<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><title>GameFAQs: Message List</title>

<link rel="stylesheet" type="text/css" href="genmessage6_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage6_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage6_files/bc.css"></head><body linkifytime="270" linkified="7" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage6_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage6_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29002092%26page%3D5"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage6_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div><a href="http://adlog.com.com/adlog/c/r=10153&amp;s=657810&amp;t=2006.07.11.19.55.31&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=01c17-gne-ad544AD542F1FF6530/http://www.gamespot.com/pc/action/bladeofdarkness/index.html?q=blade%20of%20darkness" target="_blank"><img src="genmessage6_files/severance_leader.gif" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage6_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29002092&amp;page=5">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29002092" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">First
          Page</a> |
          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=4">Previous
          Page</a> |
          Page 6 of 10          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=6">Next
          Page</a>
          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=9">Last
          Page</a>
      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/6/2006 2:47:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317777315">message detail</a>
 | #251</td></tr>
<tr class="even">
<td>
Okay, since you've obviously believed every word I've said until now,
we've got a Vyse/Laharl match here. Two entrants who couldn't draw 60%
on a hunk of stale bread. Two entrants who couldn't draw 65% on a 404
Error. You get the picture. Simply put, although Silent Hill looks to
be at a slight disadvantage, a good portion of the site isn't going to
have a strong preference towards <i>either</i>.
So where do they vote? Some might not vote at all, some might vote with
their bracket, and some might just vote for the one they recognize
better. I'm banking on the name "Silent Hill" being more recognizable
to the ones who don't care about either. As such, it will be swaying
votes and brackets (and hence bracket voters) towards Silent Hill. The
Silent Hill franchise has been around longer, its games have been on
bigger systems in the PS2 and X-Box rather than the GBA and Gamecube,
and also the franchise has recently had a movie released, and one that
had quite a bit of hype. It's simply more well known.<br> <br>Am I
saying people will come to vote for a movie? No. I'm saying ambivalent
voters will let the movie be the tiebreaker between two unknowns, be it
by just recognition, or by actually liking the movie, that's all.<br><br><b>Lopen's Prediction:</b> Silent Hill with 53.17%<br><br> <br> <br> <br>Comments:
Aside for Lopen, the Crew thinks Fire Emblem will win this match.
Hopefully we'll see our first not-blowout match of the Contest here.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=965303&amp;board=8&amp;topic=29002092" class="name">SephirothG</a> |
Posted 7/6/2006 2:48:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317777518">message detail</a>
 | #252</td></tr>
<tr class="even">
<td>
&lt;3 Lopen. If we go down, we go down together.<br>---<br>[Something clever was here before the sig wipe]<br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=965303&amp;board=8&amp;topic=29002092" class="name">SephirothG</a> |
Posted 7/6/2006 2:49:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317777684">message detail</a>
 | #253</td></tr>
<tr class="even">
<td>
<i>Am I saying people will come to vote for a movie? No. I'm saying
ambivalent voters will let the movie be the tiebreaker between two
unknowns, be it by just recognition, or by actually liking the movie,
that's all.</i><br><br>Lopen just nailed you all!<br>---<br>[Something clever was here before the sig wipe]<br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/6/2006 2:50:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317778015">message detail</a>
 | #254</td></tr>
<tr class="even">
<td>
<i>Leonhart&#8217;s Prediction: Fire Emblem with 55.54%</i><br><br>Too close to my prediction, Leon<i>!!</i><br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3452790&amp;board=8&amp;topic=29002092" class="name">ApplesauceSign</a> |
Posted 7/6/2006 2:51:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317778127">message detail</a>
 | #255</td></tr>
<tr class="even">
<td>
Oh, HaRR's analysis reminds me, my mom just joined up for a bowling
league every saturday night, she was wondering if you guys could switch
to fridays. She'd have called you, but you didn't pay her last time and
they turned off the phone.<br><br>---<br><b>Explicit Content</b><br>Cheer Up Emo Kids.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/6/2006 2:52:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317778592">message detail</a>
 | #256</td></tr>
<tr class="even">
<td>
I still say the movie will do nothing for it in the poll. A movie
didn't help Lara, a movie didn't help Jill, and it won't help here as
well.<br><br>I'll
go even further to say that just by putting Marth and Roy in the match
pic would be more of a help to FE than the Silent Hill movie is to SH.<br>---<br>Moltar Status: Excited, the Contest is here at last!<br>Metal Gear vs. Soul Calibur - Bracket: <b>MG</b> - Vote: <b>MG</b> (4/4)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=126509&amp;board=8&amp;topic=29002092" class="name">Inviso</a> |
Posted 7/6/2006 2:54:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317779047">message detail</a>
 | #257</td></tr>
<tr class="even">
<td>
&lt;3 Lopen for not making it a blowout of everyone picking FE.
Although there are two outcomes I can see for this match. FE winning
with over 55% or Silent Hill winning with less than 52%. Still, good
luck.<br>---<br>"WHO THE **** DESIGNED THIS ****ING HOSPITAL?!"-Hara Kazuko</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29002092" class="name">UltimaterializerX</a> |
Posted 7/6/2006 3:11:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317782976">message detail</a>
 | #258</td></tr>
<tr class="even">
<td>
I think I have the highest pick.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), FE8, WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/6/2006 3:13:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317783513">message detail</a>
 | #259</td></tr>
<tr class="even">
<td>
Inviso, do you think that Silent Hill will win?  (Not <i>can</i>... WILL!)<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=162204&amp;board=8&amp;topic=29002092" class="name">The n00b Avenger</a> |
Posted 7/6/2006 3:13:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317783596">message detail</a>
 | #260</td></tr>
<tr class="even">
<td>
<i>The Silent Hill franchise has been around longer</i><br><br>Psh, Fire Emblem predates Silent Hill by 7 years or so &gt;_&gt;<br>---<br>ertyu and VeghEsther are truly proof that there is much about this world we still do not understand.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=304351&amp;board=8&amp;topic=29002092" class="name">Mac Arrowny</a> |
Posted 7/6/2006 3:24:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317786062">message detail</a>
 | #261</td></tr>
<tr class="even">
<td>
<i>I still say the movie will do nothing for it in the poll. A movie
didn't help Lara, a movie didn't help Jill, and it won't help here as
well.</i><br><br>Arguably, Lara got a boost against Zelda because of
the movie. She was at 23% in the stats in 2k3, compared to 15% in 2k4.
An 8% boost is certainly not too shabby.<br>---<br>Pity for the guilty is treason to the innocent.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/6/2006 3:24:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317786103">message detail</a>
 | #262</td></tr>
<tr class="even">
<td>
<i>Am I saying people will come to vote for a movie? No. I'm saying
ambivalent voters will let the movie be the tiebreaker between two
unknowns, be it by just recognition, or by actually liking the movie,
that's all.<br><br>Lopen just nailed you all!</i><br><br>I said the same exact thing!  I just don't think it's going to be enough to take down Fire Emblem.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=965303&amp;board=8&amp;topic=29002092" class="name">SephirothG</a> |
Posted 7/6/2006 3:33:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317788153">message detail</a>
 | #263</td></tr>
<tr class="even">
<td>
ya well u stink than loxd<br>---<br>[Something clever was here before the sig wipe]<br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3224997&amp;board=8&amp;topic=29002092" class="name">WildCherrySoul</a> |
Posted 7/6/2006 3:35:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317788564">message detail</a>
 | #264</td></tr>
<tr class="even">
<td>
Wooo! Not completely boxed in like I originally thought.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br><i>^5 SOWL IMHO</i> - Explicit Content</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2273363&amp;board=8&amp;topic=29002092" class="name">shadow8021</a> |
Posted 7/6/2006 4:29:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317800693">message detail</a>
 | #265</td></tr>
<tr class="even">
<td>
Tag<br>---<br>Series Contest Score: 4/4<br>Today's Pick: Metal Gear</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29002092" class="name">Lugia2</a> |
Posted 7/6/2006 4:48:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317805303">message detail</a>
 | #266</td></tr>
<tr class="even">
<td>
No 60%?  Darn.  Fire Emblem isn't THAT fodderish, is it?<br><br>Still,
I just can't see Silent Hill taking it. Fire Emblem has the Nintendo
thing going on, and we may see a Starcraft kind of thing if things get
too close.<br><br>Remember: Mass swords, instant win!  Unless the enemy is using lances....<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/6/2006 9:03:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317864939">message detail</a>
 | #267</td></tr>
<tr class="even">
<td>
Sure thing EC...as long as she still drives to Denny's in her birthday suit to meet me.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29002092" class="name">UltimaterializerX</a> |
Posted 7/6/2006 11:04:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317893843">message detail</a>
 | #268</td></tr>
<tr class="even">
<td>
I can't believe I'm the only one that picked FE to win with over 60%.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), FE8, WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3224997&amp;board=8&amp;topic=29002092" class="name">WildCherrySoul</a> |
Posted 7/6/2006 11:09:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317894932">message detail</a>
 | #269</td></tr>
<tr class="even">
<td>
So much for the 60%...<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br><i>^5 SOWL IMHO</i> - Explicit Content</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29002092" class="name">BlAcK TuRtLe</a> |
Posted 7/6/2006 11:11:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317895380">message detail</a>
 | #270</td></tr>
<tr class="even">
<td>
69.69% was mine. And we still haven't seen the day vote, which will no
doubt favour the series that has a SSBM character in the match pic!<br><br><br><b>TuRtLe</b><br>~~~<br>Like Darth Maul, the bastard child of Michael Flatley and Hellboy. -trancer1</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=416122&amp;board=8&amp;topic=29002092" class="name">Meatwadd</a> |
Posted 7/6/2006 11:17:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317896944">message detail</a>
 | #271</td></tr>
<tr class="even">
<td>
mr. moltar!<br><br>&gt;_&gt; long time no see...<br>---<br><i>Seekin that silence, Realizing what a mic was for,<br>Unleashed the power, my lines are war, So do you wanna piss me off anymore?</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/6/2006 11:25:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317898729">message detail</a>
 | #272</td></tr>
<tr class="even">
<td>
Ya know, that's like the second time in three days you predicted 69.69%
for a series to win, and 69.69% ain't exactly inspired guessing.<br><br>Just sayin'.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/6/2006 11:31:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317900201">message detail</a>
 | #273</td></tr>
<tr class="even">
<td>
<i>I can't believe I'm the only one that picked FE to win with over 60%.</i><br><br>We all knew better. =p<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29002092" class="name">Lugia2</a> |
Posted 7/7/2006 5:57:03 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317946686">message detail</a>
 | #274</td></tr>
<tr class="even">
<td>
Is it just me, or is FE going DOWN in percentage?<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29002092" class="name">UltimaterializerX</a> |
Posted 7/7/2006 8:46:19 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317957638">message detail</a>
 | #275</td></tr>
<tr class="even">
<td>
Hey now, that 60% looked damn good early when FE was pulling in over 100 votes every update =p<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), FE8, WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/7/2006 8:51:46 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317958187">message detail</a>
 | #276</td></tr>
<tr class="even">
<td>
I knew I should have lowered my Crew pick to 57%, oh well...<br> <br><i>I can't believe I'm the only one that picked FE to win with over 60%.<br><br>We all knew better. =p</i><br><br>Ha Ha<i>!!</i><br>---<br>Moltar Status: Excited, the Contest is here at last!<br>Fire Emblem vs. Silent Hill - Bracket: <b>FE</b> - Vote: <b>FE</b> (5/5)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/7/2006 10:10:54 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317968078">message detail</a>
 | #277</td></tr>
<tr class="even">
<td>
Metal Gear................69.89% 77349<br>Soul Calibur.............30.11% 33321<br>TOTAL VOTES....................110670<br><br>88.25% of the brackets predicted this match correctly.<br><br>Metal
Gear started very strong, but Soul Calibur fought hard and brought
itself over 30% before the end of the match. Still, Soul Calibur is the
strongest 8 seed, so Metal Gear's performance isn't as bad as it looks.<br><br>Today, Fire Emblem and Silent Hill are having the closest match yet, but Fire Emblem is looking to run away with the day vote.<br><br>HM - 2<br>Moltar - 1<br>Soul - 1<br>HaRRich - 1<br>Ulti - 1<br>Leon - 0<br>Yoblazer - 0<br>Mnm - 0<br>Lopen - 0<br><br>HM and I had the same prediction, and it paid off. Go us!<br>---<br>Moltar Status: Excited, the Contest is here at last!<br>Fire Emblem vs. Silent Hill - Bracket: <b>FE</b> - Vote: <b>FE</b> (5/5)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/7/2006 12:47:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317996661">message detail</a>
 | #278</td></tr>
<tr class="even">
<td>
I would like to take the time to mention, with my first post back, that even though I'm not going to get the point here...<br><br>Heroic Mario sucks for upping me by <i>.01%</i>
and ruining any chance I had at getting this point. And with the way
this contest has been going, I have a feeling that tomorrow's
prediction is going to be a tad low. I'm not changing anything though.<br><br>With that, I'm off to watch Pirates of the Caribbean: Dead Man's Chest.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/7/2006 12:48:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317996880">message detail</a>
 | #279</td></tr>
<tr class="even">
<td>
Oh wait, one more thing:<br><br>Curse HaRRicH for stealing my Suikoden/MMX point!<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/7/2006 2:21:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318017645">message detail</a>
 | #280</td></tr>
<tr class="even">
<td>
<b>Snake Division:</b> <i>Round 1 - Match 7</i> &#8211; (3)Castlevania vs. (6)Halo <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Castlevania</b><br>The
Castlevania series is admired highly on GameFAQs. Symphony of the Night
is like, one of Board 8&#8217;s favorite games. The series is still going
with Dawn of Sorrow on the DS (Get it?! lolz)<br> <br><b>Halo</b><br>Casuals
love Halo. The Halo franchise sells so well here, it&#8217;s unbelivable. It
only has Halo and Halo 2, but it has become the biggest series on the
Xbox and one of the biggest selling franchises this generation.<br><br>What
is up with these 3 seeds? Pokemon, Castlevania, Elder Scrolls, all
stand some chance of being upset this round. The only series that looks
to be safe this round is Sonic. I wonder what Alucard would say about
something like this.<br><br>Alucard: It&#8217;s all a part of my plan.<br><br>So, your plan is to bring back the infamous 3-seed curse?<br><br>Alucard: Yes, isn&#8217;t it excellent! My plans never fail!<br><br>Err&#8230;okay. Anyway, the Castlevania series usually does well in GameFAQs contests.<br><br>Alucard: Yes, I do. That&#8217;s all a part of my plan.<br><br>But this time, it faces the Halo series in Round 1. I don&#8217;t know how the Halo series only managed to get a 6 seed?<br><br>Alucard: Me either, Halo is some good ****.<br><br>&#8230;Yes,
anyway. We all remember what happened to Halo in 2004, when Starcraft
upset it in a close match. However, many seem to be forgetting how
strong Starcraft is, and that Halo is just about on par with it. The
Halo hate is overrated. Castlevania may be strong, but Halo is much
stronger. When I first saw this match in the bracket, I hesitantly went
with Halo. After some time though, I grew more confident in a Halo
victory.<br><br>Alucard: But Moltar! Master Chief barely beat teh Kawng!<br><br>Characters
=/= Games. All signs are pointing to the Halo series being stronger
than Master Chief. Even 2004 hinted strongly at that. The match should
go something like this. Castlevania leads during the night, but once
day breaks, Halo runs away with it. Then evening hits and CV slowly
chips away at the lead, but not by enough to win. Those with
Castlevania winning this match are most likely just blinded by the Halo
hate. Halo has this in the bag.<br><br>Alucard: My plan will be a success. It will-<br><br>*From
out of nowhere*: EVERYBODY ESCUCHAME! Listen, Haha, TO ME! MY NAAME! IS
ARMANDO! ALEJANDRO! ESTRRRRRRAAAADA!!! And I! Haha! Got something! For
j00!! THEE SAMOAN BULLDOZER, UUUUMAAAAGA!!! <br><br>*Umaga comes out
of nowhere and crushes Alucard with the Almighty Samoan Spike! He then
leaves to his awesome music, leaving Moltar in shock.* <br><br><b>Moltar&#8217;s Bracket Says:</b> Halo will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Castlevania: 44% - Halo: 56%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>This
is a fun little match. On one hand we have a series spanning across
consoles since the NES days, and on the other we have.... two games.<br><br>Halo
is an interesting case, because I doubt its rabid fans will look at the
poll and go "Well Halo only has two games, and this is a SERIES
contest, so... *votes CV*". This mentality may hurt Kingdom Hearts and
Super Smash Brothers a bit later in the contest, but I doubt it will
hurt Halo much. It's the least transitive contest entity ever, and I
doubt this being a series contest will matter much.<br><br>There's also
the fact that even though Metroidvania has been around forever, it
can't seem to get out of niche status. It may quite literally be
banking on SOTN to win this match and little else, which isn't going to
be enough to cancel out the might of Halo's fans and Halo 2's smash
success. This is one of those matches that's being overrated because of
Board 8's disdain for the Xbox.<br><br>That said, CV might take an
early lead and hold it for awhile before Halo comes back in the
afternoon and smashes it. Halo likes doing that.<br><br>Prediction: Halo with 57.67%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/7/2006 2:21:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318017751">message detail</a>
 | #281</td></tr>
<tr class="even">
<td>
<b>Soul&#8217;s Analysis</b><br> <br>Again, a match that's supposed to be
close but will be a blowout. Don't be fooled by the seeds in this one.
Halo will win this, and will win quite easily.<br><br>The main thing
going for Castlevania is the fact that it has many different games on
many different consoles. Halo will be weaker because it's only on the
XBox. If that's the only reason you have, then I pity you and laugh
when you lose your point. Castlevania has never been a strong series in
this contest. In fact, the only game that has proven to have any
strength at all is SotN. And SotN by itself is a league under the
original Halo. Now, do you really think the rest of the Castlevania
series can push Castlevania on top of the original Halo <i>and</i> Halo 2?<br><br>It's not happening people. Again, the match looks good on paper, but it will be a rather convincing win for Halo.<br><br><b>My prediction: Halo wins with 68.72% of the vote.</b><br> <br> <br> <br><b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Halo<br>Top 100 List comparison:<br>---C:SotN - #15<br>---Halo - #9, Halo 2 - #85 (one of the two write-ins to successfully make the Top 100 List)<br>Best Game Ever x-stat comparison:<br>---C:SotN - 20.27% (was behind GE007/LoZ:OoT)<br>---Halo - 37.24% (was behind Starcraft)<br><br>While
there's a first-round match that I believe will be closer AND is harder
to predict AND includes two of my favorite series (Mega Man/Mario
Kart), this is probably the first-round match I'm looking forward to
the most because of the night-time/day-time swings that will be seen
for sure. Alucard is notorious for having a good night-vote and then
bomb during the day-time, and C:SotN went with the same pattern against
Perfect Dark and Goldeneye. Meanwhile, Master Chief is known for doing
really bad at night-time and then soaring with the day-vote, and
Halo/Starcraft is a perfect example of this as well: started off
behind, then made a big come-back in the day, then lost it in the final
hours of the night (MC/Frog fits it perfectly, too). For a match like
this that should be fairly close anyway, that means one thing: massive <i>massive</i> <b>MASSIVE</b> comeback.  No matter who wins, you will see both games ahead of each other at some point in the poll.<br><br>Now,
as for why I'm picking Halo...while the Game Contest stats probably
have Halo over-rated and C:SotN under-rated, there is still a huge gap
to fill (unadjusted stats say C:SotN gets only <i>27.22%</i> on Halo
in 2004), and I would think Halo's stock has had more room to rise
since then than Castlevania's. Even when you consider them both being
over/under-rated, I think it's a given that Halo would beat Perfect
Dark pretty hard...and it got 46.82% on C:SotN in 2004. Also, 46+% of
Castlevania fans believe C:SotN is the best one, and I don't think any
other game had even 8%. Halo 2 and the 360 have since been released,
and -- though MC showed no signs of boosting last year except for
MC/Crono -- Halo 2 was the runner-up for GotY in 2004 and enough people
wrote in Halo 2 on the Top 100 List to get it in there. There are three
things that make me wary about Castlevania though: the number of games
it has, the systems and generations it has spanned, and Halo/Halo 2
ownership has a big over-lap. It hurts Halo that it's restricted to the
least popular console, too...but for Castlevania being niche, I don't
see it affecting Halo as much as it could.<br><br>It should be one of the most exciting matches of the contest.<br><br>Halo wins with 52.12%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/7/2006 2:22:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318017904">message detail</a>
 | #282</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>Now here comes the first really tricky
match of the contest. This is the first match that made me sit there
for a few seconds and think about it when I was filling out my bracket.
And unlike the other tough calls of the first round, this is
potentially a three-point match, as the winner has a good chance of
winning another match in the next round. In a sense, this could wind up
being the most important match in the bracket (in terms of needing to
get it right to succeed) other than the final.<br><br><i>Finally</i>,
we have a match where we have plenty of contest data with which to
compare both entrants. Let&#8217;s start with the higher seed, Castlevania
(seems odd to say that considering Halo is usually the overseeded one
and Castlevania is usually the underseeded one). Of course, the most
popular entry to the series is Symphony of the Night, and, with the
exception of Simon Belmont in SC2K2, it is the only game in the series
with contest experience. Alucard is a Character Contest mainstay, one
who owns the ignorant casual bracket makers with &#8220;The Plan&#8221; every year.
In his most recent appearance, he defeated Kratos (the God of War one,
not the Tales of Symphonia one) before bowing out against Sora with 45%
in what was expected to be one of the biggest toss-ups of SC2K5. The
Kingdom Hearts kid then went and bombed against Solid Snake, leaving us
without a good read on Alucard for nearly three years (he was behind
Link/Ganondorf SFF in 2004). However, many were convinced that he was
on the way down. <br><br>In the Games Contest, Symphony of the Night
had a somewhat easy win over Perfect Dark in a poll that didn&#8217;t update
for several hours, though the margin of victory was nothing impressive.
In the second round, it struggled to break 40% on GoldenEye, which in
turn looked bad when GE got owned by Ocarina of Time. However, the Top
100 List has perhaps given SotN a measure of redemption, finishing 15th
and GoldenEye breaking the top 10 at #7. While it should hardly be
considered indicative of contest strength (games with hardcore
followings like Symphony of the Night are likely to be overrated,
simply based on the format, I think), it does make you feel better
about SotN not being nearly as weak as it ended up looking.<br><br>On
the other hand, you have Halo. As far as character contests are
concerned, Master Chief has perhaps been one of the most inconsistent
(if not THE most inconsistent) oddities we&#8217;ve ever seen. In 2003, he
barely defeated Felix of Golden Sun &#8220;fame&#8221; (who has promptly never been
seen since) before getting 40% on Aeris, which is actually a
respectable performance. In the end, Felix actually looked like a
decent competitor (he finished 32nd in the stats, above Wario and
Yuna), even when Isaac, another Golden Sun character, had all the
makings of fodder.<br><br>In 2004, Master Chief ripped Crash Bandicoot
to shreds in a match where people thought he could actually perform
decently because he was facing a character even more hated than he was.
In the second round, he lost to Frog in one of the most memorable
matches the GameFAQs Contests have ever seen, falling short by a mere
seven votes. When the Chrono Trigger character scored over 48% on Solid
Snake, the effects of Halo 2 seemed to have set in early, and Master
Chief had propelled himself to high midtier.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/7/2006 2:23:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318018081">message detail</a>
 | #283</td></tr>
<tr class="even">
<td>
2005 was a bit of a reality check for the Chief, despite getting a 1
seed and his own division. He struggled to double up CATS in the first
round, and after falling far behind in the early hours, needed a
massive comeback to defeat Donkey Kong, of all people. Of course,
because the big ape is an even bigger choke, Master Chief still managed
to beat him, but with Frog getting exposed by Samus, he suddenly didn&#8217;t
appear to be quite as strong as he looked only a year ago. However, he
always seems to go out with a bang. He got nearly 39% on Crono
(although he never won an update, like I guaranteed Lopen he
wouldn&#8217;t!), an impressive performance. Either way, Master Chief proved
that he was strong enough to avoid getting blown out except by perhaps
the strongest of characters (Link, Cloud, and Sephiroth, for certain,
maybe Mario and Samus as well), but his true strength is unknown,
perhaps unstable at best.<br><br>Then,
of course, there&#8217;s Halo as a game. It was on the losing end of one of
the most legendary matches of all-time, the first and thus far only 16
seed upsetting a 1 seed. Even though it looked bad at the time, Halo
ended up looking pretty good in the stats. It fell in between The Wind
Waker and Final Fantasy X in the stats, and is actually expected to get
49.56% on Super Smash Brothers Melee. Granted, StarCraft is a bit
erratic and is hard to trust as far as stat values go, but for the
featured game on the supposedly hated and anti-voted XBox, Halo proved
its strength. Then, Halo placed at #9 on the Top 100 Games List, even
ahead of Final Fantasy VI, though it was a format that favored the game
(no anti-voting). Halo 2 was also one of only two write-in games to
make the list.<br><br>The biggest advantage that Castlevania has in its
corner is its wide variety of games spanning across several generations
and consoles. Halo is very new, having only debuted this generation and
only on one console (well, I suppose you COULD count the PC version,
but&#8230;) thus far. Plus, there is likely a high overlap in the fanbase
between the two games. However, I believe that Castlevania is probably
a little too niche to win, but it should certainly hold its own here.<br><br><i>Leonhart&#8217;s Prediction</i>: <b>Halo with 54.98%</b><br> <br> <br> <br><b>HM&#8217;s Analysis</b><br> <br>This is a <i>huge</i>
match &#8230; at least if you went by the board. I have to say that the hype
surrounding this one has baffled me from the start. Are people really
thinking the history of the series and amount of games is going to
overcome a monster powerhouse with only two games? It would appear that
people are at least entertaining the idea that Castlevania stands a
chance here. I have to say I disagree with this idea, myself. <br><br>I
will readily admit that I&#8217;m one of those people who believe that
combining all of the series&#8217; games together is going to make it
stronger and more popular than any singular game. But there is also a
&#8220;hidden requirement,&#8221; so to speak, that I always just include as a
given when discussing things like this &#8211; is the series strong to begin
with? I don&#8217;t think Castlevania has really been neither all that
impressive nor that strong for the contests that have taken place on
this site. Alucard, for a while, was pretty impressive in the character
contest. It seems that he has been slowly taking gradual falls as of
late, but he hasn&#8217;t turned into fodder or anything. To me, Castlevania
needs to be <i>impressive</i> for me to take it over a beast like Halo.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/7/2006 2:23:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318018227">message detail</a>
 | #284</td></tr>
<tr class="even">
<td>
If you look at the performance of Castlevania : Symphony of the Night &#8211;
one of my favorite games of all-time, I might add &#8211; in the games
contest you can see it wasn&#8217;t terribly strong. The placement in the
extrapolated standings was right at 20% on Final Fantasy VII, and
around titles like Sonic 2, Xenogears, Mortal Kombat, and Doom. Just
looking at those games, that is nothing to shrug off as nothing, but
you have to look at where Halo is in relation to these games. You have
to go up <i>17%</i> before you get to where Halo ranks. That is <i>insane</i>.
The difference between the two games is far, far too significant for me
to think of Castlevania as a serious threat to the most popular and
dominate IP in the gaming industry right now. The mere mention of Halo
makes people wet themselves &#8211; I admit that just seeing something about
Halo gives me the chills because it&#8217;s just so damn badass. <br><br>Another
thing to ask is &#8220;Are there any games in the Castlevania series more
popular than Symphony of the Night?&#8221; I believe the answer to that is
&#8220;No.&#8221; I doubt any of the NES or SNES games are going to end up being
more popular. The GBA incarnations, while good, are not generally
viewed as better. So you would be taking games <i>weaker</i> than
SotN, which in turn is significantly weaker than Halo : Combat Evolved,
and adding them together. This is all going to somehow add up enough to
allow it to overcome this monstrous series. There is a funny thing
about this analysis thus far &#8211; I haven&#8217;t even mentioned Halo 2, the
game that shattered pre-order records and sold millions in 24 hours. I
have no doubt in my mind Halo 2 is stronger <i>and</i> more popular than Halo 1. This is just spelling murder &#8230;<br><br>I
often find myself using the &#8220;quantity and quality over just quality&#8221;
argument (Sonic over SSB; Mega Man over Mario Kart; etc.), but a
primary support of that argument is that there are more popular games
in those series than we may have seen or they are already strong games
being all put together. With Castlevania, you&#8217;re taking games that are
weaker and adding them together. They are diverse, but they don&#8217;t hold
very much strength, even when packaged together, I don&#8217;t think. Halo,
on the other hand, is an entirely different beast that has some split
fans between those who think Halo : Combat Evolved is the better game,
plus those who think Halo 2 is far superior. On top of that, though
this is not as big a factor, Halo 3 was shown in trailer form during
E3, which could only help. <br><br>Ultimately, I think people are
thinking far too much on this one. I believe it will end in a match
that is not even remotely close, but not a complete blowout. For all
the debate this match is getting, it&#8217;ll all be for not as soon as the
match begins. Halo wins here without trouble to face Kingdom Hearts in
round 2. <i>Book it!!</i><br><br><b>Aitch Emm&#8217;s Bracket Says :</b> Halo will win.<br><br><b>Aitch Emm&#8217;s Prediction :</b> Halo 62% -- Castlevania 38%<br><br><b>Aitch Emm&#8217;s Vote :</b> Castlevania<br><br><br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Here
we have another decently disputed match between two very different
series. In the drearily dressed corner, Castlevania! Castlevania is
wise. Castlevania is ancient. Castlevania has stared at a full moon on
many different homes. TRUE gamers LOVE Castlevania. Hey, this sounds
like Mega Man Lite! Of course, let us give credit where credit is due.
Unlike Mega Man, Castlevania has one game in its arsenal that the rest
of the series can rally around and benefit from its power. That game is
Symphony of the Night. Hailed as one of the greatest video games of all
time, Symphony of the Night is clearly Castlevania's crowned jewel. It
has a recognizable fanbase on GameFAQs, and it has proven it more than
once. Sadly, other than a decently strong core game, Castlevania has
nothing outside of its legacy. Can that legacy be enough to earn it
this win?</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/7/2006 2:25:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318018528">message detail</a>
 | #285</td></tr>
<tr class="even">
<td>
I do not think so. Castlevania's career has been relegated exclusively
to Nintendo handhelds for the past five years, and as we all know,
handhelds don't cut it when it comes to poll popularity. It has had a
very small, forgettable presence on the PS2 and a largely disliked one
on the N64. Really, Symphony of the Night is the only notable thing
that links the series to its days of old. Now, can a series with a
solid anchor and several small-time players take out a twin-headed
behemoth? Let's take a look at Halo...<br><br>Halo
has, without a shadow of a doubt, been the biggest new gaming series of
the past five years. It has single-handedly saved its system, a claim
which no other series can make. Nintendo had Mario, but they also had
Zelda, Metroid, and Mega Man. Sony had Final Fantasy, but they also had
Crash Bandicoot, Tomb Raider, and Metal Gear Solid. Sega had Sonic, but
they also had... well, not being a Sega fan, I have no idea what else
they had, but maybe that's why they're dead now, haw. The Xbox has Halo
and NOTHING else. Without Halo, Microsoft's biggest exclusive would be
Fable. Without Halo, the Xbox would have been a disaster.<br><br>So,
what does this mean? It means Halo is a series with a religiously
devoted fanbase. Even on GameFAQs, people care, and they've been caring
more over the past few years. Save for a rookie loss to Aeris in 2003,
neither Master Chief nor Halo has ever been blown out in a contest
match. They may lose, but they sure as hell don't lose quietly. Master
Chief impressed us twice in 2004 (Crash Bandicoot and Frog) and once
more in 2005 (Crono). The original Halo, while falling just a bit short
against Starcraft, proved at least one thing: the Halo fans will never
hesitate to rally for the cause. Could Castlevania make such a claim
about its voters? My money's on "no."<br><br>Halo may be a two game
series, but either of those games could beat Castlevania's strongest
title in a direct match. True, there may be a huge fanbase overlap for
Halo, but the original game and Halo 2 are simply too strong for it to
change the outcome. Of course, there's always the chance that voters
really WILL take the whole series into consideration before voting, and
that <i>could</i> change the outcome.<br><br>Castlevania<br>+ Lots of games<br>+ Spans many systems and eras<br>+ Strong main game<br>- Halo has two stronger games<br>- What have you done for me lately?<br>- Fanbase doesn't strike me as rabid enough to get the job done<br><br>Halo<br>+ System saver. This series has defined Microsoft's console for five years.<br>+ Two strong games<br>+ Rabid, loyal fanbase<br>- Severely outnumbered in the game count department<br>- Its fanbase could stand to be a bit bigger on GameFAQs<br><br>My prediction: Halo def. Castlevania (53-47) <br><br> <br> <br><b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: Festival of Servants (SotN)<br><br>After a match that made my head explode, we get a match that wasn&#8217;t <i>quite</i>
as tough for me to decide on. I admit that this wasn&#8217;t exactly a walk
in the park for me either though. We have the famed Halo series opening
this contest as a <i>lower</i> seed?  To <i>Castlevania</i>?  Board 8&#8217;s influence is apparent.  Not that I mind though, as I absolutely love the Castlevania series!</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/7/2006 2:25:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318018672">message detail</a>
 | #286</td></tr>
<tr class="even">
<td>
We already have a good idea of Halo&#8217;s strength on this site. In 2k4,
Halo gave Starcraft a battle for all it was worth. We&#8217;re talking a 373
vote difference out of about 113k votes. If that match happens again
today, Halo probably wins. Halo has come a long way since the early
Xbox days. In the beginning, this site had a very significant anti-Xbox
sentiment. It got bad enough that Ceej actually turned the Xbox into an
April Fool&#8217;s Joke. But since then, the Xbox hate has died down. Halo
itself is representive of that. It&#8217;s gone from getting trounced in the
2001 GotY poll to Halo 2 getting runner up in the &#8217;05 GotY poll. In the
&#8217;05 extended poll, it actually nearly <i>won</i>.
And looking at Halo&#8217;s #8 spot on the Top 100 games list, it&#8217;s apparent
that the Xbox fanbase has a strong presence on this site. It may not be
as widespread as the Nintendo or Sony fanbase, but it has a significant
presence. Unfortunately, there is also a good deal of the GameFAQs
demographic that want nothing to do with the Xbox, so a strong opponent
always has a fighting chance against Halo.<br><br>That&#8217;s where
Castlevania comes in. Now people may take a glimpse at the Castlevania
favorites poll and assume that Symphony of the Night is the only game
that Castlevania fans care about. That is hardly the case. Castlevania
is a series that has deep roots and games spanning across many systems.
SotN may be the most <i>popular</i> game in the series, but it doesn&#8217;t
mean at all that fans don&#8217;t care about the other games in the series.
You can look at that very poll and see that outside of SotN that the
NES games have a fanbase, the handheld games have a fanbase, the N64
games has a small fanbase, the SNES games have a fanbase&#8230; You can even
see in the GBA GotY polls that the handheld games always get a bit of
support. And let&#8217;s not forget Dawn of Sorrow, which did pretty well for
itself in the DS GotY poll. It&#8217;s really not all about SotN. <br><br>Some
people think that the Castlevania series won&#8217;t be much stronger than
SotN was in the games contest. I have to adamantly disagree with that.
SotN may be the most popular game in the series but it isn&#8217;t a game
that encompasses the series, especially not in a way that SSBM
encompasses the SSB fanbase. There are <i>plenty</i> of Castlevania fans who&#8217;ve never even played Symphony of the Night.  The game may have sold okay, but it doesn&#8217;t have <i>that</i>
kind of numbers behind it. And it&#8217;s been really hard to find as of
late. I&#8217;m willing to bet a good deal of that handheld fanbase is
exclusive of the SotN fanbase, no matter how similar the games are. The
Castlevania series will definitely be drawing from more than SotN.<br><br>Fortunately
for Halo, its fanbase is strong enough to counter this. Being about as
strong as LoZ:WW and SSBM is no joke. And since then, we&#8217;ve had Halo 2
drop on us, as well as Xbox hate dying down, and the system slowly
becoming more popular since 2k4. It definitely will be bringing it in
this match. But since there&#8217;s still a good percentage of the site that
doesn&#8217;t care for Halo and the Xbox at all, it will almost never blow
anything out. And Castlevania is definitely going to be a strong
opponent for it. Speaking of Castlevania, SotN&#8217;s matchup with Goldeneye
is a good starting place for it. Goldeneye beat SotN 59-41. Halo is
comparable to Goldeneye (don&#8217;t forget OoT/GE SFF), although it&#8217;s
probably a good bit more popular. But Castlevania will be stronger than
SotN as well. Look for it to give Halo a run for its money.<br><br>Bracket: Halo<br>Vote: Castlevania<br>Prediction: Halo with 54.32%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/7/2006 2:26:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318018948">message detail</a>
 | #287</td></tr>
<tr class="even">
<td>
<b>Lopen&#8217;s Analysis</b><br> <br>I'm having such a tough time analyzing
this one. It seems like it could be a dangerous match for Halo. I think
Castlevania will be putting up a better fight than Kingdom Hearts. And
yet, at the same time, there's not too much doubt in my mind Halo will
be taking this.<br><br>"Does GameFAQs <i>really</i> care about any
Castlevania game that isn't named Symphony of the Night?". Good
question, and one that pretty much decides the match in my books. As
for me? I'm saying "no". Unfortunately, there isn't all <i>that</i>
much I can really bring up to support or deny this claim that I can
think of aside from "intuition". What do we have to represent the other
games? Simon Belmont in the character contest, I guess. Yeah, he didn't
do too well for himself. Not a death sentence, but that can't be
interpreted as <i>good</i>. We also have a few polls involving the
offerings for the DS and Gameboy Advance. These are probably
Castlevania's second biggest threat. They did fairly well in polls, but
if I recall correctly it was nothing to make me think they're
absolutely huge for the series here either. A factor? Yes, some extra
votes here and there&#8230; but is it enough?<br><br>Anyway, the main point
here is that Halo has looked pretty decisively more popular here than
Symphony of the Night, and that's the main gun for Castlevania. And it
has looked this way for quite a while, during pre Halo 2 days, and
during days when X-Box hate was higher. Will the rest of series be able
to make up for this strength gap between Symphony of the Night and a
Halo powered up with Halo 2's release and more acceptance from
GameFAQs? It definitely has the potential to do so, with a horde of
games out there that <i>could</i> be fairly popular. And to be honest,
I think it's more of a threat to beat Halo than Kingdom Hearts is
because of this wild number of games that it has. But, Castlevania
games just aren't typically the kind of games that have people raving
here on GameFAQs. And I don't think a bushel of games that are just
liked here (from what I see) are going to be able to make enough of a
difference to make up for SotN's pretty substantial initial
disadvantage.<br><br><b>Lopen's Prediction:</b> Halo with 54.75%<br><br><br> <br>Comments:
For such a debated match, the Crew has Halo winning 9-0. Personally, I
think Soul is a little crazy for going so high, but the rest of us
think it will be pretty close.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1536971&amp;board=8&amp;topic=29002092" class="name">Guess how many teens</a> |
Posted 7/7/2006 2:31:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318019962">message detail</a>
 | #288</td></tr>
<tr class="even">
<td>
Well so far for credibility if Castlevania wins :P.<br>---<br>There are 2 rules to being a success in life: 1. Never give out all the information.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/7/2006 2:43:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318022966">message detail</a>
 | #289</td></tr>
<tr class="even">
<td>
Well, the last time Soul went way higher than everyone, it paid off.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29002092" class="name">Lopen</a> |
Posted 7/7/2006 2:45:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318023430">message detail</a>
 | #290</td></tr>
<tr class="even">
<td>
Yay for a 0.3% margin of victory in this one!  Damn box!  *gets to reading*<br>---<br>Raiden is still [<i>!!</i>] nominations short!  <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/7/2006 2:51:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318024780">message detail</a>
 | #291</td></tr>
<tr class="even">
<td>
Well, only Soul's (and HM, to an extent) got any room to work with as far as margin of victory is concerned.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/7/2006 2:57:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318026255">message detail</a>
 | #292</td></tr>
<tr class="even">
<td>
Let's go blow-out!<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/7/2006 2:59:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318026528">message detail</a>
 | #293</td></tr>
<tr class="even">
<td>
Well, with the increased vote totals, that's got me worried that I did undershoot Halo. <br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29002092" class="name">Lopen</a> |
Posted 7/7/2006 2:59:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318026644">message detail</a>
 | #294</td></tr>
<tr class="even">
<td>
I XDed at Umaga, by the way.  Moltar so wins this one, regardless of the %s.  <br>---<br>Raiden is still [<i>!!</i>] nominations short!  <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/7/2006 3:42:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318036489">message detail</a>
 | #295</td></tr>
<tr class="even">
<td>
Ah, now's as good a time as any to finish these round 1 matches. <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/7/2006 3:50:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318038223">message detail</a>
 | #296</td></tr>
<tr class="even">
<td>
There we go. Nothing to worry about for another week.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/7/2006 3:52:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318038663">message detail</a>
 | #297</td></tr>
<tr class="even">
<td>
Been very busy lately, but I'll get my next batch of write-ups in by tomorrow, if not late tonight.<br>---<br><b>Board 8</b>: Where people treat each other <i>right</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29002092" class="name">DaruniaTheGoron</a> |
Posted 7/7/2006 3:58:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318040097">message detail</a>
 | #298</td></tr>
<tr class="even">
<td>
This match is close between Harrich and Soul...<br>---<br>...little Weezing it's gonna stand up against my ****in' Charizard? Just get back on your bike <br>and keep pretending to be cool with your lame ass mohawk ****er. - phoenix1487 <b><i>Sp2k6: 6/6</i></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/7/2006 7:42:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318088842">message detail</a>
 | #299</td></tr>
<tr class="even">
<td>
If I would have went ahead and made that +5% like I did in the Oracle contest, this match would have been <i>mine</i>.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29002092" class="name">Lugia2</a> |
Posted 7/7/2006 7:45:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318089364">message detail</a>
 | #300</td></tr>
<tr class="even">
<td>
Mind if I do a mini-analysis?  <br><br>Considering everyone else is using REAL evidence, I am going to rely on charcters.<br><br>All
right, we have Castlevania, with its main character Alucard (well, in
SotN. Simon is around, but most of us prefer Dracula backwards). He
is/was considered very strong in these contests, but, like <i>some</i>
characters, (hello thar Crono) seem to have aged a bit in 2005 after
losing to Sora. Why? I have no idea. Perhaps it's the increasing
dominance of the Nintendo nuts. Then again, those same Nintendo nuts
have been playing Castlevania on their portables for years now...<br><br>We
also have Halo, with its main character being insanely popular. How
popular? Some people think it's Noble 9 material. They're probably
nuts, but he's still popular and, at the least, a mid-carder. Still,
lot's of anti-votes, and a powerful day vote.<br><br>So an increasingly nintendo-based Castlevania to X-Box's mascot, Halo.<br><br>...And I thought this would be CLOSE?<br><br>Halo <b>60%</b><br><br>Bank it!  It won't destroy my bracket either way. ;)<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">1</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=1">2</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=2">3</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=3">4</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=4">5</a></li>
<li>      6</li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=6">7</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=7">8</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=8">9</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=9">10</a></li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage6_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29002092&amp;page=5" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage6_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>