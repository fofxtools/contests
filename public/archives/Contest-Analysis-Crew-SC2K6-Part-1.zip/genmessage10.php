<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><title>GameFAQs: Message List</title>

<link rel="stylesheet" type="text/css" href="genmessage10_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage10_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage10_files/bc.css"></head><body linkifytime="251" linkified="6" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage10_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage10_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29002092%26page%3D9"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage10_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div><a href="http://adlog.com.com/adlog/c/r=10153&amp;s=668168&amp;t=2006.07.11.19.55.40&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=01c17-gne-ad444B372693D56F0/http://www.gamespot.com/pc/action/brothersinarms/index.html?q=brothers%20in%20arms%20road%20to%20hill%2030" target="_blank"><img src="genmessage10_files/bia_rth3_buyit_leader.jpeg" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage10_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29002092&amp;page=9">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29002092" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">First
          Page</a> |
          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=8">Previous
          Page</a> |
          Page 10 of 10      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=683142&amp;board=8&amp;topic=29002092" class="name">transience</a> |
Posted 7/10/2006 9:48:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318808473">message detail</a>
 | #451</td></tr>
<tr class="even">
<td>
no matter the percentage, Ulti pretty much won today. that analysis
took every possible point and smashed it into the ground. good work.<br>---<br>xyzzy</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/10/2006 9:51:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318809276">message detail</a>
 | #452</td></tr>
<tr class="even">
<td>
But he'll pay for lowballing it! With all of the work he put into proving that Warcraft won't be much, he should've shot higher.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29002092" class="name">UltimaterializerX</a> |
Posted 7/10/2006 11:08:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318829776">message detail</a>
 | #453</td></tr>
<tr class="even">
<td>
Eh, if you say so.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), FE8, WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29002092" class="name">THEJackSparrow</a> |
Posted 7/10/2006 11:13:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318831104">message detail</a>
 | #454</td></tr>
<tr class="even">
<td>
Oh well. At least I got the point for yesterday's match.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=456743&amp;board=8&amp;topic=29002092" class="name">Sir Bormun</a> |
Posted 7/11/2006 12:35:33 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318848988">message detail</a>
 | #455</td></tr>
<tr class="even">
<td>
Uh oh, looks like the Crew might get 0 points'd again.<br>---<br>Need new sig.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/11/2006 3:02:03 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318870335">message detail</a>
 | #456</td></tr>
<tr class="even">
<td>
Super Mario Bros. vs. Madden NFL<br>+9 Leon<br>+8 HM<br>+7 Soul<br>+6 Ulti<br>+5 mnm<br>+4 Moltar<br>+3 Lopen<br>+2 yo<br>+1 HaRRicH<br><br><b>The Rankings</b> (Through Super Mario Bros./Madden NFL)<br>1. Master Moltar (42)<br>2. HaRRicH (41)<br>3. UltimaterializerX (37)<br>3. yoblazer33 (37)<br>5. therealmnm (34)<br>6. Leonhart (33)<br>7. XxSoulxX (31)<br>8. Lopen (29)<br>9. Heroic Mario (28)<br><br>---<br><b>Board 8</b>: Where people treat each other <i>right</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29002092" class="name">Lugia2</a> |
Posted 7/11/2006 6:27:43 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318884751">message detail</a>
 | #457</td></tr>
<tr class="even">
<td>
WC is ahead by 500 votes.<br><br>Woah, you guys had me fooled!  There goes the 60%+ predictions...<br><br>Props to Soul for at leasting betting that it would be close!<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/11/2006 6:29:08 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318884822">message detail</a>
 | #458</td></tr>
<tr class="even">
<td>
Crazy 60%+ indeed. I didn't figure it would be quite that high, though I never suspected that GTA would be losing like it is.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/11/2006 9:47:42 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318903121">message detail</a>
 | #459</td></tr>
<tr class="even">
<td>
Wow, has SMB/Madden's joke-analysis and over-shooting GTA/WC today ever crushed me on yo's scoring or what?  ****in' ouch.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/11/2006 9:51:53 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318903731">message detail</a>
 | #460</td></tr>
<tr class="even">
<td>
Hey, I'll be losing more points than you today. From first to last, bah.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/11/2006 9:56:47 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318904523">message detail</a>
 | #461</td></tr>
<tr class="even">
<td>
Meanwhile, I'll be goin' from last to...next-to-last.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=884755&amp;board=8&amp;topic=29002092" class="name">CantFaketheFunk</a> |
Posted 7/11/2006 10:00:15 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318905049">message detail</a>
 | #462</td></tr>
<tr class="even">
<td>
This topic amuses me.<br><br>---<br><b>Jayne</b> <i>[Shadow Syndicate]</i>: Level 60 Troll Mage, Mug'Thol<br>Level 3X Gnome Warrior, Skullcrusher</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/11/2006 10:18:30 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318908044">message detail</a>
 | #463</td></tr>
<tr class="even">
<td>
LEAVE US ALONE, FUNK.<br>---<br><b>Board 8</b>: Where people treat each other <i>right</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/11/2006 10:20:56 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318908424">message detail</a>
 | #464</td></tr>
<tr class="even">
<td>
<i>This topic amuses me.</i><br><br>It'll amuse you even more after GTA's massive day vote surge too<i>!!</i><br><br>But
seriously, I didn't see this coming. This match has an insane amount of
votes, mostly due to WC rallying, which we did underestimate. Take away
those and you get something like 55-45.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Grand Theft Auto vs. Warcraft - Bracket: <b>GTA</b> - Vote: <b>GTA</b> (8/9)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/11/2006 10:21:46 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318908557">message detail</a>
 | #465</td></tr>
<tr class="even">
<td>
Take those away and Aitch Emm gets his point!<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/11/2006 10:22:01 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318908599">message detail</a>
 | #466</td></tr>
<tr class="even">
<td>
Yes, "rallying..."<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=156521&amp;board=8&amp;topic=29002092" class="name">metroid composite</a> |
Posted 7/11/2006 10:30:17 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318910000">message detail</a>
 | #467</td></tr>
<tr class="even">
<td>
If you were a warcraft fan, why would you cheat instead of rally? It's
well-known that CJay throws out cheat votes and there are extremely
obvious places to rally.<br><br>It's GTA that's less obvious--where do you rally if you want to garner more votes for that game?<br>---<br>Cats
land on their feet. Toast lands peanut butter side down. A cat with
toast strapped to its back will hover above the ground in a state of
quantum indecision</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29002092" class="name">DaruniaTheGoron</a> |
Posted 7/11/2006 2:34:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318963334">message detail</a>
 | #468</td></tr>
<tr class="even">
<td>
Either you guys look like a bunch of idiots right now, or WC is doing an insane amount of cheating. Which wouldn't surprise me.<br>---<br>...little Weezing it's gonna stand up against my ****in' Charizard? Just get back on your bike <br>and keep pretending to be cool with your lame ass mohawk ****er. - phoenix1487 <b><i>Sp2k6: 8/9</i></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/11/2006 2:36:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318963992">message detail</a>
 | #469</td></tr>
<tr class="even">
<td>
Neither would surprise me.<br><br>*drools on topic*<br>---<br><b>GET UP ON THE HYDRA'S BACK!</b><br><b>GET UP ON THE HYDRA'S BACK!</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/11/2006 3:09:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318972219">message detail</a>
 | #470</td></tr>
<tr class="even">
<td>
Super Mario Bros...............92.21% 108512<br>Madden NFL..............................7.79% 9168<br>TOTAL VOTES..............................117680<br><br>96.11% of the brackets predicted this match correctly.<br><br>Ouch, just ouch. SMB crushes Madden into the ground with over 92% of the vote! 108K votes for Mario, that's <i>insane.</i> Madden just got owned here.<br><br>Today,
speaking of things getting owned, Warcraft is...beating GTA? Mass
rallying or cheating ftw? We'll find out what's going down by the end
of the match, but I wouldn't count GTA out yet. It hasn't lost a close
match yet.<br><br>Moltar - 2<br>HaRRich - 2<br>HM - 2<br>Leon - 1<br>Soul - 1<br>Ulti - 1<br>Yoblazer - 0<br>Mnm - 0<br>Lopen - 0<br><br>Leon finally gets a point. Yay him!<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Grand Theft Auto vs. Warcraft - Bracket: <b>GTA</b> - Vote: <b>GTA</b> (8/9)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=439221&amp;board=8&amp;topic=29002092" class="name">Canadian Carnage</a> |
Posted 7/11/2006 3:12:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318973070">message detail</a>
 | #471</td></tr>
<tr class="even">
<td>
-Sigh-<br><br>Perhaps I should just try to rally the PC gamers
out there that do respect console games and own a few, but love PC
games more for many a reason.<br><br>How hard is it for people to understand that Warcraft has a huge following, even outside of WoW.<br><br>---<br>"<b>NO CLOUD IS NOT IN THE GAME, GO AWAY</b>" -  pictish freak</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=433816&amp;board=8&amp;topic=29002092" class="name">andaca</a> |
Posted 7/11/2006 3:22:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318975594">message detail</a>
 | #472</td></tr>
<tr class="even">
<td>
<i><br>But seriously, I didn't see this coming. This match has an
insane amount of votes, mostly due to WC rallying, which we did
underestimate. Take away those and you get something like 55-45.</i><br><br>There may be an extra 10,000 votes, but to think they are all for WC is just silly.<br><br>Remember
back when Ceej announced that 65% of Koreans had voted for Starcraft?
There isn't a single place anywhere that you can get everyone to all
vote the same way. While WC may have helped to rally those extra 10000
votes, thinking that it pulled any higher than 65% of those seems
extreme -- although rallying clearly helped WC out, GTA tended to spike
at the same times WC did. This suggests that GTA was getting a healthy
percentage of the rallied votes.<br><br>Mind you, a 6500-3500 split is
still a 3000 vote gain for Warcraft. However, if you took that entire
mass of votes away (and I think that split is about as extreme in favor
of WC as you could realistically expect) GTA would only be winning
51-49.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29002092" class="name">Lopen</a> |
Posted 7/11/2006 3:29:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318977214">message detail</a>
 | #473</td></tr>
<tr class="even">
<td>
Sure, I underestimated Warcraft, I'll admit it. This won't be the first
time I screw up an analysis, and I'm still happy to see it winning
here. <br><br>However,
the hole in my analysis comes from underestimating the Warcraft RTS's
popularity here. Not underestimating "mass rally votes" or failing to
notice "GTA SUX BECAUSE CJ LOST TO NESS". Warcraft supporters may have
been right, but I claim they were right for the wrong reasons until I'm
proven wrong. <br><br>And I'm not yet counting out GTA. The poll is
~11500 ahead of Castlevania/Halo right now... and I'm having trouble
stomaching that these are all rally votes. <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/11/2006 3:35:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318978836">message detail</a>
 | #474</td></tr>
<tr class="even">
<td>
I didn't say they all were, just most. <br><br>And I think this
is more than just a 65-35 split. Not only did we get the rally votes
from Asia in the early hours, but also the heavy ralling at the forums.
It's no coincidence that Warcraft's strongest updates where then. I'm
thinking more 80-20.<br><br>Either way, I'll admit that I
underestimated Warcraft's strength here, but without the successful
rallying, I'm pretty sure GTA would have a comfortable lead.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Grand Theft Auto vs. Warcraft - Bracket: <b>GTA</b> - Vote: <b>GTA</b> (8/9)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29002092" class="name">SquallidSnake</a> |
Posted 7/11/2006 4:22:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318990520">message detail</a>
 | #475</td></tr>
<tr class="even">
<td>
Well, at least nobody will get the point on Moltar's system, but oh boy, yo's system is going to hurt me.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29002092" class="name">Lugia2</a> |
Posted 7/11/2006 4:29:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318992109">message detail</a>
 | #476</td></tr>
<tr class="even">
<td>
<i>Either way, I'll admit that I underestimated Warcraft's strength
here, but without the successful rallying, I'm pretty sure GTA would
have a comfortable lead.</i><br><br>True. But who said there is no
rallying in the Squaretendo/Sega/Mega Man (it happened in both
Sephiroth matches, but not as much as right now) matches? Since when
does Blizzard have an isolated advantage on this?<br><br>If you took out ALL the rallying votes, then those vote totals would be constantly below 100k votes- Forget 100k <i>leads</i>!<br><br>After all, GTA is STILL doing pretty well...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/11/2006 4:35:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318993711">message detail</a>
 | #477</td></tr>
<tr class="even">
<td>
Hey Moltar, I don't see you online so if you see this, up my Sonic percentage by 8%!<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/11/2006 4:37:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318994203">message detail</a>
 | #478</td></tr>
<tr class="even">
<td>
Heh, that's quite the increase. <br><br>*hopes he doesn't end up getting boxed in*<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29002092" class="name">Lopen</a> |
Posted 7/11/2006 4:40:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318994851">message detail</a>
 | #479</td></tr>
<tr class="even">
<td>
I'd imagine he's got Sonic at about 37% right now.  Understandable, I'd probably increase it a hair more if I were him.  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/11/2006 4:40:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318994906">message detail</a>
 | #480</td></tr>
<tr class="even">
<td>
Well I think I overrated Devil May Cry as a series. Plus Sonic most
likely will get that "Nintendo" influence. I already said after seeing
Fire Emblem/Silent Hill that I would up all of my Nintendo related
matches by at least 5%.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/11/2006 4:42:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318995423">message detail</a>
 | #481</td></tr>
<tr class="even">
<td>
Actually, I was thinking about upping my Final Fantasy prediction, but after this match, I'm not so sure if I should...<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/11/2006 5:51:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319011977">message detail</a>
 | #482</td></tr>
<tr class="even">
<td>
<b>Mushroom Division:</b> <i>Round 1 - Match 11</i> &#8211; (3)Sonic vs. (6)Devil May Cry <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Sonic</b><br>Oh
Sonic, Mario&#8217;s true rival from back in the Genesis days. The Blue
Hedgehog is still churning out games, with Sonic Riders being the
latest, but most consider the Genesis games the best.<br> <br><b>Devil May Cry</b><br>One
of the more recent entries in the Contest is the Devil May Cry series.
Dante has become a strong character at GameFAQs even though he&#8217;s
relatively new. DMC3 is the latest.<br><br>It&#8217;s the Sonic series. I&#8217;m
sorry, but that spells DMC&#8217;s doom right there. I really don&#8217;t even know
what to say about this match. Sonic is stronger than Dante, and the
Sonic series has been out far longer and spanned much further than
Dante and DMC.<br><br>I have Sonic winning, and that&#8217;s all I need to
say. Now go grab some popcorn and prepare for Lopen&#8217;s analysis, because
it&#8217;s bound to be entertaining. =P<br><br><b>Moltar&#8217;s Bracket Says:</b> Sonic will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Sonic: 66% - DMC: 34%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>I
quite literally had to look at the bracket to remember that DMC was
even in this contest. The two main characters from these series have
fought before, and I doubt DMC3 will prevent DMC from suffering a
similar fate as two years ago.<br><br>Prediction: Sonic with 57.5%<br> <br><br><br><b>Soul&#8217;s Analysis</b><br><br>You know it's sad that I didn't even notice DMC was in this contest until right now...<br><br>Sonic
and company begin their contest by taking on a somewhat underseeded
Devil May Cry. DMC is indeed strong, but this is Sonic here. Sonic is
one of the strongest in the contest, and DMC just can not compare.<br><br>
In 2004, Sonic defeated Dante with 62% of the vote. Since that time,
Sonic has had a new DS game and a few more games announced for all next
generation consoles. Since that time, there has been a shift of voting
pool, which could potentially help Sonic out. Therefore, I believe that
Sonic will be able to get even higher then 62%. And that's that.<br><br><b>My prediction: Sonic wins with 68.42% of the vote.</b><br> <br><br><br><b>Yoblazer&#8217;s Analysis</b><br> <br>My
lazy ass has the advantage here, as I'm writing this late (Castlevania
is owning Halo as I type this). After a week of matches, we've already
seen that people are voting differently. Voters really <i>do</i> seem
to be taking the entire series into consideration, as Star Ocean, Soul
Calibur, and Halo have already found out, much to their chagrin. This
match will almost surely continue that trend.<br><br>Individually,
Sonic's games may not be that strong, but together, they form a very
formidable, respected, and popular series. He has fans from the golden
2D days and fans from the newer Sonic Adventure titles. He's gone
multiplatform over the past few years, a move which has helped him mend
ties with the Nintendo fans he once fought so feverishly to win over.
Sonic is looking to make waves in this contest.<br><br>Devil May Cry,
on the other hand, seems to have everything working against it. Like a
few of our earlier losers, it is a newer series with a small number of
games in its arsenal. Worse yet, those games are probably nowhere near
as popular as Halo or Kingdom Hearts. Worse <i>yet</i>, its three lone
games call only one console him. Worse YET, its second game was
completely hated by the fanbase, and its third game sold poorly.<br><br>This should be a very routine win for the Blue Blur.<br><br>Sonic<br>+ Many games on different consoles<br>+ As a series, is very well known and respected<br>+ Branched out to more fans over the years<br>- Questions abound if any of Sonic's individual games are that strong<br><br>Devil May Cry<br>+ Good contest history for Dante<br>- Newer series<br>- Small number of games<br>- All games share the same console<br><br>My prediction: Sonic def. Devil May Cry (66-34)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/11/2006 5:52:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319012133">message detail</a>
 | #483</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>Ah, it&#8217;s the all-or-nothing Lopen
special. And, as usual, he&#8217;ll end up on the nothing side, if you know
what I mean!!!! (Psst, **SPOILERS** that means Devil May Cry is going
to lose! **END SPOILERS**)<br><br>As far as contest experience goes,
Sonic&#8217;s series has plenty of it, with a grand total of five characters
appearing throughout the Character Contest&#8217;s history. Robotnik is the
only one who could be considered fodder, barely scraping by a fin and
smacking down a hand before getting blown away by a nose. While Tails
has not enjoyed a great deal of contest success, he can be considered a
low mid-tier. It took him three years to win his first match, but his
first round opponents the first two years were Alucard and Auron,
certainly no slouches. After finally beating Viewtiful Joe in 2004, he
put up a very respectable performance against Dante, of all characters.<br><br>For
a long time, Knuckles the Echidna had one of the roughest streaks of
bad luck we&#8217;d seen in a character contest. While he was always able to
win his first round match, he was always fed to the lions (or in this
case, Snakes) in the second round. For three years, Knux had to deal
with a one-and-done in an unwinnable situation against a Noble Niner in
the second round. In 2005, while Solid Snake was nowhere near him, his
luck didn&#8217;t seem to be improving much. This time, he was set up against
the supposed Noble Nine breaker in the first round, Magus. However,
Knuckles scored one of the biggest upsets ever, exposing the dark
wizard for the fraud that he was all along. While he lost to Squall
Leonhart in the second round, he&#8217;d left his mark on the contest.<br><br>Shadow
the Hedgehog was a character that people weren&#8217;t expecting much out of
when he made his debut in 2003, but he surprised a good number of
people when he <i>destroyed</i> Wario and then scored an astounding
45% on Mario (which we have since figured out was an overperformance,
though it was suspected all along). In 2004, he lost a tight match
against Tidus, but the fact that he was able to hang in there with an
FF main character is commendable. Despite drawing primarily from one
game, Shadow appears to be around the same level of strength as
Knuckles. While being a Sonic proxy certainly is a benefit, that cannot
be the only reason for his strength. More on that later.<br><br>And, of
course, there&#8217;s Sonic the Hedgehog himself. Few characters have
disappointed expectations more than the Blue Blur. Due to his
long-standing history, he was expected to be a powerhouse, though he
has basically shown himself to be one of the weak links in the Noble
Nine, having never beaten another fellow member (though he came close
against Samus in 2002 and Mega Man in 2005). However, with the new
Sonic game on the horizon, that SHOULD change in the near future.<br><br>As
far as his games go, all we&#8217;ve seen in a contest setting is Sonic the
Hedgehog 2, which was utterly destroyed in the second round by Super
Mario World. It&#8217;s hard to believe that Sonic 2 is as weak as it looked
in the Games Contest, but it certainly wouldn&#8217;t be all THAT strong
overall. There is a big split amongst the Sonic fanbase about what is
the best game in the series, which I believe could hurt an individual
game&#8217;s performance. However, with this being a Series Contest, you&#8217;re
throwing all of them together under one banner, which will help it
significantly, I think. I don&#8217;t buy this idea of saying that a series
won&#8217;t be much stronger than its strongest game, at least not in THIS
case. In the event of something like Super Smash Brothers, it makes
sense. In the case of the Sonic series, I just don&#8217;t see that holding
true because there isn&#8217;t an overwhelming favorite here.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/11/2006 6:01:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319014379">message detail</a>
 | #484</td></tr>
<tr class="even">
<td>
Now let&#8217;s talk about Devil May Cry&#8217;s contest history. Of course, Dante
has appeared in every Summer Contest. I find this to be almost a
fitting match because, like Sonic, he has also had a history of
underperforming/disappointing in contests. In 2002, he was nearly
doubled by Crono in the second round before people had any idea of how
powerful the Chrono Trigger hero was. In 2003, he was considered the
favorite to beat Ryu (even though the stats showed that the Street
Fighter character was expected to win, though this was before they were
widespread), but he once again fell short in the second round. In 2004,
he finally broke through to the Sweet Sixteen, but not before letting
Tails do better than most people were expecting. The third round was
not kind to Dante, as he was stuck with an awful picture and was
thoroughly owned by Sonic the Hedgehog himself.<br><br>2005
was probably one of Dante&#8217;s better years, even though he lost in the
second round again. He owned Final Fantasy VI&#8217;s Terra with over 70%,
but was given no chance even to compete with Final Fantasy VII&#8217;s
Vincent, who had nearly quadrupled Kerrigan. However, Dante brought
those supporters back down to earth by scoring 46% exactly and even
holding the lead in the early going. His brother Vergil had also
appeared in the Villains Contest and beat the crap out of a constipated
Ghaleon (see what I did there?) before being fed to eventual contest
champion Sephiroth. Though he holds nowhere near the strength of Dante,
Vergil was still high fodder.<br><br>No Devil May Cry game made it into
the Games Contest, so we have no reference point in that regard. We
don&#8217;t have much to go by as far as polls are concerned except for a
Favorite Capcom Series poll, in which DMC didn&#8217;t fare too well at all.
I know it&#8217;s not something that we can look at for sure as an indicator
of strength, but there isn&#8217;t much else to go by. The original Devil May
Cry did decently on the Top 100 Games List, placing two spots below
Sonic 2, which doesn&#8217;t say too much either way. However, I do feel that
the series isn&#8217;t all that popular overall. I could honestly see Dante
being more popular than his series, really. I don&#8217;t foresee this match
being close. Sonic will be one of the stronger series in this contest
and Devil May Cry&#8230;won&#8217;t be.<br><br><i>Leonhart&#8217;s Prediction:</i> <b>Sonic with 67.03%</b><br><br> <br><br><br><b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Sonic<br>Top 100 List comparison:<br>---Sonic 2 - #38<br>---DMC - #40<br>Best Game Ever x-stat comparison:<br>---Sonic 2 - 20.15% (may have been Something Fishy Factor'd by SMW)<br>---DMC - N/A (no rep)<br><br>Here's
a match where the upset potential is so small it's damn near
non-existant, yet people will try to force one out of it. I'm looking
at you, Lopen. =P<br><br>Sonic 2 barely outranks the first DMC,
granted, but Sonic also has more games, more popular games, has spanned
more generations, has spanned more systems, is iconic, and Sonic got
62% against Dante in 2004. Tails got 42.6% against Dante that year.
Dante and Knuckles are practically even last year, too. As far as the
Capcom loyalties go, Dante doesn't even have it so much in his favor:<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1454" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1454">http://www.gamefaqs.com/poll/index.html?poll=1454</a><br><br>Scoring
7.3% (between Breath of Fire and Marvel vs.) in a Capcom-poll doesn't
do you any favors when your series will be facing Sonic's series, and
keep in mind the closest match of the year last year was Sonic/Mega
Man...then go back and look at the Mega Man series having 31.49%.
There's not much at all in DMC's favor, though I will point out one
thing I noticed: according to the Villain Contest, Vergil would get
53.89% on Dr. Robotnik. That might be the deciding factor of this
match, ya know.....<br><br>Sonic wins with 63.12%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/11/2006 6:02:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319014556">message detail</a>
 | #485</td></tr>
<tr class="even">
<td>
<b>HM&#8217;s Analysis</b><br> <br>Ah, we finally get to see Sonic show his
stuff in the contest! I have some pretty high hopes for Sonic in this
series contest. I have no doubt that the power the series has will open
some eyes around the board. This is another match that is getting some
attention, albeit not as much as others, as one that could have a
potential upset. But, again, that one just does not compute at all.
This is an upset choice only if you&#8217;re <i>Lopen</i> -- oh snap! &#8211; and we all know about that guy<i>!!</i><br><br>Personally, I think the Sonic series is going to be an absolute <i>monster</i>
of a series. I have no doubt it&#8217;ll be within the top 5 strongest series
once the end of the contest rolls around &#8211; this is probably already
being disagreed upon with everyone who is reading this right now. You
are basically combining all of Sonic&#8217;s games into one series and
allowing people to vote. I think the fact that the series will likely
be labeled as just &#8220;Sonic&#8221; means huge things for it, as it encompasses
every Sonic game ever. The entire Sonic franchise against &#8230; <i>Devil May Cry</i>? Yeah, that one is just simple. <br><br>We
have only had the opportunity to see Devil May Cry represented once in
these contests before, and that&#8217;s through the character contest with
Dante. Dante has always been a pretty strong competitor; he&#8217;s never
among that group right outside the Noble Nine, but he&#8217;ll always hold
his own against everyone around him and below him. He even went 54/46
against Ryu, which is pretty impressive. Even then, Sonic is <i>far</i> above the likes of Dante, and only has room to go up. <br><br>Sonic
has performed well whenever he has made a contest, with the exception
of the Games Contest but there is a perfectly logical explanation for
that one. Devil May Cry is certainly going to be pretty strong, but
Sonic is just clearly the stronger franchise here. Devil May Cry boasts
two well liked games and one that people wish to forget; Sonic has tons
of great games on a variety of systems in the past 15 years. These
games together are going to make a beast of a series and it&#8217;ll show in
this match. <br><br><b>Aitch Emm&#8217;s Bracket Says:</b> Sonic will win<br><br><b>Aitch Emm&#8217;s Prediction:</b> Sonic 63% -- Devil May Cry 37%<br><br><b>Aitch Emm&#8217;s Vote :</b> Devil May Cry.<br> <br><br> <br> <br><b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: Rhythm &amp; Balance (Sonic Adventure 2)<br><br>Sonic
is a series that people have a lot of faith in for this contest. I
don&#8217;t have that same faith, and the Sonic series is probably my second
or third favorite series overall. But I&#8217;m just not convinced that
GameFAQs really cares about Sonic games. We&#8217;ve only really been able to
gauge Sonic&#8217;s popularity as a character on this site. Sure he&#8217;s a
popular character, but come on. There aren&#8217;t really a lot of overly
popular video game characters out there. Games are an entirely
different animal, as there are <i>plenty</i> of popular games out
there. Sonic doesn&#8217;t have that same advantage in the games spectrum.
Sure his games may have been really popular at a time, but today Sonic
games just aren&#8217;t held in the same light. The video game industry has
grown since the Genesis days, and Sonic games have failed to grow with
it. Today, Sonic games aren&#8217;t held in the same light as a Metal Gear,
Halo, Final Fantasy, GTA, or any of the overly popular series. When a
new Sonic game is released, people hardly care nowadays due to many
past blunders. The series will mostly have to rely on past popularity
to carry it in this contest.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/11/2006 6:03:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319014773">message detail</a>
 | #486</td></tr>
<tr class="even">
<td>
Devil May Cry is actually a tough series to judge. We have little data
about the popularity of the series on this site outside of Dante&#8217;s
success in the character contest. Sure Dante entered the character
battles as a newbie with surprising strength, but it&#8217;s tough to say
whether his contest strength is due to the popularity of his series,
the popularity of his character design, or a mixture of both. I would
say that Devil May Cry is a fairly popular, as it sold over a million
copies in America. DMC2 was a dud, bit DMC3 was also fairly received.
DMC3 was surprisingly missing from the 2k5 GotY polls, but you would
think that the series is more popular than God of War, which ended up
being pretty popular on the site.<br><br>But
in the end, even if Devil May Cry ends up having a bit of strength, it
probably won&#8217;t be enough to take down the Sonic series, although it
probably will be close. The jury is still out on the overall strength
of the Sonic series, but it should be able to muster up enough to take
down Devil May Cry. Sonic has a lot more to draw from than the PS2
fanbase of Devil May Cry, having fans from the Genesis days, Dreamcast,
and the Gamecube games among others. Sonic beat Viewtiful Dante in the
character contest 62-38. I think Devil May Cry will do a bit better
than that. Still, Sonic&#8217;s true test will come in the next round.<br><br>Bracket: Sonic<br>Vote: Sonic<br>Prediction: Sonic with 64.92%<br> <br> <br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Sonic will easily defeat Devil May Cry, 60%+. Maybe even a doubling! Did you see Sonic vs. Dante? Same deal here, for sure.<br><br>No! <i>No!</i>
If you've been paying any attention to my ramblings of the last few
weeks, you know that I'm calling for Devil May Cry to not only surprise
here, but actually <i>upset</i> that dastardly hedgehog! Rabid DMC
fanboyism? I can't completely deny the influence of bias in the pick,
but I don't risk brackets exclusively on bias. There are reasons here
for Sonic's weakness, as well as Devil May Cry's strength, let's go
over em. I'll start positive here and promote Devil May Cry a bit.<br><br>The main thing we have to read into DMC's popularity on this site is Dante. Dante isn't <i>quite</i>
king of the mountain yet in the character contests, but he's pretty
close. Definitely on that near elite tier. How many characters
originating from the PS2/X-Box/GC era can even try to say this? Master
Chief is the only one who even comes close. He's the "face of the
X-Box", and no one's going to question that Halo is pretty respectable
on this site, even with the anti-votes. Alright, alright, enough
putting over Halo&#8230; what's my point? Series != Characters, I'll be one
of the first to say that. But, at the same time, Dante's popularity
being so high with so little time and releases on his side can say only
good for the appeal of the series on GameFAQs, the way I see it. He
isn't like Sonic, he isn't "just known" because he's an icon of fifteen
years. He won't be more liked because he's made appearances in comics
or television, because of nostalgia, or because he can slowly whittle
away at your defenses with a plethora of "simply decent" releases. Most
people who vote Dante have to really enjoy the games in the series,
considering it's so new, relatively speaking.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/11/2006 6:03:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319014884">message detail</a>
 | #487</td></tr>
<tr class="even">
<td>
Dante aside, we haven't seen much of Devil May Cry in GameFAQs, only
two significant things I can think of. First of all, there was a
discouraging poll out there, asking for the best Capcom series&#8230; I can't
say DMC did admirably, getting only ~8%, but the competition <i>was</i> fairly stiff. Mega Man, Street Fighter, Resident Evil. And DMC has had time to gain popularity since that poll. (Dante <i>has</i>
boosted from ~25% to ~33% in his years here) Most notably from Devil
May Cry 3, which has been released since that poll. DMC3, it's the game
many would say "rejuvenated the series". It received great reviews all
around, and although the sales weren't on par with the first, they
weren't horrible by any means. More recently, post DMC3, DMC had a
pretty nice showing on the top 100 list, at #40. (only two below
Sonic's best) Devil May Cry doesn't have much data for it on this site,
but what it has is looking strong.<br><br>But is it strong enough to beat the mighty <i>Sonic</i>?<br><br>Yes,
I think so. Sonic the Hedgehog has done nicely for himself over
GameFAQs, but his games? Not really. In the game contest, Super Mario
World makes Sonic the Hedgehog 2, possibly the most popular of the old
school Genesis games, look like a joke. You can scream "Same Fanbase
Factor" all you like, but there's only so much I'll buy taking place
here. Anyway, that same Sonic 2 doesn't do too badly on the top 100
list, getting a #38, but this is still well below the best any of the
other noble niners have to offer. (there is Mega Man&#8230; but Mega Man had
no presence on the drop down list, so we can forgive him.) And also,
this may be higher than Sonic 2 may have normally have gotten on such a
list. Do I think many fans of Sonic 3 &amp; Knuckles, or perhaps some
other Sonic games voted for Sonic 2 simply because it was the only one
on the list? You bet I do. Many have admitted to "voting for the one
they thought had a chance", and you can't deny results. Only two write
ins made it into that thing. What's more is that Sonic is a favorite of
the board, and Devil May Cry&#8230; well&#8230; it really isn't. I don't want to
exaggerate the significance of the top 100 list, but all I'm saying is
Sonic 2 looked pretty feeble in the Game Contest of yore, and the top
100 list isn't giving me any reason to believe that was a fluke or a <i>huge</i> amount of "SFF".<br><br>Now,
I think if you take out Sonic 2, you've pretty much won half the
battle. Take out the flagship of the old school series, and you pretty
much take out the whole of it. Some may prefer S3&amp;K, but some
really do prefer Sonic 2 as well. I think it about balances out, and I
find myself doubting if any of the old school games are a huge threat
as a result. What else does Sonic have&#8230; Sonic Adventure 2: Battle? Give
me a break. Intuition told me that this wasn't anything to be feared,
and the polls I found did not give me a thing to doubt it. SA2:B got
like 2% in the game of the year poll when it came out for the Gamecube.
Oh, it had <i>decent</i> competition, but I can't take 2% seriously. I just can't. You put any game with any sort of decent fan base here in <i>any</i>
poll&#8230; even against something ridiculous like a three way with Ocarina
of Time and FF7, and I'm sure this game will get more than <i>two</i> percent.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/11/2006 6:04:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319015016">message detail</a>
 | #488</td></tr>
<tr class="even">
<td>
To sum it up here, I think Sonic's potential big time game threats are
Sonic 2, S3&amp;K, and Sonic Adventure 2: Battle. But we've seen Sonic
2 disappoint, we've seen SA2: B disappoint, and to be honest, I can't
see S3&amp;Knux being much more than a souped up Sonic 2 at best. Devil
May Cry is easily a possibility to be more popular than Sonic 2 byt the
looks of it, although we don't have any official contest data on it.
And I'd put my money on Devil May Cry 3 being more popular than it as
well. Devil May Cry 2... well, it probably won't help so much. It's not
going to <i>hurt</i> like some have said. The Devil May Cry fan base is the most forgiving of all. You know our motto, right? <i>"Devil May Cry 2 never happened."</i>
I'd think the slight rift between the 3D and 2D Sonic fans would hurt
Sonic more than DMC2 hurts Devil May Cry. A series with a bunch of
decent games will be stronger than any of the parts, yes. But I think
any strong series needs a "big gun", and I just don't think the Sonic
series has one. Nothing that can compete with Ebony and Ivory.<br><br><b>Lopen's Prediction:</b> Devil May Cry with 51.81% <br><br> <br> <br> <br> <br>Crew: So yeah, other than Lopen, we all went with Sonic. Sorry about the pause too, connection died.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=884755&amp;board=8&amp;topic=29002092" class="name">CantFaketheFunk</a> |
Posted 7/11/2006 6:06:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319015587">message detail</a>
 | #489</td></tr>
<tr class="even">
<td>
Any cheating is minimal.<br><br>The ONE topic on the WoW General
boards has almost 20k views. Add: any battle.net, spamming on the sites
themselves, fansites (I put it on the front page of the fansite I work
for), realm forums, class forums, the offtopic forum, spamming
in-game...<br><br>I'm surprised the vote totals aren't higher.<br>---<br><b>Jayne</b> <i>[Shadow Syndicate]</i>: Level 60 Troll Mage, Mug'Thol<br>Level 3X Gnome Warrior, Skullcrusher</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/11/2006 6:08:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319016019">message detail</a>
 | #490</td></tr>
<tr class="even">
<td>
Heh, mnm upping his prediction makes some of his write-up contradict itself.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29002092" class="name">Lopen</a> |
Posted 7/11/2006 6:09:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319016204">message detail</a>
 | #491</td></tr>
<tr class="even">
<td>
One person can easily view a topic 10+ times if they're paying attention to it.  Views wouldn't even be <i>close</i> to votes drawn from it, I wouldn't think.  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/11/2006 6:11:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319016822">message detail</a>
 | #492</td></tr>
<tr class="even">
<td>
Nobody cares about this match anymore, Funk! Come on now! Seriously though...<br><br>Sure,
Warcraft is going to win. Props to you for that, but I still maintain
that you seriously overrated how much rallying the game would get.
We'll see for sure when Warcraft faces Mario in the next round, but my
preliminary analysis is that I overestimated GTA.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/11/2006 6:24:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319019793">message detail</a>
 | #493</td></tr>
<tr class="even">
<td>
<i>Heh, mnm upping his prediction makes some of his write-up contradict itself.</i><br><br>Didn't
get to Moltar in time to take out that line... but issokay! But
seriously, after seeing Pokemon and Fire Emblem blow out games that
supposedly have PS2 fanbase backing, I'm wary of how much support Devil
May Cry will get... especially against something as universal as Sonic.
At <i>best</i> for Devil May Cry, we'll see a Castlevania/Halo
affair... But Sonic is probably stronger than Castlevania, and DMC is
likely weaker than Halo. If DMC actually gets 40% on Sonic, I think
Sonic's in <i>serious</i> trouble against SSB...<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/11/2006 6:25:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319020015">message detail</a>
 | #494</td></tr>
<tr class="even">
<td>
I would agree with you on that, unless SSB struggles really badly with Dragon Quest.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3216520&amp;board=8&amp;topic=29002092" class="name">TheSwizzle</a> |
Posted 7/11/2006 6:26:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319020416">message detail</a>
 | #495</td></tr>
<tr class="even">
<td>
The crew in total's never missed two matches in the same round, or am I forgetting something?<br>---<br><i>"If at first you don't succeed, find out if the loser gets anything."</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=295911&amp;board=8&amp;topic=29002092" class="name">Epyo the Great</a> |
Posted 7/11/2006 6:29:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319021157">message detail</a>
 | #496</td></tr>
<tr class="even">
<td>
Why do you guys all always agree with each other?<br>---<br><b>People who don't finish their sentences</b><br>I'm a Castlevania superfan!  Ask me anything!</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=884755&amp;board=8&amp;topic=29002092" class="name">CantFaketheFunk</a> |
Posted 7/11/2006 6:41:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319024230">message detail</a>
 | #497</td></tr>
<tr class="even">
<td>
I never overrated how much rallying it'd get. I said it'd get enough to win. :P<br><br>It, of course, has the POTENTIAL to wipe out anything. But it won't.<br><br>---<br><b>Jayne</b> <i>[Shadow Syndicate]</i>: Level 60 Troll Mage, Mug'Thol<br>Level 3X Gnome Warrior, Skullcrusher</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29002092" class="name">THEJackSparrow</a> |
Posted 7/11/2006 6:49:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319026162">message detail</a>
 | #498</td></tr>
<tr class="even">
<td>
<i>Why do you guys all always agree with each other?</i><br><br>We don't <i>always</i> agree with each other. Lopen picked Devil May Cry.<br><br>And I'm assuming that Mega Man/Mario Kart will be split.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1883202&amp;board=8&amp;topic=29002092" class="name">warning_crazy</a> |
Posted 7/11/2006 6:50:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319026315">message detail</a>
 | #499</td></tr>
<tr class="even">
<td>
500?<br><br>---<br>Nominate the Gray Fox FC2K6!<br>Current Score: 8/9 Today's  Pick: Warcraft</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1883202&amp;board=8&amp;topic=29002092" class="name">warning_crazy</a> |
Posted 7/11/2006 6:50:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=319026426">message detail</a>
 | #500</td></tr>
<tr class="even">
<td>
hah!<br>---<br>Nominate the Gray Fox FC2K6!<br>Current Score: 8/9 Today's  Pick: Warcraft</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">1</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=1">2</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=2">3</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=3">4</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=4">5</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=5">6</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=6">7</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=7">8</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=8">9</a></li>
<li>      10</li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage10_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29002092&amp;page=9" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage10_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>