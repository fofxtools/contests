<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><title>GameFAQs: Message List</title>

<link rel="stylesheet" type="text/css" href="genmessage5_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage5_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage5_files/bc.css"></head><body linkifytime="641" linkified="9" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage5_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage5_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29002092%26page%3D4"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage5_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div><a href="http://adlog.com.com/adlog/c/r=10153&amp;s=657806&amp;t=2006.07.11.19.55.29&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=01c17-gne-ad144B3FF01164D7C/http://www.gamespot.com/pc/driving/rebeltrucker/index.html?q=rebel%20trucker" target="_blank"><img src="genmessage5_files/rebel_leader.gif" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage5_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29002092&amp;page=4">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29002092" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">First
          Page</a> |
          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=3">Previous
          Page</a> |
          Page 5 of 10          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=5">Next
          Page</a>
          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=9">Last
          Page</a>
      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/4/2006 12:02:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317272428">message detail</a>
 | #201</td></tr>
<tr class="even">
<td>
Suikoden...........................27.39% 28018<br>Mega Man X................72.61% 74270<br>TOTAL VOTES............102288<br><br>77.84% of the brackets predicted this match correctly.<br><br>MM
once again proves that it just can't get a good backing from the
brackets. MMX easily takes care of Suikoden, though most of us expected
a bigger blowout. This still works though.<br><br>Today, Pokemon is surprising us big time. Most of us saw both as weak series at GameFAQs, but Pokemon is <i>doubling</i> Star Ocean. GG Soul! That'll teach the rest of us to buy into HM's words!<br><br>HaRRich - 1<br>Ulti - 1<br>Moltar - 0<br>Soul - 0<br>Leon - 0<br>HM - 0<br>Yoblazer - 0<br>Mnm - 0<br>Lopen - 0<br><br>It was close, but HaRRich gets it by a hair.<br>---<br>Moltar Status: Excited, the Contest is here at last!<br>Pokemon vs. Star Ocean - Bracket: <b>Pokemon</b> - Vote: <b>Pokemon</b> (2/2)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2665492&amp;board=8&amp;topic=29002092" class="name">XIII_rocks</a> |
Posted 7/4/2006 12:09:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317273735">message detail</a>
 | #202</td></tr>
<tr class="even">
<td>
Not quite a doubling yet. 66.52 =/= 66.66 ^_~<br>---<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738</a> Sign plz<br>Beef Jerky, Catgirls, DESU DESU DESU! <b>O_o</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/4/2006 2:47:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317303201">message detail</a>
 | #203</td></tr>
<tr class="even">
<td>
If Star Ocean can bring Pokemon down to 65%, I'll be extremely ecstatic.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br><i>^5 SOWL IMHO</i> - Explicit Content</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/4/2006 8:24:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317368841">message detail</a>
 | #204</td></tr>
<tr class="even">
<td>
Where's Moltar?<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/4/2006 9:21:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317379962">message detail</a>
 | #205</td></tr>
<tr class="even">
<td>
<b>Hyrule Division:</b> <i>Round 1 - Match 4</i> &#8211; (2)Metroid vs. (7)Kirby <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Metroid</b><br>Another
Nintendo staple is the Metroid series. Though it is not as known than
the Mario or Zelda series, it&#8217;s still very popular and well liked in
the Nintendo community. Metroid Prime: Hunters is the latest on the DS.<br> <br><b>Kirby</b><br>The
Puffball who&#8217;ll send your attacks Right Back at Ya!! is here. Canvas
Curse was released last year on the DS, and for a while it was the
Killer App for the handheld.<br><br>I love Kirby. I love him like a
mother loves her child. I also love Samus (no, not like that&#8230;or maybe
it is!), so this match won&#8217;t be fun to watch.<br><br>Kirby does well in
the Summer Contests, but Samus does better. Also, I believe Kirby is
more liked than his games, so the series won&#8217;t wind up doing as well as
him. There aren&#8217;t any really strong individual Kirby games. Two that
you could make a case for are Kirby SuperStar and Kirby: Canvas Curse,
but neither stand up to Metroid Prime alone, much less the rest of the
Metroid series. Metroid should have this match easily. Hopefully there
isn&#8217;t much SFF though, I&#8217;d hate to see Kirby end up like garbage in the
stats&#8230;So how about some random Kirby art!<br><br>(&gt;^_^)&gt;&lt;(^_^&lt;) &lt;(^.^)&gt;^(^_^)^ (&gt;-_-)&gt;={XXXX}=====&gt; &lt;//////////////[xxx]=&lt;(*_*&lt;) (b^_^)b <br><br><b>Moltar&#8217;s Bracket Says:</b> Metroid will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Metroid: 68% - Kirby: 32%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>Someone in the stats topic asked before the bracket if Kirby could rSFF Samus enough to win. lol foreshadowing.<br><br>Anyway,
though the match seems fairly obvious, Samus is ALWAYS on the ass end
of SFF in Nintendo matches. In matches where she should be SFFing the
competition, she gets nothing. For this reason, I think Metroid is
going to have a lot of problems in this match. I doubt Kirby can
actually win, but I doubt his series will get SFFd out of the poll,
either. I'm almost willing to bet that Kirby scores some rSFF in the
match, akin to his match with Bowser last year. This could be far
closer than people are making it out to be.<br><br> Prediction: Metroid with 52.13%<br> <br><br><br><b>Soul&#8217;s Analysis</b><br> <br>I'm predicting this will be the closest match of this entire division.<br><br>Metroid
is a pretty big series for Nintendo. Kirby is a smaller series that is
loved by mostly all. There is a rabid Kirby fanbase on Board 8. Kirby
probably boosted the most for Nintendo during the Summer Contest. Kirby
packs a punch, that's for sure. Will it be enough to defeat Metroid?
No. Metroid is probably Nintendo's fourth biggest series right now
(Behind LoZ, SMB and SSB). Samus is a hell of a lot stronger then Kirby
is. Plus, Kirby gets most of his/her strength from SSB/SSBM. Well, the
SSB series is not here to help Kirby in this match. But still, the
Kirby name alone will get a few votes from the site.<br><br>Metroid
will win this one. And quite easily, I might add. But it's sad that
this will probably be the closest match of the division, even with the
added SFF, if any.<br><br><i>My Prediction: Metroid wins with 61.46% of the vote. </i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/4/2006 9:22:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317380077">message detail</a>
 | #206</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>Well, it didn&#8217;t take long for us to
reach an SFF affair in this bracket. Well, I suppose I should say that
it could possibly be an SFF affair. However, Samus and Metroid have
displayed difficulty in the past in applying SFF to its opponents. In
this contest, Metroid will have perhaps two chances to pull off SFF
successfully against an opponent before the Legend of Zelda pulls it
aside and says, &#8220;THIS is how SFF works!&#8221; Before the bracket was
released, I said that Metroid was one series that was most likely to be
overrated by Board 8. However, it has a relatively easy path, and a
loss to either of its opponents would be a huge upset indeed.<br><br>Metroid&#8217;s
first victim is the Kirby series. Now the pink puffball has proven to
be a very popular character in Character Contests, but we have never
seen one of his games perform. The only problem is that he doesn&#8217;t
exactly have any smash hits on his resume, other than MAYBE Kirby
SuperStar. He also hasn&#8217;t really had a big release since then, unless
you want to count Canvas Curse. I don&#8217;t know how well it sold, so I
can&#8217;t vouch for that. Either way, the odds of Kirby&#8217;s series being as
popular as he is are slim at best. Where DOES all of his popularity
come from anyway? He might be the only character who is that strong
without a really popular title. <br><br>Then again, perhaps Kirby will
impress me. I think it can manage to avoid SFF against Metroid, though
it probably won&#8217;t be that strong in the first place. If it breaks 40%
in this match, I will be impressed. <br><br><i>Leonhart&#8217;s Prediction:</i> <b>Metroid with 64.48%</b><br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>We
round out the Hyrule Division with another blowout, and this one being
our first SFF match-up of the entire bracket. I have to say that I&#8217;m
not ever a fan of SFF matches unless some potential rSFF can occur that
could make a match closer or make an upset possible. Something like
this is just boring and dull, even for a typical blowout match. In
fact, most of the Hyrule Division could be summed up like that &#8220;dull.&#8221;
It has one match that is getting some debate and that&#8217;s Pokemon/Star
Ocean. <br><br>In order to avoid a lot of filler for this analysis
I&#8217;ll make it quick. We have seen the Nintendo chain go Zelda &gt; Mario
&gt; Metroid in both character and games contests in the past. Metroid
games were a lot stronger than some might suspect at first because of
the SFF it ran into with Super Mario Bros. 3 (Metroid) and A Link to
the Past (Super Metroid). The highest Metroid game placed in the Top 20
in the stats and that was Metroid Prime at 33.40% against Final Fantasy
VII, which is not bad at all. On the other hand, we have no data on
Kirby games at all, not even from The List. What we can gather from
character contests is that he is pretty popular, but Samus absolutely
murders him strength. It&#8217;s debatable on how much Samus was helped by
SSB, but it&#8217;s entirely possible Kirby was helped out by the original
release back on the Nintendo 64 as well. At any rate, there has yet to
be an instance where Kirby beats out something Metroid and we have yet
to see an instance where the fanbase has preferred Kirby over Metroid
in any respect. <br><br>This one is rather simple, really. What is
difficult is to decide just how much SFF is going to occur in this
match and if it&#8217;ll be a massive blowout or just another beating we
usually see. I have my doubts on Metroid being able to crack 80%
against Kirby, but I don&#8217;t think a tripling is out of the question.
It&#8217;s entirely possible that there might not be much of any SFF either,
but the result is basically the same. Metroid wins this one and with
absolute ease.<br><br><b>Aitch Emm&#8217;s Bracket Says :</b> Metroid will win.<br><br><b>Aitch Emm&#8217;s Prediction :</b> Metroid 72% -- Kirby 28%<br><br><b>Aitch Emm&#8217;s Vote :</b> Metroid</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/4/2006 9:22:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317380160">message detail</a>
 | #207</td></tr>
<tr class="even">
<td>
<b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: Fountain of Dreams (SSBM)<br><br>What
is it with Ceej deciding to make this a psuedo-Nintendo division?
Instead of spreading Metroid and Kirby out and letting them spread
their wings against other series, we are stuck with a potential SFF
match in every round for this division. The balancing of this bracket
is horrible. Wouldn&#8217;t you rather see how Kirby would fare against say,
Devil May Cry or Diablo? Wouldn&#8217;t you rather see Metroid test its
mettle against Kingdom Hearts or something where it could display its
full strength? <i>Anything</i> but another bunch of SFF matches for
Metroid. The series deserves better than that. Enough ranting though,
on with the analysis!<br><br>Metroid is a series that&#8217;s been around
since the old NES days, but it has absolutely exploded in popularity
within the last four years. Sure Metroid had the whole Justin Bailey
craze on the NES, and Super Metroid was a favorite on the SNES, but the
series didn&#8217;t peak in popularity until 2k2 with the release of Metroid
Prime, Metroid Fusion, and Metroid Zero Mission in their footsteps.
Those games introduced Metroid to a generation of gamers (32-64 bit
era) who didn&#8217;t even know who Samus was outside of SSB. Metroid has
proven to be pretty popular on GameFAQs since then. Metroid Prime won
Game of the Year, Metroid Prime 2 came pretty close, and both handheld
games had pretty good showings as well. Plus you now have to add in
Metroid Prime: Hunters to the mix as it has spread among the DS
fanbase. Metroid hasn&#8217;t really had a chance to shine in a contest
setting, but that&#8217;s because it was stuck behind SFF on <i>all</i> fronts.  But as the GotY polls have shown, it still is a force on this site.<br><br>Kirby
is a little hard to place. On one hand, he&#8217;s a pretty popular character
on this site. It makes sense, as Kirby has been around for 14 years and
has had tons of games, not to mention appearances in the SSB games.
Kirby is indeed a Nintendo star. On the other hand, none of his games
are really popular at all. His most popular game is Kirby Super Star,
which was just one good game on an SNES loaded with popular games. You
could say that Canvas Curse was well received and has the recency
factor, but face it. Kirby games just aren&#8217;t that popular. Samus would
probably beat Kirby with over 60% of the vote. Kirby&#8217;s games are much
less popular than the character. With Metroid being pretty popular on
this site, I don&#8217;t see how Kirby can avoid the doubling. The voters
know this is about the games, as evident by SMW/Sonic 2, which was
pretty much a picture of Mario vs. Sonic. Sorry Kirby, being a popular
character just won&#8217;t cut it in this contest.<br><br>Bracket: Metroid<br>Vote: Metroid<br>Prediction: Metroid with 66.74%<br><br>And since I feel like being random, I&#8217;m posting the Super Metroid rap!<br><br>Now, this is a story all about how<br>A Baby Metroid got stolen-turned upside down<br>And I liked to take a minute<br>Just sit right there<br>I'll tell you how I kicked ass in a place called Norfair<br><br>In SR-388 born and displaced<br>Ceres Space Colony was where it spent most of its days<br>Scientists seeing what they could find<br>Powers being harnessed for the good of mankind<br>When a familiar guy<br>Who was up to no good<br>Startin makin&#8217; trouble in my neighborhood<br>But after one little fight, Ridley got scared<br>And said 'I'm movin' with my auntie and uncle in Norfair'<br><br>I whistled for my ship and when it came near<br>I set the course for Zebes, "That place looks familiar!" <br>I saw no space pirates, thought that was rare<br>But I thought 'Naw forget it' - 'Yo homes to Norfair'<br><br>I... went... through the whole planet to Ridley's base<br>Shot about a hundred missiles in his face<br>I looked at my map, I was nearly there<br>To kick ass and take names in Mother Brain's lair</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/4/2006 9:23:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317380301">message detail</a>
 | #208</td></tr>
<tr class="even">
<td>
<b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Metroid<br>Top 100 List comparison:<br>---Super
Metroid - #24, Metroid Prime - #29, Metroid - #65, MP2: Echoes - #74
(Fun-fact: Metroid Fusion is the only Nintendo game on the drop-down
list that didn't make the Top 100 List)<br>---Kirby - N/A (had no games on the drop-down list)<br>Best Game Ever x-stat comparison:<br>---Metroid
Prime - 33.4% (may have been SFF'd by LoZ:WW, was behind Starcraft),
Super Metroid - 21.63% (SFF'd by LoZ:LttP), Metroid - 17.53% (SFF'd by
SMB3)<br>---Kirby - N/A (no rep)<br><br>I wish Kirby had some other
series to face -- besides this being a same-fanbase match (hopefully
with no SFF), I would think the Metroid series is bigger than Samus
while Kirby is bigger than his series. Furthermore, though not many
people would take the risk, if Kirby had to be a "7-seed," he would
have been much more fun to watch in Harvest Moon's place or Shadow
Heart's place (though that'd then make Metroid/Shadow Hearts...heh).
ANYWAY, I got off-topic...<br><br>...on-topic, Metroid wins, but it'll
be fascinating to see by how much since we've never seen anything-Kirby
in action here. Again, it's an same-fanbase battle though SFF actually
occuring isn't quite so likely (Metroid has never shown signs of being
able to dish out SFF except for, what, Samus/Isaac?), and Kirby's as
popular and strong as he is for a reason. I credit SSB/M to a lot of
that, but, then again, I credit SSB/M to a lot of Samus's strength too,
and Samus-2k4 would beat Kirby-2k5 with 59.42% (though I think Kirby
rSFF'd Bowser some and made him too strong...but that's another tale
for another time). I don't see any Kirby game matching Super Metroid or
Metroid Prime in either contest strength or number of fanatics, but its
base should still be fairly firm too.<br><br>Metroid wins with 63.12%<br> <br><br><br><b>Lopen&#8217;s Analysis</b><br> <br>Holy
overlapping fanbases, Hurricane! Which is higher in the Nintendo series
pecking order, Metroid or Kirby? Seems to be pretty strongly pointing
to Metroid at this point. Metroid Prime was in contention for Game of
the Year a few years back, so was Metroid Prime 2... less years back.
Kirby? Not a chance. Metroid had like 3... maybe even 4 entries into
the top 100 list, Kirby had none. Metroid had three reps in the game
contest&#8230; Kirby, once again, had none. Wow, with all these factors
against Kirby, this is gonna be ugly, right? At a glance, yeah, but I'm
not feeling it.<br><br>If any series will get votes based on the
character, it'll be Kirby. Half of the fun of Kirby's games is using
the little campfire treat wannabe. So in the best case for Kirby we
have Metroid against Kirby the character. I still think Kirby loses out
on that, but not nearly as bad as what was implied above. Also, add to
this that Metroid always seems to be on the bad end of these "SFF"
situations, and Kirby seems to be on the good end of them (Kirby v
Bowser&#8230; well it's only one, but whatever), and you actually have a
situation that might be dangerous for <i>Metroid</i> here.<br><br><i>Might</i> being the keyword. I still don't think any upset is gonna happen, but watch for a surprise in percentagaes!<br><br><b>Lopen's Prediction:</b> Metroid with 57.11%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3590042&amp;board=8&amp;topic=29002092" class="name">swyg</a> |
Posted 7/4/2006 9:25:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317380852">message detail</a>
 | #209</td></tr>
<tr class="even">
<td>
hey guys DOOOOOOOOOOOOOOOOOOOOOOOOOOOOM!</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/4/2006 9:31:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317382175">message detail</a>
 | #210</td></tr>
<tr class="even">
<td>
I think you missed mine.<br>---<br><b>Board 8</b>: Where <i>Wii</i> treat each other <i>right</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/4/2006 9:32:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317382443">message detail</a>
 | #211</td></tr>
<tr class="even">
<td>
<b>Yoblazer&#8217;s Analysis</b><br> <br>No need for length here. While we
all know Metroid doesn't fare well when it comes to Nintendo SFF, it
should be able to take this one easily. When's the last time a Kirby
game was even discussed? Samus has at least two games in her arsenal
that will thrash anything Kirby has to offer, and that's not even
considering SFF, which will obviously favor Metroid.<br><br>Amazingly,
there were some wild predictions of Kirby actually taking this match.
Now, I'm not usually one for in-your-face statements, but that is
completely ridiculous. When you get a bracket that, at first glance,
seems way too predictable, you start looking for upsets where they
don't exist. This is one of those cases. Metroid takes it.<br><br>Metroid<br>+ Stronger games<br>+ SFF will go Samus's way<br>+ It will humiliate its second round opponent<br>- It will get humiliated one week later<br><br>Kirby<br>+ Puffball made the contest<br>- First round loss<br><br>My prediction: Metroid def. Kirby (65-35)<br><br> <br> <br>Comments:
Crew has Metroid 9-0. Interesting to see how SFF will play out in this
match. It could be a blowout or it could be close.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/4/2006 9:52:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317386617">message detail</a>
 | #212</td></tr>
<tr class="even">
<td>
I'll go ahead and say that Ulti is going to be horribly off this round.
If Kirby rSFF'd Bowser (which I think he did), it's because of how much
more favored Kirby is in SSB/M than Bowser in SSBM. Besides,
indirectly, Kirby's been slightly stronger than Yoshi for two years
before that, and Yoshi got 43.66% on Bowser in 2k3. The SSB/M fanbase
wouldn't have to do much from there to have Kirby do as well as he did
against Bowser...<br><br>...but
there's no SSB/M in this match, and I'm not sure any Kirby game could
beat Metroid, Super Metroid, Metroid Prime, Metroid Prime 2, Metroid:
Zero Mission, Metroid Fusion, or Metroid Prime: Hunters. A Kirby game
or two could beat one or two of the handheld games, but I wouldn't
count anything as definite.<br><br><br>Man, I wish I would have redone my prediction.  I like therealmnm's the best.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/4/2006 9:54:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317387117">message detail</a>
 | #213</td></tr>
<tr class="even">
<td>
Oh, and throw in Canvas Curse somewhere in my last post.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/4/2006 11:17:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317405892">message detail</a>
 | #214</td></tr>
<tr class="even">
<td>
<i>I like therealmnm's the best.</i><br><br>I like mine the best, personally<i>!!</i><br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29002092" class="name">BlAcK TuRtLe</a> |
Posted 7/4/2006 11:22:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317406792">message detail</a>
 | #215</td></tr>
<tr class="even">
<td>
My reasoning in my analysis topic seems similar to Harrich's, but I
have a prediction of 69.69%, which I thought was off-the-wall high.<br><br><br><b>TuRtLe</b><br>~~~<br>Like Darth Maul, the bastard child of Michael Flatley and Hellboy. -trancer1</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29002092" class="name">DaruniaTheGoron</a> |
Posted 7/5/2006 2:10:25 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317435307">message detail</a>
 | #216</td></tr>
<tr class="even">
<td>
Nice pick for once, HM.<br>---<br>...little Weezing it's gonna stand up against my ****in' Charizard? Just get back on your bike <br>and keep pretending to be cool with your lame ass mohawk ****er. - phoenix1487 <b><i>Sp2k6: 3/3</i></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29002092" class="name">Lugia2</a> |
Posted 7/5/2006 8:01:28 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317460042">message detail</a>
 | #217</td></tr>
<tr class="even">
<td>
Just yesterday we were laughing at HM...Well, now he gets to laugh at <i>us</i>.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/5/2006 10:24:02 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317475693">message detail</a>
 | #218</td></tr>
<tr class="even">
<td>
Pokemon....................65.74% 71579<br>Star Ocean................34.26% 37307<br>TOTAL VOTES..............108886<br><br>83.74% of the brackets predicted this match correctly.<br><br>For
a match so hotly debated on the board, Pokemon went and made Star Ocean
a joke. Pokemon won easily and had huge bracket support, two things I
didn't expect to see.<br><br>Today, the Metroid series is showing its
strength by keeping Kirby under 30%. The day vote should hopefully
bring Kirby up a bit though.<br><br>Soul - 1<br>HaRRich - 1<br>Ulti - 1<br>Moltar - 0<br>Leon - 0<br>HM - 0<br>Yoblazer - 0<br>Mnm - 0<br>Lopen - 0<br><br>Soul is the only one who called a beatdown yesterday, so he earned his point here.<br>---<br>Moltar Status: Excited, the Contest is here at last!<br>Metroid vs. Kirby - Bracket: <b>Metroid</b> - Vote: <b>Kirby</b> (3/3)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=623712&amp;board=8&amp;topic=29002092" class="name">RPGGamer0</a> |
Posted 7/5/2006 10:30:19 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317476596">message detail</a>
 | #219</td></tr>
<tr class="even">
<td>
C'mon, 'blazer -- I need you to wipe the floor with everybody, or my
prediction goes to hell what with me choosing Sowl and Ulti to be last.
&gt;_&gt;<br><br>---<br><b>My mom calls hers a Money Money Hole. :( - chaoscell</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1313568&amp;board=8&amp;topic=29002092" class="name">Jmast7</a> |
Posted 7/5/2006 12:27:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317496952">message detail</a>
 | #220</td></tr>
<tr class="even">
<td>
tag<br>---<br>"I have never cared for the Yankees, and for a very good reason: The Yankees are evil." <br>&#8211; Dave Barry</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/5/2006 5:10:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317563097">message detail</a>
 | #221</td></tr>
<tr class="even">
<td>
<b>Snake Division:</b> <i>Round 1 - Match 5</i> &#8211; (1)Metal Gear vs. (8)Soul Calibur <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Metal Gear</b><br>The
Metal Gear series started on the NES, but moved to the Playstation and
became Metal Gear Solid. The third is the latest, but we&#8217;re all ready
for MGS4.<br> <br><b>Soul Calibur</b><br>The Soul Calibur franchise is
one of the few fighting series that I actually like. Started on the
Dreamcast, but branched out to all three consoles for the sequel. The
latest is the 3rd and it&#8217;s PS2 exclusive.<br><br>And thus begins what
should be the most fun division in the bracket, the Snake division. MG
is obviously the weakest 1-seed in the Contest, and contenders like
Kingdom Hearts and Halo are looking for the upset.<br><br>While MG
might be the weakest 1 seed though, doesn&#8217;t mean it&#8217;s weak overall. It
will probably be underrated in this match because most will forget how
well Soul Calibur did in 2004. SC was pretty much even with Kingdom
Hearts, which lost in a close one to Starcraft, and we all know how
well Starcraft did. <br><br>Unfortunately, a strong series like Soul
Calibur is screwed over by going up against Metal Gear in Round 1. It
would have had tons of potential in another part of the bracket. Soul
Calibur might do well against Metal Gear, but it&#8217;s not looking like it
can pull off the win. MG should at least hit the doubling in order to
look good.<br><br><b>Moltar&#8217;s Bracket Says:</b> Metal Gear will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Metal Gear: 67% - Soul Calibur: 33%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>It's
a shame that Soul Calibur is stuck being 8 seed fodder in this contest,
because it would be nice to see whether or not its performance in the
games contest was a fluke. As it stands, MGS just has an easy first
round match. The only drama here will be where MGS's percentage ends up.<br><br> Prediction: MGS with 62.35% <br> <br><br><br><b>Soul&#8217;s Analysis</b><br> <br>After
that bore known as the Hyrule Division, we move on to a slightly better
division. Ok, I'm sorry. A hell of a better division. We have a great
four-back in the upcoming days, as well as a pretty good 4 Vs. 5 match.
But first, we have the heavy hitter of the division.<br><br>Metal Gear
is probably Sony's most beloved series on this site. Sure, Madden and
GTA get more sales, but I doubt those series are nearly as loved as MGS
is. Add to that a kickass story with phenomenal characters and boss
fights and you've got one hell of a strong series in this contest.<br><br>What's
so shocking about this match though is the fact that Soul Calibur is
also a strong series. This is evident by the fact that the first Soul
Calibur game ranked ahead of every Metal Gear game in the Top 100
contest. (Note from Moltar: Actually, SC ranked below every MG game on
the Top 100) There's also the extremely popular Soul Calibur 2 that was
released on every major platform this generation. Soul Calibur 3 was
well received as well. Basically, Soul Calibur will be no slouch in
this contest, and could potentially scare Metal Gear in their first
round match.<br><br>Mostly everyone believes Metal Gear will win this
one. I suspect that Metal Gear will win this as well, but not as
comfortably as others believe. SC is underseeded for sure, and will
definitely surprise many people.<br><br><b>My prediction: Metal Gear wins with 57.86% of the vote. </b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/5/2006 5:11:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317563285">message detail</a>
 | #222</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>Ah, two contests for Soul Calibur, two 8
seeds. The only difference now is that being an 8 seed means you get
fed to the top seed right off the bat. The last time we saw it in a
contest, it shocked nearly everybody on Board 8 by leading Kingdom
Hearts for a long time before finally giving way and losing in a close
one. When an entrant shows that kind of strength in a contest, being
relegated to a sacrificial lamb seems like a waste. Soul Calibur could
be a good dark horse somewhere else, but alas, such is bracketing.<br><br>Before
the bracket was released, three of the four 1 seeds were no-brainers:
Final Fantasy, the Legend of Zelda, and Super Mario Brothers. The
fourth top seed was oft-debated, but the majority seemed to agree that
Metal Gear was the most likely choice to get it. Turns out they were
right. After Metal Gear Solid was utterly embarrassed by Final Fantasy
VII in the Spring Contest and Solid Snake&#8217;s disappointing performance
in SC2K4 where he didn&#8217;t even appear to be Noble Nine quality anymore,
the series appeared to be on the way down. <br><br>However, the
release of Metal Gear Solid 3: Snake Eater in late 2004 appears to be
the breath of fresh air that the series needed. Solid Snake was
stronger than he&#8217;s ever been in 2005, and he needed every ounce of that
new power to make his first ever Final Four. Then the original Metal
Gear Solid placed at #8 on the GameFAQs Top 100 List, leading some to
believe (along with Sephiroth/Liquid Snake in the Villains Contest)
that perhaps Final Fantasy VII had overperformed on it back then. Now
here it is in 2006 with the coveted fourth top seed in the Best Series
Ever Contest.<br><br>Metal Gear&#8217;s strength was a hot topic among us
statheads, wondering if it really WOULD be the fourth strongest. There
were quite a few who felt that it could be beaten by some other series,
but unfortunately (or perhaps fortunately, if you&#8217;re a Metal Gear mark)
the strongest contenders are nowhere to be seen in the Snake Division.
Granted, Metal Gear still has some potential challengers, but compared
to what it could have had, it got off easy. Soul Calibur will do
decently, but it won&#8217;t do enough to win. Heck, I think it&#8217;ll do better
than a lot will expect, leading people to get on the upset bandwagon
for it to lose before the Final Four.<br><br><i>Leonhart&#8217;s Prediction:</i> <b>Metal Gear with 58.41%</b><br> <br><br><b>Lopen&#8217;s Analysis</b><br> <br>1v8
fodder match! Alright, I get to make fun of the fodder now! No? What do
you mean no? Soul Calibur is actually something to be respected? Why
yes, Timmy, it is. At least&#8230; it looks like it is. Soul Calibur gave
Kingdom Hearts quite the scare in the game contest a couple of years
ago. And that was just the original! The second one had some stupid
gimp-tier elf in it that I'm told is pretty popular on this site. Oh
man, imagine that as the match picture? Link vs. Melting Snake. I'd be
loling to the bank, there. I'm going off on a tangent&#8230; anyway&#8230;<br><br>I
have a somewhat bold assumption here&#8230; that most of the people who voted
for Soul Calibur did so because of Soul Calibur 2 in the game contest.
So what you see there is the meat of what you get. Soul Calibur 3 has
since been released, but it didn't really leave the mark that Soul
Calibur 2 did&#8230; and it lacked gimp-tier-mcelfton.<br><br>So assuming you
believe me (and why wouldn't you?), the Soul Calibur of yore is about
as good as we're going to see. You've got a series here that barely
loses to Kingdom Hearts 1 alone in a 3 on 1 handicap match. Man, I hope
the entire Metal Gear Solid series can do better than that. And if it
can't, I blame it on Solid Snake and his games that are less good than
Metal Gear Solid 2. Raiden had <i>nothing</i> to do with it.<br><br><b>Lopen's Prediction:</b> Metal Gear with 61.61%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/5/2006 5:11:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317563414">message detail</a>
 | #223</td></tr>
<tr class="even">
<td>
<b>HM&#8217;s Analysis</b><br> <br>Here we are at the start of Metal Gear&#8217;s
first match in what will be an impressive run in the &#8220;Best. Series.
Ever.&#8221; Contest &#8211; fourth strongest, in fact! Soul Calibur is probably
one of those games that fall under &#8220;wasted potential,&#8221; as it could have
done some major things in any other place in the bracket.
Unfortunately, it got stuck against an absolute beast of a franchise in
Metal Gear. Even with its strength, I think Soul Calibur is going to be
getting quite a beat down that may not be expected by everyone. <br><br>Let&#8217;s
examine some of the facts we know about both franchises in previous
contests and what we can get from The List. Interestingly, Soul Calibur
places above any singular Metal Gear Solid game in the extrapolated
stats. However, you just have to take a look at StarCraft&#8217;s cheating
run in the contest to see that it is overrated a bit. On top of that,
Metal Gear Solid likely suffered some sort of SFF against Final Fantasy
VII, which has shown to show some type of fanbase before. Further,
Metal Gear Solid managed to rank in the Top 10 in The List, eighth to
be exact. Metal Gear Solid 2 ranked pretty highly in the stats as well,
slightly above Metal Gear Solid, though both were Top 25 games.<br><br>As
far as The List is concerned, Metal Gear Solid, as I said ranked 8th;
Metal Gear Solid 3 ranked 21st; and Metal Gear Solid 2 ranked 41st.
Soul Calibur ended up ranking 51st and that would be the only game on
the list from the series. It is pretty clear from this alone that Metal
Gear Solid outranks Soul Calibur in pretty much every stat related case
we have &#8211; you have to take into account StarCraft&#8217;s cheating votes. And
let&#8217;s just be honest here, Metal Gear is far too popular of a series to
lose to <i>any</i> fighting game series, or even any series not named
Mario, Zelda, or Final Fantasy. It is a widely popular franchise that
has gathered many fans, sold millions upon millions of copies, and
currently has one of the most anticipated next-generation games in
Metal Gear Solid 4. Solid Snake is also a testament to just how strong
the Metal Gear franchise is, with its character always being in the top
nine characters since his entry back in 2002. There&#8217;s no way this one
will be even remotely close, folks. But I bet you already knew that<i>!!</i><br><br>I
probably spent too much time going over something that is rather
obvious, but I really wanted to give a little insight into why Metal
Gear is going to be strong enough to lay a beat down on Soul Calibur
and others in its division, at least until it runs into Kingdom Hearts.
I even think it&#8217;ll end with a respectable percentage against The Legend
of Zelda, but that&#8217;s another analysis for another time &#8230;<br><br><b>Aitch Emm&#8217;s Bracket Says :</b> Metal Gear will win.<br><br><b>Aitch Emm&#8217;s Prediction :</b> Metal Gear 67% -- Soul Calibur 33%<br><br><b>Aitch Emm&#8217;s Vote :</b> Metal Gear.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/5/2006 5:12:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317563548">message detail</a>
 | #224</td></tr>
<tr class="even">
<td>
<b>Mnm&#8217;s Analysis</b><br> <br>Metal Gear gets its expected number one
seed in this contest and is in great position to do some damage in this
contest. People are expecting it to be a powerhouse in this contest,
but I wouldn&#8217;t go as far as to call it that. Metal Gear is certainly
beatable, and I would take a number of series to beat it. Fortunately
for Metal Gear, most of those series are either on the on the other
side of the bracket, or out of the contest altogether. But still, there
are a few series in this division that can give MG a run, but again
Metal Gear is fortunate in that they have to beat each other up to
reach MG. Ah, the comfort of being a one seed.<br><br>Don&#8217;t get me wrong, Metal Gear Solid is <i>definitely</i>
a popular series on GameFAQs. I just feel that people overrate its
strength on this site. Metal Gear definitely has a large core group of
fans, but it isn&#8217;t for everyone. I wouldn&#8217;t say its fanbase was any
bigger than say, the GTA or Halo fanbase on this site. Now, on to the
match at hand.<br><br>Metal Gear had a decent run in the games contest, but it didn&#8217;t do <i>that</i>
well. The meat of the series, as we all know, is the Metal Gear Solid
trilogy. MGS2 did pretty well against SSBM, but it was directly
outclassed by GTA: Vice City. MGS did well in beating FFT, but it
succumbed to FFVII and probably is underrated due to a tad of SFF. MGS2
did okay in its GotY poll, but was overshadowed by GTA and FFX. MGS3
also did well in the GotY poll, but it too was outclassed by GTA. The
best thing MGS has to show on this site is its #8 spot on the Top 100
list. But then again, having a large dedicated fanbase does wonders for
you in that type of contest. Still, Metal Gear has shown to be pretty
strong on this site. It&#8217;s definitely beatable though.<br><br>It&#8217;s
opponent is Soul Calibur and it is no slouch itself. If you go by the
SpC2k4 stats, one might even be enticed to take SC over MGS, seeing
that SC ranked higher than both MGS games. There are a couple of things
about that though. Metal Gear Solid is definitely underrated in that
contest. Soul Calibur is probably <i>overrated</i> due to being behind
Starcraft&#8217;s Cinderella run. Plus, Soul Calibur was probably at the peak
of its popularity then, with the large SC2 multi-console release. A lot
of SC&#8217;s strength is probably due to SC2 and the many Nintendo fans
happy that they have Link in their version of the game joining the
dedicated SC fanbase. But that time has come and gone. Even with Soul
Calibur 3 on the PS2, I don&#8217;t think SC as a series is as popular as it
was in 2k4. It still definitely will give the Metal Gear a fight
though. Don&#8217;t think it will just roll over for it. Some of these
predictions I&#8217;ve seen around the board are crazy with people having
Metal Gear absolutely thrash Soul Calibur. Metal Gear will have to
prove it to me in this match.<br><br>Bracket: <i>Metal Gear?!</i><br>Vote: <i>Metal Gear?!</i><br>Prediction: Metal Gear with 59.65%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/5/2006 5:13:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317563741">message detail</a>
 | #225</td></tr>
<tr class="even">
<td>
<b>Yoblazer&#8217;s Analysis</b><br><br> If you're one of those nuts who
takes 1/8-1/16 upset risks in the hopes something will pay off, this is
undoubtedly your best bet since Halo/Starcraft. Soul Calibur is a
legitimate series; it certainly isn't the fodder its seeding hints at.
The original SC shocked us all by going toe-to-toe with Kingdom Hearts,
and the sequel sold pretty well on all three consoles (and featured
Link in the Gamecube version, no less). Also, Metal Gear has nowhere
near the power of the other top seeded games. When you put the weakest
1-seed against the strongest 8-seed, you'll end up with the best match,
and that's what we'll see.<br><br>That said, the chances for anything
interesting here are slim to none, and slim kinda sorta maybe just took
the first cab outta town. Metal Gear (man, I have to stop myself from
typing "Solid" every single time) is far too established and popular
for Soul Calibur to stand a realistic chance. MGS has a long history of
being Sony's #2 series; the right hand man to Final Fantasy, if ya
wheeeeeeel (why am I sticking a Dusty Rhodes reference into this
analysis? Quote frankly, because I'm bored and hope to god at least one
person gets it). While some might argue that that spot now belongs to
GTA, Snake's series remains high atop the Sony chain of command; much
higher than any fighter.<br><br>Regardless of what the Game Contest
tells us, I'd take any of the three MGS games over Soul Calibur. When
you release a big sequel guest starring friggin' Link, you're going to
get a boost. Doubt that game will be as strong today. Things only look
grimmer once Soul Calibur III's disappointing performance in the Game
of the Year polls comes into play. Also, CJayC's inclusion of CYBORG
RAIDEN in the contest banner shows he is all too willing and able to
provide Metal Gear nothing but recent pics that all fans will instantly
recognize. Board 8 MGS fans, of course, will ***** and moan about every
picture it gets. Looking forward to it!<br><br>Metal Gear<br>+ Three popular games to carry it<br>+ Spans a surprising amount of consoles<br>+ Gets a bye into Round 3<br>- Nothing for this match<br>- Round 3 match could be surprising<br>- Is that Zelda I see up there? Oh, fiddley-dee<br><br>Soul Calibur<br>+ Spans a good amount of consoles<br>+ Great SpC2K4 performance<br>- What have you done for me lately?<br><br>My prediction: Metal Gear def. Soul Calibur (62-38)<br> <br> <br> <br><b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Metal Gear<br>Top 100 List comparison:<br>---MGS - #8, MGS3 - #21, MGS2 - #41<br>---SC - #51<br>Best Game Ever x-stat comparison:<br>---MGS2 - 32.52%, MGS - 28.7% (may have been SFF'd by FF7), MG - 14.13%<br>---SC - 34.28% (was behind Starcraft)<br><br>I
just want to point out the huge clash between the Top 100 List and the
Best Game Ever stats and note that, as always, both should be totally
ignored and your bracket should go by pure instinct. Diablo &gt;
Pokemon in the championship, bay-bee.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=25659&amp;board=8&amp;topic=29002092" class="name">Adamantno1</a> |
Posted 7/5/2006 5:14:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317564015">message detail</a>
 | #226</td></tr>
<tr class="even">
<td>
<i>The Metal Gear series started on the NES</i><br><br>No it didn't.<br><br>---<br>My
nick's Adamant. I have a "no 1" that looks stupid. Would've changed it
if I could without losing karma. So it's Adamant, not Adamanto or
Adamantno.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/5/2006 5:14:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317564051">message detail</a>
 | #227</td></tr>
<tr class="even">
<td>
With Metal Gear Solid being a Top Ten game on the site according to the
Top 100 List while MGS2 got #41, it looks all but certain that MGS was
SFF'd in the Game Contest. SC was behind Starcraft and it placed #51 on
the Top 100 List -- below all three MGS games when the stats <i>clearly</i> show SC &gt; MGS2 and MGS, so consider me crazy, 'cuz I <i>tthhiinnkk</i>
Starcraft might have over-performed somewhere; call it a hunch. To add
to it, the MG series has spanned more systems and generations than SC.
Then to finish it off, I think more people appreciate the MG series
than fighting games in general (excluding SSB/M, damn you), so that
should put a halt to most arguments. Now, SC2 did get real popular
though, and SC3 was...released, at least (I almost literally know
nothing else about it than that, heh), so it should hold its own
against "that one other one-seed" in their match-up, but I plan to
watch this match-up more to see the potential strength for Nightmare in
the Character Contest than anything else.<br><br><br>It sucks that Soul Calibur couldn't have been a "7-seed" though -- switch it with Harvest Moon.....<br><br>Metal Gear win with 60.12%<br> <br> <br> <br>Comments:
Crew in favor of MG 9-0. It frightens me that HM, that crazed MG
fanboy, and I call for the same result. The others think it will be
closer though.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/5/2006 5:16:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317564584">message detail</a>
 | #228</td></tr>
<tr class="even">
<td>
[This message was deleted at the request of the original poster]</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/5/2006 5:18:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317564829">message detail</a>
 | #229</td></tr>
<tr class="even">
<td>
Damn you Soul! I thought I had the lowest percentage for Metal Gear by
far! I even upped my prediction percentage by 2% out of comfort that I
would still be the lowest! Now I'm.... <i>boxed in again</i>!<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/5/2006 5:18:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317564933">message detail</a>
 | #230</td></tr>
<tr class="even">
<td>
<i>The Metal Gear series started on the NES<br><br>No it didn't.</i><br><br>I meant in the US.<br>---<br>Moltar Status: Excited, the Contest is here at last!<br>Metroid vs. Kirby - Bracket: <b>Metroid</b> - Vote: <b>Kirby</b> (3/3)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29002092" class="name">BlAcK TuRtLe</a> |
Posted 7/5/2006 5:35:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317568839">message detail</a>
 | #231</td></tr>
<tr class="even">
<td>
If Kirby can bring today's down to 70.84 or less, I will have beaten the crew.<br><br><br><b>TuRtLe</b><br>~~~<br>Like Darth Maul, the bastard child of Michael Flatley and Hellboy. -trancer1</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/5/2006 5:56:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317573928">message detail</a>
 | #232</td></tr>
<tr class="even">
<td>
Whoa! No idea I had the same prediction as Moltar, but I like the way he thinks!<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29002092" class="name">BlAcK TuRtLe</a> |
Posted 7/5/2006 6:18:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317579141">message detail</a>
 | #233</td></tr>
<tr class="even">
<td>
[This message was deleted at the request of the original poster]</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29002092" class="name">BlAcK TuRtLe</a> |
Posted 7/5/2006 6:20:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317579476">message detail</a>
 | #234</td></tr>
<tr class="even">
<td>
<a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29013865&amp;page=0" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29013865&amp;page=0">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29013865&amp;page=0</a><br><br>Is my analysis if anyone's interested. And noone has a blowout pick? My prediction of 72.57 is looking pretty lonely up there.<br><br><br><b>TuRtLe</b><br>~~~<br>Like Darth Maul, the bastard child of Michael Flatley and Hellboy. -trancer1</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=457389&amp;board=8&amp;topic=29002092" class="name">ravensrule99</a> |
Posted 7/5/2006 6:20:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317579485">message detail</a>
 | #235</td></tr>
<tr class="even">
<td>
Moltar must think really bad then</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=835534&amp;board=8&amp;topic=29002092" class="name">Rad Link 5</a> |
Posted 7/5/2006 11:31:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317655731">message detail</a>
 | #236</td></tr>
<tr class="even">
<td>
Post in topic with Bobobo-bo Bobobo mention.<br>---<br>um that dose that mean your a girl my immortal since you have a boy friend - ertyu<br><b>Detective in Sir Chris' Police</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/5/2006 11:34:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317656351">message detail</a>
 | #237</td></tr>
<tr class="even">
<td>
<i>It frightens me that HM, that crazed MG fanboy, and I call for the same result. </i><br><br>Hmm? =p<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/5/2006 11:34:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317656484">message detail</a>
 | #238</td></tr>
<tr class="even">
<td>
I had a blowout pick for the Oracle. <br><br>God damn, if I stayed with all my oracle picks I would be pretty damn unstoppable right about now.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br><i>^5 SOWL IMHO</i> - Explicit Content</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29002092" class="name">Lugia2</a> |
Posted 7/6/2006 7:07:02 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317704570">message detail</a>
 | #239</td></tr>
<tr class="even">
<td>
Blowout, blowout, blowout...Maybe we should all just pick 90% picks.<br><br>Kidding.  Anyway, the next match shouldn't be so blowoutish.<br><br>FE 56%-SH 44%?<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/6/2006 12:40:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317748768">message detail</a>
 | #240</td></tr>
<tr class="even">
<td>
Metroid........................70.57% 75098<br>Kirby............................29.43% 31312<br>TOTAL VOTES........................106410<br><br>89.22% of the brackets predicted this match correctly.<br><br>Metroid
went and laid the smackdown on Kirby here. Most of us saw this coming
though, so it's not really any surprise. I liked how Kirby chipped away
at the percentage all day though. Shows that the puffball had
determination!<br><br>Today, Metal Gear exploded out of the gate, but
ever since morning, Soul Calibur has been chipping away at the
percentage. At a much faster rate than Kirby did too.<br><br>HM - 1<br>Soul - 1<br>HaRRich - 1<br>Ulti - 1<br>Moltar - 0<br>Leon - 0<br>Yoblazer - 0<br>Mnm - 0<br>Lopen - 0<br><br>I almost stole this one away from HM, but he gets the point in the end.<br>---<br>Moltar Status: Excited, the Contest is here at last!<br>Metal Gear vs. Soul Calibur - Bracket: <b>MG</b> - Vote: <b>MG</b> (4/4)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/6/2006 1:03:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317753541">message detail</a>
 | #241</td></tr>
<tr class="even">
<td>
Best prediction two days in a row<i>!!</i><br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/6/2006 2:32:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317773691">message detail</a>
 | #242</td></tr>
<tr class="even">
<td>
You know, I think I need to start putting a +5% on all my Nintendo
related matches. I'll try one more time, but if Fire Emblem beats
Silent Hill down, I'm changing my Nintendo related picks!<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/6/2006 2:42:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317775944">message detail</a>
 | #243</td></tr>
<tr class="even">
<td>
<b>Snake Division:</b> <i>Round 1 - Match 6</i> &#8211; (4)Fire Emblem vs. (5)Silent Hill <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Fire Emblem</b><br>Back
in 2004, the FE series was new to America, and most already associated
it with Marth and Roy. Now the FE franchise is a bit more popular in
America. The latest is Path of Radiance released on the GCN.<br> <br><b>Silent Hill </b><br>Other
than Pyramid Head, we haven&#8217;t seen SH in Contest format. It is pretty
popular though, even spawning a movie. The most recent in the franchise
is Silent Hill 4.<br><br>This is a Round 1 match that has gotten some
talk. Too bad it&#8217;s a match where, like Vyse/Laharl, will be harder to
watch than two old people making love.<br><br> Fire Emblem was in the Spring 2004 Contest, where it was doubled by FFTA. <br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1629" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1629">http://www.gamefaqs.com/poll/index.html?poll=1629</a> &#8211; FFTA/FE<br><br>Now,
the GBA game had only been out 4 months prior to the Contest, and it
was facing another GBA RPG. The only thing was that it&#8217;s part of the
Final Fantasy franchise. FFTA then proceeded to get whooped by another
Final Fantasy game, FFX.<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1647" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1647">http://www.gamefaqs.com/poll/index.html?poll=1647</a> &#8211; FFX/FFTA<br><br>So
could it be that Fire Emblem&#8217;s weaknesses was not only caused by how
new it was, but also because it was behind some serious SFF? Who knows?
Now, the FE franchise has 2 new games with it, and time to age, so
should it do much better now? Of course.<br><br>But what about Silent
Hill? I haven&#8217;t mentioned it at all yet. Well, what is there to talk
about? The franchise should be stronger than Pyramid Head, but I can&#8217;t
see SH having any strength whatsoever. &#8220;but zomg it has the movie!!1!&#8221;
Ok, so it might be more popular overall in the States, but here at
GameFAQs, that doesn&#8217;t matter. Silent Hill shouldn&#8217;t do too badly, but
that&#8217;s because Fire Emblem isn&#8217;t much stronger itself.<br><br>The match
picture should have a huge influence on this match as well. If FE ends
up with Marth and Roy in the picture, expect it to do much better than
a picture without them.<br><br><b>Moltar&#8217;s Bracket Says:</b> Fire Emblem will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Fire Emblem: 59% - Silent Hill: 41%<br><br><br><br><b>Soul&#8217;s Analysis</b><br> <br>Here's
a match that is supposed to be a close one but won't. People are really
hyping this one to go any way. On paper it looks interesting, but if
you would think about it, you would realize how easy this match is to
predict.<br><br>Fire Emblem is a pretty big franchise in Japan, and
it's just starting to get popular in North America. It is a Nintendo's
best RPG series not named Pokemon. Silent Hill, as good as it is, will
not be strong enough to handle a respectable Nintendo RPG series. It
would need outside influence to be able to take on Fire Emblem. Maybe
something like... a movie?<br><br>XD!<br><br>I contemplated leaving
this write-up as is, but I guess I could extend it a bit. The Silent
Hill movie will do nothing for our contest. I laugh at anyone who
thinks that. I'll compare it to the Tomb Raider and Resident Evil
movies. Both TR movies did nothing for Lara Croft. The RE movies did
nothing for Jill Valentine. The Silent Hill movie will do nothing for
the Silent Hill series. Add to the fact that the movie wasn't that
good. The movie would have had to have been amazing for it to make
people vote for a series they've never played.<br><br>And SSBM could
have some influence in this match. "Marth, the best character in SSBM,
comes from Fire Emblem! That series must be good!". Ok, that probably
won't happen, but you never know.<br><br><b>My prediction: Fire Emblem wins with 58.25% of the vote</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=965303&amp;board=8&amp;topic=29002092" class="name">SephirothG</a> |
Posted 7/6/2006 2:42:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317776121">message detail</a>
 | #244</td></tr>
<tr class="even">
<td>
SH &gt; FE lol<br>---<br>[Something clever was here before the sig wipe]<br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/6/2006 2:43:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317776224">message detail</a>
 | #245</td></tr>
<tr class="even">
<td>
<b>Ulti&#8217;s Analysis</b><br> <br>I have little experience with the Silent
Hill series, so sorry in advance for this one being a bit one-sided on
my end. I once tried playing SH2, but got scared and quit after getting
to that big apartment building near the beginning. And you people think
I'm kidding when I say The Ring scarred me for life.<br><br>Anyway,
this is a match between two cult series. Fire Emblem, Nintendo or not,
is rather cult. It can credit SSBM for its popularity's starting point
in America. Before FE7 was released stateside, the first six games of
the series were all Japan-only. This makes the fact that some FF titles
were held from the US look miniscule.<br><br>Thanks in large part to
Marth and Roy being in SSBM, "Fire Emblem" saw some success when it was
released. 500k copies were sold in America, and over a million sold
worldwide. Nintendo saw that the series had potential, and ran with it.
Fire Emblem 8 was released for the GBA, and Fire Emblem 9 was released
on the GCN to mark the first Fire Emblem to see a major console on
American soil. Furthermore, go look at the SSBB trailer. It's pretty
obvious that Ike and his castle are both going to be in the game, which
will only help boost the series even further.<br><br>Fire Emblem has
moved from cult status to niche since the release of SSBM and FE7, and
it's slowly establishing itself with each new release. Correct me if
I'm wrong, but I think a Fire Emblem Wii is currently in production.<br><br>As
for why I think Fire Emblem wins, FE is niche. Silent Hill is about as
cult as it gets, movie release or not. That movie is also being damn
overrated by Silent Hill fans hopeful for a win. Tomb Raider 2 came out
the weekend before Lara Croft's match with Zelda in 2003; Lara still
got her ass whipped. Crash Bandicoot, due to commercial exposure alone,
should have wiped the floor with Ulala in 2002. He did not. He probably
should have beaten the far lesser-known KOS-MOS in 2003. He did not.
Resident Evil movies haven't exactly helped their characters out; that
credit goes to games themselves. It takes far more than TV exposure to
do anything on GameFAQs, land of all things that make no sense. Silent
Hill would likely be a lock on any other site. As it stands... nah.<br><br>Prediction: Fire Emblem with 62.15%<br><br> <br> <br><b>Leon&#8217;s Analysis</b><br> <br>For
some reason, every contest features a match between two fodderific
entrants, guaranteeing that at least one of them will win a match while
two strong entrants end up facing each other in the first round,
leaving one without a single win. 2002 was full of them, but Serious
Sam/Mr. Driller was the worst of the worst, if you want to get down to
it. 2003 had Gordon Freeman/Max Payne. The Games Contest had, well,
Final Fantasy Tactics Advance/Fire Emblem. SC2K4 had Vyse/Laharl, which
has essentially become the iconic match to symbolize this type, and it
was an 8/9 match to boot! The Villains Contest, of course, had quite a
few, with Ansem/CATS being the headliner. SC2K5 had Lloyd/Wesker. And
here we are in our 2006 Series Contest with Fire Emblem/Silent Hill.<br><br>With
very limited data to work with for both series and little guarantee of
strength from either side, this essentially becomes a matter of which
series you think is weaker. As mentioned earlier, Fire Emblem&#8217;s only
previous contest experience is a bad loss against Final Fantasy Tactics
Advance in Sp2K4, where it barely avoided a doubling. Granted, you
could make a case for Fire Emblem not looking <i>quite</i> as bad as
it appeared. After all, the game had only been out for four months at
the time of the contest, and it was facing another GBA-exclusive title,
and a Final Fantasy title on top of that. An underperformance is not
out of the question. Then there is the possibility of FFX/FFTA SFF, of
course, so Fire Emblem has a little room for improvement.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/6/2006 2:44:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317776417">message detail</a>
 | #246</td></tr>
<tr class="even">
<td>
The only Silent Hill entry we have seen is Pyramid Head in the Villains
Contest, where he was destroyed by Bowser and finished fourth from the
bottom, almost on equal ground with Luca Blight. And we KNOW Suikoden
is about as weak as they come, but I&#8217;ll give it the benefit of the
doubt because games =/= characters. Silent Hill does have the advantage
of being more mainstream and I suppose more recognizable to the average
gamer, but on GameFAQs, I don&#8217;t consider that to be much of an
advantage. This is a gamers&#8217; site and one that loves RPGs and Nintendo
above all. And whaddya know? Fire Emblem is BOTH an RPG and Nintendo.<br><br>As
I mentioned before, this is a situation where you pick the game with
the least likelihood of losing. In this case, I have to believe it&#8217;s
Fire Emblem.<br><br><i>Leonhart&#8217;s Prediction:</i> <b>Fire Emblem with 55.54%</b><br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br>This
would be the second debated match so far in the bracket &#8211; the first
being Pokemon/Star Ocean, at least to some extent &#8211; and it&#8217;s really
more of a snooze fest than something exciting. Perhaps it is because
most people are not really fanatical about either series, but the
debates circulating around this one are rather boring, and the match
itself should rack up the lowest vote totals in the contest. <br><br>My
initial thought on this match when filling out the bracket was to
choose Fire Emblem simply because it is a Nintendo franchise. I never
saw Silent Hill as being all that popular here, and Fire Emblem at
least had the added benefit of having some of the Nintendo fanbase
behind it. Of course, those were just initial thoughts and it wasn&#8217;t
until afterward that I realized there was actually some real
justification to picking Fire Emblem that didn&#8217;t deal with Silent
Hill&#8217;s weakness. <br><br>We have seen Fire Emblem perform in the
contest before &#8211; it went against Final Fantasy Tactics Advance in the
games contest. Unfortunately, it was beaten down pretty easily, which
goes to show that vocal hatred on boards does not translate into hatred
when the entire site votes. There <i>is</i> a possibility that FFTA
SFFed FE since both come from the same genre and on the same platform.
FFTA does carry the Final Fantasy name, which is certainly going to
give it some added strength. Of course, this is all just a possibility
and probably one that isn&#8217;t too significant. <br><br>As well know,
FFTA went on to face FFX, which just seems to scream SFF. FFX didn&#8217;t
completely annihilate FFTA, so it&#8217;s entirely possible that there wasn&#8217;t
very much SFF there. Still, anything would help to give Fire Emblem
some added strength. On top of that, this match took place only four
months after its release in November 2003. I hadn&#8217;t gotten around to
playing it by the time it had a match, which I&#8217;m sure might be the same
for a number of people. Further, Fire Emblem has seen two releases
since its last appearance in the game contest (Fire Emblem : The Sacred
Stones on the GBA and Fire Emblem : Path of Radiance on the GCN).
Awareness has undoubtedly increased for the series with more games
released over here in America. I think it&#8217;s worth bringing up the sales
of the games too &#8230;<br><br>Fire Emblem (GBA) -- 450,000<br>Fire Emblem : The Sacred Stones (GBA) -- 308,414<br>Fire Emblem : Path of Radiance (GCN) -- 173,858</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/6/2006 2:44:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317776556">message detail</a>
 | #247</td></tr>
<tr class="even">
<td>
That isn&#8217;t too shabby, really. I think the fact that it sold pretty
well, it comes from a Nintendo franchise, has three titles released
over here in America (which seems to have raised awareness and
popularity of the series overall), and weakness of Silent Hill overall
will lead a pretty easy Fire Emblem victory. People like to cite the
Silent Hill movie and the overall advertisement it has received over
the past few months, but movies for weak series really aren&#8217;t going to
do much. We have seen DOOM and Lara Croft not benefit much at all with
the release of a new movie, so why should we expect the same of Silent
Hill?<br><br>Perhaps
I&#8217;m mistaken, but I have never once noticed anything notable from
Silent Hill at GameFAQs. It seems to have its own little fanbase, but
it is nothing overwhelming or exceptionally popular. We have seen
Pyramid Head in the villains contest and his performance was really
poor. It is true that one could bring up that any Fire Emblem villain
probably wouldn&#8217;t perform much better, but I would wager that someone
like Lyn or Hector would out perform any Silent Hill character, villain
or protagonist. It helps that Fire Emblem has seen exposure through
Super Smash Bros. Melee with Marth and Roy. <br><br>So yeah, I think
Fire Emblem ends up taking this one without too much trouble. It won&#8217;t
be a blowout, but the match will never be in question. I can&#8217;t say I&#8217;m
looking forward to it either, if only because it&#8217;ll be really dull. <br><br><b>Aitch Emm&#8217;s Bracket Says :</b> Fire Emblem will win.<br><br><b>Aitch Emm&#8217;s Prediction :</b> Fire Emblem 55.5% -- Silent Hill 44.5%<br><br><b>Aitch Emm&#8217;s Vote :</b> Fire Emblem.<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Fodder matches stink<br>Plagued half of last spring's first round<br>This year, much less stink<br><br>For
anyone who's upset over this fodderific match, I urge you to take a
quick trip down Spring Contest 2005 memory lane. No less than HALF the
opening round matches were stinkers like this one. Let us count our
blessings and be thankful that this 32-entry bracket only has one
fodder match.<br><br>Speaking of last spring, I have a little story to
share with everyone. As the Spring 2005 Contest bracket was released, I
initially had Ridley winning his division. I was confident with this...
for all of four hours. After looking at the arguments and separating
good from bad, I decided Diablo would be the wiser choice. I made that
one change to my bracket, locked it up, threw away the key, and was
lucky enough to come out with a fortunate result. Fast forward to the
series contest: I initially had Silent Hill winning this match. I was
confident with this... for all of four hours. After looking at the
arguments and separating good from bad, I decided Fire Emblem would be
the wiser choice. I have made this one change to my bracket and have
since locked it up and thrown away the key.<br><br>It was something
that Leonhart said which really helped put this match in perspective
for me: "Silent Hill could be like the Splinter Cell of the survival
horror genre. You have the clearly established most popular series
(Metal Gear Solid/Resident Evil) and a looooong drop before you hit
second." To me, this makes a lot of sense. Resident Evil has the more
popular games and characters. It has the more established fanbase on
GameFAQs. Even before RE4 hit the scene, it was clearly the genre's
most popular representative on this site. Silent Hill, on the other
hand, has characters and games that have barely caused a blip on the
radar, and its fanbase is practically nonexistent.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/6/2006 2:45:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317776698">message detail</a>
 | #248</td></tr>
<tr class="even">
<td>
As a series, Silent Hill performed terribly in an older "Which Konami
series is your favorite?" poll (losing not only to Metal Gear and
Castlevania, but to Suikoden, Contra, and <i>Yu-Gi-Oh</i>)
and its lone character entry, Pyramid Head, had a lackluster Spring
2005 match against Bowser. For a series that is often looked upon as
Konami's #3, Silent Hill sure doesn't draw much attention on GameFAQs.
Can it really beat a Nintendo RPG that is on a very healthy popularity
upswing in America? I wouldn't bet on it; Analysis complete; no look at
Fire Emblem required.<br><br>Fire Emblem<br>+ Nintendo RPG<br>+ Gaining popularity in America<br>+ Lucky enough to draw one of the only series it could beat<br>- Still fairly new to this part of the world<br>- Sacrificed in Round 2<br><br>Silent Hill<br>+ It made the contest (&lt;3 Inviso)<br>+ It has MY vote<br>+ Lucky enough to draw one of the only series that wouldn't kill it<br>- Poor contest/poll history<br>- No indication of a fanbase on GameFAQs<br><br>My prediction: Fire Emblem def. Silent Hill (56-44)<br> <br> <br> <br><b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: Fire Emblem (SSBM)<br><br>Okay, this match scares me.  I mean it <i>really</i>
scares me. At first glance I didn&#8217;t think much of it, but the more I
looked at the matchup, the more uncertain I became of it. Out of all
the first round matchups, this is the one I feel I have the greatest
chance of losing. Neither series is really popular here on GameFAQs,
but that still doesn&#8217;t mean that this can&#8217;t be a back breaker of a
match. The thing that worries me is that the games have wild cards that
are completely different. The match could easily end up being pretty
decisive on either front. <br><br>Fire Emblem is a Nintendo strategy
RPG that has gained a little bit of fanfare since its release in
America in 2k4. Before that, the only thing the series had going for it
was Marth and Roy&#8217;s appearances in SSBM. Not a bad game to have
showcasing for you, but still, Fire Emblem definitely needs more than
SSBM cameos to get votes. We&#8217;ve seen it once in the contest setting,
when it was a fledgling set up in a match with the Final Fantasy name.
Sure, it was only FFTA, but outside of board 8 the game actually has
some fans, and that game also went up in a SFF match with FFX. So Fire
Emblem was probably underrated in 2k4. Not to mention that since then,
the series has had a couple more release and a chance to gain some
popularity. Plus you know that it is going to have a lot of the
Nintendo fanbase behind it against the likes of Silent Hill.<br><br>Silent
Hill is a series I&#8217;d like to consider as a &#8220;poor man&#8217;s Resident Evil&#8221;.
It is a decent survival horror series that has been around since the
PSX days. The series has had 4 releases spanning the PSX, PS2, and
Xbox. The series actually has quite a few fans from what I&#8217;ve seen. It
definitely is a known name in the video game market. Unfortunately, the
series has done nothing to show any popularity, although we don&#8217;t have
much data on it. In fact, the only things we have on it is a favorite
Konami series poll, and Silent Hill 2 in a GotY poll dominated by MGS2,
FFX, and GTA3. There was also Pyramid Head&#8217;s showing in the Villains
contest, but I wouldn&#8217;t dare use that to gauge Silent Hill&#8217;s
popularity. The average person would barely even know who the main
protagonist of any of the games is, let alone an obscure villain from
the game. And he was going up against friggin&#8217; BOWSER of all people.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/6/2006 2:45:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317776836">message detail</a>
 | #249</td></tr>
<tr class="even">
<td>
My main thing is this: People seem to think that Silent Hill is some
obscure and unknown series. That is far from the truth. It may not be a
<i>hugely</i>
popular series, but it definitely is well known throughout the
industry. The first game was fairly popular on the PSX and was well
marketed. People know the name &#8220;Silent Hill&#8221;. Put it this way, if
Silent Hill is obscure, then you might as well say Syphon Filter,
Legacy of Kain, Tenchu, and other &#8220;midcard&#8221; series are obscure as well.
I don&#8217;t think so. Plus there was the recent Silent Hill movie. Now I
know people will point to Tomb Raider and Lara Croft to counter that,
but this is a completely different scenario. This isn&#8217;t people looking
for the Tomb Raider movie to cause Lara Croft to increase in popularity
against friggin&#8217; Zelda. This is Silent Hill looking to gain a vote of
indifference against Fire Emblem, which is no Zelda. It doesn&#8217;t take
much to gain that if someone isn&#8217;t a fan of Fire Emblem. All in all,
Silent Hill is a bigger name in the industry and it has a bigger
demographic to draw votes from (PSX, PS2, Xbox), regardless of if they
are votes of indifference. Think about it. If a person who is mainly a
PS2 or Xbox gamer votes in this poll, do you think it&#8217;s going to be for
<i>Fire Emblem</i>? If that person votes at all, it&#8217;s going to be for
Silent Hill. The more votes this match gets, the worse it&#8217;s going to
look for Fire Emblem&#8230;<br><br>Fire Emblem really has one thing going for
it in this match. And that is the Nintendo fanbase behind it. Once
again, with a greater influx of Nintendo fans in this site, FE is going
to be a bit stronger and have a lot of potential support. And one thing
that FE has over SH is that it has a dedicated fanbase <i>on this site</i>.
The SSBM appearance plus the release of 3 games is more than enough to
get the Nintendo backing. In the event of a close match, that Nintendo
fanbase will probably rally to support FE. Silent Hill has no such
backing. If it wins this match, it is going to have to be pretty
decisive (55%-45%). Otherwise, with the expected low vote totals, I can
see the Nintendo wagon getting behind FE and pushing it to a close
victory. Or the fanbase can just make it win outright. Anyways, I&#8217;m
going with Fire Emblem in a close one, but I am very prepared to lose
this match.<br><br>Bracket: Fire Emblem<br>Vote: Silent Hill (I played the first one.  It was pretty good!)<br>Prediction: Fire Emblem with 52.19%<br><br> <br><br><b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Fire Emblem<br>Top 100 List comparison:<br>---FE (GBA) - #54<br>---SH - N/A (had no games on the drop-down list)<br>Best Game Ever x-stat comparison:<br>---FE - 16.59% (was behind FFTA/FFX)<br>---SH - N/A (no rep)<br><br>Don't
worry Ed, I still maintain your quote breaks 45% on either of these
jobbers -- these two are almost as big on jobbing as Randy Orton, ain't
that right ExLax? *botches an RKO on those who disagree*<br><br>Man, it sucks to have to be serious on this match.  Totally sucks.  Can I just skip this match?  Please, Moltar.  No?  *sigh*  <b>****.</b>  Let's see what I can do.<br><br>FE
was the weakest entry in the 128-Division as far as unadjusted x-stats
go, though it was also behind FFTA/FFX, so it should likely be higher.
Futhermore, FE hadn't been out for long -- it, along with other FE
games, have since had more time in America. Roy and Marth both opened
up some awareness for it by being in SSBM, and it doesn't hurt FE at
all that it's a Nintendo RPG. As for Silent Hill, it isn't very good
when arguably your best rep of the series puts up this kind of
performance:<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=775" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=775">http://www.gamefaqs.com/poll/index.html?poll=775</a><br><br>Granted,
there were some big games there, but it's still bad that the series'
best rep only gets 1.65% in a PS2 GotY poll. Compare it to this:<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=525" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=525">http://www.gamefaqs.com/poll/index.html?poll=525</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/6/2006 2:46:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317777063">message detail</a>
 | #250</td></tr>
<tr class="even">
<td>
Yes, FE got dead-last in that poll with 1.07%, but three things should
be considered. One, that poll's got SFF written all over it -- the PS2
poll doesn't (though, granted, MGS2 and SH2 are both made by Konami).
Two, the LoZ series, Mario series, and Metroid series are bigger than
FFX, GTA3, and MGS2. Three, that poll was taken in the early-to-middle
part of 2001...you know, where the Gamecube was still half a year away
from releasing. That means no Roy/Marth exposure, and I'm <i>pretty</i>
sure that means no American-releases had been out for the series yet
either. Now, Silent Hill has had a movie out recently...but it
shouldn't bring too many gamers to this site -- especially not like
FF:AC did, which so many people already give no credit to, so I don't
want to hear a word about SH's movie debut having some kind of effect
from those people.<br><br>Times have changed in FE's favor for sure,
though that doesn't mean it's a big series or anything. Then again,
neither is Silent Hill, so I think, all things considered, FE takes
this one home...<br><br>...like I do EC's mom every other Saturday night.<br><br>Fire Emblem wins with 56.12%<br> <br><br><br><b>Lopen&#8217;s Analysis</b><br> <br>They
called this match a 4v5 on the bracket, but when I looked&#8230; I just
couldn't shake the feeling that this was really an 8v8 match. Or if you
want to say it in non-numerical form, FoddervFodder. I could be wrong,
this is just my "common sense" talking here. But our exposure to both
series is pretty limited on GameFAQs, we don't have <i>too</i> much
more than "common sense" to go off of. I could bring up some polls, but
the gist of it is that Silent Hill does pretty bloody horribly in every
poll it's seen in, but it's usually seen with tougher competition than
Fire Emblem. Fire Emblem on the other hand has shown it can do notably
better, but then again against any competition that's worth their salt,
it falls down just as hard as Silent Hill does.<br><br>So far, it's
looking to me like my hypothesis is correct. Both are pretty foddery
series, with Fire Emblem appearing to have a little bit of an
advantage. Fire Emblem also has one scary factor that Silent Hill does
not&#8230; a game on the top 100 list. Surely a series that is total fodder
could not have a game that is at #54 on that puppy, right? Nay, I say&#8230; <i>wrong</i>. For further reading, I suggest you refer to #68, Skies of Arcadia, and #81 Tales of Symphonia (the latter being a <i>write in</i>)
no less. These games are a lot like Fire Emblem to me from what I've
observed. They all have pretty fanatical fanbases, and they all have
pretty huge followings on Board 8. The second one is the main one I'm
going to stress: Board 8. I think we had a much more significant effect
on the Top 100 list than you'd think. I looked at the top 100 winners,
and <i>6/15</i> were names I could immediately recall from Board 8. "But Lopen, we <i>should</i>
do better, we knows our stuff!", you say. Maybe so, but the thing is,
this is a much higher ratio than most contests, if I recall correctly.
I'm led to believe that there wasn't as high a front page entry rate
for this contest as there were for most. And because entries = votes
for the top 10 list, there were less front page <i>votes</i> for this
one, as well. So, assuming I'm right, we shouldn't be as intimidated by
a "Board 8 favorite" doing so well on that list as we should a Halo or
a Devil May Cry. (It should also be noted that Silent Hill had no rep
on the drop down menu for the top 10 list, so you can't fault it too
much)</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">1</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=1">2</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=2">3</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=3">4</a></li>
<li>      5</li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=5">6</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=6">7</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=7">8</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=8">9</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=9">10</a></li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage5_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29002092&amp;page=4" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage5_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>