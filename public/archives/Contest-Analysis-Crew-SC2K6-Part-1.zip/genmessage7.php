<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><title>GameFAQs: Message List</title>

<link rel="stylesheet" type="text/css" href="genmessage7_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage7_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage7_files/bc.css"></head><body linkifytime="350" linkified="17" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage7_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage7_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29002092%26page%3D6"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage7_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div><a href="http://adlog.com.com/adlog/c/r=10153&amp;s=657805&amp;t=2006.07.11.19.55.35&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=01c17-gne-ad144B3FF01164F81/http://www.gamespot.com/pc/sports/probassfishing2003/index.html?q=pro%20bass" target="_blank"><img src="genmessage7_files/probass_leader.gif" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage7_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29002092&amp;page=6">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29002092" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">First
          Page</a> |
          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=5">Previous
          Page</a> |
          Page 7 of 10          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=7">Next
          Page</a>
          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=9">Last
          Page</a>
      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/7/2006 9:15:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318109286">message detail</a>
 | #301</td></tr>
<tr class="even">
<td>
<i>Curse HaRRicH for stealing my Suikoden/MMX point!</i><br><br>Cheers for giving it away!  =P<br><br><br>As
for today's match, here's to hoping FE stays below 57.18% -- I'll take
another point by the skin of my teeth any chance I can, heh. Then, as
for tomorrow's match, I got a question: if Castlevania wins, do I still
get a point for being the lowest predictor for Halo?<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29002092" class="name">THEJackSparrow</a> |
Posted 7/7/2006 9:16:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318109442">message detail</a>
 | #302</td></tr>
<tr class="even">
<td>
No, you actually have to get the match right. If we're all wrong, nobody gets a point.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/7/2006 9:32:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318113248">message detail</a>
 | #303</td></tr>
<tr class="even">
<td>
Captain Jack Sparrow is correct.<br><br>Then again, when is he ever wrong?<br>---<br>Moltar Status: Excited, the Contest is here at last!<br>Fire Emblem vs. Silent Hill - Bracket: <b>FE</b> - Vote: <b>FE</b> (5/5)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29002092" class="name">THEJackSparrow</a> |
Posted 7/7/2006 9:33:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318113471">message detail</a>
 | #304</td></tr>
<tr class="even">
<td>
Only when I choose to be, mate.<br><br>That is to say, never.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/7/2006 9:48:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318116733">message detail</a>
 | #305</td></tr>
<tr class="even">
<td>
Never...or never <i>again</i>?<br><br><br><br><br><br><br><br><br><br><br>Kuja.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29002092" class="name">THEJackSparrow</a> |
Posted 7/7/2006 9:49:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318116980">message detail</a>
 | #306</td></tr>
<tr class="even">
<td>
Captain Jack Sparrow doesn't fill out brackets, mate. That's why there
hasn't been a perfect one yet. You must have me confused for somebody
else.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=80585&amp;board=8&amp;topic=29002092" class="name">DBZFIGHTERS</a> |
Posted 7/8/2006 12:26:03 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318151961">message detail</a>
 | #307</td></tr>
<tr class="even">
<td>
*cough*<br><br>Halo with over 60% eh.<br><br>---<br>Die hard Cubs, Pistons, Patriot and Maple Leafs fan<br>Owl Squad Member ( �v�( �v� )�v� ) O RLY?</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/8/2006 12:35:33 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318153821">message detail</a>
 | #308</td></tr>
<tr class="even">
<td>
From the way that this is looking, as long as Halo wins, I'll nab
another point. Who knows how strong the swing will be though.....<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29002092" class="name">Lugia2</a> |
Posted 7/8/2006 5:53:44 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318186675">message detail</a>
 | #309</td></tr>
<tr class="even">
<td>
*Bangs head against the wall*<br><br>Forget about the "Over 60%" predictions...My bracket hopes that the King of the Day vote can make it...&gt;_&gt;<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=453709&amp;board=8&amp;topic=29002092" class="name">jonthomson</a> |
Posted 7/8/2006 5:55:22 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318186749">message detail</a>
 | #310</td></tr>
<tr class="even">
<td>
<i>the Crew has Halo winning 9-0</i><br><br>gg, ul<br>---<br>Jon Thomson - CATS, Jay Solano, Ridley, Scorpion, Alien Hominid, Duke Nukem, The Prince, Johnny Rocketfingers, two TBA</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29002092" class="name">Lugia2</a> |
Posted 7/8/2006 6:13:48 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318187207">message detail</a>
 | #311</td></tr>
<tr class="even">
<td>
Castlevania now has a 4000+ lead...it seems to be over<br><br>But, speaking as one who hasn't gotten over the semi-obvious point loss...<br><br>There's still a chance!  Didn't Kuja find his 6000+ lead from a <i>hand?</i>  I mean, if a ****ing hand can defeat a <b>bracket</b>favorite, why not the King of the Day Vote,?<br><br>Yeah, I'm in denial...Still, it's nice to see Alucard's game win...It's only one point.<br><br>I had Halo losing in the next round anyway...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1254692&amp;board=8&amp;topic=29002092" class="name">Mr Lasastryke</a> |
Posted 7/8/2006 6:30:02 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318187645">message detail</a>
 | #312</td></tr>
<tr class="even">
<td>
Yeah, that's the thing... Shake actually convinced me to take Halo over
Kingdom Hearts. This isn't such a big deal for most people who had Halo
losing next round anyway, but for me, it kills my bracket. &gt;_&lt;<br>---<br>stingers135 is the coolest person in existence.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=402049&amp;board=8&amp;topic=29002092" class="name">Zylo the wolf</a> |
Posted 7/8/2006 6:34:04 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318187837">message detail</a>
 | #313</td></tr>
<tr class="even">
<td>
<i>Didn't Kuja find his 6000+ lead from a hand?</i><br><br>Wow Kuja lead gets bigger the older the poll gets. He only had a 400+ lead. Not above 1000.<br><br> <br>---<br>1f u c4n r34d th1s u r34lly n33d t0 g37 l41d</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29002092" class="name">Lugia2</a> |
Posted 7/8/2006 6:50:16 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318188661">message detail</a>
 | #314</td></tr>
<tr class="even">
<td>
Then where in God's name did I read 6000?<br><br>Oh well.  Match is practically over now anyway.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29002092" class="name">UltimaterializerX</a> |
Posted 7/8/2006 12:22:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318224413">message detail</a>
 | #315</td></tr>
<tr class="even">
<td>
WE GOT SERVED.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), FE8, WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/8/2006 12:25:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318224851">message detail</a>
 | #316</td></tr>
<tr class="even">
<td>
7,000 and rising, this is over.<br><br>Halo should cut it down a little later, but it's too late for a full-blown comeback.<br><br>I'm
just shocked Castlevania, a series that never wins the day vote, is
winning it over Halo, which usually dominates the day vote.<br>---<br>Moltar Status: #37 on the Leaderboard<i>!!</i><br>Castlevania vs. Halo - Bracket: <b>Halo</b> - Vote: <b>Halo</b> (6/6)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29002092" class="name">BlAcK TuRtLe</a> |
Posted 7/8/2006 12:27:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318225221">message detail</a>
 | #317</td></tr>
<tr class="even">
<td>
Well, there goes a whole bunch of points for me. I had Halo beating KH ;__;<br><br><br><b>TuRtLe</b><br>~~~<br>Like Darth Maul, the bastard child of Michael Flatley and Hellboy. -trancer1</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2017015&amp;board=8&amp;topic=29002092" class="name">dragonhealer99</a> |
Posted 7/8/2006 12:28:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318225484">message detail</a>
 | #318</td></tr>
<tr class="even">
<td>
I have KH &gt; Halo <br>---<br>____________________<br>Spring Conest 06', Help me win! Vote of Kingdom Hearts Tomarrow!</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/8/2006 12:33:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318226380">message detail</a>
 | #319</td></tr>
<tr class="even">
<td>
lol 68%.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/8/2006 1:58:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318242584">message detail</a>
 | #320</td></tr>
<tr class="even">
<td>
Fire Emblem...................57.05% 57798<br>Silent Hill.........................42.95% 43511<br>TOTAL VOTES.........................101309<br><br>50.65% of the brackets predicted this match correctly.<br><br>Fire
Emblem proves all the doubters wrong and trumphs Silent Hill with ease.
The brackets were pretty split on this match too. I also can't believe
this match drew over 100K votes. Who knew so many people cared?<br><br>Today,
the unthinkable is happening. No, not Halo losing to Castlevania, but
Castlevania actually winning the day vote against Halo. Trust me,
that's completely unexpected.<br><br>HaRRich - 2<br>HM - 2<br>Moltar - 1<br>Soul - 1<br>Ulti - 1<br>Leon - 0<br>Yoblazer - 0<br>Mnm - 0<br>Lopen - 0<br><br>HaRRich wins the point in a close one with Soul.<br>---<br>Moltar Status: #37 on the Leaderboard<i>!!</i><br>Castlevania vs. Halo - Bracket: <b>Halo</b> - Vote: <b>Halo</b> (6/6)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/8/2006 3:36:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318263169">message detail</a>
 | #321</td></tr>
<tr class="even">
<td>
<i>This isn't such a big deal for most people who had Halo losing next round anyway</i><br><br>Actually,
it is. We're almost guaranteed to have a perfect bracket unless
something insane happens, so 1 point loss means either you better have
a really good tiebreaker or hope there aren't multiple perfects.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/8/2006 6:03:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318293095">message detail</a>
 | #322</td></tr>
<tr class="even">
<td>
<b>Snake Division:</b> <i>Round 1 - Match 8</i> &#8211; (2)Kingdom Hearts vs. (7)Harvest Moon <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Kingdom Hearts</b><br>Kingdom
Hearts was a game that pretty much came out of nowhere. Many only saw
it as popular because of the FF cameos, but now with KH2, the series&#8217;
own fanbase has exploded.<br> <br><b>Harvest Moon</b><br>Heh, Harvest
Moon. That farming game according to some people. I&#8217;ve always thought
they were lame *summons flame shield*, but people really like it. A DS
game is on the way.<br><br>Yeah&#8230; I&#8217;m all upset Halo lost and I lost my
perfect bracket and spot on the leaderboard. So, I&#8217;m going to make my
life and your lives easier and have a really short write-up for this
match on why Kingdom Hearts will win<br><br><b>IT&#8217;S KINGDOM F&#8217;N HEARTS</b><br><br>Now
Darkness be with you, and before I go and kill myself over Halo losing,
I urge you to go look at Leon&#8217;s analysis. He actually wrote a Wall for
a match like this! What a loser with no life he must be, mirite? Also
Mnm&#8217;s, it&#8217;s great. Reminds me of my own work in my prime.<br><br><b>Moltar&#8217;s Bracket Says:</b> Kingdom Hearts will win.<br><br><b>Moltar&#8217;s Prediction is:</b> KH: 75% - Harvest Moon: 25%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>I
haven't played any Harvest Moon games. And even if I did, I wouldn't be
silly enough to think it had a chance at winning this given KH2's
recent release.<br><br> Prediction: 76.44% ; even though Harvest Moon
is cult, KH always gets anti-voted in these contests. I'll be shocked
if it manages to break 80%.<br> <br><br><br><b>Soul&#8217;s Analysis</b><br> <br>Umm... Does this match really need an analysis? Harvest Moon fans are thankful that the game got in, and lets leave it at that.<br><br><b>My prediction: Kingdom Hearts wins with 87.88% of the vote.</b><br> <br><br><br><b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Kingdom Hearts<br>Top 100 List comparison:<br>---KH - #16<br>---HM - N/A (had no games on the drop-down list)<br>Best Game Ever x-stat comparison:<br>---KH - 34.7% (was behind Starcraft)<br>---HM - N/A (no rep)<br><br>Hey,
a blow-out -- we haven't seen one of these in...how long? Six days?
Wow, we needed ano--oh, nope, wait, Ulti says we saw a blow-out
yesterday. Nevermind.<br><br>Harvest Moon making it in is...cute, I
guess. It should be "fun" fodder, maybe. I don't know why, really, it
just seems like there's a small clique of people who really enjoy it,
and it's got more potential than Suikoden at least, so...hey, let's
watch it. Meahwhile, I care more about seeing KH kick its ass. I've
never played either series, but I want to see the damage it can dish
out since KH2 is out and is the most recent huge hit on GameFAQs right
now. It needs to really make a point, too, because it should have a
tough second-round match-up.<br><br>Kingdom Hearts wins with 77.12%<br> <br><br><br><b>Lopen&#8217;s Analysis</b><br><br>Harvest
Moon is quite a threat here. Now hear me out&#8230; much like Count Dracula,
the Harvest Moon rises but once every century. Much like the Death, the
main character of these games uses a scythe to harvest. Much like
Castlevania 2: Simon's Quest, the Harvest Moon games feature day <i>and</i>
night. And also, Simon Belmont has a curse and doesn't want to be out
at night&#8230; similarly little Harvest dude he needs his sleep, and *gasps*
<i>also</i> doesn't want to be out at night! But they can both fight it
out if they need to. So you can expect the (possibly disgruntled!)
Castlevania fans of the last match to be backing this one in full
force! Watch out, Kingdom Hearts!<br><br>&#8230; who am I kidding?<br><br><b>Lopen's Prediction:</b> Kingdom Hearts with 79.59%.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/8/2006 6:03:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318293229">message detail</a>
 | #323</td></tr>
<tr class="even">
<td>
<b>HM&#8217;s Analysis</b><br> <br>Ah, yes! One of my favorite series in the
contest against one series that I think is pretty good. Luckily, the
one that is one of my favorite series is the one who will win this
match. Huzzah! <br><br>There is not really much to analyze here, as
most of the 1/8 and 2/7 matches are going to be throughout the entire
contest. Harvest Moon stands practically no chance of doing <i>anything</i>
to even begin threatening Kingdom Hearts here. Kingdom Hearts is going
to be coming off of the huge hit in Kingdom Hearts II &#8211; something that
is dominating the sales charts month after month. I have never noticed
any type of liking for Harvest Moon here at all. The toughest part of
this match is trying to come up with how much Kingdom Hearts is going
to get to win, because it is somewhat hard to gauge how well Harvest
Moon would do. <br><br>But yeah, Kingdom Hearts has Kingdom Hearts,
Kingdom Hearts : Chain of Memories, and the recently released Kingdom
Hearts II on its side. It is pretty much accepted that Kingdom Hearts
was the main factor behind the huge Square boost in 2003, and I think
with KH2 we&#8217;ll see something similar here as well. This is just a
stepping stone for KH until the final showdown with Metal Gear in the
Snake Division. Even the monstrous Halo will end up crumbling before
might of the Keyblade<i>!!</i> Heh.<br><br><b>Aitch Emm&#8217;s Bracket Says :</b> Kingdom Hearts will win.<br><br><b>Aitch Emm&#8217;s Prediction :</b> Kingdom Hearts 84% -- Harvest Moon 16%<br><br><b>Aitch Emm&#8217;s Vote :</b> Kingdom Hearts. <br><br> <br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>As
a big Kingdom Hearts fan, it pains me to say that KH/HM will be
competing with RE/SH for the honor of being the first round's most
uninteresting match. I've spent more time thinking about Madden picture
possibilities than I have about this match.<br><br>We all know who the
winner will be, and, unlike other matches with a decided outcome, there
is nothing which adds even the tiniest bit of flavor to this one. It's
just so... drab. Hell, we can't even use this match to gauge Kingdom
Hearts' strength, since we've never seen Harvest Moon in a contest;
actually, I'm not even sure if it's ever been in a poll, period (no,
those "Which *random month* game are you most looking forward to?"
don't count). To put it bluntly, Kingdom Hearts has two popular games
and a large GameFAQs fanbase. Harvest Moon has nothing. It's tough to
predict the extent of this beating, but KH better lay the smack down if
it wants to look good for its debated second round match.<br><br>Kingdom Hearts<br>+ Much stronger games<br>+ Much stronger contest/poll history<br>+ Actually HAS a contest poll/history<br>- None for this match<br><br>Harvest Moon<br>+ It made the contest<br>+ If it's anything like Animal Crossing, I'd probably love it<br>- It's going to get killed<br><br>My prediction: Kingdom Hearts def. Harvest Moon (81-19)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/8/2006 6:04:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318293327">message detail</a>
 | #324</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>Fresh off the smash hit Kingdom Hearts
II, the series earns itself a 2 seed in the one division it could
actually win. Of course, it&#8217;s got its work cut out just to get to the
divisional finals, but it can be done. However, the one danger is that
Kingdom Hearts has had a tendency to disappoint in the past, but we&#8217;ll
see if it can get past that this time.<br><br>While we&#8217;re at it, let&#8217;s
review that contest history. Otherwise, this is going to be an awfully
short analysis (not as though this match needs one). The first we saw
of anything Kingdom Hearts was Sora in SC2K3 as a 6 seed, facing Aeris
Gainsborough. The match turned out to be the closest we&#8217;ve come to an
exact doubling, with Aeris netting 66.66% of the vote. For some odd
reason, the idea of SFF was disregarded by most, perhaps because people
just assumed Sora wasn&#8217;t very popular anyway (Oh Board 8 and its
differing opinions). That would eventually come back to haunt a lot of
bracket makers, as Sora ended up making the Sweet Sixteen in 2004,
doubling up HK-47 and owning Ryu Hayabusa before bowing out respectably
to a Samus who showed perhaps the most dominance we&#8217;ve ever seen from a
non-Clinkeroth character in one contest (other than perhaps Mario in
2005). That was the one time where it should be considered that Kingdom
Hearts did not disappoint overall expectations.<br><br>In 2005, Kingdom
Hearts nearly faced the ultimate embarrassment. In the Villains
Contest, Ansem was pitted in a match against CATS, the GameFAQs
Contest&#8217;s resident joke character. Although he wasn&#8217;t expected to be
strong, it was thought that he would have little trouble in his first
match. However, Ansem not only struggled mightily, he was <i>losing</i>
to CATS for most of the night. He eventually came back to win, but it
was still a shameful performance. Oddly enough, he still ended up being
the second strongest character in Ganondorf&#8217;s division, which raised a
few eyebrows, but Ansem is still fodder.<br><br>In SC2K5, Riku joined
Sora in the field. The Kingdom Hearts antihero was matched up against
Frog, and most expected nothing out of him (though I will give Lopen a
little credit. He did say Riku would keep it very close). However, once
Frog got past the infamous Chrono Trigger night vote, he found it very
difficult to make any gains on Riku. Although the idea that Frog&#8217;s
four-pack in 2004 was overrated had already been suspected by Liquid&#8217;s
bombing in the Villains Contest, Riku essentially settled it. At first,
Sora appeared to be a little&#8230;off when he failed to destroy Agent 47 as
if he were indeed &#8220;Neo Tanner&#8221; as he had been dubbed before the
contest. But then he breezed by Alucard once morning arrived (a
vampire&#8217;s weakness, so it&#8217;s only natural), and some people believed he
could hang with Solid Snake. Oh how wrong they were. When Snake was
FINALLY FINALLY FINALLY FINALLY on the good side of a one-sided
picture, he beat Sora nearly as badly as Samus had the year before,
leading many people to suspect an overperformance.<br><br>And of
course, there&#8217;s what Kingdom Hearts did in the Games Contest. It needed
a comeback to defeat Soul Calibur, a Dreamcast game, before becoming
the only easy match StarCraft had. While it wasn&#8217;t really weak, Kingdom
Hearts certainly didn&#8217;t do as well as some people (even yours truly,
who had it in the Elite Eight) had hoped. It also did fairly well on
the Top 100 List, placing at 16th overall, but once again, my
overestimation of its popularity ended up costing me. I had every game
on the top 10 there except for GoldenEye, and I had Final Fantasy X in
the last spot for a while, but for some inexplicable reason, changed it
to Kingdom Hearts. While I still won $150 from that contest, I could&#8217;ve
won more if it weren&#8217;t for that meddling Kingdom Hearts and that dog,
too! Err&#8230;wait.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/8/2006 6:05:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318293531">message detail</a>
 | #325</td></tr>
<tr class="even">
<td>
Either way, though Kingdom Hearts COULD once again disappoint in this
contest, it shouldn&#8217;t have any reason to fret against its first round
opponent. Harvest Moon surprised nearly everybody by making the field
at all, so this is definitely a &#8220;We&#8217;re just happy to be here&#8221;
situation. We have virtually no past poll information to work with for
Harvest Moon, but in all likelihood, it&#8217;s going to be very, very weak.
In fact, aside from the series that get SFF&#8217;d, it has a chance of
hitting the very bottom of the Extrapolated Rankings (with Shadow
Hearts and Madden being the main competition). So for you Harvest Moon
fans, enjoy these 24 hours because the odds of ever seeing it again in
any contest are slim. <br><br><i>Leonhart&#8217;s Prediction</i>: <b>Kingdom Hearts with 85.64%</b><br> <br> <br> <br><b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: The 13th Struggle (KH2)<br><br>*KINGDOM HEARTS SPOILERS*<br><br>*A
young boy has inherited his father&#8217;s farm and has been entrusted to
keep up with the daily well being of the farm, live the everyday life
of a farmer, and eventually&#8230; succeed in life! The boy wakes up to his
alarm and to his surprise, there isn&#8217;t sunshine beaming through his
window, but <b>DARKNESS!</b>  The boy rushes outside and notices a dark, cloaked figure wandering in front of the barn*  <br><br>Boy: Wh-Who&#8217;s there?<br>Hooded Man: I&#8217;ve come to see the bracket.<br>Boy: Huh?<br>Hooded Man: This bracket has been connected.<br>Boy: Bracket?  What are you talking about?<br>Hooded Man: Tied to the darkness&#8230; soon to be completely eclipsed.<br>Boy: Well, whoever you are, stop freaking me out like this!  I have animals to tend to&#8230;<br>Hooded Man: You do not yet know what lies beyond the bracket.<br>Boy: So, you&#8217;re from another game!<br>Hooded Man: There is so very much to learn.  You understand so little.<br>Boy:
Oh, yeah? Well, you&#8217;ll see. I&#8217;m gonna get out and learn what&#8217;s out
there! I&#8217;m gonna be a successful farmer and find me a nice girl to
marry!<br>Hooded Man: A meaningless effort.  One who knows nothing can understand nothing.<br>Boy: I think I&#8217;m gonna get out of here&#8230;<br>Hooded
Man: All brackets begin in darkness, and all so end. This farm is no
different. Darkness sprouts within it, grows, consumes it. Such is its
nature. In the end, every farm returns to the darkness whence it came.<br>Boy: Umm&#8230;. Speaking of farms&#8230; I have one to tend to.<br><br>*The
hooded man disappears and sunlight suddenly returns to the farm. The
boy heads to his crops to water them, when suddenly he sees another
hooded figure standing over his crops. He lifts up his hood to reveal&#8230;
a mullet*<br><br>Demyx: Let&#8217;s see here&#8230; &#8220;If the subject fails to
realize that his series is going to get crushed, use aggression to
liberate his true disposition&#8221;&#8230; Right. Did they ever pick the wrong guy
for this one&#8230;<br>Boy: You&#8217;re bizarre&#8230;<br>Demyx (wagging a finger): You shouldn&#8217;t judge anyone by appearance.<br><br>*A
dome of water appears around him, he lifts up his hand, and the water
forms into a sitar. He grabs it spins around, and points at the boy
with a smirk on his face.*<br><br>Demyx: DANCE, WATER! DANCE!<br>*Demyx conjures water creatures.  The creatures all collapse over the crops, watering them thoroughly*<br><br>Boy: Gee, thanks!  You just watered my crops for me!<br>Demyx: I told them they were sending the wrong guy&#8230;<br><br>*Demyx
disappears. Seeing that his crops were already watered for him, the boy
decides to take a break and go fishing. After a few minutes, another
hooded man appears next to him*</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/8/2006 6:05:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318293632">message detail</a>
 | #326</td></tr>
<tr class="even">
<td>
Xaldin: I&#8217;ve come to take something you hold very dear.<br>Boy: Shhhhhh.  Dammit!  I almost had that one hooked!  See what you did??!!<br>Xaldin: Yes.  Let your anger grow.<br>Boy: What do you guys really want?<br>Xaldin: &#8230;to win the match.<br>(Xaldin takes off his hood)<br>Xaldin:
When we win this match, we can exist fully and completely. There is
much more to be conquered! So you see, that&#8217;s why we need you to lose
this match!<br>*The boy hasn&#8217;t heard a word Xaldin has said, as he has been working on reeling in a Big Sharshark*<br>Xaldin: Is this what you do every day?<br>Boy: Yep.<br>Xaldin (is bored): Where&#8217;s the fun in this? <br><br>*Xaldin
disappears. Having pulled in a prize catch, the boy decides to go into
town and make a profit off of it. He notices another dark figure
secluded in an alley. He goes to investigate. The hooded figure takes
off his hood to reveal spiky red hair*<br><br>Axel: Way to fall right into their trap.<br>Boy: What&#8217;s going on?<br>Axel:
C&#8217;mon, it&#8217;s a set-up by GameFAQs. CJayC is using your series to serve
as first round fodder for Kingdom Hearts---that&#8217;s his big master plan.<br>Boy: CJayC?<br>Axel: Yeah, that GameFAQs site. He&#8217;s the leader. C-J-A-Y-C.  Got it memorized? <br>Boy: CJayC wants my series to lose?<br>Axel:
Man, you&#8217;re slow. Every popular series must have fodder served to it in
order to show off its strength as it vouches for the championship.
That&#8217;s what GameFAQs is after.<br>Boy: Wait, so what happens to me after this match?<br>Axel: I&#8217;m not telling.<br>Boy: Tell me!<br>Axel: Look, I&#8217;m sorry. <br><br>*Axel
disappears. Enraged, the boy heads to the town center to get some
answers. There a man appears in a black cloak. He takes his hood off,
revealing his silver hair and orange eyes*<br><br>Mansex: Yes&#8230; Kingdom
Hearts&#8230; Rejoice, and feast on these games we offer! Shine your pale
light on this empty realm. Share your power with all games in the
series!<br><br>*The boy runs up to him*<br><br>Mansex: I was wondering
who would dare interfere with my Kingdom Hearts. And look---here you
are. How convenient for me. Harvest Moon&#8230; you look pathetic.<br>Boy: Have your laugh.  I deserve as much for failing to be a mainstream series.<br>Mansex: Only a fool would limit his appeal to a cult fanbase.<br>Boy:
I admit&#8230; my disregard for the mainstream brought lower sales for my
series. But what were YOU seeking? Taking advantage of fanboys, taking
all of their favorite characters and putting them all in one game just
to create a series with little substance. Is this the answer you&#8217;ve
been looking for?<br>Mansex: All that and more. I&#8217;m marching past what
you represent, and I&#8217;m creating a brand new world where large
corporations can collaborate and create cash cows. And fans would
mindlessly buy into it just because it contains their favorite brand of
characters. And you&#8217;re powerless to control it.<br>Boy: Foolish series
of a foolish company. You&#8217;ve surpassed nothing---only proved how little
you know about the industry. You used to be a <i>good</i> company.
What happened to creating gems like Secret of Mana, Brave Fencer
Musashi, and Parasite Eve? Now you&#8217;ve resorted to creating garbage and
focusing on your mainstream revenue generators, creating the umpteenth
spinoff of Final Fantasy VII, and working on releasing THREE versions
of FFXIII at <i>once</i>. I may not be as popular as you, but at least
I&#8217;ve been loyal to my fans over the years! I&#8217;ve said enough! Halo,
Metal Gear, you know what to do! My fans, my friends, forgive me!
Farewell!<br><br>Bracket: <b>DARKNESS!</b><br>Vote: <b>DARKNESS!</b><br>Prediction: Kingdom Hearts with 81.65%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/8/2006 6:06:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318293818">message detail</a>
 | #327</td></tr>
<tr class="even">
<td>
Crew picks KH 9-0, and unlike today, we won't be wrong!<br><br>Kinda surprising to see a tripling is the lowest pick though...<br>---<br>Moltar Status: #37 on the Leaderboard<i>!!</i><br>Castlevania vs. Halo - Bracket: <b>Halo</b> - Vote: <b>Halo</b> (6/6)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3191556&amp;board=8&amp;topic=29002092" class="name">LegendarySnake</a> |
Posted 7/8/2006 6:11:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318294794">message detail</a>
 | #328</td></tr>
<tr class="even">
<td>
*thumbs up for mnm's analysis*<br><br>Good stuff.<br>---<br>I am the man who makes the impossible possible. I am the man, the legend: Solid Snake!</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/8/2006 7:22:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318309162">message detail</a>
 | #329</td></tr>
<tr class="even">
<td>
You know, if I had picked Castlevania instead of Halo with that percentage, I'd be looking at a sure point right now.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29002092" class="name">Lugia2</a> |
Posted 7/8/2006 8:02:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318317187">message detail</a>
 | #330</td></tr>
<tr class="even">
<td>
Castlevania winning.  Dear lord.  Oh well, at least all of the crew will be losing their perfects a long with me.  <br><br>As
for KH, I finally bought the first one today, a long with We &lt;3
Katamari. It should be nice to play while HM is getting killed.<br><br>I say 75% for KH.  There is NO chance in Heaven, heck, or purgatory that HM is going to pull a Castlevania on us.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=867798&amp;board=8&amp;topic=29002092" class="name">SlikRick</a> |
Posted 7/8/2006 8:34:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318323865">message detail</a>
 | #331</td></tr>
<tr class="even">
<td>
Wow, just checked my bracket. I have Castlevania winning. Man this is great.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/8/2006 8:44:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318325977">message detail</a>
 | #332</td></tr>
<tr class="even">
<td>
Man...I wish I still got some credit for being the lowest predictor for CV/Halo...but <i>c'este la vie</i>.<br><br><br>For
those looking in the 80+% range for Kingdom Hearts tomorrow, expect to
be sorely disappointed. KH was no Metal Gear (even before we saw MG/SC
and CV/Halo), and MG is no LoZ...and I don't think Harvest Moon would
lose to Civilization either, though I wouldn't think there'd be a big
difference between the two. LoZ almost got 90%, and the difference
between LoZ and KH as we should see it now is HUGE.<br><br>I dare say we all over-predicted it.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/8/2006 8:45:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318326168">message detail</a>
 | #333</td></tr>
<tr class="even">
<td>
I'm not so sure I'd take Harvest Moon to beat anything outside of maybe Madden and Shadow Hearts...<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/8/2006 8:54:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318327925">message detail</a>
 | #334</td></tr>
<tr class="even">
<td>
I expect Madden to easily look the worst, then from there, I wouldn't put Civ. or HM too far away from Shadow Hearts.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=640243&amp;board=8&amp;topic=29002092" class="name">Big Bob</a> |
Posted 7/8/2006 8:55:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318328102">message detail</a>
 | #335</td></tr>
<tr class="even">
<td>
It could beat Civilization as well..<br>---<br><a class="linkification-ext" href="http://img.photobucket.com/albums/v674/ImBigBob/PokemonvsMetroid.jpg" title="Linkification: http://img.photobucket.com/albums/v674/ImBigBob/PokemonvsMetroid.jpg">http://img.photobucket.com/albums/v674/ImBigBob/PokemonvsMetroid.jpg</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=154579&amp;board=8&amp;topic=29002092" class="name">DeepHyren12</a> |
Posted 7/8/2006 11:26:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318362420">message detail</a>
 | #336</td></tr>
<tr class="even">
<td>
Mnm fricking wins everything. That was as beautiful as the pac man post
from a couple contests back. Ulti, you need to post that in your end of
year wrap-up.<br>---<br>"Patriotism is clearly the greatest danger to which civilization is at present exposed" --Bertrand Russell</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3292020&amp;board=8&amp;topic=29002092" class="name">LessThan3Presea</a> |
Posted 7/8/2006 11:32:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318363715">message detail</a>
 | #337</td></tr>
<tr class="even">
<td>
I should get half a point for an almost exact percentage but wrong winner...<br>---<br>"A huge void in her heart. It is filled not by darkness, but kindness from others." - Presea Combatir, the Empty Soul</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/9/2006 12:57:51 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318380110">message detail</a>
 | #338</td></tr>
<tr class="even">
<td>
Yeah, and I should get a point for having the lowest prediction for Halo!<br><br>Sucks for us, eh?<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3292020&amp;board=8&amp;topic=29002092" class="name">LessThan3Presea</a> |
Posted 7/9/2006 1:00:07 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318380490">message detail</a>
 | #339</td></tr>
<tr class="even">
<td>
No way. Being the most gutless Halo predictor is not worthy of points!<br>---<br>"A huge void in her heart. It is filled not by darkness, but kindness from others." - Presea Combatir, the Empty Soul</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3292020&amp;board=8&amp;topic=29002092" class="name">LessThan3Presea</a> |
Posted 7/9/2006 1:22:59 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318384132">message detail</a>
 | #340</td></tr>
<tr class="even">
<td>
Moltar, a favor:<br><br>Raise my Sonic/DMC prediction by 5%, please.<br>---<br>"A huge void in her heart. It is filled not by darkness, but kindness from others." - Presea Combatir, the Empty Soul</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29002092" class="name">Lugia2</a> |
Posted 7/9/2006 6:18:41 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318408507">message detail</a>
 | #341</td></tr>
<tr class="even">
<td>
...Is KH losing the day vote?<br><br>I mean, it has ******' Donald Duck in it!<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/9/2006 12:20:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318444116">message detail</a>
 | #342</td></tr>
<tr class="even">
<td>
Castlevania......................55.02% 61073<br>Halo...................................44.98% 49929<br>TOTAL VOTES............................111002<br><br><i>31.49%</i> of the brackets predicted this match correctly.<br><br>Starcraft
overrated Halo by alot apparently, and Halo 2 did nothing for the
series as a whole. We learned that yesterday as Castlevania pulled off
the huge upset in the 2nd lowest predicted Round 1 match of all time.
Castlevania even won the day vote, something SotN and Alucard have
never been able to do. Looks like the handheld games helped more than
we thought.<br><br>Today, KH once again underperforms in Round 1. I wouldn't expect anything more either. CV/KH is looking very interesting now.<br><br>HaRRich - 2<br>HM - 2<br>Moltar - 1<br>Soul - 1<br>Ulti - 1<br>Leon - 0<br>Yoblazer - 0<br>Mnm - 0<br>Lopen - 0<br><br>lol no point<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Kingdom Hearts vs. Harvest Moon - Bracket: <b>KH</b> - Vote: <b>KH</b> (6/7)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/9/2006 12:24:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318444814">message detail</a>
 | #343</td></tr>
<tr class="even">
<td>
<i>Mnm fricking wins everything. That was as beautiful as the pac man post from a couple contests back.</i><br><br>Glad to see I'm not the only one who enjoyed it. And yay for someone remembering my Pac-Man/Ocelot write-up!<br> <br><i>Yeah, and I should get a point for having the lowest prediction for Halo!<br><br>Sucks for us, eh?</i><br><br>Yeah, it does. =P<br> <br><i>Raise my Sonic/DMC prediction by 5%, please.</i><br><br>Done.<br> <br><i>...Is KH losing the day vote?</i><br><br>It's not losing it, just not doing too well with it. I'm not too surprised though.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Kingdom Hearts vs. Harvest Moon - Bracket: <b>KH</b> - Vote: <b>KH</b> (6/7)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29002092" class="name">DaruniaTheGoron</a> |
Posted 7/9/2006 1:05:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318452274">message detail</a>
 | #344</td></tr>
<tr class="even">
<td>
Looks like Moltar wins today.<br>---<br>...little Weezing it's gonna stand up against my ****in' Charizard? Just get back on your bike <br>and keep pretending to be cool with your lame ass mohawk ****er. - phoenix1487 <b><i>Sp2k6: 6/7</i></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/9/2006 1:08:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318452828">message detail</a>
 | #345</td></tr>
<tr class="even">
<td>
<i>I dare say we all over-predicted it.</i><br><br>Nope, I do.<br><br><br><br><br><br>I fully expect a point.  Ahem...pronto.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/9/2006 4:38:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318497442">message detail</a>
 | #346</td></tr>
<tr class="even">
<td>
<b>Mushroom Division:</b> <i>Round 1 - Match 9</i> &#8211; (1)Super Mario Bros. vs. (8)Madden <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Super Mario Bros.</b><br>Super
Mario Bros? What&#8217;s that? Who is this Mario? Wha? You say he&#8217;s been
around for over 20 years now? Still churning them out too with New
Super Mario Bros. for the DS?<br> <br><b>Madden</b><br>Casual fans,
rejoice! Madden makes it the Contest. Barely, that is. It&#8217;s a popular
football series for the 3 of you who don&#8217;t know what Madden is, with
slightly updated versions being released each year.<br><br>So, yeah, I don&#8217;t know what to say about this one&#8230;but I&#8217;ll find something<i>!!</i> <br><br>Madden,
along with GTA and Halo, are probably the biggest franchises with the
casual gamers in the Contest. However, Madden differs from GTA and Halo
because GTA and Halo actually have a fanbase on GameFAQs. GTA is a
strong franchise at GameFAQs (we&#8217;ll see how strong exactly soon), and
Halo, while it lost to Castlevania, is still a strong series. Even
though Madden is untested, odds are it won&#8217;t be anywhere close to the
other two.<br><br>Besides, Super Mario Bros. is part of the GameFAQs
Big 3 along with Legend of Zelda and Final Fantasy, and the GameFAQs
Big 3 &gt; the Casual Big 3. <br><br><b>Moltar&#8217;s Bracket Says:</b> Super Mario Bros. will win.<br><br><b>Moltar&#8217;s Prediction is:</b> SMB: 87% - Madden: 13%<br><br> <br><br><b>Ulti&#8217;s Analysis</b><br> <br>Sports
games get a lot of unfair hate on GameFAQs. Multiplayer sports games
are some of the best experiences I've had in gaming, especially when
Madden finally went online. I'll never forget almost cracking Top 500
in Madden 2004, but I digress. Mario is winning this; the only question
is whether or not this will be the contest's biggest blowout. Madden is
well-known on GameFAQs, but both it and its publisher (EA) are hated to
a sickeningly high degree. Surf some old polls and see for yourself how
bad it is.<br><br>Prediction: Mario with 88.45%; Madden's fanbase MAY keep it above 10%.<br> <br><br><br><b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Super Mario Bros. (and the ESPN NFL 2k series)<br>Top 100 List comparison:<br>---SMB3 - #5, SM64 - #13, SMB - #22, SMW - #23, SMW2:YI - #82<br>---Madden NFL - #91<br>Best Game Ever x-stat comparison:<br>---SMB3 - 39.9% (8 Division champion), SMW - 34.24%, SM64 - 21.93% (SFF'd by LoZ:OoT, has since had SM64DS released)<br>---Madden NFL - N/A (no rep)<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1400" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1400">http://www.gamefaqs.com/poll/index.html?poll=1400</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1490" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1490">http://www.gamefaqs.com/poll/index.html?poll=1490</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1875" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1875">http://www.gamefaqs.com/poll/index.html?poll=1875</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1909" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1909">http://www.gamefaqs.com/poll/index.html?poll=1909</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2141" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2141">http://www.gamefaqs.com/poll/index.html?poll=2141</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2251" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2251">http://www.gamefaqs.com/poll/index.html?poll=2251</a><br>#5+#13+#22+#23+#82 &gt; #91<br><br><a class="linkification-ext" href="http://wonka.ytmnd.com/" title="Linkification: http://wonka.ytmnd.com/">http://wonka.ytmnd.com/</a><br><br>Super Mario Bros. wins with 99.99% (though Madden will get the first vote)<br> <br><br><br><b>Lopen&#8217;s Analysis</b><br> <br>Now <i>correct me if I'm wrong</i> but I <i>think</i>
the Madden series has something to do with Football. I've got a lot of
knowledge, I know. Okay, okay&#8230; it's real popular sport, right? As such,
it's a big threat, right? Well, just trust me when I say this&#8230; there's
a poll out there, and it says 90% of GameFAQs doesn't give a flying
field goal about Football. There goes the chances of Madden taking this
match with just one poll. Oh yeah, maybe&#8230; but what about the foot care
fanatics on GameFAQs? Never underestimate the power of (BOOM!) Tough
Actin' Tinactin fanboys en masse. But man, even then&#8230; Mario was doing
the foot care thing before it was cool. Remember Kuribo's Shoe?
Footcare Fanbase Factor? <i>Indeed&#8230;</i><br><br><b>Lopen's Prediction:</b> Super Mario Brothers with 85.11%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/9/2006 4:39:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318497581">message detail</a>
 | #347</td></tr>
<tr class="even">
<td>
<b>Soul&#8217;s Analysis</b><br> <br>LOL Chuck.<br><br>Mario starts this
contest with a very easy first round match. Madden is a cash grabber
for sure, but that means nothing in these contests. Mario is top 3.
Madden will probably be bottom 3. Sports games are not a loved genre on
GameFAQs. And... that's about it. I'll let the stats guys give you the
longer analysis.<br><br><b>My prediction: SMB wins with 89.53% of the vote.</b><br> <br> <br> <br><b>HM&#8217;s Analysis</b><br> <br>Oh, <i>man</i>
does this match hurt. In most of the other blowout matches, I have
never really cared for the game that was getting dominated &#8230; but I <i>love</i>
Madden. Yes, I&#8217;m one of those who go out every year and picks up the
next installment of Madden, if only for the updated rosters and
graphics &#8211; what more do you need from a football game? This one is
going to be just plain ugly, and it hurts because of that. <br><br>We
all know that Super Mario Bros. is one of three absolute dominative
series here on GameFAQs. The Big Three (Final Fantasy, The Legend of
Zelda, and Super Mario Bros.) are going to be so far ahead of the rest
of the competition it won&#8217;t even be funny. Even the fourth strongest
contender (I&#8217;m looking at you to come through, Metal Gear!) won&#8217;t even
be within reach of these guys, so you can understand how rough
something like <i>Madden NFL</i> has it. <br><br>It is pretty apparent
that the visitors of GameFAQs are not the biggest fans of sports &#8211;
losers, I say! &#8211; and if they aren&#8217;t a fan, it&#8217;s likely they don&#8217;t care
one bit about virtually playing a sport they don&#8217;t care for, unless it
is radically different from the respective sport. A good case of this
might be the Mario sports games or whatever. Attach Mario to it, make
it all arcade style, and GameFAQs is likely to care more by a multiple
of ten. Still, even then the game wouldn&#8217;t be strong. Yeah &#8230; it&#8217;s just
really rough. I would suspect that we see the largest blowout of the
contest here. Me? I&#8217;ll be crying the entire day it happens. I love
Mario, but I also love Madden &#8211; why can&#8217;t we get, like, 60 &#8211; 40?! <br><br>In
truth, I could have had this entire analysis completed with just one
link, but I wanted to go ahead and cover some things about the match.
Anyway &#8230;<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2141" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2141">http://www.gamefaqs.com/poll/index.html?poll=2141</a><br><br>See
that? A whomping 10% of the GameFAQs voters in that poll went out to go
and get Madden. There is one &#8220;Yes&#8221; option and four &#8220;No&#8221; options, which
just goes to show how even CJayC knows the people of GameFAQs aren&#8217;t
big fans of football. I have a feeling that the 10% who voted there
will likely transfer into the actual percentage of the match, giving
Super Mario Bros. the biggest blowout of the contest. Just for good
measure &#8230;<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1688" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1688">http://www.gamefaqs.com/poll/index.html?poll=1688</a><br><br>Yeah.<br><br><b>Aitch Emm&#8217;s Bracket Says :</b> Super Mario Bros. will win.<br><br><b>Aitch Emm&#8217;s Prediction :</b> Super Mario Bros. 90% -- Madden NFL 10%<br><br><b>Aitch Emm&#8217;s Vote :</b> Madden NFL</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/9/2006 4:40:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318497904">message detail</a>
 | #348</td></tr>
<tr class="even">
<td>
<b>Yoblazer&#8217;s Analysis</b><br> <br>Don't be fooled. This match is about
one thing and one thing only: Madden NFL's picture. Needless to say, if
John Madden's studdly face is not present on gameday, I will be mighty
upset at old CJayC. Will we have smiling Madden? Smiling Madden holding
a football? How about smiling Madden holding a box of Tinactin? Maybe
we'll get thrown for a complete loop and have a photoshopped pic of
smiling Madden holding a big turkey leg!! Just thinking about it is
making my head spin; the possibilities are truly endless.<br><br>Now,
let's begrudgingly get to the match, which takes a long back seat
behind the coach's ruggedly handsome portrait. Sadly, past polls have
proven that over half of our voting pool are too stupid to care about
American football.<br><br>Encroachment: GameFAQs's dumbass voters. Five percent swing. Still 95-5.<br><br>Are
the rules too complicated for ya, tubbies? Worse yet, only a small
percentage of the ones that do actually play and enjoy Madden NFL.<br><br>Pass
interference: Those idiots voting on GameFAQs. Ball will be placed at
the spot of the foul (10% down the field). Still 85-15.<br><br>Unfortunately
for Big John, my pockets aren't deep enough to bribe the refs any
further (can you spare a few bucks, Pittsburgh?). Mario has far too
much going for him for this match to be anything other than a huge
blowout. There are several reasons why 99% of the board believes Super
Mario Bros. will easily be the third strongest series in this contest.
It is the most recognized series of all time. Not only does it have
several games, but it has several <i>popular</i> games. From the
twenty-something-year-olds who grew up with the original Super Mario
Bros., to the young teens who were first captivated by Super Mario 64,
this series has established some emotional connection with an
overwhelming majority of GameFAQs voters. Everyone here has played it.
Nearly everyone here has enjoyed it in one way or another. It will
demolish everything in its path before meeting a wall in Final Fantasy.<br><br>Super Mario Bros.<br>+ Several games from which to draw popularity<br>+ Most of those games are pretty damn strong in their own right<br>+ Most recognized series in gaming history<br>+ NintendoFAQs<br>- If the picture features Mario holding a mushroom and John Madden spraying it with Tinactin, we are all screwed<br><br>Madden NFL<br>+ BOOM! Tough Actin' Tinactin!<br>+ BOOM! Six-legged turkey on Thanksgiving!<br>+ BOOM! Coached the Oakland Raiders to the Super Bowl XI crown!<br>- Are you nuts? NOTHING.<br><br>My prediction: Super Mario Bros. def. Madden NFL (85-15)<br> <br><br><br><b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: SMB3 Boss Music (Super Mario All-Stars version)<br><br>Okay,
after that last write-up, I won&#8217;t waste much time with this one. I&#8217;ll
leave that to other people. &lt;_&lt; Super Mario Bros. has its eyes
set on Final Fantasy in a matchup that will be a preview to the final,
just as Bowser got the first dibs on Sephiroth before Ganon got to
prove his strength. The question that comes to mind with SMB will be
how strong is it compared to the Zelda series. But I&#8217;ll save my actual
analysis of the Mario series for a later round, since it&#8217;s only going
up against Madden this round.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/9/2006 4:41:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318498177">message detail</a>
 | #349</td></tr>
<tr class="even">
<td>
Ah, Madden. How the times have changed. During the SNES/Genesis, you
were adored as the hottest football game in town. You took the torch
from Tecmo Bowl and flourished as John Madden spit his corny
one-liners. The &#8220;BOOMs&#8221; and the &#8220;POWs&#8221; slowly crept across the nation.
And then you took your series on to the Playstation, where you played a
strong part in Sony&#8217;s push to overtake the gaming industry. Your games
thrived as more and more people juked left and juked right with the L
and R buttons, one of the most broken maneuvers in all of football
video games. You moved on to the PS2, becoming more expansive than
ever. GM mode, franchise mode, mini-camps, rookie scouting, you had
everything you could want out of a football game. But then something
happened. Suddenly your parent company decided to become king and buy
up every franchise it could. Movies, Marvel, Sports, EA started to take
over everything. And with each passing moment, the industry began to
turn its back. And suddenly, there was EA&#8217;s exclusive takeover of the
NFL. Suddenly Madden became the face of everything there was to hate
about EA.<br><br>So today, the series suffers.  Sure, it still has <i>plenty</i>
of fans. But on a site like GameFAQs, which isn&#8217;t really big on sports
anyways, it is hated with a passion. Sure there are plenty of people
that still like Madden on GameFAQs. But there are even more who will
probably anti-vote the game at will. And then with the fact that Madden
is going up against <i>Mario</i>, the godfather of gaming, look for Madden to get creamed.<br><br>Bracket: Super Mario Bros.<br>Vote: Super Mario Bros.<br>Prediction: 88.23%<br><br> <br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Now <i>correct me if I'm wrong</i> but I <i>think</i>
the Madden series has something to do with Football. I've got a lot of
knowledge, I know. Okay, okay&#8230; it's real popular sport, right? As such,
it's a big threat, right? Well, just trust me when I say this&#8230; there's
a poll out there, and it says 90% of GameFAQs doesn't give a flying
field goal about Football. There goes the chances of Madden taking this
match with just one poll. Oh yeah, maybe&#8230; but what about the foot care
fanatics on GameFAQs? Never underestimate the power of (BOOM!) Tough
Actin' Tinactin fanboys en masse. But man, even then&#8230; Mario was doing
the foot care thing before it was cool. Remember Kuribo's Shoe?
Footcare Fanbase Factor? <i>Indeed&#8230;</i><br><br><b>Lopen's Prediction:</b> Super Mario Brothers with 85.11%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/9/2006 4:42:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318498502">message detail</a>
 | #350</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>Really, man, this match is all a matter
of knowing your roots. Super Mario Brothers games went out of style a
long time ago. Who really cares about them anymore, right? In fact,
Nintendo&#8217;s fallen off the edge of the map. Dead last in console sales,
it&#8217;s a dying breed. The company has just lost touch with the average
gamer and almost intentionally seems to try to appeal to the kiddy
demographic. It&#8217;s like they&#8217;ve accepted defeat and are just trying to
get what they can before they fold. Poor Nintendo. You were awesome
when I was a kid, but things sure have changed since then. It ain&#8217;t
what it used to be. There hasn&#8217;t been a decent Mario game in a decade,
so you&#8217;re basically getting to the point where a lot of people haven&#8217;t
even PLAYED a Mario game before. Never thought I&#8217;d say that growing up,
but it&#8217;s getting that way. <br><br>Now Madden on the other hand, here
is a franchise that has been churning out successful games for around
15 years now. That is what I call consistent strength. Even when they
hardly offer anything new at all, you can still expect to see a new
Madden sell millions, and it&#8217;s released on all major consoles, unlike
the Nintendo-exclusive Mario games. You just can&#8217;t expect many
franchises to stand up to that kind of selling power. In fact, I&#8217;m
convinced that CJayC just made a typo and Madden is supposed to be the
1 seed here. It&#8217;s got to be considered one of the favorites to take
this contest, and with all of the history working against Mario, I&#8217;m
surprised it made it into the contest at all. As a matter of fact, I&#8217;m
not even going to waste my breath doing any more analysis on such an
obvious match, so I&#8217;m going to hand the rest of this write-up over to
my good friend, John Madden to let you know how the match will go down.</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">1</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=1">2</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=2">3</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=3">4</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=4">5</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=5">6</a></li>
<li>      7</li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=7">8</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=8">9</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=9">10</a></li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage7_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29002092&amp;page=6" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage7_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>