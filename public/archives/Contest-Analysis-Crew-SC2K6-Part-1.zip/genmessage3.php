<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><title>GameFAQs: Message List</title>

<link rel="stylesheet" type="text/css" href="genmessage3_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage3_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage3_files/bc.css"></head><body linkifytime="251" linkified="4" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage3_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage3_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29002092%26page%3D2"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage3_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div><a href="http://adlog.com.com/adlog/c/r=10153&amp;s=657805&amp;t=2006.07.11.19.55.20&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=01c17-gne-ad644AD546D2000A25/http://www.gamespot.com/pc/sports/probassfishing2003/index.html?q=pro%20bass" target="_blank"><img src="genmessage3_files/probass_leader.gif" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage3_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29002092&amp;page=2">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29002092" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">First
          Page</a> |
          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=1">Previous
          Page</a> |
          Page 3 of 10          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=3">Next
          Page</a>
          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=9">Last
          Page</a>
      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=596170&amp;board=8&amp;topic=29002092" class="name">SurfingVaporeon</a> |
Posted 7/2/2006 7:36:38 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316793261">message detail</a>
 | #101</td></tr>
<tr class="even">
<td>
TAGZ0RZ!!11<br>---<br><b>QUEM TUNG� MINHA COCA?</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29002092" class="name">UltimaterializerX</a> |
Posted 7/2/2006 7:38:13 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316793343">message detail</a>
 | #102</td></tr>
<tr class="even">
<td>
Zelda not quite being able to hit 90% looks great for my writeup. Looks
like only Lopen's pick can challenge mine, unless Zelda explodes in the
rest of the match.<br><br><i>Aitch Emm&#8217;s Prediction : The Legend of Zelda 84% -- Civilization 12%</i><br><br>That only adds up to 96% &gt;_&gt;<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), FE8, WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/2/2006 10:42:09 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316809381">message detail</a>
 | #103</td></tr>
<tr class="even">
<td>
Hey, Ulti, take your math out of here!<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/2/2006 10:47:10 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316810029">message detail</a>
 | #104</td></tr>
<tr class="even">
<td>
Suikoden/MMX write-ups a bit later<br><br>And Civ's awesome day vote will DEFINITELY push Zelda down to 86%. &lt;.&lt;<br>---<br>Moltar Status: Excited, the Contest is here at last!<br>LoZ vs. Civilization - Bracket: <b>LoZ</b> - Vote: <b>LoZ</b> (0/0)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/2/2006 12:49:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316828378">message detail</a>
 | #105</td></tr>
<tr class="even">
<td>
Nice prediction Ulti. <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br><i>^5 SOWL IMHO</i> - Explicit Content</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/2/2006 3:31:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316857845">message detail</a>
 | #106</td></tr>
<tr class="even">
<td>
<i>That only adds up to 96% &gt;_&gt;</i><br><br>You just proved you haven't read this topic, heh.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29002092" class="name">UltimaterializerX</a> |
Posted 7/2/2006 4:21:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316867469">message detail</a>
 | #107</td></tr>
<tr class="even">
<td>
<i><b>From XxSoulxX Posted 7/2/2006 1:49:14 PM #105</b></i><br><i>Nice prediction Ulti. </i><br><br>Eh, you win this one if Zelda breaks 90, which it's on track to do.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), FE8, WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/2/2006 4:50:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316872849">message detail</a>
 | #108</td></tr>
<tr class="even">
<td>
You know, with the match pics being character based, I may have to
change a few of my prediction percentages.... Combined with the high
vote totals, I think X may beat Suikoden worse than I thought.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29002092" class="name">BlAcK TuRtLe</a> |
Posted 7/2/2006 4:58:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316874355">message detail</a>
 | #109</td></tr>
<tr class="even">
<td>
I wonder if the night vote will favour the more cult, mature Civ series.<br><br><br><b>TuRtLe</b><br>~~~<br>Like Darth Maul, the bastard child of Michael Flatley and Hellboy. -trancer1</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1474778&amp;board=8&amp;topic=29002092" class="name">Dawodieiam75</a> |
Posted 7/2/2006 5:12:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316877037">message detail</a>
 | #110</td></tr>
<tr class="even">
<td>
man, this looks to be quite an interesting contest...<br><br>...boy did I choose an awesome time to return from my 2 year hiatus!<br>---<br>If
you fail to answer all of the questions correctly, you will be referred
to as "BumBumDoodleDum the 00ber n00b" and will be treated accordingly.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1474778&amp;board=8&amp;topic=29002092" class="name">Dawodieiam75</a> |
Posted 7/2/2006 5:13:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316877238">message detail</a>
 | #111</td></tr>
<tr class="even">
<td>
oh yeah, just for a little two cents value...i think tomm. will be MMX with 63.73%<br>---<br>If
you fail to answer all of the questions correctly, you will be referred
to as "BumBumDoodleDum the 00ber n00b" and will be treated accordingly.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=965303&amp;board=8&amp;topic=29002092" class="name">SephirothG</a> |
Posted 7/2/2006 5:35:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316881336">message detail</a>
 | #112</td></tr>
<tr class="even">
<td>
Damn this topic is flying this year!<br>---<br>[Something clever was here before the sig wipe]<br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=453709&amp;board=8&amp;topic=29002092" class="name">jonthomson</a> |
Posted 7/2/2006 5:37:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316881678">message detail</a>
 | #113</td></tr>
<tr class="even">
<td>
Will be interesting to see tomorrow's numbers...<br>---<br>Jon Thomson - CATS, Jay Solano, Ridley, Scorpion, Alien Hominid, Duke Nukem, The Prince, Johnny Rocketfingers, two TBA</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29002092" class="name">UltimaterializerX</a> |
Posted 7/2/2006 5:38:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316881801">message detail</a>
 | #114</td></tr>
<tr class="even">
<td>
<i><b>From BlAcK TuRtLe Posted 7/2/2006 5:58:46 PM #109</b></i><br><i>I wonder if the night vote will favour the more cult, mature Civ series.<br><br><br><b>TuRtLe</b></i><br><br>What would you know about gauging the maturity of anything?<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), FE8, WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3489629&amp;board=8&amp;topic=29002092" class="name">TransgenderLove</a> |
Posted 7/2/2006 5:39:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316882059">message detail</a>
 | #115</td></tr>
<tr class="even">
<td>
<i>Zing!</i><br><br>---<br><b>Explicit Content</b><br>Cheer Up Trannys.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=80585&amp;board=8&amp;topic=29002092" class="name">DBZFIGHTERS</a> |
Posted 7/2/2006 5:41:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316882316">message detail</a>
 | #116</td></tr>
<tr class="even">
<td>
Shhhh.<br><br>---<br>Die hard Cubs, Pistons, Patriot and Maple Leafs fan<br>Owl Squad Member ( �v�( �v� )�v� ) O RLY?</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1474778&amp;board=8&amp;topic=29002092" class="name">Dawodieiam75</a> |
Posted 7/2/2006 5:42:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316882492">message detail</a>
 | #117</td></tr>
<tr class="even">
<td>
<i>From BlAcK TuRtLe Posted 7/2/2006 5:58:46 PM #109<br>I wonder if the night vote will favour the more cult, mature Civ series.<br><br><br>TuRtLe</i><br><br>i dont think any kind of favoring matters at this point...just saying...<br><br>---<br>If
you fail to answer all of the questions correctly, you will be referred
to as "BumBumDoodleDum the 00ber n00b" and will be treated accordingly.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=722305&amp;board=8&amp;topic=29002092" class="name">Dilated Chemist</a> |
Posted 7/2/2006 5:42:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316882556">message detail</a>
 | #118</td></tr>
<tr class="even">
<td>
Say my name, Leon! Say my name!<br><br>---<br><b>=DC=</b><br>Chemistry
can be a good and bad thing. Chemistry is good when you make love with
it. Chemistry is bad when you make crack with it.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/2/2006 5:44:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316882848">message detail</a>
 | #119</td></tr>
<tr class="even">
<td>
<b>Hyrule Division:</b> <i>Round 1 - Match 2</i> &#8211; (4)Suikoden vs. (5)Mega Man X <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Suikoden</b><br>Hey,
Suikoden, interesting to see you appear here again. And with a 4 seed
to boot too! Impressive. The latest in the series is Suikoden V.<br> <br><b>Mega Man X</b><br>Ahh,
the long-neglected X series. Many find it better than Classic Mega Man,
so good to see it finally getting its time in the light. MMX8 is the
most recent.<br><br>On one hand, we have a pretty much cult-RPG series,
and on the other, Mega Man X. Yeah, this isn&#8217;t a very good seeding
trap. Casuals aren&#8217;t going to fall for this. How did Suikoden get such
a high seed anyway? Look at the other 4 seeds, Fire Emblem, Mega Man,
GTA. Even Fire Emblem would probably beat Suikoden, as would all the 5
seeds, Silent Hill, Mario Kart, and Warcraft.<br><br>Oh well, it should
please all 4 of the Suikoden fans to see it seeded so high, but MMX is
going to destroy it. MMX is arguably more popular than the Classic
series. We&#8217;ve seen how Mega Man does in these Contests, and unlike a
lot of other characters, Mega Man only has his games to draw his
strength from. What does that mean? Well, Mega Man the series and Mega
Man the character shouldn&#8217;t be that far from each other in strength.
Now, MMX will probably end up looking a lot weaker because of what it
faces next round, but eh. Enjoy it while it lasts.<br><br><b>Moltar&#8217;s Bracket Says:</b> Mega Man X will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Suikoden: 25% - MMX: 75%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>MMX
is an oddball. A recent "favorite Mega Man series" poll asked what the
best MM series was. MMX surprisingly beat the original with ease, yet
few people will try saying that MMX will have more contest strength
than Mega Man. I think.<br><br>Anyway, the second match of this contest
is another no-brainer. MMX might perform below the rather high
expectations, but it doesn't exactly matter given how easy MMX's path
is to predict in this. Zelda &gt; MMX SFF, here we come. As for
Suikoden, I doubt even the recent release of 5 will stop the series
from getting its ass whipped. It's simply too cult.<br><br>Prediction: Mega Man X with 74.24%<br> <br><br><br><b>Soul&#8217;s Analysis</b><br> <br>Another
predictable winner in this one. MMX is the clear cut favorite here. I'm
predicting somewhere around low 70s/high 60s simply because Suikoden is
a very obscure series.<br><br>Hmm... what to do now. I could talk about
this match some more, but what else needs to be said? MMX has a chance
to be strong, Suikoden does not. Simple?<br><br><i>My Prediction: MMX wins with 68.93% of the vote. Sadly, that's as far as MM is going to go this year)</i><br> <br><br><br><b>Lopen&#8217;s Analysis</b><br> <br>Man,
I don't want to sound overconfident here, but the way I see it, this is
a 1v8 match in a sneaky 4v5 costume. I have to admit, though, it's a
pretty convincing costume. Some people even took Suikoden to win this
one! Now, rather than just say they're wrong, as satisfying as that is,
I'd rather explain why they're wrong. Three reasons (don't worry,
they're good!):<br><br>1. How many games has the Suikoden series sold
total? Correct me if I'm wrong but I think they cracked their sixth
dozen with the recent Suikoden 5.<br><br>2. How well has Suikoden done
in this contest so far? Not so good&#8230; really not so good. Alright, how
not so good, you ask? Well I'm sure one of my coanalyzers will no doubt
be bringing up Luca's and Suikoden 2's beautiful polls, so I'll just
say this: This could be Suikoden vs. X, and you know what? I'd be
putting X in my bracket, because those X-Treme sports fans would surely
propel X to victory!<br><br>3. Whoa whoa whoa&#8230; it's <i>Mega Man</i> X?!<br><br>Riiight. I love you, Suikoden&#8230; you've got my pity vote, but you haven't really got a chance. I'm... sorry.<br><br><b>Lopen's Prediction:</b> Mega Man X with 81.56%.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/2/2006 5:44:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316883039">message detail</a>
 | #120</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>Suikoden actually got the higher seed,
eh? Well, it makes sense. The last time we saw a Suikoden
representative, Luca Blight was the 4 seed facing off against Albert
Wesker in last year&#8217;s Villains Contest. I mean, we already know the
series is weak, but let&#8217;s review its contest history, shall we?<br><br>Spring
Contest 2004, Suikoden II is the first sacrificial lamb for Final
Fantasy VII. It fails to break even 15% in the match, but we&#8217;ll cut it
some slack. It only faced the most popular game on GameFAQs. I mean, it
ranked 47th out of 64 games in the stats (above even <b>Metal Gear?!</b>), so that&#8217;s not TOO shabby. Still fodder, but not a bottom feeder, at least.<br><br>Suikoden
keeps rolling along and sends Luca Blight into Summer Contest 2004 as
an 11 seed against Magus. He only gets around 19%, but come on&#8230;Magus is
practically on the level of the Noble Nine, right? That&#8217;s forgivable.
He makes a repeat appearance in the 2005 Villains Contest, facing off
against the main villain of the very popular Resident Evil series,
Albert Wesker. Luca surprises nearly everyone by breaking 40% in that
match. Wow! Pretty impressive, right? But then Wesker fails to get even
30% against Kefka, a very low tier character. So much for that&#8230;And
then, to top it all off, Magus gets exposed as a fraud against
Knuckles, making Luca Blight look even <i>weaker</i> than he already did. Basically, just when it seemed it couldn&#8217;t get any worse&#8230;it did.<br><br>Now
here is the entire Suikoden series rolled into one facing off against
the Mega Man X series. I spent all that time reviewing its contest
history to say this&#8230;It doesn&#8217;t stand a chance. In fact, its odds of
victory are the equivalent to the name of its opponent&#8217;s most popular
character: Zero. If there is a dictionary ANYWHERE with the word &#8220;Cult
RPG&#8221; in it, I&#8217;d bet good money that there&#8217;s a picture of a Suikoden
game (or at least it would be mentioned as an example) somewhere
nearby. There are some people who even believe Mega Man X can be
stronger than Mega Man Classic (there&#8217;s a favorite Mega Man series poll
that MMX won as evidence of this). Heck, it doesn&#8217;t really matter what
incarnation of Mega Man you throw Suikoden against, it wouldn&#8217;t win.
The series has a hardcore (and I mean hardcore) following, but it&#8217;s
just not big enough to matter against virtually ANYTHING, much less a
big name like Mega Man. However, I&#8217;ll give it enough credit to manage
to avoid getting completely destroyed here.<br><br><i>Leonhart&#8217;s Prediction:</i> <b>Mega Man X with 71.90%</b><br> <br><br><br><b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Mega Man X<br>Top 100 List comparison:<br>---N/A (neither series had games on the drop-down list)<br>Best Game Ever x-stat comparison:<br>---Suikoden 2 - 14.37% (may have been SFF'd by FF7)<br>---MMX - N/A (no rep)<br><br>You
know what's great about this match? MMX wins. You know what's horrible
about this match? It's another blow-out. You know what justifies that
though? MMX wins.<br><br>Seriously though, we have another
not-so-entertaining match, though it could prove interesting when we
can compare MMX to Mega Man later in the contest. Until then...I mean,
we've seen Mega Man be a Final Four character three times, Zero get
47+% on Sonic in 2003 whereas Luca Blight <i>almost</i> got 19% on
Magus in 2004, and Sigma is expected to get 64.04% on Luca Blight
according to the Villain Contest's stats. It also doesn't hurt that Dr.
Wily was in the top quarter of villains in the Villain Contest, nor
does it hurt that Protoman is right at the fodder-line despite being
potentially SFF'd. I'm still surprised that Suikoden is "seeded" higher
though -- I know we don't see the numbers this time, but think about
the way they should go (1/8, 4/5, 3/6, 2/7) for every division, and it
fits decently for the most part. This though...bah. A sign, perhaps?
Not at all, watch.<br><br>Mega Man X wins with 73.12%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/2/2006 5:45:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316883166">message detail</a>
 | #121</td></tr>
<tr class="even">
<td>
<b>HM&#8217;s Analysis</b><br> <br><i>Finally</i>, we get to see Mega Man X
in some form in one of these contests. CJayC always grouped &#8220;Mega Man&#8221;
and &#8220;X&#8221; together in the character contests, but it looks like there was
enough of a backing to get both Mega Man and Mega Man X into this
series contest. It is kind of unfortunate it got put into a position
where it is one and out though. I think Mega Man X could have done some
real damage in other places, but I suppose one can&#8217;t expect a perfect
bracket.<br><br>Anyway, we have Suikoden perform in the contest before,
and it was incredibly weak to say the least. Granted, it was against
Final Fantasy VII, the strongest game on this site, but it still
doesn&#8217;t look like it has much of a fanbase at this site, despite being
an RPG. One could probably blame Konami for some shipping issues and
not enough advertising because you would figure a company as big as
them would be able to get an RPG series like that to catch on. In any
case, it&#8217;s clear that fanbase here, while dedicated, it incredibly
small and isn&#8217;t going to be saving it from suffering a massive blowout
at the hands of Mega Man X &#8211; something the Blue Bomber loves to do to
fodder.<br><br>It&#8217;s a bit disappointing considering the quality of the
Suikoden series, but that&#8217;s just how things go. Interestingly, I think
this match will have a blowout similar to that of The Legend of Zelda,
which may seem a bit weird at first, but I think Civilization would be
able to handle Suikoden without too much trouble. Of course, even with
a comparable blowout, Mega Man X stands no real shot at a powerhouse
like Zelda, though its performance should be respectable. <br><br>So yeah, Mega Man X wins this one without any trouble at all. <br><br><b>Aitch Emm&#8217;s Bracket Says :</b> Mega Man X will win.<br><br><b>Aitch Emm&#8217;s Prediction :</b> Mega Man X 85% -- Suikoden 18%<br><br><b>Aitch Emm&#8217;s Vote :</b> Mega Man X<br> <br><br><br><b>Yoblazer&#8217;s Analysis</b><br> <br>You
know, 4/5 matches aren't supposed to be like this. They're supposed to
be competitive. They're supposed to be filled to the brim with
uncertainty. They're supposed to have us clawing at each other's
throats, looking for something, <i>anything</i>, that distinguishes
itself as proof good enough from which to base our decisions. We should
get good matches. We should NOT get 80/20 bloodbaths.<br><br>Unfortunately,
that's what we're going to get. Suikoden is a very cult series with a
small, highly devoted fanbase. There are a very concentrated group of
fans who will vote Suikoden over their own mothers, and they seem to
show up in every poll which features the series. Sadly, that's about
all it has. Mega Man X is a very respected series spanning two of the
most popular consoles in history. It carries the Mega Man name, which
might not be as big a deal for the other MM in the contest, but should
help immensely against fodder of this craptitude. Voters who don't care
about either series will probably vote for the one they've heard of,
and EVERYONE has heard of Mega Man. It's an open and shut case. Mega
Man X gets the honor of being Zelda's second sacrificial lamb, while
Suikoden battles Star Ocean for last place on the Extrapolated
Standings.<br><br>Suikoden<br>+ Actually got a decent seed<br>+ Incredibly devoted fanbase<br>- That fanbase is very, very small<br>- It's going to get killed<br><br>Mega Man X<br>+ Situated on arguably the two most popular consoles of all time<br>+ Large number of games<br>+ Mega Man name<br>+ Known for blowing up fodder<br>- Zelda will SFF it in Round 2; such a shame<br><br>My prediction: Mega Man X def. Suikoden (83-17)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/2/2006 5:46:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316883410">message detail</a>
 | #122</td></tr>
<tr class="even">
<td>
<b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: Double (MMX4)<br><br><b><i>FINALLY!!!</i></b>
After years and years of fans of the X series demanding that Mega Man
be represented by X pictures in the character contest, Ceej finally
sticks Mega Man X in a contest as a stand alone series! Unfortunately,
the X series was placed in a lackluster bracket position, having its
path already set. It goes through a snorefest against Suikoden before
being sacrificed to Zelda. Nonetheless, at least X will look good in
blowing out cult favorite Suikoden! <br><br>The X series has proven to
be the most popular Mega Man series, as shown by the Mega Man favorites
poll. However, the poll also shows that there is a <i>huge</i> split
between the Classic Mega Man series and the Mega Man X series. What&#8217;s
even more surprising is that before MMXC was released, I noticed there
were many people who hadn&#8217;t even <i>played</i> a Mega Man X game. It&#8217;s
surprising to me because the X series was basically the SNES extension
of the Mega Man series. There was Super Mario World for Mario, A Link
to the Past for Zelda, Super Metroid for Metroid, and Mega Man X for
Mega Man. You would think that every fan of the NES Mega Man games
would go grab MMX, especially seeing that MM7 wasn&#8217;t even released
until 2 years <i>after</i> MMX. Still, MMX is still a pretty popular
franchise on this site, as is evident by Zero&#8217;s popularity in the
character contest. Of course, this doesn&#8217;t mean that MMX will equal
Zero&#8217;s character strength. Games are a whole different ballgame than
characters, and even though the X games have some popularity, I
wouldn&#8217;t even put them <i>near</i> the popularity level of a Mario,
Zelda, Chrono Trigger, etc. And since the SNES days, the popularity of
the series has declined.<br><br>It won&#8217;t matter though because it&#8217;s up
against Suikoden, the very definition of cult RPGs. We&#8217;ve seen Suikoden
represented in these contests in a couple of instances. Luca Blight has
been in 2 character contests, where he&#8217;s shown to be supreme fodder.
Suikoden 2 went up against the FFVII juggernaut and nabbed 14%. Pretty
decent given that Suikoden 2 fans are probably FFVII fans as well. It
shows there&#8217;s at least a dedicated Suikoden fanbase, although that
fanbase is still ultimately small. Look for it to avoid a complete
blowout to MMX, although it probably still won&#8217;t avoid a tripling.<br><br>Bracket: Mega Man X<br>Vote: Mega Man X<br>Prediction: MMX with 76.24%<br><br> <br> <br>Comments: The whole Crew is going with MMX in this match. Our predictions are all over though. From low 70's to mid 80's.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/2/2006 5:47:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316883543">message detail</a>
 | #123</td></tr>
<tr class="even">
<td>
I'll take the low road...<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br><i>^5 SOWL IMHO</i> - Explicit Content</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/2/2006 5:47:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316883556">message detail</a>
 | #124</td></tr>
<tr class="even">
<td>
<i>Aitch Emm&#8217;s Prediction : Mega Man X 85% -- Suikoden 18%</i><br><br>... Bless it. That should be 82% for Mega Man X. &lt;&lt;<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=80585&amp;board=8&amp;topic=29002092" class="name">DBZFIGHTERS</a> |
Posted 7/2/2006 5:47:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316883563">message detail</a>
 | #125</td></tr>
<tr class="even">
<td>
All the Analysis could be sum up in one sentence:<br><br>Mega Man X will win.<br><br>Interesting to see how many ways you guys can repeat it &gt;_&gt;<br><br>---<br>Die hard Cubs, Pistons, Patriot and Maple Leafs fan<br>Owl Squad Member ( �v�( �v� )�v� ) O RLY?</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=965303&amp;board=8&amp;topic=29002092" class="name">SephirothG</a> |
Posted 7/2/2006 5:48:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316883641">message detail</a>
 | #126</td></tr>
<tr class="even">
<td>
You did that with the last prediction too HM. &gt;_&gt;<br>---<br>[Something clever was here before the sig wipe]<br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/2/2006 5:48:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316883746">message detail</a>
 | #127</td></tr>
<tr class="even">
<td>
<i>Aitch Emm&#8217;s Prediction : Mega Man X 85% -- Suikoden 18%</i><br><br>Is this a long-running joke or something? =P<br>---<br><b>Board 8</b>: Where <i>Wii</i> treat each other <i>right</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29002092" class="name">UltimaterializerX</a> |
Posted 7/2/2006 5:49:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316883876">message detail</a>
 | #128</td></tr>
<tr class="even">
<td>
Damn, I thought I'd be the only one around the 75% range.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), FE8, WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=722305&amp;board=8&amp;topic=29002092" class="name">Dilated Chemist</a> |
Posted 7/2/2006 5:49:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316883926">message detail</a>
 | #129</td></tr>
<tr class="even">
<td>
I can see MMX getting close to 80% against Suikoden.<br><br>---<br><b>=DC=</b><br>Chemistry
can be a good and bad thing. Chemistry is good when you make love with
it. Chemistry is bad when you make crack with it.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1474778&amp;board=8&amp;topic=29002092" class="name">Dawodieiam75</a> |
Posted 7/2/2006 5:50:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316884035">message detail</a>
 | #130</td></tr>
<tr class="even">
<td>
<i>Aitch Emm&#8217;s Prediction : Mega Man X 85% -- Suikoden 18%</i><br><br>heheh, HM's not even trying anymore. I guess i'm the only one who belives MMX will only be in the 60's.<br><br>---<br>If
you fail to answer all of the questions correctly, you will be referred
to as "BumBumDoodleDum the 00ber n00b" and will be treated accordingly.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/2/2006 5:50:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316884086">message detail</a>
 | #131</td></tr>
<tr class="even">
<td>
Silence! Math never was one of my strong points.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/2/2006 5:52:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316884413">message detail</a>
 | #132</td></tr>
<tr class="even">
<td>
Should have just stuck to giving the winner's percentage then.  =P<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/2/2006 5:52:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316884500">message detail</a>
 | #133</td></tr>
<tr class="even">
<td>
I was going to change it HM, until I realized I didn't know which side to add/subtract from.<br><br>At least the Pokemon/SO one adds up to 100!<br>---<br>Moltar Status: Excited, the Contest is here at last!<br>LoZ vs. Civilization - Bracket: <b>LoZ</b> - Vote: <b>LoZ</b> (0/0)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3489629&amp;board=8&amp;topic=29002092" class="name">TransgenderLove</a> |
Posted 7/2/2006 5:53:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316884529">message detail</a>
 | #134</td></tr>
<tr class="even">
<td>
XMFD. I love you Aitch Emm.<br><br>---<br><b>Explicit Content</b><br>Cheer Up Trannys.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1474778&amp;board=8&amp;topic=29002092" class="name">Dawodieiam75</a> |
Posted 7/2/2006 5:55:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316885018">message detail</a>
 | #135</td></tr>
<tr class="even">
<td>
Aitch Emm ='s My new Hero<br><br>i love him...<br>---<br>If you
fail to answer all of the questions correctly, you will be referred to
as "BumBumDoodleDum the 00ber n00b" and will be treated accordingly.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29002092" class="name">BlAcK TuRtLe</a> |
Posted 7/2/2006 6:04:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316886951">message detail</a>
 | #136</td></tr>
<tr class="even">
<td>
I have 71.82 I believe. I fear it might be a little on the low side.
Let's just hope that Suikoden can pull random votes out of it's ass.<br><br><br><b>TuRtLe</b><br>~~~<br>Like Darth Maul, the bastard child of Michael Flatley and Hellboy. -trancer1</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1474778&amp;board=8&amp;topic=29002092" class="name">Dawodieiam75</a> |
Posted 7/2/2006 8:34:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316917056">message detail</a>
 | #137</td></tr>
<tr class="even">
<td>
oooh wheee, LoZ is sooooo close to 90....<br>---<br>If you fail
to answer all of the questions correctly, you will be referred to as
"BumBumDoodleDum the 00ber n00b" and will be treated accordingly.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1011146&amp;board=8&amp;topic=29002092" class="name">fortybelowsummer</a> |
Posted 7/2/2006 8:43:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316918912">message detail</a>
 | #138</td></tr>
<tr class="even">
<td>
taggage<br>---<br><i>During universal times of deceit, telling the truth becomes a revolutionary act. - George Orwell</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/2/2006 9:14:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316925428">message detail</a>
 | #139</td></tr>
<tr class="even">
<td>
I believe HM should not be allowed to continue posting on Board 8 until
he agrees to keep ****ing up his math. Not that he'd HAVE to agree to
it to do it anyway, but I love seeing it, heh.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/2/2006 10:41:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316945611">message detail</a>
 | #140</td></tr>
<tr class="even">
<td>
&gt;_&lt;!<br><br>I can't believe I changed my 90% prediction. <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br><i>^5 SOWL IMHO</i> - Explicit Content</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29002092" class="name">SquallidSnake</a> |
Posted 7/2/2006 10:42:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316945834">message detail</a>
 | #141</td></tr>
<tr class="even">
<td>
Odd, I don't have the lowest prediction this time. I'm surprised somebody went under 70% for this one.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=863018&amp;board=8&amp;topic=29002092" class="name">Janus5000</a> |
Posted 7/2/2006 10:48:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316947076">message detail</a>
 | #142</td></tr>
<tr class="even">
<td>
<i>and unlike a lot of other characters, Mega Man only has his games to draw his strength from. </i><br><br>Didn't he have an old cartoon?<br>---<br>"Those who cast the vote decide nothing. Those who count the vote decide everything."</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29002092" class="name">SquallidSnake</a> |
Posted 7/2/2006 10:49:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316947248">message detail</a>
 | #143</td></tr>
<tr class="even">
<td>
<b>SUPER FIGHTING ROBOT...<br><br>MEGA MAN!</b><br><br>Yes, and the show was awesome.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29002092" class="name">BlAcK TuRtLe</a> |
Posted 7/2/2006 10:51:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316947894">message detail</a>
 | #144</td></tr>
<tr class="even">
<td>
85.02% was my Oracle pick. Seems as though that beats out HM, mnm, Leon and yo<br><br><br><br><b>TuRtLe</b><br>~~~<br>Like Darth Maul, the bastard child of Michael Flatley and Hellboy. -trancer1</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29002092" class="name">SquallidSnake</a> |
Posted 7/2/2006 11:19:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316954340">message detail</a>
 | #145</td></tr>
<tr class="even">
<td>
Looks like Ulti got the first point.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29002092" class="name">UltimaterializerX</a> |
Posted 7/2/2006 11:26:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316955945">message detail</a>
 | #146</td></tr>
<tr class="even">
<td>
And I'm on track for another if this keeps up.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), FE8, WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/2/2006 11:27:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316956140">message detail</a>
 | #147</td></tr>
<tr class="even">
<td>
O RLY?<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29002092" class="name">Lopen</a> |
Posted 7/2/2006 11:28:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316956440">message detail</a>
 | #148</td></tr>
<tr class="even">
<td>
I'd say Moltar, mnm, and yes, even myself are more likely to get the
point on this one than you, Ulti. Mega Man X is only gonna speed up
come daytime. <br>---<br>Raiden is still [<i>!!</i>] nominations short!  <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/2/2006 11:28:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316956554">message detail</a>
 | #149</td></tr>
<tr class="even">
<td>
I think you mean, <i>I'm</i> on track for a point!!<br>---<br>Moltar Status: Excited, the Contest is here at last!<br>MMX vs. Suikoden - Bracket: <b>MMX</b> - Vote: <b>MMX</b> (1/1)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=844694&amp;board=8&amp;topic=29002092" class="name">Saiyan Pezhead</a> |
Posted 7/2/2006 11:29:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316956606">message detail</a>
 | #150</td></tr>
<tr class="even">
<td>
Can I be Over? I prefer Dengakuman, but Over is about the coolest person not allready used thar.<br>---<br>Nominating: Phoenix Wright, Miles Edgeworth, Captain Falcon, Prince of Persia, Rain, Vivi, Fox McCloud, Mewtwo, Axel</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">1</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=1">2</a></li>
<li>      3</li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=3">4</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=4">5</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=5">6</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=6">7</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=7">8</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=8">9</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=9">10</a></li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage3_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29002092&amp;page=2" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage3_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>