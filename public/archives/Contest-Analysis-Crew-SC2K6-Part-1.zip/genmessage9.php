<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><title>GameFAQs: Message List</title>

<link rel="stylesheet" type="text/css" href="genmessage9_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage9_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage9_files/bc.css"></head><body linkifytime="341" linkified="17" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage9_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage9_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29002092%26page%3D8"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage9_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div><a href="http://adlog.com.com/adlog/c/r=10153&amp;s=657790&amp;t=2006.07.11.19.55.39&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=00c17-gne-ad244B3BA192E81CE/http://www.gamespot.com/pc/action/hitman2silentassassin/index.html?q=hitman%202" target="_blank"><img src="genmessage9_files/hitman_leader.gif" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage9_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29002092&amp;page=8">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29002092" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">First
          Page</a> |
          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=7">Previous
          Page</a> |
          Page 9 of 10          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=9">Last
          Page</a>
      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2587111&amp;board=8&amp;topic=29002092" class="name">Anal Storage</a> |
Posted 7/9/2006 11:40:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318589421">message detail</a>
 | #401</td></tr>
<tr class="even">
<td>
<i>Way to make me look like a fool Madden!</i><br><br>That's a mirror.<br><br>---<br><b>Explicit Content</b><br>I used to be Asian, but I didn't get good enough grades so my parents beat it out of me. - snalien</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29002092" class="name">BlAcK TuRtLe</a> |
Posted 7/9/2006 11:41:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318589731">message detail</a>
 | #402</td></tr>
<tr class="even">
<td>
<i>From XxSoulxX Posted 7/10/2006 12:40:05 AM</i><br><i>This is classic case of SFF right here! </i><br><br>As hilarious as it sounds, he's right. Mario shares a fanbase with almost every game in existance.<br><br><br><b>TuRtLe</b><br>~~~<br>Like Darth Maul, the bastard child of Michael Flatley and Hellboy. -trancer1</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29002092" class="name">THEJackSparrow</a> |
Posted 7/9/2006 11:43:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318590055">message detail</a>
 | #403</td></tr>
<tr class="even">
<td>
Considering less than 2% have never played ANY Mario game, naturally there will be an overlap with every series to some extent.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/9/2006 11:47:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318590813">message detail</a>
 | #404</td></tr>
<tr class="even">
<td>
SMB versus Tetris!  Ultimate fan-overlap!<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/9/2006 11:48:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318590973">message detail</a>
 | #405</td></tr>
<tr class="even">
<td>
Only 3 votes would be cast because everyone else is too torn over which to vote for.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Super Mario Bros. vs. Madden - Bracket: <b>SMB</b> - Vote: <b>SMB</b> (7/8)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29002092" class="name">DaruniaTheGoron</a> |
Posted 7/10/2006 12:09:31 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318595227">message detail</a>
 | #406</td></tr>
<tr class="even">
<td>
This is such a bad match. I wish CJayC would just fill in the bottom 5
entrants with series that are actually popular, such as Half-Life,
Doom, Xenogears/Saga, KOTOR, etc.<br>---<br>...little Weezing it's gonna stand up against my ****in' Charizard? Just get back on your bike <br>and keep pretending to be cool with your lame ass mohawk ****er. - phoenix1487 <b><i>Sp2k6: 7/8</i></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/10/2006 12:11:12 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318595578">message detail</a>
 | #407</td></tr>
<tr class="even">
<td>
Kingdom Hearts vs. Harvest Moon<br>+9 Moltar<br>+8 Ulti<br>+7 HaRRicH<br>+6 Lopen<br>+5 yo<br>+4 mnm<br>+3 HM<br>+2 Leon<br>+1 Soul<br><br><b>The Rankings</b> (Through Kingdom Hearts/Harvest Moon)<br>1. HaRRicH (40)<br>2. Master Moltar (38)<br>3. yoblazer33 (35)<br>4. UltimaterializerX (31)<br>5. therealmnm (29)<br>6. Lopen (26)<br>7. Leonhart (24)<br>7. XxSoulxX (24)<br>9. Heroic Mario (20)<br><br>---<br><b>Board 8</b>: Where people treat each other <i>right</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=456743&amp;board=8&amp;topic=29002092" class="name">Sir Bormun</a> |
Posted 7/10/2006 12:14:39 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318596339">message detail</a>
 | #408</td></tr>
<tr class="even">
<td>
Maybe the best system would be something where the three closest get
points... 3 for the closest, 2 for the second closest, and 1 for the
third closest. Sort of a compromise between the two that are going on
currently.<br>---<br>Need new sig.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/10/2006 12:16:07 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318596636">message detail</a>
 | #409</td></tr>
<tr class="even">
<td>
Looks like I could jump up a few spots after today's match. Hopefully, Mario can keep it above 90%. That's all I need.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29002092" class="name">Lugia2</a> |
Posted 7/10/2006 6:46:35 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318632607">message detail</a>
 | #410</td></tr>
<tr class="even">
<td>
Wow.  That 93% is looking pretty good right now...<br><br>Nice for someone who got Vercetti's strength wrong and believed that a 60-40 in favor of Halo (against CV) was a lock...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/10/2006 9:49:52 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318648442">message detail</a>
 | #411</td></tr>
<tr class="even">
<td>
No need for a compromise -- it's just for looks more than anything else.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/10/2006 10:41:53 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318656149">message detail</a>
 | #412</td></tr>
<tr class="even">
<td>
Kingdom Hearts...................73.12% 81729<br>Harvest Moon........................26.88% 30051<br>TOTAL VOTES..................................111780<br><br>90.3% of the brackets predicted this match correctly.<br><br>Kingdom
Hearts might not have looked too dominant in the match, but it
certainly looked strong in the brackets. Over 90% had it winning, the
second highest so far. KH never blows out it's opponent, so I'm not too
surprised it failed to triple HM. At least it makes next round look
very interesting.<br><br>Today, SMB...well...just look at the poll resultsand be in awe!<br><br>Moltar - 2<br>HaRRich - 2<br>HM - 2<br>Soul - 1<br>Ulti - 1<br>Leon - 0<br>Yoblazer - 0<br>Mnm - 0<br>Lopen - 0<br><br>Lowest pick for the win.<br><br>Also
yo, are you going to keep on doing those full rankings? If so, is it
alright if you keep track of those while I stick with these?<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Super Mario Bros. vs. Madden - Bracket: <b>SMB</b> - Vote: <b>SMB</b> (7/8)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/10/2006 10:52:55 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318657938">message detail</a>
 | #413</td></tr>
<tr class="even">
<td>
Leon's got this pick locked up.  In fact, unless Mario rises some more, I very well could get last on yo's format this time.<br><br>Dammit.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/10/2006 10:53:36 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318658041">message detail</a>
 | #414</td></tr>
<tr class="even">
<td>
Still can't believe that only 3 people picked Mario to break 90% here.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/10/2006 10:56:15 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318658512">message detail</a>
 | #415</td></tr>
<tr class="even">
<td>
Me too.  People went conservative with Madden for whatever reason.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=685460&amp;board=8&amp;topic=29002092" class="name">Turbo Kirby</a> |
Posted 7/10/2006 12:32:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318677210">message detail</a>
 | #416</td></tr>
<tr class="even">
<td>
*tag*<br>---<br><i>A gentle answer turns away wrath, but a harsh word stirs up anger.</i> -Proverbs 15:1</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/10/2006 2:24:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318701992">message detail</a>
 | #417</td></tr>
<tr class="even">
<td>
Alright, I'm pretty confident in my picks the rest of the way through. Got to get out of this hole. <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/10/2006 2:32:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318703994">message detail</a>
 | #418</td></tr>
<tr class="even">
<td>
<b>Mushroom Division:</b> <i>Round 1 - Match 10</i> &#8211; (4)Grand Theft Auto vs. (5)Warcraft <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Grand Theft Auto</b><br>The
GTA series exploded with GTA3, and has only grown thanks to Vice City
and San Andreas. The latest in this huge franchise is Liberty City
Stories.<br> <br><b>Warcraft</b><br>No, not Starcraft. Warcraft! Most of you might recognize it in World of Warcraft, the very popular MMORPG. <br><br>I
hate this match. Not because it&#8217;s hard or anything, but because of one
thing. The Blizzard Fanboys. So sorry in advance if I come off as rude
or impolite&#8230;actually, no I&#8217;m not.<br><br>A lot of people got owned by
Starcraft in 2004 when it beat Halo, KH and Wind Waker before losing in
a close one to SSBM. They then got owned again in 2005 by a devil
called Diablo, who won his division in the Spring Contest by beating
favorites Ridley, M. Bison and Kefka. Since then, many people believe
that Blizzard = omg the vote ralliez instant win. No, that is wrong!
People seriously overestimate the rallying. Diablo needed none of it to
beat the garbage in his division, and StarCraft was pretty strong as it
is. The minor vote rallying and cheat votes it received just pushed it
over the edge in close matches with Halo and WW.<br><br>The Blizzard
Fanboys have suffered one huge defeat thus far, and that was Vincent
vs. Kerrigan. You know, the match that Vincent beat the holy hell out
of Kerrigan with nearly 80% of the vote and the Vincent supports rubbed
it hard in the faces of the Kerrigan supporters? Well, we might be
seeing another loss right here in GTA vs. Warcraft.<br><br>Ok, GTA hate
has seem to have blinded some people. San Andreas was GotY in 2005, and
Vice City lost GotY a few years back in a close one with Metroid Prime.
GTA3 was also a huge game, which revived the franchise and made it the
behemoth it is today. GTA is no pushover, it&#8217;s one of the strongest
series in the Contest! Heck, it has 3 games in the Top 35 of &#8220;The List&#8221;
while the highest Warcraft game ranks at #39.<br><br>Speaking of
Warcraft, all it has pretty much is Warcraft III and World of Warcraft,
which isn&#8217;t even liked that much on GameFAQs. I&#8217;m sure another analyst
linked to the poll below, but it says over half of GameFAQs could care
less for WoW. WoW is not going to push the Warcraft franchise to
victory over 3 huge GTA games. Also, <b>Warcraft =/= Starcraft, Warcraft =/= Diablo</b>,
end of story. I won&#8217;t be surprised if Warcraft is destroyed in this
match. It won&#8217;t be as bad as Kerrigan, but we&#8217;re bound to see a handful
of whining Blizzard Fanboys on the board the day of the match.<br><br>If only GTA weren&#8217;t dead in Round 2&#8230;it could have been quite the bracket buster in the Metal Gear division.<br><br><b>Moltar&#8217;s Bracket Says:</b> Grand Theft Auto will win.<br><br><b>Moltar&#8217;s Prediction is:</b> GTA: 61% - Warcraft: 39%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>Board
8 is overrating the living hell out of Warcraft. Why? Because board
consensus went against Starcraft in 2004 and Diablo in 2005. Plenty of
people got burned, so now everyone is overcompensating for Blizzard in
any questionable match it appears in. The major reason for this is
because everyone assumes that rallying made the big difference in all
of Starcraft and Diablo's matches.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/10/2006 2:33:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318704118">message detail</a>
 | #419</td></tr>
<tr class="even">
<td>
Well first off, this depends on the definition of rallying. I'm on Bnet
every day, and it's not difficult to /ignore an idiot spammer. Most
Bnet regs don't give two craps about spamming, and I'd honestly be
stunned if rallying made a significant difference (like over 3-5%) in
any of Starcraft or Diablo's matches. When Diablo was blown out by
Sonic and Ganondorf, you would assume that rallying could have helped
him save face. When Diablo beat Ridley, M. Bison and Kefka all in a
row, people forget that these three characters are all clowns --
literally, in Kefka's case. I maintain that the only character that had
a chance of beating Diablo in that division was Bison, hence why I
picked that "upset" in the first place. I have no idea why anyone
thought Kefka or freaking RIDLEY could win that match, but I digress.
Diablo pretty much went on innate strength alone. Rallying made little
to no noticeable difference, which I can say from my own experience. I
was awake from the beginning of the Ridley match all through the d2.net
linkage and for a few hours afterwards. The OMG VOTE WHORING JUMP never
happened, and the percentage stayed pretty constant through the day
once Diablo established that he was going to win.... which was a few
minutes in.<br><br>Which beings me to Starcraft, the supposed king of all rallying. I say supposedly for a reason.<br><br>This is a direct copy-paste from my PCA of Kefka/Vercetti 2005. First paragraph is a post from Ceej, the rest is from me:<br><br><i> From: CJayC | Posted: 8/7/2005 3:11:54 AM | Message Detail | #102<br>Yeah,
I did see the Vercetti stuff at the end of it; odd thing though, it
good portion of it (half?) came from a wide variety of IPs and ISPs, in
China of all places. None of the IPs were known proxies, and given that
they were from multiple ISPs, it can't have been one person doing it; <b>it looked more like the Korean ISP floods during the Best Game Ever matches with StarCraft</b>. *shrug*<br><br>Translated:
"Starcraft may have cheated in Spring 2004, but the IP addresses are
varied enough to where I can't confirm it for sure."<br><br>Am I the only one who thinks that admitting this was a <b>horrible</b>
idea? Assuming that my assumption is correct, Ceej could have very well
admitted that Starcraft did far more potential cheat damage than in the
match with SSBM. Seeing how, if ever, this plays out in future
Starcraft matches will be very interesting. Or maybe Korea just knows
how to rally votes at the right time, who knows.</i><br><br>And if that doesn't convince you that rallying played little part in why Starcraft was such a force, feed on this:<br><br>Starcraft v Wind Waker<br><br>Starcraft 50.1% <b>41480</b><br>Wind Waker 49.9% 41309<br><br>Starcraft v Kingdom Hearts<br><br>Starcraft 53.57% <b>40698</b><br>Kingdom Hearts 46.43% 35274<br><br>Against
Wind Waker, Starcraft had the OMG SATURDAY factor to go along with the
already-supposedly-insane-power of the OMG RALLYING factor. Bnet
traffic doubles on Saturday night slash Sunday morning, so <i>clearly</i> Starcraft benefited from the increased rallying potential to INSANE and ASTRONOMICAL heights.<br><br>...to
the tune of 782 more votes than it got against Kingdom Hearts, a match
in which rallying was never once needed. Some force, that rallying
factor was. One could easily assume that the extra little 1-2% punch
Starcraft got in every match were due to these ISP floods that Ceej
couldn't confirm as cheating, and not from all this rallying that
everyone likes to bring up.<br><br>Which brings us, at last, to Warcraft. I just now got off of WC3 on Bnet. It's the weekend, so traffic should be massive.<br><br>57,543
users. 1,247 games. That's not even half the traffic that you'd usually
see for Starcraft or Diablo, and weekend numbers for the latter two
blow this out of the water. Starcraft alone will usually bring in
between 200k and 250k people during peak hours -- the same peak hours
that generated MASSIVE VOTER INFLUX against Wind Waker, I might add.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/10/2006 2:34:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318704306">message detail</a>
 | #420</td></tr>
<tr class="even">
<td>
Oh right, all of this rallying potential comes from World of Warcraft
selling 5 million copies in a year. Legions of loser MMO dorks are
bound to spend the three seconds required to get off their lazy asses
and vote on another website for their game (okay series, but let's be
honest about where Warcraft's main strength will have to come from) of
choice.<br><br>The
people banking on this lead me to believe that a lot of the Warcraft
supporters haven't seen an MMO dork in action. I imagine they'll care
about rallying about as much as the fans of Starcraft and Diablo did
during their time in the sun. See also: Practically not at all.
Starcraft and Diablo both relied on stand-alone strength to do well.
Diablo looked stronger than he actually was due to being in a soft-ass
division filled with rats and bums.<br><br>And in the Blizzard echelon,
Starcraft &gt; Diablo &gt;&gt;&gt; Warcraft when it comes to fan
dedication. Warcraft people are banking SOLELY on rallying potential,
which I've just proven will practically not exist. I suppose Warcraft
can hope for some untraceable Korean ISP floods to help it along...<br><br>If
anything, WoW will cause Warcraft to get anti-voted. All MMOs get
anti-voted in polls on GF. Go look them up and see for yourself.<br><br>And
this all paired with the fact that Grand Theft Auto is a damn BEAST. In
the same contest where Starcraft made its "rally"-fueled run, Vice City
wound end up losing to SSBM by a mere 5000 votes. San Andreas could
very well give SSBM an even better run if the two ever fought. GTA3 is
considered the best game in the series by many, as well as the series'
FF7 in that it made the series famous. GTA 1 and 2 also have their
fans, myself included. And let's not forget GTA being slapped up all
over the news in the past few years, thanks to morons who think that
playing violent games trains violent people.<br><br>Oh yeah, and San
Andreas won Game of the Year on GameFAQs a year and a half ago, over
Halo 2. Board 8 may not like GTA much, but to deny how popular the
series is on GameFAQs is a crime. To combat this, Warcraft has....
rallying. If Warcraft even breaks 60% in this match, I'll be stunned.
Vincent : Kerrigan Overhype Mk 2, here we come <i>!!</i><br><br>Prediction:
GTA with 60.91% ; I know I'm generally lazy with my writeups in the
Crew, but I try to launch one nuke every contest. Hope you enjoyed my
version of the Spring 2006 U-238 Cruise Missile.<br> <br> <br><br><b>Soul&#8217;s Analysis</b><br> <br>Originally
I had Warcraft winning this without much hesitation. I was blinded by
my love of blizzard. I was thinking that Warcraft could have easily
defeated Starcraft in these contests, and therefore could easily defeat
GTA. That lasted about a week and a half. That's when reality kicked in.<br><br>Yes,
Warcraft will be pretty strong. You must be a fool to think GTA will
win via blowout. GTA will be stronger though. GTA has had the past 3
games (not including LCS) receive major success, site-wise. San Andreas
is still number 4 overall on the site. I believe it will be a strong
competitor in this contest because of that. Yes, the series will
receive some anti-votes, but those anti-votes won't be as bad as say
Pokemon.<br><br>Everyone thinks that Warcraft will win because of vote
rallying. If it worked for Starcraft, why wouldn't it work for
Warcraft? To answer this bluntly, it didn't work for Starcraft. Sure,
Starcraft did keep matches close during the day, but that's all it
could do. What pushed Starcraft over the hump was Korea. Starcraft is
absolutely huge in Korea. Warcraft is not. Warcraft does not get that
kind of love anywhere, really.<br> <br>People also think WoW will push
Warcraft over GTA. WoW could potentially help Warcraft out, but I doubt
it will be enough to put it over GTA. People could spam WoW all they
want, but it would work just as well as the Starcraft spamming.
Basically, it won't work that well.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/10/2006 2:34:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318704468">message detail</a>
 | #421</td></tr>
<tr class="even">
<td>
Therefore, Warcraft will get close to GTA, but it won't be able to beat it.<br><br><b>My prediction: GTA wins with 52.71% of the vote.</b><br> <br><br><br><b>Leon&#8217;s Analysis</b><br> <br>I&#8217;ve
heard this one argued and debated so much that I&#8217;m essentially sick of
it, especially considering that it&#8217;s not worth arguing over. Grand
Theft Auto is going to win, and easily at that, so I&#8217;m going to make
this brief. I&#8217;ll just give you the basics:<br><br>--Warcraft is NOT
StarCraft, and vote rallying from bnet will not matter. StarCraft had
plenty of its own strength and didn&#8217;t need the rallying to be a beast,
though it likely needed them to win those close matches. 75% of the
GameFAQs population hasn&#8217;t even PLAYED World of Warcraft. The only
reason people are even picking Warcraft is because they&#8217;re afraid of
Blizzard.<br><br>--There is no correlation between Grand Theft Auto&#8217;s
games and its characters. The games are all about gameplay. The
characters are not important, nor do they carry over from game to game
anyway. Grand Theft Auto comes in first or second in nearly every Game
of the Year Poll it&#8217;s involved in, and it came within 5000 votes of the
beloved Super Smash Brothers Melee.<br><br>Really, there&#8217;s not much
hope for Warcraft unless we get rallying the likes of which we&#8217;ve never
seen before. This one should be ugly.<br><br><i>Leonhart&#8217;s Prediction</i>: <b>Grand Theft Auto with 64.71%</b><br><br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>This is another anticipated and debated match around the board &#8211; but I have not the slightest clue as to <i>why</i>.
I suppose I already know the answer to that very question in my head &#8211;
StarCraft. You may think that sounds odd that people would be thinking
StarCraft when picking <i>Warcraft</i> to win a match, but it loosely
has to do with StarCraft. We all know that StarCraft&#8217;s run a couple of
years back was filled with battle.NET spamming, website links, and just
rallying anywhere possible &#8211; throw in some cheaters for good measure.
Most of the board got <i>burned</i> bad by StarCraft&#8217;s run all the way
to the division final and this ultimately led to people fearing
anything that came from Blizzard in a contest environment. Everyone was
worried that Blizzard entries would have an added advantage of being
one of the top performers because of rallying and their fear of not
wanting to get burned so badly led them to choose it whenever it was in
a match that wasn&#8217;t completely out of its league (What&#8217;s up, Final
Fantasy!)<br><br>Oddly enough, why people still have that fear is
clearly beyond me. We have seen that anything Blizzard does not
translate into instant power and success. Kerrigan was viciously beat
down and dominated by Vincent in Summer 2005, so much so that she was
one of the weakest characters in the contest. On top of that, Diablo
places right around the mid level where you aren&#8217;t fodder, but you
aren&#8217;t anything particularly special either. So here we go again with
another Blizzard entry that is being hyped not for its strength in
relation to GameFAQs; rather, its strength in potential rallying, which
is the stupidest thing to rely on. <br><br>Warcraft is up against one
of the most popular franchises in the gaming industry right now &#8211; Grand
Theft Auto. There is a large misconception that Grand Theft Auto is not
popular here at GameFAQs, but there is absolutely nothing to support
this claim. Poll after poll after poll have shown that Grand Theft Auto
is a force here at this site, one of the strongest there is. Sure, its
characters are nothing to write home about, but who plays Grand Theft
Auto for its characters and plot? Almost no one. You could careless
about the characters and still love the game to death because it is all
about the gameplay. Let&#8217;s take a look at a couple of polls in the past
that show people on GameFAQs <i>do</i> care a great deal about GTA &#8230;</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/10/2006 2:35:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318704606">message detail</a>
 | #422</td></tr>
<tr class="even">
<td>
<a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2033" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2033">http://www.gamefaqs.com/poll/index.html?poll=2033</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1831" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1831">http://www.gamefaqs.com/poll/index.html?poll=1831</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1471" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1471">http://www.gamefaqs.com/poll/index.html?poll=1471</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1270" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1270">http://www.gamefaqs.com/poll/index.html?poll=1270</a><br><br>Just looking at those should give you an idea of how many people <i>do</i>
care about Grand Theft Auto on this site &#8211; and these aren&#8217;t even the
key indicators of its popularity. Sure, you have a chunk of the site
who don&#8217;t care about the games and won&#8217;t play them, but that is to be
expected with pretty much anything that isn&#8217;t a Final Fantasy or Zelda.
Still, the amounts of people who care for it are the majority. Now
let&#8217;s look at some of the Game of the Year polls, which really show off
how much people like them &#8230;<br><br>Game of the Year 2001 : <a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=776" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=776">http://www.gamefaqs.com/poll/index.html?poll=776</a><br>Game of the Year 2002 : <a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1134" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1134">http://www.gamefaqs.com/poll/index.html?poll=1134</a><br>Game of the Year 2004 : <a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1877" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1877">http://www.gamefaqs.com/poll/index.html?poll=1877</a><br><br>Grand
Theft Auto III placed extremely well in 2001, second only to Final
Fantasy X and beating out Super Smash Bros. Melee. There was plenty of
competition there and it still came away with a solid placement. In
2002, Grand Theft Auto : Vice City came really close to winning, but
was beat out by Metroid Prime, which is a big game here too. In 2004,
Grand Theft Auto : San Andreas <i>killed</i> Halo 2, Half-Life 2, and
Metroid Prime 2. That is some damn fine competition yet it wasn&#8217;t even
close in the final poll. Notable is that San Andreas beat out Metal
Gear Solid 3 in the PlayStation poll before. <br><br>Another thing to
take a look at it is Vice City&#8217;s performance in the Games Contest back
in 2004. People believe the SSB franchise is going to challenge SMB
(ridiculous, I know), so you would figure that this match would be even
<i>easier</i> of a decision once you see that Vice City came awful close to beating out SSBM. <br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1648" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1648">http://www.gamefaqs.com/poll/index.html?poll=1648</a><br><br>That
just about clears any doubts I may have had about GTA not being cared
about by the voters of GameFAQs. When you can get close to a game as
strong as SSBM that just about seals the deal on your strength. So it
is clearly established that Grand Theft Auto is undoubtedly a
powerhouse franchise here, now Warcraft would have to have some serious
power, which is highly unlikely.<br><br>The Blizzard &#8220;chain&#8221; likely
goes as follows &#8220;StarCraft &gt; Diablo &gt; Warcraft,&#8221; which means that
it is already the weakest of the three. However, the thought process of
some is that the rallying potential of Warcraft is far larger than
StarCraft or Diablo due to World of Warcraft &#8211; a game that GameFAQs
does not care about in the slightest. There was a poll held not long
ago that showed some 75% of the voters not having played the game.
People can cite the 6 million players of World of Warcraft worldwide
and it isn&#8217;t going to matter one bit when the majority of people here
don&#8217;t care or play the game. <br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2232" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2232">http://www.gamefaqs.com/poll/index.html?poll=2232</a><br><br>Of course, it <i>is</i>
notable that there is more to Warcraft than just World of Warcraft.
That just happens to be the most recent release of the series. But
there has not been anything to show that Warcraft would have any of the
power that something like StarCraft would have; in fact, I would say it
just doesn&#8217;t even have comparable strength. Warcraft needs a
pre-existing strength and fanbase at GameFAQs before it has the ability
to go up against something like Grand Theft Auto.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/10/2006 2:36:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318704795">message detail</a>
 | #423</td></tr>
<tr class="even">
<td>
In the end, it comes down to Warcraft&#8217;s power pre-rallying. This
nonsense about Warcraft having more potential with rallying than
StarCraft does not matter at all when it isn&#8217;t already strong enough
without them. StarCraft always managed to keep it close with its
opponents, but the moment that things got out of hand (SSBM) it had to
resort to cheating to even get close, which was promptly shut down.
Grand Theft Auto&#8217;s power is far too much for Warcraft, rallying or not.
It would need something <i>massive</i> in order to win, and that is just not happening.<br><br><b>Aitch Emm&#8217;s Bracket Says :</b> Grand Theft Auto will win.<br><br><b>Aitch Emm&#8217;s Prediction :</b> Grand Theft Auto 56% -- Warcraft 44%<br><br><b>Aitch Emm&#8217;s Vote :</b> Warcraft<br> <br><br><br><b>Yoblazer&#8217;s Analysis</b><br> <br>Fire
Emblem versus Silent Hill? Nope. Castlevania versus Halo? Nope. Grand
Theft Auto versus Warcraft? You betcha. Throughout the past few weeks,
this bad boy has surpassed 14 competitors and claimed the title of
Second Most Debated Match of the First Round (behind only Mega
Man/Mario Kart). Not as flashy a title as, say, Best Series Ever, but
better than nothing, right? What was at first deemed an open and shut
case has been spurring more and more debate as more supporters have
snowballed onto the WoW side of things. Can Warcraft really turn this
into a match? Is Grand Theft Auto really such a heavy favorite?<br><br>In
two words, no and yes. Let's start this analysis by taking a look at
Grand Theft Auto. Now, I realize most skeptics have been arguing much
more for Warcraft's potential strength than GTA's possible weakness,
but I think it's in everyone's best interest to examine just what
Rockstar's premier series brings to the table. Grand Theft Auto is a
popular series. It is a very popular series. In fact, it has been
GameFAQs's most popular series since late 2001... seriously. In terms
of popularity, GTA's releases in that time period beat out Final
Fantasy, Zelda, Smash, Metal Gear Solid, and Halo. That's quite a
resume already, is it not? All three big games have performed very well
on the GOTY polls (San Andreas won handily, and Vice City almost beat
out Metroid Prime for the title). The latest GTA game is always, always
located somewhere on the Top 10 FAQs list, and its message boards are
always bustling.<br><br>Polls and FAQ hits are all well and good, but
we know that nothing speaks more volumes about an entrant than contest
results. Contrary to what some people have probably fooled themselves
into believing, GTA does <i>not</i> disappoint in this respect. Far
from it. Vice City is stronger than MGS2. None of that fuzzy Starcraft
crap or heavy stats crunching; Vice City PROVED it against Super Smash
Bros. Melee with a very impressive 46.5%. San Andreas is likely
stronger, and GTAIII can't be too far behind, if at all. In fact, if we
look at the Fall 2005 Top 100 list, we'll see that Vice City actually
placed last among the big three, and even <i>then</i>, all three games
made the top 35, with San Andreas missing the top ten by a single spot.
That is power, folks; it's not some temporary craze that will pass over
in a year. Grand Theft Auto is a bigtime player, and it's here for good.<br><br>Warcraft. My oh my, Warcraft. You have quite the fight on your hands.<br><br>As
tricky as it is to pin-point Warcraft's strength in a contest setting,
it really doesn't require much analysis at all. Being Blizzard or not
is irrelevant; there is very little indication that this site cares
about the series. Its older games are never brought up, and both
Starcraft and Diablo got entrants nominated into the contests before
Warcraft. To me, this suggests that Warcraft is third in the Blizzard
hierarchy. Of course, most Warcraft supporters aren't taking this risk
because they feel GTA is weak or their series' older stuff is popular.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/10/2006 2:36:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318704941">message detail</a>
 | #424</td></tr>
<tr class="even">
<td>
Enter WoW. World of Warcraft, the forbidden fruit of over six million
people, is viewed as a danger by some and an overhyped, guaranteed
suicide by others. Like Starcraft, it is played by millions of people
Online. Unlike Starcraft, however, it already has a huge piece of
evidence against it. A poll conducted in late 2005 shows that only 15%
of the voter pool were Warcraft players at the time, and well over half
of the remaining voters had no intention of ever trying the game. How
can one game that appears to be so weak on GameFAQs scare so many
people? It's because Warcraft supporters are hoping that massive
rallying on WoW fansites and forums will give the series a crucial edge
in the match. The flaw here is that these supporters are too caught up
in this potential rallying and are completely overlooking the game's
inherent weakness. Take away all of the rallied votes, and Starcraft
still gives Halo and Wind Waker a fight. Take away the rallied votes
here, and nobody would argue that Warcraft wouldn't get killed. For
Warcraft to be victorious, we need to see a very sizable chunk of the
votes come from outside sources. Simply put: if you don't expect to see
at least 140,000 votes on match day, don't expect Blizzard's series to
win. How many people actually expect that?<br><br>Hell,
let's use our imaginations here. Let's assume Warcraft does draw the
massive outside numbers and pulls off the win. If it beat GTA, what the
hell is stopping it from beating Mario? It only needs, what, 50,000
more votes, tops? Why is that such a big deal when you have 6 million
troops at your beck and call? What's to stop it from taking Final
Fantasy and Zelda? What's stopping it from winning every match by a few
hundred thousand votes?<br><br>See how ridiculous it starts to sound? Too ridiculous for me, that's for sure!<br><br>Grand Theft Auto<br>+ Three very strong games<br>+ Great contest history<br>+ Even better poll history<br>- Possibly a big overlap between the fanbases<br>- All three games congregated on one main console<br><br>Warcraft<br>+ The potential for WoW rallying<br>- That potential is very small<br>- Weak/no poll and contest history<br><br>My prediction: Grand Theft Auto def. Warcraft (61-39)<br> <br><br><br><b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: Welcome to the Jungle<br><br>I
can&#8217;t believe this match is even being debated at all, let alone to the
lengths that some people on the board are going to in believing that
Warcraft will actually <i>win</i>. Grand Theft Auto may have the
appearance of a series that only appeals to casuals, but that is hardly
the case. The GTA series is popular among casual and hardcore gamers
alike. And what&#8217;s more important is that it&#8217;s one of the most popular
series on THIS site, something that I can&#8217;t say for Warcraft.<br><br>I
don&#8217;t even have to argue to prove GTA&#8217;s popularity on this site. The
writing is on the wall. GTA3 was runner-up in the 2001 GotY poll.
GTA:Vice City was runner-up in the 2002 GotY poll, <i>barely</i>
losing out to Metroid Prime. And GTA:San Andreas was easily the 2004
GotY, handily beating the likes of MGS3, Metroid Prime 2, Halo 2, and
Half-Life 2. Also, Vice City destroyed Star Wars:KOTOR and directly
outperformed Metal Gear Solid 2 against Super Smash Bros. Melee. That&#8217;s
right. The GTA series has definitely shown to be popular on this site,
even more than Metal Gear and Halo. It is no joke on this site as a
series.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/10/2006 2:37:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318705111">message detail</a>
 | #425</td></tr>
<tr class="even">
<td>
If you want to bring up GTA characters, I&#8217;d like to introduce you to my size-13 foot.  GTA is a series that is <i>all</i> about the gameplay.  Sure the games have a story to move the game along, but it is a <i>heavy</i> gameplay focused series.  And with that being said, the fact that Tommy Vercetti was <i>still</i>
able to bust on the scene and be more popular than Donkey Kong speaks
volumes. What&#8217;s that? CJ bombed against Ness? Well it&#8217;s already known
that a good percentage of GameFAQs absolutely hates the hip-hop/gangsta
image. And yet, even with that image, GTA:San Andreas <i>still</i> won GotY.  And last I checked, this was a series contest, not a character contest.<br><br>As for Warcraft, I&#8217;m sorry but it hasn&#8217;t done <i>anything</i> to show that it is popular on this site.  GTA:Vice City <i>destroyed</i>
Warcraft III in the 2k2 GotY poll. In the 2k4 GotY polls World of
Warcraft couldn&#8217;t even compete with Half-Life 2, which GTA:San Andreas
crushed (like my action verbs?). And don&#8217;t forget about the WoW polls
on this site. See for yourself:<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1827" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1827">http://www.gamefaqs.com/poll/index.html?poll=1827</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1943" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1943">http://www.gamefaqs.com/poll/index.html?poll=1943</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2232" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2232">http://www.gamefaqs.com/poll/index.html?poll=2232</a><br><br>More than half the site already doesn&#8217;t care for WoW at <i>all</i>!
And seeing how Warcraft III was already outclassed in a poll with
GTA:Vice City, the Warcraft supporters are depending on WoW to be
Warcraft&#8217;s strength, and it has a hell of a hole to climb out of
already. Basically, people are hoping that Warcraft will be able to
have a vote rally large enough to take down GTA. Not just any rally
either&#8230; It would have to be the largest rally this site has ever <i>seen</i>
to take down GTA. Larger than even Starcraft! We&#8217;re talking tens of
thousands of votes. I&#8217;m sorry. I simply don&#8217;t see that happening. The
day that happens is the day this site loses all credibility. As an
additional X-factor, GTA:LCS was recently released for the PS2, and
even though its just a port and is probably the least popular game in
the recent series, it still gives GTA fans a major reason to be
frequenting the site. Warcraft has no chance.<br><br>Bracket: GTA<br>Vote: GTA<br>Prediction: GTA with 62.38%<br> <br><br><br><b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Grand Theft Auto<br>Predicted losers:  those who encourage any rallying<br>Top 100 List comparison:<br>---GTA:SA - #11, GTA3 - #27, GTA:VC - #35<br>---WoW - #39, Warcraft 3 - #60<br>Best Game Ever x-stat comparison:<br>---GTA:VC - 34.91%<br>---Warcraft - N/A (no rep)<br><br>I
will go ahead and say this: if Warcraft can beat GTA, Warcraft will win
the championship. Outside of huge rallying, no series can beat Final
Fantasy, Legend of Zelda, or Super Mario Bros. here...and only two
series should prove capable of any rallying at all -- Warcraft and
Diablo. Seeing as how Diablo (the character) hasn't crushed anybody
with that rallying ability of his, I see Warcraft being next in line
for winning the championship only because it <i>might</i> have that crazy-huge rally...<br><br>...but
my money says it won't. When 55+% of the voters here want no part of
the biggest game of its series and all three mainstream GTA games in
the Top 100 List outrank it, you're in trouble. Hell, the
assumed-to-be-weakest of the GTA games is still able to prevent being
doubled by FF7, so that's nothing to mess with. Warcraft HAS to rely on
more rallying than we have ever seen here in order to do respectable,
much less win. I, for one, don't see that happening, though I'm sure
rallying will take place.<br><br>I really hate that GTA got wasted in
this bracket though -- it needed to face MGS, SSB, or Sonic...not Super
friggin' Mario. Switch out GTA/Warcraft with FE/SH, and the bracket
suddenly gets much tougher.<br><br>Grand Theft Auto wins with 64.12%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/10/2006 2:37:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318705214">message detail</a>
 | #426</td></tr>
<tr class="even">
<td>
<b>Lopen&#8217;s Analysis</b><br> <br>This match has a lot of hype, a <i>lot</i>
of it. And really, I don't think it deserves the hype. To be blunt, I
don't respect Warcraft's upset potential here. But I have my reasons, I
have them! That's what this analysis is for, right? So I'll just get
right to it.<br><br>What does Warcraft bring to the table? At the core,
we've got a real time strategy game made by the folks at Blizzard.
Warcraft 3 being the most recent addition, and probably the most
popular on GameFAQs by a decent little margin. It's also the only game
in the RTS half that we have any polls relating to. So how about that
Warcraft 3? There was a game of the year poll, in which Warcraft 3 was <i>stomped</i>
by GTA: Vice City. Vice City tripled it and then some. It wasn't a
direct match, Metroid Prime and some other game soaked up some votes&#8230;
and Warcraft 3 might have done better in a direct match with Vice City
than those numbers imply. But it's pretty well undeniable that Warcraft
3 didn't really look like any sort of a <i>serious contender</i> for
Vice City in that one. And I'd say Vice City is possibly the least
favorite of the three PS2 GTAs on the site. But it's not by that much,
either way. In any case, the other two PS2 GTAs <i>easily</i> bring
more to the table for GTA than WC and WC2 bring for Warcraft. In fact I
wouldn't even be sure if the PS1 and PSP GTA games don't bring more to
the table than WC and WC2.<br><br>What does this all mean? This means
that if World of Warcraft doesn't exist, I'm taking Grand Theft Auto to
win this match&#8230; and quite easily. I'm talking more than 70% of the
vote, here. Ah, but World of Warcraft <i>does</i> exist. And with it,
enters the warcry of the Warcraft supporter&#8230; "READY TO WORK!"&#8230; er&#8230;
"MASSIVE WoW RALLYING POWER!". Well, let's look into that power, okay?
Let's see, according to polls done a few times, ~85% of GameFAQs <i>doesn't even play the game</i>.
By those numbers, it had better hope for rallying power, because
Warcraft 3 is looking better than it at this point. With 6 Million
Subscribers, the potential is there for sure! But I don't think the
meat of any rally threat is going to come from the actual game, but
rather forums and the like related to the game. That's how it seemed to
be with Starcraft and Diablo in the past. It makes sense&#8230; who's going
to stop in the middle of a game to go vote? Assuming that's so, the
threat is drastically lower<br><br>But even if that's not so&#8230; just
think about how many votes it has to rally to win this! Say GTA beats
Warcraft 65-35 in a match with no rallying at all. I think I'm being
generous to Warcraft with that number, honestly, based on all the stuff
we've seen from Warcraft and GTA in previous outings. Let's assume the
match gets 100000 votes (for simplicity's sake)&#8230; that makes the final
score:<br><br>GTA: 65000<br><br>Warcraft: 35000<br><br>That means Warcraft has to <i>net</i>
30000 votes to catch up to GTA. Why do I say net? Because WoW players
aren't drones, (hold your tongue, Ulti!) they aren't necessarily <i>always</i>
going to vote Warcraft. The rallying could backfire sometimes. So I'd
think WoW would have to rally something more like 35000 votes to win
this thing. It's a rather ridiculous number. Diablo only managed a
thousandish at best when he was fighting, and Starcraft didn't pull off
much more. Admittedly, they don't have quite the potential WoW does,
but does WoW have <i>fifteen times</i> the vote rallying power they do? I doubt it. I really do.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/10/2006 2:38:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318705470">message detail</a>
 | #427</td></tr>
<tr class="even">
<td>
Oh yeah&#8230; I'm sure some guy is gonna yell at my projected non-rally
numbers saying "CJ lost to NESS!". Who cares? You honestly think
Arthas, Thrall, Illidan or Undead Hero would do better? I'm not sure CJ
could manage a <i>triple</i>-barrel shotgun, but a <i>double</i>-barrel
shotgun to blow their heads off with would not be out of his reach.
(It's a pun! Get it? &#8230; what?) Oh, and we mustn't forget characters
aren't the same as Series. Especially in GTA's case. GTA is hardly a
character centric series.<br><br><b>Lopen's Prediction:</b> Grand Theft Auto with 59.81%<br> <br> <br>  <br>Comments:
Whew, that was alot to post, but hopefully it shows you how sick we are
of hearing about this match. Everyone here has GTA winning.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2584321&amp;board=8&amp;topic=29002092" class="name">longbladeofhiko</a> |
Posted 7/10/2006 2:40:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318705809">message detail</a>
 | #428</td></tr>
<tr class="even">
<td>
I totally deserve a spot on the crew &gt;_&gt;<br>---<br><b>WWEGSB Hardcore Legend Masa</b><br>JUST LIKE UR MOM LOLO AND URS TO LALA-Tombolo</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/10/2006 2:46:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318707312">message detail</a>
 | #429</td></tr>
<tr class="even">
<td>
Looks like I've gone from low predictions to high predictions lately. I've got the highest for GTA today.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/10/2006 2:47:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318707503">message detail</a>
 | #430</td></tr>
<tr class="even">
<td>
And I think I have the shortest write-up, to boot! Who'd have thought that?<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/10/2006 2:50:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318708123">message detail</a>
 | #431</td></tr>
<tr class="even">
<td>
I'll take the low road.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/10/2006 3:37:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318719505">message detail</a>
 | #432</td></tr>
<tr class="even">
<td>
...Man, I don't even know where to begin analyzing the Castlevania/Kingdom Hearts match.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/10/2006 4:09:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318727365">message detail</a>
 | #433</td></tr>
<tr class="even">
<td>
<i>...Man, I don't even know where to begin analyzing the Castlevania/Kingdom Hearts match.</i><br><br>Heh, already had in your mind what your Halo/KH analysis was going to say?<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/10/2006 4:10:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318727647">message detail</a>
 | #434</td></tr>
<tr class="even">
<td>
No, I didn't do any second round write-ups until the first round was
done. It's just that I'm not entirely sure which way to lean or how to
begin analyzing it.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/10/2006 4:11:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318727961">message detail</a>
 | #435</td></tr>
<tr class="even">
<td>
Same here Leon. I'll probably just end up picking KH2.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/10/2006 4:12:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318728227">message detail</a>
 | #436</td></tr>
<tr class="even">
<td>
I haven't done any 2nd rounds either, but I already had most of my
arguments for KH/Halo formulated, which was why I played around with
KH's first round analysis. I've already said why I thought Castlevania
would be underrated... There's nothing more to really be analyzed on
that end after it beat Halo convincingly.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/10/2006 4:13:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318728338">message detail</a>
 | #437</td></tr>
<tr class="even">
<td>
Err...I suppose I should clarify that a bit. I didn't begin doing any
second round matchups until the opponents had finished their first
match. In other words, I wouldn't have even begun working on
Castlevania/Kingdom Hearts until today. <br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/10/2006 4:14:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318728558">message detail</a>
 | #438</td></tr>
<tr class="even">
<td>
Well, you still have to analyze how Kingdom Hearts compares to Halo,
how much impact actually being a long-running series with several games
to draw from has, etc.<br><br>Really, I'm all out of whack.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29002092" class="name">Lopen</a> |
Posted 7/10/2006 4:17:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318729237">message detail</a>
 | #439</td></tr>
<tr class="even">
<td>
Yeah, I've had Halo/KH in my mind for quite a while. So Castlevania/KH
is more a matter of just using that to argue for why Castlevania will
beat KH by even more. <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=154579&amp;board=8&amp;topic=29002092" class="name">DeepHyren12</a> |
Posted 7/10/2006 8:43:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318791383">message detail</a>
 | #440</td></tr>
<tr class="even">
<td>
Why are you guys basing your arguments off of non-contest polls? Didn't
FFX/SSBM prove that they're not indicative of the contest population as
a whole?<br>---<br>"Patriotism is clearly the greatest danger to which civilization is at present exposed" --Bertrand Russell</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/10/2006 8:45:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318792068">message detail</a>
 | #441</td></tr>
<tr class="even">
<td>
They're not an authority, but they can give you an idea of tendencies.
For example, seeing that 3/4 of the site doesn't care about WoW gives
you an idea that it's not very popular.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/10/2006 8:50:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318793283">message detail</a>
 | #442</td></tr>
<tr class="even">
<td>
<i>Why are you guys basing your arguments off of non-contest polls?
Didn't FFX/SSBM prove that they're not indicative of the contest
population as a whole?</i><br><br>That poll was held at the beginning of 2002, back when there was a <i>heavy</i> Square dominance.  The PS2 had been out for well over a year, the Gamecube and Xbox had <i>just</i> been released, and SSBM wasn't even a month old yet.  FFX was <i>supposed</i> to dominate that poll.  It's not like we are blindly throwing polls out there without justification.  GotY polls <i>still</i> can give an indication of how popular games are.  <br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/10/2006 8:51:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318793529">message detail</a>
 | #443</td></tr>
<tr class="even">
<td>
FFX was like a week old when that poll was taken.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/10/2006 8:51:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318793533">message detail</a>
 | #444</td></tr>
<tr class="even">
<td>
Oh, and of course there are the countless other polls, as Leonhart just mentioned.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/10/2006 8:54:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318794188">message detail</a>
 | #445</td></tr>
<tr class="even">
<td>
Aye, I keep forgetting FFX didn't launch with the PS2. Nonetheless,
there still was a heavy Square presence on the site back then. The N64
was a dying system by then. There was a reason why Aya Brea almost beat
Donkey Kong that year...<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/10/2006 8:58:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318795236">message detail</a>
 | #446</td></tr>
<tr class="even">
<td>
Leon - 64.71%<br>HaRRicH - 64.12%<br>mnm - 62.38%<br>Moltar - 61.00%<br>yo - 61.00%<br>Ulti - 60.91%<br>Lopen - 59.81%<br>HM - 56.00%<br>Soul - 52.71%<br><br><br>This makes scoring much easier for me, and it also lets everyone know just how much room they have to work with at a glance.<br>---<br><b>Board 8</b>: Where people treat each other <i>right</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/10/2006 9:00:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318795600">message detail</a>
 | #447</td></tr>
<tr class="even">
<td>
[This message was deleted at the request of the original poster]</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/10/2006 9:00:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318795780">message detail</a>
 | #448</td></tr>
<tr class="even">
<td>
Err...nevermind. I thought it had something to do with Mario/Madden.<br><br>*goes to his room to cry*<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29002092" class="name">Lugia2</a> |
Posted 7/10/2006 9:26:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318802200">message detail</a>
 | #449</td></tr>
<tr class="even">
<td>
*Reads write-ups*<br><br>Well, I guess that WC&gt;GTA pick was a bad idea.  Luckily, I'm doing this for fun.<br><br>I guess I just depended on two things...<br><br>CJ
losing to the cultish Ness, and Vercetti's near defeat by Kefka (which,
apparently, only got close in the end with the help of Korea. I didn't
know Romero had that kind of access...). The fact that SSB:M beat GTA
kinda helps, but, as you said, WC isn't that popular to begin with.
Even if GTA is merely a midcarder...<br><br>Oh well, another red mark...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/10/2006 9:29:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318803061">message detail</a>
 | #450</td></tr>
<tr class="even">
<td>
Trust me, GTA as a whole is going to be MUCH stronger than the main characters of two of it's games.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Super Mario Bros. vs. Madden - Bracket: <b>SMB</b> - Vote: <b>SMB</b> (7/8)</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">1</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=1">2</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=2">3</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=3">4</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=4">5</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=5">6</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=6">7</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=7">8</a></li>
<li>      9</li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=9">10</a></li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage9_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29002092&amp;page=8" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage9_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>