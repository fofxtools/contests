<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><title>GameFAQs: Message List</title>

<link rel="stylesheet" type="text/css" href="genmessage4_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage4_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage4_files/bc.css"></head><body linkifytime="400" linkified="21" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage4_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage4_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29002092%26page%3D3"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage4_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div><a href="http://adlog.com.com/adlog/c/r=10153&amp;s=657782&amp;t=2006.07.11.19.55.26&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=00c17-gne-ad544AD542F1FF2C1E/http://www.gamespot.com/pc/strategy/celtickingsrageofwar/index.html?q=celtic%20kings" target="_blank"><img src="genmessage4_files/celtic_leader.gif" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage4_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29002092&amp;page=3">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29002092" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">First
          Page</a> |
          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=2">Previous
          Page</a> |
          Page 4 of 10          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=4">Next
          Page</a>
          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=9">Last
          Page</a>
      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/2/2006 11:29:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316956693">message detail</a>
 | #151</td></tr>
<tr class="even">
<td>
I'm actually getting the point today, gentlemen.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/2/2006 11:30:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316956822">message detail</a>
 | #152</td></tr>
<tr class="even">
<td>
Sure, go right ahead.<br><br>Just don't hurt me with those giant scissors now.<br>---<br>Moltar Status: Excited, the Contest is here at last!<br>MMX vs. Suikoden - Bracket: <b>MMX</b> - Vote: <b>MMX</b> (1/1)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/2/2006 11:30:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316956869">message detail</a>
 | #153</td></tr>
<tr class="even">
<td>
Pfft. Just you wait until Suikoden's awesome day vote!<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br><i>^5 SOWL IMHO</i> - Explicit Content</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29002092" class="name">UltimaterializerX</a> |
Posted 7/2/2006 11:31:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316957069">message detail</a>
 | #154</td></tr>
<tr class="even">
<td>
We'll see what happens. Regardless, I think the percentages will stabilize fairly quickly.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), FE8, WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/2/2006 11:32:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316957312">message detail</a>
 | #155</td></tr>
<tr class="even">
<td>
I dunno... it's speeding along at a fairly good pace.  I say it might get up to 77-78%.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29002092" class="name">UltimaterializerX</a> |
Posted 7/3/2006 12:22:39 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316967573">message detail</a>
 | #156</td></tr>
<tr class="even">
<td>
I hope my bracket turns out to be as good as my current Crew
future-telling skeelz. The percentage is falling already, but only
slightly. Me like.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), FE8, WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29002092" class="name">BlAcK TuRtLe</a> |
Posted 7/3/2006 12:23:21 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316967709">message detail</a>
 | #157</td></tr>
<tr class="even">
<td>
71.82% was my oracle for this match. Let's see how well I do.<br><br><br><b>TuRtLe</b><br>~~~<br>Like Darth Maul, the bastard child of Michael Flatley and Hellboy. -trancer1</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/3/2006 12:23:47 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316967780">message detail</a>
 | #158</td></tr>
<tr class="even">
<td>
It <i>is</i> going to rise back up in the daytime.  Don't deny it.  The percentage is going to fall on <i>my</i> side of 75%!<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=25659&amp;board=8&amp;topic=29002092" class="name">Adamantno1</a> |
Posted 7/3/2006 9:06:12 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317012022">message detail</a>
 | #159</td></tr>
<tr class="even">
<td>
What IS SFF, anyway? System Fanboy Factor?<br><br>---<br>My
nick's Adamant. I have a "no 1" that looks stupid. Would've changed it
if I could without losing karma. So it's Adamant, not Adamanto or
Adamantno.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=453709&amp;board=8&amp;topic=29002092" class="name">jonthomson</a> |
Posted 7/3/2006 9:07:51 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317012205">message detail</a>
 | #160</td></tr>
<tr class="even">
<td>
<i>What IS SFF, anyway? System Fanboy Factor?</i><br><br>Same Fanbase Factor. Compare the Link/CATS and Link/Ganondorf matches.<br>---<br>Jon Thomson - CATS, Jay Solano, Ridley, Scorpion, Alien Hominid, Duke Nukem, The Prince, Johnny Rocketfingers, two TBA</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=402049&amp;board=8&amp;topic=29002092" class="name">Zylo the wolf</a> |
Posted 7/3/2006 9:13:09 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317012764">message detail</a>
 | #161</td></tr>
<tr class="even">
<td>
O_O Suikoden doing better than what all in the crew expected, I thought it would at least get 30%.<br>---<br>1f u c4n r34d th1s u r34lly n33d t0 g37 l41d</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=945395&amp;board=8&amp;topic=29002092" class="name">FantasyFreak999</a> |
Posted 7/3/2006 10:17:23 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317020750">message detail</a>
 | #162</td></tr>
<tr class="even">
<td>
tag<br>---<br>"Run, run, or you'll be well done!" <br>~Kefka, Final Fantasy 6~</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/3/2006 11:24:53 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317031247">message detail</a>
 | #163</td></tr>
<tr class="even">
<td>
The Legend of Zelda..........89.97% 100163<br>Civilization...............................10.03% 11169<br>TOTAL VOTES.....................................111332<br><br>98.15% of the brackets predicted this match correctly.<br><br>Wow,
Day 1 of the Contest and we already have records being shattered. No
competitor at GameFAQs has ever gotten more than 100K votes until LoZ
did yesterday. That's <i>incredible</i>. Don't count out Final Fantasy yet though. <br><br>Today,
MMX is easily beating Suikoden, but by a bit less than we thought.
Suikoden cut down the percentage overnight, but the day vote is looking
to help MMX recover some of that.<br><br> <br> <br>Ulti - 1<br>Moltar - 0<br>Soul - 0<br>Leon - 0<br>HM - 0<br>Yoblazer - 0<br>Mnm - 0<br>HaRRich - 0<br>Lopen - 0<br><br>In the first match of the Contest, Ulti prediction was the closest to LoZ's final percentage, so he gets the point.<br>---<br>Moltar Status: Excited, the Contest is here at last!<br>MMX vs. Suikoden - Bracket: <b>MMX</b> - Vote: <b>MMX</b> (1/1)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29002092" class="name">UltimaterializerX</a> |
Posted 7/3/2006 2:14:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317064956">message detail</a>
 | #164</td></tr>
<tr class="even">
<td>
Leon or H looks like they'll take today.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), FE8, WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=453709&amp;board=8&amp;topic=29002092" class="name">jonthomson</a> |
Posted 7/3/2006 3:35:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317082788">message detail</a>
 | #165</td></tr>
<tr class="even">
<td>
Entire crew picks Pokemon, am i rite?<br>---<br>Jon Thomson - CATS, Jay Solano, Ridley, Scorpion, Alien Hominid, Duke Nukem, The Prince, Johnny Rocketfingers, two TBA</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/3/2006 4:32:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317095750">message detail</a>
 | #166</td></tr>
<tr class="even">
<td>
<b>Hyrule Division:</b> <i>Round 1 - Match 3</i> &#8211; (3)Pokemon vs. (6)Star Ocean <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Pokemon</b><br>Pokemon,
Pokemon, with the Pokey and the Mon, yeah, we all know what it is. Most
of us took part of the Pokemon craze. It&#8217;s still going too, with
Diamond and Pearl coming out soon.<br> <br><b>Star Ocean</b><br>Star
Ocean, while not as popular as&#8230;Final Fantasy, isn&#8217;t as obscure as most
other RPGs in this Contest. Latest release = Star Ocean 3<br><br>ZOMG A DEBATABLE MATCH? QUICK! ALERT THE STUFFERS!<br><br>So,
when the bracket was released, this was one of those matches that no
one really talked about at first, until it was brought up that
Xenogears beat Pokemon G/S/C with 58% back in 2004. A few brave souls
then began to believe Star Ocean would win this match. I mean, it is
more popular than Xenogears&#8230;right? That&#8217;s the big question in this
match.<br><br>Most people are thinking, &#8220;its pokemon lolz, its the uber
popularzz!11&#8221; but that still doesn&#8217;t change the fact it lost to
Xenogears. Now, I have Pokemon winning this match. It&#8217;s definitely the
safe route, as Pokemon&#8230;well&#8230;IS very popular. Yeah, it has it&#8217;s share of
haters, but still. I think it&#8217;s performance against Xenogears was a
fluke. I had Pokemon back in my bracket in 2004, and I really couldn&#8217;t
believe that it lost that match. The reasoning back then was because
Pokemon garnered a bunch of anti-votes, but times have changed.<br><br>Another
problem is that it could have been the G/S/C series, because more
casuals are prone to prefer the original R/B/Y series. Since the
Pokemon series is now united in this match, it&#8217;s likely to do better.
Also, Pokemon was behind possible FF7/Xenogears SFF, which made
Xenogears look very weak (weaker than we already thought). I mean,
Xenogears was #32 on the Top 100 list, which is pretty good, and shows
it does have its share of fans. It beat out Pokemon G/S/C by a bit, but
R/B/Y ranked above it.<br><br>Conclusion: If Pokemon and Xenogears were
underrated in 2004 because of FF7, then Pokemon should take this match.
However, if Star Ocean winds up having some semblance of strength on
GameFAQs, then we have an upset on our hands. I&#8217;m banking on the former
though.<br><br><b>Moltar&#8217;s Bracket Says:</b> Pokemon will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Pokemon: 53% - Star Ocean: 47%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>This
will be the first match of the contest that is in any question, though
it's disappointing that a one-point first round match is the only
question we really have in the Hyrule Division.<br><br>Pokemon is the
favorite to win, but the issue is whether or not Star Ocean can cover
the imaginary gap between itself and Pokemon via Pokemon anti-votes and
Star Ocean's own innate strength... whatever that is.<br><br>It's a
reasonable question, but then one has to wonder what Star Ocean's
innate strength is. A good comparison to make is with Tales of
Symphonia (TOS and SO3 always gets lumped together by fans of SO3 for
whatever reason), a game that has seen three of its characters make
contest fields. One of these characters has actually won a match. Star
Ocean has gotten no characters into the field. Neither game made the
Spring 2004 Contest, though Star Ocean 2 not getting in might say a lot
about the series' cult status.<br><br>Another interesting note is the
Xenogears vs GSC match from 2004. Xenogears was obviously SFFd by FF7,
so GSC is very underrated as a result. The Recent Top 100 list somewhat
confirms both things.<br><br>Personally, I doubt Star Ocean has enough
of a fanbase to win, even with anti-votes factored in. It's also worth
postulating that only Pikachu has suffered from anti-votes in contests,
but that's a different animal entirely until we see other Pokemon in
contests.<br><br>Prediction: Pokemon with 53.33%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/3/2006 4:33:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317095969">message detail</a>
 | #167</td></tr>
<tr class="even">
<td>
<b>Soul&#8217;s Analysis</b><br> <br>This one is up in the air for some
reason? A few people are saying that Star Ocean could beat Pokemon
because Xenogears beat G/S. Well, if you're looking for upset picks, I
believe you should look somewhere else. This match will definitely go
to Pokemon. Where's my proof? Common sense, really. What do you think
is more well known? What do you think is more popular? What do you
think is more anticipated?<br><br>There's also been a change of
demographic on this site. What was once known as RPGFAQs is now known
as NintendoFAQs. You really think a huge series like Pokemon will get
defeated by an almost obscure series like Star Ocean? Don't make me
laugh. Not trusting my common sense has bit me in the ass already, and
I'm not about to let that happen to me again.<br><br><i>My Prediction: Pokemon wins with 64.57% of the vote.</i><br> <br><br><br><b>Leon&#8217;s Analysis</b><br> <br>At
first glance, this match appears to have upset potential written ALL
over it. Pokemon hate has been a serious factor in previous contests.
In SC2K2, Pikachu struggled to beat PaRappa the friggin&#8217; Rapper before
getting quadrupled by Cloud. In SC2K3, he didn&#8217;t even get past the
first round, only managing around 32% on Fox McCloud. In the 2004 Best
Game Ever Contest, Pokemon Gold/Silver/Crystal was beaten with ease by
Xenogears, a relatively obscure RPG.<br><br>In steps Star Ocean, a
relatively obscure RPG series. Right away, the correlation between this
match and that Xenogears vs. Pokemon G/S/C match in 2004 should be
obvious. Pokemon is far from unbeatable, that&#8217;s for sure. However, from
the looks of things, the hate does not appear to be as extreme as it
has been in years past. Plus, Xenogears only had to beat ONE (or three,
whatever) game. Star Ocean has to tackle the entire series. I don&#8217;t
think it&#8217;s a stretch to say that Red/Blue/Yellow is the most popular
set in the series, so that&#8217;s one advantage for Pokemon.<br><br>Now the
question becomes&#8230;How does Star Ocean compare to Xenogears? It&#8217;s hard to
say. I&#8217;ll be honest. I&#8217;ve never played one of its games, so I don&#8217;t
know that much about it on a personal level. I know that it IS an RPG,
which is the most popular genre on this site, and it is property of
Square-Enix, which could help. We don&#8217;t have a single example of how it
has performed in any contest. It will essentially be relying solely on
Star Ocean 3, as the rest of the series hasn&#8217;t been nearly as popular.
However, it DOES have Pokemon anti-votes (one of the few times when
anti-votes DO matter) to its benefit, but how significant will that be?
In reality, that is what will make or break this match. In terms of any
other factor that you can possibly look at to analyze this match,
Pokemon has the advantage in just about all of them. In the end, I
don&#8217;t think it&#8217;s quite enough to give Star Ocean the victory, but it
could certainly swing the other way. This is a perfect trap match, one
that really gives you a headache trying to figure it out. Either way,
this should be one of the better matches of the contest and close
throughout.<br><br><i>Leonhart&#8217;s Prediction:</i> <b>Pokemon with 53.64%</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/3/2006 4:34:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317096293">message detail</a>
 | #168</td></tr>
<tr class="even">
<td>
<b>Yoblazer&#8217;s Analysis</b><br> <br>The third contest match is the first
one that's actually been the focus of debate. Hmm... maybe if we didn't
have ONE GUY WHO DOES THIS FOR EVERY SINGLE CONTEST, we could devote
more time to other, better matches. Ah well, I guess it's contest
tradition by now.<br><br>It's clear that the aura of invincibility
surrounding other Nintendo franchises decided not to envelop itself
around Pokemon. The series has never been particularly popular on
GameFAQs, especially when compared to its juggernaut-like status around
the world. It's likely the most SFF-able Nintendo series, and we've
never really seen the Nintendo faithful rally for it (kind of like
Donkey Kong in game form). These are not good signs for a series that
wants to do well in a contest setting, but just how strong does Pokemon
need to be to fend off something like Star Ocean? Let's take a look at
the competition...<br><br>Star Ocean is an RPG series now published by
Square Enix. It's... hold the presses... a Squeenix RPG? Why is this
match even being discussed? Unfortunately, only two of Star Ocean's
four games have been released in the US. It's a two-game series,
joining the likes of Super Smash Bros., Halo, and Kingdom Hearts (well,
technically not KH, but come on). The difference here is that those
aforementioned series have at least one very strong game. A humble
analogy, if I may: we have three one-gallon containers filled with
alcohol. They are labeled Halo, Kingdom Hearts, and Smash Bros.,
respectively. We take one spoonful from each container and dump it in a
fourth empty container. We fill the rest of that container with water.
That's Star Ocean. It's diluted. It's weak. It's not giving anyone a
buzz. No one cares about its first game and its second game isn't big
enough to stand up to much.<br><br>Of course, there is one central
piece of evidence that Star Ocean supporters have relied upon, and that
is Xenogears' 58-42 win over Pokemon Gold/Silver/Crystal in the Games
Contest. Here we have another small-time RPG with unspectacular sales
beating a very well-known Pokemon game. If it happened once, why
couldn't it happen again? For one, I very much doubt Star Ocean: Till
the End of Time is more popular than Xenogears. Xenogears was always
talked about. It, like Suikoden, has a very devoted group of fans, and
that group is larger. I've never seen such support for Star Ocean. In a
direct match, I'd take Xenogears without hesitation. Secondly, it's
hard to argue the fact that the voter pool has been favoring Nintendo
more since SpC2K4, as two Summer Contests and the Villains Contest have
clearly shown. This may not help Pokemon significantly, but it sure
won't hurt. The final point, and the one that will help Pokemon most,
is its status as a series. As the Fall Top 100 has shown us, Pokemon
Red/Blue is clearly the series's most popular game (coming in at an
impressive #28, as opposed to Pokemon Gold's #59). There's no doubt
that this game, along with the dozens of other Pokemon titles stuffed
into one Pokeball-sized contest entrant, will make for a stronger
competitor than its Spring Contest counterpart.<br><br>Pokemon<br>+ We've yet to see its strongest stuff<br>+ Lots of games<br>+ Voter shift toward Nintendo could help it out<br>- Terrible contest history<br>- One of the only series where anti-voting can play a factor<br>- Its second round match (should it win here) will be so sad<br><br>Star Ocean<br>+ Square Enix RPG<br>+ Its second game drew decent hype and recognition<br>- All hopes lie on the shoulders of one game<br>- That game ain't even strong, buddy<br><br>My prediction: Pokemon def. Star Ocean (55-45)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/3/2006 4:35:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317096543">message detail</a>
 | #169</td></tr>
<tr class="even">
<td>
<b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: Pokefloats (SSBM)<br><br>Here
we go! The first &#8220;debated&#8221; match-up of the contest, even though it was
a fairly easy decision for me. Since I&#8217;m already aware of a 2000 word
analysis for this match, I&#8217;ll get to the point. Pokemon is known to
have a lot of hate on this site, but I don&#8217;t think that is really true.
It&#8217;s just Pikachu and Nintendo making a cash cow of the brand that gets
the hate. The games have plenty of fans on this site. People look at
the Xenogears/Pokemon G/S/C matchup as a sign of weakness for Pokemon,
but there are a few things I&#8217;d like to point out about that matchup:<br><br>1.
That was Pokemon G/S/C represented in that contest. Not the series as a
whole. Some people might argue that fans of one game are probably fans
of them all. But that&#8217;s not necessarily true. Pokemon R/B/Y is
undoubtedly the most popular branch of the series, as it serves as the
roots and featured the most popular Pokemon. Given the age demographic
of the site, and Pokemon&#8217;s reputation of a &#8220;kiddie&#8221; franchise, there
are probably plenty of people on this site who have only played R/B/Y
(myself included) and outgrew the series. Remember, G/S/C came out
about 2-3 years after R/B/Y. The sales numbers for the games in America
are 17.42 million for R/B/Y (11.44 for R/B), and 11.73 G/S/C (9.14 for
G/S). And those numbers don&#8217;t even tell the whole story, as a good
number of those G/S/C sales are going to be kids new to gaming, as is
evident by the age demographic of the series. Trust me. I worked at
Toys R Us. There were tons of kiddies picking up a GBC along with
G/S/C. R/B/Y is much more popular than G/S/C and would have done better
against Xenogears.<br><br>2. Speaking of Xenogears, people seem to
forget that it was in an SFF match with FFVII. People see that it got a
solid 19.97% and assumed that it probably didn&#8217;t get SFF&#8217;d at all. Look
closer. Xenogears and FFVII were simultaneous Square projects on the
PSX. With most of Square&#8217;s resources going to FFVII, Xenogears was
delayed. Parasite Eve was the next big Square hit for the PSX. Parasite
Eve came with a Xenogears demo. Xenogears was released later that year.
Given FFVII&#8217;s immense popularity then, most people who bought Xenogears
were undoubtedly people who bought or at least played FFVII. They
pretty much share the <i>exact</i> same fanbase. As for Xenogears&#8217;
sales numbers, those are a bit skewed since Xenogears wasn&#8217;t
mass-produced. It became a commodity on the used market, and the demand
for the game became so great that Square re-released it as a greatest
hit 3 years later. Xenogears didn&#8217;t beat Pokemon because of Pokemon&#8217;s
weakness. It was due to Xenogears&#8217; strength. Xenogears and Pokemon
G/S/C are most likely underrated in the SpC2k4 stats.<br><br>3. People
also seem to be forgetting about the influx of Nintendo fans on this
site since 2k4. The DS has been a big part of that. Even though there
hasn&#8217;t been a big Pokemon release on the DS yet, the fans are still
there. With &#8220;The Boost&#8221; already having been in effect, Pokemon would
probably be a bit stronger than it was in 2k4. Plus add the fact that
Pokemon hate has slowly been dwindling in the industry, and Pokemon has
a great chance to win this match.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/3/2006 4:36:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317096710">message detail</a>
 | #170</td></tr>
<tr class="even">
<td>
On the other side, we have Star Ocean, which is a pretty decent series
in popularity, but not on the level of any of the Square RPGs. The
series was pretty obscure before Star Ocean: Till the End of Time,
which is the most popular game in the series, and probably the most
popular non-Square/non-Dragon Quest/non-Xenosaga RPG on the PS2. Yes, I
know it is under the Square-Enix brand, but come on, we <i>all</i>
know that Star Ocean is an Enix game. Square-Enix did a good job of
marketing the game, but it&#8217;s not like people are adopting it as a
Square game. Looking at how Till the End of Time fared in polls, I
would say it&#8217;s about as popular as Tales of Symphonia on this site.
Decent popularity, but I don&#8217;t think it&#8217;s enough to beat the Pokemon
series as a whole.<br><br>Bracket: Pokemon<br>Vote: Pokemon<br>Prediction: Pokemon with 55.46% <br> <br> <br> <br><b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Pokemon<br>Top 100 List comparison:<br>---Pokemon R/B/Y - #28, Pokemon G/S/C - #59<br>---SO - N/A (had no games on the drop-down list)<br>Best Game Ever x-stat comparison:<br>---Pokemon G/S/C - 16.79% (was behind FF7/Xenogears)<br>---SO - N/A (no rep)<br><br>Finally,
our first good match...well, hopefully good -- I'm thinking it should
be close and deceptively unpredictable, anyway. We've never seen SO in
contest-action, though it's done okay in some GotY polls and "Which
game release do you most anticipate in March?"-type polls. However, I'm
of the opinion that Xenogears, which beat Pokemon G/S/C with 57.95%,
would beat the entire SO series; while Heroic Mario has convinced me SO
isn't cult, per say, I still don't figure it can match Xenogears's
popularity here, no matter the sales-difference between them. I also
think Pokemon R/B/Y should be noticably stronger than Pokemon G/S/C,
then that the Pokemon series should be even stronger than that. Pokemon
has reached more systems and made more games as well, which can't hurt.
Last, as little notes, Pokemon hate has appeared to die down a bit
since Spring 2004 (when we last saw a Pokemon-related contest entry)
and we saw some Nintendo characters boost a lot last year or at least
generally be impressive...neither should be difference-makers, but
neither can hurt its cause either. SO can pull the upset, but I think
it's simply going to walk away with a moral victory.<br><br>Pokemon wins with 53.12%<br> <br> <br> <br><b>Lopen&#8217;s Analysis</b><br> <br>At first glance, this one seems like a no brainer. It's the Nintendo hit <i>Pokemon</i>&#8230;
the same game that sold 5 bajillion copies, against some series which
sold something like 0.1 bajillion copies? (It doesn't matter what a
bajillion is, it's all about the ratio!) Basically what I mean to say
is, Pokemon has the <i>huge</i> exposure advantage in this match. But
is that enough? Back in 2004 it wasn't, when Pokemon GSC went down to
the likes of Xenogears. 2003 and 2002? Poor lil Pikachu struggled to
beat <i>Pafreakingrappa</i> and got his ass kicked a couple of times in his other matches!<br><br>So
from its past appearances, it's safe to say the site hates Pokemon
enough to give it the loss against all but the fodderyist of fodder?
Well you know what? I don't think so. It's obvious that the voters <i>did</i>
at one time, but I sense that the Pokemon hate has gone down now that
we aren't being force-fed yellow rat at every opportunity. Let's face
it, the series became popular for a reason, and I think that the people
are starting to realize that once again. Evidence? Well, aside from
observations over the boards (boards != site&#8230; yeah yeah&#8230; shut up!) and
in life, you can also notice that Pokemon Red (I personally preferred
Blue, but I digress) grabbed a pretty respectable #28 in the top 100
list from last year.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/3/2006 4:37:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317096932">message detail</a>
 | #171</td></tr>
<tr class="even">
<td>
Yes, it's true, you can't anti-vote in the top 100 list, and it may not
be a hugely reliable gauge of strength, but I still think it looks good
for Pokemon. I really doubt all of the Pokemon anti-voters were always
anti-Pokemon crusaders. Surely, some of them played it, enjoyed it, and
then got sick of the overexposure. I've seen it happen. But now those
crusaders, they're turning around and saying&#8230; "man, Pokemon isn't so
bad! I liked Pokemon for the Gameboy back in the day!", and so they
vote for Pokemon when they wouldn't have a while back.<br><br>And the thing is, it's just <i>Star Ocean</i>
Pokemon has to beat. We don't need a Pokemon Pride Parade, here. Star
Ocean isn't quite "cult", but it's pretty bloody close as far as
GameFAQs popularity is concerned. It's not much more of a threat than
Xenogears, if at all.<br><br>And even if you aren't convinced and you don't think the hate hasn't gone down <i>one bit</i>,
think about this: It's also possible (probable, I'd say!) that Pokemon
RBY are significantly more popular than Pokemon GSC and Pikachu, which
would help Pokemon. Hardly an unreasonable assumption, is it?<br><br><b>Lopen's Prediction:</b> Pokemon with 56.08%<br> <br> <br> <br><b>HM&#8217;s Analysis</b><br><br>Ah,
yes, Pokemon v. Star Ocean is one that I have argued over since the
bracket was released. For some reason, everyone seems to shrug off Star
Ocean as if it didn&#8217;t stand a chance of winning, but I think it&#8217;s going
to end up shocking <i>a lot</i> of people once the match results come in. Not only is Star Ocean going to put up a great fight, but it&#8217;s going to <i>win</i>--you heard it here, folks!<br><br>Initially,
I actually had Pokemon winning the match in my bracket, but I was just
going through quickly to make all my initial decisions. When I saw who
Pokemon was up against, I hesitated for a moment, but went with the
safe pick. It wasn&#8217;t until later on that I came to the realization that
Xenogears, who faced Pokemon G/S/C in the Games Contest, had beaten
it&#8212;and rather convincingly at that. With that tidbit in mind, I went
back to change to Star Ocean, because I just knew that Star Ocean 3
would beat Xenogears in a match-up, and Xenogears had mauled Pokemon
G/S/C.<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1618" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1618">http://www.gamefaqs.com/poll/index.html?poll=1618</a><br><br>Interestingly,
I recall the match was closer when only registered members of GameFAQs
could vote&#8212;you had to have an account in order to cast a vote. It was a
strange glitch, but <i>after</i> it was fixed, Xenogears won by even <i>more</i>.
I think, more than anything, it helped to prove that Pokemon is by no
means a powerhouse franchise here at GameFAQs. I have no doubt in my
mind that the Pokemon hate still lingers even to this day, as there has
not been anything notable that would change people from hating to
liking it in just two short years. Further, Pokemon is not enjoying the
same popularity it did back in the days of R/B/Y; not only in public
opinion, but also in sales. I think it is very safe to say that
ridicule and dislike toward the series still exists on a pretty
significant scale to this day, which does not spell good things when it
goes up against a series that people do like, even if it&#8217;s not played
on the same widespread scale.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/3/2006 4:38:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317097069">message detail</a>
 | #172</td></tr>
<tr class="even">
<td>
It should be pretty clear at this point that Star Ocean does <i>not</i>
need to be a significant franchise in order to pull out a victory
against Pokemon. One might bring up Pokemon Red/Blue/Yellow, but I
can&#8217;t imagine that it would help out the series <i>significantly</i>
at all. If you have played one Pokemon game, you have more or less
played them all. Sure, there are some that are better than others, and
each adds something new in an attempt to make it fresh (more Pokemon,
double team battles, day/night, breeding, etc.), but it essentially is
the same game even after all these years, or at least the basic concept
has remained intact. I&#8217;m sure that Pokemon will be <i>stronger</i> due to people like R/B/Y more than others just because it was during the big craze, but it wouldn&#8217;t be <i>that</i>
much stronger to where this is out of Star Ocean&#8217;s reach. As an
example, I wouldn&#8217;t take Pokemon R/B/Y over Xenogears, or even give
that match a second thought. And just as a refresher course, Pokemon
G/S/C ended up around Donkey Kong, Duck Hunt, Resident Evil, and Secret
of Mana in the extrapolated standings. Of course, there is the Final
Fantasy VII/Xenogears SFF to take into consideration, but I wouldn&#8217;t
picture it being all that significant. It was certainly there, but not
quite in the large scale that some want to believe.<br><br>However, I&#8217;m <i>not</i>
relying on Pokemon&#8217;s weakness and its anti-votes; rather, I&#8217;m banking
on the popularity of Star Ocean, which seems to be grossly
underestimated on the board for some reason (I could only assume it was
because it never really became a board &#8220;fad&#8221; along the lines of Tales
of Symphonia or Phoenix Wright), mixed with those said
anti-votes&#8212;they&#8217;re always worth taking into consideration when it&#8217;s
Pokemon. Oddly enough, one of the biggest misconceptions about Star
Ocean is that it is <i>obscure</i> or <i>cult</i>, which could not be
further from the truth. There was never any argument to back up Star
Ocean being cult, and when its sales for the latest entry hit 630,000
in America alone, I think it is pretty justified in being far above an
obscure RPG or an obscure RPG franchise&#8212;the entire series has sold over
two million copies worldwide, which is pretty solid for an RPG series
not named &#8220;Final Fantasy.&#8221;<br><br>Fortunately, I managed to come across some Star Ocean sales for the <i>entire</i> franchise over at tri-Ace&#8217;s website. I wouldn&#8217;t dare think about using sales as a way to <i>prove</i> the strength of a series, especially against something like Pokemon, but this simply goes to show that Star Ocean is <i>not</i> cult, obscure, or unheard of among gamers. It has had two releases here in America, and both received very good sales&#8230;<br><br>1.) Star Ocean (SNES)<br>Japan -- 235,000<br>America -- N/A<br><b>Total:</b> 235,000<br><br>2.) Star Ocean : The Second Story (PSX)<br>Japan -- 724,000<br>America -- 370,000<br><b>Total:</b> 1.09 million<br><br>3.) Star Ocean : Blue Sphere (GBC)<br>Japan -- 130,000<br>America -- N/A<br><b>Total:</b> 130,000<br><br>4.) Star Ocean 3 : Till the End of Time (PS2)<br>Japan -- 478,000<br>America -- 630,000 [This is a more accurate number according to NPD's recently released]<br><b>Total:</b> 1.10 million<br><br>5.) Star Ocean 3 : Till the End of Time - Director's Cut (PS2)<br>Japan -- 164,000<br><b>Total:</b> 164,000<br><br>(<a class="linkification-ext" href="http://www.tri-ace.com/en/company/sales.html" title="Linkification: http://www.tri-ace.com/en/company/sales.html">http://www.tri-ace.com/en/company/sales.html</a>)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/3/2006 4:39:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317097302">message detail</a>
 | #173</td></tr>
<tr class="even">
<td>
As you can clearly see, Star Ocean 2 and Star Ocean 3 both sold very
well over here, especially the latter. To give a comparison, Star Ocean
2&#8217;s sales are comparable to Dragon Quest VIII&#8217;s (400,000) and Xenosaga
Episode I (500,000). It didn&#8217;t sell as much, but it is clearly up there
in sales. Even <i>more</i>
interesting is that those figures surpass that of Xenogears, which sold
239,000 in America. Xenogears is certainly more popular than those
sales figures would indicate, but it&#8217;s hard to give Xenogears so much
credit and undercut Star Ocean when its sales are as good as these.
Gamers have played them, they have heard of them, and it isn&#8217;t cult.
Looking at Star Ocean 3&#8217;s sales, you could even compare those to
Resident Evil 4 and God of War (pre-Greatest Hits) with around the
630,000 number. How <i>crazy</i> is it that people are willing to call <i>that</i> obscure? It just doesn&#8217;t make sense.<br><br>Even
further in Star Ocean&#8217;s favor, the latest entry in the series&#8212;Star
Ocean 3&#8212;has the added benefit of being heavily advertised and by a
company known as &#8220;Square Enix.&#8221; Yes, arguably the biggest company at
this website is the one behind Star Ocean 3 : Till the End of Time,
which I think it a pretty significant factor. It helps out a lot that
the series, or at least the latest entry, is now attached to Square.
More people are likely to give it a look, more people are likely to
play it, and more people are likely to vote for it based entirely off
of the company if they hated/didn&#8217;t care about Pokemon and saw Star
Ocean there. On another note, Star Ocean 3 enjoyed immense success here
on GameFAQs. It peaked as the number one game at one point, and it
stuck around in the Top 10 for a <i>long</i> time before falling off.
Again, it is not to prove its strength; rather, it is to prove that it
was not ignored. It shows that people at GameFAQs took notice to the
game and were playing it, which is big for something like this. <br><br>One
of the unfortunate things about this match is that we have not had the
opportunity to see Star Ocean ever really show off its strength in any
type of contest environment. Heck, it&#8217;s barely had an opportunity in
the standard polls that take place year round on GameFAQs. But, it has
appeared a few times, even if it wasn&#8217;t in the question.<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1872" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1872">http://www.gamefaqs.com/poll/index.html?poll=1872</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1245" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1245">http://www.gamefaqs.com/poll/index.html?poll=1245</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1484" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1484">http://www.gamefaqs.com/poll/index.html?poll=1484</a><br><br>In
the first poll, Star Ocean 3 ended up coming in a solid third behind
Grand Theft Auto : San Andreas (Game of the Year Winner) and Metal Gear
Solid 3&#8212;both huge games. That&#8217;s some extremely stiff competition right
there, so it&#8217;s understandable that it would not dominate the charts. I
mean, I wouldn&#8217;t even be thinking about Star Ocean over Metal Gear or
Grand Theft Auto (though I do wish it were popular enough to go
toe-to-toe with them. Heh), so it&#8217;s placement isn&#8217;t really all that
negative. At the least, it shows it can net some real votes and not be
favored over other &#8220;mainstream&#8221; titles.<br> <br>In the second poll, we
see it coming in fourth of the most anticipated Square Enix games
coming out in the future. There is plenty of &#8220;Final Fantasy&#8221;
competition, which is automatically going to place ahead of anything
else in that poll, but it does have comparable numbers to FFTA&#8212;a pretty
strong game in the games contest&#8212;and FFXI. Again, nothing really
earthshaking, but it does show that there are people who care about the
game quite a bit, which just further removes the idea that it is overly
obscure. <br> <br>In the last poll, Star Ocean places <i>second</i> in
a poll asking what first-quarter PlayStation 2 game are you most
looking forward to. Once again, it has pretty comparable numbers to
FFXI, much like that other poll, but that&#8217;s all that manages to beat
it. It does beat out games like Splinter Cell, Mega Man Anniversary
Collection, StarCraft : Ghost, and Resident Evil : Outbreak. This is
probably the more impressive poll, though there are plenty of options
to choose from.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/3/2006 4:41:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317097685">message detail</a>
 | #174</td></tr>
<tr class="even">
<td>
I would go and grab a bunch of polls that ask about upcoming Nintendo
games or handheld games or whatever where Pokemon gets a small chunk of
the &#8220;most anticipated.&#8221; Even recently, it seems to have the same voters
who will vote for it, but they are in a very small number. Pokemon is
usually last or second to last in any of those polls, regardless of
what competition is there. However&#8230;<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1198" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1198">http://www.gamefaqs.com/poll/index.html?poll=1198</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1198" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1198">http://www.gamefaqs.com/poll/index.html?poll=1198</a><br><br>These
two polls do a fine job of covering the &#8220;Pokemon hate&#8221; that I talked
about earlier. Everyone pretty much knows all about hatred toward the
series, and those polls just reinforce those ideas. The latest one,
admittedly, was taken in 2003, but I can&#8217;t imagine that hate
diminishing by any notable amount over the past two years&#8212;Pokemon&#8217;s
last appearance in a contest. That on top of Star Ocean&#8217;s clear and
present fanbase and pretty solid popularity are leading me to believe
that Star Ocean will pull a victory here &#8230;<br><br>I think Star Ocean is going to have some surprising strength (No, not anything that puts Metroid in danger) that people are <i>really</i>
underestimating. These arguments being tossed around that Pokemon is
going to win decisively or not ever have to worry are ludicrous to me.
What&#8217;s worse is that I have yet to see any argument that supports
Pokemon winning this match in such a way. There is not much debate
surrounding this match on the board, because most people seem to think
Pokemon is the safe choice&#8212;and if you want to be safe, sure. The only
thing I can come up with as to why people would pick Pokemon in this
match is their own unfamiliarity with the Star Ocean series, and just
not looking at the actual facts at hand here. We may not have see Star
Ocean in a contest before, but that is not a negative against it. The
reasonable explanation for that is that Star Ocean 3, the most popular
entry by far, released in August 2004. That essentially means it had <i>one</i>
contest to get in and that was Summer 2005. I don&#8217;t recall a rally ever
being held to get Fayt (the main character) into the contest, and Board
8 has significant influence on the nominations. The games contest &#8230;
well, I wouldn&#8217;t have imagined Star Ocean 2 cracking through that with
the such strict competition&#8212;but I wouldn&#8217;t imagine it being strong
enough to beat something like Xenogears, though Suikoden would be on
the receiving end of beating. <br><br>So yeah. Ultimately, I think
Star Ocean is going to prove to have some pretty solid strength,
Pokemon is going to continue to show its own weakness, and people are
going to continue to think Pokemon is the &#8220;safe choice,&#8221; despite it
proving to be fodder on numerous occasions. We have seen Pokemon on the
losing end against a Square RPG&#8212;Xenogears&#8212;and it&#8217;s in the same
situation here against a more popular Star Ocean. I&#8217;m confident in Star
Ocean pulling out a victory that isn&#8217;t overly close, but isn&#8217;t a
blowout by any means. This&#8217;ll be a much closer match that people are
giving credit, and Star Ocean should at least garner <i>some</i>
respect from this, win or lose. Anyone expecting this match to be
entirely one sided is just not giving this match the thought it
deserves. It may be just one point, but it could end up being a crucial
one point. <br><br>(*waves the Star Ocean flag* Final Fantasy &gt; Star Ocean final in my favorites bracket, yo.)<br><br><b>Aitch Emm&#8217;s Bracket Says :</b> Star Ocean will win.<br><br><b>Aitch Emm&#8217;s Prediction :</b> Star Ocean 53% -- Pokemon 47%<br><br><b>Aitch Emm&#8217;s Vote :</b> Star Ocean.<br> <br> <br> <br>Comments:
WHEW, glad that's done with. Crew is in favor of Pokemon 8-1, but with
HM's write-up, for might as well call it even. Most of us think it will
be close, but Soul smells a easy Pokemon victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=941543&amp;board=8&amp;topic=29002092" class="name">Shivan Reincarnated</a> |
Posted 7/3/2006 5:22:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317107101">message detail</a>
 | #175</td></tr>
<tr class="even">
<td>
Wow<br>---<br><i>"Any society that would give up a little liberty to gain a little security will deserve neither and lose both."</i> ~ Benjamin Franklin</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=409564&amp;board=8&amp;topic=29002092" class="name">Phediuk</a> |
Posted 7/3/2006 5:24:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317107585">message detail</a>
 | #176</td></tr>
<tr class="even">
<td>
Good God, HM. Think of how many hours of your life you wasted rooting for the losing team.<br>---<br>"Thank you, Mario. But our princess is in another castle."<br>-Toad in Super Mario Bros.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=409564&amp;board=8&amp;topic=29002092" class="name">Phediuk</a> |
Posted 7/3/2006 5:25:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317107856">message detail</a>
 | #177</td></tr>
<tr class="even">
<td>
Wait, wait...how does 45% of the GameFAQs population owning Pokemon RS translate to Pokemon hate? Explain this to me.<br>---<br>"Thank you, Mario. But our princess is in another castle."<br>-Toad in Super Mario Bros.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=170417&amp;board=8&amp;topic=29002092" class="name">Blade Of Evils Bane</a> |
Posted 7/3/2006 5:27:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317108227">message detail</a>
 | #178</td></tr>
<tr class="even">
<td>
Hes going to feel pretty stupid for wasting all that time typing that up in a couple of hours... : D<br><br>---<br>Can't think of a good sig.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=965303&amp;board=8&amp;topic=29002092" class="name">SephirothG</a> |
Posted 7/3/2006 5:27:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317108245">message detail</a>
 | #179</td></tr>
<tr class="even">
<td>
Christ, HM...<br>---<br>[Something clever was here before the sig wipe]<br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585012</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=941543&amp;board=8&amp;topic=29002092" class="name">Shivan Reincarnated</a> |
Posted 7/3/2006 5:28:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317108408">message detail</a>
 | #180</td></tr>
<tr class="even">
<td>
It's actually less than 45%. I doubt all 18% that said maybe ended up buying it.<br><br>---<br><i>"Any society that would give up a little liberty to gain a little security will deserve neither and lose both."</i> ~ Benjamin Franklin</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=409564&amp;board=8&amp;topic=29002092" class="name">Phediuk</a> |
Posted 7/3/2006 5:31:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317109199">message detail</a>
 | #181</td></tr>
<tr class="even">
<td>
<a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1872" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1872">http://www.gamefaqs.com/poll/index.html?poll=1872</a><br><br>A Square RPG scoring less than 15% in a GotY poll is not at all impressive.<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1245" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1245">http://www.gamefaqs.com/poll/index.html?poll=1245</a><br><br>HOLY CRAP FIFTH PLACE, in close contention with "None of the above".<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1484" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1484">http://www.gamefaqs.com/poll/index.html?poll=1484</a><br><br>It's
a Square RPG up against a bunch of franchises the GameFAQs populace
doesn't care about. Big ****ing whoop. Aside from that, it still got
beaten by FFXI, which would probably be one of the weakest games in the
main FF series.<br>---<br>"Thank you, Mario. But our princess is in another castle."<br>-Toad in Super Mario Bros.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29002092" class="name">Lopen</a> |
Posted 7/3/2006 5:36:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317110279">message detail</a>
 | #182</td></tr>
<tr class="even">
<td>
Phediuk is kinda right here.  Part of HM's analysis is arguing against himself in my eyes.  I'd have brought those polls up in <i>support</i> of Pokemon.  SO isn't ultimate jobber fodder, but it's hardly looking <i>impressive</i> either.  <br>---<br>Raiden is still [<i>!!</i>] nominations short!  <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/3/2006 5:47:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317112634">message detail</a>
 | #183</td></tr>
<tr class="even">
<td>
<i>Good God, HM. Think of how many hours of your life you wasted rooting for the losing team.</i><br><br>It didn't even take an hour ...<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/3/2006 5:57:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317114820">message detail</a>
 | #184</td></tr>
<tr class="even">
<td>
I hardly touched on Star Ocean itself.  I was more or less arguing for Pokemon.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=721764&amp;board=8&amp;topic=29002092" class="name">Captain Brainslide</a> |
Posted 7/3/2006 6:45:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317124790">message detail</a>
 | #185</td></tr>
<tr class="even">
<td>
Ah, another year, another time to tag this thing so I can find it in
the mess of topics on the board. There's way more posts already than
previous Crew topics, though, which I guess is good except it gets to
500 too fast.<br><br>Oh,
and I do have to hand out props to HM for that latest writeup (I guess
I have a better tolerance/appreciation for length and detail than some
around here). Even if the prediction comes up short, that was well
done. I wouldn't mind at all if Star Ocean wins and kills my zero
bracket early. Still, HM's percentage skills earlier just show that he
hasn't given up his need to change his mind on things quickly, even
after only a few seconds of typing numbers... ;-)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/3/2006 9:37:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317162376">message detail</a>
 | #186</td></tr>
<tr class="even">
<td>
<i>In the last poll, Star Ocean places second in a poll asking what
first-quarter PlayStation 2 game are you most looking forward to. Once
again, it has pretty comparable numbers to FFXI, much like that other
poll, but that&#8217;s all that manages to beat it. It does beat out games
like Splinter Cell, Mega Man Anniversary Collection, StarCraft : Ghost,
and Resident Evil : Outbreak. This is probably the more impressive
poll, though there are plenty of options to choose from.</i><br><br>Splinter
Cell had two games in the Top 100 List's drop-down box -- which
featured 130 games -- and only one game made it (#87)...and it was
still beaten by the two write-ins. MMAC helped Mega Man NONE in 2004.
While the fact that SC:G got cancelled doesn't matter, I wouldn't think
fans of Starcraft would be crazy about a third-person shooter on the
Gamecube. RE:O wasn't quite so hyped, if memory serves me right -- I
think that was around the time the RE brand-name was startin' to be
slung into mud before RE4 saved the franchise.<br><br>SO should do good for itself, and it could win...but just don't push your arguement too far out there HM.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29002092" class="name">UltimaterializerX</a> |
Posted 7/3/2006 9:38:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317162724">message detail</a>
 | #187</td></tr>
<tr class="even">
<td>
Man, I got boxed in hardcore.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), FE8, WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/3/2006 9:47:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317164607">message detail</a>
 | #188</td></tr>
<tr class="even">
<td>
I'm boxed worse than you Ulti, and I still plan to win the point on this match.  =P<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/3/2006 9:50:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317165481">message detail</a>
 | #189</td></tr>
<tr class="even">
<td>
I also want to point out a mistake I made in my Suikoden/MMX analysis...<br><br><i>---N/A (neither series had games on the drop-down list)</i><br><br>...Suikoden 2 was actually #57.  Sucks for me!<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=456743&amp;board=8&amp;topic=29002092" class="name">Sir Bormun</a> |
Posted 7/3/2006 10:24:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317173522">message detail</a>
 | #190</td></tr>
<tr class="even">
<td>
<a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1872" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1872">http://www.gamefaqs.com/poll/index.html?poll=1872</a><br><br>Oh
my God, it beat Ratchet and Clank: Up Your Arsenal! I've been such a
fool, there's no way Pokemon can contend with this monolith of a series!<br><br>Seriously...
ya. That was a pretty pathetic showing. And SO3 was the ONLY RPG in the
poll. On a site that was, at least then, RPGFAQs, that's a damned
terrible showing.<br>---<br>Need new sig.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29002092" class="name">BlAcK TuRtLe</a> |
Posted 7/3/2006 11:05:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317183339">message detail</a>
 | #191</td></tr>
<tr class="even">
<td>
I have 55.01%. Let's see how I stack up.<br><br><br><b>TuRtLe</b><br>~~~<br>Like Darth Maul, the bastard child of Michael Flatley and Hellboy. -trancer1</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3122769&amp;board=8&amp;topic=29002092" class="name">Jarvis_Clarinet</a> |
Posted 7/3/2006 11:12:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317184911">message detail</a>
 | #192</td></tr>
<tr class="even">
<td>
I think it's safe to say that Soul wins... about eleven minutes into the poll...<br><br>Wow.<br>---<br>Original Account: Doctor Clarinet; Created 11/1/03; Banned 8/18/05</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/3/2006 11:41:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317191276">message detail</a>
 | #193</td></tr>
<tr class="even">
<td>
HM got BLASTED in this match.<br><br>I pity him, really -- I thought it would be close as well (in Poke's favor though), like many of us...but holy ****.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/3/2006 11:42:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317191509">message detail</a>
 | #194</td></tr>
<tr class="even">
<td>
I doubted Pokemon's blowout ability.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/4/2006 12:04:44 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317195995">message detail</a>
 | #195</td></tr>
<tr class="even">
<td>
First of many, hopefully.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br><i>^5 SOWL IMHO</i> - Explicit Content</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/4/2006 12:09:43 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317196913">message detail</a>
 | #196</td></tr>
<tr class="even">
<td>
I did in this match for sure. I wouldn't have said the series is unable
to perform blow-outs...but I certainly wouldn't have thought we would
see one here.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/4/2006 12:12:56 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317197538">message detail</a>
 | #197</td></tr>
<tr class="even">
<td>
Oh, and I believe I get a point for the Suikoden/MMX match...if so, hells yeah.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=7953&amp;board=8&amp;topic=29002092" class="name">Ngamer64</a> |
Posted 7/4/2006 12:23:27 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317199587">message detail</a>
 | #198</td></tr>
<tr class="even">
<td>
Glad I didn't pick against Nintendo this year!  Hoo boy!<br><br>---<br>"lol x-stats" - The Contest Simulator: <b><a class="linkification-ext" href="http://thengamer.com/xstats" title="Linkification: http://thengamer.com/xstats">http://thengamer.com/xstats</a></b><br>Ngamer's Contest Archives: <a class="linkification-ext" href="http://thengamer.com/gamefaqs/" title="Linkification: http://thengamer.com/gamefaqs/">http://thengamer.com/gamefaqs/</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3381640&amp;board=8&amp;topic=29002092" class="name">zman804</a> |
Posted 7/4/2006 1:11:33 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317208331">message detail</a>
 | #199</td></tr>
<tr class="even">
<td>
Tag.<br>---<br>Skunk Gold Panda Revolution... I'd so buy that!<br>-Dingle_Dootie</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=985004&amp;board=8&amp;topic=29002092" class="name">Metal Goomba</a> |
Posted 7/4/2006 9:09:43 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=317246947">message detail</a>
 | #200</td></tr>
<tr class="even">
<td>
Tag<br>---<br>Now Playing: Super Mario RPG: Legend of the Seven Stars</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">1</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=1">2</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=2">3</a></li>
<li>      4</li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=4">5</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=5">6</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=6">7</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=7">8</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=8">9</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=9">10</a></li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage4_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29002092&amp;page=3" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage4_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>