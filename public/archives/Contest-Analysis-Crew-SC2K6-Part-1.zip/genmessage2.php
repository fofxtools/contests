<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><title>GameFAQs: Message List</title>

<link rel="stylesheet" type="text/css" href="genmessage2_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage2_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage2_files/bc.css"></head><body linkifytime="141" linkified="6" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage2_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage2_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29002092%26page%3D1"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage2_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div><a href="http://adlog.com.com/adlog/c/r=10153&amp;s=668760&amp;t=2006.07.11.19.55.19&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=00c17-gne-ad244B3BA192E7A66/http://www.gamespot.com/pc/action/snowblind/index.html?q=project%20snowblind" target="_blank"><img src="genmessage2_files/pr_snowblind_leader_buyit.jpeg" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage2_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29002092&amp;page=1">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29002092" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">First
          Page</a> |
          Page 2 of 10          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=2">Next
          Page</a>
          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=9">Last
          Page</a>
      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29002092" class="name">BlAcK TuRtLe</a> |
Posted 7/1/2006 8:09:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316701128">message detail</a>
 | #051</td></tr>
<tr class="even">
<td>
I can't see there being noticeable SFF in that match, just an overall
beatdown by LoZ. But, you're the fancy Analysis Crew member and I'm
just the lowly n00b.<br><br><br><b>TuRtLe</b><br>~~~<br>Like Darth Maul, the bastard child of Michael Flatley and Hellboy. -trancer1</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/1/2006 8:13:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316701878">message detail</a>
 | #052</td></tr>
<tr class="even">
<td>
<i>MMX is not going to suffer any notable SFF in that match. </i><br><br>Ummm...
yes it will. MMX is basically a SNES series. Sure it went on to
continue on the Playstation, but outside of X4, its most popular games
are all on the SNES. And the majority of its fanbase probably started
there.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/1/2006 8:14:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316701988">message detail</a>
 | #053</td></tr>
<tr class="even">
<td>
Not like it matters. Zelda would blow it out either way.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/1/2006 8:17:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316702663">message detail</a>
 | #054</td></tr>
<tr class="even">
<td>
Of course, but people are questioning SFF between them like it has no possibility of happening.  MMX is basically a SNES series.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/1/2006 8:21:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316703378">message detail</a>
 | #055</td></tr>
<tr class="even">
<td>
<i>Ummm... yes it will. MMX is basically a SNES series. Sure it went on
to continue on the Playstation, but outside of X4, its most popular
games are all on the SNES. And the majority of its fanbase probably
started there.</i><br><br>That is absurd. It has <i>three</i> games on a Nintendo platform and <i>every</i>
other game on another platform, dominatly the PS brand. It is
ridiculous to think there will be some significant SFF because of that.
It is <i>not</i> a SNES only series, it is <i>not</i> essentially a Nintendo series. The entire idea of that is stupid. <br><br>That
case works for the original Mega Man because all of its games with the
exception of one appear on a Nintendo platform (NES dominantly). Will
there be some SFF? Sure. Will it be significant? Not at all. This'll be
a blowout anyway, but MMX is not going to get SFFed by any Nintendo
series in a notable way. Hell, Zero didn't even receive much SFF
against <i>Mario</i> for crying out loud. <br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/1/2006 8:29:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316704704">message detail</a>
 | #056</td></tr>
<tr class="even">
<td>
<i>That is absurd. It has three games on a Nintendo platform and every
other game on another platform, dominatly the PS brand. It is
ridiculous to think there will be some significant SFF because of that.
It is not a SNES only series, it is not essentially a Nintendo series.
The entire idea of that is stupid.<br><br>That case works for the
original Mega Man because all of its games with the exception of one
appear on a Nintendo platform (NES dominantly). Will there be some SFF?
Sure. Will it be significant? Not at all. This'll be a blowout anyway,
but MMX is not going to get SFFed by any Nintendo series in a notable
way. Hell, Zero didn't even receive much SFF against Mario for crying
out loud. </i><br><br>Where the hell do you think most of the people
who played those PS game started? You surely don't think that the
Playstation games are more popular than the SNES games? The PS2 games
are irrelevant... do you think those games <i>really</i> brought new
fans to the series? It doesn't matter that there are more games on the
PS. The roots of MMX are on the SNES. Open your damn eyes. How much the
series gets SFF'd is another story, as the strength of LoZ is already
going to be so much over it, but don't act like the roots of MMX isn't
primarily Nintendo... Hell, it's not like Mega Man himself is only
represented by the NES. Mega Man is in all of the X games too. He <i>still</i> got SFF'd by Link.  Zero didn't get SFF'd as much by Mario, but it still was there.<br><br>Besides, this is <i>games</i>, not characters.  How can you be so adamant about SMW SFFing Sonic 2, yet vehemently deny that LoZ will not be SFFing MMX?<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2636207&amp;board=8&amp;topic=29002092" class="name">expaniol</a> |
Posted 7/1/2006 8:29:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316704822">message detail</a>
 | #057</td></tr>
<tr class="even">
<td>
Tag<br>---<br>Midgar Zolom for SC2K6</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/1/2006 8:30:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316705007">message detail</a>
 | #058</td></tr>
<tr class="even">
<td>
I'm willing to bet that MMX will be stronger than what its final X-stats value is.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29002092" class="name">BlAcK TuRtLe</a> |
Posted 7/1/2006 8:32:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316705344">message detail</a>
 | #059</td></tr>
<tr class="even">
<td>
HM brings up a good point. Zero did decently against <i>Mario</i>, the king of random SFF. Not that we'll know either way, since it will be pretty much a 75-25 blowout.<br><br><br><b>TuRtLe</b><br>~~~<br>Like Darth Maul, the bastard child of Michael Flatley and Hellboy. -trancer1</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/1/2006 8:33:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316705470">message detail</a>
 | #060</td></tr>
<tr class="even">
<td>
No, Zelda/Link is the king of SFF, not Mario.<br><br>And I'd wager that Mario overperformed on Zero somewhat.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/1/2006 8:35:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316705913">message detail</a>
 | #061</td></tr>
<tr class="even">
<td>
Mario did overperform, at least based against our pre-match expectations. Everyone was surprised at how easily Mario won.<br>---<br><b>Board 8</b>: Where <i>Wii</i> treat each other <i>right</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/1/2006 8:36:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316706084">message detail</a>
 | #062</td></tr>
<tr class="even">
<td>
<i>HM brings up a good point. Zero did decently against Mario, the king
of random SFF. Not that we'll know either way, since it will be pretty
much a 75-25 blowout.</i><br><br>Zero still did worse than he was expected to.  And it's not like Link SFF'd Mega Man to the ground.  But we're talking about <i>games</i>.
We've seen SMW absolutely thrash Sonic 2, and we've seen OoT destroy
Goldeneye, which is probably a good deal stronger than it shows if the
Top 100 list is any indication. I seriously doubt the Playstation games
will be enough to prevent LoZ making MMX look bad. And remember that
MMX is a more popular series than the Mega Man series. It would
probably beat a number of series in this contest. With an eminent
beatdown from LoZ, that most likely won't be shown in the X-stats.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/1/2006 8:37:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316706271">message detail</a>
 | #063</td></tr>
<tr class="even">
<td>
<i>Where the hell do you think most of the people who played those PS
game started? You surely don't think that the Playstation games are
more popular than the SNES games? The PS2 games are irrelevant... do
you think those games really brought new fans to the series? It doesn't
matter that there are more games on the PS. The roots of MMX are on the
SNES. Open your damn eyes. How much the series gets SFF'd is another
story, as the strength of LoZ is already going to be so much over it,
but don't act like the roots of MMX isn't primarily Nintendo...</i><br><br>The roots of nearly <i>every</i>
franchise today began on a Nintendo platform. It is ludicrous to call
Mega Man X a "Nintendo franchise" or expect to get heavily SFFed in the
match against Zelda. The fact that it <i>began</i> on a system does not mean the Nintendo fanbase is the one attached to these games. <br><br>The
three Mega Man X games that appeared on the SNES were also ported over
to the PSX later on, too. I would fully expect there to be <i>some</i>
SFF in this match because of these roots, but on a significant level?
Forget that. No Nintendo series is going to "SFF" Mega Man X in a
notable manner. <i>Nothing</i> even remotely points to that being the
case. Zero is the best representation of the X series in these contests
and he isn't getting SFFed by any other Nintendo character in a notable
manner.<br><br><i>Hell, it's not like Mega Man himself is only
represented by the NES. Mega Man is in all of the X games too. He still
got SFF'd by Link. Zero didn't get SFF'd as much by Mario, but it still
was there.</i><br><br>Yes, it was there. I also said there would be
some here, too. The difference is that it is not ever going to be on a
significant level that makes it worth mentioning. And the amount of SFF
Zero received is not really what I would consider notable. It was
likely to be about 1%, which could occur in almost any given match.<br><br><i>Besides,
this is games, not characters. How can you be so adamant about SMW
SFFing Sonic 2, yet vehemently deny that LoZ will not be SFFing MMX?</i><br><br>Super
Mario World and Sonic 2 are a lot more alike than Zelda and MMX. The
entire reason I believe that SMW and Sonic 2 featured SFF is because of
the fact that they're both really popular platformers from an era when
Mario and Sonic were considered pretty big rivals. MMX and Zelda only
relate in the fact that they both appeared on the SNES.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/1/2006 8:40:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316706734">message detail</a>
 | #064</td></tr>
<tr class="even">
<td>
<i> It would probably beat a number of series in this contest. With an
eminent beatdown from LoZ, that most likely won't be shown in the
X-stats.</i><br><br>The series it would beat it is still going to be
above. It may be a few percentage points off from what it would
normally be, but it won't be drastically off.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/1/2006 8:56:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316709918">message detail</a>
 | #065</td></tr>
<tr class="even">
<td>
<i>The three Mega Man X games that appeared on the SNES were also
ported over to the PSX later on, too. I would fully expect there to be
some SFF in this match because of these roots, but on a significant
level? Forget that. No Nintendo series is going to "SFF" Mega Man X in
a notable manner. Nothing even remotely points to that being the case.
Zero is the best representation of the X series in these contests and
he isn't getting SFFed by any other Nintendo character in a notable
manner.</i><br><br>Who the hell actually <i>has</i> the PSX ports of
the first 3 games? 95% of the fans of the first 3 MMX games probably
played them on the SNES, if you don't take into account MMXC. The
series wasn't nearly as popular on the PSX as it was for the SNES, and
I doubt that those games brought a significant number of fans to the
series. The MMX series was one of the top series on the SNES. Can you
say the same for the PSX? I really, <i>really</i> doubt that the PSX
and PS2 MMX games fanbase is really separate from the SNES games. Those
gamers most likely started with the SNES games.<br><br><i>Super Mario
World and Sonic 2 are a lot more alike than Zelda and MMX. The entire
reason I believe that SMW and Sonic 2 featured SFF is because of the
fact that they're both really popular platformers from an era when
Mario and Sonic were considered pretty big rivals. MMX and Zelda only
relate in the fact that they both appeared on the SNES.</i><br><br>Please
don't play the genre card. It's really a lame argument outside of RPGs.
MMX started as a SNES series. A Link to the Past is one of the most
popular games <i>on </i> that system. There is bound to be SFF between
them. When you try to break down between adventure and action, the
genre lines are hardly noticeable as far as having separate fanbases.
It's not like either genre is niche by any means. I could see if you
were talking about RTS or something. Action and adventure games pretty
much appeal to <i>everyone</i>.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/1/2006 8:57:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316710127">message detail</a>
 | #066</td></tr>
<tr class="even">
<td>
On a side-note, do you have the sales of MMAC and MMXC for each system?  I want to see how much a role those will play.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/1/2006 9:00:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316710903">message detail</a>
 | #067</td></tr>
<tr class="even">
<td>
MMAC sold about 250,000 on the PS2 and GCN each. MMXC sold 78,000 on the PS2 and 55,000 on the GCN.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/1/2006 9:02:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316711243">message detail</a>
 | #068</td></tr>
<tr class="even">
<td>
<i>MMAC sold about 250,000 on the PS2 and GCN each. MMXC sold 78,000 on the PS2 and 55,000 on the GCN.</i><br><br>Wow, those MMXC sales <i>really</i> suck.  So much for bringing new fans to the series... :(  <br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/1/2006 9:03:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316711419">message detail</a>
 | #069</td></tr>
<tr class="even">
<td>
Probably not too far from the average for a Mega Man game, actually. &lt;&lt;<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/1/2006 9:04:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316711606">message detail</a>
 | #070</td></tr>
<tr class="even">
<td>
Yeah, Mega Man on the average doesn't sell too well...<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/1/2006 9:30:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316716767">message detail</a>
 | #071</td></tr>
<tr class="even">
<td>
Therealmnm is already showin' why I hope he does the best out of us (besides me) with this MMX arguement.  Good show.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/1/2006 9:33:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316717409">message detail</a>
 | #072</td></tr>
<tr class="even">
<td>
There are no allies in the Analysis Crew! Only acquaintances!<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/1/2006 9:35:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316717693">message detail</a>
 | #073</td></tr>
<tr class="even">
<td>
And losers.  Don't forget about losers, <i>Leon</i>.....<br><br>*glares*<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=433611&amp;board=8&amp;topic=29002092" class="name">ad00</a> |
Posted 7/1/2006 9:35:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316717800">message detail</a>
 | #074</td></tr>
<tr class="even">
<td>
It begins! (before the first vote even cast too...)<br><br>Tag'd.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/1/2006 9:35:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316717849">message detail</a>
 | #075</td></tr>
<tr class="even">
<td>
Don't be jealous because you know you've lost to me before we've even begun!<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2266918&amp;board=8&amp;topic=29002092" class="name">KamikazePotato</a> |
Posted 7/1/2006 9:35:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316717883">message detail</a>
 | #076</td></tr>
<tr class="even">
<td>
<i>The Legend of Zelda 84% -- Civilization 12%</i><br><br>HM failed math class.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/1/2006 9:36:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316718009">message detail</a>
 | #077</td></tr>
<tr class="even">
<td>
You're all losers compared to me!<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=722305&amp;board=8&amp;topic=29002092" class="name">Dilated Chemist</a> |
Posted 7/1/2006 9:36:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316718025">message detail</a>
 | #078</td></tr>
<tr class="even">
<td>
I would like to request a analysis crew spot for the next topic, please...<br><br>---<br><b>=DC=</b><br>Chemistry
can be a good and bad thing. Chemistry is good when you make love with
it. Chemistry is bad when you make crack with it.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/1/2006 9:37:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316718165">message detail</a>
 | #079</td></tr>
<tr class="even">
<td>
<i>HM failed math class.</i><br><br>I really did ... multiple times.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/1/2006 9:37:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316718228">message detail</a>
 | #080</td></tr>
<tr class="even">
<td>
You'll have to wait 'til 2007, DC.<br><br>Also, HM posted that so he could try to swing a point and say "Oh, I really meant THIS!"<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/1/2006 9:38:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316718463">message detail</a>
 | #081</td></tr>
<tr class="even">
<td>
Stop ruining my plans<i>!!</i><br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2266918&amp;board=8&amp;topic=29002092" class="name">KamikazePotato</a> |
Posted 7/1/2006 9:41:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316719041">message detail</a>
 | #082</td></tr>
<tr class="even">
<td>
I might as well be in the next Contest Analysis Crew as well.<br><br><i>Someone</i> needs to be the bottom of the barrel.<br><br>---<br>Angsty_Lou: Everything has a sexual connotation if you just look long and hard enough.<br>Theo72: U SED LONG AND HARD LOL</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3191556&amp;board=8&amp;topic=29002092" class="name">LegendarySnake</a> |
Posted 7/1/2006 9:46:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316720025">message detail</a>
 | #083</td></tr>
<tr class="even">
<td>
Lopen fills that role well enough!<br>---<br>I am the man who makes the impossible possible. I am the man, the legend: Solid Snake!</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/1/2006 9:48:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316720469">message detail</a>
 | #084</td></tr>
<tr class="even">
<td>
Your puny quips cannot harm Lopen. Only his hilarious brackets can do that!<br>---<br><b>Board 8</b>: Where <i>Wii</i> treat each other <i>right</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/1/2006 10:20:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316727685">message detail</a>
 | #085</td></tr>
<tr class="even">
<td>
That and kryptonite.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/1/2006 10:27:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316729135">message detail</a>
 | #086</td></tr>
<tr class="even">
<td>
<i>The Legend of Zelda 84% -- Civilization 12%</i><br><br>Yeah...I fixed it in the Stats topic, but I missed it here. &gt;.&gt;<br><br>And you don't exactly sign up for the Crew. It goes more by invitation.<br>---<br>Moltar Status: Eagerly awaiting for the next Contest to begin.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3201793&amp;board=8&amp;topic=29002092" class="name">Ed Bellis</a> |
Posted 7/1/2006 10:42:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316732207">message detail</a>
 | #087</td></tr>
<tr class="even">
<td>
Tag. Looking forward to this season of analyses, guys. DON'T LET ME DOWN OR I MIGHT SHOVE A TREE ONTO YOUR HOUSES<br>---<br>This was Ed Bellis. Summer 2005 Fanfiction Project:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=28403845" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=28403845">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=28403845</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/1/2006 10:47:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316733333">message detail</a>
 | #088</td></tr>
<tr class="even">
<td>
<i>I might as well be in the next Contest Analysis Crew as well.<br><br>Someone needs to be the bottom of the barrel.</i><br><br>Don't worry, by the looks of the predictions, that person will be me. <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br><i>^5 SOWL IMHO</i> - Explicit Content</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/1/2006 10:49:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316733686">message detail</a>
 | #089</td></tr>
<tr class="even">
<td>
<i>Tag. Looking forward to this season of analyses, guys. DON'T LET ME DOWN OR I MIGHT SHOVE A TREE ONTO YOUR HOUSES</i><br><br>lol, nothing but palm trees around my house fool!<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3201793&amp;board=8&amp;topic=29002092" class="name">Ed Bellis</a> |
Posted 7/1/2006 10:50:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316733965">message detail</a>
 | #090</td></tr>
<tr class="even">
<td>
Palm trees can still CRUSH A HUMAN BEING<br><br>On another note, I totally wanna be in this next year, just so there can be somebody overly ridiculous to laugh at. &gt;_&gt;<br>---<br>This was Ed Bellis. Summer 2005 Fanfiction Project:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=28403845" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=28403845">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=28403845</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29002092" class="name">SquallidSnake</a> |
Posted 7/1/2006 10:52:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316734329">message detail</a>
 | #091</td></tr>
<tr class="even">
<td>
Once again, Lopen fulfills that role well enough!<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2266918&amp;board=8&amp;topic=29002092" class="name">KamikazePotato</a> |
Posted 7/1/2006 10:53:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316734541">message detail</a>
 | #092</td></tr>
<tr class="even">
<td>
I can fill that role even better!<br><br>POKEMON&gt;METROID LAWL<br><br>---<br>Angsty_Lou: Everything has a sexual connotation if you just look long and hard enough.<br>Theo72: U SED LONG AND HARD LOL</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29002092" class="name">SquallidSnake</a> |
Posted 7/1/2006 10:53:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316734626">message detail</a>
 | #093</td></tr>
<tr class="even">
<td>
No, if we wanted outlandish predictions, we would've kept Inviso and Vlado.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3201793&amp;board=8&amp;topic=29002092" class="name">Ed Bellis</a> |
Posted 7/1/2006 10:54:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316734751">message detail</a>
 | #094</td></tr>
<tr class="even">
<td>
LAWL DEVIL MAY CRY WITH LIEK 58 PERCENT<br><br>LAWL ELDER SCROLLS GETS TEH RECOGNIZABLE BOXORT AND WILL BREAK 45 ON RESIDENT EVIL<br><br>LAWL MNM IS GETTING A PALM TREE TO THE FACE TONIGHT<br>---<br>This was Ed Bellis. Summer 2005 Fanfiction Project:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=28403845" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=28403845">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=28403845</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=722305&amp;board=8&amp;topic=29002092" class="name">Dilated Chemist</a> |
Posted 7/1/2006 10:57:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316735505">message detail</a>
 | #095</td></tr>
<tr class="even">
<td>
I meant next contest....<br><br>I would like to request a analysis crew spot for the next <i>contest</i>, please...<br><br>---<br><b>=DC=</b><br>Chemistry
can be a good and bad thing. Chemistry is good when you make love with
it. Chemistry is bad when you make crack with it.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29002092" class="name">BlAcK TuRtLe</a> |
Posted 7/2/2006 12:08:41 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316750758">message detail</a>
 | #096</td></tr>
<tr class="even">
<td>
Also let me say how absolutely thrilled I am that Inviso and Vlado are
dumped. Now this crew can be more about analysing the contest and less
about bashing popular games.<br><br><br><b>TuRtLe</b><br>~~~<br>Like Darth Maul, the bastard child of Michael Flatley and Hellboy. -trancer1</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29002092" class="name">SquallidSnake</a> |
Posted 7/2/2006 12:10:03 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316750992">message detail</a>
 | #097</td></tr>
<tr class="even">
<td>
Well, this crew stays the same for the Character Contest with no new additions, so it'll have to be at least 2007.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/2/2006 1:57:58 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316769260">message detail</a>
 | #098</td></tr>
<tr class="even">
<td>
Looks like we're setting records for length now, but that may just be
due to the contest itself. It seems a lot easier to write about an
entire series than one character.<br><br>Yes, this post is completely out of the blue.<br>---<br><b>Board 8</b>: Where <i>Wii</i> treat each other <i>right</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2382766&amp;board=8&amp;topic=29002092" class="name">WaterMario222</a> |
Posted 7/2/2006 2:17:07 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316771621">message detail</a>
 | #099</td></tr>
<tr class="even">
<td>
tag</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=722305&amp;board=8&amp;topic=29002092" class="name">Dilated Chemist</a> |
Posted 7/2/2006 7:29:33 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=316792822">message detail</a>
 | #100</td></tr>
<tr class="even">
<td>
<i>LeonhartForever<br>Posted 7/1/2006 2:33:25 PM<br>message detail On
the contrary, yours is way too high. Civilization is NOT a bottom
feeder series, like everyone seems to think.</i><br><br>DC - 1<br>Leon - 0<br> <br>---<br><b>=DC=</b><br>Chemistry
can be a good and bad thing. Chemistry is good when you make love with
it. Chemistry is bad when you make crack with it.</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">1</a></li>
<li>      2</li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=2">3</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=3">4</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=4">5</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=5">6</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=6">7</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=7">8</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=8">9</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=9">10</a></li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage2_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29002092&amp;page=1" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage2_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>