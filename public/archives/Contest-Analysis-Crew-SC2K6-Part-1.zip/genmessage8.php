<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"><title>GameFAQs: Message List</title>

<link rel="stylesheet" type="text/css" href="genmessage8_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage8_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage8_files/bc.css"></head><body linkifytime="200" linkified="15" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage8_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage8_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29002092%26page%3D7"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage8_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div><a href="http://adlog.com.com/adlog/c/r=10153&amp;s=673833&amp;t=2006.07.11.19.55.36&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=01c17-gne-ad244B3BA192E31DC/http://www.gamespot.com/pc/sim/worldwariisquadron/index.html?q=blazing%20angels" target="_blank"><img src="genmessage8_files/blazing_angels_leader_buyit.jpeg" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage8_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29002092&amp;page=7">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29002092" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">First
          Page</a> |
          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=6">Previous
          Page</a> |
          Page 8 of 10          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=8">Next
          Page</a>
          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=9">Last
          Page</a>
      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/9/2006 4:42:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318498569">message detail</a>
 | #351</td></tr>
<tr class="even">
<td>
John Madden: &#8220;Thanks, Leon. Do you mind if I call you Leon?&#8221;<br><br>Actually, I do.<br><br>John
Madden: &#8220;Anyway, as my good friend Leon was just saying, this match is
about as obvious as a game between the Indianapolis Colts and the
Houston Texans, but I&#8217;ll tell you what&#8217;s going to happen anyway. First
of all, let me pull out the telestrator. You know I can&#8217;t do a
half-decent analysis without it. On the day of the match, people will
turn on their computers right&#8230;&#8221;<br><br>*cut to picture of a computer, followed by Madden circling the power button*<br><br>&#8220;&#8230;Here.
Of course, once the computer boots up, they will want to open up
Internet Explorer. You can tell what it is by this weird little blue
&#8216;e&#8217; here.&#8221;<br><br>*cut to picture of computer desktop, and Madden circles the Internet Explorer icon*<br><br>&#8220;After that, the average computer user will use what we in football call an address bar, which you can find&#8230;&#8221;<br><br>*circles address bar on Internet Explorer window*<br><br>&#8220;&#8230;Here. From there, it&#8217;s a matter of typing <a class="linkification-ext" href="http://www.gamefaqs.com/" title="Linkification: http://www.gamefaqs.com">www.gamefaqs.com</a>
and you&#8217;ll be taken to the home page of the site. Now, sometimes
finding the poll can be tricky, especially if you&#8217;re a Madden fan and
used to having everything pointed out to you, but it can generally be
found in the upper-right hand corner.&#8221;<br><br>*circles poll location*<br><br>&#8220;From
here, what the fans will want to do is find the option for &#8220;Madden NFL&#8221;
on the poll, which will be on the bottom, as we can see&#8230;&#8221;<br><br>*circles Madden NFL&#8217;s position on the poll*<br><br>&#8220;&#8230;Here. Now, the average voter will want to use the, uhh&#8230;arrow thing, which we see right&#8230;&#8221;<br><br>*circles the arrow all over the screen as someone keeps moving it across the screen*<br><br>&#8220;&#8230;Here. No, here. Wait, it&#8217;s here. Anyway, the arrow will be pointed at this little bubble, as you can see&#8230;&#8221;<br><br>*circles bubble next to &#8220;Madden NFL&#8221;*<br><br>&#8220;&#8230;Here.
Now, all that&#8217;s left to do is click on the bubble, move down to the
&#8220;Vote&#8221; button, and BAM! There&#8217;s one of many votes for my franchise.
From there, you&#8217;ll be taken to a screen that shows how easily the
franchise is winning.&#8221;<br><br>*goes to results page, Madden circles his blue results bar*<br><br>&#8220;As
we can see here, my bar is much, much longer than the one for the
opponent, whoever it is. You can only see a small sliver of a bar for
it anyway. Well, that&#8217;s all. Thanks for having me on, Leon. Be sure to
pick up Madden NFL 2007, which will be almost identical to the last
three games I&#8217;ve released! Everyone else will.&#8221;<br><br>However, this
match does make me sad thinking about it. After this, our beloved
transience will have to close his account and never return. I don&#8217;t
know why he entered a losing battle, but it seems obvious that he&#8217;s
ready to leave this board. He has his reasons. I&#8217;ll just let him know
that he will be missed.<br><br>*salutes*<br><br><i>Leonhart&#8217;s Prediction:</i> <b>Madden NFL with 99.99%</b> (I&#8217;ll probably throw Super Mario Brothers a pity vote to keep it from being a shutout)<br><br>Okay, not really. <br><br><i>Leonhart&#8217;s REAL Prediction</i>: <b>Super Mario Brothers with 90.09%</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/9/2006 4:44:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318498989">message detail</a>
 | #352</td></tr>
<tr class="even">
<td>
Comments: Oops, I posted Lopen's twice by accident. Oh well...Crew says SMB wins tommorrow's match. All over 85% too.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Kingdom Hearts vs. Harvest Moon - Bracket: <b>KH</b> - Vote: <b>KH</b> (6/7)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/9/2006 4:46:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318499419">message detail</a>
 | #353</td></tr>
<tr class="even">
<td>
Damn. I keep finding myself with very little room to work with. Ah well.<br>---<br><b>Board 8</b>: Where people treat each other <i>right</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/9/2006 4:47:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318499930">message detail</a>
 | #354</td></tr>
<tr class="even">
<td>
Yeah, this point system sucks with 9 people in the crew now. Maybe we
should have done a 9 point system with the closest pick getting 9
points and the furthest getting 1. I wonder how everything would be
then?<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29002092" class="name">Master Moltar</a> |
Posted 7/9/2006 4:56:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318502028">message detail</a>
 | #355</td></tr>
<tr class="even">
<td>
<i>Yeah, this point system sucks with 9 people in the crew now. Maybe
we should have done a 9 point system with the closest pick getting 9
points and the furthest getting 1. I wonder how everything would be
then?</i><br><br>Hey, if someone's willing to go back and do that, I could keep track of both sets of scores.<br><br>That's right, someone else go back and do it. &gt;.&gt;<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Kingdom Hearts vs. Harvest Moon - Bracket: <b>KH</b> - Vote: <b>KH</b> (6/7)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/9/2006 5:03:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318503765">message detail</a>
 | #356</td></tr>
<tr class="even">
<td>
<i>Super Mario Bros. wins with 99.99% (though Madden will get the first vote)<br>Leonhart&#8217;s
Prediction: Madden NFL with 99.99% (I&#8217;ll probably throw Super Mario
Brothers a pity vote to keep it from being a shutout)</i><br><br>IT'S AAAAWWWWNNNN<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/9/2006 5:17:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318507128">message detail</a>
 | #357</td></tr>
<tr class="even">
<td>
Also, ironically enough, I feel all but certain that this will be a battle between me and Leon for the point.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2587111&amp;board=8&amp;topic=29002092" class="name">Anal Storage</a> |
Posted 7/9/2006 5:43:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318512948">message detail</a>
 | #358</td></tr>
<tr class="even">
<td>
Me too HaRR. I'm honestly expecting SMB to get 95% of the vote. People
have proven that they're voting on the merits of the series, and well
Madden as a series sucks. People will give Super Mario Bros. it's props
when it comes to being the better series, and I honestly believe we'll
be seeing a new record for biggest blowout by percentage, and if we
don't, it'll be damn close to it. People picking in the 80's is
honestly boggling my mind after what we've seen from the contest thus
far.<br><br>---<br><b>Explicit Content</b><br>I used to be Asian, but I didn't get good enough grades so my parents beat it out of me. - snalien</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=415172&amp;board=8&amp;topic=29002092" class="name">TimJab</a> |
Posted 7/9/2006 5:59:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318516287">message detail</a>
 | #359</td></tr>
<tr class="even">
<td>
tagged<br><br>---<br><a class="linkification-ext" href="http://alt8.proboards56.com/" title="Linkification: http://alt8.proboards56.com">http://alt8.proboards56.com</a><br><a class="linkification-ext" href="http://nawaefed.proboards102.com/" title="Linkification: http://nawaefed.proboards102.com">http://nawaefed.proboards102.com</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/9/2006 6:03:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318517303">message detail</a>
 | #360</td></tr>
<tr class="even">
<td>
Yeah, we know that SMB isn't going to match LoZ in strength...but I
feel good in saying Madden's not going to match Civilization's
strength, directly or indirectly. 98+% of gamers here have played a
Mario game before, while at least 33% of the site either hates
sports-titles or hates EA the most out of all genres/companies...and
Madden is the face of both sports-titles and EA. Any Mario game...<i>any</i>...would
beat any Madden game, and I want to say any single Mario game would
probably beat the Madden series (I would LOVE to see Mario Is Missing
beat the entire series -- viva la ESPN 2k). Madden may be a casual game
and get afew votes like that, but Mario's even more casual than that;
Madden can't claim to be more mainstream than Mario unless you're only
going by the type of voters who aren't coming here.<br><br>You'll have
gamers who like sports more than video games, sure, but you won't have
as many gamers that like Madden more than Mario.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/9/2006 6:05:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318517677">message detail</a>
 | #361</td></tr>
<tr class="even">
<td>
Oh, and if Castlevania is a sign of anything, Madden really will lose the ground it stands on.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/9/2006 6:38:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318525325">message detail</a>
 | #362</td></tr>
<tr class="even">
<td>
<i>People picking in the 80's is honestly boggling my mind after what we've seen from the contest thus far.</i><br><br>Ummmm, some people still <i>do</i> like Madden.  It certainly has a bigger audience than Civilization on this site.  I'm sure people that <i>do</i> like the series know its going to get creamed against Mario, and will give it the pity vote.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/9/2006 6:44:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318526538">message detail</a>
 | #363</td></tr>
<tr class="even">
<td>
It's too late to change, but I believe we are all underestimating Madden's strength. <br><br>Mario with 79%.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/9/2006 6:56:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318529389">message detail</a>
 | #364</td></tr>
<tr class="even">
<td>
Here's are the current match rankings taking consistency into play.
They are pretty basic regarding correct predictions (top guy gets +9,
next best gets +8, etc.), but there's a unique penalty for incorrect
picks. If you were the only crew member to incorrectly pick a match,
you'd receive a -1. However, if you are one of three members to get the
match wrong, you could get a -3, -2, or -1, depending on just how badly
you were off. Everyone received negative points for Castlevania/Halo,
but some were hurt more than others.<br><br>The Legend of Zelda vs. Civilization<br>+9 Ulti<br>+8 Soul<br>+7 Lopen<br>+6 Moltar<br>+5 HaRRicH<br>+4 yo<br>+3 mnm<br>+2 HM<br>+1 Leon<br><br>Suikoden vs. Mega Man X<br>+9 HaRRicH<br>+8 Leon<br>+7 Ulti<br>+6 Moltar<br>+5 mnm<br>+4 Soul<br>+3 Lopen<br>+2 yo<br>+1 HM<br><br>Pokemon vs. Star Ocean<br>+9 Soul<br>+8 Lopen<br>+7 mnm<br>+6 yo<br>+5 Leon<br>+4 Ulti<br>+3 HaRRicH<br>+2 Moltar<br>-1 HM<br><br>Metroid vs. Kirby<br>+9 HM<br>+8 Moltar<br>+7 mnm<br>+6 yo<br>+5 Leon<br>+4 HaRRicH<br>+3 Soul<br>+2 Lopen<br>+1 Ulti<br><br>Metal Gear vs. Soul Calibur<br>+9 Moltar (tie)<br>+9 HM (tie)<br>+7 Ulti<br>+6 yo<br>+5 Lopen<br>+4 HaRRicH<br>+3 mnm<br>+2 Leon<br>+1 Soul<br><br>Fire Emblem vs. Silent Hill<br>+9 HaRRicH<br>+8 yo<br>+7 Soul<br>+6 Leon<br>+5 HM<br>+4 Moltar<br>+3 mnm<br>+2 Ulti<br>-1 Lopen<br><br>Castlevania vs. Halo<br>-1 HaRRicH<br>-2 yo<br>-3 mnm<br>-4 Lopen<br>-5 Leon<br>-6 Moltar<br>-7 Ulti<br>-8 HM<br>-9 Soul<br><br>---<br><b>Board 8</b>: Where people treat each other <i>right</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/9/2006 6:57:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318529488">message detail</a>
 | #365</td></tr>
<tr class="even">
<td>
[This message was deleted at the request of the original poster]</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/9/2006 6:57:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318529671">message detail</a>
 | #366</td></tr>
<tr class="even">
<td>
<b>The Rankings</b> (Through Castlevania/Halo)<br>1. HaRRicH (33)<br>2. yoblazer33 (30)<br>3. Master Moltar (29)<br>4. therealmnm (25)<br>5. UltimaterializerX (23)<br>5. XxSoulxX (23)<br>7. Leonhart (22)<br>8. Lopen (20)<br>9. Heroic Mario (17)<br><br>---<br><b>Board 8</b>: Where people treat each other <i>right</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/9/2006 7:00:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318530218">message detail</a>
 | #367</td></tr>
<tr class="even">
<td>
And that first paragraph shows just how badly I write in haste. Yeeee!<br>---<br><b>Board 8</b>: Where people treat each other <i>right</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/9/2006 7:01:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318530431">message detail</a>
 | #368</td></tr>
<tr class="even">
<td>
<i>The Rankings (Through Castlevania/Halo)<br>1. HaRRicH (33)</i><br><br>I know nobody can see it right now...but I've totally got my oh-face going on.<br><br>Not really, but that's still real cool!<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/9/2006 7:01:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318530575">message detail</a>
 | #369</td></tr>
<tr class="even">
<td>
<i>Yeah, this point system sucks with 9 people in the crew now. Maybe
we should have done a 9 point system with the closest pick getting 9
points and the furthest getting 1. I wonder how everything would be
then?</i><br><br>Not nearly as fun as what we have now. It's just a
matter of being within a couple of percents of the match to get a
crapload of points. Lame. &gt;&gt;<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/9/2006 7:03:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318530952">message detail</a>
 | #370</td></tr>
<tr class="even">
<td>
We can have both rankings running side by side. One of them is more
like the Prophet Challenge, while the other is similar to the
Oracle/PPC. <br>---<br><b>Board 8</b>: Where people treat each other <i>right</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/9/2006 7:10:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318532600">message detail</a>
 | #371</td></tr>
<tr class="even">
<td>
I don't mind them both being calculated, just so long we don't ditch the current system for the much lamer 9 point system.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/9/2006 7:14:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318533593">message detail</a>
 | #372</td></tr>
<tr class="even">
<td>
I'll agree with HM -- I don't want to ditch the classic. However, I'm
completely down for having that updated alongside with it -- it could
work as a tie-breaker, perhaps, if nothing else.<br><br>I get the sneak in suspicion that I love seeing that up for the same reasons HM hates it though.  =P<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=623712&amp;board=8&amp;topic=29002092" class="name">RPGGamer0</a> |
Posted 7/9/2006 7:15:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318533639">message detail</a>
 | #373</td></tr>
<tr class="even">
<td>
I think it's funny that HM is tied for first in the current system, but
is getting doubled in the greatly superior 9 point system.<br><br>&gt;_&gt;<br><br>---<br><b>My mom calls hers a Money Money Hole. :( - chaoscell</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/9/2006 7:17:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318534121">message detail</a>
 | #374</td></tr>
<tr class="even">
<td>
Greatly superior my ass. The whole point is to get the closest to the
actual percentage, not get in the ballpark and get six points for it.
&lt;&lt;<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/9/2006 7:19:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318534615">message detail</a>
 | #375</td></tr>
<tr class="even">
<td>
The goal's the same no matter what format.  It's just a matter of illustrating consistency with it now.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/9/2006 7:21:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318535112">message detail</a>
 | #376</td></tr>
<tr class="even">
<td>
<i>Greatly superior my ass. The whole point is to get the closest to
the actual percentage, not get in the ballpark and get six points for
it. &lt;&lt;</i><br><br>I'm just saying... if you end up getting boxed in for every single match, you most likely aren't going to get <i>any</i>
points in the current system, unless you call it exactly right. At
least the other way gives better indication of how good a predictor you
are overall. It's nice to be able to see both.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29002092" class="name">Lugia2</a> |
Posted 7/9/2006 7:25:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318535774">message detail</a>
 | #377</td></tr>
<tr class="even">
<td>
On the system...<br><br>Well, I just like reading your stuff, it can be fun.  <i>Especially</i> when you guys get it wrong.  It makes the upset all the more fun!  Go Knuckles!<br><br>As for Madden...<br><br>Most of the people who play Madden here *cough*H<b>M</b>*cough* are also Mario fans.  So 90% might be a bit low...<br>I would put it more at 93%.  IT'S FOOTBALL!<br><br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/9/2006 7:25:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318535976">message detail</a>
 | #378</td></tr>
<tr class="even">
<td>
You do not even <i>need</i> to get the top prediction much at
all. This system allows for you to get by with getting five to six
points in most of that matches and rank extremely well. You've gotten
the top prediction <i>once</i>, and you're the top predictor. Yoblazer has not gotten it <i>once</i>
and he's second -- his highest place was second. It's a system that
rewards getting in the area of the actual percentage more than
anything. <br><br>There is nothing <i>better</i> about the current
system at all, really. I much prefer the one point system per match, as
it awards the closest predictor the point and no one else. If you
aren't the closest, you shouldn't get any points. But whatever, it
really doesn't matter as long as we do both. Ditching the original for
this new one, though, would <i>suck</i>. Hard. <br><br>On another note, anyone below 90% or above 93% is not getting the point tomorrow<i>!!</i> And with that, I go to get my McDonald's! &lt;3<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/9/2006 7:28:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318536516">message detail</a>
 | #379</td></tr>
<tr class="even">
<td>
Man, I totally made my prediction thinkin' EVERYBODY would be higher
than what they picked -- not that all would be 90+%, but I was figuring
there would be more like that. I think if I would have been half-assed
serious about it and said 94%, I'd have an easy point.<br><br>Hopefully, tomorrow doesn't prove me wrong...and maybe it'll prove me so right that I'll get the point anyway, heh.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/9/2006 7:29:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318536797">message detail</a>
 | #380</td></tr>
<tr class="even">
<td>
I wouldn't be surprised if Madden kept Mario under 80%. <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=412846&amp;board=8&amp;topic=29002092" class="name">yoblazer33</a> |
Posted 7/9/2006 7:30:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318536823">message detail</a>
 | #381</td></tr>
<tr class="even">
<td>
Both have their advantages and disadvantages. When one of us makes a
really fantastic pick that makes the rest of the crew look like
slobbering children (Soul with Pokemon or HM with Metroid), the
traditional system shines. However, when there are several people
within 2% (Fire Emblem/Silent Hill), well... how is it "far superior"
for only one person to get the point?<br>---<br><b>Board 8</b>: Where people treat each other <i>right</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/9/2006 7:30:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318536885">message detail</a>
 | #382</td></tr>
<tr class="even">
<td>
I'm not liking this 9 point system. I'm going to get 1 point for today's match. BAH.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/9/2006 7:32:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318537326">message detail</a>
 | #383</td></tr>
<tr class="even">
<td>
And I'm surprised that only 3 out of 10 called for Mario to break 90% here.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29002092" class="name">HaRRicH</a> |
Posted 7/9/2006 7:32:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318537431">message detail</a>
 | #384</td></tr>
<tr class="even">
<td>
Yeah, but then again, I'm tied for first in the official way and I'm
also first by myself up there. Leon and Lopen haven't got one yet, and
they're two of the bottom three. It's not THAT skewed...<br><br>...the
current system shows who wins the most, which is what we should
continue to go by this contest. However, this new way shows who is
doing the best overall...hard to complain about that.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29002092" class="name">therealmnm</a> |
Posted 7/9/2006 7:42:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318539508">message detail</a>
 | #385</td></tr>
<tr class="even">
<td>
<i>Most of the people who play Madden here *cough*HM*cough* are also Mario fans. So 90% might be a bit low...<br>I would put it more at 93%. IT'S FOOTBALL!</i><br><br>If
you like a series that's most likely going to get creamed, more than
likely, you are going to give it the vote, even if you like the more
popular series more. For instance, the Legend of Zelda may be my
favorite series overall, but I would <i>easily</i> give Castlevania, Sonic, or Mega Man X the vote were they to face LoZ.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29002092" class="name">THEJackSparrow</a> |
Posted 7/9/2006 7:43:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318539730">message detail</a>
 | #386</td></tr>
<tr class="even">
<td>
The thing is...I wonder how many people even consider Madden to be a
"favorite" series of theirs anyway. I can't see that being too many
here.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/9/2006 7:44:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318540038">message detail</a>
 | #387</td></tr>
<tr class="even">
<td>
(McChicken's are heavenly<i>!!</i>)<br><br><i>I wouldn't be surprised if Madden kept Mario under 80%. </i><br><br>Under <i>80%</i>?
I can understand under 90%, but there is only about 10% of this site
that even remotely likes Madden. And it's up against Super Mario Bros.
of all series, easily one of the most well played and well liked
franchises ever. I have an extremely hard time believing that Madden is
going to keep Mario under 80%.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/9/2006 7:46:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318540336">message detail</a>
 | #388</td></tr>
<tr class="even">
<td>
<i>If you like a series that's most likely going to get creamed, more
than likely, you are going to give it the vote, even if you like the
more popular series more.</i><br><br>The thing is, not many people here actually <i>like</i> Madden. So the amount who are going to toss it a pity vote aren't in large number to begin with.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29002092" class="name">THEJackSparrow</a> |
Posted 7/9/2006 7:50:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318541128">message detail</a>
 | #389</td></tr>
<tr class="even">
<td>
Heroic Mario and I made the same point and started both posts with "The thing is."<br><br>*high fives!*<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29002092" class="name">Lopen</a> |
Posted 7/9/2006 7:50:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318541183">message detail</a>
 | #390</td></tr>
<tr class="even">
<td>
Madden's mug will assure Madden the joke votes it needs to get around
15%. You watch. (I was counting on it... I guess I should've mentioned
that in the write up instead of yammering on about Tinactin)<br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29002092" class="name">THEJackSparrow</a> |
Posted 7/9/2006 7:51:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318541444">message detail</a>
 | #391</td></tr>
<tr class="even">
<td>
Why are we assuming that so many people are treating Madden like a joke entry?<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29002092" class="name">Lopen</a> |
Posted 7/9/2006 7:53:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318541924">message detail</a>
 | #392</td></tr>
<tr class="even">
<td>
Just because I'm saying Madden will get joke votes doesn't mean I'm calling it a joke entry.  There's a difference.  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/9/2006 7:54:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318542160">message detail</a>
 | #393</td></tr>
<tr class="even">
<td>
Getting joke votes for what, exactly? Being on the picture? <br><br>Honestly, who outside of Board 8 is going to care? It's not like this is Duke Milkem.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29002092" class="name">Lopen</a> |
Posted 7/9/2006 7:59:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318543396">message detail</a>
 | #394</td></tr>
<tr class="even">
<td>
Yes. Exactly that. Madden is just so out of place it's funny. You can
call it a board thing, but I don't see why it would be limited to that.
(nor do I see some huge Madden fad either) <br><br>I'm confident that my sense of humor hasn't been <i>completely</i> warped by this board.  Madden will get joke votes based on the picture.  I'm still in touch with the casual voters!!<br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/9/2006 8:03:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318544044">message detail</a>
 | #395</td></tr>
<tr class="even">
<td>
The amount of "joke votes" Madden will get outside this board will likely be extremely small in number. This <i>is</i> pretty much a board thing. <br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29002092" class="name">LeonhartForever</a> |
Posted 7/9/2006 8:13:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318546392">message detail</a>
 | #396</td></tr>
<tr class="even">
<td>
I don't think the casual voter will find humor in John Madden being on
a match picture. Heck, that's pretty much what I was expecting it to be.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29002092" class="name">Tatsumaki Senpuu</a> |
Posted 7/9/2006 8:21:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318548029">message detail</a>
 | #397</td></tr>
<tr class="even">
<td>
Yeah, same here. The picture really isn't very funny at all. It's just
a picture of Madden with a football, which is pretty much what you have
to expect.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/9/2006 11:38:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318589182">message detail</a>
 | #398</td></tr>
<tr class="even">
<td>
Way to make me look like a fool Madden!<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29002092" class="name">THEJackSparrow</a> |
Posted 7/9/2006 11:39:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318589282">message detail</a>
 | #399</td></tr>
<tr class="even">
<td>
Way to make me look brilliant for once, Madden!<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29002092" class="name">XxSoulxX</a> |
Posted 7/9/2006 11:40:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29002092&amp;message=318589392">message detail</a>
 | #400</td></tr>
<tr class="even">
<td>
This is classic case of SFF right here! <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=0">1</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=1">2</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=2">3</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=3">4</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=4">5</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=5">6</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=6">7</a></li>
<li>      8</li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=8">9</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29002092&amp;page=9">10</a></li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage8_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29002092&amp;page=7" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage8_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>