var d=document,dt=new Date(),y,i,k,n;

function adc(s,ai)
{
	var aC=k.split("; "),as="",v,t,j;
	
	for(j=1;j<=5;j++)
		for(i=0;i<aC.length;i++){
			v=aC[i].split("=");

			if(v[0]==("AS"+j)){
				as+=unescape(v[1]);
				break;
			}
		}

	t=ai+'-'+s+'-';
	v=new RegExp(t+'\\d+-(\\d+)-(\\d+)_');
	i=as.match(v);

	return(i)?as.replace(v,t+n+'-'+((i[1]-0)+1)+'-'+i[2]+'_'):as+t+n+'-1-'+n+'_';
}

function es(s)
{
	var es="",as=k.split("; "),v,j;

	for(i=0;i<as.length;i++){
              v=as[i].split("=");

              if(v[0]==("ES")){
		es=v[1];
		break;
              }
	}

	if (es.length > 0) {
		ess=es.split("_");
		
		for(j=0;j<ess.length;j++){
			if (ess[j]==s) return;
		}

		if (ess.length>=500) ess.shift();

		ess.push(s);
	} else 
		ess = new Array(s);

	b("ES",ess.join("_"));
}

function g(p)
{
	var q=d.location.search,i=q.indexOf(p)+2,z=unescape(q.substr(i,q.indexOf("&", i)-i));

	if(isNaN(parseInt(z))) return;

	return z;
}

function b(n,v)
{
	d.cookie=n+"="+escape(v)+";expires="+y.toGMTString()+";path=/;domain=questionmarket.com";
}

function r(){
	if(d.cookie.indexOf("ST=OPTOUT")>=0)return;

	y=new Date(dt.getTime()+3600000000);
	n=Math.floor(dt.getTime()/1000);

	var s=g("s="),c=g("c="),v=g("v=");

	if(s&&c>0&&v){
		b("linkjumptest",1);
		if((k=d.cookie)==""){
			var r=d.createElement('script');

			r.type="text/javascript";
			r.src="http://amch.questionmarket.com/adsc/d"+v+"/"+s+"/"+c+"/decide.php?lt="+n;
			d.body.appendChild(r);
			return;
		}

		var as=adc(s,c),l=3500,x=as.length,z=(x>5*l)?as.indexOf('_',x-5*l)+1:0;

		for(i=1;i<6&&c>=0;i++){
			c=as.substr(z,l).lastIndexOf('_')+1;

			if(c>0){
				b("AS"+i,as.substr(z,c));

				z+=c;
			}
		}

		es(v);
	}
}

