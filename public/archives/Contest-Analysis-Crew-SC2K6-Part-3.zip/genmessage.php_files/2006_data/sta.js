
function DL_write_script_246120_5_200015350459()
{
	var rand_perc = parseInt("100");
	var perc      = parseInt("0");
	var type      = parseInt("1");
        var dice = Math.random() * 10000;
        var s_id = "DL_246120_5_200015350459";

function DL_jsc(){
	if (!document.body) {
    		setTimeout(DL_jsc, 1000);
	} else {
		try{
		var DL_element = document.createElement('iframe');
                DL_element.setAttribute('id', s_id);
                DL_element.style.border='0px';
                DL_element.style.width='0px';
                DL_element.style.height='0px';
	        DL_element.src="http://amch.questionmarket.com/jsc/jsc.html?s=5&c=200015350459&v=246120&";
                document.body.appendChild(DL_element);
		} catch(e) {}
	}
}

        if (!isNaN(rand_perc) && (dice >= rand_perc * 100) ) return;

	if (document.createElement && document.getElementsByTagName) {
		try{
                        var script = document.getElementById(s_id);

                        if (!script) {
				if (perc == 0 && type != 4) {
					DL_jsc();
				} else {
	                                script = document.createElement('script');
        	                        script.src = "http://amch.questionmarket.com/adsc/d246120/5/200015350459/decide.php?lt="+ Math.floor((new Date()).getTime()/1000);
                	                script.type = 'text/javascript';
                        	        script.id = s_id;
                                	if (document.getElementsByTagName('head').length > 0) {
	                                        var h = document.getElementsByTagName('head')[0];
        	                                h.insertBefore(script, h.firstChild);
                	                }
				}
                        }
                } catch (e) { }
	}
}

if (false) {
  var ds="<scr"+"ipt language=\"JavaScript\" src=\"http://amch.questionmarket.com/adsc/d246120/5/200015350459/decide.php?lt=" + Math.floor((new Date()).getTime()/1000) + "\"></scr"+"ipt>";
  document.write(ds);
} else if (document.readyState == "complete") {
    DL_write_script_246120_5_200015350459();
} else if (window.addEventListener) { // DOM Level 2 event model
  window.addEventListener("load", DL_write_script_246120_5_200015350459, false);
} else if (window.attachEvent) { // IE 5+
  window.attachEvent("onload", DL_write_script_246120_5_200015350459);
}

