<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">

<title>GameFAQs: Message List</title><link rel="stylesheet" type="text/css" href="genmessage2_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage2_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage2_files/bc.css"></head><body linkifytime="180" linkified="0" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage2_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage2_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29618174%26page%3D1"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<a href="http://adlog.com.com/adlog/c/r=10153&amp;s=676348&amp;t=2006.08.02.20.50.35&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=01c17-gne-ad544C8F1BE28C5E96/http://www.chowhound.com" target="_blank"><img src="genmessage2_files/060726_chowhound_ad3_728x90.jpeg" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage2_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew - Part 3</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29618174&amp;page=1">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

          | <a href="http://boards.gamefaqs.com/gfaqs/post.php?board=8&amp;topic=29618174">Post New Message</a>
           | <a href="#8,29618174" id="gamefox-tag-link">Tag Topic</a></div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29618174&amp;page=0">First
          Page</a> |
          Page 2 of 2      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29618174" class="name">Master Moltar</a> |
Posted 7/31/2006 9:56:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324091670">message detail</a>
 | #051</td></tr>
<tr class="even">
<td>
<b>Finals:</b> <i>Match 31</i> &#8211; (1)Legend of Zelda vs. (1)Final Fantasy<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Legend of Zelda</b> - <i>Link: I not going to hold back this time.</i><br>Round 1 &#8211; 89.97% vs. Civilization (10.03%)<br>Round 2 &#8211; 80.32% vs. Mega Man X (19.68%)<br>Round 3 &#8211; 84.70% vs. Metroid (15.30%)<br>Round 4 &#8211; 73.74% vs. Metal Gear (26.26%)<br><br>Legend of Zelda continues to dominate, nearly tripling Metal Gear.<br> <br><b>Final Fantasy</b> - <i>Cloud: I know. I won&#8217;t either.</i><br>Round 1 &#8211; 85.98% vs. Diablo (14.02%)<br>Round 2 &#8211; 74.19% vs. Mega Man (25.81%)<br>Round 3 &#8211; 76.06% vs. Resident Evil (23.94%)<br>Round 4 &#8211; ~53.00% vs. Super Mario Bros (47.00%)<br><br>Super Mario Bros. gives FF quite the match.<br><br>No
big, epic write-up here, even though it&#8217;s a big, and pretty epic match.
Both series have proven their dominance in this Contest, so no need to
look at past performances&#8230;well, except for one.<br><br>I said last
analysis that if FF couldn&#8217;t beat SMB with more than 55%, it was
looking iffy going into the finals. Well, 53% against SMB doesn&#8217;t look
so hot going into the Finals, especially when Zelda nearly tripled MG.
A lot of people are jumping to the Zelda ship now, but I still think
Final Fantasy will pull through<br><br>&#8220;But Moltar!&#8221; You scream, &#8220;LoZ
is stronger than SMB!&#8221; Yeah, but perhaps we underestimated SMB this
whole time and the two end up closer than we expected. Heck, what if
SMB outdoes LoZ against FF because of the Mario Factor? I wouldn&#8217;t be
too surprised. Still, I&#8217;m not counting out Zelda, as is looking very
good to win. It has a bigger fanbase than Mario does on this site, and
if SMB can do this well, LoZ could do better. <br><br>This match is nearly a toss-up for me, but I&#8217;ve had FF since Day 1, and I&#8217;m sticking to it now.<br><br><b>Moltar&#8217;s Bracket Says:</b> Final Fantasy will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Legend of Zelda: 49% - Final Fantasy: 51%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>I
had FF in my bracket from day one, so I can't turn my back on it now
even with today's results. Though given today, it's probably the
underdog. I doubt Mario came this close to FF by accident; lawl
NintendoFAQs. And around these parts, Zelda is bigger than Mario by
enough to make up the Mario/FF margin. Should be an exciting match,
assuming Zelda doesn't run away with it by a mile early.<br><br>Prediction: Final Fantasy with 50.02%<br> <br><br><br><b>Soul&#8217;s Analysis</b><br> <br><i>Legend of Zelda defeated Metal Gear with 73.74%<br>Final Fantasy defeated Super Mario Bros with around 52-53%</i><br><br>The
finals. Well, what can I say? Another contest down, another horribly
predicted contest by yours truly. 3 points wrong, and if FF loses here,
that's another 16 points gone. I would be more upset if I cared about
my bracket, but seeing Zelda win over FF will be a hell of a lot better
then 16 points. The bracket was very predictable, as could be seen by
the amount of perfect brackets we're getting. Enough about the contest,
let's get to the match at hand.<br><br>To say this final wasn't
predictable would be a pretty stupid thing to say. Final Fantasy and
Zelda always seem to have representation in the finals. In fact, in
every single contest after SC2K2, Zelda and FF have fought in the
finals. FF has won three battles, while Zelda has won 3. Hmm? So, I
guess this would be the tiebreaker match then.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29618174" class="name">Master Moltar</a> |
Posted 7/31/2006 9:57:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324091909">message detail</a>
 | #052</td></tr>
<tr class="even">
<td>
In this contest, Link plowed through everyone like a snowblower on
snow. Like geeks on their Harry Potter books. Like Link against
everyone. You know the deal, I'm sure. Link... I mean, Legend of Zelda
has never finished below 73%. Zelda was only below 100K votes once, and
that was against Metal Gear. And even then it managed to put up 97K
votes. LoZ put up 114K votes against Metroid. Seriously, LoZ has been
an absolute monster in this contest, and has <i>definitely</i>
looked like contest champion material. I said after round 1 that the
only way LoZ could win is if it put up around 67% against Metal Gear.
Not only did LoZ exceed my expectation, but it killed it and stole it's
dog. That's how impressive LoZ has been so far.<br><br>Final Fantasy
has looked like contest champion material as well. I always though it
would win, and I was absolutely stunned after it got 86% against
Diablo. I was so shocked that I given up all hope for an interesting
contest and laughed at anyone who thought that LoZ had a chance. Truth
be told, Final Fantasy had a hell of a lot tougher bracket then LoZ.
Even though it did have a much tougher road, it still managed to put up
over 100K, even against Mega Man. Mega Man is no slouch, so putting up
100K votes against it is pretty damn impressive. The one slip up, as of
right now, is against Resident Evil. Yes, it got over 100K votes
against it, but percentage wise, FF only got 76.06% against it. Yes,
it's an ok number, but when Legend of Zelda put up similar numbers
against Metal Gear, you know something is up. And as I'm writing this,
Final Fantasy has around 53% against Mario. We all know that Zelda is
stronger then Mario, and there is not much room to spare there for FF.
The only way FF could win is in a wire-to-wire match that could go
either way, really.<br><br>I'm siding with Legend of Zelda on this one.
He completely demoralized his entire half of his bracket. The strongest
series that challenged LoZ only got 26.26% against it. Couldn't even
break 30%. You know how weak that makes his entire half of the bracket?
Most competitors could only score 10-19% against him! That is ****ing
scary! Final Fantasy had stronger challengers, sure, but it hasn't
looked as strong as Zelda when it counted.<br><br><b>My prediction: Legend of Zelda wins with 53.35% of the vote. Thanks for another great Analysis Crew Moltar!</b><br><br> <br><br><b>Leon&#8217;s Analysis</b><br> <br>First
of all, let me congratulate Super Mario Brothers for putting up more of
a fight than I ever thought it would. I suppose just being THE Mario
series accounted for more than I figured. With that said, there isn&#8217;t
much else to contribute toward this match. I mean, it&#8217;s the Legend of
Zelda vs. Final Fantasy. This is what the entire contest has been
building up to. I&#8217;m just hoping this one turns out to be an instant
classic. We&#8217;ve yet to have a blockbuster match between these two that
actually delivers in terms of drama. Either that, or I hope Super Mario
Brothers outperforms the Legend of Zelda against Final Fantasy, which
is more wishful thinking than anything. <br><br>After what Super Mario
Brothers did yesterday, I fully expect the Legend of Zelda to get out
to a fast start, and then it&#8217;ll be up to Final Fantasy to overcome the
early deficit it is almost certain to face. If, somehow, it doesn&#8217;t
trail, let me pull a stats topic tradition here and call it over after
five minutes. However, after the previous match, the Legend of Zelda is
more likely to win this match easily than the other way around.
However, it&#8217;s difficult to gauge its strength because the only
legitimate match we&#8217;ve seen is the one against Metal Gear. I&#8217;m not
entirely sure if it&#8217;s stronger than Mega Man or not, but I&#8217;d wager it&#8217;s
fairly close one way or the other. <br><br>But I&#8217;m going to pull an Analysis Crew first (at least for this contest) and predict the outcome even down to the votes. <br><br><i>Leonhart&#8217;s Prediction:</i><br><br><b>The Legend of Zelda 100149 49.99975%<br><br>Final Fantasy 100150 50.00025%<br><br>TOTAL VOTES 200299</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29618174" class="name">Master Moltar</a> |
Posted 7/31/2006 9:58:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324092082">message detail</a>
 | #053</td></tr>
<tr class="even">
<td>
<b>Mnm&#8217;s Analysis</b><br> <br>Finally the match that we've all been
waiting on... Two juggernauts going head to head. I'm sure others
probably have lengthy analysis so I'll keep it short. Like Super Mario
Bros., I already had a pretty good feeling about how LoZ would perform
against Final Fantasy, and even with Super Mario Bros. good showing,
I'm still not changing my stance. Like I said before, I thought SMB
would get 43-45%, and it surpassed that in netting 47%. I'd like to
take note that I thought since the beginning that SMB would be a
powerhouse, and it proved itself. It may be weird in taking Final
Fantasy to win because it puts LoZ really close to SMB. But I think
indirectly SMB as a series has nearly as much power as LoZ. Sure it
would get dominated head-to-head, but I respect it that much. Of
course, LoZ can put that to rest by handling FF.<br><br>Now most people
will assume that since Super Mario Bros. was so close, then with the
Legend of Zelda being stronger, that should automatically push it past
Final Fantasy. I don't think that's quite the case here. Sure Legend of
Zelda will be stronger, but I think it squeezes into the space between
SMB and outright beating Final Fantasy. It's the same way I think that
someone like Squall or Bowser gain strength and <i>still</i> not break the ranks of the Noble Nine.  They may beat lesser opponents down <i>like</i>
they were Noble Nine, but in the end, due to the pecking order they end
up squeezing into place right below that rank. I think that's what
Zelda does in this instance. All matches aside, it probably is Final
Fantasy's equal, but when it comes down to it, Final Fantasy still ekes
it out. Call it a hunch. (Or maybe this is my conscious speaking for
going against Kingdom Hearts after Castlevania dominated Halo). <br><br>No jumping ships here, even though Legend of Zelda is my favorite series by <i>far</i>
(A Link to the Past, Link's Awakening, and The Wind Waker are all Top
10 material for me). Final Fantasy ekes out the victory, but I win
either way since I'm such a huge Legend of Zelda fan. Plus I can just
see the backlash from Vlado and others if Zelda takes it.<br><br>Bracket: Final Fantasy<br>Vote: The Legend of Zelda<br>Prediction: Final Fantasy with 50.89%<br><br> <br><br><b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner: Final Fantasy<br>Earlier this contest:<br>---LoZ - 89.97% on Civilization, 80.32% on Mega Man X, 84.7% on Metroid, 73.74% on Metal Gear<br>---FF - 85.98% on Diablo, 74.19% on Mega Man, 76.06% on Resident Evil, about 53% on Super Mario Bros. at the half-way mark<br>Top 100 List comparison:<br>---LoZ:OoT - #2, LoZ:LttP - #4, LoZ - #30, LoZ:WW - #45, LoZ:MM - #46<br>---FF7 - #1, FF3/6 - #10, FFX - #12, FF8 - #17, FFT - #19, FF9 - #42, FF2/4 - #50, FF - #76, FFTA - #89<br>Best Game Ever x-stat comparison:<br>---LoZ:OoT
- 46.18% (32-64 Division runner-up), LoZ:LttP - 41.61% (16 Division
runner-up), LoZ:WW - 37.29% (was behind Starcraft), LoZ - 34.49% (8
Divison runner-up)<br>---FF7 - 50% (Best. Game. Ever. champion), FF3/6
- 39.4%, FFX - 36.86%, FF - 32.24%, FFT - 28.69% (was behind FF7/MGS),
FFTA - 24.27% (SFF'd by FFX)<br><br>This is short: between the
Nintendo-series poll that had LoZ getting 50.05% against every other
Nintendo franchise (Mario had 24.4%), Mario getting 37.47% against Link
in 2k2, Mario being expected to get 39.59% against Link in 2k5, LoZ
having two games that are bigger than SMB3, and LoZ having the only
game that can compete with FF7...and that SMB is doing so damn good
against Final Fantasy.....<br><br>Legend of Zelda wins with 54.12%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29618174" class="name">Master Moltar</a> |
Posted 7/31/2006 9:58:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324092220">message detail</a>
 | #054</td></tr>
<tr class="even">
<td>
<b>Yoblazer&#8217;s Analysis</b><br> <br>Hmm... only a few hours until start
time; looks like I really forgot about this. Kind of sad, actually,
since I was looking forward to putting together one hell of a
long-winded analysis to cap things off. Ah well, just a few points
before I make my prediction:<br><br>1. I, in all my fanboyish devotion,
was planning to take Zelda since day one. Call me a fanboy however long
you may wish, but don't call me easily influenced. Actually, go ahead
and call me easily influeced, because The Legend of Zelda is just <i>so influential!</i><br><br>2. Zelda defeated Metal Gear Solid, a series better than Final Fantasy, with nearly 74%. I imagine it can only do better here.<br><br>My prediction: The Legend of Zelda def. Final Fantasy (78-22)<br>Real prediction: The Legend of Zelda def. Final Fantasy (53-47)<br><br> <br><br> <b>Lopen&#8217;s Analysis</b><br> <br>*Sigh*.
Well, at least Mario gave us a show. I said in my Mario/FF writeup that
I was more confident in Mario's upset chances against FF than the
Legend of Zelda's. Mario had the "X-Factor" going into the match. "It's
freaking Mario", "The Father of all Gaming"&#8230; blah blah blah. Weird
stuff&#8230; stuff that can't be conveyed in "SMB3 only got 47% against
Chrono Trigger WTF". In addition, whereas Mario <i>completely dominates</i>
the NES vote, I don't think the original LoZ + Adventures of Link are
that much more popular than the original Final Fantasy, so LoZ can't
take the "old school"/nostalgic vote as well as Mario can.<br><br>Nope,
there is no strong X-Factor. It's just going to be game for game, and I
really think just by comparing the series, Final Fantasy has a distinct
edge going into it. The fanbases are spread out in about the same way.
Let's do a match card.<br><br>FF7 beats OoT pretty easily. Not overwhelmingly, but easily.<br><br>FF6 loses to LttP by a smaller margin.<br><br>FFX about breaks even with WW&#8230; though I'd put my money on FFX.<br><br>FF1 barely loses to LoZ, methinks. Not by quite as much as the X-Stats imply, though.<br><br>FF8 is similar to Majora's Mask, sorta the "black sheep" of their franchises. I'd take FF8 in this one, though.<br><br>Then we've got FF9, FF5, FFT, and FF4 to match up with all the rest of the oddball Zelda games. I think with <i>just those</i>
games, FF has a sizable advantage there&#8230; and what about the other
random FF games in classics such as FF Mystic Quest!? Yeah! We can't
forget all of them! (Sorry, I had to bring up MQ in one of these write
ups)<br><br>By the breakdowns, it doesn't seem like FF has a huge
advantage&#8230; but I think it does. You could throw in FF4 to aid FF6 and
make the match closer, or throw in FF9 to help FF8... and FF5 and FFT <i>still</i> probably beat all other Zelda games. Final Fantasy just has more big guns.<br><br>So
yeah, basically what I'm saying is: I think Final Fantasy beats LoZ by
a greater margin than it beat Mario by. Looking at their contest
history, even with Mario aside, many people would be giving this to
LoZ&#8230; but is 73% on MG really better than 72% on Mega Man? I'd say it's
about equal&#8230; impressive performances against impressive competitors.
I'd have guessed Mega Man and MG were about equal before the contest.
Not that it matters to me&#8230; I'll say it again&#8230; screw extrapolation&#8230; I
swear it doesn't work in this contest.<br><br>Does this "contradict everything we've ever seen in the contests"? Yeah, yeah it does&#8230; but it wouldn't be the first time.<br><br><b>Lopen's Prediction:</b> Final Fantasy with 54.01%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29618174" class="name">Master Moltar</a> |
Posted 7/31/2006 9:59:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324092419">message detail</a>
 | #055</td></tr>
<tr class="even">
<td>
<b>HM&#8217;s Analysis</b><br><br><b>The Legend of Zelda</b><br><i>Previous Matches :</i><br><br>The Legend of Zelda &#8211; 89.97% -- 100,163<br>Civilization &#8211; 10.03% -- 11,169 <br><br>The Legend of Zelda &#8211; 80.32% -- 104,400<br>Mega Man X &#8211; 19.68% -- 25,577 <br><br>The Legend of Zelda &#8211; 84.7% -- 114,009<br>Metroid &#8211; 15.3% -- 20,595 <br><br>The Legend of Zelda &#8211; 73.74% -- 97,633<br>Metal Gear &#8211; 26.26% -- 34,777 <br><br><b>Final Fantasy</b><br><i>Previous Matches :</i><br><br>Final Fantasy &#8211; 85.98% -- 107,648<br>Diablo &#8211; 14.02 -- 17,560 <br><br>Final Fantasy &#8211; 74.19% -- 100,574<br>Mega Man &#8211; 25.81% -- 34,988 <br><br>Final Fantasy &#8211; 76.06% -- 103,552<br>Resident Evil &#8211; 23.94% -- 32,602 <br><br>Super Mario Bros. &#8211; 47.09% -- 65,432 (current percentages as of 8:00 PM EST)<br>Final Fantasy &#8211; 52.91% -- 73,513 (current percentages as of 8:00 PM EST) <br><br>The
final showdown between the two largest forces in contest history
colliding in the final &#8211; Final Fantasy v. The Legend of Zelda. The
strongest competitors since the beginning of this contest have always
been a representative from these two franchises, whether it&#8217;s Link or
Sephiroth. Each of them has been very impressive in this contest so
far, completely shattering previous vote totals, setting new records
for individual votes, and just overall being extremely domineering
throughout the duration of the contest. Even before this began, we all
knew the only match that mattered in the end was Final Fantasy against
The Legend of Zelda. The Ultimate Showdown, yo! <br><br>In the
beginning, Zelda began by setting contest history against Civilization
by amazingly shattering the previous individual vote total record set
by Cloud Strife. We had never seen any series manage to get 100,000
individual votes before, and seeing Zelda do it was crazy. Little did
we know that we&#8217;d see many more of these, and even larger in number,
later on. There wasn&#8217;t much to say other than that because it was a
typical first contest match blowout for Zelda, though some were
surprised that Zelda was able to nearly put up 90%. <br><br>In its
second match, it faced Mega Man X where it once again put up an insane
100,000+ votes, and in an even larger number than it did against
Civilization, which was very impressive. The fact that Zelda was able
to quadruple Mega Man X was also quite shocking, but not without reason
as many had suspected that there would be plenty of SFF in such a
match-up. Given how weak MMX ended up being, it&#8217;s probably worth
considering some SFF in this match. <br><br>The third match was yet
another SFF match, but this one was even more brutal and even more
expected than the last. Zelda absolutely smashed Metroid by getting
nearly 85%. And, once again, it put up <i>another</i> 100,000+ votes,
even more than the last. Interestingly, Zelda also put up three
straight 80%+ performances, which had only been done by Link in 2004,
who happened to win that contest. Things were looking very good at this
point, but it still had to actually face a series that many suspected
would have a legitimate claim to the fourth strongest series in the
contest. <br><br>In the last round, Zelda put up a very good
performance against Metal Gear. It didn&#8217;t actually hit either extreme &#8211;
not doubling to more than tripling &#8211; in percentages, but somewhere
along the middle, though definitely more toward the latter extreme.
This was the first time Zelda didn&#8217;t hit 80% and didn&#8217;t get 100,000
votes. It was still impressive in every regard and it caused some doubt
as to Final Fantasy heading into the final match as the favorite, but
that&#8217;s not terribly surprising.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29618174" class="name">Master Moltar</a> |
Posted 7/31/2006 9:59:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324092495">message detail</a>
 | #056</td></tr>
<tr class="even">
<td>
Final Fantasy&#8217;s contest performance for this series is probably even <i>more</i>
impressive to me just because of the actual competition that Final
Fantasy had to face. In the first round, Final Fantasy came out and
shocked the masses by putting up an <i>amazing</i> 86% on <i>Diablo</i>. This wasn&#8217;t some typical eight seed fodder &#8211; this was a <i>strong</i>
series, or so people had expected. There is was no doubt about it that
Final Fantasy was looking to be an absolute beast of which we had not
seen before in a contest. The fact that it could more than quadruple
Diablo was extremely impressive. <br><br>In the following round, it
put the smacketh downeth on the Blue Bomber by nearly tripling it. The
fact that it could make Mega Man look so bad <i>without</i> any
potential SFF to speak of was pretty shocking. This was the second
series that Final Fantasy had made look bad. Mega Man, who had just
beat Mario Kart with 58%, could barely avoid a tripling in the face of
the Square&#8217;s top franchise. Everything was pointing to Final Fantasy
just plowing through this contest with relative ease. <br><br>In the
next round, Final Fantasy faced another one of Capcom&#8217;s series in
Resident Evil. Strangely, this match might have been the first one to
put forth a &#8220;chink&#8221; in the invincible Final Fantasy&#8217;s armor. Many had
expected this to be an SFF affair that could potentially net Final
Fantasy a quadrupling, but it managed to just get by with a tripling,
which didn&#8217;t put it too far off from Mega Man, and later Metal Gear. <br><br>In
the last round, Final Fantasy had quite a scare against Super Mario
Bros. in the initial hour or so of the match. Super Mario Bros. &#8211;
stealing a method from Crono&#8217;s book &#8211; lead Final Fantasy for a good 45
minutes and even was leading at the hour mark. Of course, Final Fantasy
eventually took back the lead and never looked back. Still, after SMB&#8217;s
rather &#8220;poor&#8221; performance against SSB, it wasn&#8217;t expected that this
match would be so close. Still, it is clear that FF/SMB/LoZ are indeed
the Big Three and are all on par with each other as far as strength
goes. This didn&#8217;t look that good for Final Fantasy heading into the
finals against The Legend of Zelda, though, especially after the
destruction of Metal Gear. However, <i>THE</i> star of Final Fantasy
would soon be making his grand return to the picture in the final round
&#8211; Cloud and Sephiroth are ready to take that fairy boy to town, yo! <br><br>Throughout this entire contest, I have stuck behind Final Fantasy ultimately being the undisputed champion in this match. I <i>still</i>
am well behind the series that built GameFAQs too. It is really hard to
analyze much in this match just because we have seen both of them put
forth dominative performances and we have see them have a solid contest
history against each other with win and losses from each. This match
should not be decided either way by more than a percentage point or two.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29618174" class="name">Master Moltar</a> |
Posted 7/31/2006 10:00:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324092826">message detail</a>
 | #057</td></tr>
<tr class="even">
<td>
What I do feel might be advantageous to Final Fantasy in this match is
that it will have the return of Cloud and &#8211; perhaps for the first time
&#8211; Sephiroth. Zelda has had its strongest character, and other stronger
characters, present since the beginning, but the only time we have seen
Cloud in a picture was during round 1. Notable is that when Cloud was
present in the picture, Final Fantasy put forth its biggest blowout
against the Diablo series. Since these are likely user made, I have a
feeling that Final Fantasy will be getting its strongest
representation, which should help sway any of the ones who don&#8217;t know
who to vote for, I think. <br><br>The
only bad thing in Final Fantasy&#8217;s corner about this match is Super
Mario Bros. being so close to The Legend of Zelda, but if there was <i>ever</i>
a time when Mario could match Zelda, this would be it. How many people
are voting for Mario even if it isn&#8217;t their favorite series? How many
are voting based upon history? How many are voting based upon what
Mario has done for the gaming industry? All of these things are
exclusive to Mario, and something that Zelda wouldn&#8217;t have in its
corner. It should be interesting either way, but I&#8217;m behind Final
Fantasy bringing home the win here. <br><br><b>Aitch Emm&#8217;s Bracket :</b> Final Fantasy<br><br><b>Aitch Emm&#8217;s Prediction :</b> Final Fantasy &#8211; 51% ; The Legend of Zelda &#8211; 49%<br><br><b>Aitch Emm&#8217;s Vote :</b> <b>Final Fantasy</b>.<br> <br> <br> <br>Comments:
Ahhh, the final write-ups of the Contest. The Crew is kinda split, but
the majority is sticking with Final Fantasy tommorrow. I hope you all
enjoyed it.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29618174" class="name">LeonhartForever</a> |
Posted 7/31/2006 10:02:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324093181">message detail</a>
 | #058</td></tr>
<tr class="even">
<td>
Final Fantasy's the majority pick? Crap.<br><br>...I think I've got this one though.<br>---<br>Squall, Tidus, The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden<br>Presea, Chun-Li, Tifa, Celes, Quistis, Amy Rose, Mei Ling</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29618174" class="name">XxSoulxX</a> |
Posted 7/31/2006 10:19:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324097889">message detail</a>
 | #059</td></tr>
<tr class="even">
<td>
Leon got boxed by Ulti and a Zelda win. <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>stingers, Rad, longblade, and Ryoko owned me in a sig bet and all I got was this lousy T-Shirt</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3667364&amp;board=8&amp;topic=29618174" class="name">Matroshka67</a> |
Posted 7/31/2006 10:30:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324101178">message detail</a>
 | #060</td></tr>
<tr class="even">
<td>
Super Mario Bros. vs. Final Fantasy<br>+9 mnm<br>+8 Ulti<br>+7 yo<br>+6 Soul<br>+5 HM (tie)<br>+5 Moltar (tie)<br>+3 HaRRicH<br>+2 Leon<br>-1 Lopen<br><br><b>The Rankings</b> (Through Super Mario Bros./Final Fantasy)<br>1. Master Moltar (137)<br>1. yoblazer33 (137)<br>3. UltimaterializerX (125)<br>4. XxSoulxX (121)<br>5. therealmnm (117)<br>6. Leonhart (111)<br>7. Heroic Mario (99)<br>8. HaRRicH (90)<br>9. Lopen (76)<br><br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3667364&amp;board=8&amp;topic=29618174" class="name">Matroshka67</a> |
Posted 7/31/2006 10:32:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324101463">message detail</a>
 | #061</td></tr>
<tr class="even">
<td>
Looks like the "consistency award" will not deal with percentages, but will be decided completely by the final winner.<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=640243&amp;board=8&amp;topic=29618174" class="name">Big Bob</a> |
Posted 7/31/2006 10:32:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324101608">message detail</a>
 | #062</td></tr>
<tr class="even">
<td>
Damn, FF's got it.<br><br>If EVERYONE had picked FF, then LoZ would win, since that's the tradition in this contest so far.  But alas...<br>---<br>This space reserved for a new sig.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3662060&amp;board=8&amp;topic=29618174" class="name">YoAriel33</a> |
Posted 8/1/2006 11:42:13 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324219935">message detail</a>
 | #063</td></tr>
<tr class="even">
<td>
Final Fantasy<br>Lopen - 54.00<br>HM - 51.00<br>Moltar - 51.00<br>mnm - 50.89<br>Ulti - 50.02<br>Leon - 50.00<br><br>The Legend of Zelda<br>yo - 53.00<br>Soul - 53.35<br>HaRR - 54.12<br><br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29618174" class="name">THEJackSparrow</a> |
Posted 8/1/2006 2:51:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324265948">message detail</a>
 | #064</td></tr>
<tr class="even">
<td>
Looks like yoblazer's got this won.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29618174" class="name">Master Moltar</a> |
Posted 8/1/2006 6:29:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324323115">message detail</a>
 | #065</td></tr>
<tr class="even">
<td>
Super Mario Bros.............46.76% 73776<br>Final Fantasy...................53.24% 83997<br>TOTAL VOTES.............................157773<br><br>62.64% of the brackets predicted this match correctly.<br><br>Holy
vote totals! Those are the highest yet, and will only be surpassed by
todays match. Anyway, Mario shocks all as the series was actually able
to hang with Final Fantasy! After going toe-to-toe with it in the
evening, it took FF a while to finally pull away.<br><br>Today, Legend of Zelda is winning the Championship. Wow, never thought I'd see the day.<br><br>Soul - 5<br>Ulti - 4<br>Mnm - 3<br>Leon - 3<br>Yoblazer - 3<br>Lopen - 3<br>HaRRich - 3<br>Moltar - 3<br>HM - 2<br><br>Mnm gets his 3rd point.<br>---<br>Moltar Status: Currently the property of the true Master, <b>Z1mZum</b><br>Final July '06 Contest Score: 62 (Boo)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2497742&amp;board=8&amp;topic=29618174" class="name">MurderousNun</a> |
Posted 8/1/2006 10:17:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324376432">message detail</a>
 | #066</td></tr>
<tr class="even">
<td>
The Legend of Zelda vs. Final Fantasy<br>+9 yo<br>+8 Soul<br>+7 HaRRicH<br>-1 Leon<br>-2 Ulti<br>-3 mnm<br>-4 HM (tie)<br>-4 Moltar (tie) <br>-6 Lopen<br><br><b>The Final Rankings</b><br>1. yoblazer33 (146)<br>2. Master Moltar (133)<br>3. XxSoulxX (129)<br>4. UltimaterializerX (123)<br>5. therealmnm (114)<br>6. Leonhart (110)<br>7. HaRRicH (97)<br>8. Heroic Mario (95)<br>9. Lopen (70)<br><br>---<br>The Summer 2006 Guru Contest: Where <b>Z1mZum</b> kicked my <i>ass</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29618174" class="name">LeonhartForever</a> |
Posted 8/1/2006 10:23:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324378056">message detail</a>
 | #067</td></tr>
<tr class="even">
<td>
At least I broke 100 points...<br>---<br>Squall, Tidus, The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden<br>Presea, Chun-Li, Tifa, Celes, Quistis, Amy Rose, Mei Ling</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=80585&amp;board=8&amp;topic=29618174" class="name">DBZFIGHTERS</a> |
Posted 8/1/2006 10:25:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324378515">message detail</a>
 | #068</td></tr>
<tr class="even">
<td>
I find it disturbing how the analyses for the first match of this
contest ended up being longer than the highly anticipated final.<br><br>---<br>Die hard Cubs, Pistons, Patriot and Maple Leafs fan<br>Owl Squad Member ( �v�( �v� )�v� ) O RLY?</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29618174" class="name">XxSoulxX</a> |
Posted 8/1/2006 10:28:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324379274">message detail</a>
 | #069</td></tr>
<tr class="even">
<td>
I think it's a nice balance of short and long analysis myself.<br>--- -<br>Z1mZum &gt; ertyunese. Congrats!<br>stingers, Rad, longblade, and Ryoko owned me in a sig bet and all I got was this lousy T-Shirt</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2562507&amp;board=8&amp;topic=29618174" class="name">H__RR____H</a> |
Posted 8/2/2006 12:28:43 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324411524">message detail</a>
 | #070</td></tr>
<tr class="even">
<td>
I'm rather glad we didn't get all wound up for the final -- most of us
had the same things to say and we had one day to do it if you were
waiting to see how SMB/FF went once it got started.<br><br>Looking
forward to the next contest though...and, man, I gotta say this: Ulti
deserves second more than me because of consistancy, but I still say
damn that FF/RE match being 0.01% away from mine and in his favor, he
he he.<br>---<br><i>Damn, most of my dates involve mocking and/or beating up people like you and your bride-to-be, so I really have no advice</i> --Horatio</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29618174" class="name">Lopen</a> |
Posted 8/2/2006 12:32:08 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324412231">message detail</a>
 | #071</td></tr>
<tr class="even">
<td>
Character contest, next!  Now <i>that's</i> what I signed up for... <i>that's</i> where all my crazy theories <i>really</i> shine!  <br>---<br><b>Z1mZum</b> whooped me so bad in the Guru Contest that the next Lopen wannabe is gonna feel it.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29618174" class="name">DaruniaTheGoron</a> |
Posted 8/2/2006 12:35:04 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324412877">message detail</a>
 | #072</td></tr>
<tr class="even">
<td>
Glad to see a fellow Avs/Habs fan get the most match points! Nicely done Soul.<br>---<br><b>Sp2k6:<i> 60/64</i> Rank: <i>Tied for 1018th</i> Losses: <i>Halo, GTA, SF</i> </b>Nominate Nidoran F and <br><b>Yesterday's Pick: <i>FF</i> Today's Pick: <i>FF</i> Today's Vote: <i>Zelda</i></b> CATS in the character contest!</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29618174" class="name">XxSoulxX</a> |
Posted 8/2/2006 12:37:29 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324413368">message detail</a>
 | #073</td></tr>
<tr class="even">
<td>
&lt;3<br><br>I'm on a roll!<br>--- -<br>Z1mZum &gt; ertyunese. Congrats!<br>stingers, Rad, longblade, and Ryoko owned me in a sig bet and all I got was this lousy T-Shirt</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29618174" class="name">Master Moltar</a> |
Posted 8/2/2006 12:40:46 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324414034">message detail</a>
 | #074</td></tr>
<tr class="even">
<td>
The Legend of Zelda.......50.99% 80825<br>Final Fantasy..................49.01% 77702<br>TOTAL VOTES..........................158527<br><br>35.66% of the brackets predicted this match correctly.<br><br>Well,
and this is how it ends. The Legend of Zelda has taken the title of
Best Series Ever at GameFAQs. Just goes to show how much the site has
shifted since 2003, when anything Square was dominating. FF7 might be
the most popular game, but LoZ is the most popular series. Congrats!<br><br>Soul - 5<br>Yoblazer - 4<br>Ulti - 4<br>Mnm - 3<br>Leon - 3<br>Lopen - 3<br>HaRRich - 3<br>Moltar - 3<br>HM - 2<br><br>The final point goes to Yoblazer, but Soul has the most overall. Congrats Sowl!<br><br>And
thanks to the rest of the Analysis Crew for making this awesome as
usual. Great job guys, and I hope to see you all return for the summer.<br>---<br>Moltar Status: Currently the property of the true Master, <b>Z1mZum</b><br>Final July '06 Contest Score: 62 (Boo)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29618174" class="name">Master Moltar</a> |
Posted 8/2/2006 12:47:07 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324415183">message detail</a>
 | #075</td></tr>
<tr class="even">
<td>
Oh, and this is most likely the worst the Crew has done since SpC2K4. Go us!<br>---<br>Moltar Status: Currently the property of the true Master, <b>Z1mZum</b><br>Final July '06 Contest Score: 62 (Boo)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=758581&amp;board=8&amp;topic=29618174" class="name">steve illumina</a> |
Posted 8/2/2006 7:10:52 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324452612">message detail</a>
 | #076</td></tr>
<tr class="even">
<td>
Just pitchin my tent here as I plan to join the Crew this summer :)<br>---<br><b>Steve Illumina: Sage of Board 8 &amp; Elitist Analyst</b><br><i>Beaten by Z1m...may he revel in his Guru glory!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29618174" class="name">THEJackSparrow</a> |
Posted 8/2/2006 2:55:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324537957">message detail</a>
 | #077</td></tr>
<tr class="even">
<td>
You don't really choose to be on the Crew. You're chosen.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29618174" class="name">XxSoulxX</a> |
Posted 8/2/2006 2:56:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29618174&amp;message=324538237">message detail</a>
 | #078</td></tr>
<tr class="even">
<td>
*Bows*<br><br>Thanks for all the congrats everyone! &gt;_&gt;<br><br>Anyways, great job once again Moltar.<br>--- -<br>Z1mZum &gt; ertyunese. Congrats!<br>stingers, Rad, longblade, and Ryoko owned me in a sig bet and all I got was this lousy T-Shirt</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29618174&amp;page=0">1</a></li>
<li>      2</li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage2_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29618174&amp;page=1" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage2_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>