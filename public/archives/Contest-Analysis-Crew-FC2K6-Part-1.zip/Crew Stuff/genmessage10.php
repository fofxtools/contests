<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	



<title>GameFAQs - GameFAQs Contests Message Board</title><meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage10_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage10_files/nogs.css"></head><body linkifytime="280" linkified="7" linkifying="false"><div id="container">
	<div id="gne_nav">
		<img src="genmessage10_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/events/x06/">X06</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage10_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30499515%26page%3D9"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage10_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage10_files/advertisement.gif" alt="advertisement" height="10" width="120"></div>
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage10_files/f.xhtml" marginwidth="0" marginheight="0" hspace="0" vspace="0" allowtransparency="true" frameborder="0" height="90" scrolling="no" width="728">
&lt;script language=javascript&gt;&lt;!-- randNum = ((new
Date()).getTime() % 2147483648) + Math.random(); document.write( "&lt;a
href='http://a.tribalfusion.com/i.click?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID="
+ randNum + "' target=_blank&gt;" + "&lt;img
src='http://a.tribalfusion.com/i.ad?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID="
+ randNum + "'" + " width=728 height=90 border=0 alt='Click
Here'&gt;&lt;/a&gt;"); // --&gt;&lt;/script&gt; &lt;noscript&gt; &lt;a
href="http://a.tribalfusion.com/i.click?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID=1576037958"
target=_blank&gt; &lt;img
src="http://a.tribalfusion.com/i.ad?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID=1576037958"
width=728 height=90 border=0 alt="Click Here"&gt;&lt;/a&gt;
&lt;/noscript&gt; </iframe><img src="genmessage10_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;page=9">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30499515" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=8">Previous Page</a> |
Page 10 of 10
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=304351" class="name">Mac Arrowny</a> |
Posted 9/27/2006 9:53:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337375619">message detail</a>
 | #451</td></tr>
<tr class="even"><td>
I'll be happy as long as I get Ganon vs. Sonic...and Ganon vs. Crono...and Ganon vs. Mega Man. &lt;3<br>---<br>Pity for the guilty is treason to the innocent.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/28/2006 5:44:00 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337419514">message detail</a>
 | #452</td></tr>
<tr class="even"><td>
Lopen didn't get the highest percentage this time, but he would've won this time if he did.  Which means...<br><br><i>Hit or miss Karma Hunter strikes-</i> uh, has he done this before?<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=2665492" class="name">XIII_rocks</a> |
Posted 9/28/2006 10:25:26 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337436136">message detail</a>
 | #453</td></tr>
<tr class="even"><td>
I'd love to have Ganon/Vince, lol. Not gonna happen &gt;_&gt; It'll be the first match down.<br>---<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738</a> Sign plz<br>Hi-ho, Hi-ho, <b>Z1m Zum, Z1m Zum</b>...our guru champ.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/28/2006 10:37:18 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337437229">message detail</a>
 | #454</td></tr>
<tr class="even"><td>
Damn it, percentage, stop going down!  Let me beat the Crew in predicting for once!<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/28/2006 6:34:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337517436">message detail</a>
 | #455</td></tr>
<tr class="even"><td>
Lara Croft..........77.55% 75464<br>Alyx Vance.........22.45% 21850<br>TOTAL VOTES...............97314<br><br>92.91% of the brackets predicted this match correctly.<br><br>Lara
flat out dominates....that sounds really odd to say. Nearly 93% of the
brackets and 77.55% of the vote. Match didn't break 100K though...<br><br>Today, it's the MALE HALF!!! Snake is laying waste too.<br><br>Lopen - 5<br>Ulti - 4<br>Moltar - 3<br>KH - 2<br>Yoblazer - 1<br>Guest (Wigs) - 1<br>HM - 1<br><br>KH gets another point.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Snake vs. Soma - Bracket: <b>Snake</b> - Vote: <b>Snake</b> (15/16)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/28/2006 6:38:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337518553">message detail</a>
 | #456</td></tr>
<tr class="even"><td>
Solid Snake vs. Soma Cruz<br>+7 KH<br>+6 Yo<br>+5 Mo<br>+4 Lo<br>+3 Guest<br>+2 HM<br>+1 Ulti<br><br><b>The Rankings</b> (Through Snake vs. Soma)<br>1. Karma Hunter (79)<br>2. Master Moltar (72)<br>2. UltimaterializerX (72)<br>4. Heroic Mario (66)<br>5. Yoblazer (65)<br>6. Lopen (53)<br>7. Board 8 (47)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/28/2006 7:14:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337527962">message detail</a>
 | #457</td></tr>
<tr class="even"><td>
Sign-ups for Round 2 (female half) are now up! Go, quickly!<br><br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30817598" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30817598">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30817598</a><br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Snake vs. Soma - Bracket: <b>Snake</b> - Vote: <b>Snake</b> (15/16)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/28/2006 7:45:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337535515">message detail</a>
 | #458</td></tr>
<tr class="even"><td>
KH is definitely number 1 now in consistency.<br>---<br>CB06 - Score: <b>15/16 </b>Rank: <b>Tied - 2768th </b>Yesterday's Pick:<b> Lara Croft</b> <br>Today's Pick: <b>Snake</b> Tomorrow's Pick: <b>Squall</b> Losses: <b>Cortana</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/28/2006 7:46:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337535765">message detail</a>
 | #459</td></tr>
<tr class="even"><td>
And soon I'll be #1 in Moltar's system too! KAY AITCH IS INVINCIBLE<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/28/2006 8:06:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337540928">message detail</a>
 | #460</td></tr>
<tr class="even"><td>
Moltar's no longer at the bottom!<br><br>You
know, considering that the next match is Squall/Tidus, and today is
Snake/Soma, it feels as if we haven't cleared the Female bracket yet...<br><br>Oh well.  Eventually.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/28/2006 8:08:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337541259">message detail</a>
 | #461</td></tr>
<tr class="even"><td>
Hey, Moltar. If you get a chance, up my Squall prediction by 2%? Thanks.<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3657433" class="name">LusterSoldier</a> |
Posted 9/28/2006 8:41:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337550004">message detail</a>
 | #462</td></tr>
<tr class="even"><td>
<i>Lopen - 5<br>Ulti - 4<br>Moltar - 3<br>KH - 2<br>Yoblazer - 1<br><b>Guest (Wigs) - 1</b><br>HM - 1</i><br><br>Hey, that's not the guest for today's match.<br>---<br><b>Luster Soldier</b> - Pwned by Repus_Yortsed<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/28/2006 9:09:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337557242">message detail</a>
 | #463</td></tr>
<tr class="even"><td>
Yeah, but he was the one who got the point, so he deserves some recognition.<br><br>And I don't have the Guest write-up for Squall/Tidus yet, so...anyone wanna do it?<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Snake vs. Soma - Bracket: <b>Snake</b> - Vote: <b>Snake</b> (15/16)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/28/2006 9:40:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337564457">message detail</a>
 | #464</td></tr>
<tr class="even"><td>
Bump<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/28/2006 9:51:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337567022">message detail</a>
 | #465</td></tr>
<tr class="even"><td>
<b>Patriot Division:</b> <i>Round 1 - Match 18</i> &#8211; (4)Squall Leonhart vs. (5)Tidus <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Squall</b><br>Game/Series Known From: Final Fantasy VIII<br>Extrapolated Rank in 2002: 20th (24.36%)<br>Extrapolated Rank in 2003: 16th (31.72%) <br>Extrapolated Rank in 2004: 19th (22.92%) - Adjusted Value:17th (29.58%)<br>Extrapolated Rank in 2005: 11th (32.22%) <br>Seed in 2002: 15<br>Seed in 2003: 6<br>Seed in 2004: 4<br>Seed in 2005: 2<br>Lost in 2002 to Sonic in Round 1<br>Lost in 2003 to Samus in the Round 3<br>Lost in 2004 to Cloud in the Round 3<br>Lost in 2005 to Vincent in Round 3<br><br>Hero of FF8<br><br><b>Tidus</b><br>Game/Series Known From: Final Fantasy X<br>Extrapolated Rank in 2002: 11th (33.80%)<br>Extrapolated Rank in 2003: 13th (34.25%) <br>Extrapolated Rank in 2004: 20th (22.82%) - Adjusted Value: 24th (25.35%)<br>Extrapolated Rank in 2005: 24th (27.16%) <br>Seed in 2002: 8<br>Seed in 2003: 5<br>Seed in 2004: 8<br>Seed in 2005: 4<br>Lost in 2002 to Sonic in Round 2<br>Lost in 2003 to Ganondorf in Round 1<br>Lost in 2004 to Mega Man in the Round 2<br>Lost in 2005 to Kirby in Round 2<br><br>Hero of FF10<br><br>Hero
of FF8 vs. Hero of FF10?! Oh my, sounds like there could be some SFF
here! But who will it go to, Squall or Tidus? Let&#8217;s find out.<br><br>First,
look at the Extrapolated Rankings of the characters over the years. As
time passes, it seems that Squall gets stronger while Tidus gets
weaker. Then again, Tidus was fresh off FFX back then, but it seems as
time passes, the more he fades away. Squall still remains stronger, and
thanks to the KH series, he seems to be getting stronger, thanks to a
prominent role in the games.<br><br>So now Squall, a guy who went
toe-to-toe with Vincent last year, is facing Tidus, who got spanked
against Kirby, who Squall beat 2 years ago. Wow, this already doesn&#8217;t
even seem like it will be close. Now throw in some SFF and a possible
KH2 boost for Squall, and you have Tidus on the receiving end of an
ass-kicking.<br><br><b>Moltar&#8217;s Bracket Says:</b> Squall will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Squall: 63% - Tidus: 37%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br><br>This
would have been a HUGE match last year, but now we've seen how much of
a fraud Tidus 2003 is. Even with potential SFF (which would favor
Squall, because FF fans hate Tidus more than him), I doubt this match
deviates much from last year's stats.<br><br>Prediction: Squall with 57.85%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>This match makes me hurt inside. I like both of these characters&#8230;but my preference is <i>clearly</i>
toward Tidus &#8211; second best character ever! This match in 2003 would
have great&#8230;or at least seemed great! Unfortunately, everything points
to Squall winning this one without much trouble at all. Tidus &#8211; thanks
to Magus &#8211; was overrated in 2003 and has gone from hanging with Ganon
to getting beat down hard by Kirby, who Squall has beaten. <br><br>The only way this match could get interesting is if the fanbase actually <i>prefers</i>
Tidus over Squall. It&#8217;s a real stretch, but that&#8217;s about all Tidus has
to work with. I would guess that this one gets a bit ugly and even
uglier in the next round if there is anything to the Snake/Squall SFF
theory &#8211; it seems Snake can SFF damn near everything! <br><br><b>Aitch Emm&#8217;s Bracket:</b> Squall Leonhart<br><br><b>Aitch Emm&#8217;s Prediction:</b> Squall Leonhart &#8211; 60.5% ; Tidus &#8211; 39.5%<br><br><b>Aitch Emm&#8217;s Vote:</b> Tidus
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/28/2006 9:52:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337567198">message detail</a>
 | #466</td></tr>
<tr class="even"><td>
<b>Yoblazer&#8217;s Analysis</b><br> <br>If this match were held in
2002-2004, it would have easily been one of the most debated of the
contest. I remember the long debates about which Final Fantasy hero was
the second strongest, and I remember when Tidus had the upper hand in
2002 and throughout most of 2003. Needless to say, the tables have
turned. Ever since his shocking win over Luigi in 2003, Squall Leonhart
has establishes himself as FF's #2 hero. He beat Kirby without trouble
in 2004, beat the surging Knuckles in a similar fashion in 2005, and
then went 50/50 against Vincent Valentine in his next match.<br><br>While
Squall has been making impressive gains, Tidus has had a crap-filled
spiral into the crappy depths of craptitude. He gave a decent effort
but came up short against Ganondorf in Square's best contest year. In
2004, he got completely *****-slapped by Mega Man (did you guys know
Heroic Mario called that match <i>perfectly</i>? No fooling. He did!
Believe it! I do! Do you? You should! It's true!), and the poor guy
suffered an even more humiliating loss against Kirby in 2005.<br><br>At
this point, the voters clearly favor Squall. Once you add Kingdom
Hearts II and some Final Fantasy SFF in the mix, you have another
painful, disappointing loss for Tidus. Serves him right. Know why?
Because Squall is handsome; Tidus is just girlie.<br><br>My prediction: Squall Leonhart def. Tidus (61-39)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Man, think how debated this one would be had Kirby <i>not</i>
embarrassed Tidus last year. Seriously, it's hard to think Tidus has a
chance when Kirby beat him 57-43 or so&#8230; and when Squall beat Kirby
55-45 the year before. There's the infamous "Big N boost", but I'm
still not quite buying that this is a debatable match. Luckily, I don't
think any of you are either, so that makes my job easier.<br><br>There
is one thing this match has that can make it go really wack, and I'm
sure my fellow analyzers will be spewing the letters SFF at every
opportunity. But as for me? I really don't think so. I don't expect
this match to get tainted by it that much. I think as the main
character of their respective games, their games being probably about
as popular as one another, and with a generation gap between FF8 and
FFX to add to that, they should both hold their own pretty well.
Something Fishy Factor in this match? Nope, Nothing Fishy Factor.
Alright, maybe a little. Some But Not That Much Fishy Factor. (SBNTMFF,
for those keeping score at home)<br><br><b>Lopen's prediction:</b> Squall Leonhart with 59.77%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>SQUALL LEONHART</b><br> <br><i>"I'm not having anyone talk about me in the past tense!."</i><br> <br>Summer 2002 Contest<br>Extrapolated Strength --- 20th Place [24.36%]<br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 16th Place [30.7% ]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 17th Place [29.58%]<br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 12th Place [32.22% ]<br> <br>My
former personal favorite Final Fantasy character (well, tied with
Vincent) has a place near and dear to my heart. And apparently much of
GameFAQs feels the same way, because, 2002 outing aside, Squall has
been a <i>force</i> in these contests, and we all took notice the
first time we saw him beat Luigi to within an inch of his life. It's
much deserved, too -- whether it be in Final Fantasy VIII or Kingdom
Hearts, Squall has all kinds of awesome going for him.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/28/2006 9:52:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337567282">message detail</a>
 | #467</td></tr>
<tr class="even"><td>It's a shame that he got kind of screwed this
contest by getting Solid Snake in the second round (though he has more
of a shot than you might think), so we're not going to be able to see
him stretch his new KH2 wings much. Not to mention he still has that
whole Devil Division baggage potentially hampering him. Then again, if
Squall wanted an upset run that would make his win over Luigi look like
child's play, the time is now... WOO SQUALL<br> <br><b>TIDUS</b><br> <br><i>"I know it's selfish...but this is my story!"</i><br> <br>Summer 2002 Contest<br>Extrapolated Strength --- 11th Place [33.8%]<br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 13th Place [33.14% ]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 24th Place [25.35%]<br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 26th Place [27.16% ]<br> <br>However <i>!!</i> Spotlight falls now on Tidus for me -- the man who is now my <i>new</i>
favorite FF character! I didn't think it would be possible for anyone
to beat out the Squincent duo, but Tidus through his actions in FFX
cracked into my top ten. And it's a damn shame that he's just a
midcarder in all probability...though I can't say he's entirely
blameless for it. &lt;_&lt;<br> <br>He's also known in these contests
for being a fraud, though that's more Magus' fault than anything.
Still, the once thought near-elite now just a midcarder...and worse
he's in a virtually unwinnable match -- a SFF match at that, so no love
there. I mean, come on, he could decimate 95% of the women's field...<br><br><i>Notable Releases Since Last Appearance</i><br><br>Squall Leonhart: Kingdom Hearts 2 (PS2)<br>Tidus: N/A<br><br><i>Upcoming Releases</i><br><br>Squall Leonhart: N/A<br>Tidus: N/A<br> <br>This
is a boring match that won't tell us much about either character thanks
to the SFF potential. Squall is a lock here, alright -- they've got the
common opponent in Kirby, Squall won big while Tidus lost bigger. The
percentages might be weird depending on which way the core fanbase
splits, but the only thing to watch out for in this match will be
seeing two of the best characters going at it -- and the inevitable
fanboy arguments that will ensue.<br> <br>...aw.<br><br>Karma Hunter's Vote: Tidus. I considered abstaining, but Tidus needs a bit of support.<br><br><b>Karma Hunter's Krazy Prediction: Squall Leonhart with 64.22%.</b><br> <br>A safe, boring pick that exceeds the X-Stats' prediction by enough to call some SFF on it. Um...yay. <br><br>Upset Potential: 1%<br> <br>After a lot of thought, Tidus doesn't have <i>zero</i>
chance in this matchup...sure it might as well be, but he's got one
thing on his side -- without Kingdom Hearts, there's very strong case
for Tidus &gt; Squall. That doesn't mean much since Kingdom Hearts,
y'know, <i>exists</i> and all that, but if Tidus is stronger than
Squall without it, there's a case for scoring SFF there. And if you
score enough SFF, it could theoretically overcome the KH disadvantage
and become a win by rSFF!<br> <br>Of course, that would make us have to
assume that Tidus could score major SFF on Squall (we're talking
Cloud-like here), assume that Tidus is stronger than Squall without KH
in the first place (hey, Snake/Squall strangeness!), and a bunch of
other ridiculous factors that contradict what's staring us straight in
the face.<br> <br>Chalk up even this 1% potential to newly found Tidus fanboyism.<br> <br>Upset Prediction: Tidus with 51.08%<br><br><br><br><b>Guest&#8217;s Analysis</b> - <i>Ken "Cena" Masters</i><br><br>First
things first, it's good to be doing an analysis write-up again. It
feels like it's been a little too long since I was a full-time part of
the crew.<br><br>Secondly, I don't think there is any need to bring up
past polls to describe voting patterns either. This is 2006, not 2005,
and definitely not 2004. Kirby won't have dick-all to do with anything
this year.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/28/2006 9:53:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337567496">message detail</a>
 | #468</td></tr>
<tr class="even"><td>So without further adieu, we'll get on with it.
Now, the match I have the pleasure of addressing is Squall Leonhart vs
Tidus. Let's get a few things out of the way. Both are from Final
Fantasy games in which they're the main character. They're also pretty
similar from what I've surmised. I haven't gotten far in FFX, and I've
yet to play FF8, but I'm sure it won't make a hell of a lot of
difference on voting. Basically, the character's personalities seem to
be similar. So, how much does this lend to those magical three letters
that everybody will be mouthing the moment they read this sentence?<br><br>Probably
not a whole lot. Neither picture seems to show any amount of
man-boobies that could bring in quite a few number of votes.<br><br>Oh...
thought I meant SFF? With the characters being so similar (which I
previously mentioned), I think these two are even in the amount of fans
they've got. Unless I'm totally rusty at this whole 'analysis' thing,
I'll bet SFF means just as much as TJF... well, slightly more, but it
won't be why anybody's going to win this. You know how much I
exaggerate things, Board 8.<br><br>I'm not sure what most people are
thinking about this one, to be honest. Somebody out there is going to
think it'll be a squash, but I'm on the fence. It's fairly easy to
guess that Squall's going to win, but by how much? I'm not a fan of the
X-Stats, but I can guess that it'll show Squall winning by a fair
margin. The thing about that is that's pretty obvious without knowing
X-Stats.<br><br>Some brackets have Tidus winning, and more have Squall
winning. It's just the way it is, and I think the majority's got it
right.<br><br>There are quite a lot of factors in this match that could
lend to either character, but I think I'm pretty safe with what I've
got in the bracket, and who I plan on voting for.<br><br><b>Ken "Cena" Masters' (Still Perfect) Bracket Pick</b>: <br><br>Squall Leonhart<br><br><b>Ken "Cena" Masters' Prediction</b>:<br><br>Squall Leonhart with 57.21%.<br><br> <br> <br>Crew Consensus: Squall wins this FF showdown. Mid 50's to mid-60's is looking right.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/28/2006 9:55:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337568013">message detail</a>
 | #469</td></tr>
<tr class="even"><td>
The highest pick for me again? It's been working well enough so far!<br><br>Though in terms of preference I do hope I end up in last this time around.<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/28/2006 10:23:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337573760">message detail</a>
 | #470</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>These are usually the easy
kinds of matches: the matches with characters from the same series (or,
the SFF matches, for those contest junkies). You just have to figure
out which one is the stronger of the two, and that's usually not hard.
And just taking a quick look back shows that Squall has been perhaps
the strongest consistent Final Fantasy character outside of Cloud and
Sephiroth (too small of a sample for Vincent and Aeris), and Tidus has
been nothing more than mediocre.<br><br>My vote: Ugh, do I even have to vote in this one? Fine, Squall.<br>My bracket: Squall<br>My prediction: Squall with 73%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/28/2006 10:26:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337574307">message detail</a>
 | #471</td></tr>
<tr class="even"><td>
*looks at my Squall prediction*<br><br>*looks at the Crew's Squall prediction*<br><br>Yeah........that's
why I don't belong in the Crew (that, or I'll look like a genius and
laugh at you all for wildly underestimating Squall).<br><br>But hey, I
might actually be beating the crew this match....Snake just has to stay
above 82.11%....you can do it Snake, hold him off!<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/28/2006 11:03:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337581333">message detail</a>
 | #472</td></tr>
<tr class="even"><td>
82.15%, yay me!<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3469883" class="name">Ken Masters</a> |
Posted 9/28/2006 11:04:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337581487">message detail</a>
 | #473</td></tr>
<tr class="even"><td>
I think Molly might take this one.<br>---<br><b>Formerly CenaStone</b><br><b>Character Contest Score</b>: Perfect - Next Controversial Picks: Squall, Yoshi, Phoenix, Vincent, Zero
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=795464" class="name">Tatl</a> |
Posted 9/28/2006 11:06:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337581934">message detail</a>
 | #474</td></tr>
<tr class="even"><td>
Re-Tagging<br>---<br>"I reject your reality and substitute my own." ~ Adam Savage; Insanity Personified<br>"Crikey!" ~ Steve Irwin (R.I.P.); Perfection Personified
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/28/2006 11:10:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337582696">message detail</a>
 | #475</td></tr>
<tr class="even"><td>
Looks like Karma Hunter wins his third straight point with his third
straight highest prediction. I'm going to let my jealousy shine through
by calling him Lopen Hunter for the rest of the contest.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/28/2006 11:30:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337586356">message detail</a>
 | #476</td></tr>
<tr class="even"><td>
Damn, KH is on FIYAH!<br>---<br>CB06 - Score: <b>16/17 </b>Rank: <b>Tied - 2764th </b>Yesterday's Pick:<b> Solid Snake</b> <br>Today's Pick: <b>Squall</b> Tomorrow's Pick: <b>Yoshi</b> Losses: <b>Cortana</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/29/2006 5:45:41 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337615258">message detail</a>
 | #477</td></tr>
<tr class="even"><td>
...Yikes.  When these guys blow out, they <i>really</i> blowout...<br><br>Snake/Squall might be an interesting match to analyse at this point...but, well, Snake still wins.<br><br>Lopen Hunter sounds right...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=2665492" class="name">XIII_rocks</a> |
Posted 9/29/2006 1:48:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337658666">message detail</a>
 | #478</td></tr>
<tr class="even"><td>
When were the analysis sign ups for the male half even posted? Along with the female half? I can't remember.<br>---<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738</a> Sign plz<br>Hi-ho, Hi-ho, <b>Z1m Zum, Z1m Zum</b>...our guru champ.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=367686" class="name">Weird Kirby Dude11</a> |
Posted 9/29/2006 1:50:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337659064">message detail</a>
 | #479</td></tr>
<tr class="even"><td>
<i>DpObliVion | Posted 9/28/2006 11:26:10 PM | message detail<br>*looks at my Squall prediction*<br><br>*looks at the Crew's Squall prediction*<br><br>Yeah........that's
why I don't belong in the Crew (that, or I'll look like a genius and
laugh at you all for wildly underestimating Squall).</i><br><br>So, Dp ends up looking like a genius... &gt;_&gt;<br>---<br>Weird Kirby Dude - spud2002 is alive! &gt;_&gt;<br><b>Minnesota Twins:</b> 89-61
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/29/2006 6:45:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337717814">message detail</a>
 | #480</td></tr>
<tr class="even"><td>
Solid Snake................82.15% 89697<br>Soma Cruz.................17.85% 19487<br>TOTAL VOTES.......................109184<br><br>96.53% of the brackets predicted this match correctly.<br><br>Snake ain't playing no games! He makes Soma look like fodder...or perhaps Soma is fodder. Who knows...<br><br>Today, Squall is...embarrassing Tidus. He's used to it though.<br><br>Lopen - 5<br>Ulti - 4<br>KH - 3<br>Moltar - 3<br>Yoblazer - 1<br>Guest (Wigs) - 1<br>HM - 1<br><br>KH gets another point with his highest pick.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Squall vs. Tidus - Bracket: <b>Squall</b> - Vote: <b>Squall</b> (16/17)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3602792" class="name">Garsha_III</a> |
Posted 9/29/2006 8:01:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337733344">message detail</a>
 | #481</td></tr>
<tr class="even"><td>
Are there any archives to past Analyses from the crew?<br>---<br>George Harrison &gt; Flonne
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/29/2006 8:19:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337737040">message detail</a>
 | #482</td></tr>
<tr class="even"><td>
Yup.<br><br><a class="linkification-ext" href="http://www.gamefaqscontests.com/drupal/node/9" title="Linkification: http://www.gamefaqscontests.com/drupal/node/9">http://www.gamefaqscontests.com/drupal/node/9</a><br><br>Oh, and HOT DAMN KAY AITCH IS PUMMELIN' DA CREW seems appropriate here.<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/29/2006 8:35:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337740292">message detail</a>
 | #483</td></tr>
<tr class="even"><td>
<b>Patriot Division:</b> <i>Round 1 - Match 19</i> &#8211; (3)Riku vs. (6)Yoshi <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Riku</b><br>Game/Series Known From: Kingdom Hearts<br>Extrapolated Rank in 2005: 45th (18.43%) - Adjusted Value: 36th (22.12%)<br>Seed in 2005: 4<br>Lost in 2005 to Frog in Round 1<br><br>Looks like KH2 brings Riku back to the Contest-setting.<br><br><b>Yoshi</b><br>Game/Series Known From: Super Mario<br>Extrapolated Rank in 2003: 23rd (27.05%)<br>Extrapolated Rank in 2004: 38th (18.26%) - Adjusted Value: 26th (25.22%)<br>Extraploated Rank in 2005: 32nd (22.69%) - Adjusted Value: 27th (26.59%)<br>Seed in 2003: 4<br>Seed in 2004: 5<br>Seed in 2005: 3<br>Lost in 2003 to Bowser in Round 2<br>Lost in 2004 to Link in Round 3<br>Lost in 2005 to Mega Man in Round 3<br><br>Yoshi&#8217;s seeding may look weak, but this dino is tough.<br><br>Seems
as if the more time the Contest goes on, the more people bring up this
match. I don&#8217;t know why though. Yeah, Riku has had KH2, which should
make him a bit stronger than last year, but in Yoshi&#8217;s league? No way. <br><br>Yoshi
is a strange case as it is. He always performs very well on opponents
weaker than him, but then he always ends up facing a Nintendo character
stronger than he is in the end, and thus suffers SFF every year. 2003
is the closest to a real value we have on him, and since then, there
have been Nintendo boosts and such. Finally, this year we may actually
get an accurate value on Yoshi! Right now, he&#8217;s projected to have a
close match against Dante, which would put him near 30% on BL. I
wouldn&#8217;t think of putting Riku that high. In fact, I&#8217;d go as far to say
that Yoshi/Sora would be nearly even.<br><br>So yeah, unless you think
Mega Man&#8217;s performance against Yoshi wasn&#8217;t SFF, this match isn&#8217;t in
any question. Yoshi wins without much trouble.<br><br><b>Moltar&#8217;s Bracket Says:</b> Yoshi will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Riku: 40% - Yoshi: 60%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>We've
never had a good reading on Yoshi. Ever. He was behind SFF in 2003,
2004 AND 2005 (Bowser, Link, Mega Man). The best people can do is
extrapolate Yoshi through other characters and hope his value is
accurate.<br><br>Which means little here, because Riku ain't winning even with KH2.<br><br>Prediction: Yoshi with 59.01%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>Unless I&#8217;m mistaken, this is the <i>first</i>
Nintendo/Square match-up of the contest! What will ultimately become
the norm this contest, the Nintendo character looks primed to take care
of business. Yoshi came out with as a beneficiary of the Nintendo Boost
last year, and may even get another smaller boost this year thanks to
the increased DS ownership and NSMB. Riku, on the other hand, looks to
be coming off a strong showing in Kingdom Hearts II. Some have
speculated that he may have some upset potential, but I&#8217;m just not
seeing it myself. <br><br>The only way Yoshi can have trouble winning
this one is if he is overrated. Personally, I don&#8217;t see him being
overrated by very much, if at all, from where he stood in 2005. I don&#8217;t
necessarily buy the &#8220;Luigi is his floor&#8221; business, but where he sits
now is far out of Riku&#8217;s reach, even with KH2. Despite how some expect
a close match, I&#8217;m expecting a clear favoring toward Mario&#8217;s dinosaur
companion. Yoshi wins this won without trouble, racking up one of many
wins for Nintendo. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Yoshi<br><br><b>Aitch Emm&#8217;s Prediction:</b> Yoshi &#8211; 56% ; Riku &#8211; 44%<br><br><b>Aitch Emm&#8217;s Vote:</b> Yoshi<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>I've
touted that Riku over Yoshi is one of the best Squall/Luigi,
Knuckles/Magus, Master Hand/Kuja-type upsets in this bracket. Other
than that, surprisingly, I can't seem to find a single witty or
informative thing to write about this one. Hmm... YOSHI IS GOING TO EAT
RIKU AND LAY HIM OUT AS AN EGG. HAHA.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/29/2006 8:35:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337740428">message detail</a>
 | #484</td></tr>
<tr class="even"><td>If Riku manages to keep this match somewhat close,
it will be a great indicator of Kingdom Hearts II making a significant
impact. If he gets beaten easily, it will probably mean that any boosts
from the sequal aren't as significant as they were from the original
KH. Personally, I think KHII will boost several Square characters.
However, I feel that Nintendo will be even more dominant this year than
it was in 2005, so I'm giving Yoshi the easy win.<br><br>My prediction: Yoshi def. Riku (61-39)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Yay, a seeding upset, yay, a seeding upset! It's about ti&#8230;<br><br><i>Not so fast, Crewba!</i><br><br>That's right&#8230; not so fast. Slow it down&#8230; <i>sloowww</i>.
At first, I thought this was an easy win for Yoshi, just like all of
you. Luigi looked so good last year, and Yoshi beat him 55-45, so
therefore Yoshi should look pretty good last year too, right? Oh,
forget Mega Man getting equipped with "blow Yoshi's face off&#8230; beam",
that was SFF, right guys?<br><br>Oh yeah, <i>maybe</i> it was SFF. But
I've got a different theory. But before I bring that theory up for you
readers, I'll give a little Yoshi match history lesson. No, I'm not
going to go over every match, I'll just summarize it for you.
Basically, we can split Yoshi's matches into three categories:<br><br>1. Yoshi kicks the ass of some fodder, we're all <i>very</i> impressed.<br><br>2. Yoshi does well against one of his Mario buddies.<br><br>3. Yoshi gets <i>stomped</i> by the enemy that isn't one of the above (Mega Man and Link, it's understandable give him a break)<br><br>So what we've got here is Yoshi failing to really do anything against something that isn't Mario. One could say&#8230; he <i>does well against Mario characters</i>. Whoops!<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2328" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2328">http://www.gamefaqs.com/poll/index.html?poll=2328</a><br><br>What
the hell was that I just dropped? Some poll? Oh yeah, go look at it.
You'll see Yoshi taking some sorta sick pleasure out of kicking the
crap out of all his friends <i>again</i>. So I'm thinking&#8230; maybe
little Yoshi might not have been SFFed against Mega Man at all! Maybe
Mega Man v Yoshi was just Mega Man simply refusing to take Yoshi's
"bully yer friends" crap.<br><br>Alright, now let's assume Mega Man
exposed Yoshi as a weakling. Even then, Riku still doesn't have a free
pass. Frog did pretty horribly against Samus last year after beating
Riku. So Riku didn't look <i>that great</i> either. But&#8230; but&#8230; we
mustn't forget Kingdom Hearts 2. How much could Riku gain from that?
Well, I'm sure he'd easily trump Frog were they to rematch, for one.
Would it be enough to overtake a Yoshi who isn't really as good as he
wants us to think? Yeah, I think so.<br><br>So what two things did we just learn here? Yoshi is a horrible friend, a real punk. And also, Kingdom Hearts 2 Boost.<br><br><b>Lopen's Prediction:</b> Riku with 52.76%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>RIKU</b><br> <br><i>"You always were chatty when it came to darkness."</i><br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 36th Place [22.12%]<br> <br>Riku returns! Fresh off of KH2, it's the first original KH character <i>returning</i>
to the bracket...and he's got one whopper of a match ahead of him. A
shame that he's in all probability wasted, but it'll be cool to see how
he performs and attempt to gauge if even the most minimal of roles in
KH2 help characters out. WOO RIKU <br> <br><b>YOSHI</b><br> <br><i>"Yoshi!"</i><br> <br>Summer 2003 Contest<br> <br>Extrapolated Strength --- 23rd Place [26.17%]<br> <br>Summer 2004 Contest<br>Extrapolated Strength --- 26th Place [25.22% ]<br>Summer 2005 Contest<br>Extrapolated Strength --- 27th Place [26.59% ]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/29/2006 8:36:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337740638">message detail</a>
 | #485</td></tr>
<tr class="even"><td>
The big Mario fan-favorite returns, and is primed to try his hand at
another winnable fourpack before bowing out to elite competition. Yoshi
is definitely an odd one to gauge, though if you assume that he
increased in relative proportion to Bowser and Luigi he's the big
favorite for taking down this fourpack. Unfortunately, Yoshi's never
really been tested against non-SFF competition around his level of
strength. This is a virtual lock for him...but he'll be looking to
impress here. WOO YOSHI<br> <br><i>Notable Releases Since Last Appearance</i><br><br>Riku: Kingdom Hearts 2 (PS2)<br>Yoshi: N/A<br><br><i>Upcoming Releases</i><br><br>Riku: N/A<br>Yoshi: N/A<br> <br>I
know this match is getting some hype...but, I'm sorry, I just can't
understand it. KH2 isn't going to allow Sora to beat Mega Man, and I
can't see this match being much different from that. I mean, there's a
shot here for Riku with some crazy theories, but Yoshi just feels like
he's not getting enough credit here. I personally don't care much for
the guy, but his potential scares me. I actually struggled on
Snake/Yoshi a little...yeah, second Nintendo boost and all that.
&lt;_&lt;<br> <br>Not too much else to see here...though look out for the votals! =D<br><br>Karma Hunter's Vote: Riku. Riku ain't much in KH or KH2, but his CoM personality is made of win.<br><br><b>Karma Hunter's Krazy Prediction: Yoshi with 58.22%.</b><br> <br>...I was tired of going high, anyway! Yeah. &lt;_&lt; <br><br>Upset Potential: 9.5%<br> <br>Hey, I guess it's not <i>impossible</i>...with an overestimated Yoshi and a crazy KH2F, it could happen. Still, 48% on the Frog I saw in 2005 is not too assuring.<br> <br>Ah, well. Go get 'em, Riku.<br> <br>Upset Prediction: Riku with 52.46%<br> <br><br><br><b>Guest&#8217;s Analysis</b> - <i>BigBob</i><br><br>When
I was filling out my bracket, Riku/Yoshi was the match that put a snag
in my bracket. Sure, matches like The Boss/Celes and Terra/Kerrigan
made me pause for a moment, but when I saw this match I just kinda
stopped. I ended up filling the rest of the bracket as much as I could
before I finally had to decide on a winner here.<br><br>With good
reason, too. 2k3 proved Kingdom Hearts was a force to be reckoned with,
as all the Square cameos overperformed like crazy that year. Sora has
done well despite his beating at the hands of Snake last year, and Riku
nearly beat Frog BEFORE Kingdom Hearts II. On the other hand, nobody
really knows where Yoshi stands. He got SFF'd to death by Link in 2k4,
and may have been SFF'd by Mega Man last year. This will be the first
year Yoshi isn't going to die in a SFF match, and the first chance
we'll get to see how strong he is. He may end up strong enough to beat
Dante (which I agonized over just as much as this match), or he could
lose to Riku in round 1.<br><br>The sheer randomness of these two
characters is what makes this match so hard to call. I picked Yoshi,
but the upset potential is there.<br><br>Yoshi with 53.4%.<br><br> <br> <br>Crew Consensus: Majority says Yoshi, Lopen says Riku. Consensus seems to be Yoshi in the mid-to-high 50's.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/29/2006 8:47:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337742712">message detail</a>
 | #486</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Riku vs. Yoshi, finally.
Kingdom Hearts is pretty popular right now, but I have a hard time
believing that a KH character other than the main character could beat
a Nintendo legend and Mario party member. As popular as KH is....SMW
and SSBM are more popular.<br><br>My vote: Yoshi<br>My bracket: Yoshi<br>My prediction: Yoshi with 61%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/29/2006 8:51:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337743524">message detail</a>
 | #487</td></tr>
<tr class="even"><td>
<i>*looks at my Squall prediction*<br><br>*looks at the Crew's Squall prediction*<br><br>Yeah........that's why I don't belong in the Crew <b>(that, or I'll look like a genius and laugh at you all for wildly underestimating Squall)</b>.</i><br><br>HA!  I just killed the crew with my Squall/Tidus prediction.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3623587" class="name">Gaddswell</a> |
Posted 9/29/2006 9:51:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337755939">message detail</a>
 | #488</td></tr>
<tr class="even"><td>
Almost 500<br>---<br>By the time we localize the programs, kids don&#8217;t even know they&#8217;re from Japan any more. - 4Kids CEO Al Kahn<br><b>Vote Right! Phoenix Wright!</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=640243" class="name">Big Bob</a> |
Posted 9/29/2006 10:15:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337761107">message detail</a>
 | #489</td></tr>
<tr class="even"><td>
As much as I like Yoshi and though it would hurt my bracket, seeing Riku pull the upset would silence so many naysayers.<br>---<br><i>My bracket is so screwed.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/29/2006 11:52:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337779732">message detail</a>
 | #490</td></tr>
<tr class="even"><td>
Squall Leonhart vs. Tidus<br>+7 KH<br>+6 Mo<br>+5 Yo<br>+4 HM<br>+3 Lo<br>+2 Ulti<br>+1 Guest<br><br><b>The Rankings</b> (Through Squall vs. Tidus)<br>1. Karma Hunter (86)<br>2. Master Moltar (78)<br>3. UltimaterializerX (74)<br>4. Heroic Mario (70)<br>4. Yoblazer (70)<br>6. Lopen (56)<br>7. Board 8 (48)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/29/2006 11:53:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337779866">message detail</a>
 | #491</td></tr>
<tr class="even"><td>
Another good start for me! &lt;_&lt;<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/30/2006 3:03:38 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337799498">message detail</a>
 | #492</td></tr>
<tr class="even"><td>
Damn man, you're going for 4 in a row with this one. Hopefully Yoshi stays constant.<br>---<br>CB06 - Score: <b>17/18 </b>Rank: <b>Tied - 2206th </b>Yesterday's Pick:<b> Squall Leonhart</b> <br>Today's Pick: <b>Yoshi</b> Tomorrow's Pick: <b>Dante</b> Losses: <b>Cortana</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/30/2006 5:37:21 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337806830">message detail</a>
 | #493</td></tr>
<tr class="even"><td>
<i>Lopen shoots himself in the foot once again!</i><br><br>Also, great
job Karma Hunter! I doubt Riku will drop in percentage much- this is a
weekend, so no after-school vote- so you probably have this point...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/30/2006 8:45:19 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337817971">message detail</a>
 | #494</td></tr>
<tr class="even"><td>
Riku's looking impressive here...*too* impressive. I'm going to end up losing my streak to <i>Aitch Emm</i> of all people! =(<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3657433" class="name">LusterSoldier</a> |
Posted 9/30/2006 12:26:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337849989">message detail</a>
 | #495</td></tr>
<tr class="even"><td>
Riku's stealing the day vote now.<br>---<br><b>Luster Soldier</b> - Pwned by Repus_Yortsed<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/30/2006 6:51:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337927687">message detail</a>
 | #496</td></tr>
<tr class="even"><td>
New topic is up...should get to saving this one...<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Riku vs. Yoshi - Bracket: <b>Yoshi</b> - Vote: <b>Yoshi</b> (17/18)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=834874" class="name">MarkSmith</a> |
Posted 9/30/2006 6:52:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337927841">message detail</a>
 | #497</td></tr>
<tr class="even"><td>
501<br>---<br>PROUDEST MEMBER OF THE FIGHTIN' TEXAS AGGIE CLASS OF 2010<br>Next game: ARMY (2-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=834874" class="name">MarkSmith</a> |
Posted 9/30/2006 6:53:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337927954">message detail</a>
 | #498</td></tr>
<tr class="even"><td>
teh 500?<br>---<br>PROUDEST MEMBER OF THE FIGHTIN' TEXAS AGGIE CLASS OF 2010<br>Next game: ARMY (2-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 9/30/2006 6:53:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337928018">message detail</a>
 | #499</td></tr>
<tr class="even"><td>
Yay, I got Terra!<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i><br>Michelle.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3221156" class="name">ChaoChaoSuperqq</a> |
Posted 9/30/2006 6:53:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337928073">message detail</a>
 | #500</td></tr>
<tr class="even"><td>
Hehehe.<br>---<br>I have a Zombie Movie Projector in my backpack! And I'm not afraid to use it!
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=8">9</a></li>
<li>10</li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage10_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30499515&amp;page=9" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
<div id="copyright">
	<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
	<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
	<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
</div>
<script src="genmessage10_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</div></body></html>