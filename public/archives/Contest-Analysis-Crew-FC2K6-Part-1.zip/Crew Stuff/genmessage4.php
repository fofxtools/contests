<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	



<title>GameFAQs - GameFAQs Contests Message Board</title><meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage4_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage4_files/nogs.css"></head><body linkifytime="180" linkified="3" linkifying="false"><div id="container">
	<div id="gne_nav">
		<img src="genmessage4_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/events/x06/">X06</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage4_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30499515%26page%3D3"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage4_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage4_files/advertisement.gif" alt="advertisement" height="10" width="120"></div>
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage4_files/f.xhtml" marginwidth="0" marginheight="0" hspace="0" vspace="0" allowtransparency="true" frameborder="0" height="90" scrolling="no" width="728">
&lt;script language=javascript&gt;&lt;!-- randNum = ((new
Date()).getTime() % 2147483648) + Math.random(); document.write( "&lt;a
href='http://a.tribalfusion.com/i.click?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID="
+ randNum + "' target=_blank&gt;" + "&lt;img
src='http://a.tribalfusion.com/i.ad?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID="
+ randNum + "'" + " width=728 height=90 border=0 alt='Click
Here'&gt;&lt;/a&gt;"); // --&gt;&lt;/script&gt; &lt;noscript&gt; &lt;a
href="http://a.tribalfusion.com/i.click?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID=1576037958"
target=_blank&gt; &lt;img
src="http://a.tribalfusion.com/i.ad?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID=1576037958"
width=728 height=90 border=0 alt="Click Here"&gt;&lt;/a&gt;
&lt;/noscript&gt; </iframe><img src="genmessage4_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;page=3">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30499515" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=2">Previous Page</a> |
Page 4 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=4">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/16/2006 9:42:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335007566">message detail</a>
 | #151</td></tr>
<tr class="even"><td>
I <i>would</i> mind, seeing as how the analysis itself is just...blech. And I like my bracket!<br><br>But in terms of The Boss' character, meh. We needed Meryl here! &lt;_&lt;<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=264094" class="name">Heroic Mario</a> |
Posted 9/16/2006 9:44:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335008039">message detail</a>
 | #152</td></tr>
<tr class="even"><td>
Meryl sucks hard though. &gt;&gt;<br><br>---<br><i>...a lone figure shining in the toxic shadows. She comes dressed for war, and her wrath is terrible.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/16/2006 9:45:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335008291">message detail</a>
 | #153</td></tr>
<tr class="even"><td>
I'd rather have seen Mei Ling or Paramedic than The Boss or Meryl.  <br><br>Hell, I'd rather have seen Rose, just for the humor.  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 9/16/2006 9:46:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335008448">message detail</a>
 | #154</td></tr>
<tr class="even"><td>
I nominated Mei Ling.<br><br>*drools*<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/16/2006 9:49:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335009246">message detail</a>
 | #155</td></tr>
<tr class="even"><td>
Mei Ling would have been fine, too. Same with Sniper Wolf. I was just
thinking of a female that would be the closest to The Boss.<br><br>But eww at Rose. She doesn't need to be anywhere near this contest (or another game) ever, EVER again. <br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 9/16/2006 9:50:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335009474">message detail</a>
 | #156</td></tr>
<tr class="even"><td>
Emma Emmerich &gt; Most MGS females<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=264094" class="name">Heroic Mario</a> |
Posted 9/16/2006 9:51:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335009658">message detail</a>
 | #157</td></tr>
<tr class="even"><td>
The Boss  &gt; &gt; All MGS females.<br><br>---<br><i>...a lone figure shining in the toxic shadows. She comes dressed for war, and her wrath is terrible.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/16/2006 9:51:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335009777">message detail</a>
 | #158</td></tr>
<tr class="even"><td>
Here's a question:  Snake vs Rose, does Rose do worse than Tanner?  Rose vs Tingle, that'd be a good match too.  <br><br>Man, screw Jay Solano, what we need is Rose.  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=264094" class="name">Heroic Mario</a> |
Posted 9/16/2006 9:52:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335009957">message detail</a>
 | #159</td></tr>
<tr class="even"><td>
Tingle would beat the <i>hell</i> out of Rose. <br><br>--<br><i>...a lone figure shining in the toxic shadows. She comes dressed for war, and her wrath is terrible.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/16/2006 9:56:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335010910">message detail</a>
 | #160</td></tr>
<tr class="even"><td>
Meryl &gt; Wolf &gt; Chris &gt; Emma &gt; Naomi &gt; Mei Ling &gt;
Nastasha &gt; EVA &gt; Para-Medic &gt; Fortune &gt; Olga &gt; The Boss
&gt; Natasha &gt; Holly &gt; Diane
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;
Rose<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/16/2006 10:52:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335024281">message detail</a>
 | #161</td></tr>
<tr class="even"><td>
AW YEAH HIGHEST ****IN' PICK BY .06% BABY HEROIC MARIO'S GOIN' DOWN AGAIN WOO WOO WOO.<br><br>Ahem.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/17/2006 12:50:15 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335048888">message detail</a>
 | #162</td></tr>
<tr class="even"><td>
The last time I started off the analysis crew this hot, it was the spring of 2004. And we all know what happened that contest.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=863018" class="name">Janus5000</a> |
Posted 9/17/2006 12:50:41 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335048963">message detail</a>
 | #163</td></tr>
<tr class="even"><td>
You missed SMRPG/SFII.<br>---<br>"Those who cast the vote decide nothing. Those who count the vote decide everything."<br><a class="linkification-ext" href="http://www.scorehero.com/scores.php?user=2916&amp;diff=4" title="Linkification: http://www.scorehero.com/scores.php?user=2916&amp;diff=4">http://www.scorehero.com/scores.php?user=2916&amp;diff=4</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=264094" class="name">Heroic Mario</a> |
Posted 9/17/2006 12:50:55 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335049007">message detail</a>
 | #164</td></tr>
<tr class="even"><td>
<i>AW YEAH HIGHEST ****IN' PICK BY .06% BABY HEROIC MARIO'S GOIN' DOWN AGAIN WOO WOO WOO.</i><br><br>I get screwed out of many a point this way. &gt;&gt;<br><br>---<br><i>...a lone figure shining in the toxic shadows. She comes dressed for war, and her wrath is terrible.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/17/2006 12:51:39 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335049115">message detail</a>
 | #165</td></tr>
<tr class="even"><td>
Tifa Lockheart vs. Ivy Valentine<br>+6 Lopen<br>+5 KH<br>+4 Mo<br>+3 Ulti<br>+2 Yo<br>+1 HM<br><br><b>The Rankings</b> (Through Tifa vs. Ivy)<br>1. UltimaterializerX (23)<br>2. Heroic Mario (18)<br>2. Karma Hunter (18)<br>4. Lopen (13)<br>4. Yoblazer (13)<br>6. Master Moltar (9)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/17/2006 12:55:53 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335049770">message detail</a>
 | #166</td></tr>
<tr class="even"><td>
I'm never gonna get a point at this rate. I'm the worst Crew addition ever! ;_;<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/17/2006 12:56:40 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335049898">message detail</a>
 | #167</td></tr>
<tr class="even"><td>
Wait, I actually look kinda good in yo's rankings. YEAH SCREW THAT OTHER STUFF I'M DOING PRETTY GOOD!<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/17/2006 1:55:49 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335057967">message detail</a>
 | #168</td></tr>
<tr class="even"><td>
Oh ****, I missed an analysis.  Damn alcohol...okay.,.... umm....<br><br><i>DpOblivion's Drunken Quick Analysis</i><br><br>Ok, I picked The Boss, I swear!  Because, umm....MGS &gt; FF? Wait, no, that's not right.  Ummm........just because.<br><br>My Vote: Boss<br>My Bracket: Boss<br>My
Prediction: Boss....wouldnt be right to post a % after the match has
been underway for 3 hours, but I certainly wouldnt have predicted a
blowout like this.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br>**Character Battle V PRINTABLE BRACKET** See quote for link.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/17/2006 6:33:32 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335074538">message detail</a>
 | #169</td></tr>
<tr class="even"><td>
Wow. The Crew is unanimous on a match that is rather disputed. Last
time that happened, KH defeated the crew's choice, Castlevania. And
now...<br><br>Oh well, it's good for my bracket!  Still perfect!<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/17/2006 1:27:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335132449">message detail</a>
 | #170</td></tr>
<tr class="even"><td>
The Boss vs. Celes Chere<br>+6 Ulti<br>+5 HM<br>+4 Mo (tie)<br>+4 Yo (tie)<br>+2 KH<br>+1 Lo<br><br><b>The Rankings</b> (Through The Boss vs. Celes)<br>1. UltimaterializerX (29)<br>2. Heroic Mario (23)<br>3. Karma Hunter (20)<br>4. Yoblazer (17)<br>5. Lopen (14)<br>6. Master Moltar (13)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 9/17/2006 3:08:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335156214">message detail</a>
 | #171</td></tr>
<tr class="even"><td>
Analysis sent, Moltar.<br>---<br>This was Ed Bellis, servant to the mighty Guru <b>Z1mZum</b>. Congrats, buddy!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/17/2006 4:35:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335177905">message detail</a>
 | #172</td></tr>
<tr class="even"><td>
Tifa Lockhart..........76.18% 96118<br>Ivy Valentine...........23.82% 30046<br>TOTAL VOTES................126164<br><br>90.96% of the brackets predicted this match correctly.<br><br>Tifa easily triples Ivy. While she didn't look too impressive throughout the day, she still ended above 76%<br><br>Today, FF6 doesn't fail to disappoint again. The Boss is making easy work of Celes.<br><br>Lopen - 2<br>Ulti - 2<br>HM - 1<br>Moltar - 0<br>Yoblazer - 0<br>KH - 0<br>Guest - 0<br><br>Lopen's pick = the closest.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>The Boss vs. Celes - Bracket: <b>The Boss</b> - Vote: <b>The Boss</b> (4/5)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/17/2006 7:08:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335216785">message detail</a>
 | #173</td></tr>
<tr class="even"><td>
<b>Limit Division:</b> <i>Round 1 - Match 7</i> &#8211; (3)Jill Valentine vs. (6)Sheena Fujibayashi <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Jill</b><br>Game/Series Known From: Resident Evil <br>Extrapolated Rank in 2002: 16th (27.37%)<br>Extrapolated Rank in 2003: 28th (25.38%)<br>Extrapolated Rank in 2004: 29th (20.64%) <br>Seed in 2002: 3<br>Seed in 2003: 11<br>Seed in 2004: 14<br>Lost in 2002 to Link in Round 3 <br>Lost in 2003 to Squall in Round 1<br>Lost in 2004 to Ryu H. in Round 1<br><br>Seems Jill has been getting weaker as time passes. She was a threat in &#8216;02, but not so much in &#8217;04.<br><br><b>Sheena</b><br>Game/Series Known From: Tales of Symphonia<br><br>Another ToS character. My favorite female, Sheena, enters the fray.<br><br>Oh
man, this match blows. Instead of Sheena getting an easy opponent like
Amy Rose, she gets Jill Valentine. Jill has been a character on the
decline since 2002. Back then, she was able to beat Kirby. Now she goes
toe-to-toe with low-midcarders like Ryu Hayabusa.<br><br>Jill should be
safe in this match though. Sheena shouldn&#8217;t be any stronger than Kratos
(ToS). Kratos isn&#8217;t even as strong as Jill is, so there&#8217;s no way Sheena
can be stronger using that logic. Still, I hope Sheena does well, if
only for my bias alone.<br><br><b>Moltar&#8217;s Bracket Says:</b> Jill will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Jill: 63% - Sheena: 37%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br><br>DAMN! Poor Sheena gets put into a 100% unwinnable match in what will likely be TOS's last entrant into a contest :(<br><br>As
for how badly, who knows. But given TOS's history of performing like
crap, this may actually get pretty ugly. The Jill &gt; Peach upset
bandwagon will begin after this match, assuming that match is even an
upset at all.<br><br>Prediction: Jill with 65.34%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>Another
Resident Evil character &#8211; a good one this time! &#8211; graces us with her
presence in another match. Fortunately, this match isn&#8217;t that debatable
unless your name is Lopen. Jill Valentine has had a pretty impressive
track record in the past &#8211; beating Kirby, going even with Ryu Hayabusa,
doing better against Squall than Luigi, etc. Sheena, however, has not
had any previous contest experience and the others from her game do not
invoke much confidence in her. <br><br>This match should really be a
no-brainer to anyone who has been around these contests for a while.
Jill Valentine may not be as strong as she once was, but she&#8217;s clearly
capable of holding her own against pretty strong opponents. There is
one thing to consider in this match &#8211; would Jill beat Kratos Aurion,
the strongest representative from Tales of Symphonia? The answer to
that, of course, is yes. He is far and away the strongest from that
game with Sheena in a nice second. There&#8217;s not much hope for Sheena
here other than to put up a respectable performance and take the loss. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Jill Valentine<br><br><b>Aitch Emm&#8217;s Prediction:</b> Jill Valentine &#8211; 58% ; Sheena Fujibayashi &#8211; 42%<br><br><b>Aitch Emm&#8217;s Vote:</b> Sheena Fujibayashi<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>This
will be a boring match. If Lloyd Irving, the Tales of Symphonia lead,
can't score 55% against Resident Evil's weakass (but badass) Albert
Wesker, there's no way a ToS side character can hope to take down RE's
main gal. Sheena may get a few votes because of her breasts, but it
won't keep this from being ugly in the end. Jill will easily move on to
face Peach in one of the more debated Round 2 matches.<br><br>My prediction: Jill Valentine def. Sheena Fujibayahi (70-30)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/17/2006 7:08:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335216976">message detail</a>
 | #174</td></tr>
<tr class="even"><td>
<b>Lopen&#8217;s Analysis</b><br> <br>Jill Valentine&#8230; in 2002 she was a
mighty force to be reckoned with, taking down Kirby in a shocker and
then Bomberman before losing respectably to Link. In 2003 she lost to
Squall in a not so close match. In 2004, she lost to Ryu Hayabusa who
got beat down by Sora. What's the history lesson for? It's to show that
she's been decaying every year, of course! Jill Valentine has been
dropping dropping dropping, looking crappier with each contest. Will
the trend continue? I think it very well could&#8230; in fact, I'm counting
on it.<br><br>Some might say it would be silly to call Jill to drop
after Resident Evil 4. But the thing is, Jill isn't in Resident Evil 4.
And no, I don't think that RE4 is necessarily going to make people play
and enjoy the others. A couple of reasons: 1. They're on systems from
different generations&#8230; meaning RE1 &amp; RE3 aren't immediately
accessible&#8230; especially for GC RE4 players. 2. RE4 is what I'd call
radically different from the RE 1-3. I personally <i>despise</i> RE2 and RE3, yet I love RE4. And I know I'm not alone on this matter.<br><br>Some
might say it's silly to give Jill a chance to lose this when Ryu
Hayabusa did a good 9-10% better than Lloyd Irving did against Zero
last year. I say that Jill could've dropped <i>again</i> last
year/this year, and also that Ryu Hayabusa 2k5 is much more fearsome a
foe than the feeble Arabusa we saw in 2k4. (match pictures, check em
out here if you don't know what I'm talking about: <a class="linkification-ext" href="http://www.gamefaqscontests.com/gallery/index.php" title="Linkification: http://www.gamefaqscontests.com/gallery/index.php">http://www.gamefaqscontests.com/gallery/index.php</a>)
I really do think Ryu Hayabusa draws a lot from his image&#8230; and heck, I
think a lot of Hayabusa's fans don't know his name. All I have is
anecdotal evidence to support that, but it's enough for me. I honestly
wouldn't be <i>that</i> surprised if Zero got 72% on Arabusa. ("lol X-Stats" for 2004 expects him to get 67.4%, just so you know)<br><br>And
since those "some" brought up Lloyd Irving, like I knew they would, I
want to point out who he beat. Let's give some props to&#8230; <i>Resident Evil's own Albert Wesker</i>!
Yeah, whoo! Hoorah! Now, remember before that guy entered the contest?
Remember when people were saying "Wesker could as strong or stronger
than Jill Valentine!". And it makes some sort of sense, he's in RE4...
Jill's not. People don't believe it for a second now, because
apparently Jill getting only 60% on Luca Blight is utter nonsense.
Well, maybe back when she was really popular, but now? It's been so
long, I'm not so sure. Logic that hasn't been tainted by match results
tells me that Wesker and Jill could be close. And logic that has tells
me Jill could have dropped to around that point.<br><br>All this talk
about Jill&#8230; none for poor Sheena. Well, it's because Jill's where the
real debate in this match comes from. We know Sheena's probably
somewhere between "just under Lloyd Irving" and "a bit below Kratos
Aurion". And we also know that Jill is projected to beat ol Kratos
based on the last time we've seen her. So basically, Jill has to have
dropped in popularity just a bit more for the superior hunny to win
this match&#8230; and I think she has.<br><br><b>Lopen's Prediction:</b> Sheena Fujibayashi with 51.08%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br>Jill Valentine<br><br>Summer 2002 Contest<br>Extrapolated Strength --- 16th Place [27.37%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 28th Place [24.56%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 37th Place [20.64%]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/17/2006 7:09:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335217120">message detail</a>
 | #175</td></tr>
<tr class="even"><td>
Jill Valentine. For a long time considered to be the face of the
Resident Evil series -- and honestly, she still may be, even with Leon
Kennedy's main character appearance in RE4. She might as well have been
THE only main character of the original RE, with her far better
storyline, ability to pick locks and not have to search for irritating
keys, and superior weaponry. She was such a popular character that she
got her own game in Resident Evil 3, where she acted as THE main
character. Alas, aside from the REmake and a few cameos here and there,
Jill hasn't really been seen on the scene lately in the RE scene.<br><br>This
doesn't mean she has been forgotten by her fans, however, and Capcom
knows this. After all, in the upcoming Resident Evil: Umbrella
Chronicles for the Wii, only two characters will be playable in more
than one chapter -- Leon Kennedy, and, yes, Jill Valentine.<br><br>Sheena Fujibayashi<br> <br>lol N/A<br><br>One
of the better females from one of the better RPGs, if I do humbly say
so myself. Sheena is strong-willed yet feminine, fast and fun to play
as, has cool summons, and has perhaps one of the most likable
characters in the game (and having Jennifer Hale as your voice actress
never hurts). It's no wonder she's one of the big fan-favorites from
Tales of Symphonia.<br><br>Her problem in this match? <i>She's from Tales of Symphonia.</i><br><br><i>Notable Releases Since Last Appearance</i><br><br>Jill Valentine: N/A<br>Sheena Fujibayashi: Tales of Symphonia (GCN)<br><br><i>Upcoming Releases</i><br><br>Jill Valentine: Resident Evil: Umbrella Chronicles (WII)<br>Sheena Fujibayashi: N/A<br><br>*yawn*
In all probability, this is a boring match, though I love both of the
characters in it. Unfortunately, Sheena doesn't have a chance. Even if
she's stronger than Lloyd (which I doubt), she won't be as strong as
Kratos, and even the weakest Jill that we've seen yet wouldn't lose to
him. More importantly, common sense takes precedence here -- I don't
think half of GameFAQs has heard of 'Sheena Fujibayashi'. I do think
half have heard of 'Jill Valentine'. So unless Jill is going to get
massively <i>anti-voted</i> by the people that know her, she virtually
*can't* lost this match. And sorry, Sheena, but Lara Croft is on the
other side of the bracket. Jill won't have mercy here.<br><br>The thing
to watch for here is to if Jill will have a chance at Peach next round.
Under 60%, she's basically screwed. Over 70%, and Peach may need to
sweat. Of course, that's all guessing since we've never seen Sheena
before. And at any rate, I think it'll be in the middle.<br><br>Karma
Hunter's Vote: Jill Valentine. Sheena's great and all, but Jill, like
Claire, has carried the torch of strong females long before Ms.
Fujibayashi ever hit the scene.<br><br><b>Karma Hunter's Krazy Prediction: Jill Valentine with 64.23%.</b><br> <br>A little under the official spread, for safety's sake (I've been overestimating percentages too much in this thing).<br><br>Upset Potential: 2%<br><br>If
Sheena is near Kratos' level, Jill has taken *that* much of a dive
since even her 2004 level, and TJF works its magic for the first time
since 2002, we could see Sheena barely, <i>barely</i> squeak by. But it won't happen. =P<br><br>Upset Prediction: Sheena Fujibayashi with 50.5%.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/17/2006 7:10:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335217298">message detail</a>
 | #176</td></tr>
<tr class="even"><td>
<b>Guest&#8217;s Analysis</b> - <i>WiggumFan</i><br><br>Jill Valentine,
destroyer of zombies, badass chick with a gun, sharer of last names
(including Skeeter, Nyehonk Nyehonk!) . Almost like a more popular
version of Boobsra Croft, isn&#8217;t she? Well, what the X-stats will tell
you is that she&#8217;s been going downhill, but you know how a lot of people
feel about X-stats&#8230;. And maybe they&#8217;re right&#8230;. You can&#8217;t use 2002 for
anything sane anymore. 2003 is sketchy, but it&#8217;s okay. And Jill had a
stupid run in &#8217;03. Kirby was not all that strong then, and who the hell
knows about Bomberman (Nowadays, I&#8217;d take Kirby over Jill easily)? Now,
I don&#8217;t know much about Jilly, but I&#8217;d call her the most prominent of
all the Resi good guys. (I&#8217;m not sure if I can call her more
recognizable than Kennedy because of RE4, or Wesker, as far as the
entire Resi staff goes since, well&#8230; Wesker always seems to be hanging
around&#8230;)<br><br>So, in 2003, she took on a force named Squall. She got
40%, which is pretty good, considering Square did great that year
(Squall went on to crush Luigi, only to do decently on Samus, for
recollection&#8217;s sake). It&#8217;s not great&#8230;. But it&#8217;s pretty good. Now,
recall 2004, in which we have arguably the most controversial match of
the contest. Redone because of a voting glitch, the 2nd time Jill took
on her opponent, Ryu Hayabusa, it was a much closer affair, a 27-vote
difference in a match of over 95,000 votes. So, in 2004, we can say,
SFF aside, that Ryu = Jill. 2004 Ryu was so-so, so that&#8217;s just
okay.Jill disappeared for a year, probably because of Resident Evil 4,
and the excitement around Leon. But now, she&#8217;s back.<br><br>As for
Sheena Foojee-boojee, we have a newbie. While she&#8217;ll benefit more from
NintendoFAQs than Jill will, it won&#8217;t be nearly enough to help her.
We&#8217;ve only seen 2 other ToS reps; Lloyd and Kratos Aurion. ToS came out
right around contest time in 2004, I think. They both made it in 2005.
Lloyd, while he was able to defeat a weakening Wesker, was a zero
compared to the hands of&#8230;. Well&#8230;. Kratos, meanwhile, put up some nice
numbers on a Diablo, who performed okay in 2005. But also, Kratos and
Lloyd are clearly the 2 most popular characters from ToS. Sheena has
never made it before, and with good reason, making it only under the
fact that female ranges have been broadened. Jill may or may not have
made it without this handicap, but I doubt it.<br><br>Expect this match
to give you a decent idea of how Jill will do versus Peach. Odd, how
Jill has made this contest 3 times, before Peach did once (maybe Mario
and the rest of the crew who has made it before were taking her noms).
Peach vs. Jill is by no means a pick-in-a-second match&#8230;. It&#8217;s a
pick-in-a-minute match.<br><br>This match though, Jill will win, most
definitely, but she will struggle a bit, with an only moderately
popular RPG series, that someone from Resi should normally at least
double. But, Jill is weakening, which may explain her absence in 05.<br><br>Prediction: Jilly V. with 62%
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/17/2006 7:15:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335218736">message detail</a>
 | #177</td></tr>
<tr class="even"><td>
WIGGLES!!  Err, I mean.....<br><br><i>DpOblivion's Quick Analysis</i><br><br>Well,
we already saw one RE character lose to an RPG character. But that was
an extremely close match, and Kingdom Hearts is much more popular than
Tales of Symphonia. Jill Valentine should easily be able to beat Sheena
Fubi...Fujiyash....Fu...her opponent.<br><br>My Vote: Jill<br>My Bracket: Jill (I think)<br>My Prediction: Jill with 64%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br>**Character Battle V PRINTABLE BRACKET** See quote for link.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=640243" class="name">Big Bob</a> |
Posted 9/17/2006 7:16:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335219047">message detail</a>
 | #178</td></tr>
<tr class="even"><td>
I would gladly sacrifice that one point in my bracket for Lopen to be right.<br>---<br>September 22nd!  Amy Rose &gt; KOS-MOS<br>Currently Playing: Disgaea: Hour of Darkness, God of War, Tales of Symphonia (again)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/17/2006 7:17:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335219217">message detail</a>
 | #179</td></tr>
<tr class="even"><td>
As would I. Sheena rocks.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>The Boss vs. Celes - Bracket: <b>The Boss</b> - Vote: <b>The Boss</b> (4/5)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/17/2006 7:18:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335219331">message detail</a>
 | #180</td></tr>
<tr class="even"><td>
Oh damn, Wiggles showed me up with "Sheena Foojee-boojee."<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br>**Character Battle V PRINTABLE BRACKET** See quote for link.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/17/2006 7:18:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335219402">message detail</a>
 | #181</td></tr>
<tr class="even"><td>
One?  More like <i>three</i>!  Sheena's walking over Peach next round, too!  Jill's the bigger threat, here!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3623587" class="name">Gaddswell</a> |
Posted 9/17/2006 7:22:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335220467">message detail</a>
 | #182</td></tr>
<tr class="even"><td>
Re-Tagging again...<br><br>My vote goes to Sheena as well although my bracket has Jill. Yay, my first non-bracket vote this contest!<br>---<br>By the time we localize the programs, kids don&#8217;t even know they&#8217;re from Japan any more. - 4Kids CEO Al Kahn<br><b>Vote Right! Phoenix Wright!</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=304351" class="name">Mac Arrowny</a> |
Posted 9/17/2006 7:35:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335223742">message detail</a>
 | #183</td></tr>
<tr class="even"><td>
People like Sheena? WTF? She's the worst ninja in any game ever, the
worst character Jennifer Hale's ever played, and a disgrace to the
greatness of ToS.<br>---<br>Pity for the guilty is treason to the innocent.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=640243" class="name">Big Bob</a> |
Posted 9/17/2006 7:38:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335224427">message detail</a>
 | #184</td></tr>
<tr class="even"><td>
Why is she so bad?<br>---<br>September 22nd!  Amy Rose &gt; KOS-MOS<br>Currently Playing: Disgaea: Hour of Darkness, God of War, Tales of Symphonia (again)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/17/2006 8:26:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335236460">message detail</a>
 | #185</td></tr>
<tr class="even"><td>
Hey Moltar...<br><br>Just wanted to say sorry
about the "6-hour" thing. You'd think I'd realize that this is the
wrong month to be complaining about that...&gt;_&gt;<br><br>As for Sheena...well, she <i>does</i> have TJF, right?...<br><br>Okay, she's screwed.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/17/2006 8:38:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335239792">message detail</a>
 | #186</td></tr>
<tr class="even"><td>
Man, boxed in <i>again...</i>Karma's out to get me, and I've got a feeling why. =(<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 9/17/2006 10:05:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335261717">message detail</a>
 | #187</td></tr>
<tr class="even"><td>
Did you get my analysis, Moltar? Just checking.<br>---<br>This was Ed Bellis, servant to the mighty Guru <b>Z1mZum</b>. Congrats, buddy!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/17/2006 10:43:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335269908">message detail</a>
 | #188</td></tr>
<tr class="even"><td>
<i><b>From Janus5000 Posted 9/17/2006 1:50:41 AM #163</b></i><br><i>You missed SMRPG/SFII.</i><br><br>I'm hoping that PW/GF goes the same way.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/18/2006 12:26:57 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335286708">message detail</a>
 | #189</td></tr>
<tr class="even"><td>
YEAH for another awesome-ass crew pick for me.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/18/2006 12:28:03 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335286849">message detail</a>
 | #190</td></tr>
<tr class="even"><td>
You haven't won this one <i>yet!</i> Just wait 'till the kiddies go to school!<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/18/2006 12:28:54 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335286959">message detail</a>
 | #191</td></tr>
<tr class="even"><td>
Not another word about this travesty!<br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/18/2006 12:29:38 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335287040">message detail</a>
 | #192</td></tr>
<tr class="even"><td>
lol lopen more like LOLpen<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=731135" class="name">WiggumFan267</a> |
Posted 9/18/2006 3:04:52 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335299458">message detail</a>
 | #193</td></tr>
<tr class="even"><td>
Sweet =)<br><br><br>(And yeah, Dp, what NOW!?)<br><br><br>---<br>Score: <b>5</b>/6. Pick: <b>Jill</b> &gt; Sheena. Vote: <i>Sheena</i>. <br>Happily married to Alanna82 on VDay 2005
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3763340" class="name">TJam_and_Earl</a> |
Posted 9/18/2006 3:20:03 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335300172">message detail</a>
 | #194</td></tr>
<tr class="even"><td>
*Tagging*<br><br>I'm signing up for the round-two GUYS bracket...preferably one of the later rounds.<br>---<br>You want the truth?  You want the truth!  YOU CAN'T HANDLE THE...here you go.  <a class="linkification-ext" href="http://i5.tinypic.com/11uazx1.jpg" title="Linkification: http://i5.tinypic.com/11uazx1.jpg">http://i5.tinypic.com/11uazx1.jpg</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/18/2006 5:45:12 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335306100">message detail</a>
 | #195</td></tr>
<tr class="even"><td>
9000 vote difference?  Wow.  Those 60%+ picks were worth it for you guys...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/18/2006 8:55:39 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335312234">message detail</a>
 | #196</td></tr>
<tr class="even"><td>
By the way my ACTUAL pick for Peach's match is Peach with 75.01%.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=759072" class="name">cyko</a> |
Posted 9/18/2006 11:37:25 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335324088">message detail</a>
 | #197</td></tr>
<tr class="even"><td>
i sent my analysis for Terra vs. Kerrigan, Moltar. yay, me!<br><br>---<br><i>i have officially been <b>Z1mZum'D </b>in the guru contest.</i><br><b>Vincent Valentine to win the Blast Division!!</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/18/2006 2:31:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335347645">message detail</a>
 | #198</td></tr>
<tr class="even"><td>
C'mon, afterschool vote! Drive this thing below 64.78 and steal that point away from Ulti!<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/18/2006 3:40:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335362153">message detail</a>
 | #199</td></tr>
<tr class="even"><td>
I sent my analysis for Jo/Cortana, Moltar.<br>---<br>CB06 - Score: <b>6/6 </b>Rank: <b>Tied - 1st </b>Yesterday's Pick:<b> The Boss</b> <br>Today's Pick: <b>Jill Valentine</b> Tomorrow's Pick: <b>Princess Peach</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/18/2006 3:47:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335363581">message detail</a>
 | #200</td></tr>
<tr class="even"><td>
I guess the question now is how close KH will get.  He's only .09% away right now.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br>**Character Battle V PRINTABLE BRACKET** See quote for link.
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=2">3</a></li>
<li>4</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=9">10</a></li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage4_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30499515&amp;page=3" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
<div id="copyright">
	<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
	<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
	<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
</div>
<script src="genmessage4_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</div></body></html>