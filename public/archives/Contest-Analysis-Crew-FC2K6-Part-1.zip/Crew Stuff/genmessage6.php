<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	



<title>GameFAQs - GameFAQs Contests Message Board</title><meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage6_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage6_files/nogs.css"></head><body linkifytime="291" linkified="5" linkifying="false"><div id="container">
	<div id="gne_nav">
		<img src="genmessage6_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/events/x06/">X06</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage6_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30499515%26page%3D5"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage6_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage6_files/advertisement.gif" alt="advertisement" height="10" width="120"></div>
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage6_files/f.xhtml" marginwidth="0" marginheight="0" hspace="0" vspace="0" allowtransparency="true" frameborder="0" height="90" scrolling="no" width="728">
&lt;script language=javascript&gt;&lt;!-- randNum = ((new
Date()).getTime() % 2147483648) + Math.random(); document.write( "&lt;a
href='http://a.tribalfusion.com/i.click?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID="
+ randNum + "' target=_blank&gt;" + "&lt;img
src='http://a.tribalfusion.com/i.ad?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID="
+ randNum + "'" + " width=728 height=90 border=0 alt='Click
Here'&gt;&lt;/a&gt;"); // --&gt;&lt;/script&gt; &lt;noscript&gt; &lt;a
href="http://a.tribalfusion.com/i.click?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID=1576037958"
target=_blank&gt; &lt;img
src="http://a.tribalfusion.com/i.ad?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID=1576037958"
width=728 height=90 border=0 alt="Click Here"&gt;&lt;/a&gt;
&lt;/noscript&gt; </iframe><img src="genmessage6_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;page=5">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30499515" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=4">Previous Page</a> |
Page 6 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=6">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=264094" class="name">Heroic Mario</a> |
Posted 9/19/2006 8:11:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335645353">message detail</a>
 | #251</td></tr>
<tr class="even"><td>
I'm <i>so</i> winning today.<br><br>---<br><i>The Legend of Zelda: Twilight Princess</i> -- Day 1 : 1464 Hours Remain.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/19/2006 8:15:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335646347">message detail</a>
 | #252</td></tr>
<tr class="even"><td>
<i>What's you email, I have the analysis done. I'm too lazy to look it up, despite the fact it's proablly on the first page.</i><br><br>I'm too lazy to re-post it now...maybe later.<br>---<br>Moltar Status: <a class="linkification-ext" href="mailto:MasterMoltar@gmail.com" title="Linkification: mailto:MasterMoltar@gmail.com">MasterMoltar@gmail.com</a><br>Peach vs. Daisy- Bracket: <b>Peach</b> - Vote: <b>Peach</b> (6/7)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 9/19/2006 8:17:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335646653">message detail</a>
 | #253</td></tr>
<tr class="even"><td>
Wow Harr.<br>---<br>This was Ed Bellis, servant to the mighty Guru <b>Z1mZum</b>. Congrats, buddy!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/19/2006 9:00:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335657813">message detail</a>
 | #254</td></tr>
<tr class="even"><td>
*Checks bracket*<br><br>Terra vs. Kerrigan...Hopefully that means the end of the...nutty analyses.<br><br>Then again, I can't see Kerrigan winning....<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=863018" class="name">Janus5000</a> |
Posted 9/19/2006 9:10:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335660088">message detail</a>
 | #255</td></tr>
<tr class="even"><td>
That was even better than last match's analyses.<br><br>&lt;3 Lopen, KH and HaRR<br>---<br>"Those who cast the vote decide nothing. Those who count the vote decide everything."<br><a class="linkification-ext" href="http://www.scorehero.com/scores.php?user=2916&amp;diff=4" title="Linkification: http://www.scorehero.com/scores.php?user=2916&amp;diff=4">http://www.scorehero.com/scores.php?user=2916&amp;diff=4</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=395700" class="name">HaRRicH</a> |
Posted 9/19/2006 10:22:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335677100">message detail</a>
 | #256</td></tr>
<tr class="even"><td>
I'm glad people seem to have enjoyed my analysis, heh.  That took a lot more time than I'm proud to admit.....<br>---<br><b>Z1mZum</b> <i>performed a hit and run</i> on me in the Guru Contest.<br>It still hurts to be rear-ended like that.....
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/19/2006 10:29:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335678413">message detail</a>
 | #257</td></tr>
<tr class="even"><td>
Whoo!  I got mentioned in the song!  <br><br><i>Terra vs. Kerrigan...Hopefully that means the end of the...nutty analyses.</i><br><br>What
are you, crazy? These are golden! Okay, I guess it would be a nice
change of pace. But, I'll have you know I did not treat Kerrigan as if
she was a joke! <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/19/2006 11:26:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335689670">message detail</a>
 | #258</td></tr>
<tr class="even"><td>
Jill Valentine vs. Sheena Fujibayashi<br>+6 Mo<br>+5 KH<br>+4 Ulti<br>+3 HM<br>+2 Yo<br>-1 Lo<br><br>Princess Peach vs. Princess Daisy <br>+6 Mo (tie)<br>+6 Yo (tie)<br>+4 HM<br>+3 Lo<br>+2 KH<br>+1 Ulti<br><br><b>The Rankings</b> (Through Peach vs. Daisy)<br>1. UltimaterializerX (34)<br>2. Heroic Mario (30)<br>3. Karma Hunter (27)<br>4. Master Moltar (25)<br>4. Yoblazer (25)<br>6. Lopen (16)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=863018" class="name">Janus5000</a> |
Posted 9/19/2006 11:27:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335689758">message detail</a>
 | #259</td></tr>
<tr class="even"><td>
yoblazer is biased against Guests.<br>---<br>"Those who cast the vote decide nothing. Those who count the vote decide everything."<br><a class="linkification-ext" href="http://www.scorehero.com/scores.php?user=2916&amp;diff=4" title="Linkification: http://www.scorehero.com/scores.php?user=2916&amp;diff=4">http://www.scorehero.com/scores.php?user=2916&amp;diff=4</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/19/2006 11:28:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335690031">message detail</a>
 | #260</td></tr>
<tr class="even"><td>
No one <i>cares</i> about Yo's "poser rankings" anyway!  (I'm not bitter because I'm last!  Really!)<br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=863018" class="name">Janus5000</a> |
Posted 9/19/2006 11:29:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335690241">message detail</a>
 | #261</td></tr>
<tr class="even"><td>
Yeah, you're probably bitter because you're not first.<br>---<br>"Those who cast the vote decide nothing. Those who count the vote decide everything."<br><a class="linkification-ext" href="http://www.scorehero.com/scores.php?user=2916&amp;diff=4" title="Linkification: http://www.scorehero.com/scores.php?user=2916&amp;diff=4">http://www.scorehero.com/scores.php?user=2916&amp;diff=4</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=395700" class="name">HaRRicH</a> |
Posted 9/19/2006 11:43:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335692546">message detail</a>
 | #262</td></tr>
<tr class="even"><td>
That's probably more like it.  Just remember though Lopen, you weren't put on the Crew to be first, so everything'll be okay!<br>---<br><b>Z1mZum</b> <i>performed a hit and run</i> on me in the Guru Contest.<br>It still hurts to be rear-ended like that.....
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/19/2006 11:50:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335693739">message detail</a>
 | #263</td></tr>
<tr class="even"><td>
I'm very well aware I'm here for flavor. In fact, the main reason I
signed up was because I knew my picks would diverge from the crew so
often. But the people love the flavor. <br><br>Yet, I'm still keeping up with the <i>real score</i>!  I get my third point today, I can taste it!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/20/2006 12:39:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335752985">message detail</a>
 | #264</td></tr>
<tr class="even"><td>
Zelda vs. Carmen Sandiego<br>+6 Lo<br>+5 Ulti<br>+4 HM<br>+3 Yo<br>+2 Mo<br>+1 KH<br><br><b>The Rankings</b> (Through Zelda vs. Carmen)<br>1. UltimaterializerX (39)<br>2. Heroic Mario (34)<br>3. Karma Hunter (28)<br>3. Yoblazer (28)<br>5. Master Moltar (27)<br>6. Lopen (22)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/20/2006 12:43:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335753538">message detail</a>
 | #265</td></tr>
<tr class="even"><td>
I thought about including guests in the scoring system, but it doesn't
really make much sense to cram over 32 different people as one entrant
in a system based on consistency. I think including guests naturally
works better for Moltar's system, but I can go back and change things
up if enough people want it that way.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=395700" class="name">HaRRicH</a> |
Posted 9/20/2006 12:48:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335754163">message detail</a>
 | #266</td></tr>
<tr class="even"><td>
I was actually looking to see if you had already explained why you
weren't counting the guests in it. It would, in a
semi-similar-but-not-exactly-duh way, be like the BOP of the rest of
the board's prediction success if you did it like that. If nothing
else, it would just be fun to see and encourage the real Crew to not
**** up so they don't end up below <i>them</i>, heh.<br>---<br><b>Z1mZum</b> <i>performed a hit and run</i> on me in the Guru Contest.<br>It still hurts to be rear-ended like that.....
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/20/2006 3:39:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335784163">message detail</a>
 | #267</td></tr>
<tr class="even"><td>
Princess Peach...........83.1% 90611<br>Princess Daisy............16.9% 18423<br>TOTAL VOTES.......................109034<br><br>92.62% of the brackets predicted this match correctly.<br><br>Even
those Peach was basically facing her clone, she still didn't have the
strength to break 85%. Man, this was one of the most boring matches
I've had to witness.<br><br>Today, Zelda is showing us how it's done. Over 85% on Carmen and climbling.<br><br>Ulti - 3<br>Lopen - 2<br>Moltar - 1<br>Yoblazer - 1<br>Guest (Wigs) - 1<br>HM - 1<br>KH - 0<br><br>Yo and I get points for our picks. HAW HAW KAY AITCH!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Zelda vs. Carmen - Bracket: <b>Zelda</b> - Vote: <b>Zelda</b> (7/8)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 9/20/2006 3:48:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335786133">message detail</a>
 | #268</td></tr>
<tr class="even"><td>
I should have gotten that point <i>!!</i><br>---<br>This was Ed Bellis, servant to the mighty Guru <b>Z1mZum</b>. Congrats, buddy!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=2303557" class="name">FlamboyantSpy</a> |
Posted 9/20/2006 5:10:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335805069">message detail</a>
 | #269</td></tr>
<tr class="even"><td>
lol kh more like qh<br><br>---<br><b>Explicit Content</b> <br>Philadelphia's Path to Cheer Up Emo Kids (1-1) - Next week @ SanFran 49ers.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/20/2006 9:22:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335871003">message detail</a>
 | #270</td></tr>
<tr class="even"><td>
<b>Triforce Division:</b> <i>Round 1 - Match 10</i> &#8211; (4)Terra Branford vs. (5)Sarah Kerrigan <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Terra</b><br>Game/Series Known From: Final Fantasy<br>Extrapolated Rank in 2005 47th (17.10%)<br>Seed in 2005: 8<br>Lost in 2005 to Dante in Round 1<br><br>Terra is back! Apparently Dante didn&#8217;t whip her bad enough.<br><br><b>Kerrigan</b><br>Game/Series Known From: StarCraft<br>Extrapolated Rank in 2005 58th (13.70%)<br>Seed in 2005: 4<br>Lost in 2005 to Vincent in Round 1<br><br>Kerrigan is back as well! How she could show her face again after Vincent spanked her.<br><br>This
is certainly an interesting match. Two competitors that were in the
same four-pack in 2005 are now facing off. Both were semi-popular upset
picks last year, and both were slammed down hard in their matches.
Terra ended up a bit higher that Kerrigan in the end, but how will it
work out in a direct match?<br><br>Well, Terra has the whole Final
Fantasy thing with her, and though she may not be strong, look at whom
she&#8217;s facing. Kerrigan suffers from Gordon Freeman pre-HL2 syndrome of
&#8220;The game is popular, but the character in the game is unknown/not
cared for.&#8221;<br><br>Now, Kerrigan could end up looking strong and was
only underrated last year because of going up against Vincent, and FF
is known to blow out fodder worse than expected, but I doubt it. The
match may end up closer than expected, but I predict Terra will still
win in the end. Stats say Terra with 60%, but what does Moltar say?<br><br><b>Moltar&#8217;s Bracket Says:</b> Terra will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Terra: 56% - Kerrigan: 44%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br><br>It's
actually funny that this match has gotten no hype, given that "Blizzard
rallying in close matches makes a huge difference" is thrown all over
the place during potentially close matches involving the company.<br><br>Or
maybe the morons that put their heads on the guillotines last year
during Vincent/Kerrigan learned their lesson. I generally hate
gloating, but that was one match where I didn't mind it at all.<br><br>Anyway, I doubt this match deviates much from the 2005 stats.<br><br>Prediction: Terra with 60.01%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>The
good thing about this match is that we have an idea of how it will play
out already. It seems the female bracket loves throwing semi-debatable
fodder matches at us. Fortunately, these two are <i>very</i> comparable since they both in the same division last year and did not seem to suffer any type of crazy SFF or other factors.  <br><br>The
stats predict that Terra wins this one without 60% of the vote, which
seems to be right around where I would suspect Terra will end up. It&#8217;s
pretty clear that FF6 characters need someone absurdly weak to pull out
a win &#8211; and Terra&#8217;s in luck today. Kerrigan bombed last year after a
number of people were calling for her to beat Vincent, but there are a
couple of things that can help her out today. <br><br>The first is
that she may get her StarCraft: Brood War box art picture, which is far
more recognizable than the fanart picture CJayC used last year. The
second is rallying by Blizzard freaks to help her pull closer to Terra.
But even with those two factors behind her, I have a hard time seeing
Kerrigan really make this a close match or staying competitive in it.
Terra should run away with this one from the start. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Terra Branford<br><br><b>Aitch Emm&#8217;s Prediction:</b> Terra Branford &#8211; 58% ; Sarah Kerrigan &#8211; 42%<br><br><b>Aitch Emm&#8217;s Vote:</b> Sarah Kerrigan
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/20/2006 9:22:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335871145">message detail</a>
 | #271</td></tr>
<tr class="even"><td>
<b>Yoblazer&#8217;s Analysis</b><br> <br>Wow, I had totally forgotten about
this match. Maybe it was too high in crap content for even me to
stomach. That right there should tell you something, as I like some
pretty crappy stuff (Just look at my sig for proof! Wait... did I
actually write that? No, of course not.). Honestly, how in the hell do
the two most disappointing newcomers from last year's contest face each
other in the first round? What the hell kind of mathematical law allows
<i>that</i>?<br><br>Actually, you can make a pretty decent argument for
either one of these losers. While Terra is noticeably stronger in the
2005 stats, Kerrigan's camp has a better track record. Starcraft,
Diablo, and Warcraft are all known for performing wonderfully in close
matches. Final Fantasy VI characters, on the other hand, are known for
being hold-your-nose-and-hope-the-stink-goes-away bad. If she keeps it
close early and those Blizzard fans somehow get something going, it
could be very interesting (or not, since this match just sucks).
Despite all of that, I'm going with the character who managed to be
less of a bust last year, and that's Terra.<br><br>I don't believe
Kerrigan's picture would affect her performance much, if at all, and I
doubt Blizzard fans would care enough to get seriously involved in...
you know what, just why the heck am I analyzing this? It's like looking
for strengths and weaknesses in two pieces of cow dung. Look, this one
has corn; it's clearly got the after school vote now! BAH.<br><br>My prediction: Zelda def. both of these *****es (97-3)<br>My prediction so Moltar won't yell at me: Terra Branford def. Sarah Kerrigan (56-44)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Sarah Kerrigan has a strength of 14.95.<br><br>Terra has a strength of 18.65.<br><br>Terra wins with 59.92% of the vote!<br><br>A win of 19,507 with 98,324 total votes cast.<br><br>Hey&#8230;
hey&#8230; what? No! NO! I don't agree with you, young man! Okay, well, the
point of bringing this young man in was to illustrate that Terra <i>should</i>
be the favorite in this match if you follow those fancy x-stat things,
and by a good margin. But man, I don't agree with X-Stats to measure
fodder&#8230; really, I don't. I think this match will be the first fodder v
fodder match we've had with readily available X-Stats before the match.<br><br>&#8230; and they're going to fall on their face. Let's look at facts here:<br><br>Last year, no matter <i>what</i>
her "extrapolated strength" was, Terra still only got 27652 votes in
her match. Kerrigan? She got 21058 votes. Now let's take the <i>best case scenario</i>
here, and assume all of the Kerrigan voters hate Terra and vice versa
(and also that all these voters from last year are gonna show up). You
add those vote totals together, what do you get? 48710 votes. Guess how
many votes the typical match gets these days? 100k&#8230; 110k? That means
we've got over 50000 votes that we have no idea where they're going, in
the very best case. Can I really say that Terra getting 6000 more votes
is that significant with all things considered? I don't think so.
Certainly not enough to assume a 60-40 match. The way I see it: They
both got the crap kicked out of them&#8230; so hard, that you can't really
read how they'll do against each other.<br><br>So I just went with what my gut said <i>last year</i>,
before I was tainted with match results and Dante schilling, and went
with thinking Kerrigan is more popular than Terra around here.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/20/2006 9:23:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335871316">message detail</a>
 | #272</td></tr>
<tr class="even"><td>Oh, and also, even assuming my "X-Stats don't work
for fodder" logic doesn't work&#8230; Kerrigan has another factor going in:
She'll probably have a better match picture this time. Everybody whined
about it last year&#8230; and they should have. I surely didn't recognize
her, nobody did. That wasn't the chick on my Starcraft loading screen,
or my Starcraft box, or my Starcraft game! What? Her name? Maybe I
forgot it! This could be <i>huge</i> for Kerrigan, methinks. (Go picture factor!)<br><br><b>Lopen's Prediction:</b> Sarah Kerrigan with 54.91%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br>Terra<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 50th Place [17.10%]<br><br>Terra,
considered by many to be the main character of Final Fantasy 6, is
another glaring example of how characters from that game fail to be
strong on nearly every level. The fact that the game's characters have
three career wins against Pac-Man, Wesker, and <i>Mithos</i> is
absolutely pathetic, and all of those wins come from Kefka. Terra is
far weaker than the clown, and proved it when she stunk up the place in
her match against Dante last year. What a disappointment.<br><br>Sarah Kerrigan<br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 64th Place [13.70%]<br><br>But if Terra was a disappointment, Kerrigan was a complete, total, <i>utter</i>
disgrace. With a higher seed, the luxury of at least going up against
untested competition, and the resounding successes of Blizzard entries
such as Starcraft and Diablo, Kerrigan bombed to all hell against
Vincent, ending up one of the five weakest characters in the entire
contest going by the stats.<br><br>...there's not much more to say about these two.<br><br><i>Notable Releases Since Last Appearance</i><br><br>Terra: N/A<br>Sarah Kerrigan: N/A<br><br><i>Upcoming Releases</i><br><br>Terra: N/A<br>Sarah Kerrigan: N/A<br><br>The
first debatable match in a while, and I'm inclined to treat it like a 1
v. 8 blowout. That's how much I dislike this match. The fact that two
of the biggest bombs we had in the last contest are able to be pitted
against one another in a subsequent contest just makes me want to
boycott this match altogether.<br><br>In all honesty, when you get this
low with fodder, I really don't think you can say anything for certain
with this match. Things like match picture can have far more of a sway
when the voters don't know or care about either contestant, and
Kerrigan getting a Brood War picture might be the only thing she needs
to tip this into a close match. Being Blizzard won't exactly hurt in
terms of rallying potential.<br><br>Then again, I have a hard time
seeing more people care about Kerrigan than people care about Terra. I
really don't think Starcraft is in FF6's league here. Yes, I know what
that implies. I'll just be stubborn and stick to the X-Stats on this
one. If it goes differently, fine, I hate this damn female bracket
anyway.<br><br>Karma Hunter's Vote: BOYCOTT<br><br><b>Karma Hunter's Krazy Prediction: Terra with 58.86%.</b><br> <br>...yeah. I gotta win a point one of these times. =/<br><br>Upset Potential: 30%<br><br>I'm
not even going to grace this with the typical upset alert that
accompanies such a high upset probability. Man, I hate this match.<br><br>Upset Prediction: Kerrigan with 53.8%.<br> <br><br><br><b>Guest&#8217;s Analysis</b> - <i>cyko</i><br><i><b><br>(4) Terra Branford</b> (Final Fantasy3/6) vs. <b> (5) Sarah Kerrigan</b> (Starcraft)</i> -<br><br>at first glance, this seemed like an easy match to predict:<br><br>unadjusted S2K5 x-stats -<br><i><br>47) Terra Branford - 17.10% ..... 18.65%<br>.<br>.<br>.<br>58) Sarah Kerrigan - 13.70% ..... 14.95%</i><br><br>that
means that Terra is expected to win with 59.94% of the vote. therefore,
most people in the BOP and the Guru Contest took Terra without giving
this match a passing thought. in fact, pretty much noone talked about
this match until this past Sunday, when Celes got absolutely clobbered
by The Boss:
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/20/2006 9:24:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335871661">message detail</a>
 | #273</td></tr>
<tr class="even"><td>
<i><br>The Boss    61.08%        66787<br>Celes Chere    38.92%        42565<br>TOTAL VOTES    109352 </i><br><br>everyone to the PANIC ROOM!!!!<br><br>so,
should we be panicing about Terra's chances? well, first of all, we
have no guarantee of where Celes or The Boss lie in relation to Terra.
most people feel that Celes had a slim, if any, chance at being
stronger than Terra. there's really been no evidence (up until Sunday's
match) that Celes was any stronger or weaker than Terra. as for The
Boss, she did have a lot of casual bracket-maker support. and being a
fan-favorite boss from the MGS series, she might be as strong as
Revolver Ocelot, who was pretty even with Kefka (who in turn, seemed
quite a bit stronger than Terra). so it's quite possible that The Boss
would beat Terra as easily as she did Celes.<br><br>the other thing
that makes people a little nervous about picking against Kerrigan is
that she's a Blizzard character and Blizzard keeps finding a way to
throw matches in the face of this board. however, those same people
keep forgetting that Kerrigan is NO Starcraft. the majority of
Starcraft fans do not play Starcraft for the campaign or because of how
much they love Kerrigan. she will not gather the Blizzard support the
same way that Diablo, GTA, and Starcraft did.<br><br>finally, don't
forget about the pictures; because in fodder vs. fodder matches - they
do make a difference. Terra holds a HUGE advantage in this department.
i tried finding decent, recognizable pictures of Kerrigan. i really
did. the only thing i could come up with was the cover of Starcraft:
Brood War. and it seems highly unlikely that Ceej will use that pic
because it just doesn't lend itself to the style of match pics that he
uses. all that leaves is that ugly, unrecognizable pic that she got
against Vincent last year. so, even though some people are still
nervous about the Mass Carriers of Blizzard, they aren't gonna rescue
Kerrigan.<br><i><b><br>cyko's prediction</b> - Terra Branford with 60.43%</i><br><br><br>Summary:
Crew minus Lopen has Terra winning, though I am surprised no one is
going for Terra with more than 60%, yet no less than 56%.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=759072" class="name">cyko</a> |
Posted 9/20/2006 9:25:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335871804">message detail</a>
 | #274</td></tr>
<tr class="even"><td>
<i>Kerrigan has another factor going in: She'll probably have a better
match picture this time. Everybody whined about it last year&#8230; and they
should have. I surely didn't recognize her, nobody did. That wasn't the
chick on my Starcraft loading screen, or my Starcraft box, or my
Starcraft game! What? Her name? Maybe I forgot it! This could be huge
for Kerrigan, methinks. (Go picture factor!)</i><br><br>lol Lopen!<br><br>---<br><i>i have officially been <b>Z1mZum'D </b>in the guru contest.</i><br><b>Vincent Valentine to win the Blast Division!!</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=2303557" class="name">FlamboyantSpy</a> |
Posted 9/20/2006 9:25:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335871868">message detail</a>
 | #275</td></tr>
<tr class="even"><td>
Guest FTW!<br><br>---<br><b>Explicit Content</b> <br>Philadelphia's Path to Cheer Up Emo Kids (1-1) - Next week @ SanFran 49ers.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3052691" class="name">satai_delenn</a> |
Posted 9/20/2006 9:32:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335873693">message detail</a>
 | #276</td></tr>
<tr class="even"><td>
<i>Kerrigan has another factor going in: She'll probably have a better match picture this time.</i><br><br>&gt;_&gt;<br><br>&lt;_&lt;<br><br>Oops.<br>---<br>Beating
FE5 and FE6 hard mode is a true test of manhood in the Japanese
culture. However. This explains why they have a lot of effeminate men.
~Sytha
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/20/2006 9:42:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335875997">message detail</a>
 | #277</td></tr>
<tr class="even"><td>
Satai, Cyko... <i>look again!</i>  My analysis was psychic beyond psychic!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=759072" class="name">cyko</a> |
Posted 9/20/2006 9:45:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335876604">message detail</a>
 | #278</td></tr>
<tr class="even"><td>
where's that picture of Edgeworth looking like he's in pain? because right now, that's me...<br><br>---<br><i>i have officially been <b>Z1mZum'D </b>in the guru contest.</i><br><b>Vincent Valentine to win the Blast Division!!</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/20/2006 9:45:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335876619">message detail</a>
 | #279</td></tr>
<tr class="even"><td>
Too bad it'll still end up wrong in the end!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Zelda vs. Carmen - Bracket: <b>Zelda</b> - Vote: <b>Zelda</b> (7/8)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/20/2006 10:08:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335881666">message detail</a>
 | #280</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Originally, I picked
Kerrigan to win this match, because OH MY GOD Blizzard rallies like
crazy. But then I remembered Kerrigan got killed last year, 79-21%, by
Vincent. Terra isn't as popular as Vincent, but she's still a FF
character, FF6/3 to be exact, so she should still put up similar
numbers.<br><br>But wait.....OH MY GOD CJay changed her pic!  She's supposedly recognizable now!  Whatever.<br><br>My vote: Kerrigan<br>My bracket: Terra<br>My prediction: Terra with 66%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/21/2006 5:41:59 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335926231">message detail</a>
 | #281</td></tr>
<tr class="even"><td>
Looks like the match is playing close to the X-Stats...There goes Lopen's analysis.<br><br>Next match: Amy Rose v. Kos-mos.<br><br>I disliked Amy Rose and went with Kos-Mos.  That was probably a mistake.  Stupid after-school voters!<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=759072" class="name">cyko</a> |
Posted 9/21/2006 7:52:14 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335932918">message detail</a>
 | #282</td></tr>
<tr class="even"><td>
<i>Guest FTW!<br><br><b>TAKE THAT!!</b></i><br><br>barring some insanely backwards afterschool vote, i do believe we will be chalking up another victory for the guest!!<br><br>---<br><i>i have officially been <b>Z1mZum'D </b>in the guru contest.</i><br><b>Vincent Valentine to win the Blast Division!!</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/21/2006 3:24:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335987190">message detail</a>
 | #283</td></tr>
<tr class="even"><td>
<i>barring some insanely backwards afterschool vote, i do believe we will be chalking up another victory for the guest!!</i><br><br>LAWL<br><br>Unless Terra goes berserk, this is between me, HM and KH.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/21/2006 4:39:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336004467">message detail</a>
 | #284</td></tr>
<tr class="even"><td>
Zelda..........................86.08% 102509<br>Carmen Sandiego......13.92% 16578<br>TOTAL VOTES.......................119087<br><br>98.13% of the brackets predicted this match correctly.<br><br>Zelda ends up looking as the most impressive female so far. Over 100K individual votes, 86% on Carmen. ZeldaFAQs indeed.<br><br>Today, Terra is showing no troubles against Kerrigan.<br><br>Lopen - 3<br>Ulti - 3<br>Moltar - 1<br>Yoblazer - 1<br>Guest (Wigs) - 1<br>HM - 1<br>KH - 0<br><br>Lopen may have some very off picks, but sometimes he nails it...or gets the closest.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Terra vs. Kerrigan - Bracket: <b>Terra</b> - Vote: <b>Terra</b> (8/9)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/21/2006 4:41:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336004786">message detail</a>
 | #285</td></tr>
<tr class="even"><td>
I've got this horrible suspicion I'm going to go the entire contest without a point. -_-<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/21/2006 4:42:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336005195">message detail</a>
 | #286</td></tr>
<tr class="even"><td>
If it makes you feel any better KH, if my predictions were being counted, I wouldn't have any points either.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=1966949" class="name">Minipoooot</a> |
Posted 9/21/2006 6:16:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336027468">message detail</a>
 | #287</td></tr>
<tr class="even"><td>
tag<br>---<br>I long to be a hobbit.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=829368" class="name">Tai</a> |
Posted 9/21/2006 7:34:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336046295">message detail</a>
 | #288</td></tr>
<tr class="even"><td>
tag<br>---<br>I lost my sig. Can you find it for me? :(
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/21/2006 8:47:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336065293">message detail</a>
 | #289</td></tr>
<tr class="even"><td>
<b>Triforce Division:</b> <i>Round 1 - Match 11</i> &#8211; (3)KOS-MOS vs. (6)Amy Rose <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>KOS-MOS</b><br>Game/Series Known From: Xenosaga<br>Extrapolated Rank in 2003: 36th  (22.96%)<br>Extrapolated Rank in 2004: 21st (22.60%)<br>Extrapolated Rank in 2005: 41st (19.52%)<br>Seed in 2003: 7<br>Seed in 2004: 8<br>Seed in 2005: 7<br>Lost in 2003 to Samus in Round 2<br>Lost in 2004 to Ryu in Round 1<br>Lost in 2005 to Luigi in Round 1<br><br>The blue-haired beauty is back! Yay!<br><br><b>Amy</b><br>Game/Series Known From: Sonic the Hedgehog<br><br>Blah&#8230;Amy. Only a few in the Sonic-verse surpass you in suckitude.<br><br>KOS-MOS
wins. Amy would have to be stronger than Robotnik, and maybe Tails, to
even stand a chance. I also think KOS-MOS is a underrated in 2005, and
with XS3 behind her, she&#8217;s bound to look better now.<br><br>Now, back
to this cursed female bracket. A lot of good characters were left out
because of it, and instead we got stuff like&#8230;Amy Rose. I&#8217;ll show you
another Sonic character that deserves to be in it instead!<br><br>*This regularly scheduled analysis has been interrupted for this short announcement. Please do not change topics.*<br><br><b>Real Men, Real Snubs</b> - <i>Knuckles</i><br><br>He&#8217;s Red. He&#8217;s mean. He has his priorities straight. He&#8217;s Knuckles, a real man, and a snub in the 2006 Contest.<br><br>*Shot of Knuckles doing an uppercut*<br><br>Ever
since 2002, this Echinda has seen action in GameFAQs Summer Contests.
Back then, he mustered up 80% of the vote against Akira Yuki. <b>THE</b>
Akira Yuki. Knuckles&#8217; path of destruction wasn&#8217;t done there. Next year,
semi-fresh off of Final Fantasy X, Yuna challenged the big Red One. Yet
even she could not stand up to him. The King Dig&#8217;s track of Round 1
victories didn&#8217;t end there though, because in 2004, he took down Kefka
with ease.<br><br>*Shot of Knuckles standing over his fallen opponents triumphantly*<br><br>However,
in 2005, all seemed lost for Knux, the Red Demon of the Wind. His round
1 opponent was Magus, known for his win over Ganondorf and impressive
performance against Link&#8230;and the game he&#8217;s in, Chrono Trigger. No one
had faith in Knuckles, but even though the odds were against him,
Little Mac in Echinda Form overcame the odds and won the match-up.
Brackets had died, but new life was breathed into Knuckles, as that
match would forever be remembered in the hearts of the GameFAQs members.<br><br>*Shot of Knuckles cheered on by the masses*<br><br>But
where is he now? He didn&#8217;t even make the cut for the 5th Character
Battle. Knuckles, a character who&#8217;s only weakness was a snake that
didn&#8217;t reside on an aircraft, missed the mark. His impressive
victories, including the upset of Magus, and even his valiant loss
against Squall Leonhart, couldn&#8217;t get him a spot. Is that what Knuckles
really deserved?<br><br>*Shot of Knuckles frowning in a lone spotlight*<br><br>Knuckles. A real man, and a real snub. (P.S.: Shadow &gt; Knuckles, 45% on Mario! Shadow for 2K7!)<br><br><b>Moltar&#8217;s Bracket Says:</b> KOS-MOS will win.<br><br><b>Moltar&#8217;s Prediction is:</b> KOS-MOS: 65% - Amy: 35%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br><br>I
know KOS-MOS completely ****ing tanked last year (remember how
KOS-MOS/Luigi was an "even" match according to stats?), but has she
fallen so far that she'll fail to beat a character that Sonic fans
despise? Somehow I doubt it, plus for what it's worth XS3 is a recent
release.<br><br>Prediction: KOS-MOS with 57.45%<br> <br> <br><br><b>HM&#8217;s Analysis</b><br> <br>I have no idea <i>why</i>
Amy Rose managed to disgrace us with her rotten appearance in this
contest, but she did. Fortunately, she was put in a match she cannot
possibly win against KOS-MOS. Most of the reason this match isn&#8217;t
debatable is because the Sonic fanbase has shown to hate Amy Rose in
previous polls. They were old, sure, but it&#8217;s not like Amy got any
better over the years. She&#8217;s still the annoying little rodent who&#8217;s
trying to get Sonic&#8217;s attention.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/21/2006 8:48:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336065529">message detail</a>
 | #290</td></tr>
<tr class="even"><td>
I believe the stats put <i>Tails</i> around
KOS-MOS&#8217;s level or around there, which is far above the ceiling for
Amy. Added to that, KOS-MOS has proven to be decently strong in these
contests before, and she has the benefit of a new game coming out right
around the contest &#8211; Xenosaga Episode III. It may not be something big,
but it should at least put some more focus back onto her for now. <br><br>This match should end up being a rather boring affair with KOS-MOS taking it without trouble. <br><br><b>Aitch Emm&#8217;s Bracket:</b> KOS-MOS<br><br><b>Aitch Emm&#8217;s Prediction:</b> KOS-MOS &#8211; 60% ; Amy Rose &#8211; 40%<br><br><b>Aitch Emm&#8217;s Vote:</b> KOS-MOS<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>This
is the second consecutive match where I know nothing and don't give a
hoot about either character; it definitely makes these harder to write.
KOS-MOS isn't weak, and Amy should be a good bit weaker than Tails, so
the hot robo babe on the left will win easily. Rather than spice this
up with something witty or entertaining, I'd rather just go ahead and
slurp the X-Stats. According to the 2004 stats, KOS-MOS is projected to
beat Tails with approximately 52%. Ok. Hmm... no wonder everyone hates
these things. That didn't help at all. Let's try Robotnik. According to
the stats, 2004 KOS-MOS beats the evil doctor with a little over 65%.
Much better, but then you have to remember that Robotnik was probably
SFF'D by Ganondorf. **** these things. Ok, in 2003, KOSSY beats Crash
Bandicoot with 62%. There's no way Amy Rose is stronger than him, so
I'll bump that percentage and call it a day. Actually, I'll bump it a
lot, since I get the feeling that not even Sonic fans care about this
goofball.<br><br>My prediction: KOS-MOS def. Amy Rose (68-32)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Amy Rose is <i>yet another</i>
example of a character from a popular series that I don't feel has any
real fans. They seem to grow on trees here in this contest, it seems.
However, any of the statements I say apply to Peach, Kairi (shaddap!),
Celes, Terra&#8230; and all those others, apply even <i>worse</i> to Amy
Rose. Amy Rose doesn't have the benefit of being in every/almost every
game of the series like Kairi or Peach. Amy Rose doesn't have the
benefit of being "the main character of a game" like Celes or Terra.
She's not in any of the old games, which I think are the main appeal of
Sonic. She's got nothing!<br><br>In that "favorite Sonic character"
poll? She got last? Second to last maybe? She didn't get more than 2 or
3%, I know that. Not to put <i>too much</i> faith in those polls, but
when they back up my thoughts on the matter, well, they can only help.
She did about as bad as Robotnik, she's not as important to the games
as Robotnik, she's not in as many games as Robotnik. She's got no
appeal to the old school Sonic fans. All signs say that she should be
less popular than Robotnik.<br><br>Would KOS-MOS beat Robotnik? Of course she would! Xenosaga isn't <i>hugely</i>
popular here, but don't let KOS-MOS's match with Luigi last year fool
ya. She's not mega jobber fodder&#8230; at least she beat Crash Bandicoot
decisively. And quite simply put&#8230; I think Amy Rose is the very mega
jobber fodder I was talking about! Crash vs. Amy? I'd put my money on
Crash. Really! But, this match isn't too debated, so most of you agree
with me! Good then, I guess I can shut up now!<br><br><b>Lopen's prediction:</b> KOS-MOS with 64.88%
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/21/2006 8:48:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336065654">message detail</a>
 | #291</td></tr>
<tr class="even"><td>
<b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br>KOS-MOS<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 36th Place [22.22%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 31st Place [22.60%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 45th Place [19.52%]<br><br>A
long running, middle-of-the-pack contest entrant, KOS-MOS has the
dubious honor of being one of the hardest people to write for in the
FFP when she loses. &lt;_&lt; She has also had Xenosaga III since her
last appearance, which would seem to spell good things for her -- but
last year, even after Xenosaga II, she appeared to take a bit of a
fall. She's still got the nomination power to get into these things,
though, and still hovers around the fodder line, so that's not all bad.
As for her opponent....<br><br>Amy Rose<br> <br>lol N/A<br><br>KOS-MOS
was just wasted here, as this match is hardly debatable. Amy is one of
*the* most hated and reviled characters in the Sonic series, happens to
only be prominent in the Adventure titles (y'know, the less popular
ones), and would basically lose to anyone with a bit of strength. Poor
Amy. I still like you! ;_;<br><br><i>Notable Releases Since Last Appearance</i><br><br>KOS-MOS: Xenosaga III (PS2)<br>Amy Rose: Shadow the Hedgehog (Multi)<br><br><i>Upcoming Releases</i><br><br>KOS-MOS: N/A<br>Amy Rose: N/A<br><br>While
Amy Rose may come from a more popular series, she is generally hated.
KOS-MOS has taken out more well known characters on the basis of hate
before (Crash). Although to be fair, that was her <i>only</i> win.<br><br>Something
tells me that Amy should win this, and I'd have definitely picked her
if this were their first contests. But KOS-MOS has stood the test of
time too well to fall to someone I know should be fodder. Don't be
surprised if the overall bracket predictions differ <i>drastically</i> from the board though.<br><br>Karma Hunter's Vote: Amy Rose. Don't judge me!<br><br><b>Karma Hunter's Krazy Prediction: KOS-MOS with 61.72%%.</b><br> <br>Xenosaga III will help a bit? C'mon...<br><br>Upset Potential: 14.5%<br><br>It's not <i>impossible</i> for Amy to win this, but like Kerrigan...it's not worth discussing. What a fall it would be for KOS-MOS, though.<br><br>Upset Prediction: Amy Rose with 51.3%.<br> <br><br><br><b>Guest&#8217;s Analysis</b> - <i>Tai</i><br><br><i>KOS-MOS</i><br><br> 2k3: Defeated Crash Bandicoot 61.98%-38.02%<br>     Lost to Samus 30.25%-69.75%<br><br> 2k4: Lost to Ryu 37.87%-62.13%<br><br> 2k5: Lost to Luigi 34%-66%<br><br> <i>Amy Rose</i><br><br> OMG, FIRST TIMER LOLZ!<br><br> Omg, a veteran with somewhat respectable history vs a first-timer that no one cares about. Who could possibly win? :)<br><br>
KOS-MOS is that sexy android from the Xenosaga series. While I don't
know much about that series, I guess KOS-MOS is sorta a cult favorite
in GameFAQs, from a *gasps* cult RPG series! She hasn't done anything
ground-breaking in these tournaments, and hasn't been past the first
round since 2003. Hell, she may have gone down. I mean, come on; 37% on
Ryu one year then 34% on Luigi the next? Well, I guess it doesn't
matter against who she's facing.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/21/2006 8:50:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336066047">message detail</a>
 | #292</td></tr>
<tr class="even"><td>Amy Rose....oh, she's that girl who chases Sonic
around, or tries. Yeah, considering she's from one of the more classic
series in video gaming and can't get into a contest unless CJayC allows
at least 32 girls in, no one should care about her, right? Uh, right;
get with my program, damnit! :( Unless you're Tifa or Vincent, if this
is your first time in your contest, there's probably a reason for that;
YOU SUCK and you will be going home with nothing to talk about with
your family and friends (possibly imaginary) but the bruises on your
ass! I mean, ask Kerrigan! "Starcraft's legion is gonna mass spam the
polls lol!" Uh huh, she did well vs Vincent! :) Oh...and furries do
suck....those fans didn't hear me, did they? &gt;_&gt;<br><br>
Yeah, so with all that said, it's a bit shocking Amy did get in period,
cause what happened to that echinda that exposed Magus has fraud? That
two-tailed fox that follows Sonic around and makes cool airplanes?. Oh,
they got snubbed? :( See? That actually leaves only Sonic and Amy to
represent the Sonic series, right? Isn't that cute? See, that's why we
can take KOS-MOS to win and don't have to worry about the Sonic legion
mass spamming the polls, ok? Or at least, enough to beat KOS-MOS. Maybe
Sonic would beat KOS-MOS, no questions asked. But, his girlfr....I mean
stalker doesn't have that kind of support. Hell, FURRIES don't have
that...ok, forget it.<br><br> KOS-MOS wins with 61.23%. Cry, furry fans. Cry very hard. :-)<br><br> All four of you on GameFAQs. *runs*<br> <br> <br><br>Crew
Consensus: KOS-MOS wins with ease. The range is a bit wide though, as
Amy is a bit of a wildcard. KOS-MOS is also hard to judge, especially
after he performance last year.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/21/2006 8:54:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336067217">message detail</a>
 | #293</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>The lower Sonic characters
already have shown that they struggle. Knuckles and Shadow have been
ok, but Tails and Robotnik have both both performed very poorly. Now,
Amy Rose is below all of these people, and she wasn't in the Genesis
games that gave Sonic its popularity. <br><br>One month ago, KOS-MOS
would have won. And now, Xenosaga 3 has come out. KOS-MOS will kill
Amy. The only thing that matters with this match is what Notre Game's
new sig will be.<br><br>My vote: Amy Rose<br>My bracket: KOS-MOS<br>My prediction: KOS-MOS with 72%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 9/21/2006 8:58:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336068057">message detail</a>
 | #294</td></tr>
<tr class="even"><td>
<i>From Master Moltar Posted 9/21/2006 9:50:25 PM</i><br><i>Unless
you're Tifa or Vincent, if this is your first time in your contest,
there's probably a reason for that; YOU SUCK and you will be going home
with nothing to talk about with your family and friends (possibly
imaginary) but the bruises on your ass!</i><br><br><a class="linkification-ext" href="http://objection.mrdictionary.net/go.php?n=1128238" title="Linkification: http://objection.mrdictionary.net/go.php?n=1128238">http://objection.mrdictionary.net/go.php?n=1128238</a><br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i><br>Michelle.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3708259" class="name">MastaHealer</a> |
Posted 9/21/2006 9:02:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336069202">message detail</a>
 | #295</td></tr>
<tr class="even"><td>
I dont get why people would think XS II would have helped K-MOS. It
alienated a huge amount of the series fans, probably is the reason the
series got cut short, and it was tedious. Game took forever. Battle
would take like 10 min. Bosses were even worse. The campaign sidequest
was boring and horrendously time consuming. And the voice actors..dont
get me started. Albedo saved that trainwreck of a game. Now XSIII thats
a different story. After jumping the massive hurdle of playing XSII,
XSIII Is absolutely amazing. In fact, I say play 1 then skip 2 and just
play 3. You can read the summaries to get filled in. Less boring. <br>---<br>*is <b>wavedash101</b>*<br>Satai gets Biggest Surprise EVER Award! ^_^
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/21/2006 9:07:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336070432">message detail</a>
 | #296</td></tr>
<tr class="even"><td>
Wow, +80,009 respect/love points to Moltar for going off about Knuckles.<br><br>Oh yeah, and......<br><br>&lt;_&lt;<br><br>I nominated Amy Rose.<br><br>Not
that I necessarily wanted to nom her, I just didn't have enough females
to nominate her, so I just threw her in there cause she's from Sonic. I
may have nominated KOS-MOS too though, I'm not sure.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3753237" class="name">t3hl3fty</a> |
Posted 9/21/2006 9:09:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336071000">message detail</a>
 | #297</td></tr>
<tr class="even"><td>
KH seems to have this one in the bag!<br>---<br><b><i>th3l3fty</i></b><br>...since he apparently though we&#8217;d confuse the Son of Sparda with the star of, say, Divine Comedy 64 - Ed Bellis
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/21/2006 9:11:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336071553">message detail</a>
 | #298</td></tr>
<tr class="even"><td>
Suddenly, the Kos-Mos&gt;Amy Rose pick doesn't look so horrible.  Yay!<br><br>Next up:Aeris and Marle!<br><br>In
other words...the return of the Nutty analyses. And why Magus isn't in
to somehow redeem himself. Same with Frog. Besides the fact that they
fell pretty hard. Meh.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=759072" class="name">cyko</a> |
Posted 9/21/2006 9:34:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336077671">message detail</a>
 | #299</td></tr>
<tr class="even"><td>
curse the insanely backwards afterschool vote!!!! i really thought
Terra would keep building her lead all day. it's not very often that
the before school vote is that different from the after school vote.
&gt;_&lt;<br><br>---<br><i>i have officially been <b>Z1mZum'D </b>in the guru contest.</i><br><b>Vincent Valentine to win the Blast Division!!</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/21/2006 9:40:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336079012">message detail</a>
 | #300</td></tr>
<tr class="even"><td>
This isn't <i>quite</i> over yet...I need Terra to stay over 58.43% or else the point goes to that dastardly HM.<br><br>C'mon girl, you can do it!<br>---<br><b>Commit it to memory.</b>
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=4">5</a></li>
<li>6</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=9">10</a></li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage6_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30499515&amp;page=5" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
<div id="copyright">
	<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
	<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
	<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
</div>
<script src="genmessage6_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</div></body></html>