<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	



<title>GameFAQs - GameFAQs Contests Message Board</title><meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage8_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage8_files/nogs.css"></head><body linkifytime="271" linkified="6" linkifying="false"><div id="container">
	<div id="gne_nav">
		<img src="genmessage8_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/events/x06/">X06</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage8_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30499515%26page%3D7"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage8_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage8_files/advertisement.gif" alt="advertisement" height="10" width="120"></div>
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage8_files/a.xhtml" marginwidth="0" marginheight="0" hspace="0" vspace="0" bordercolor="#000000" frameborder="0" height="90" scrolling="no" width="728">
&lt;SCRIPT language='JavaScript1.1'
SRC="http://ad.doubleclick.net/adj/N1260.cnetentertainment/B2029426.10;abr=!ie;sz=728x90;click0=http://adlog.com.com/adlog/e/r=10153&amp;amp;s=687301&amp;amp;t=2006.10.01.20.54.26&amp;amp;o=1:&amp;amp;h=pi&amp;amp;p=&amp;amp;b=4&amp;amp;l=En_US&amp;amp;site=6&amp;amp;pt=&amp;amp;nd=&amp;amp;pid=&amp;amp;cid=&amp;amp;pp=&amp;amp;e=&amp;amp;rqid=01c17-gne-ad345196A4622751BA&amp;amp;event=58/;ord=2006.10.01.20.54.26?"&gt;
&lt;/SCRIPT&gt;
&lt;NOSCRIPT&gt;
&lt;A
href="http://adlog.com.com/adlog/e/r=10153&amp;amp;s=687301&amp;amp;t=2006.10.01.20.54.26&amp;amp;o=1:&amp;amp;h=pi&amp;amp;p=&amp;amp;b=4&amp;amp;l=En_US&amp;amp;site=6&amp;amp;pt=&amp;amp;nd=&amp;amp;pid=&amp;amp;cid=&amp;amp;pp=&amp;amp;e=&amp;amp;rqid=01c17-gne-ad345196A4622751BA&amp;amp;event=58/http://ad.doubleclick.net/jump/N1260.cnetentertainment/B2029426.10;abr=!ie4;abr=!ie5;sz=728x90;ord=2006.10.01.20.54.26?"&gt;
&lt;IMG
SRC="http://ad.doubleclick.net/ad/N1260.cnetentertainment/B2029426.10;abr=!ie4;abr=!ie5;sz=728x90;ord=2006.10.01.20.54.26?"
BORDER=0 WIDTH=728 HEIGHT=90 ALT="Click Here"&gt;&lt;/A&gt;
&lt;/NOSCRIPT&gt;
</iframe><img src="genmessage8_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;page=7">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30499515" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=6">Previous Page</a> |
Page 8 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=8">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/24/2006 12:06:29 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336525785">message detail</a>
 | #351</td></tr>
<tr class="even"><td>
*still has not beaten any of the crew for percentage*<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/24/2006 5:55:50 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336558077">message detail</a>
 | #352</td></tr>
<tr class="even"><td>
Yuna?  Getting <i>77%+!?!?!</i><br><br>And Aeris didn't?...<br><br>Ah, screw it.  My bracket lives anyway...Although I did see this happening...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=2665492" class="name">XIII_rocks</a> |
Posted 9/24/2006 6:08:17 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336558450">message detail</a>
 | #353</td></tr>
<tr class="even"><td>
lol, wasn't actually that far off... &gt;_&gt;;<br><br>&lt;_&lt;<br>---<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738</a> Sign plz<br>Hi-ho, Hi-ho, <b>Z1m Zum, Z1m Zum</b>...our guru champ.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/24/2006 1:29:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336615177">message detail</a>
 | #354</td></tr>
<tr class="even"><td>
darn you lopen<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/24/2006 1:34:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336616276">message detail</a>
 | #355</td></tr>
<tr class="even"><td>
Hit-or-Miss Lopen strikes again!<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/24/2006 1:37:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336616894">message detail</a>
 | #356</td></tr>
<tr class="even"><td>
Uwehehehe!  This is marvelous!  That's my Yunie!  <br><br>(For the record, I'd <i>never</i> even <i>think</i> of taking Yuri over Roll.  No, I'm not saying Yuna boosted, either.)<br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/24/2006 7:40:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336706954">message detail</a>
 | #357</td></tr>
<tr class="even"><td>
Aeris Gainsborough.......69.78% 80305<br>Marle...............................30.22% 34779<br>TOTAL VOTES...........................115084<br><br>87.71% of the brackets predicted this match correctly.<br><br>The Chrono Trigger name gets you far it seems. Marle was able to get over 30% of the vote against Aeris. <br><br>Today, you could say Yuna is <i>rolling</i> over her opponent!<br><br>Ulti - 4<br>Lopen - 3<br>Moltar - 2<br>KH - 1<br>Yoblazer - 1<br>Guest (Wigs) - 1<br>HM - 1<br><br>Ulti gets the point here.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Yuna vs. Roll - Bracket: <b>Yuna</b> - Vote: <b>Yuna</b> (11/12)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/24/2006 8:07:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336713915">message detail</a>
 | #358</td></tr>
<tr class="even"><td>
<b>Triforce Division:</b> <i>Round 1 - Match 14</i> &#8211; (4)Joanna Dark vs. (5)Cortana <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Joanna</b><br>Game/Series Known From: Perfect Dark<br>Extrapolated Rank in 2005 54th (15.12%)<br>Seed in 2005: 8<br>Lost in 2005 to Mario in Round 1<br><br>Jo Jo may not have looked so hot last year, but now it&#8217;s time for redemption!<br><br><b>Cortana</b><br>Game/Series Known From: Halo<br><br>Yep, that blue thing from Halo made it in. Good for it!<br><br>This
is a somewhat debated match. Many just think Joanna will breeze though
and call it a match, but you know me. I need to ramble on about
Cortana&#8217;s &#8220;potential&#8221;. So let me put on my shield&#8230;and begin.<br><br>Cortana,
if you didn&#8217;t know, is from Halo. Yeah, Halo is popular and all, but is
Cortana? Do the Halo fans even care for Cortana? I mean, we know how
weird Halo fans are towards Master Chief, but this is &#8220;That blue thing
that tells you stuff, kind of like Navi except less annoying and more
hot.&#8221; She&#8217;s not even playable or anything.<br><br>On the other hand,
there&#8217;s Joanna Dark, from the popular series Perfect Dark, who is
playable. Heck, she&#8217;s the main character! She also has Perfect Dark
Zero on her side, and while her first match is a bit unfair to base her
strength on, she isn&#8217;t looking to be too strong anyway.<br><br>I have
Joanna winning, and she should barring some weird thing happening and
Cortana actually showing she has some fight in her. Joanna does have
all the right factors on her side, it&#8217;s just a matter of what those
crazy Halo fans will do. <br><br><b>Moltar&#8217;s Bracket Says:</b> Joanna will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Joanna: 61% - Cortana: 39%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br><br>This
is a match between which fanbase cares less. I actually had Cortana in
my bracket for a bit given Master Chief's success, but then I
remembered that no one gives a crap about Cortana. She's Halo's version
of Navi.<br><br>Joanna Dark however actually has fans and has actually
made a contest in the past. Perfect Dark was a million seller that
still has people debating Goldeneye vs Perfect Dark, plus Perfect Dark
Zero being on the 360 is very important. Whatever Xbox/Halo factor that
Cortana might have had going for her will be weakened by Jo being on
Xbox Live.<br><br>The Halo fanbase caring less is odd to consider, but quite possible.<br><br>Prediction: Joanna Dark with 55.55%<br> <br><br><br><b>HM&#8217;s Analysis</b><br><br>This
match is one of the most interesting in the entire female bracket. It
didn&#8217;t get too much debate because we all pretty much figured that
Joanna would be able to take care of this without too much trouble. I,
however, am a bit worried about Cortana surprising and pulling out a
win. Personally, I didn&#8217;t even <i>expect</i> Cortana to make the bracket. And with something like Halo, it&#8217;s always a big question mark heading into the match. <br><br>A
good argument for Joanna is that she not only has had Perfect Dark Zero
within the past year &#8211; it sold around 500,000 copies in America &#8211; she
also was unfortunate enough to be put up against Mario last year.
There&#8217;s definitely some potential SFF to be had in that match, I think.
It probably isn&#8217;t anything <i>drastic</i>, but enough to keep moving Joanna up the ladder. I think that, her game, <i>and</i> the fact that she should have plenty of support from the Nintendo fanbase should be enough to push her over the top here.  <br><br>&#8230;But I still wouldn&#8217;t be surprised if Cortana did something crazy. Halo is always hard to peg. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Joanna Dark<br><br><b>Aitch Emm&#8217;s Prediction:</b> Joanna Dark &#8211; 59% ; Cortana &#8211; 41%<br><br><b>Aitch Emm&#8217;s Vote:</b> Joanna Dark
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/24/2006 8:07:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336714049">message detail</a>
 | #359</td></tr>
<tr class="even"><td>
<b>Yoblazer&#8217;s Analysis</b><br> <br>As bad as this match looks, it's
interesting to note that we may have seen its mirror version only four
days ago. That was a semi-debated match between two foder caliber
females; one was a main lead in her game, the other was a single player
character in a game that draws its popularity from multiplayer action.
Seem familiar? Remember what happened in that match? Yeah... ouch.<br><br>Gentlemen,
if you thought Starcraft fans didn't care about Kerrigan, prepare to be
amazed. Unless she did some astoundingly amazing thing in Halo 2 that
I'm unaware of, Cortana is completely useless to Halo fans. She's your
tutorial voice person. You know who's a good character to compare to
Cortana? Toad. Imagine a Toad who you hardly ever see and never get to
play as. That's Cortana. Seriously... <i>Cortana</i>? What the ****?<br><br>Joanna
Dark may be weak as hell, but she managed over 19% on a super strong
Mario before Perfect Dark Zero. Think Cortana can do that? Not a
chance. She also looks absolutely dreadful in the picture, and that
won't help. Easy match.<br><br>My prediction: Joanna Dark def. Cortana (63-37)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>What have you done for me lately?<br><br>Cliche?
Sure. But that's what I keep thinking when I see this match. Perfect
Dark for the N64 is pretty popular on this site, it doesn't make sense
that the main character would be that weak. But yet, she seemingly is
from her appearance last year. It's clear from the best game ever, and
the top 100 list that the GameFAQs users haven't forgotten about
Perfect Dark, but have they forgotten about Joanna? Basically, I think
they have. I don't think she's the kind of iconic character that can
survive such a grueling test of time, even if her game was fairly
popular. And her poor showing last year helps support that.<br><br>"But
Lopen!", you say, "Perfect Dark Zero was released for the X-Box 360!
She should have a resurgence!". *Ahem* My dear man, did you just say <i>X-Box?</i> The same X-Box lives by Halo and Master Chief? You think they'd <i>dare</i>
turn on Master Chief's talking little in helmet hologram thing for some
new chick on the block? &#8230; what? They know her name! They know what she
looks like! They would not dare turn on her! She is their holographic
goddess! <i>Our</i> holographic goddess!<br><br>Cortana's in our
minds, Joanna's only in the minds of the people who have already been
enslaved by Master Chief and talking hologram helmet thing. It worked
for Kairi, it'll work here! Recency factor&#8230; yeaah, baby! (If only I'd
been <i>consistent</i> with these thoughts!)<br><br><b>Lopen's prediction:</b> Cortana with 52.29%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br> <br>Joanna Dark<br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 59th Place [15.12%]<br> <br>The
lovely Ms. Dark makes her second appearance in the GameFAQs contests
with a much more favorable seed and matchup this time around -- rather
than being stuck as fodder against the future contest champion, she has
a very winnable match this time around, and has Perfect Dark Zero on
her side to boot. Now, let's see if she can spread her wings...<br>  <br><br>Cortana<br> <br>lol N/A<br> <br> <br>Cortana,
for her part, doesn't have much going for her -- she's from Halo, and
that's about it. It's a damn shame, too, because she's the best
character from either of the games, even IF you want to include the
books. Still, it's not like it's impossible for her to pull this out.<br>  <br><i>Notable Releases Since Last Appearance</i><br><br>Joanna Dark: Perfect Dark Zero (XB360)<br>Cortana: Halo (XBox), Halo 2 (XBox)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/24/2006 8:08:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336714196">message detail</a>
 | #360</td></tr>
<tr class="even"><td>
<i>Upcoming Releases</i> <br><br>Joanna Dark: N/A<br>Cortana: Halo 3 (XB360)<br> <br>Y'know,
Cortana scares me in this matchup. After all, in a contest between
Perfect Dark Zero and the Halo games, the XBox fanbase clearly prefers
Halo, even in a matchup between a side character and a main character.
Joanna's going to be working off of Perfect Dark -- which, while
decently popular here, didn't get her very far against Mario. However,
there's always SFF to think of there...<br> <br>Basically, if PDZ
doesn't help much and Joanna didn't suffer much SFF against Mario,
Cortana's got a good shot at this. Especially if the Halo fanbase
really comes out and supports her -- I mean, we see how MC seems to
defy linearity. What if the fanbase is that devoted to all its
characters? Cortana...a contest mainstay?<br> <br>I certainly hope not. Joanna FTFW<br><br>Karma Hunter's Vote: Cortana. If you couldn't tell, bit of a Cortana fanboy here.<br><br><b>Karma Hunter's Krazy Prediction: Joanna Dark with 58.88%.</b><br> <br>Most likely, however, I see this becoming another Terra/Kerrigan. I may actually be going too low!<br><br><b>Upset Potential: 21%<br> <br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br> <br>Yes, we've established that I think Cortana *can* win. No, nothing much else to say here.<br> <br>Upset Prediction: Cortana with 52.1%<br><br><br><br><b>Guest&#8217;s Analysis</b> - <i>DaruniaTheGoron</i> <br> <br>This
match isn't being very heavily debated. I'm betting the only Crew
member that has Cortana is Lopen, and we all know how whacked out some
of his upsets are. I only count 12 Gurus out of 133 that have Cortana.
That's 9%.<br><br>However, this match certainly deserves more debate.
The Master Chief and Halo have solid fanbases that vote for those two
every time. It's why MC can only put up 68% on CATS but still put up
39% on Crono. I believe Cortana will benefit from this fanbase.<br><br>Let's
take a look here... MC, the main character from Halo, can manage 39% on
Crono (who is almost even with Mario). Joanna can manage 19% on Mario
(which could have been an overperformance). Cortana, the biggest
supporting character, only needs half of MC's fanbase to be even with
Joanna.<br><br>Joanna will certainly benefit from PDZ, but I think the
Xbox fans who have PDZ also have Halo, and love Halo much, much more.
And let's not forget only 25% of GF even has a 360. Also, I'm betting a
lot of PD fans are also Halo fans now (as both games are console
shooters). The one thing that Jo needs to push her to victory is
getting people to vote based on the nostalgia factor of PD on N64. I'm
betting 80+% of her strength will come from that. Let's look at
ownership rates:<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2180" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2180">http://www.gamefaqs.com/poll/index.html?poll=2180</a><br><br>Now,
I know that's Goldeneye, but GE and PD have similar fanbases. However,
I'm guessing only 30-40% had PD if only 60% ever owned GE. Let's not
forgot GE beat CV: SOTN with 60% while PD lost to SOTN with 43% in
Sp2k4. I could have used an old poll from 2000 for PD, but obviously
that data would be way off, so this was the best I could do.<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2178" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2178">http://www.gamefaqs.com/poll/index.html?poll=2178</a><br><br>Halo
has a 50% ownership rate. However, the fans are more rabid and the
series is much more recent and recognizable to new gamers, which is why
MC has at least double the strength of Jo.<br><br>It would seem like a big detractor to my argument is this poll:<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2198" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2198">http://www.gamefaqs.com/poll/index.html?poll=2198</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/24/2006 8:09:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336714401">message detail</a>
 | #361</td></tr>
<tr class="even"><td>
However, look at PDZ's competition on there. Pathetic. People were
obviously just voting for the well known option. Besides that, only 5%
even had a 360 at launch, so this 60% can't be taken too seriously. I'm
thinking the PGR3 and Kameo voters in particular count more towards
actual strength, and in an poll among actual 360 buyers, PDZ would not
dominate nearly as much. Plus, this is just a poll among hyped games,
now that PDZ has actually been out for a year and is considered to be
highly inferior to the original, the game does not have nearly as much
strength, while Halo has been going strong in popularity despite having
no releases in 2 years. To put things in perspective, PDZ's message
board has as much activity as PGR3's.<br><br>Another
point I have to address is people saying Cortana has no shot because
people play Halo for multiplayer and don't care about the
campaign/story.<br><br>1. That's not true at all. Upcoming movies and
novels are based around the Halo story. Peter freaking Jackson signed
on to produce the movie. That speaks volumes, the man would not invest
time and money in a movie with a story that is bad and that no one
cares about. The 3 books and Graphic Novel have sold decently (the
first one, a prequel to Halo 1, sold 200 000+ copies, and this was
released before Halo was popular!) and they have <i>nothing</i> to do
with Halo's multiplayer. Also, I know most Halo fans work to beat the
campaign on Legendary in the Halo games. So obviously they care about
the campaign otherwise they wouldn't even bother. There's also tons of
fangroups dedicated to solving the puzzle of the Halo universe. And
let's not forget ILoveBees.<br><br>2. People played PD for single
player? Okay, that was a joke mocking the people who say the same about
Halo. But there's no doubt people played the game mostly for
multiplayer. It's not like either game are touted for their single
player as much as their multiplayer, which is why I believe the
argument is a weak one to use against Cortana because it goes both ways.<br><br>My
final points: I'm betting Cortana gets bracket support of at least 50%
from the casuals, which always happens with Halo related entries. And
one good point for Jo: She'll most certainly get a pic advantage. I'm
just praying whatever pic she gets is a bad one, as it could be the
difference in a match like this. I'm hoping that Ceej knows this and
gives Jo a bad pic to make it a closer match though!<br><br>I wouldn't be surprised to see Joanna leading by 5% throughout the night, but then I expect Cortana will make a <i>Halo</i> style comeback with the morning/afterschool vote.<br><br>Phew, this turned into a much longer analysis than I thought it would! <b>Well, here's my prediction:</b> Cortana with 50.89%<br><br>And a secondary prediction if Jo gets some sexy match pic: Jo with 52.08%. But this one doesn't count officially :P<br> <br><br> <br>Crew
Consensus: Majority says Joanna will win, but Lopen and the Guest say
otherwise. Cortana is going to be quite the wildcard, it seems...
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/24/2006 8:13:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336715411">message detail</a>
 | #362</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>We all have seen this
situation before. A Halo match where by all means, Halo should come out
on top, but it doesn't. I honestly have no reason to support Joanna in
this match, other than......it's Cortana. Who the hell cares about
Cortana, even if you like Halo? Only the most serious of Halo fans, or
people who have played Halo but not Perfect Dark, will be voting for
Cortana. And with Joanna being the higher seed, Cortana can't even
count on bracket voting. <br><br>But then again, Halo is many times
more widely played than Perfect Dark. This is the first match where I
really don't know what to expect.<br><br>My vote: Cortana<br>My bracket: Joanna<br>My prediction: Joanna with 56%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 9/24/2006 8:16:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336716208">message detail</a>
 | #363</td></tr>
<tr class="even"><td>
PDZ doesn't count for very much at all, due to SFF. =/<br><br>Um, could I maybe do a writeup some time in round two? D:<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i><br>Michelle.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=395700" class="name">HaRRicH</a> |
Posted 9/24/2006 8:21:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336717452">message detail</a>
 | #364</td></tr>
<tr class="even"><td>
If Ulti doesn't get his point, I will be shocked.<br>---<br><b>Z1mZum</b> <i>performed a hit and run</i> on me in the Guru Contest.<br>It still hurts to be rear-ended like that.....
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/24/2006 8:52:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336725272">message detail</a>
 | #365</td></tr>
<tr class="even"><td>
Well, that was kind of expected.  Of the crew.<br><br>I
think that it is good to note that Joanna comes from one of the last
Nintendo-Rare games- Perfect Dark. So, she may have the Nintendo base
on this one.<br><br>Yeah, I have little faith in Cortana.  That's why I have Joanna in my bracket.  As do most of the gurus...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/24/2006 9:01:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336727915">message detail</a>
 | #366</td></tr>
<tr class="even"><td>
Yuna finishes with less than 79.31% = KH gets 6 points<br>Yuna finishes with more than 79.31% = XIII (Guest) gets 6 points<br>Yuna
finishes with exactly 79.31% = Tie, meaning both get 6 points if and
only if they purchase The Little Mermaid 2-Disc Platinum Edition DVD on
release day and prove it with pics<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/24/2006 9:19:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336732527">message detail</a>
 | #367</td></tr>
<tr class="even"><td>
One more thing I'd like to point out... aren't we quite overdue for an
upset here &gt;_&gt; Have we ever gone this long without at least one?<br>---<br>CB06 - Score: <b>12/12 </b>Rank: <b>Tied - 1st </b>Yesterday's Pick:<b> Aeris</b> <br>Today's Pick: <b>Yuna</b> Tomorrow's Pick: <b>Cortana</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/24/2006 9:23:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336733403">message detail</a>
 | #368</td></tr>
<tr class="even"><td>
We went 18 straight matches without a percentage upset to start the Summer 2005 Contest, but four of those were in the low 50's.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/24/2006 9:32:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336735862">message detail</a>
 | #369</td></tr>
<tr class="even"><td>
But on the board, wasn't CJ the majority pick over Ness? And Riku/Frog was pretty debated too wasn't it?<br>---<br>CB06 - Score: <b>12/12 </b>Rank: <b>Tied - 1st </b>Yesterday's Pick:<b> Aeris</b> <br>Today's Pick: <b>Yuna</b> Tomorrow's Pick: <b>Cortana</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3623587" class="name">Gaddswell</a> |
Posted 9/24/2006 9:35:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336736574">message detail</a>
 | #370</td></tr>
<tr class="even"><td>
<i><b>Triforce</b> Division: Round 1 - Match 14 &#8211; (4)Joanna Dark vs. (5)Cortana </i><br><br>You forgot to switch it to the <b>Aeon</b> Division for both last match and this match.<br>---<br>By the time we localize the programs, kids don&#8217;t even know they&#8217;re from Japan any more. - 4Kids CEO Al Kahn<br><b>Vote Right! Phoenix Wright!</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/24/2006 9:35:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336736640">message detail</a>
 | #371</td></tr>
<tr class="even"><td>
<i>But on the board, wasn't CJ the majority pick over Ness?</i><br><br>Yup. <br><br><i>And Riku/Frog was pretty debated too wasn't it?</i><br><br>HELLLLLLLLLLLLLLLLLLLLLL NO<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=395700" class="name">HaRRicH</a> |
Posted 9/24/2006 9:39:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336737458">message detail</a>
 | #372</td></tr>
<tr class="even"><td>
The board was practically unanimous for Frog on the board, but Frog only had 53.08% of the total brackets.<br>---<br><b>Z1mZum</b> <i>performed a hit and run</i> on me in the Guru Contest.<br>It still hurts to be rear-ended like that.....
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/24/2006 11:09:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336758251">message detail</a>
 | #373</td></tr>
<tr class="even"><td>
Yuna vs. Roll<br>+7 Lo<br>+6 KH<br>+5 Guest<br>+4 Mo<br>+3 Yo<br>+2 Ulti<br>+1 HM<br><br><b>The Rankings</b> (Through Aeris vs. Marle)<br>1. UltimaterializerX (61)<br>2. Karma Hunter (56)<br>3. Heroic Mario (51)<br>4. Master Moltar (49)<br>5. Yoblazer (47)<br>6. Board 8 (45)<br>7. Lopen (42)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/24/2006 11:10:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336758560">message detail</a>
 | #374</td></tr>
<tr class="even"><td>
Go Joanna!  Still got that perfect going....<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/24/2006 11:20:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336760350">message detail</a>
 | #375</td></tr>
<tr class="even"><td>
Oh well, looks like I phail, and Im out of the Guru contest already.<br>---<br>CB06 - Score: <b>12/12 </b>Rank: <b>Tied - 1st </b>Yesterday's Pick:<b> Aeris</b> <br>Today's Pick: <b>Yuna</b> Tomorrow's Pick: <b>Cortana</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=964696" class="name">TheRye</a> |
Posted 9/25/2006 1:18:09 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336776179">message detail</a>
 | #376</td></tr>
<tr class="even"><td>
Moltar, if you could drop me an IM when you're on AIM so I could send you my Crono/Falcon analysis, that would be great<br>---<br>Congrats to <b> Z1mZum </b> and his Guru ownage<br>&#8220;TheRye is like Jesus, if Jesus ever played video games.&#8221; -Inviso
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3685859" class="name">PartOfYourWorld</a> |
Posted 9/25/2006 1:54:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336834139">message detail</a>
 | #377</td></tr>
<tr class="even"><td>
Man, I am so Moltar's whipping boy. &gt;_&lt;
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=2665492" class="name">XIII_rocks</a> |
Posted 9/25/2006 2:15:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336837646">message detail</a>
 | #378</td></tr>
<tr class="even"><td>
<i><b>HAR~!</b></i>, etc.<br>---<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738</a> Sign plz<br>Hi-ho, Hi-ho, <b>Z1m Zum, Z1m Zum</b>...our guru champ.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/25/2006 3:31:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336853312">message detail</a>
 | #379</td></tr>
<tr class="even"><td>
Yuna..................79.3% 97716<br>Roll....................20.7% 25501<br>TOTAL VOTES...........123217<br><br>90.64% of the brackets predicted this match correctly.<br><br>Looks
like Roll turns out to be a bit weaker than most of us had thought.
Yuna nearly gets 80% on her, and the vote totals look very nice as well.<br><br>Today, Joanna is having an easy time with Cortana<br><br>Lopen - 4<br>Ulti - 4<br>Moltar - 2<br>KH - 1<br>Yoblazer - 1<br>Guest (Wigs) - 1<br>HM - 1<br><br>"Hit-or-Miss" Lopen scores a hit with this match!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Joanna vs. Cortana - Bracket: <b>Joanna</b> - Vote: <b>Joanna</b> (12/13)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/25/2006 3:34:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336854060">message detail</a>
 | #380</td></tr>
<tr class="even"><td>
<i>You forgot to switch it to the Aeon Division for both last match and this match.</i><br><br>Good eye, it's been fixed for the next two division matches.<br><br><i>Moltar, if you could drop me an IM when you're on AIM so I could send you my Crono/Falcon analysis, that would be great</i><br><br>I'll be on for the rest of the day. You can also e-mail it if you want to <a class="linkification-ext" href="mailto:MasterMoltar@gmail.com" title="Linkification: mailto:MasterMoltar@gmail.com">MasterMoltar@gmail.com</a><br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Joanna vs. Cortana - Bracket: <b>Joanna</b> - Vote: <b>Joanna</b> (12/13)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/25/2006 4:36:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336869074">message detail</a>
 | #381</td></tr>
<tr class="even"><td>
Yo, up my Chunners prediction by 3%.  I think I gave Kasumi too much credit.  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/25/2006 8:53:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336941303">message detail</a>
 | #382</td></tr>
<tr class="even"><td>
<b>Aeon Division:</b> <i>Round 1 - Match 15</i> &#8211; (3)Chun-Li vs. (6)Kasumi <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Chun-Li</b><br>Game/Series Known From: Street Fighter<br>Extrapolated Rank in 2005 31st (22.84%)<br>Seed in 2005: 6<br>Lost in 2005 to Bowser in Round 1<br><br>It&#8217;s good to see Thunda Thighs back in the Contest, seeing as how she&#8217;s actually decent in strength.<br><br><b>Kasumi</b><br>Game/Series Known From: Dead or Alive<br>Extrapolated Rank in 2002 25th (22.82%)<br>Seed in 2002: 6<br>Lost in 2002 to Aeris in Round 1<br><br>Back from the grave known as the 2002 Contest, it&#8217;s DoA Girl #32!<br><br>This
match would be interesting&#8230;.if Kasumi was still the fighter she was
back in 2002 that is. I&#8217;m going to go out on a limb and say she isn&#8217;t.
Chun-Li on the other hand, put up a good fight against Bowser just last
year. This should be an easy match for Chun-Li.<br><br>In fact, Kasumi
doesn&#8217;t even deserve to be in this Contest. I can think of so many
others to take her place, preferably a male. A strong male character
who was wrongfully pushed to the side to let characters like Kasumi
into this Contest. I think this calls for another edition of&#8230;<br><br><b>Real Men, Real Snubs</b> - <i>Magus and Frog</i><br><br>Chrono
Trigger. A game about 6 people outside of GameFAQs have played. But who
cares about what goes on outside GameFAQs. Chrono Trigger is big here,
and that&#8217;s all that matters.<br><br>*Shot of Magus and Frog in fighting stances*<br><br>With
the success of Crono in 2002, Magus was nominated by the masses in
2003. He did not disappoint either. After an easy win over Sam &#8220;Solid
Snake Lite&#8221; Fisher, he took on his first worthy advisary, Ganondorf.
The Black Wind howled all day as the two fought hard, but in the end,
it was Magus who came out as the victor. Magus then went on to face
another Zelda character, Link. The Vegeta-faced guy might have lost,
but still put up an impressive 35% on Link. He had become a Contest
elite, even ranking above Sonic in the end.<br><br>*Shot of Magus going toe-to-toe with Link*<br><br>While
2003 was the year of Magus, 2004 was the year of Frog. Magus didn&#8217;t
have much to show besides an easy Round 1 victory and a defeat at the
hands of his Chrono Trigger companion, Crono. Frog was the talk of
2004, predicted to have easy victories over Liquid Snake and Master
Chief, and a loss to Solid Snake. Frog/Liquid kicked off, and became a
classic. The two went back and forth all day, lead swaps and all, but
Frog won in the end in a close one. If you didn&#8217;t think it could get
better after that, you were wrong. Frog/Master Chief became one of the
most remembered matches in Contest history. A battle that ensued all
day, and even until the final seconds of the poll. Ye Olde Amphibian
won the match by only 7 votes in the closest match in Contest history.
The Green Swordsman then received nearly 49% of the vote on Solid
Snake, giving him the praise for that year.<br><br>*Shot of Frog doing some sword action*<br><br>But
where are they now? Not in this Contest that&#8217;s for sure. Was it Magus&#8217;
choke against Knuckles that kept him from returning? Was it Frog&#8217;s
bombing against Riku and Samus that left him in the dust? Can we blame
it, just like all the problems in the world, on the female bracket?
Whoever to blame, it&#8217;s a shame that such fine competitors, marred by
one horrible year for any CT character not in the title, are forced to
sit on the sidelines this Contest<br><br>*Shot of Magus and Frog frowning in a lone spotlight*<br><br>Magus. Frog. Real men, and real snubs<br><br><b>Moltar&#8217;s Bracket Says:</b> Chun-Li will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Chun-Li: 64% - Kasumi: 36%.<br>  <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>This
match REEKS of fighting game chick SFF. I also don't give a crap about
DoA, so I'll take the lazy way out like I always do! &lt;3
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/25/2006 8:54:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336941511">message detail</a>
 | #383</td></tr>
<tr class="even"><td>It's not like Kasumi ever had a chance anyway,
even WITH DoA4. However, I wouldn't be surprised if Kasumi does better
than everyone thinks. and by this I mean break 40%.<br><br>Prediction: Chun-Li with 59.99%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>Hey, <i>two</i>
females facing each other that we have actual data on! These two female
fighting characters have both made their presence known in these
contests before &#8211; Kasumi in 2002 and Chun-Li in 2005. Both of them were
pretty impressive in their respective years, but there is a definite
nod to Chun-Li in this match. <br><br>Thunder Thighs comes from the
most popular fighting game series, Street Fighter, and Kasumi comes
from Dead or Alive. It&#8217;s really a no-brainer there who is already at an
advantage &#8211; but there&#8217;s more! In 2002, Kasumi clocked in at 22.85% on
Base Link while Chun-Li came in at 24.92% on Base Link. If I had to
guess, I would wager that Kasumi has definitely dropped off the map
over the past couple of years, so this should match should really never
come into question. <br><br>Chunners should be able to take this one with ease. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Chun-Li<br><br><b>Aitch Emm&#8217;s Prediction:</b> Chun-Li &#8211; 60% ; Kasumi &#8211; 40%<br><br><b>Aitch Emm&#8217;s Vote:</b> Chun-Li<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>My
god, Chun-Li looks so awesome in the pic. Kasumi doesn't look bad, but
the picture doesn't really accentuate her enormous TJF, so there goes
about 800% of her vote. Seriously, though, folks... *realizes that no
one is laughing*<br><br>Bunch of bastards.<br><br>Anyway, this match is
another one that belongs in the "tough to gauge because we have very
little information" category. Both of these lovely ladies have only
been in one match (both losses), but the matches are three years apart.
It's very shakey information, but NGamer's X-Stats calculator says that
Chun wins this with a little over 54% of the vote. I think Kasumi migh
have slightly been overrated in 2002 (boobs = votes). Also, there might
be some slight female fighting character SFF to deal with here, so I
think Chun-Li will overshoot that percentage. I'm guessing this one
ends up in the standard 60/40 Snake/Knuckles range.<br><br>My prediction: Chun-Li def. Kasumi (59-41)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>So
I'm looking at the 2002 X-Stats, and they seem to imply that Kasumi
might not be fodder. Well, we know how jacked up those things are (I'm
looking at you, Claire! Way to flop into foddersville!). Thanks, but no
thanks. As far as the fighting game pecking order goes, if you're not
from Street Fighter and you're not from Mortal Kombat, you might as
well just go home (or Guilty Gear&#8230; Ky Kiske = 39% on Base Link&#8230; what?).
Chun Li is from Street Fighter, Kasumi isn't, that's all there is to
it. Dead or Alive 4 isn't going to help, Dead or Alive Beach Volleyball
isn't gonna help.<br><br>I'm about getting bored with the female half&#8230; sorry&#8230; you've gotta forgive my lack of enthusiasm&#8230;please?<br><br><b>Lopen's Prediction:</b> Chun Li with 68.99%<br> <br> <br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br> <br>Chun-Li<br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 34th Place [22.84%]<br> <br>A
Street Fighter character that happens to be a midcarder? I'm shocked,
truly shocked! Though thanks to the female bracket, she escapes the
fate of Ken and has the potential now of M. Bison in the Villains
Contest. Come to think of it, if she can upset Yuna, Chun-Li will have
made it farther in a bracket than any SF character. Including Ryu.<br> <br>...<i>damn.</i><br> <br>Kasumi<br> <br>Summer 2002 Contest<br>Extrapolated Strength --- 25th Place [22.82%]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/25/2006 8:55:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336941838">message detail</a>
 | #384</td></tr>
<tr class="even"><td>
Also benefitting from the female bracket is Kasumi, although instead of
enjoying the rewards of winnable matches she's just plain happy to be
in the field again. Though her showing in 2002 is now in retrospect
more or less respectable, back then she was just another 'one-and-done'
character that 2002's field would be infamous for.<br> <br>Unlike
the other long-running 2k2 absentee Claire Redfield, Kasumi is up
against tested competition in her first match. Her big goal here isn't
winning ('cause that ain't happening), but to give the 2k2 stats a
smidge of credibility. Getting 45% or so would do wonders for that,
even though people might blame the Snake/Bowser nonsense on such an
'underperformance'...<br> <br><i>Notable Releases Since Last Appearance</i><br><br>Chun-Li: N/A<br>Kasumi: Dead or Alive XTreme Beach Volleyball (XBox), Dead or Alive 4 (X360)<br><br><i>Upcoming Releases</i> <br><br>Chun-Li: N/A<br>Kasumi: N/A<br> <br>However, Kasumi will be doing good to break 40% here. <i>Really</i>
good. Claire's already shown her 2k2 value to be all but false against
Kairi, and Kasumi's primed to follow suit. Then there's the fact that
SF &gt; DoA, the fact that Kasumi's not the most popular character from
her own game ('sup, Hayabusa), and that I'd probably take Chun-Li over
Ryu H. myself...Kasumi just doesn't have much luck here. Cortana,
Kerrigan, Jade, there'd be a ton of matches she could have won here.
Welcome back, I suppose -- and don't let the door hit you on the way
out. &lt;_&lt;<br><br>Karma Hunter's Vote: Thunder Thighs. Why? Well, the fact that I just called her "Thunder Thighs", for one. =/<br><br><b>Karma Hunter's Krazy Prediction: Chun-Li with 63.74%.</b><br> <br>This is a percent higher than Aeris got in 2002. Even with "lol 2k2 stats", I don't feel comfortable going any higher. <br><br>Upset Potential: 4.2%<br> <br>Y'know, just looking at the stats and taking Kasumi's new games into account, this ain't a bad upset. Still not happening.<br> <br>Upset Prediction: Kasumi with 51.51%<br> <br><br><br><b>Guest&#8217;s Analysis</b> - <i>MrPatch</i><br><br>Projected Winner: Chun Li<br><br>This
match, to me anyway, is pretty clear. First we have Chun Li of Street
Fighter fame. To put it simply, she is a Chinese girl with thighs that
can probably crush boulders. Oh yeah, she&#8217;s supposed to kick your ass
too. Her opponent is Kasumi, a ninja who along with most of the female
cast of the Dead or Alive series, has breasts the size of Barry Bond&#8217;s
fat head. She is also made to kick ass. However, no matter the amount
of kickassery both of these ladies have, they have a pretty bad shot at
getting past what seems to be a mini-powerhouse in Yuna (blame the
Final Fantasy hax) being in their division.<br><br>Now let&#8217;s get into
the match itself. This isn&#8217;t going to be a blow out of any sort, but it
will be a decent win. Street Fighter itself gives Chun-Li the advantage
as it probably is the more popular game on the site. I don&#8217;t even
remember DoA characters even doing remotely well in a contest so I
think this match should be an easy decision for you bracket voters.
Chun Li probably takes this in about a 53-47 split. I just don&#8217;t see
Kasumi doing anything going up against Chun Li. Maybe if TJF actually
kicked in for once.<br> <br> <br> <br>Crew Consensus: We all are going with Chun-Li here. Anywhere in the low-to-mid 60's seems to be the average.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/25/2006 9:02:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336943850">message detail</a>
 | #385</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>So we have 2 fighting game
characters. One from Street Fighter, who just happened to be basically
the first major female playable character in any game (thanks,
wikipedia!), and one from Dead or Alive. Clearly Street Fighter is much
more popular than Dead or Alive, and clearly Chun-Li is winning this
match.<br><br>My vote: Chun-Li<br>My bracket: Chun-Li<br>My prediction: Chun-Li with 74%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/25/2006 9:08:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336945064">message detail</a>
 | #386</td></tr>
<tr class="even"><td>
I think we can all agree the Female bracket sucks.  Talk about a good idea gone bad.  Oye...<br><br>Though
I think the sucky performances of 2005 did in the CT characters, not
merely the bracket. Even Crono did badly that time...But he's Noble 9,
so he has to come. But still...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3050550" class="name">TheKoolAidShoto</a> |
Posted 9/25/2006 9:10:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336945826">message detail</a>
 | #387</td></tr>
<tr class="even"><td>
Yeah, this female bracket sucks *****. I think this is the worse
bracket yet. A few fun matches here and there( Kratos/Ryu,
Phoenix/Gordon, and anything that involves Dante), but for the most
part I'm kinda just..."eh".<br><br>When do the 2nd round sign-ups start again?<br>---<br>Edited TNT Kill Bill line: "Buck: My name's Buck, and I'm here to (completely different voice) screw!"
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/25/2006 9:15:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336947123">message detail</a>
 | #388</td></tr>
<tr class="even"><td>
Crono did bad? He did well on Zidane, as expected on Vercetti,
underperformed against Master Chief (but it's MC), unsure with Vincent,
and did ok against Mega Man.<br><br>It wasn't that Crono got weaker, just his competition (namely Mega Man, Sonic and Mario) got stronger.<br><br>Round
2 sign-ups will go up sometime Wednesday I'm guessing. A seperate topic
will be made then (and it will probably be in the evening for those
looking to camp out or something and wait for the topic to go up).<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Joanna vs. Cortana - Bracket: <b>Joanna</b> - Vote: <b>Joanna</b> (12/13)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3602792" class="name">Garsha_III</a> |
Posted 9/25/2006 9:19:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336948248">message detail</a>
 | #389</td></tr>
<tr class="even"><td>
Weren't Magus and Frog both proven to be frauds?<br>---<br>George Harrison &gt; Flonne
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=46088" class="name">therealmnm</a> |
Posted 9/25/2006 9:25:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336949642">message detail</a>
 | #390</td></tr>
<tr class="even"><td>
<i>It wasn't that Crono got weaker, just his competition (namely Mega Man, Sonic and Mario) got stronger.</i><br><br>Eh?
Crono got exactly what he was supposed to on Mega Man. Mega Man looked
slightly stronger in 2k3. Crono looked slightly stronger in 2k4. And
Crono edged out Mega Man in 2k5. There was nothing out of the ordinary
about Crono and Mega Man in 2k5. It was Sonic and Mario that seemed
particularly beefed.<br>---<br><b>Vote for Soma Cruz</b><br>Currently playing: Grand Theft Auto 3, Castlevania:Curse of Darkness, Mega Man ZX
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/25/2006 9:28:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336950580">message detail</a>
 | #391</td></tr>
<tr class="even"><td>
Mega Man actually looks a tad <i>stronger</i> in 2k5 than he did in 2k3, actually...<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/25/2006 9:29:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336950776">message detail</a>
 | #392</td></tr>
<tr class="even"><td>
Oh, wait, you mean relative to each other. Never mind.<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/25/2006 10:32:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336965807">message detail</a>
 | #393</td></tr>
<tr class="even"><td>
Ahh, that's right. For some reason, I thought Crono should have beaten
Mega Man by more, but it was probably Sonic throwing me off. Damn that
hedgehog!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Joanna vs. Cortana - Bracket: <b>Joanna</b> - Vote: <b>Joanna</b> (12/13)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=46088" class="name">therealmnm</a> |
Posted 9/25/2006 10:35:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336966612">message detail</a>
 | #394</td></tr>
<tr class="even"><td>
Yeah, Sonic really surprised me last year.  I thought he had <i>no</i>
chance against Mega Man and I'm a huge fan of his. I thought Leonhart
(or whoever it was in the stats topic) was crazy for actually taking
Sonic. But seeing Sonic almost take it was delightful to me, even
though I would have been on the losing side. I <i>almost</i> took
Sonic to take the main bracket this year, had his games been a bit
closer for release... But something still doesn't seem right. I played
it safe, but I'm pulling for him to take it.<br>---<br><b>Vote for Soma Cruz</b><br>Currently playing: Grand Theft Auto 3, Castlevania:Curse of Darkness, Mega Man ZX
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/25/2006 10:36:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336966798">message detail</a>
 | #395</td></tr>
<tr class="even"><td>
Looks like Moltar's barely got this barring a miracle percentage drop.<br>---<br>CB06 - Score: <b>13/13 </b>Rank: <b>Tied - 1st </b>Yesterday's Pick:<b> Cortana</b> <br>Today's Pick: <b>Chun Li</b> Tomorrow's Pick: <b>Lara</b> Losses: <b>Cortana</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 9/25/2006 10:39:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336967306">message detail</a>
 | #396</td></tr>
<tr class="even"><td>
Go Lopen!<br><br>Kasumi being fodder of the lowest grade FTW!<br><br><br><b>TuRtLe</b><br>~~~<br>I used my brain and statistics to make my bracket. Karma Hunter used MGS fanboyism. KH won. <b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/25/2006 10:53:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336970314">message detail</a>
 | #397</td></tr>
<tr class="even"><td>
Joanna Dark vs. Cortana<br>+7 Mo<br>+6 HM<br>+5 KH<br>+4 Yo<br>+3 Ulti<br>-1 Guest<br>-2 Lo<br><br><b>The Rankings</b> (Through Joanna vs. Cortana)<br>1. UltimaterializerX (64)<br>2. Karma Hunter (60)<br>3. Heroic Mario (57)<br>4. Master Moltar (56)<br>5. Yoblazer (51)<br>6. Board 8 (44)<br>7. Lopen (40)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/25/2006 11:09:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336973648">message detail</a>
 | #398</td></tr>
<tr class="even"><td>
I call this one a <i>hit</i>!<br><br>FODDER OF THE LOWEST GRADE!  OH YES!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/25/2006 11:35:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336978340">message detail</a>
 | #399</td></tr>
<tr class="even"><td>
Lopen's number 1 after today, and KH is almost number 1 in consistency.<br>---<br>CB06 - Score: <b>13/14 </b>Rank: <b>Tied - 3075th </b>Yesterday's Pick:<b> Cortana</b> <br>Today's Pick: <b>Chun Li</b> Tomorrow's Pick: <b>Lara Croft</b> Losses: <b>Cortana</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/25/2006 11:37:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336978610">message detail</a>
 | #400</td></tr>
<tr class="even"><td>
Lopen is <i>KILLING</i> the crew!<br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=6">7</a></li>
<li>8</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=9">10</a></li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage8_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30499515&amp;page=7" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
<div id="copyright">
	<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
	<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
	<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
</div>
<script src="genmessage8_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</div></body></html>