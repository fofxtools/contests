<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	



<title>GameFAQs - GameFAQs Contests Message Board</title><meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage2_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage2_files/nogs.css"></head><body linkifytime="241" linkified="5" linkifying="false"><div id="container">
	<div id="gne_nav">
		<img src="genmessage2_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/events/x06/">X06</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage2_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30499515%26page%3D1"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage2_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage2_files/advertisement.gif" alt="advertisement" height="10" width="120"></div>
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage2_files/f.xhtml" marginwidth="0" marginheight="0" hspace="0" vspace="0" allowtransparency="true" frameborder="0" height="90" scrolling="no" width="728">
&lt;script language=javascript&gt;&lt;!-- randNum = ((new
Date()).getTime() % 2147483648) + Math.random(); document.write( "&lt;a
href='http://a.tribalfusion.com/i.click?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID="
+ randNum + "' target=_blank&gt;" + "&lt;img
src='http://a.tribalfusion.com/i.ad?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID="
+ randNum + "'" + " width=728 height=90 border=0 alt='Click
Here'&gt;&lt;/a&gt;"); // --&gt;&lt;/script&gt; &lt;noscript&gt; &lt;a
href="http://a.tribalfusion.com/i.click?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID=1576037958"
target=_blank&gt; &lt;img
src="http://a.tribalfusion.com/i.ad?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID=1576037958"
width=728 height=90 border=0 alt="Click Here"&gt;&lt;/a&gt;
&lt;/noscript&gt; </iframe><img src="genmessage2_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;page=1">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30499515" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">First Page</a> |
Page 2 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=2">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/12/2006 11:12:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334209866">message detail</a>
 | #051</td></tr>
<tr class="even"><td>
I'm betting it goes down to under 75%. Don't call this too quickly HM<i>!!</i><br>---<br><a class="linkification-ext" href="http://img180.imageshack.us/img180/5394/nidoranfcx9.png" title="Linkification: http://img180.imageshack.us/img180/5394/nidoranfcx9.png">http://img180.imageshack.us/img180/5394/nidoranfcx9.png</a><br><b>Vote Nidoran F!</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=264094" class="name">Heroic Mario</a> |
Posted 9/12/2006 11:12:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334209961">message detail</a>
 | #052</td></tr>
<tr class="even"><td>
It may go under 75% <i>tonight</i>, but thinking Jade continues bringing it down throughout the day is silly.<br><br>---<br><i>...a lone figure shining in the toxic shadows. She comes dressed for war, and her wrath is terrible.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/12/2006 11:14:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334210163">message detail</a>
 | #053</td></tr>
<tr class="even"><td>
We'll see.<br>---<br><a class="linkification-ext" href="http://img180.imageshack.us/img180/5394/nidoranfcx9.png" title="Linkification: http://img180.imageshack.us/img180/5394/nidoranfcx9.png">http://img180.imageshack.us/img180/5394/nidoranfcx9.png</a><br><b>Vote Nidoran F!</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 9/12/2006 11:14:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334210177">message detail</a>
 | #054</td></tr>
<tr class="even"><td>
tag<br><br>---<br><b>Z1mZum</b> won the Guru
Contest. I picked Pokemon over Metroid, GTA over Warcraft, Halo over
CV, Street Fighter over RE, and FF over Zelda.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=1254692" class="name">Mr Lasastryke</a> |
Posted 9/12/2006 11:51:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334215849">message detail</a>
 | #055</td></tr>
<tr class="even"><td>
Tag<br>---<br><i>It belongs to the imperfection of everything human that man can only attain his desire by passing through its opposite.</i> ~ Kierkegaard
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/12/2006 11:54:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334216285">message detail</a>
 | #056</td></tr>
<tr class="even"><td>
My 78% wins, too bad it doesn't count.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br>**Character Battle V PRINTABLE BRACKET** See quote for link.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/13/2006 3:13:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334296938">message detail</a>
 | #057</td></tr>
<tr class="even"><td>
I think HM's got this one.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/13/2006 3:27:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334299882">message detail</a>
 | #058</td></tr>
<tr class="even"><td>
Samus Aran...............81.85%95533<br>Nidoran F .................18.15% 21180<br>TOTAL VOTES....................116713<br><br>97.13% of the brackets predicted this match correctly.<br><br>First
match of the female bracket, goody. Nidoran F puts up more than a fight
than most of us thought. Still, I wouldn't slam Samus for it.<br><br>Today, Ada is destroying Jade. Seriously, this is making Jade look <i>very</i> bad. I didn't think fodder could blow out fodder this badly!<br><br>Ulti - 1<br>Moltar - 0<br>HM - 0<br>Yoblazer - 0<br>Loepn - 0<br>KH - 0<br>Guest - 0<br><br>Ulti nabs the first point of the Contest.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Ada Wong vs. Jade - Bracket: <b>Ada</b> - Vote: <b>Ada</b> (1/1)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/13/2006 3:39:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334302195">message detail</a>
 | #059</td></tr>
<tr class="even"><td>
Ada's percentage has been on the rise for the past hour, so I think it's safe to post the results.<br><br>Ada Wong vs. Jade<br>+6 HM<br>+5 Ulti<br>+4 Yo<br>+3 KH<br>+2 Mo<br>+1 Lo<br><br><b>The Rankings</b> (Through Ada Wong vs. Jade)<br>1. UltimaterializerX (11)<br>2. Karma Hunter (8)<br>2. Yoblazer (8)<br>4. Heroic Mario (7)<br>5. Lopen (4)<br>5. Master Moltar (4)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=2665492" class="name">XIII_rocks</a> |
Posted 9/13/2006 3:56:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334306109">message detail</a>
 | #060</td></tr>
<tr class="even"><td>
Moltar, did you get my analysis?<br>---<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738</a> Sign plz<br>Hi-ho, Hi-ho, <b>Z1m Zum, Z1m Zum</b>...our guru champ.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=1966949" class="name">Minipoooot</a> |
Posted 9/13/2006 3:56:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334306185">message detail</a>
 | #061</td></tr>
<tr class="even"><td>
tag<br>---<br>I long to be a hobbit.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/13/2006 4:11:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334309622">message detail</a>
 | #062</td></tr>
<tr class="even"><td>
<i> From: Heroic Mario </i><br><i>It may go under 75% <i>tonight</i>, but thinking Jade continues bringing it down throughout the day is silly.</i><br><br>Yeah, that was silly of me to think Jade would go up eh?<br>---<br>CB06 - Score: <b>1/1 </b>Rank: <b>Tied - 1st </b>Yesterday's Pick:<b> Samus</b> <br>Today's Pick: <b>Ada Wong</b> Tomorrow's Pick: <b>Rikku</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/13/2006 4:15:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334310347">message detail</a>
 | #063</td></tr>
<tr class="even"><td>
<i>Moltar, did you get my analysis?</i><br><br>Yuna/Roll? Yes, I did.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Ada Wong vs. Jade - Bracket: <b>Ada</b> - Vote: <b>Ada</b> (1/1)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=685460" class="name">Turbo Kirby</a> |
Posted 9/13/2006 6:25:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334342556">message detail</a>
 | #064</td></tr>
<tr class="even"><td>
*tag*<br>---<br><i>A gentle answer turns away wrath, but a harsh word stirs up anger.</i> -Proverbs 15:1
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=264094" class="name">Heroic Mario</a> |
Posted 9/13/2006 6:26:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334342751">message detail</a>
 | #065</td></tr>
<tr class="even"><td>
<i>I'm betting it goes down to under 75%. </i><br><br>That was silly, yes.<br><br>---<br><i>...a lone figure shining in the toxic shadows. She comes dressed for war, and her wrath is terrible.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/13/2006 6:28:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334343340">message detail</a>
 | #066</td></tr>
<tr class="even"><td>
Thanks for doing those rankings again, yo. Moltar's system is cool and
all, but I like systems that factor in overall performance as well as
who simply makes the best picks.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/13/2006 6:31:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334343872">message detail</a>
 | #067</td></tr>
<tr class="even"><td>
<i> From: Heroic Mario </i><br><i><i>I'm betting it goes down to under 75%. </i><br><br>That was silly, yes.</i><br><br>You're clearly twisting what you said.<br>---<br>CB06 - Score: <b>1/1 </b>Rank: <b>Tied - 1st </b>Yesterday's Pick:<b> Samus</b> <br>Today's Pick: <b>Ada Wong</b> Tomorrow's Pick: <b>Rikku</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/13/2006 6:35:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334345043">message detail</a>
 | #068</td></tr>
<tr class="even"><td>
<i>Thanks for doing those rankings again, yo.</i><br><br>You're welcome. =)<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=378235" class="name">Mario Man53245</a> |
Posted 9/13/2006 6:41:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334346495">message detail</a>
 | #069</td></tr>
<tr class="even"><td>
tag<br>---<br>"Nothing helps a bad mood like spreading it around" - Calvin
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/13/2006 7:43:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334363245">message detail</a>
 | #070</td></tr>
<tr class="even"><td>
Close only counts in horseshoes and handgrenades. And I've got one of each with me!<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/13/2006 7:48:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334364559">message detail</a>
 | #071</td></tr>
<tr class="even"><td>
And flamethrowers, and nuclear bombs.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=945395" class="name">FantasyFreak999</a> |
Posted 9/13/2006 7:59:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334367710">message detail</a>
 | #072</td></tr>
<tr class="even"><td>
tag (I've been looking everywhere for this!)<br>---<br>"Run, run, or you'll be well done!" <br>~Kefka, Final Fantasy 6~
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/13/2006 8:35:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334377482">message detail</a>
 | #073</td></tr>
<tr class="even"><td>
<b>Spazer Division:</b> <i>Round 1 - Match 3</i> &#8211; (3)Rikku vs. (6)Lenneth Valkyrie <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Rikku</b><br>Game/Series Known From: Final Fantasy X<br>Extrapolated Rank in 2005: 28th  (24.33%)<br>Seed in 2005: 7<br>Lost in 2005 to Ryu in Round 1 <br><br>Rikku made her Contest debut in 2005 and is back to show the females how it&#8217;s done.<br><br><b>Lenneth</b><br>Game/Series Known From: Valkyrie Profile<br><br>&#8230;&#8230;&#8230;&#8230;&#8230;&#8230;&#8230;&#8230;&#8230;&#8230;&#8230;&#8230;&#8230;&#8230;&#8230;&#8230;&#8230;.<i>Who?</i><br><br>So
in one corner we have a Final Fantasy X female, and in the
other&#8230;Lenneth. In one corner, we have a woman who was able to put up
45% on Ryu, and in the other&#8230;Lenneth. This match is just too easy. <br><br>I
could go and do research on how much FFX/FFX-2 has outsold Valkyrie
Profile, but that&#8217;s unecessary. All you need to do is ask yourself if
the casual voter will know who Lenneth is? Then ask if they would vote
her over Rikku. Yeah, Rikku has this in the bag.<br><br><b>Moltar&#8217;s Bracket Says:</b> Rikku will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Rikku: 80% - Lenneth: 20%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br><br>Lenneth
making a contest is cool and all, but Valkyrie Profile is far too cult
for her to do any damage in this match at all. Especially not after
what Rikku pulled off against Ryu last year. Valkyrie Profile making it
to the PSP might make a difference of a percent or two, but that's
still not much of anything noteworthy.<br><br>Prediction: Rikku with 72.45%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>So
I&#8217;m guessing that Lenneth managed to make it in because of that new PS2
RPG&#8230;Silmeria, I believe. No matter, she&#8217;s up against a Final Fantasy
female who was able to put up 45% against <i>Ryu</i> of all
characters. Rikku is definitely one of the strongest on the female
side, which doesn&#8217;t really matter considering Ms. Aran heads up this
division, but it&#8217;s worth noting! <br><br>Lenneth may have a nice cult
fanbase that will be able to keep her from being too far below other
cult RPG characters, but there&#8217;s nothing to see here other than a huge
blowout for Rikku. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Rikku<br><br><b>Aitch Emm&#8217;s Prediction:</b> Rikku &#8211; 77% ; Lenneth Valkyrie &#8211; 23%<br><br><b>Aitch Emm&#8217;s Vote:</b> Rikku<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>I don't know her, you don't know her, but her name is <b>Lenneth Valkyrie</b>, and she's here to stink up the joint! Tell me, <i>Lenneth</i>, can you score 45% on Ryu? Huh? Can you? Want to give it a shot? Oh, what's that? You say you can't? Awww...<br><br>Well too bad so sad for you, toots! Get out of my sight.<br><br>My prediction: Rikku def. Lenneth Valkyrie (77-23)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>From
what I understand, Lenneth Valkyrie is the star of Valkyrie Profile.
Valkyrie Profile is a pretty hard game to get your hands on, I can't
find it anywhere! You know what, I think as research for this match, I
should play this game&#8230; let's go to eBay!<br><br>*walk walk walk*<br><br>Okay,
we're here at eBay! Let's find "Valkyrie Profile". *finds results* Oh,
alright! The games are only selling for $30 or $40! Excellent! Whoa
whoa&#8230; that's the <i>PSP</i> game? Yeah right, like anyone owns <i>that</i>. I want the PS game! Ah, here we go:<br><br><a class="linkification-ext" href="http://cgi.ebay.com/Valkyrie-Profile-Playstation_W0QQitemZ120027041798QQihZ002QQcategoryZ62053QQrdZ1QQcmdZViewItem" title="Linkification: http://cgi.ebay.com/Valkyrie-Profile-Playstation_W0QQitemZ120027041798QQihZ002QQcategoryZ62053QQrdZ1QQcmdZViewItem">http://cgi.ebay.com/Valkyrie-Profile-Playstation_W0QQitemZ120027041798QQihZ002QQcategoryZ62053QQrdZ1QQcmdZViewItem</a><br><br>EGADS!
$102.50 plus S&amp;H! And it's still going! Stay tuned to see how much
it finished for! Okay, this was a roundabout way of saying "Valkyrie
Profile is cult". Sorry, I wanted more than a four word analysis&#8230; I
know you did too. Expect a Luca Blight-esque (who is also star of an
eBay ripoff special!) performance from Lenneth.<br><br><b>Lopen's Prediction:</b> Rikku with 76.94%
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/13/2006 8:35:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334377653">message detail</a>
 | #074</td></tr>
<tr class="even"><td>
<b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br>Rikku<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 30th Place [24.33%]<br><br>Next
up is Rikku. And hey, this year I actually know something about her,
thanks to my recent playthrough of FFX. Yeah, Rikku's cool, though if
you're not using items or stealing she's basically useless early on.
Good personality too, though she could stand to act more realistic.
Though this is a problem with every character in X, not just -- oh,
wait! Contest match, yeah...well, Rikku did a helluva job in her first
time out, getting 44% on Ryu -- for comparison, <i>Dante</i> got 46%
in 2k3. Even on a weaker Ryu, that's great. But she could have only got
20% on Ryu and still have this first match in the bag. For her opponent
is...<br><br>Lenneth Valkyrie<br><br>lol N/A<br><br>My pick for the
weakest character of the contest here, ladies and gentlemen. No, the
PSP remake will do squat. No one knows who she is, no one will confuse
her with anyone except maybe the Valkyrie from Gauntlet Legends (who,
by the way, I would take to beat Lenneth in a match). And no, I don't
know anything about her, so nyah. =p<br><br><i>Notable Releases Since Last Appearance</i><br><br>Rikku: Kingdom Hearts 2 (PS2)<br><br>Lenneth Valkyrie: Valkyrie Profile (PS), Valkyrie Profile (PSP)<br><br><i>Upcoming Releases</i><br><br>Rikku: N/A<br>Lenneth Valkyrie: Valkyrie Profile: Silmeria (PS2)?<br><br>Yeah,
the only thing hard about this match is gauging how fodderific Lenneth
will be, and then putting it up against Rikku. Um...geez. I dunno,
Rikku seems to get some hate, which might stop her a bit, but on the
flip side...well, it should be well above what Samus got on Nidoran F.<br><br>Karma Hunter's Vote: Rikku. See Ada/Jade.<br><br><b>Karma Hunter's Krazy Prediction: Rikku with 86.34%.</b><br><br>This *looks* crazy, but if Ada can get 75% on Jade...<br><br>Upset Potential: 0%<br><br>Wow, I have no respect for Lenneth, it seems. Come get me, fanboys.<br> <br><br><br><b>Guest&#8217;s Analysis</b> - <i>Redtooth</i><br> <br>This
is my first (and hopefully not final) foray into the world of B8
contest analysis. For this initiation of sorts, my match to predict is
pretty easy. That also means kind of dry, but that&#8217;s probably more my
fault anyways =P. So on one side, we have Rikku, who jumped into the
last contest and really impressed. On the other, we have a complete
unknown, Lenneth Valkyrie. As with most of the matches in the female
sections, percentages and even results are bound to fluctuate
enormously. <br><br>Rikku so far has only had one match, against Ryu.
Putting up high percentages there shows the potential that Rikku has.
Although x-stats are seemingly laughed it, she&#8217;d still place higher
then Yuna according to them. Seeing the competition, this puts Rikku at
the top of the field. She&#8217;d be able to put up good numbers against
pretty much any girl in the contest. We won&#8217;t really know until we see
how she does against Samus though. It could show the fight with Ryu was
a fluke or her actual power. <br><br>Then we see Lenneth Valkyrie. Her
first contest appearance placed into a very unsure match. Not of the
result, but of the percentage. A quick look through the Oracle shows a
spread from 59.23% to 88.39% as to predictions, most falling between
63% and 80%. Now, regardless of how strong Rikku happens to be, which
is still unsure, no one really knows how strong LV might be. The
difficulty of getting a copy and a non-casual game might put her below
the fodder line? Maybe the fact that she looks cool, is cult and a cool
character might throw her into a respectable level?
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/13/2006 8:36:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334377903">message detail</a>
 | #075</td></tr>
<tr class="even"><td>Regardless the match is completely without debate,
with no one I&#8217;ve seen yet to side with Lenneth. The whole match is
frustrating too, as it&#8217;ll be hard to understand for a long while.
Barring an upset and a 90/10 match, it seems this early fight won&#8217;t be
giving much input for either character. <br><br>And
who am I kidding anyways, 90% of voters will probably: vote Rikku
because they get excited by her looks or vote Lenneth because she looks
cool and has a sword. Since you can logically follow that kids play
game, gamefaqs is about games, so perverts and murderers flock gamefaqs
for the innocent kids, and inadvertently vote. And everyone knows there
are more perverts on the internet then murderers. Thus Rikku wins easy.
The only swing votes are those perverted murderers, who&#8217;ll probably
vote green this year anyways. <br><br>Prediction: Rikku with 62.00% <br> <br>  <br><br>Summary:
Lenneth may be an unknown, but we all know she won't be a match for
Rikku. The Crew thinks it'll be ugly, but the Guest has a different
result in mind.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/13/2006 8:47:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334380878">message detail</a>
 | #076</td></tr>
<tr class="even"><td>
Nice writeup on short notice, redtooth. Probably a much better job than I could have done, haha.<br>---<br>CB06 - Score: <b>1/1 </b>Rank: <b>Tied - 1st </b>Yesterday's Pick:<b> Samus</b> <br>Today's Pick: <b>Ada Wong</b> Tomorrow's Pick: <b>Rikku</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=304351" class="name">Mac Arrowny</a> |
Posted 9/13/2006 8:55:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334383395">message detail</a>
 | #077</td></tr>
<tr class="even"><td>Crew = Lame for not playing BG&amp;E or VP.
Seriously, a game doesn't have to sell a million copies for it to be
worth playing, guys.<br>---<br>Pity for the guilty is treason to the innocent.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=1009378" class="name">The Real Truth</a> |
Posted 9/13/2006 8:58:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334384334">message detail</a>
 | #078</td></tr>
<tr class="even"><td>
Lenneth is also a secret boss in Star Ocean 3.<br>---<br><b>Let's welcome Chaos.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/13/2006 9:00:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334384758">message detail</a>
 | #079</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis</i><br><br>Let's see....on one hand, we
have a character from the widely popular RPGs Final Fantasy X, Final
Fantasy X-2, and Kingdom Hearts II. On the other hand, we have a
character from the relatively unknown RPG Valkyrie Profiles, or
something. *yawn*<br><br>My vote: Rikku, she's hot<br>My bracket: Rikku<br>My prediction: Similar to today's match, but Rikku is stronger than Ada, so.....84%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br>**Character Battle V PRINTABLE BRACKET** See quote for link.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=1009378" class="name">The Real Truth</a> |
Posted 9/13/2006 9:00:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334384759">message detail</a>
 | #080</td></tr>
<tr class="even"><td>
Well Valkyrie Profile is like $100....And not everybody wants to buy a PSP for one game.<br>---<br><b>Let's welcome Chaos.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/13/2006 9:01:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334385109">message detail</a>
 | #081</td></tr>
<tr class="even"><td>
Hey, I can't play everything that's out there.<br><br>Besides, I make fun of characters from games that I have played too!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Ada Wong vs. Jade - Bracket: <b>Ada</b> - Vote: <b>Ada</b> (1/1)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 9/13/2006 9:02:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334385406">message detail</a>
 | #082</td></tr>
<tr class="even"><td>
I say the Guest gets the point here! &gt;_&gt;<br>---<br>This was Ed Bellis, servant to the mighty Guru <b>Z1mZum</b>. Congrats, buddy!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/13/2006 9:07:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334386565">message detail</a>
 | #083</td></tr>
<tr class="even"><td>
I've beaten Beyond Good and Evil a few times. Good game. Not fantastic, but good.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=988915" class="name">Redtooth</a> |
Posted 9/13/2006 9:09:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334387196">message detail</a>
 | #084</td></tr>
<tr class="even"><td>
Yea, I like Lenneth. Even though I have her losing and my oracle pick
is much higher, I can at least make my analysis guess more or less
hopeful &gt;_&gt;<br><br>---<br>Z1mZum&gt;Redtooth <br><i>Nice list, I counted twenty that would be in my top ten</i> - BlondeAfroHero7
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/13/2006 11:26:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334412831">message detail</a>
 | #085</td></tr>
<tr class="even"><td>
MAN I have an easy point today unless Rikku either completely explodes or completely tanks.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=2797132" class="name">appestats</a> |
Posted 9/14/2006 10:37:53 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334463833">message detail</a>
 | #086</td></tr>
<tr class="even"><td>
tag
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/14/2006 5:46:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334539376">message detail</a>
 | #087</td></tr>
<tr class="even"><td>
Ada Wong.........75.89% 74498<br>Jade..................24.11% 23669<br>TOTAL VOTES.................98167<br><br>64.74% of the brackets predicted this match correctly.<br><br>Wow,
I didn't think Ada would be capable of blowing out an opponent that
badly. The woman in the red dress triples Jade. Unfortunately, the
match is the first in a long streak to not break 100K votes.<br><br>Today, Rikku is making easy work of Lenneth. At the rate she's increasing, she looking to pull off a tripling.<br><br>HM - 1<br>Ulti - 1<br>Moltar - 0<br>Yoblazer - 0<br>Loepn - 0<br>KH - 0<br>Guest - 0<br><br>HM has the closest Ada pick.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Rikku vs. Lenneth - Bracket: <b>Rikku</b> - Vote: <b>Rikku</b> (2/2)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/14/2006 5:56:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334541889">message detail</a>
 | #088</td></tr>
<tr class="even"><td>
<i>MAN I have an easy point today unless Rikku either completely explodes or completely tanks.</i><br><br>HAW HAW!<br><br>And
here's a Crew Preview: Kairi/Claire analyses are in, and it's a 4-3
split. Which side did the Crew favor? Find out a little later! <br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Rikku vs. Lenneth - Bracket: <b>Rikku</b> - Vote: <b>Rikku</b> (2/2)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=2584321" class="name">longbladeofhiko</a> |
Posted 9/14/2006 5:57:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334542076">message detail</a>
 | #089</td></tr>
<tr class="even"><td>
Are there any matches left?<br>---<br><b>WWEGSB Hardcore Legend And Tag Champ Masa</b><br>I jobbed to <b>Z1mZum</b> in the Guru Contest. Did you?
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/14/2006 5:57:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334542100">message detail</a>
 | #090</td></tr>
<tr class="even"><td>
I still don't know who I think is going to win that match.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br>**Character Battle V PRINTABLE BRACKET** See quote for link.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/14/2006 6:16:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334547016">message detail</a>
 | #091</td></tr>
<tr class="even"><td>
<i>MAN I have an easy point today unless Rikku either completely explodes or completely tanks.</i><br><br>I
don't know what he was talking about. Rikku &gt;= 74.69% = my point.
Even when he posted it she was hovering around that area. With the
square evening vote and some breathing room, the point is <i>mine</i>.  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/14/2006 8:01:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334574446">message detail</a>
 | #092</td></tr>
<tr class="even"><td>
<b>Spazer Division:</b> <i>Round 1 - Match 4</i> &#8211; (2)Kairi vs. (7)Claire Redfield <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Kairi</b><br>Game/Series Known From: Kingdom Hearts <br><br>Kingdom Hearts is the thing on GameFAQs right now, so no surprise to see Kairi here.<br><br><b>Claire</b><br>Game/Series Known From: Resident Evil<br>Extraploated Rank in 2002: 13th (30.11%)<br>Seed in 2002: 9<br>Lost in 2002 to Tidus in Round 1<br><br>Well, it&#8217;s an old familiar face! Looks like RE4 reminded some people to get Claire in this Contest.<br><br>Alright, this is my match! This is the upset special I&#8217;m looking forward to. Kairi or Claire, let&#8217;s rock!<br><br>First,
let me begin with some predictions. I don&#8217;t think Kairi will be as
strong as her seed indicates. With Sora and Riku also getting high
seeds and Axel getting in on the male side, it seems like people just
nominated KH characters in droves. It doesn&#8217;t mean they&#8217;ll actually
vote for them over any opponent. Now, if Kairi does end up showing some
decent strength, then she&#8217;ll probably win, but hey, gotta take risks
when looking for an upset.<br><br>Next is my prediction on Claire,
which is that while she won&#8217;t be at her 2002 value, she hasn&#8217;t fallen
far enough to lose this match. In 2002, she was able to put up 45% on
Tidus, which wasn&#8217;t a joke back then. However, Claire hasn&#8217;t been in a
game in forever, and the only thing she really has going for her now is
the RE fans votes. She&#8217;s fallen off the map. Her and Jill could boost
because of RE4 even though they aren&#8217;t in it because of the series
getting stronger as a whole.<br><br>Now we get to this match. Untested,
over-seeded newbie who on her own has few fans and will probably get
most of her strength from series votes versus someone who was strong
but hasn&#8217;t had a release in years, but could potentially still have
some of her strength. Tough. I won&#8217;t be surprised if Kairi wins, but I
can&#8217;t see her winning with anything more than 55%. <br><br>I see the
match as a gamble either way. If you&#8217;re banking on Kairi, she could
flop horribly and Claire wins with ease. If you&#8217;re on the Claire
bandwagon, she could end up beaten eaten alive by KH fans and her own
problem with exposure these days. Some may say I&#8217;m holding on to
Claire&#8217;s 2002 value too tightly, but whatever. We may see voting
shifts, but I can&#8217;t see the voting audience shift enough to where
Claire falls to the bottom. I see this upset having the best chance of
happening in the female bracket.<br><br>It&#8217;ll also be interesting to
look at the voting patterns in the match. I think Claire will start
with the early lead, but it&#8217;s just a matter of how quick and how much
she can build it. Kairi will begin to fight during the KH day vote, so
hopefully this match is as good as it looks on paper.<br><br><b>Moltar&#8217;s Bracket Says:</b> Claire will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Kairi: 47% - Claire: 53%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br><br>I feel like writing an analysis that makes no real sense for once.<br><br>Robotnik vs Sin from 2005 CLEARLY tells us how this here match will go<i>!!</i><br><br>Sonic &gt; Auron<br><br>Knuckles &gt; Tidus<br><br>Shadow &gt; Yuna<br><br>With
all that in mind, Robotnik being &gt; Sin should have been an obvious
conclusion that we all should have seen coming from day one! And
obviously the entire Sonic series would have whipped FFX's ass in a
poll if such a thing were even possible. See where I'm going with this?
No? Well screw you, then.<br><br>But because I'm nice, we'll look at an equally credible analysis of Resident Evil versus Kingdom Hearts!<br><br>Sora &gt; Leon Kennedy<br><br>Riku &gt; Jill Valentine<br><br>Ansem &gt; Wesker<br><br>Kingdom Hearts &gt; Resident Evil (you have to factor in "MGS tanks against anything with real strength" SFF in those stats)<br><br>Clearly, Kairi &gt; Claire is the only logical conclusion that can come of this! \m/
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/14/2006 8:02:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334574636">message detail</a>
 | #093</td></tr>
<tr class="even"><td>
Clearly, Kairi &gt; Claire is the only logical conclusion that can come of this! \m/<br><br>Though
if you want something a bit more serious, I went and surfed the net a
bunch during some random day of boredom. The KH fanbase cares for Kairi
about as much as the RE fanbase cares for Claire. That said, close
matches like this are generally about whichever fanbase is more rabid.
I give a SLIGHT edge to Kingdom Hearts there, solely because my inbox
hasn't been the same since I got that KH2 bestiary posted on GameFAQs.
RE4 is popular as hell in its own right, but I doubt any of its
in-depths scored 100k hits in ~6 months.<br><br>And yeah yeah FAQ hits
are meaningless with contest matches, but it's either make a joke
analysis or post something like "I think Kairi wins on gut instinct".<br> <br>Prediction: Kairi with 51.24%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>We
arrive at the first debatable match quite early this time around with
Kairi and Claire. Both of these characters have reasons to win and
reasons to lose. Claire made her first appearance in the 2002 contest
and did quite well for herself, but she has been absent from every
other contest since. Kairi is a newcomer who got in thanks to the surge
of Kingdom Hearts fans that were brought to the site thanks to Kingdom
Hearts II. <br><br>In this match, I think it matters more about who do
people care about more, because both of them are going to be rather
weak. In the case of Claire, she comes from a Resident Evil series that
seems to be picking up more popularity thanks to Resident Evil 4 &#8211; she
had no role in the game &#8211; but also hasn&#8217;t made been in with the gaming
scene since about 2001. That puts her at a rather disadvantageous
position against a more prominent Kairi who has been here since 2003
and, more recently, 2006 courtesy of Kingdom Hearts II. <br><br>I
think that for the people who don&#8217;t care about either character, which
I&#8217;m assuming will be a good deal of the site, they&#8217;re going to vote for
the one who may be in their favorite game or who is at least fresh in
their minds &#8211; Kairi. This match will undoubtedly be close, but I have a
hard time imagining that Claire would be able to take care of someone
who is coming off such a huge hit. Kairi should still be weak, no
doubt, but it should be enough to squeak by a much weakened Claire. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Kairi<br><br><b>Aitch Emm&#8217;s Prediction:</b> Kairi &#8211; 53% ; Claire Redfield &#8211; 47%<br><br><b>Aitch Emm&#8217;s Vote:</b> Kairi<br><br> <br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Well,
here it is! This has easily been the most debated female match of the
bracket, and is, in actuality, probably one of the only female matches
where my plebian brain can muster a long write-up. This is also the
match that's occupied more of my thinking time than the rest of this
bracket combined.<br><br>It's not hard to see why Kairi is the favorite
going into this thing. She has the higher seed, the more recent big
game, and three other Kingdom Hearts characters in the bracket,
including a TOP SEEDED Sora. We all know that seeding is a pretty weak
indicator of strength, so let's take a look at just why Kairi should be
popular enough to defeat Claire: Kingdom Hearts II.<br><br>Needless to
say, KHII has been hot stuff ever since its release in late March. It's
still GameFAQs' most popular game of 2006, and it allowed the series to
get past Castlevania in our last contest. Kairi is Kingdom Hearts' lead
heroine in both games. Naturally, she should have enough popularity to
defeat Claire Redfield, who has been missing from the gaming scene for
five years. Well, if it were all <i>that</i> easy, this match wouldn't be so debated, would it?
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/14/2006 8:02:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334574750">message detail</a>
 | #094</td></tr>
<tr class="even"><td>
Delving further, one will realize that Kairi has several "flaws" that
will hinder her popularity. Unlike more traditional, experienced female
entrants like Samus, Zelda, and Jill Valentine, Kairi has never been
playable. Unlike our contingent of Final Fantasy gals (from Tifa all
the way down to Terra), Kairi has never been a party member. Not being
an RPG buff, I'm not sure if "party member" can be sandwiched in the
same category as "playable," so I separated them. Now, the general
progression of power goes <i>Playable &gt; Party Member &gt; Villain</i>
(with the last two being often interchangeable). It makes sense.
Villains are usually badass and play major roles in plotlines.
Unfortunately, Kairi isn't a villain, either. She's not badass (she's
not even cool, and I say this as a big Kairi fan), she doesn't
contribute much memorable stuff to the story, and she doesn't even have
that much screen time. Armed with this knowledge, I consulted the
contest archives in search of the strongest non-playable, non-party
member, non-villain we had ever seen. Let me tell you, folks... the
search was not an easy one. Simply put, not many of these characters
have ever been in a contest. I was about to call it a day, and then I
found it.<br><br><i><a class="linkification-ext" href="http://img160.imageshack.us/img160/5549/youvegottobekiddingmelq9.jpg" title="Linkification: http://img160.imageshack.us/img160/5549/youvegottobekiddingmelq9.jpg">http://img160.imageshack.us/img160/5549/youvegottobekiddingmelq9.jpg</a></i><br><br>Yes,
HIM. HE'S the most popular non-playable, non-party member, non-villain
we've ever seen. I'd like to see you argue your way out of <i>this</i>,
Kairi! In all seriousness, I do believe this hurts Kairi. There's only
so much emotional attachment you can make with a player if you're never
around and never do anything memorable. There's a limit to how much the
average voter can care about you. Unless Kingdom Hearts fans are just
as loyal as (or more loyal than) Nintendo fans in their voting
patterns, Kairi should be <i>really</i> weak stuff.<br><br>Now, it's
Claire's turn to face my fury. My my my, where have you been, Ms.
Redfield? It's been years since I've played RE2 and Code Veronica, but
that doesn't mean I've forgotten how much I like you. Much like Ada
Wong, Claire has made the most of her two games, appearing on an
incredible <i>five</i> different consoles. The games themselves are
nothing to scoff at, either. Claire's two RE games are arguably #2 and
#4 in the Resident Evil popularity ladder, and she had the <i>most popular</i>
RE game of all prior to January of 2005. Unlike Kairi, however, Claire
doesn't spend her in-game time as a side character. She's starred in
two games, and has been a playable lead in both. That's good. Also, if
contest history is your thing, Claire absolutely tore up the X-Stats in
2002. Sure, that was a long time ago, and the result is almost
certainly skewed and not very useful today, but there's no way you can
call that bad. At least she has <i>something</i>. Well, it seems that
the balance of power has shifted! Whereas Kairi was the clear favorite
at the start of this analysis, now, through nothing more than my
infallible arguments and Herculean jaw line, Claire is the favorite?!
What gives?! Two things: recency and Jill Valentine's contest history.<br><br>As
stated earlier, Claire Redfield has long been missing in action. In
fact, her last big console game (Code Veronica X for the PS2) was
released a full year before Kairi even <i>existed</i>. Many Kairi
supporters are hoping that all this time away from the spotlight will
have hurt Claire's status and popularity among voters. It certainly is
a valid point, and one we won't find the answer to until match time (if
ever). Bracket makers are also trying to get a feel for Claire's
strength by looking at Jill. Much like Claire, Jill was pretty damn
strong in 2002. In 2003, Claire was gone, but Jill was back... and she
had gotten weaker. In 2004, she got even weaker still. She was nowhere
to be seen in 2005, but people look at this three year stretch of
decreasing popularity and wonder if Claire would have met the same
fate.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/14/2006 8:03:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334574943">message detail</a>
 | #095</td></tr>
<tr class="even"><td>Would she have? If I had to guess, I'd say
absolutely. To put it bluntly, having boobs in 2002 helped. It helped a
lot. Even still, there's no way Claire was ever legitimately worth 30%
on Link. However, I see no reason to believe why she would be
significantly weaker than Jill. Both have been playable leads in two
Resident Evil games, and both have 4+ year absences from the gaming
industry. This, and the fact that I would never, ever consider taking
Kairi over Jill, has caused me to side with Claire in this real *****
of a match.<br><br>I hope this tank of a write-up makes up for my rather short earlier ones; now let's just hope it was worth something!<br><br>My prediction: Claire Redfield def. Kairi (55-45)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Claire
was first in this thing in 2002. She did pretty well against Tidus (who
I'd easily take over Kairi), and she had a pretty mighty X-Stat value
too, implying that might've been a stronger Tidus. Well you know what?
I don't really care what happened back then&#8230; it was from <i>years</i>
ago. Jill Valentine sure looked a lot better back then, too. Basically&#8230;
I'm not trusting that Claire is what those X-Stats of yore imply, or
that she even still has a close match with Tidus. (who doesn't seem
nearly as fearsome these days)<br><br>And yet&#8230; even though I say Claire's not <i>nearly</i> as popular as 2002 implies, I <i>still</i> think Claire's taking this match pretty easily. Kairi may be from Kingdom Hearts, the same Kingdom Hearts that managed to get <i>four</i>
reps in this contest, the same Kingdom Hearts that has a sequel that
most of GameFAQs would call game of the year right now. But&#8230; a name can
only get you so far! Kairi just doesn't strike me as having many <i>fans</i> out there.<br><br>Characters from popular games <i>can</i>
be fodder. We've seen it time and time again. Terra&#8230; Kerrigan&#8230; Sin&#8230;
even Ansem from the very same series. (who I'd take to beat Kairi, by
the way) People are expecting Kingdom Hearts to carry Kairi to victory?
After this one&#8230; I'm expecting Kingdom Hearts to have to carry Kairi&#8230;
out on a stretcher! OH YEAH!<br><br><b>Lopen's Prediction:</b> Claire Redfield with 63.08%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br>Kairi<br><br>lol N/A<br> <br>Hello,
useless NPC romantic interest! Haven't seen you in a while, and your
importance and relevance to the game is about as minimal as it can be,
especially since it's a 40+ hour RPG! Yes, it's Kairi, the girl whose
name I keep mistyping because DAMN YOU DYSLEXIA. Anywho, she's useless,
non-apparent, and jailbait. I smell a contest powerhouse here, folks!<br> <br>Claire Redfield<br> <br>Summer 2002 Contest<br>Extrapolated Strength --- 13th Place [30.11%]<br><br>Every
single time I remember Claire was in 2002, I'm shocked. Every single
time I remember that she ended up outranking Jill, I get even more
shocked. And when I realize that she came in 13th place -- OVERALL -- <i>how in the hell did she not return to the field, X-Stats be damned???</i><br> <br>Well,
there is the whole thing about 'nominations'. And Claire isn't *that*
strong, Tidus is likely a bit overrated from his Sonic match, there's
all that 'WDF' or 'Link/Mario SFF' or whatever you want to call it
going on, and she likely benefitted from being in an early match
against Tidus -- who, now that I've played FFX, understand why he got
so much hate (though I like Tidus, he's cool). But still, a little
below Jill is damn impressive, and Kairi simply can't compete with
that. However, that was 2002. Welcome to 2006, Claire Redfield. The
world has changed...<br> <br>Claire Redfield: N/A
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/14/2006 8:05:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334575523">message detail</a>
 | #096</td></tr>
<tr class="even"><td>
<i>Notable Releases Since Last Appearance</i><br><br>Kairi: Kingdom Hearts (PS2), Kingdom Hearts 2 (PS2)<br>Claire Redfield: N/A<br><br><i>Upcoming Releases</i><br><br>Kairi: N/A<br>Claire Redfield: Resident Evil: Umbrella Chronicles (WII)<br><br>The
first debatable match of the round by absolute necessity, and it has
all the ingredients of the perfect X-Stats upset. Claire was pretty
much what a near-elite looked like in 2002. Kairi *will* be fodder.
Kairi is overseeded thanks to KH2, Claire is underseeded due to
splitting noms with Jill and Ada. Kairi is a useless NPC, Claire is a
main character of two popular REs. Everything is in place...except I've
got a horrible feeling about this match.<br> <br>When's the last time
an X-Stats upset panned out? Bowser &gt; Snake was about as close as we
got, *maybe* Kirby &gt; Tidus if you want to count it. As someone said
last night, this feels like Mega Man/Mario Kart all over again, and
while it's not assured to be the same at all, I couldn't side with
Claire here, much as I wanted to.<br> <br>Kairi is from KH2 -- that
game is absolutely huge, and is STILL huge right now. Recency alone
will give her an edge. I don't think people will bother to remember
Claire, because unlike Crono her games are not incredibly impactful to
the audience here. Even Leon Kennedy of RE4 won't be remembered in a
few years if he doesn't keep up his game quota.<br> <br>Little X-Stat
reasoning here, but all my logic and initial feelings tell me Kairi
should take it. Let's use those weird thingies.<br><br>Karma Hunter's
Vote: Claire. I've got to go with the strong woman that carried me
through the best and third best RE games out there.<br><br><b>Karma Hunter's Krazy Prediction: Kairi with 58.9%.</b><br> <br>Going high here again. Since Kairi winning depends on Claire falling off the map, and all...<br><br><b>Upset Potential: 40%<br> <br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br><br>Whenever
we go into 15%+ territory, we get an upset alert, where the upset gets
its case spelled out in dramatic fashion. This is good, as you'll
sometimes see me back what I consider to be the 'upset pick' in my
bracket. It's called a calculated risk, dammit!<br> <br>Today is just a
warm up, because we've gone through it before. If Claire has even a
fraction of that original strength left, she wins. Wow, that actually
sounds really bad for Kairi. Let's give Claire a higher upset pick;
it's not like it counts for the Crew. =)<br> <br>Upset Prediction: Claire with 61.2%<br> <br><br><br><b>Guest&#8217;s Analysis</b> - <i>Inviso</i><br> <br>Kairi
is from a series that has been a big hit in the past few years and has
a new game out from March. Claire is from a series that is also pretty
big, what with RE4 being such a huge hit. There is a difference
however. Claire is not even in RE4 and hasn't been in a game in quite
some time, plus, while Jill and Leon are popular for their games,
Claire is far more obscure. Ada's showing on Jade is nothing as
BG&amp;E is obscure and Ada gets some GCN SFF. The point is, while
Kairi isn't a playable character like Claire, this is GameFAQS where
RPGs rule when Nintendo's not around, especially SquarePGs. Kingdom
Hearts&gt;Resident Evil in this instance and Kairi will win.<br><br>Winner: Kairi with 53.27%<br> <br><br> <br> <br>Summary:
Crew slightly leaning towards Kairi in a 4-3 decesion. Basically it
comes down to 'If Claire has her old-school and RE fanbase behind her
versus if Kairi has her KH fanbase behind her and they series-vote
her'.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/14/2006 8:06:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334575726">message detail</a>
 | #097</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>I originally picked Claire,
then I changed to Kairi. Then I was thinking about changing back to
Claire, but the brackets closed before I could. Right now, I have no
clue who will win this match. Kairi is from the popular Kingdom Hearts,
Claire is from the popular Resident Evil. Instinct says that KH would
beat RE, but I think Claire is more prominent in RE than Kairi is in KH.<br><br>My vote: Claire<br>My bracket: Kairi I guess<br>My prediction: 50-50 tie.  Okay, seriously......Kairi with 56%.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br>**Character Battle V PRINTABLE BRACKET** See quote for link.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3623587" class="name">Gaddswell</a> |
Posted 9/14/2006 8:07:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334575955">message detail</a>
 | #098</td></tr>
<tr class="even"><td>
Man, I was about to retag when you started posting everything... I had to wait until the entire analysis was posted!<br><br>Anyways, good job as always Analysis Crew! We finally, a debatable match!<br>---<br>By the time we localize the programs, kids don&#8217;t even know they&#8217;re from Japan any more. - 4Kids CEO Al Kahn<br><b>Vote Right! Phoenix Wright!</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3685859" class="name">PartOfYourWorld</a> |
Posted 9/14/2006 8:10:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334576985">message detail</a>
 | #099</td></tr>
<tr class="even"><td>
Hmm... I have over five percentage points of cushion. Not bad at all.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/14/2006 9:05:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334591775">message detail</a>
 | #100</td></tr>
<tr class="even"><td>
4-3 Kairi?  When the Crew split over Mario Kart-Mega Man, and the majority picked MK, MM won...Not good for my bracket...<br><br>Still,
Kairi should win. Even if I downright hated practically everything
about her in KH1...At least she isn't useless in KH2...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">1</a></li>
<li>2</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=9">10</a></li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage2_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30499515&amp;page=1" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
<div id="copyright">
	<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
	<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
	<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
</div>
<script src="genmessage2_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</div></body></html>