<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	



<title>GameFAQs - GameFAQs Contests Message Board</title><meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage5_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage5_files/nogs.css"></head><body linkifytime="280" linkified="7" linkifying="false"><div id="container">
	<div id="gne_nav">
		<img src="genmessage5_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/events/x06/">X06</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage5_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30499515%26page%3D4"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage5_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage5_files/advertisement.gif" alt="advertisement" height="10" width="120"></div>
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage5_files/f.xhtml" marginwidth="0" marginheight="0" hspace="0" vspace="0" allowtransparency="true" frameborder="0" height="90" scrolling="no" width="728">
&lt;script language=javascript&gt;&lt;!-- randNum = ((new
Date()).getTime() % 2147483648) + Math.random(); document.write( "&lt;a
href='http://a.tribalfusion.com/i.click?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID="
+ randNum + "' target=_blank&gt;" + "&lt;img
src='http://a.tribalfusion.com/i.ad?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID="
+ randNum + "'" + " width=728 height=90 border=0 alt='Click
Here'&gt;&lt;/a&gt;"); // --&gt;&lt;/script&gt; &lt;noscript&gt; &lt;a
href="http://a.tribalfusion.com/i.click?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID=1576037958"
target=_blank&gt; &lt;img
src="http://a.tribalfusion.com/i.ad?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID=1576037958"
width=728 height=90 border=0 alt="Click Here"&gt;&lt;/a&gt;
&lt;/noscript&gt; </iframe><img src="genmessage5_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;page=4">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30499515" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=3">Previous Page</a> |
Page 5 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=5">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/18/2006 3:49:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335364136">message detail</a>
 | #201</td></tr>
<tr class="even"><td>
At the rate Jill's dropping my money's on Guest or Moltar getting this point. This afterschool vote is painful.<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/18/2006 3:52:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335364702">message detail</a>
 | #202</td></tr>
<tr class="even"><td>
Down another .04% on that update. Yeah, it's gonna blow by your mark.
Looking good for my prediction, especially since I basically just threw
a number out there with nothing to back it up with; and I swear I
didn't look at any of the crew's prediction percentages first.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br>**Character Battle V PRINTABLE BRACKET** See quote for link.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=731135" class="name">WiggumFan267</a> |
Posted 9/18/2006 4:29:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335373223">message detail</a>
 | #203</td></tr>
<tr class="even"><td>
*Dances around the maypole*<br><br><br>---<br>Score: <b>5</b>/6. Pick: <b>Jill</b> &gt; Sheena. Vote: <i>Sheena</i>. <br>Happily married to Alanna82 on VDay 2005
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/18/2006 4:31:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335373700">message detail</a>
 | #204</td></tr>
<tr class="even"><td>
The Boss..................61.08% 66787<br>Celes Chere............38.92% 42565<br>TOTAL VOTES..................109352<br><br>68.16% of the brackets predicted this match correctly.<br><br>Another
debated match that turns into an easy victory for a side. We always get
a few of these. In this case, The Boss makes Celes looks pretty bad.
Excellent bracket support for her too, compared to the board.<br><br>Today, Jill is winning the match, but Sheena is doing well with the after-school vote. I wonder where it will end.<br><br>Ulti - 3<br>Lopen - 2<br>HM - 1<br>Moltar - 0<br>Yoblazer - 0<br>KH - 0<br>Guest - 0<br><br>BAH GAWD, can anyone stop the carnage? Another point for Ulti.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Jill vs. Sheena - Bracket: <b>Jill</b> - Vote: <b>Sheena</b> (5/6)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/18/2006 4:31:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335373862">message detail</a>
 | #205</td></tr>
<tr class="even"><td>
Yeah, I have recieved Peach/Daisy, Jo/Cortana, and Terra/Kerrigan for Guest writers. Thanks!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Jill vs. Sheena - Bracket: <b>Jill</b> - Vote: <b>Sheena</b> (5/6)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3657433" class="name">LusterSoldier</a> |
Posted 9/18/2006 7:20:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335416807">message detail</a>
 | #206</td></tr>
<tr class="even"><td>
I hope the Analysis for the next match goes up within the next 2 hours
or so because I want to know if there is SFF in the next match. I don't
know match about Princess Daisy but from what I know about her, I think
there may be SFF in the next match. This SFF (if there is any) will
influence my Oracle pick for tomorrow.<br>---<br><b>Luster Soldier</b> - Pwned by Repus_Yortsed<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=753228" class="name">Samurai7</a> |
Posted 9/18/2006 7:24:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335417906">message detail</a>
 | #207</td></tr>
<tr class="even"><td>
<i>I hope the Analysis for the next match goes up within the next 2
hours or so because I want to know if there is SFF in the next match. I
don't know match about Princess Daisy but from what I know about her, I
think there may be SFF in the next match. This SFF (if there is any)
will influence my Oracle pick for tomorrow.</i><br><br>XD!!!!!!!!!!!!!<br>---<br>It's a sad fact that you had to derail this topic because you are afraid of the power of the PS3 -- cade
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3657433" class="name">LusterSoldier</a> |
Posted 9/18/2006 7:28:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335419031">message detail</a>
 | #208</td></tr>
<tr class="even"><td>
Don't XD me.<br>---<br><b>Luster Soldier</b> - Pwned by Repus_Yortsed<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=731135" class="name">WiggumFan267</a> |
Posted 9/18/2006 8:21:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335433605">message detail</a>
 | #209</td></tr>
<tr class="even"><td>
I think I got this! =)<br><br>Cmon, Jilly baby, level out!<br><br><br>---<br>Score: <b>5</b>/6. Pick: <b>Jill</b> &gt; Sheena. Vote: <i>Sheena</i>. <br>Happily married to Alanna82 on VDay 2005
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/18/2006 8:37:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335438553">message detail</a>
 | #210</td></tr>
<tr class="even"><td>
XD Luster<br><br>They're like the same character, of course there's gonna be SFF.<br>---<br>CB06 - Score: <b>6/6 </b>Rank: <b>Tied - 1st </b>Yesterday's Pick:<b> The Boss</b> <br>Today's Pick: <b>Jill Valentine</b> Tomorrow's Pick: <b>Princess Peach</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/18/2006 8:41:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335439987">message detail</a>
 | #211</td></tr>
<tr class="even"><td>
<b>Limit Division:</b> <i>Round 1 - Match 8</i> &#8211; (2)Princess Peach vs. (7)Princess Daisy <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Peach</b><br>Game/Series Known From: Super Mario<br><br>Princess of the Mushroom Kingdom<br><br><b>Daisy</b><br>Game/Series Known From: Super Mario<br><br>Princess of&#8230;whatever.<br><br>Is this match supposed to be funny? Two Princesses from the Mario-verse facing off in Round 1 is supposed to make me chuckle?<br><br>I
am not amused! This match will only show that Peach with blow the hell
out of Daisy because of SFF of insane proportions. Oh well, at least
Peach will get exposed soon, but Daisy is going to end up looking so
horrible in the Stats. Now THAT&#8217;S going to be funny.<br><br>Oh, and I&#8217;m sorry in advance for what you are now about to read below. I swear, we&#8217;ll be back to normal by the next match.<br><br><b>Moltar&#8217;s Bracket Says:</b> Peach will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Peach: 81% - Daisy: 19%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br><br>LOOK
AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT
MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY
ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~ LOOK AT MY ASS! ~*ST*~<br><br><a class="linkification-ext" href="http://peachthong.ytmnsfw.com/" title="Linkification: http://peachthong.ytmnsfw.com/">http://peachthong.ytmnsfw.com/</a><br><br>Prediction: Peach with 99.99%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>&#8230; <br><br>Daisy makes me want to vomit. <br><br><b>Aitch Emm&#8217;s Bracket:</b>  Princess Peach<br><br><b>Aitch Emm&#8217;s Prediction:</b> Princess Peach &#8211; 80% ; Princess Daisy &#8211; 20%<br><br><b>Aitch Emm&#8217;s Vote:</b> Princess Peach<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>After
Samus laid an egg against Nidoran F, this match is the front runner for
the title of "Biggest Contest Blowout." Aside from REALLY preferring
Daisy in the Mario sports games and/or flat-out despising Peach, there
really isn't much reason for anyone to actually vote for Princess
Daisy. Peach is infinitely more prominent in the Nintendo universe, has
been in dozens more games, and is playable in Super Smash Bros. Melee.<br><br>I'm
very skeptical in the ability of not-so-powerful characters (in this
case, Peach) being able to completely decimate anything, so I doubt
this will end up as an all-time classic blowout. Still, it should be
very ugly.<br><br>My prediction: Princess Peach def. Princess Daisy (81-19)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/18/2006 8:42:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335440145">message detail</a>
 | #212</td></tr>
<tr class="even"><td>
<b>Lopen&#8217;s Analysis</b><br> <br>This match is evidence of Sub-Zero's corrupting presence right here. You remember it, right? This is the infamous <i>Mirror Match</i>
of Mortal Kombat fame! Yeah, that's right&#8230; I'm implying Daisy is a
Peach palette swap. What are you gonna do about it? Well, Daisy does
say "Hi I'm Daisy", and that deserves some merit. <i>Way</i> better than <i>any</i> of Peach's catchphrases. "Yeah, Peachie's got it?" Give me a <i>break</i>. What's Peachie got? An ass kicking waiting for her in the next round? You damn skippy.<br><br>That's it. That's all I got for this one.<br><br><b>Lopen's Prediction:</b> Peach with 78.05%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br>Princess Peach<br><br>lol N/A<br><br>Princess
Peach Toadstool. I know her, you know her, anyone who's played a dang
Mario game knows why they're doing it -- to save the Princess! Aside
from that she's had great roles in the Mario RPGs, SSBM, and even her
own game, Super Princess Peach! She's got a wide range and is one of
the most...unpredictable...yeah...let's move on to the REAL SHOW!<br><br>Princess Daisy<br> <br>lol N/A<br><br>The one, <i>the only</i>, <b>PRINCESS DAISY OF SARASALAND</b>
is making her glorious debut in the GameFAQs contests! One may recall
her stupendous debut in Mario's first true foray into adventuring on
the Game Boy (*the* most popular system of all time), Super Mario Land!
Monsters would pose as the fair Princess while the alien Tatanga
attempted to wed her, yet it was Mario's duty to save her...but why?
It's not like he had any obligation to her, unlike the Princess of his
own kingdom...that's right, unlike all the times he saved Peach, Daisy
was done out of Mario's own choice. Heck, I'm convinced Daisy only let
herself get captured in the first place just to that end! Of course,
Daisy being the magnanimous girl she is, had to let Mario go in order
to ensure peace and prosperity between the Mushroom Kingdom and
Sarasaland. Toadstool was always known to be a bit of a jealous prude,
after all.<br><br>But ya can't keep a good girl down forever, and
sooner than you'd know it Daisy was back on the scene in Mario Tennis
for the N64, a game that allowed her to show off her athetic prowess
against her softer counterpart. With her outgoing, energetic nature and
her tomboyish attitude, Daisy won the hearts and minds of those who had
been bored with the Plain Jane "appeal" of Peach. Of course she would
still have to treat Mario as hands off -- but hey, he always did say he
had a brother...<br><br>The sports, and the parties that followed
weren't enough for Daisy either. Then there was Super Smash Brothers
Melee, where despite Peach's attempts to upstage her Daisy was able to
sneak her way in a manner that would make Solid Snake jealous (and
she'll get the chance to prove it in Brawl!). Perhaps a mere palette
swap to the untrained eye, but the imperceptible differences in said
swap are enough to make Daisy the most superior fighter around. Who
expects the girl in yellow to pack such a wallop? And is it me, or does
she get a higher rate of item pulls than Peach does...? &lt;_&lt;<br><br>And
then Nintendo decided to screw her. And no, not in the visually obscene
manner that internet artists had done much earlier. But they decided to
make her *less* appealing -- because people just <i>couldn't</i>
prefer a female character to plain old Peach, could they? She was the
chosen one, Daisy was like the Darth Maul that got in the way with her
surprising amount of coolness and potential. So, like, Darth Maul, they
decided to ruin her as best they could. They turned her skin from tan
to a chalk pale color, gave her comically large eyes, a bad perm, and
then proceeded to chop away at her beautiful figure until she became
just potbellied enough for Peach to get away with her traditional look.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/18/2006 8:42:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335440319">message detail</a>
 | #213</td></tr>
<tr class="even"><td>A normal woman would have been crushed. But did
that stop Daisy? HELL NO, she redoubled her efforts in Mario Kart:
Double Dash -- truly her finest hour. With the help of such cheerful
cries as seen in daisy.ytmnd.com Daisy was able to make sure that she
was not forgotten, while happily introducing herself to the people that
she met and making sure that the races would be a pleasureable time for
all.<br><br>Everything she did, she did for her country. She sacrificed her life and honor for her native land. She was a real hero.<br><br>*sheds a tear*<br><br>She was a <i>true</i> patriot.<br><br>*salutes*<br><br><i>Notable Releases Since Last Appearance</i><br><br>Princess Peach: Super Mario Bros. 2 (NES), Super Mario RPG (SNES), Super Princess Peach (DS)<br>Princess Daisy: Super Mario Land (GB), Super Mario Bros. (Cinema) Mario Kart: Double Dash (GCN)<br><br><i>Upcoming Releases</i><br><br>Princess Peach: N/A<br>Princess Daisy: N/A<br><br><i>Analysis</i><br><br>HI I'M DAISY<br>HI I'M DAISY<br>HI I'M DAISY<br>HI I'M DAISY<br>HI I'M DAISY<br>HI I'M DAISY<br>HI I'M DAISY<br>HI I'M DAISY<br>HI I'M DAISY<br>HI I'M DAISY<br>HI I'M DAISY<br>HI I'M DAISY<br>HI I'M DAISY<br>HI I'M DAISY<br>HI I'M DAISY<br>HI I'M DAISY<br>HI I'M DAISY<br>HI I'M DAISY<br><br>Karma Hunter's Vote: <b>HI I'M DAISY</b><br><br><b>Karma Hunter's Krazy Prediction: Princess Peach with 88.51%.</b><br> <br>I hate Nintendo SFF. ='(<br><br>Upset Potential: <b><i>HI I'M DAISY</i></b><br> <br><br><br><b>Guest&#8217;s Analysis</b> - <i>Ed Bellis</i><br> <br>Many
a contest fan has waited for Peach to debut in the contest for quite
some time. After seeing how well practically every other Mario
character save Wario has done in these polls, Peach following suit
would make rational sense. Last year&#8217;s &#8220;Nintendo boost&#8221; and the release
of Peach&#8217;s own solo game, Super Princess Peach, have only added to this
speculation about Peach&#8217;s sleeper strength, and stats heads have
speculated that she could be anywhere as strong as Donkey Kong to as
weak as non-face CATS, and there are good reasons for both extremes:
yes, Peach is a Mario character, but she&#8217;s got a minimal fan following
of her own. I&#8217;d struggle with Peach/Wario to this day, even taking both
expected increases for Peach into consideration. <br><br>This lengthy
prologue is somewhat irrelevant for this match, though. Peach lucks out
in her first match and goes up against quite possibly the only
character from the Mario series she&#8217;d be <i>guaranteed</i> to SFF, Princess Daisy, a character virtually <i>designed</i>
to serve as a counterpoint to Peach in the &#8220;party&#8221; games. I have little
faith in Peach to do much damage in this thing and I wouldn&#8217;t surprised
at all if she lost to Jill, but this match is a complete guarantee for
her. Hell, if this got one of the highest prediction percentages of the
whole contest it wouldn&#8217;t shock me. Peach will take this with relative
ease. <br><br>&#8230;or will she? <br><br>There&#8217;s a reason I wanted this
match for the Analysis Crew &#8211; I&#8217;ve got a reputation as making stupid
calls that never pan out and I&#8217;d like to abuse that mentality here.
You&#8217;d have to be more ditzy than Peach herself to <i>not</i> have her
winning, but here&#8217;s my devil&#8217;s advocate question: if Mario fans show up
to vote in a poll with Mario characters, who exactly is going to vote
for Peach, especially on a site like this, with such a heavily male
userbase? <br><br>LET&#8217;S TAKE AT THIS POLL SHALL WE <br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2328" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2328">http://www.gamefaqs.com/poll/index.html?poll=2328</a> <br><br>Dead
last for Peach, of course, but no Daisy. If Daisy was here, though&#8230;
would she place higher than Peach? My thoughts are yes, and here&#8217;s why
&#8211; Daisy&#8217;s image is ever so slightly &#8220;cooler&#8221; than Peach. She was
created to be a more tomboyish (and, some fans might say, attractive)
version of Peach, and while she might not have a substantial fanbase on
her own, she&#8217;s likely got enough of a distinction to siphon votes from
Peach.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/18/2006 8:43:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335440492">message detail</a>
 | #214</td></tr>
<tr class="even"><td>Point is, I&#8217;m calling for Peach falling flat on
her face in this match and completely dropping the ball&#8230; at least here.
This isn&#8217;t my Oracle pick, nor is it what I&#8217;m writing in my own
analysis topic, but if this highly implausible result happens, for once
in my life I want to be on the right end. =P <br><br><b>Prediction: Peach with 60.00%.</b><br><br> <br> <br>Summary: ....I don't even know what to say. Peach wins?
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=2568612" class="name">Draco1214</a> |
Posted 9/18/2006 8:45:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335441148">message detail</a>
 | #215</td></tr>
<tr class="even"><td>
&gt;&gt;&gt;&gt;&gt;&gt;XD<br><br>Best analysis ever. Especially Ulti's and KH's.<br>---<br>Character Battle V Score - <i>7/7 points</i><br>Current Prediction - <b>Princess Peach</b> vs. Princess Daisy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=863018" class="name">Janus5000</a> |
Posted 9/18/2006 8:45:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335441155">message detail</a>
 | #216</td></tr>
<tr class="even"><td>
Ulti or Ed better win. &gt;_&gt;<br>---<br>"Those who cast the vote decide nothing. Those who count the vote decide everything."<br><a class="linkification-ext" href="http://www.scorehero.com/scores.php?user=2916&amp;diff=4" title="Linkification: http://www.scorehero.com/scores.php?user=2916&amp;diff=4">http://www.scorehero.com/scores.php?user=2916&amp;diff=4</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=753228" class="name">Samurai7</a> |
Posted 9/18/2006 8:47:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335441777">message detail</a>
 | #217</td></tr>
<tr class="even"><td>
Hi, I'm Daisy<br>---<br>It's a sad fact that you had to derail this topic because you are afraid of the power of the PS3 -- cade
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/18/2006 8:47:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335441869">message detail</a>
 | #218</td></tr>
<tr class="even"><td>
I meant to lower that damn 88% pick... =( And Ulti's still got me outdone!<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/18/2006 8:50:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335442687">message detail</a>
 | #219</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>THE NEW YORK METS ARE THE
2006 NL EAST CHAMPIONS! Wow, what a game. 2 home runs for Valentin,
Trachsel shuts 'em down, then Mota, Heilman, and Wagner are completely
dominant out of the bullpen. This is awesome.<br><br>Oh wait, I'm supposed to be analyzing the <i>match</i>?  Bah, who cares.  This is the ultimate SFF match, what is there to analyze?<br><br>My Vote: Peach<br>My Bracket: Peach<br>My Prediction: Peach with 72%<br>All I Care About: LETS GO METS!!!!<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br>**Character Battle V PRINTABLE BRACKET** See quote for link.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/18/2006 8:53:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335443396">message detail</a>
 | #220</td></tr>
<tr class="even"><td>
....Dear God. It's as if the Devil reincarnated itself in the form of
Ulti- and, to a lesser extent, KH- to make the analysis crew look
positively insane.<br><br>I've been here for four years, and I've never seen anything like it.  Did you guys drink or something?<br><br>Oh well...back to normal tomorrow...I hope.  &gt;_&gt;<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/18/2006 8:58:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335444802">message detail</a>
 | #221</td></tr>
<tr class="even"><td>
Wow, Ulti, where the hell did that come from?<br><br>And
honestly, I would not be surprised if Daisy performed semi-decently.
The SFF is so severe, that I think people won't know who to vote for,
so they'll both split the votes.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br>**Character Battle V PRINTABLE BRACKET** See quote for link.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=264094" class="name">Heroic Mario</a> |
Posted 9/18/2006 9:05:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335446931">message detail</a>
 | #222</td></tr>
<tr class="even"><td>
...Wow. &lt;&lt;<br><br>---<br><i>...a lone figure shining in the toxic shadows. She comes dressed for war, and her wrath is terrible.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=1313568" class="name">Jmast7</a> |
Posted 9/18/2006 9:08:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335447692">message detail</a>
 | #223</td></tr>
<tr class="even"><td>
DpObliVion: BEST. ANALYSIS. EVAR!<br><br>I'm so happy right now! Let's Go Mets! =)<br>---<br>"I've
tried 'em all, I really have, and the only church that truly feeds the
soul, day in, day out, is the Church of Baseball." - Annie Savoy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3251974" class="name">trannyscience</a> |
Posted 9/18/2006 9:10:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335448457">message detail</a>
 | #224</td></tr>
<tr class="even"><td>
today is the best analysis ever.<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3623587" class="name">Gaddswell</a> |
Posted 9/18/2006 9:45:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335457896">message detail</a>
 | #225</td></tr>
<tr class="even"><td>
Wow, such nice, short, simple analysis that easily get's the point across. Great Job Crew!<br><br>BTW...<br>I'm just repeating this here for those that missed it earlier.<br>Ulti's serious prediction is 75.01%. It's back on page 20.<br>---<br>By the time we localize the programs, kids don&#8217;t even know they&#8217;re from Japan any more. - 4Kids CEO Al Kahn<br><b>Vote Right! Phoenix Wright!</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 9/18/2006 11:16:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335478819">message detail</a>
 | #226</td></tr>
<tr class="even"><td>
HI I'M DAISY<br>---<br>This was Ed Bellis, servant to the mighty Guru <b>Z1mZum</b>. Congrats, buddy!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=731135" class="name">WiggumFan267</a> |
Posted 9/18/2006 11:41:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335482983">message detail</a>
 | #227</td></tr>
<tr class="even"><td>
Oh wooooo, did I call that 62% or what? ^_^<br><br><br>---<br>Score: <b>5</b>/6. Pick: <b>Jill</b> &gt; Sheena. Vote: <i>Sheena</i>. <br>Happily married to Alanna82 on VDay 2005
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=2665492" class="name">XIII_rocks</a> |
Posted 9/19/2006 2:15:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335560644">message detail</a>
 | #228</td></tr>
<tr class="even"><td>
<b>XD</b><br><br><i>Oh, and I&#8217;m sorry in advance for what you are now about to read below. I swear, we&#8217;ll be back to normal by the next match.</i><br><br>XD @ this especially<br><br>That
was the second-best analysis ever! The first is that one last year of
Moltar's (I think) where there's a bunch of snubs and Ocelot puts on
the Master Hand and becomes <b>OCELOT REBORN</b> and stuff.<br><br>Man, I want to read that again. Got a link to an archive of past analyses?<br>---<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738</a> Sign plz<br>Hi-ho, Hi-ho, <b>Z1m Zum, Z1m Zum</b>...our guru champ.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/19/2006 2:16:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335560867">message detail</a>
 | #229</td></tr>
<tr class="even"><td>
<a class="linkification-ext" href="http://www.gamefaqscontests.com/drupal/node/9" title="Linkification: http://www.gamefaqscontests.com/drupal/node/9">http://www.gamefaqscontests.com/drupal/node/9</a><br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 9/19/2006 2:20:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335561572">message detail</a>
 | #230</td></tr>
<tr class="even"><td>
THIS POINT IS TOTALLY MINE<br><br>DAISY IS JUST PLAYING AROUND<br><br>WATCH OUT <i>ANALYSIS CREW</i><br>---<br>This was Ed Bellis.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/19/2006 2:21:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335561762">message detail</a>
 | #231</td></tr>
<tr class="even"><td>
I overshot again. -_- I need to start lowering all my predictions by three percentage points.<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/19/2006 4:43:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335593050">message detail</a>
 | #232</td></tr>
<tr class="even"><td>
Jill Valentine...........................62.03% 70699<br>Sheena Fujibayashi.............37.97% 43275<br>TOTAL VOTES...............................113974<br><br>85.76% of the brackets predicted this match correctly.<br><br>Wow,
in a match that was near 66% for Jill at one point, Sheena managed to
cut it all the way down to a 62-38 loss. That's pretty good, seeing as
Lloyd would only do a little better using the stats. The match was
obvious to bracketmakers though...<br><br>Today, Peach is beating Daisy. DIDN'T SEE THAT COMING NOPE.<br><br>Ulti - 3<br>Lopen - 2<br>Guest - 1<br>HM - 1<br>Moltar - 0<br>Yoblazer - 0<br>KH - 0<br><br>First it looked to be Ulti's, then KH's, then mine, but it ends up with Wigs (aka the Guest). Finally, Guest is on the board!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Peach vs. Daisy- Bracket: <b>Peach</b> - Vote: <b>Peach</b> (6/7)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 9/19/2006 4:47:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335594060">message detail</a>
 | #233</td></tr>
<tr class="even"><td>
...upon closer inspection, how did I end up with the most serious analysis, prediction aside? o_0<br>---<br>This was Ed Bellis, servant to the mighty Guru <b>Z1mZum</b>. Congrats, buddy!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=264094" class="name">Heroic Mario</a> |
Posted 9/19/2006 4:48:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335594264">message detail</a>
 | #234</td></tr>
<tr class="even"><td>
Damn Moltar and 'blazer. ;_;<br><br>---<br><i>...a lone figure shining in the toxic shadows. She comes dressed for war, and her wrath is terrible.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/19/2006 7:58:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335642020">message detail</a>
 | #235</td></tr>
<tr class="even"><td>
You know, Yo's original pick for the match was Peach with 83%. Have fun kicking yourself!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Peach vs. Daisy- Bracket: <b>Peach</b> - Vote: <b>Peach</b> (6/7)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/19/2006 8:00:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335642556">message detail</a>
 | #236</td></tr>
<tr class="even"><td>
Yay Wiggles!<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/19/2006 8:00:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335642626">message detail</a>
 | #237</td></tr>
<tr class="even"><td>
<b>Triforce Division:</b> <i>Round 1 - Match 9</i> &#8211; (1)Zelda vs. (8)Carmen Sandiego <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Zelda</b><br>Game/Series Known From: Legend of Zelda<br>Extrapolated Rank in 2003: 19th (30.29%)<br>Extrapolated Rank in 2005 14th (30.89%)<br>Seed in 2003: 10<br>Seed in 2005: 5<br>Lost in 2003 to Mega Man in Round 2<br>Lost in 2005 to Solid Snake in Round 2<br><br>Zelda is back, and looking to be stronger than ever compared to the other females.<br><br><b>Carmen</b><br>Game/Series Known From: Where in the World is Carmen Sandiego?<br><br>Looks like we found where she went&#8230;<br><br>Rally
characters are fun! Either someone strong gets in and becomes a Contest
staple, or we get a weakling who&#8217;s only purpose is to be blown out.
Here we have a case of the latter, as Carmen Sandiego, rallied in by
the board, takes on Zelda. The same Zelda that could muster up 46% on
Solid Snake. Carmen may have been interesting somewhere else in the
bracket, but here? Nope&#8230;<br><br>Need I say more? Zelda wins in blowout fashion. Oh, and remember when I said we&#8217;d be back to normal today?<br><br>&#8230;<br><br>I lied.<br><br><b>Moltar&#8217;s Bracket Says:</b> Zelda will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Zelda: 78% - Carmen: 22%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>I'm
not even going to dignify this with a response. Again. The fodder on
the female side of this bracket makes me long for Shadow Hearts and
Tanner coming back.<br><br>Prediction: Zelda with 82.56%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>Where on earth is Carmen Sandiego?! <br><br>Oh yeah -- <i>getting her ass beat down by the Princess of Hyrule!</i> <br><br>I&#8217;m not entirely <i>how</i> or even <i>why</i>
Carmen Sandiego made the bracket, but she was able to do so.
Unfortunately for her, she&#8217;s up against the second strongest female in
the bracket &#8211; Zelda (Yes, that&#8217;s a bold prediction<i>!!</i>). A lot of Carmen&#8217;s popularity is likely to come <i>outside</i>
of what she has done in videogames, so it&#8217;ll be interesting to see how
she performs. I&#8217;m not expecting much out of her at all though. This
match should be pure domination in favor of Zelda. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Zelda<br><br><b>Aitch Emm&#8217;s Prediction:</b> Zelda &#8211; 80.5% ; Carmen Sandiego &#8211; 19.5%<br><br><b>Aitch Emm&#8217;s Vote:</b> Zelda<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>There's
so much lost potential here. Take a quick look at all the crap we have
to sift through for the female half of the bracket. Now think about how
many of the voters will instantly recognize and make some sort of
connection with Carmen Sandiego. Honestly, the sticky fingered filcher
may end up completely bombing and affirming the claim that having
recognition outside the gaming spectrum amounts to a hill of beans in
these contests. That's entirely possible. Even still, you have to
realize that almost <i>any</i> other opponent for Carmen would have
resulted in at least a somewhat debtable match. Even Yuna. Even
Chun-Li. Even Peach. Paired up against 27 of the 31 other women in the
field, Carmen would have drawn <i>some</i> debate. Unforunately, she
drew one of the other four. Sad as it may be, one of the biggest wild
cards in contest history has been pissed away. No one is really to
blame, but it sure is fun to imagine the possibilities.<br><br>As for
the actual match, this one is no contest. Trying to pin-point Carmen's
value may be a ***** and a half, but that won't change the end result
at all. Zelda will easily win as she beats a path toward THE match of
the female half against Aeris.<br><br>My prediction: Zelda def. Carmen Sandiego (75-25)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/19/2006 8:01:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335642856">message detail</a>
 | #238</td></tr>
<tr class="even"><td>
<b>Lopen&#8217;s Analysis</b><br> <br>The conundrum of this match for Zelda is that she has to <i>find</i> Carmen to defeat her. Do you think the great Carmen Sandiego is confined to her tiny little <i>Hyrule</i> when fleeing the law that is Zelda? Ha ha ha ha&#8230; yo yo&#8230; <i>no no</i>. Now Zelda may have her little <i>Triforce of Wisdom</i>,
but that "Wisdom" does not contain knowledge of Earth's Geography, I
promise you that. And this assumes Carmen Sandiego hasn't already taken
Zelda's precious Loot (that's what Carmen calls the Triforce) already.<br><br>So
what this boils down to is Zelda being confused as hell as to Carmen's
true location, and Carmen laughing it up while fondling her newly
procured Loot. Even the most casual of bracket makers could tell you
that this is what they were thinking when they filled in the bracket.<br><br>And clearly, that makes the result of this match&#8230;<br><br><b>Lopen's Prediction:</b> Zelda with 82.58%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br>Zelda<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 19th Place [30.29%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 14th Place [30.89%]<br><br>Zelda's
back, and she's ready to show us all again exactly how much being a
side character in a series named after you really counts for
popularity. Oh, and there's also that Sheik/SSBM thing, but whatever. =/<br><br>Zelda
has a free pass to the Elite Eight this year, and *most* consider her
to have a free pass to the Final Four as well...though there's a
certain flower girl that might have something to say about that. More
on that in the future! For now, she's got one of the most interesting
opponents to contend with in this match --<br><br>Carmen Sandiego<br> <br>lol N/A<br><br>Tell
me, where in the world is Carmen Sandiego? Why, the GameFAQs Contests,
of course -- and it's a damn good place to hide for her. The #1 topic
on these boards concerning Miss Sandiego have been topics expressing
confusion over her eligibility for this contest. Yes, Carmen was in a
video game before she was in the cartoon series, or the game show, or
anything else which she is predominantly known for. Which makes her one
of the biggest oddballs this contest has yet to see -- how well will a
character known for things *other* than videogaming stand up in a
setting like this?<br><br>Her range is huge, and the one thing I wish
is that we could have seen her in a more interesting matchup. As it
stands, this performance against Zelda will help to determine if the
board will rally for her in future contests or drop her like a sack of
potatoes (origin: Andes Mountains)<br><br><i>Notable Releases Since Last Appearance</i><br><br>Zelda: N/A<br>Carmen Sandiego: Where in the World is Carmen Sandiego? (Multi), Carmen Sandiego and the Stolen Drums (Multi)<br><br><i>Upcoming Releases</i><br><br>Zelda: The Legend of Zelda: Twilight Princess (WII)<br>Carmen Sandiego: N/A<br><br>I'm tempted to put the theme song here. &lt;_&lt;<br><br>This match is tough to call percentages on...Zelda could end up in the mid-80s, but that's what she's expected to get on <i>Yuri.</i> Forgive me if I think Carmen could do a little better...total guess on this one.<br><br>Karma Hunter's Vote: Carmen Sandiego. I mean, Zelda's <i>decent,</i> but c'mon...it's CARMEN SANDIEGO!<br><br><b>Karma Hunter's Krazy Prediction: Zelda with 73.5%.</b><br><br>I'm
going really low with this one...I think Carmen can make herself into
some semi-notable fodder. Like I said, I'm tired of overestimating
these percentages! &gt;_&lt;<br><br>Upset Potential: 0.1%
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/19/2006 8:02:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335643028">message detail</a>
 | #239</td></tr>
<tr class="even"><td>
Well she sneaks around the world from Kiev to Carolina,<br>She's a sticky-fingered filcher from Berlin down to Belize,<br>She'll take you for a ride on a slow boat to China,<br>Tell me, where in the world is Carmen Sandiego?<br><br>Steal their Seoul in South Korea, make Antarctica cry Uncle,<br>From the Red Sea to Greenland they'll be singing the blues,<br>Well they never Arkansas her steal the Mekong from the jungle,<br>Tell me, where in the world is Carmen Sandiego?<br><br>She go from Nashville to Norway, Bonaire to Zimbabwe,<br>Chicago to Czechoslovakia and back!<br><br>Well she'll ransack Pakistan and run a scam in Scandinavia,<br>Then she'll stick 'em up Down Under and go pick-pocket Perth,<br>She put the Miss in misdemeanor when she stole the beans from Lima,<br>Tell me where in the world is Carmen Sandiego?<br>Oh, tell me, where in the world is... Oh tell me where can she be!<br><br>Ooh, Botswana to Thailand, Milan via Amsterdam,<br>Mali to Bali, Ohio, Oahu...!<br><br>Well she glides around the globe and she'll flimflam every nation,<br>She's a double-dealing diva with a taste for thievery,<br>Her itinerary's loaded up with moving violations,<br>Tell me, where in the world is Carmen Sandiego?<br><br>...couldn't resist, mate.<br><br>Upset Prediction: Carmen Sandiego with 100%.<br> <br><br><br><b>Guest&#8217;s Analysis</b> - <i>HaRRich</i><br><br>Predicted winner:  Zelda<br><br>Since
I'll just end up bombing on the joke, I'll handle this analysis
professionally -- you can make your own jokes. Sorry gang...<br><br>...but
let's look at the facts here: LoZ just got done proving its incredible
stranglehold here by pulling the board-upset on Final Fantasy -- hell,
statistically, there are ONLY SIX SERIES that LoZ couldn't <i>TRIPLE</i>,
and that's if you ignore any SFF that LoZ could dish out to Mega Man,
SSB, and SMB (not that LoZ tripling SSB/SMB that bad would happen, but
SFF would happen for sure). The respect her series garners cannot ever
be in question, and her name is in the title...<br><br>...then, if you
want to delve deeper and judge each game one by one (because we'd hate
to mess up on this match because series =/= games -- look at GTA for
proof!), we can go elsewhere. With the Game Contest, LoZ:OoT could beat
any game not named FF7 (and it arguably could win that battle
now)...and that game is arguably the best game for her popularity as
well. Throw in LoZ:LttP being around three hundred votes short of being
the contest runner-up, the original LoZ being the second-strongest NES
game, LoZ:WW statistically being so close to SSBM in the 128-Division,
LoZ:MM having some of the most loyal fans I've seen, and the handheld
fanbase simply cannot hurt; I hear almost nothing but good things about
the ones I hear about...<br><br>...say your typical contest format
isn't enough to convince you about each game's power, however. Much to
the pleasure of EC I'm sure, let's glance at the Top 100 List. You'll
see LoZ:OoT and LoZ:LttP be in the <i>top five</i>, not to mention the
other three in the top fifty as well. That means, in a format without
anti-votes in a free-for-all situation, LoZ games still make up a <i>tenth</i> of the top fifty games.  Their fans are loyal and numerous, as you can see...<br><br>...let's
go even further though, and touch base on SSBM for a minute. The SSB
series is firmly the fourth biggest series here, and -- though she
missed out on the original -- she has made a major impact in the much
bigger SSBM. Zelda/Sheik is not only a top-tier fighter for experts,
but she is also used often by the less-professional gamers as
well...that's what happens when you get lightning-fast speed and the
ability to alternate fighters, not to mention coming from such a huge
game/series...
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/19/2006 8:03:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335643157">message detail</a>
 | #240</td></tr>
<tr class="even"><td>...despite all this though, this is still
ultimately a character battle, so let's get to the meat of the
situation: Zelda is a strong strong woman in a GameFAQs contest
situation. While she had a "tough" time with Lara in 2k3 considering
how she performed in 2k4, she faired well for herself against Mega
Man...but her stand-out year was last year. She and Vivi were expected
to be dead-even, then she goes on to get 59.5% before getting 45.5% on
Solid Snake in his best year yet. Solid's let weaker characters get
closer (hello, Frog), but he was in his prime last year and she still
got that much on him. Now that LoZ:TP is so close, perhaps hype will
feature her being even stronger than last year if you buy into hype.<br><br>Carmen Sandiego...has no such information to speak of.<br><br>However,
I think her ability to ride on her TV-popularity and edu-tainment is
enough to have some respectable strength. In fact, maybe enough to
challenge Zelda...ya know what, **** it, Carmen will probably have the
strength to get 52%-54% -- don't even think for a second I'm saying
that based off of joke-votes, either. I like to have fun just as much
as the next guy, but you can already see that I've kept from treating
this match like a joke at all, so everybody else will do the same. So
once people go to click the corresponding bubble to vote for her, like
so...<br><br>...what?  Where in the world.....?<br><br><br><br><b>BOARDAPELLA!</b><br><br>Well the bubble sneaks around the world from Kiev to Carolina,<br>It's a sticky-circled sphere from Phoenix down to Arabusa,<br>It'll take you for a browse on a slow load to China,<br>Tell me where in the world is the option to vote for Sandiego?<br><br>Steal their votes in Vietnam, make Zelda-barriers cry Uncle,<br>From CJayC to Lopen he'll be saying "you're gonna lose!",<br>Well they never Arkansas it steal Donkey Kong from the jungle,<br>Tell me where in the world is the option to vote for Sandiego?<br><br>It go from Link to Neo-Tanner, Claire to Peach and Yoshi,<br>Crono's sword to Ultima materia and back!<br><br>Well it'll ransack Mega Man and run a scam in Vercetti/Kefka,<br>Then it'll stick 'em up Down Under and go pick-pocket another win from Crono,<br>It put the VOTE in VOTE OR DIE when it stole all his base from CATS each time-a,<br>Tell me where in the world is the option to vote for Sandiego?<br>Oh tell me where in the world is... Oh tell me where can it be?<br><br>Ooh, Sheena to Ganon, Joanna via three Valentines,<br>Amy to Resetti, Wario, Rikku...!<br><br>Well it sits around the world and it'll spimspam every forum,<br>It's a Siamese-option object but with only one choice;  what mystery,<br>Its bandwith's loaded up with nerds waiting for the Wii to hit every store-um,<br>Tell me where in the world is the option to vote for Sandiego?<br><br><br><br>...well, Carmen can't exactly win if you can't find the bubble, I suppose.<br><br><i><b>Zelda</b> wins with 78.12%</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/19/2006 8:03:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335643375">message detail</a>
 | #241</td></tr>
<tr class="even"><td>
Damn, HaRR outdid me by a mile and a half.<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3251974" class="name">trannyscience</a> |
Posted 9/19/2006 8:03:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335643390">message detail</a>
 | #242</td></tr>
<tr class="even"><td>
oh my god harrich<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3685859" class="name">PartOfYourWorld</a> |
Posted 9/19/2006 8:05:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335643700">message detail</a>
 | #243</td></tr>
<tr class="even"><td>
Was my e-mail sent too late, Moltar?
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/19/2006 8:05:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335643860">message detail</a>
 | #244</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis</i><br><br>I'd like to think Carmen
Sandiego could stand a chance, I really do. Yeah, Legend of Zelda is
the Best Series Ever here, but.....hasn't everyone in America grown up
with Carmen Sandiego in their lives? And who really cares about
Princess Zelda anyway, all her voters are just going to be LoZ votes.<br><br>But,
I guess I'll just accept Carmen Sandiego even being in the contest as
pretty sweet. As widely played as she is, she's still fodder to Zelda.<br><br>My vote: Carmen Sandiego!<br>My bracket: Princess Zelda<br>My prediction: Zelda with 82%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/19/2006 8:07:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335644172">message detail</a>
 | #245</td></tr>
<tr class="even"><td>
Whoa.....I would do anything to see it finish at 82.57%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/19/2006 8:07:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335644217">message detail</a>
 | #246</td></tr>
<tr class="even"><td>
<i>Hey Moltar, can you please change my Zelda pick to 79%? Thanks.</i><br><br>Oops, that's my bad for not checking my inbox before I posted them. Yeah, 79% is your official one now.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Peach vs. Daisy- Bracket: <b>Peach</b> - Vote: <b>Peach</b> (6/7)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/19/2006 8:09:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335644764">message detail</a>
 | #247</td></tr>
<tr class="even"><td>
Hah! Less competition for me when Carmen puts on her fantastic performance today!<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3708259" class="name">MastaHealer</a> |
Posted 9/19/2006 8:09:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335644854">message detail</a>
 | #248</td></tr>
<tr class="even"><td>
HaRR just won everything AND the kitchen sink.  Awesome!<br>---<br>*is <b>wavedash101</b>*<br>Satai gets Biggest Surprise EVER Award! ^_^
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/19/2006 8:10:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335645036">message detail</a>
 | #249</td></tr>
<tr class="even"><td>
Oh, and amen, yo.  I was so pissed when I saw Carmen Sandiego vs. Zelda in the bracket.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=1883202" class="name">warning_crazy</a> |
Posted 9/19/2006 8:11:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335645251">message detail</a>
 | #250</td></tr>
<tr class="even"><td>
What's you email, I have the analysis done. I'm too lazy to look it up, despite the fact it's proablly on the first page.<br>---<br>"I just saw my best friend's dad's wang... what should I do?" GrapefruitKing
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=3">4</a></li>
<li>5</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=9">10</a></li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage5_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30499515&amp;page=4" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
<div id="copyright">
	<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
	<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
	<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
</div>
<script src="genmessage5_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</div></body></html>