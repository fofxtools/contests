<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	



<title>GameFAQs - GameFAQs Contests Message Board</title><meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage7_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage7_files/nogs.css"></head><body linkifytime="250" linkified="3" linkifying="false"><div id="container">
	<div id="gne_nav">
		<img src="genmessage7_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/events/x06/">X06</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage7_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30499515%26page%3D6"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage7_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage7_files/advertisement.gif" alt="advertisement" height="10" width="120"></div>
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage7_files/f.xhtml" marginwidth="0" marginheight="0" hspace="0" vspace="0" allowtransparency="true" frameborder="0" height="90" scrolling="no" width="728">
&lt;script language=javascript&gt;&lt;!-- randNum = ((new
Date()).getTime() % 2147483648) + Math.random(); document.write( "&lt;a
href='http://a.tribalfusion.com/i.click?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID="
+ randNum + "' target=_blank&gt;" + "&lt;img
src='http://a.tribalfusion.com/i.ad?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID="
+ randNum + "'" + " width=728 height=90 border=0 alt='Click
Here'&gt;&lt;/a&gt;"); // --&gt;&lt;/script&gt; &lt;noscript&gt; &lt;a
href="http://a.tribalfusion.com/i.click?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID=1576037958"
target=_blank&gt; &lt;img
src="http://a.tribalfusion.com/i.ad?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID=1576037958"
width=728 height=90 border=0 alt="Click Here"&gt;&lt;/a&gt;
&lt;/noscript&gt; </iframe><img src="genmessage7_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;page=6">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30499515" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=5">Previous Page</a> |
Page 7 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=7">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 9/21/2006 9:41:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336079274">message detail</a>
 | #301</td></tr>
<tr class="even"><td>
I'm rooting for you, KH!<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i><br>Michelle.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=640243" class="name">Big Bob</a> |
Posted 9/21/2006 9:43:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336079756">message detail</a>
 | #302</td></tr>
<tr class="even"><td>
I KNEW that picking Amy was completely loony and held no ground
whatsoever, but goddamn if this upset happens will I be glad I did.<br><br>I can't help it.  I saw that match and thought "I have GOT to go for the upset here."  And I did.  And I even put it in my sig.<br><br>C'mon furries, don't fail me now...<br>---<br>September 22nd!  Amy Rose &gt; KOS-MOS<br>Currently Playing: Disgaea: Hour of Darkness, God of War
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=829368" class="name">Tai</a> |
Posted 9/21/2006 9:54:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336082362">message detail</a>
 | #303</td></tr>
<tr class="even"><td>
Personally, I think it's sad Amy was able to get in this conest and not Tails nor Knuckles. <br>---<br>I lost my sig. Can you find it for me? :(
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/21/2006 10:12:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336086492">message detail</a>
 | #304</td></tr>
<tr class="even"><td>
Much less competition for a spot for her.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/21/2006 11:26:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336100754">message detail</a>
 | #305</td></tr>
<tr class="even"><td>
Lookin good for yo so far.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/22/2006 1:21:05 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336115281">message detail</a>
 | #306</td></tr>
<tr class="even"><td>
Samus vs. Nidoran F<br>+7 Ulti<br>+6 KH<br>+5 Yo<br>+4 Guest<br>+3 Lo<br>+2 Mo<br>+1 HM <br><br>Ada Wong vs. Jade<br>+7 HM<br>+6 Ulti<br>+5 Yo<br>+4 Guest<br>+3 KH<br>+2 Mo<br>+1 Lo<br><br>Rikku vs. Lenneth Valkyrie<br>+7 Lo<br>+6 HM<br>+6 Yo <br>+4 Ulti<br>+3 Mo<br>+2 KH<br>+1 Guest<br><br>Kairi vs. Claire Redfield<br>+7 Ulti<br>+6 HM<br>+5 Guest<br>+4 KH<br>-1 Mo<br>-2 Yo<br>-3 Lo<br><br>Tifa Lockheart vs. Ivy Valentine<br>+7 Lo<br>+6 KH<br>+5 Mo<br>+4 Guest<br>+3 Ulti<br>+2 Yo<br>+1 HM<br><br>The Boss vs. Celes Chere<br>+7 Ulti<br>+6 HM<br>+5 Mo (tie)<br>+5 Yo (tie)<br>+3 KH<br>+2 Lo<br>-1 Guest<br><br>Jill Valentine vs. Sheena Fujibayashi<br>+7 Guest<br>+6 Mo<br>+5 KH<br>+4 Ulti<br>+3 HM<br>+2 Yo<br>-1 Lo<br><br>Princess Peach vs. Princess Daisy <br>+7 Mo (tie)<br>+7 Yo (tie)<br>+5 HM<br>+4 Lo<br>+3 KH<br>+2 Ulti<br>+1 Guest<br><br>Zelda vs. Carmen Sandiego<br>+7 Lo<br>+6 Ulti<br>+5 HM<br>+4 Yo<br>+3 Guest<br>+2 Mo<br>+1 KH<br><br>Terra Branford vs. Sarah Kerrigan<br>+7 KH<br>+6 HM<br>+5 Ulti<br>+4 Guest<br>+3 Mo (tie)<br>+3 Yo (tie) <br>-1 Lo<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/22/2006 1:22:29 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336115412">message detail</a>
 | #307</td></tr>
<tr class="even"><td>
<b>The Rankings</b> (Through Terra vs. Kerrigan)<br>1. UltimaterializerX (51)<br>2. Heroic Mario (46)<br>3. Karma Hunter (40)<br>4. Yoblazer (37)<br>5. Master Moltar (34)<br>6. Board 8 (32)<br>7. Lopen (26)<br><br>Board
8 isn't doing too hot, but they're beating up Lopen and are within
striking distance of Moltar and me! Better watch out! Also, feel free
to check my math. I am far from infallible.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/22/2006 1:31:18 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336116348">message detail</a>
 | #308</td></tr>
<tr class="even"><td>
Bah, Guest being added into the mix gives Ulti and HM more breathing room than they should. I'm coming for you guys <i>!!</i><br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/22/2006 5:36:05 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336129336">message detail</a>
 | #309</td></tr>
<tr class="even"><td>
Amy's dead!  My bracket lives!<br><br>Now, to see how much Aeris wins by in our SFF match tomorrow...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3685859" class="name">PartOfYourWorld</a> |
Posted 9/22/2006 3:46:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336196816">message detail</a>
 | #310</td></tr>
<tr class="even"><td>
Amy Rose, you stupid *****.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/22/2006 4:33:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336207105">message detail</a>
 | #311</td></tr>
<tr class="even"><td>
Terra Branford........58.69% 58141<br>Sarah Kerrigan.......41.31% 40922<br>TOTAL VOTES.....................99063<br><br>56.5% of the brackets predicted this match correctly.<br><br>Go
Go X-Stats! They predicted this match very closely, as did many board
members. Seems Terra and Kerrigan haven't gotten much stronger since
2005. The casuals fell hard. Only 56 and a half got this right?<br><br>Today, KOS-MOS is putting up good numbers on Amy.<br><br>Lopen - 3<br>Ulti - 3<br>KH - 1<br>Moltar - 1<br>Yoblazer - 1<br>Guest (Wigs) - 1<br>HM - 1<br><br>KH gets his first point. About time, newbie!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>KOS-MOS vs. Amy - Bracket: <b>KOS-MOS</b> - Vote: <b>KOS-MOS</b> (9/10)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/22/2006 6:24:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336231550">message detail</a>
 | #312</td></tr>
<tr class="even"><td>
I'll newbie <i>you!</i><br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/22/2006 7:43:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336248791">message detail</a>
 | #313</td></tr>
<tr class="even"><td>
40%? Wow. I guess the casuals did ennie-meenie-minie-moe on that last
one. I mean, how many people actually know who Sarah Kerrigan and Terra
Banford are?<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/22/2006 8:02:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336252905">message detail</a>
 | #314</td></tr>
<tr class="even"><td>
<b>Triforce Division:</b> <i>Round 1 - Match 12</i> &#8211; (2)Aeris Gainsborough vs. (7)Marle <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Aeris</b><br>Game/Series Known From: Final Fantasy<br>Extrapolated Rank in 2002: 12th  (30.62%)<br>Extrapolated Rank in 2003: 15th (32.81%)<br>Seed in 2002: 11<br>Seed in 2003: 11<br>Lost in 2002 to Solid Snake in Round 3<br>Lost in 2003 to Sonic in Round 3<br><br>Back from her absense, Aeris returns to the Contest scene.<br><br><b>Marle</b><br>Game/Series Known From: Chrono Trigger<br><br>In place of Magus and Frog, we get Marle! Ah well&#8230;<br><br>Aeris,
Aeris, Aeris. It took you three years and a huge handicap, but you
managed to find your way back into a GameFAQs Contest! Aeris fans, you
should be proud. After years of putting in the wrong form of her name,
you finally got it right for once and she came back.<br><br>Her first
opponent in her glorious Contest return is against Marle. Now, Marle
may be from Chrono Trigger, giving her some strength, but she would
need to be stronger than Magus and Frog to win. Do you see that
happening? Well, I don&#8217;t. With FF7:AC and KH2 behind her, Aeris has no
reason to fall off the radar from 2003. She should be around as strong
as she was back then, which is scary. Who knew that someone so *SPOILER
DELETED* could still put up a fight?<br><br>Oh yeah, and obligatory &#8220;There will most likely be SFF&#8221; statement. Have fun reading this 6 more times!<br><br><b>Moltar&#8217;s Bracket Says:</b> Aeris will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Aeris: 76% - Marle: 24%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>I'm
not too big a fan of Marle, but seeing her first match be in an
unwinnable SFF scenario is kind of a disappointment. There are a lot of
spots on the female side where Marle would have been a hard character
to choose against with being the female lead of CT and all.<br><br>Prediction: Aeris with 70.01%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>It&#8217;s
nice to see that Chrono Trigger was able to get some female
representation, but it sucks that she was wasted to Aerith. She could
probably beat down more than half of the other female contestants
without a problem. Unfortunately, we have to see her get a SFF beat
down courtesy of the Flower Girl. <br><br>What will be most
interesting about this match is seeing how Marle performs. In all
likelihood, this&#8217;ll be a big blowout, but if Marle can keep it pretty
respectable it would be really good for Zelda, I think. Aerith cannot
really afford to disappoint and come out with something way under
expectations &#8211; depending on how high those expectations are. It is a
SFF match, but Square SFF usually isn&#8217;t <i>as</i> severe are Nintendo SFF. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Aerith Gainsborough<br><br><b>Aitch Emm&#8217;s Prediction:</b> Aerith Gainsborough &#8211; 78% ; Marle &#8211; 22%<br><br><b>Aitch Emm&#8217;s Vote:</b> Aerith Gainsborough<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Finally,
the last of the top four female entrants is ready to make her long
awaited return after an over THREE YEAR absence. Welcome back, Aeris!
Luckily for Ms. Gainsborough, she's got some easy competition in her
first match back. I don't know much about Chrono Trigger or Marle, but
I know weaksauce when I see it, and let me just tell you: weaksauce.<br><br>Everyone
will essentially be shooting in the dark when it comes to predictions
here, as not only are we unsure just how weak Marle will be, but the
possible SFF is also tough to gauge. Of course, I'm going to go about
my own semi-dumbassed way of trying to figure it out. Let's see... Tifa
beat Ivy Valentine with about 76%. While I doubt Aeris is quite as
strong as Tifa, Marle is probably weaker than Ivy, and I think Aeris
could get some SFF, so I'll tack on a few percentage points and call it
a day. Once again, welcome back, you sexy thang!<br><br>My prediction: Aeris Gainsborough def. Marle (78-22)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/22/2006 8:03:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336253024">message detail</a>
 | #315</td></tr>
<tr class="even"><td>
<b>Lopen&#8217;s Analysis</b><br> <br>So they took the two entrants I hate
most in the bracket, and stuck them together! I don't know whether I
should be ecstatic that one is guaranteed to lose, or be nauseous
because one is guaranteed to win. Well, I guess I'll be optimistic and
be ecstatic!<br><br><i>Yay Marle's gonna lose, Marle's gonna lose!</i>  (You can <i>feel</i>
the joy!) Yeah, there really isn't that much room for debate here. All
signs point to Aeris getting by the likes of Frog or Magus without much
trouble. Why should Marle be more popular than them? I'd be damned
surprised&#8230; and she <i>shouldn't</i>. Nobody likes her! She even loses to <i>Aeris</i> in the all important battle of TJF! You know what? As much as I <i>love</i>
to talk about these two&#8230; instead of continuing this analysis (I summed
it up in a couple of sentences anyway!), it's time for my Guilty Gear
related rant of this contest! Fire up da beat!<br><br>Yo, Marle, you just a bag full of suck. Dizzy is&#8230; not a bag of suck! Word to your mother.<br><br>&#8230;
what the hell was that? See what a match of this crappiness:character
ratio did? It robbed me of everything&#8230; even my ranting and rapping
skills! Don't worry, I'll do a good rap on a match later, I promise!<br><br><b>Lopen's prediction:</b> Aeris with 77.18%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br>Aeris Gainsborough<br><br>Summer 2002 Contest<br>Extrapolated Strength --- 12th Place [30.62%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 15th Place [32.81%]<br><br>The
most glaring snub in the Contest's history returns, and her reward is a
very real chance at making the Final Four of this contest. Good things
come to those who wait, I suppose?<br><br>Marle<br> <br>lol N/A<br><br>Another waste. Marle could have caused havoc as the 7 seed for <i>any</i>
other 2 seed, but in this match she'll be doing her damndest to just
avoid a dosage of Square SFF. I, for one, think she'll be
successful...for the most part. Then again, she's probably not packing
all that much strength to begin with...<br><br><i>Notable Releases Since Last Appearance</i><br><br>Aeris Gainsborough: Kingdom Hearts II (PS2)<br>Marle: N/A<br><br><i>Upcoming Releases</i><br><br>Aeris Gainsborough: N/A<br>Marle: N/A<br><br>Not much to discuss in this match...um...the picture might help Marle a lil'? Meh. =/<br><br>Karma Hunter's Vote: Aeris. Welcome back.<br><br><b>Karma Hunter's Krazy Prediction: Aeris Gainsborough with 71.94%.</b><br> <br>Total
guess here. Aeris hasn't been seen in years, and Marle is completely
untested. Still, I'd expect Marle to be much worse than Frog, and she's
looking at some potential SFF here.<br><br>Upset Potential: 0%<br><br>Nope.<br> <br><br><br><b>Guest&#8217;s Analysis</b> - <i>BeTheMan</i><br><br>Admittedly,
this is not one of the sexier first-round matchups, as there is very
little doubt over how the match is going to turn out. Nevertheless,
there are a couple of factors at play here that could prove to be
important in later matchups, so Aeris/Marle is well worth a bit of
analysis.<br><br>Aeris holds the distinction of being one of the most
impressive non-Noble Nine characters in contest history. She made Sweet
16 runs in 2002 and 2003, scored sizeable victories over Sora and
Master Chief, and turned in impressive performances in her losses to
Snake and Sonic. Interestingly enough, Aeris couldn't muster enough
support to land a spot in either of the last two character battles.
This <i>could</i> be a sign that Ms. Gainsborough isn't quite as formidable as she once was.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/22/2006 8:04:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336253256">message detail</a>
 | #316</td></tr>
<tr class="even"><td>
Still, Aeris has a couple of major advantages heading into her first
round matchup. In the past year, she has made notable appearances in
Advent Children and Kingdom Hearts 2. If nothing else, this should
serve to make her character relevant again. Aeris also has the good
fortune of being matched up against a Square character, and since FF7
is the crown jewel of the Square universe, Aeris should benefit from
any SFF that shows up during this match.<br><br>We
haven't seen Marle appear in a contest before now, so it's hard to say
exactly how strong she should be...but since four other Chrono Trigger
characters have shown up in past contests, we can make an educated
guess. Crono has a solid standing in the Noble Nine, and while Magus
and Frog have turned in mixed performances, they are both safely above
the fodder line. Marle is almost certainly weaker than the
aforementioned trio, but she's probably not as far off as some would
expect. Lavos fared only 5% worse than Frog did against Liquid Snake,
and it's difficult to imagine Lavos being more popular than Marle. <br><br>If
I were to make an estimate of what Aeris and Marle should look like in
the X-Stats (based off of Link at 50%), I would slot Aeris somewhere
around 33%, and Marle somewhere around 22%. If that were the case, this
match would project out to a doubling for Aeris. Of course, since Aeris
doubled Sora in 2003, and Sora &gt; Frog/Riku &gt; Marle, we know that
these numbers need an adjustment for SFF. To me, the amount of SFF that
we wind up seeing should clue us in what we should expect from the FF
and KH crew down the road. If Aeris stomps Marle into the ground,
Square's elite have a chance to make some serious noise down the road.
If Aeris struggles to break 70%, Squareheads should get their panic
buttons ready. With that in mind...<br><br>Prediction: Aeris with 74.25%<br><br> <br> <br>Crew Consensus: We all have Aeris winning in the 70% range. That's...about it.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=2303557" class="name">FlamboyantSpy</a> |
Posted 9/22/2006 8:04:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336253381">message detail</a>
 | #317</td></tr>
<tr class="even"><td>
God damn... how can you guys give KH another point on Marle/Aeris? For shame...<br><br>---<br><b>Explicit Content</b> <br>Philadelphia's Path to Cheer Up Emo Kids (1-1) - Next week @ SanFran 49ers.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/22/2006 8:45:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336262508">message detail</a>
 | #318</td></tr>
<tr class="even"><td>
Lopen can't rap?  Oye.  I don't like nutty analyses that look like someone just went insane, but I do like <i>some</i> fun in these analyses...<br><br>And,
somehow, I don't see Aeris getting such low percentages. The grand
beating that Crono got last year (after finally smashing Mario's head
in in 2004) probably indicates a fall in Chrono Trigger's popularity,
which is bad for Marle. Factor this is with not looking "cool" like
Magus and Crono and not having an easily recognizable name like Frog,
and Marle should end up pretty low in the stats. I think Lucca might've
done better, but how can we tell?<br><br>Aeris for the Quadrupling!  I called it!<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/22/2006 9:13:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336268126">message detail</a>
 | #319</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick and Drunken Analysis:</i><br><br>Marle? Who the
**** is Marle? I think she's some FF character, but I don't know. If
she is, Aeris is a much stronger FF character than Marle, sho she will
SFF her to all hell. If not.....well.....Aeris will stilll kick her
ass, cause she like......SPOILERS......died or something.<br><br>My vote: Aeris<br>My bracket: Aeris<br>My prediction: Aeris with 84%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/22/2006 11:10:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336292920">message detail</a>
 | #320</td></tr>
<tr class="even"><td>
<i><b>From FlamboyantSpy Posted 9/22/2006 9:04:40 PM #317</b></i><br><i>God damn... how can you guys give KH another point on Marle/Aeris? For shame...</i><br><br>My analysis was a good one...<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/22/2006 11:11:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336293056">message detail</a>
 | #321</td></tr>
<tr class="even"><td>
KOS-MOS vs. Amy Rose<br>+7 Mo<br>+6 Lo<br>+5 Yo<br>+4 KH<br>+3 Guest<br>+2 HM<br>+1 Ulti<br><br><b>The Rankings</b> (Through KOS-MOS vs. Amy Rose)<br>1. UltimaterializerX (52)<br>2. Heroic Mario (48)<br>3. Karma Hunter (44)<br>4. Yoblazer (42)<br>5. Master Moltar (41)<br>6. Board 8 (35)<br>7. Lopen (32)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=264094" class="name">Heroic Mario</a> |
Posted 9/22/2006 11:16:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336294001">message detail</a>
 | #322</td></tr>
<tr class="even"><td>
Ulti is going to be dethroned here soon!<br><br>---<br>"<i>Master using it and you can have this.</i>"<br><a class="linkification-ext" href="http://img90.imageshack.us/img90/160/masterjg3.jpg" title="Linkification: http://img90.imageshack.us/img90/160/masterjg3.jpg">http://img90.imageshack.us/img90/160/masterjg3.jpg</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/23/2006 1:08:12 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336311902">message detail</a>
 | #323</td></tr>
<tr class="even"><td>
<i><b>From FlamboyantSpy Posted 9/22/2006 9:04:40 PM #317</b></i><br><i>God damn... how can you guys give KH another point on Marle/Aeris? For shame...</i><br><br>AW SNAP CALL THE NATIONAL GUARD ULTI IS KILLING THE CREW.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/23/2006 1:17:12 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336312910">message detail</a>
 | #324</td></tr>
<tr class="even"><td>
<i>Lopen can't rap? Oye. I don't like nutty analyses that look like
someone just went insane, but I do like some fun in these analyses...</i><br><br>I'll take this as a compliment.  I think I've mastered the art of fun without complete insanity!  <br><br>Though I can totally throw out a fierce rap... I told ya... the sucktitude of this match just totally threw me off!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/23/2006 1:25:11 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336313818">message detail</a>
 | #325</td></tr>
<tr class="even"><td>
Who is expected to win the day vote? Aeris I assume... so maybe KH still has a shot.<br>---<br>CB06 - Score: <b>11/11 </b>Rank: <b>Tied - 1st </b>Yesterday's Pick:<b> KOS-MOS</b> <br>Today's Pick: <b>Aeris Gainsborough</b> Tomorrow's Pick: <b>Yuna</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/23/2006 1:26:58 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336314001">message detail</a>
 | #326</td></tr>
<tr class="even"><td>
It's tough to OMG ASPLODE in an SFF match, but I wouldn't count FF7 out of being able to pull it off.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/23/2006 4:56:36 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336328284">message detail</a>
 | #327</td></tr>
<tr class="even"><td>
<i>AW SNAP CALL THE NATIONAL GUARD ULTI IS KILLING THE</i>--<br><br><b>NOT SO FAST STARFOX</b><br><br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/23/2006 5:55:24 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336331023">message detail</a>
 | #328</td></tr>
<tr class="even"><td>
OMG AERIZ IZ DONIG BALDY!<br><br>Uh, sorry, but I'm still a little shocked that she's going below <i>below</i>
70%. What happened to the flower girl? Why has she not done a
quadrupling on a far less known character (who is from Chrono Trigger,
BTW)? WTH happened?<br><br>Oh well. She'll still crush Kos-Mos, but now
the Zelda&gt;Aeris pick I made doesn't look so bad...Looks like it's
sweet sixteen again!<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/23/2006 6:16:11 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336331730">message detail</a>
 | #329</td></tr>
<tr class="even"><td>
I really don't know why people were expecting the quadding out of
Aeris...Marle's not as weak as Ivy, and we've already seen CT debatably
evade SFF at the hands of FFVII itself...<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/23/2006 6:20:32 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336331954">message detail</a>
 | #330</td></tr>
<tr class="even"><td>
<i>I really don't know why people were expecting the quadding out of
Aeris...Marle's not as weak as Ivy, and we've already seen CT debatably
evade SFF at the hands of FFVII itself...</i><br><br>I suppose we just
thought that Aeris was one of the better-known FF characters, and would
therefore maul whoever came to her. Still, even you guys thought she
wouldn't go below 70% (though she's back up).<br><br>Um, actually, I
forgot...Which Chrono Trigger character evaded SFF? Besides the Noble
Nine Crono against the nearly-Noble Nine Vincent?<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/23/2006 6:37:38 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336332804">message detail</a>
 | #331</td></tr>
<tr class="even"><td>
70%+ on most any character of note is an exceptional performance. Aeris
hasn't budged much from her near-elite status (and why would you expect
her to? -- it's <i>FFVII</i>). FFVII almost always starts off weak, so I expected her to have under 70% and rise with the day vote -- that's my <i>final</i> prediction you see right there. Though I suppose Marle may get the day vote, we've never seen her before...<br><br>And
while I think this is only the second time we've seen a CT character
face a FFVII character (Vincent/Crono being the first), CT itself held
up exceptionally well against the FFVII juggernaut in the Games Contest
Finals. <br><br>...well, about as well as one could expect against <i>Final Fantasy VII</i> I suppose...<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 9/23/2006 9:38:36 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336348322">message detail</a>
 | #332</td></tr>
<tr class="even"><td>
I am proud to have earned my last place standing in the Guest rankings, <i>thank you very much.</i><br>---<br>This was Ed Bellis, servant to the mighty Guru <b>Z1mZum</b>. Congrats, buddy!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/23/2006 9:39:18 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336348407">message detail</a>
 | #333</td></tr>
<tr class="even"><td>
Haha, I predicted 84% in this match.  Crazy alcohol....<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/23/2006 12:35:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336377201">message detail</a>
 | #334</td></tr>
<tr class="even"><td>
Aeris has been decreasing... looks like Ulti's got this.<br>---<br>CB06 - Score: <b>11/11 </b>Rank: <b>Tied - 1st </b>Yesterday's Pick:<b> KOS-MOS</b> <br>Today's Pick: <b>Aeris Gainsborough</b> Tomorrow's Pick: <b>Yuna</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/23/2006 6:19:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336448267">message detail</a>
 | #335</td></tr>
<tr class="even"><td>
KOS-MOS..................65.43% 67068<br>Amy Rose..................34.57% 35441<br>TOTAL VOTES.....................102509<br><br>71.23% of the brackets predicted this match correctly.<br><br>KOS-MOS
does pretty well on Amy. Either KOS-MOS is already looking better than
she was in 2005, or Amy is pretty darn weak (or a combo of both!)<br><br>Today, Aeris is going 70-30 with Marle. That'll learn me to underestimate a CT character!<br><br>Lopen - 3<br>Ulti - 3<br>Moltar - 2<br>KH - 1<br>Yoblazer - 1<br>Guest (Wigs) - 1<br>HM - 1<br><br>I love giving myself points. I really do.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Aeris vs. Marle - Bracket: <b>Aeris</b> - Vote: <b>Aeris</b> (10/11)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/23/2006 7:44:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336467707">message detail</a>
 | #336</td></tr>
<tr class="even"><td>
<b>Triforce Division:</b> <i>Round 1 - Match 13</i> &#8211; (1)Yuna vs. (8)Roll <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Yuna</b><br>Game/Series Known From: Final Fantasy<br>Extrapolated Rank in 2003: 34th (23.66%)<br>Extrapolated Rank in 2005: 39th (19.93%) &#8211; Adjusted Value: 31st (23.92%)<br>Seed in 2003: 9<br>Seed in 2005: 6<br>Lost in 2003 to Knuckles in Round 1<br>Lost in 2005 to Ganondorf in Round 1<br><br>Yuna a number 1 seed for the females. I&#8217;m slightly impressed!<br><br><b>Roll</b><br>Game/Series Known From: Mega Man<br><br>Another Mega Man character&#8230;yep.<br><br>So
let&#8217;s see, after Samus, Zelda and Tifa we have&#8230;Yuna? We have to go that
far down to find a female decent enough for the 4th one seed not named
Aeris? Oh well&#8230;<br><br>Even though Yuna isn&#8217;t all that strong, she has
an easy match in Round 1. Roll will be nothing more than fodder, so the
FFX star has nothing to worry about here. I mean, we&#8217;ve seen other Mega
Man characters like Protoman and Dr. Wily, who I would take over Roll,
and even based on their past performances, I wouldn&#8217;t take them over
Yuna.<br><br>Also, you know your sad when Yuna is going to blow you out. Only a few more Round 1 female matches to go, yay!<br><br><b>Moltar&#8217;s Bracket Says:</b> Yuna will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Yuna: 73% - Roll: 27%<br> <br><br> <br><b>Ulti&#8217;s Analysis</b><br><br>I'm
not even going to dignify this with a response. **** Roll and her
goddamn bolt crap in Mega Man 8. GIVE me the goddamn upgrades.<br><br>Nice
to see Yunie as a 1, though. It's tough to defend her character given
her crap voice acting and the laughing scene, but I maintain that her
character in FFX is one of the finest RPG roles for any girl to ever
grace the genre.<br><br>Prediction: Yuna with 68.24%<br><br><br><br><b>HM&#8217;s Analysis</b><br> <br>Hurrah
for Yuna getting a first seed! It&#8217;s nice to see three of my favorite
female characters sporting the top seed in this bracket. Yuna is going
up against Roll from the Mega Man series here &#8211; and this will be <i>ugly</i>.
Yuna came out pretty strong last year with a nice boost from Final
Fantasy X-2. This year, she&#8217;s got some help thanks to Kingdom Hearts
II, even with her minute role, but that&#8217;s pretty much irrelevant thanks
to how fodderific Roll is going to be. <br><br>Judging by how poorly
Protoman performed in 2004, it&#8217;s safe to say that this one could
approach the 70%+ range for Yuna. She&#8217;s already projected to get 63% on
Protoman, and I wouldn&#8217;t suspect she&#8217;d be anywhere close to him. This
is one of many easy wins for Yuna as she goes and plows through this
division with ease. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Yuna<br><br><b>Aitch Emm&#8217;s Prediction:</b> Yuna &#8211; 68% ; Roll &#8211; 32%<br><br><b>Aitch Emm&#8217;s Vote:</b> Yuna<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>This
should be a very boring match between the last (and weakest) top seeded
female and a very generic looking opponent. How many voters will even
realize Roll is from Mega Man? She just looks like a background
character to me. Yuna won't have any trouble here, but she's still
forced to count the days until her inevitable match with Zelda.<br><br>My prediction: Yuna def. Roll (72-28) <br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Another
unpopular character from a popular franchise. I'm getting sick of
seeing these. Amy Rose, Daisy, Roll. At least Zelda and Metal Gear
spared us of these things!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/23/2006 7:45:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336467941">message detail</a>
 | #337</td></tr>
<tr class="even"><td>Okay, I see this as being a huge beating. Roll's a
very minor character in the Mega Man games... I think her most notable
role was the item shop chick in MM7/8? Otherwise she's just a punk who
shows her face in the ending once in a while. The only reason I give
Roll a chance to draw any votes is because of Marvel vs. Capcom 1 and 2
(and maybe that old Mega Man cartoon!). We know they were pretty
popular games in 2002... right? Look at how well Servbot, Strider, and
Morrigan did! Well, the heck with that. It had nowhere to go but down&#8230;
and I imagine Roll's an even less popular pick than any of these. (Yes,
even Servbot&#8230; he's got more novelty) Not to mention Servbot was
probably flukish anyway.<br><br>Yuna could do way worse than I expect here. And if she does&#8230; I totally blame Marvel vs. Capcom! But she won't.<br><br><b>Lopen's prediction:</b> Yuna with 80.01%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br> <br>Yuna<br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 34th Place [23.66%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 31st Place [23.92%]<br> <br>Yuna as a 1 seed? Geez, will wonders never cease? She really should have switched her division with Tifa's, though...<br> <br>Still, it'll be nice to see the summoner finally win a match. Though she could have more respectable opposition...<br> <br>Roll<br> <br>lol N/A<br> <br>LOL, indeed. Roll? <i>Roll?!</i>
I could not believe my eyes when I saw Roll made this damn contest, and
the now iconic "darn you cjay" sums up my feelings on her and this
entire match. Not that I don't like Roll, of course -- she's damn good
in the MML games, of which I'm a huge fanboy of...but other than that
and MvC2, she's nothing but an NPC. No, she's worse -- she's an NPC
that only appears in minor storyline scenes. Y'know that "I want to
grow up to be a blitzball!" kid in FFX? Yeah, he's got more relevance
to his game than Roll typically does to hers.<br> <br>****ing female bracket.<br><br><i>Notable Releases Since Last Appearance</i><br><br>Yuna: Kingdom Hearts II (PS2)<br>Roll: Mega Man Legends (PS1), Marvel vs Capcom 2 (Multi)<br><br><i>Upcoming Releases</i><br><br>Yuna: N/A<br>Roll: N/A<br> <br>I could see Yuna steamrolling Protoman. That's all ya need ta know for this match.<br><br>Karma
Hunter's Vote: Roll. Hey, I like ya Yuna. I really do. But MML Roll
holds a space near and dear to my heart, AND YOU'RE GONNA ****ING KILL
HER<br><br><b>Karma Hunter's Krazy Prediction: Yuna with 76.62% .</b><br> <br>Another total guess, and I'm trying not to go too low thanks to my MML fanboyism.<br><br>Upset Potential: 0%<br><br>HAHAHAHAHAHA<br> <br><br><br><b>Guest&#8217;s Analysis</b> - <i>XIII_Rocks</i><br> <br>God
damn time differences and the need for sleep :( I got lumbered with a
fodder match. Ah, well. Anyway, this match gives us a chance to see the
first ever female megaman character in a contest setting vs. ...random
idiotic bleghgirl from FFX/-2. Yeah, fun.<br><br>I fully expect Roll to
be much weaker than Protoman (who would be a fairly decent addition to
the contest - I'm nominating him for the returners in the NRT this
year), seeing as she doesn't have a massive role and most MM fans
probably don't care for her. Yuna, on the other hand, is fresh off a
cameo KH2.<br><br>KH2, the prequel to which propelled a Cloud who lost
to Mario to all of a sudden beating LINK. Yeah, Roll has no chance of
avoiding a quadrupling here, and after Nidoran's performance today, I
expect Roll to look TERRIBLE in the stats.<br><br>Yuna with 82%, and I'm being generous.<br> <br><br> <br>Crew Consensus: Yuna for the win. Another match with a wide range of predictions. From 68% to 82%, where will it land!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/23/2006 9:08:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336486625">message detail</a>
 | #338</td></tr>
<tr class="even"><td>
<i>DpObliVion's slightly drunken again and quick Analysis:</i><br><br>Hooray
for wikipedia letting me know who these people are. Apparently Yuna is
someone from FF10, and Roll is someone from Mega Man. Right away, just
from that, you should know that Yuna should win. Then throw in that
Yuna is pretty popular, and Roll is basically unknown/people don't give
a damn about her, plus it's a 1-vs-8 so you just know.......<br><br>My vote: I don't know.....I really have no interest in voting for either of them<br>My bracket: Yuna<br>My prediction: Yuna with 71%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/23/2006 9:16:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336488283">message detail</a>
 | #339</td></tr>
<tr class="even"><td>
Aeris vs. Marle<br>+7 Ulti<br>+6 KH<br>+5 Guest<br>+4 Mo<br>+3 Lo<br>+2 HM (tie)<br>+2 Yo (tie)<br><br><b>The Rankings</b> (Through Aeris vs. Marle)<br>1. UltimaterializerX (59)<br>2. Heroic Mario (50)<br>2. Karma Hunter (50)<br>4. Master Moltar (45)<br>5. Yoblazer (44)<br>6. Board 8 (40)<br>7. Lopen (35)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/23/2006 9:18:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336488780">message detail</a>
 | #340</td></tr>
<tr class="even"><td>
Hold on... I <i>wasn't</i> the highest Yuna prediction?  What nonsense is this?  <br><br>I also find it pretty ironic that KH and I are the only two that mentioned Marvel vs Capcom, the only way Roll should have <i>any</i> fans... and we have the highest Yuna %s of the crew.  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=264094" class="name">Heroic Mario</a> |
Posted 9/23/2006 9:18:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336488937">message detail</a>
 | #341</td></tr>
<tr class="even"><td>
You realize that Roll would need to be well below Yuri for your prediction to come true, right? &gt;&gt;<br><br>---<br>"<i>Master using it and you can have this.</i>"<br><a class="linkification-ext" href="http://img90.imageshack.us/img90/160/masterjg3.jpg" title="Linkification: http://img90.imageshack.us/img90/160/masterjg3.jpg">http://img90.imageshack.us/img90/160/masterjg3.jpg</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=46088" class="name">therealmnm</a> |
Posted 9/23/2006 9:20:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336489204">message detail</a>
 | #342</td></tr>
<tr class="even"><td>
<i>I also find it pretty ironic that KH and I are the only two that
mentioned Marvel vs Capcom, the only way Roll should have any fans...
and we have the highest Yuna %s of the crew. </i><br><br>Mega Man Legends, yo.<br>---<br><b>Vote for Soma Cruz</b><br>Currently playing: Grand Theft Auto 3, Castlevania:Curse of Darkness, Mega Man ZX
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/23/2006 9:25:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336490428">message detail</a>
 | #343</td></tr>
<tr class="even"><td>
Oh yeah... Mega Man Legends. I actually forgot she was in that. I'd
have knocked my prediction down at least a tad had I remembered that. <br><br>And
no, I didn't know... but you should know by now I rarely consult the
X-Stats for these predictions! (That's probably why my score is last.)
Roll "seems like a character that can get 80-20ed here", that was about
my thought process. <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=46088" class="name">therealmnm</a> |
Posted 9/23/2006 9:28:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336491056">message detail</a>
 | #344</td></tr>
<tr class="even"><td>
Roll can be 80-20'd, but I seriously doubt <i>Yuna</i> would be the one to do it... <br>---<br><b>Vote for Soma Cruz</b><br>Currently playing: Grand Theft Auto 3, Castlevania:Curse of Darkness, Mega Man ZX
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/23/2006 9:28:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336491171">message detail</a>
 | #345</td></tr>
<tr class="even"><td>
If I could go back, I'd bump my Yuna prediction down a peg. The Final Fantasy ladies haven't impressed me.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/23/2006 9:32:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336492058">message detail</a>
 | #346</td></tr>
<tr class="even"><td>
And everyone always likes to bring <i>Yuri</i> up when we talk about Fodder... but what about other gems in that area?  <br><br>Yuna (2005c) VS Officer Tenpenny (2005v)<br><br>Yuna has a strength of 26.10.<br>Officer Tenpenny has a strength of 8.51.<br><br>Yuna wins with 83.70% of the vote! <br>A win of 67,087 with 99,544 total votes cast.<br><br>Officer Tenpenny could <i>totally</i> give Roll a close match!  Oh yeah!!<br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=264094" class="name">Heroic Mario</a> |
Posted 9/23/2006 9:40:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336494031">message detail</a>
 | #347</td></tr>
<tr class="even"><td>
If Yuna beats Roll 80/20, then someone was <i>clearly</i> underestimated in the stats last year. <i>What's up, Ganon over Sonic!</i><br><br>---<br>"<i>Master using it and you can have this.</i>"<br><a class="linkification-ext" href="http://img90.imageshack.us/img90/160/masterjg3.jpg" title="Linkification: http://img90.imageshack.us/img90/160/masterjg3.jpg">http://img90.imageshack.us/img90/160/masterjg3.jpg</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/23/2006 11:01:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336512180">message detail</a>
 | #348</td></tr>
<tr class="even"><td>
ULTI IS <i>KILLING</i> THE CREW.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/23/2006 11:07:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336513465">message detail</a>
 | #349</td></tr>
<tr class="even"><td>
I love when people go bonkers because they overestimate useless fodder. Roll is superfluous.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/24/2006 12:01:50 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336524824">message detail</a>
 | #350</td></tr>
<tr class="even"><td>
Jeezus, do I have any competition for this pick? Someone's gonna need to go berserk to stop me from getting this one!<br>---<br><b>Commit it to memory.</b>
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=5">6</a></li>
<li>7</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=9">10</a></li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage7_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30499515&amp;page=6" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
<div id="copyright">
	<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
	<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
	<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
</div>
<script src="genmessage7_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</div></body></html>