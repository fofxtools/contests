<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	



<title>GameFAQs - GameFAQs Contests Message Board</title><meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage3_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage3_files/nogs.css"></head><body linkifytime="340" linkified="10" linkifying="false"><div id="container">
	<div id="gne_nav">
		<img src="genmessage3_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/events/x06/">X06</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage3_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30499515%26page%3D2"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage3_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage3_files/advertisement.gif" alt="advertisement" height="10" width="120"></div>
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage3_files/f.xhtml" marginwidth="0" marginheight="0" hspace="0" vspace="0" allowtransparency="true" frameborder="0" height="90" scrolling="no" width="728">
&lt;script language=javascript&gt;&lt;!-- randNum = ((new
Date()).getTime() % 2147483648) + Math.random(); document.write( "&lt;a
href='http://a.tribalfusion.com/i.click?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID="
+ randNum + "' target=_blank&gt;" + "&lt;img
src='http://a.tribalfusion.com/i.ad?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID="
+ randNum + "'" + " width=728 height=90 border=0 alt='Click
Here'&gt;&lt;/a&gt;"); // --&gt;&lt;/script&gt; &lt;noscript&gt; &lt;a
href="http://a.tribalfusion.com/i.click?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID=1576037958"
target=_blank&gt; &lt;img
src="http://a.tribalfusion.com/i.ad?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID=1576037958"
width=728 height=90 border=0 alt="Click Here"&gt;&lt;/a&gt;
&lt;/noscript&gt; </iframe><img src="genmessage3_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;page=2">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30499515" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=1">Previous Page</a> |
Page 3 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=3">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/14/2006 9:43:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334600946">message detail</a>
 | #101</td></tr>
<tr class="even"><td>
My analysis is so damn crappy &lt;3<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3050550" class="name">TheKoolAidShoto</a> |
Posted 9/14/2006 9:47:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334601852">message detail</a>
 | #102</td></tr>
<tr class="even"><td>
When do the sign-ups for the 2nd round begin?<br>---<br>Plus I wanted to always blast some guy up with Wolverine's red blast thing. -- liljon949
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=795464" class="name">Tatl</a> |
Posted 9/14/2006 9:54:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334603282">message detail</a>
 | #103</td></tr>
<tr class="even"><td>
<i>When do the sign-ups for the 2nd round begin?</i><br><br>I want to know this too.<br>---<br>"I reject your reality and substitute my own." ~ Adam Savage; Insanity Personified<br>"Crikey!" ~ Steve Irwin (R.I.P.); Perfection Personified
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/14/2006 9:57:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334603946">message detail</a>
 | #104</td></tr>
<tr class="even"><td>
It's better than mine, Ulti.  I provide nothing....<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br>**Character Battle V PRINTABLE BRACKET** See quote for link.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/14/2006 9:58:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334604040">message detail</a>
 | #105</td></tr>
<tr class="even"><td>
Sign-ups for the first half of the 2nd round begin after Lara/Alyx.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Rikku vs. Lenneth - Bracket: <b>Rikku</b> - Vote: <b>Rikku</b> (2/2)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/15/2006 12:03:39 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334627038">message detail</a>
 | #106</td></tr>
<tr class="even"><td>
Guest gonna get a point here?<br>---<br>CB06 - Score: <b>3/3 </b>Rank: <b>Tied - 1st </b>Yesterday's Pick:<b> Rikku</b> <br>Today's Pick: <b>Kairi</b> Tomorrow's Pick: <b>Tifa Lockhart</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/15/2006 9:48:41 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334666520">message detail</a>
 | #107</td></tr>
<tr class="even"><td>
I think I have the lowest Kairi pick, should she end up winning.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/15/2006 1:25:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334691846">message detail</a>
 | #108</td></tr>
<tr class="even"><td>
Rikku..........................75% 83124<br>Lenneth Valkyrie........25% 27704<br>TOTAL VOTES..................110828<br><br>85.91% of the brackets predicted this match correctly.<br><br>A
perfect tripling. Nice. I'm a bit impressed with Lenneth's strength in
the end, but that doesn't change the fact that she was no match for
Rikku.<br><br>Today, Kairi might have held the lead at first, but
Claire took charge of the early-afternoon vote. However, I wouldn't
call her safe yet. We still have the kiddies in school!<br><br>Lopen - 1<br>HM - 1<br>Ulti - 1<br>Moltar - 0<br>Yoblazer - 0<br>KH - 0<br>Guest - 0<br><br>Lopen has the closest Rikku pick. Yay him!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Kairi vs. Claire - Bracket: <b>Claire</b> - Vote: <b>Claire</b> (3/3)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/15/2006 8:25:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334777477">message detail</a>
 | #109</td></tr>
<tr class="even"><td>
Kairi is back up.  Good for my bracket!<br><br>Man, you guys are doing it LATE these days...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/15/2006 8:28:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334778258">message detail</a>
 | #110</td></tr>
<tr class="even"><td>
<b>Limit Division:</b> <i>Round 1 - Match 5</i> &#8211; (1)Tifa Lockhart vs. (8)Ivy Valentine <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Tifa</b> <br>Game/Series Known From: Final Fantasy <br>Extraploated Rank in 2005: 15th (30.77%)<br>Seed in 2005: 3<br>Lost in 2005 to Sonic in Round 3<br><br>She was the second strongest newcomer last Contest, and is looking to go far here as well.<br><br><b>Ivy</b><br>Game/Series Known From: Soul Calibur<br><br>A Soul Calibur character got in! Too bad it wasn&#8217;t Nightmare though&#8230;<br><br>Blargh, female half. Never again.<br><br>So
here we have the second strongest newcomer in 2005 facing off against
Ivy from Soul Calibur. Tifa wins with ease. Next time we get a Soul
Calibur character in, it better be Nightmare. No ifs, ands, or buts.<br><br>Now
let&#8217;s get to a more interesting match. Tifa vs. Ivy, in a 3D fighter
fight! Oh yeah. Ivy with her Whip Of Doom and Tifa with her Breasts of
Destruction. Oh man, I&#8217;d watch that!<br><br><i> Ivy: Are you ready?<br>Tifa: &#8230;&#8230;&#8230;I don't know.<br>Ivy: Do you have any last words?<br>Tifa: Why are you dressed like that!?<br>Ivy: No one can escape from me!<br>Tifa: Wait a second! You're not thinking of just going right through the main entrance, are you?<br>Ivy: Be careful or you will feel the pain.<br>Tifa: Please, stop it!<br>Ivy: Resisting only prolongs the suffering.<br>Tifa: It's not that. I'm not sure about&#8230;me. My feelings.<br>Ivy: You're a feisty one!<br>Tifa: Are you all right?<br>Ivy: Behave!<br>Tifa: Right now, I feel I have to push myself to the limit. If I stayed here&#8230;I'll go crazy.<br>Ivy: You're quite lively. I like that.<br>Tifa: &#8230;What does that mean?<br>Ivy: There, are you satisfied now?<br>Tifa: I'll tell you later! Hurry, hurry!<br> Ivy: Do you want more?<br>Tifa: You think so&#8230;?<br> Ivy: Heh, heh, hee... I like that.<br>Tifa: &#8230;&#8230;&#8230;<br>Ivy: Is that painful?<br>Tifa: &#8230;&#8230;&#8230;<br>Ivy: Go ahead, hate me.<br>Tifa: &#8230;&#8230;&#8230;<br>Ivy: Do you have any last words?<br>Tifa: I'm Tifa. Nice to meet you.<br>Ivy: I can never go back to my old life.<br>Tifa: Same here!</i><br><br><b>Moltar&#8217;s Bracket Says:</b> Tifa will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Tifa: 79% - Ivy: 21%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br><br>Poor
Lucid, and poor Soul Calibur. Its first character entrant into one of
these things is as 8 seed fodder that has no chance to do much of
anything, though there's a moral victory in knowing that Ivy's sword is
better than any goddamn weapon Tifa uses.<br><br>Thank you 32-32 system for screwing Nightmare out of a spot! *shakes fist* <br><br>Prediction: Tifa with 72.57%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>Tifa
comes back into the contest looking to make another solid run by
starting off with a domination of a Soul Calibur representative in Ivy
Valentine. Considering what we saw her do against Vyse one year ago,
this one should get pretty damn ugly &#8211; no confidence in Soul Calibur
characters being worth a dime. Fortunately, this should at least
satisfy enough people on the board to not ever want to rally for
another Soul Calibur character to see how they would do because Ivy is
about as popular as one can get not be Nightmare, who would be just as
weak. <br><br>There&#8217;s not too much to analyze here.  <br><br><b>Aitch Emm&#8217;s Bracket:</b> Tifa Lockhart<br><br><b>Aitch Emm&#8217;s Prediction:</b> Tifa Lockhart &#8211; 81.5% ; Ivy Valentine &#8211; 18.5%<br><br><b>Aitch Emm&#8217;s Vote:</b> Big Boobs McGee
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/15/2006 8:29:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334778319">message detail</a>
 | #111</td></tr>
<tr class="even"><td>
<b>Yoblazer&#8217;s Analysis</b><br> <br>It's a first round battle of the
"Thank god real women don't have names this stupid" characters! This is
another debateless gimme match. I look at Ivy, stare at the rest of the
female half of the bracket, and see some wasted potential. With her
looks and sex appeal, she could have easily given us some hotly debated
matches with several of the other gals. She's no weakling.
Unfortunately for Ivy, her opponent owns the most famous pair of
breasts in video game history. Oh, and she stars in Final Fantasy VII.
Tifa will be looking to open up a can of whoop ass on the first step of
her road to Samus, and the poor Ms. Valentine won't be able to do a
damn thing about it.<br><br>I have a feeling Tifa will do very well
here. She'll do so well, that had she been in the same quarter-bracket
as Aeris and Zelda, people would be calling her a lock. Hell, I think
she'll do well enough that a few more optimistic people will toss the
idea of Tifa &gt; Samus around. She's simply too strong and can sap too
much of Ivy's sex appeal.<br><br>My prediction: Tifa Lockheart def. Ivy Valentine (80-20)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Why Ivy and not Taki? That's what <i>I</i>
want to know coming into this one! Hey, well, at least the Nightmare
squad sorta got their wish. We just wanted to see a Soul Calibur
character in the contest, right? Okay, maybe not, maybe you just wanted
to see Nightmare. Well whatever, you get Ivy, deal with it.<br><br>Ivy
deserves better, though. Soul Calibur is at least sorta popular around
here. I'd at least struggle in matches involving Ivy and probably a
good half of this field. Strongest 8 seed, right here! I'm calling it!
And please, CJay&#8230; don't give her the awful "General Washington getup"!
That is, her second costume. Yo, I don't care if that's anything like
what Washington actually wore, Board 8 historians&#8230; I'll keep calling it
that until the end of time! It has a ring to it, admit it!<br><br><b>Lopen's Prediction:</b> Tifa with 76.08%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br>Tifa Lockheart (or is it Lockhart? I can never remember -- DAMN YOU CEEJ)<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 16th Place [30.77%]<br><br>Yay,
Tifa returns, and as a 1 seed no less! While perhaps one of my least
favored FFVII characters, she is certainly one of the strongest -- and
I'd honestly expect her to give Vincent a run for his money, if not
beat him outright (what's worth more, a role in KH2 or the star of
DoC?)...<br><br>As with (nearly) all 1 seed matches, this isn't
debated. Tifa will beat down her opponent and her next two feeble
challengers, then go out respectably to Samus. So much wasted
potential...<br><br>Ivy Valentine<br> <br>lol N/A<br><br>Heya, Ivy. One
of the postergirls for the objectification of women in today's video
games, she's one of the few females that can actually make a decent
case for having more hentai out there than Tifa. Not that I'd know
anything about that or anything.<br><br>Of course, after SC's bombing
in the Series Contest, most don't expect too much out of her. Not only
is she in an unwinnable matchup against a character that now has a KH2
boost...well, let's just say she's hoping to outperform the potentially
SFF'd Vyse.<br><br><br><i>Notable Releases Since Last Appearance</i><br><br>Tifa Lockheart: Kingdom Hearts 2 (PS2)<br>Ivy Valentine: Soul Calibur (DC), Soul Calibur II (Multi), Soul Calibur III (PS2)<br><br><i>Upcoming Releases</i><br><br>Tifa Lockheart: N/A<br>Ivy Valentine: N/A<br><br>Boring match, where we're just grasping at percentages and waiting to see who will have the bigger boobs. Money on Ivy.<br><br>Karma Hunter's Vote: Bleh. Abstain.<br><br><b>Karma Hunter's Krazy Prediction: Tifa Lockheart with 77.47%.</b><br> <br>Not
that I think Ivy is weaker than SFF'd Vyse, but Tifa has a KH2 boost in
the wings. She could show some surprising strength tonight.<br><br>Upset Potential: 0%<br><br>Nah.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/15/2006 8:29:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334778477">message detail</a>
 | #112</td></tr>
<tr class="even"><td>
<b>Guest&#8217;s Analysis</b> - <i>Vlado</i><br><br>After the first truly
awesome match of the contest, it's time for a much calmer battle, one
with a clear winner. The matches in the Limit division begin with the
top seed, the lovely Tifa, taking on Ivy from Soul Calibur, one of just
two girls in the contest to come from one of the fighting game genre,
the other one being Street Fighter's Chun Li. The Final Fantasy VII
female lead is the clear favourite in this one, and the question is
just by how much she would win. However, that doesn't mean the match
will be boring.<br><br>Tifa will definitely start her path in this
contest in a convincing fashion. Last year, the beating she gave Vyse
made many believe that she could actually stand a chance against Sonic.
Unfortunately, that wasn't the case, but this year, she's stronger than
ever. She played a big role in the Final Fantsy VII movie, Advent
Children, and received a lot of screen time, to much of the viewers'
delight. She truly looked amazing in the movie, and her fighting skills
were top-notch, just like in the game. Tifa impressed, and has
certainly earned new fans with AC. Even people who weren't too fond of
her before can't help admitting that she was amazing in the movie.
Afterwards, she was in Kingdom Hearts II, too, and her role there is
also important, though, of course, it had to do with Cloud's search for
Sephiroth, and not the main story. In FFVII: Dirge of Cerberus, she
also makes an appearance, but it's not significant and wouldn't help
her too much.<br><br>In short, Tifa is definitely stronger now than she
was a year ago. 43.6% on a boosted Sonic weren't a bad achievement, and
this year she could far surpass that score. Unfortunately, she was put
in Samus' half of the female bracket and, despite being easily stronger
than all the ones in the bottom half, she'd most likely have to bow out
one round earlier than her potential would suggest. However, with
Metroid Prime 3's delay and Samus' not-so-stellar performance against a
random Pokemon, Tifa just might stand a chance in that battle. But it's
still far too early, there'll be more to judge by later.<br><br>Her
opponent in this match is Ivy Valentine, the only Soul Calibur
representative in the contest. While it's pretty much a lunacy to think
she could break 30%, I think that Ivy has much more going for her than
Vyse did a year ago. First, she's a fighting game characters, and
fighting games have loyal and dedicated fans. It's no wonder Soul
Calibur also made the spring contest and did respectably against the
behemoth that is Metal Gear, even breaking 30%. SC has its fans on the
site, and this match will prove it yet again.<br><br>Then, there is the
picture factor, which MATTERS in female matches. While that should go
to Tifa by default, Ivy is generally considered pretty sexy, too, and
I'm sure that she could make her defeat more respectable, drawing some
votes from a sexy picture. In fact, I could see Tifa getting a rather
bland pic before Ivy. Ivy's will surely be one well exposing her assets.<br><br>In
short, I think that Tifa will win easily, but the dedicated fighting
game fanbase and some picture votes will help Ivy not look totally
horrible. Soul Calibur is yet to get beaten really badly, and I think
that Ivy will continue the trend.<br><br>Prediction: <b>Tifa with 72.68%</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/15/2006 8:30:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334778680">message detail</a>
 | #113</td></tr>
<tr class="even"><td>
So this is what it's liked to be boxed in. &gt;_&lt;<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=722305" class="name">Dilated Chemist</a> |
Posted 9/15/2006 8:33:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334779227">message detail</a>
 | #114</td></tr>
<tr class="even"><td>
Predictions. For. Tifa. Too. High.<br><br>---<br><b>Remember, remember. The 7th of October - the day Ganondorf was beat.<br>By the Valentine, who N fans despise - another win, another great feat.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3253272" class="name">MarioSuperstar</a> |
Posted 9/15/2006 8:37:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334780125">message detail</a>
 | #115</td></tr>
<tr class="even"><td>
I think any below or exactly at 80% are fine.<br>---<br>Kairi vs. Claire / Bracket: Claire/ Vote: Claire (3/3)<br>Tomorrow / Bracket: Tifa / Vote: Ivy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=722305" class="name">Dilated Chemist</a> |
Posted 9/15/2006 8:37:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334780221">message detail</a>
 | #116</td></tr>
<tr class="even"><td>
Vyse &gt; Ivy?<br><br>---<br><b>Remember, remember. The 7th of October - the day Ganondorf was beat.<br>By the Valentine, who N fans despise - another win, another great feat.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=617" class="name">Who Cares?</a> |
Posted 9/15/2006 8:38:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334780373">message detail</a>
 | #117</td></tr>
<tr class="even"><td>
Even worse, Jin &gt; Ivy...<br>---<br><b>Chun-Li's Road to the Female Final Four</b>: vs Kasumi (Septemeber 26th)<br>*Just 25 days until Tales of the Abyss*
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/15/2006 8:38:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334780448">message detail</a>
 | #118</td></tr>
<tr class="even"><td>
There was some SFF/overperformance in Tifa/Vyse on her behalf, unless Tifa = Cloud or something.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Kairi vs. Claire - Bracket: <b>Claire</b> - Vote: <b>Claire</b> (3/3)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/15/2006 8:39:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334780491">message detail</a>
 | #119</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Final Fantasy vs. Soul Calibur.  Hold on, let me clarify.....Final Fantasy <i>VII</i> vs. Soul Calibur.  Let me repeat that.....Final Fantasy VII vs. Soul Calibur.<br><br>My Vote: Ivy Valentine<br>My 4-for-4 Bracket: Tifa<br>My Prediction: Tifa with, umm.....*throws a random number out there* 74%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br>**Character Battle V PRINTABLE BRACKET** See quote for link.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=617" class="name">Who Cares?</a> |
Posted 9/15/2006 8:48:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334782726">message detail</a>
 | #120</td></tr>
<tr class="even"><td>
Oh yeah, kudos to Moltar for the SC2 dialouge for Ivy! d(o_od)<br>---<br><b>Chun-Li's Road to the Female Final Four</b>: vs Kasumi (Septemeber 26th)<br>*Just 25 days until Tales of the Abyss*
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=1694709" class="name">Pikawil100</a> |
Posted 9/15/2006 8:49:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334782823">message detail</a>
 | #121</td></tr>
<tr class="even"><td>
<i>Why Ivy and not Taki?</i><br><br>'cause people on B8 don't like
spandex. While we're at it, anyone wanna bet that if Cammy gets in a
contest, she gets a Shadowloo spandex pic?<br>---<br>Ken: Ryu, do you tattle Bison's ass so hard?<br>Ryu: <b>HA DOU, KEN!</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/15/2006 8:56:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334784398">message detail</a>
 | #122</td></tr>
<tr class="even"><td>
Rikku vs. Lenneth Valkyrie<br>+6 Lo<br>+5 HM<br>+5 Yo <br>+3 Ulti<br>+2 Mo<br>+1 KH<br><br><b>The Rankings</b> (Through Rikku vs. Lenneth Valkyrie)<br>1. UltimaterializerX (14)<br>2. Yoblazer (13)<br>3. Heroic Mario (12)<br>4. Lopen (10)<br>5. Karma Hunter (9)<br>6. Master Moltar (6)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/15/2006 8:58:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334785037">message detail</a>
 | #123</td></tr>
<tr class="even"><td>
Come on, Moltar!  What are you doing in last?<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br>**Character Battle V PRINTABLE BRACKET** See quote for link.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/15/2006 9:06:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334786612">message detail</a>
 | #124</td></tr>
<tr class="even"><td>
52.12% or lower = Ulti's point<br>52.13% or higher = HM's point<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/15/2006 9:07:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334786758">message detail</a>
 | #125</td></tr>
<tr class="even"><td>
He was on top for practically all of the Series Contest.  Now, I guess he wants to hog the bottom.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/15/2006 9:12:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334787626">message detail</a>
 | #126</td></tr>
<tr class="even"><td>
I'll be there soon enough after today.<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/15/2006 9:16:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334788499">message detail</a>
 | #127</td></tr>
<tr class="even"><td>
Nope, you're good for now, KH. The consistency rankings punish
incorrect predictions. Today's rankings will look something like this:<br><br>+6 Ulti or HM<br>+5 Ulti or HM<br>+4 KH<br>-1 Moltar<br>-2 Yoblazer<br>-3 Lopen<br><br>Disputed matches can cause a huge swing in the rankings.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/15/2006 11:04:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334811424">message detail</a>
 | #128</td></tr>
<tr class="even"><td>
I started off this Crew season on fire!<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/16/2006 3:21:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334925795">message detail</a>
 | #129</td></tr>
<tr class="even"><td>
Kairi vs. Claire Redfield<br>+6 Ulti<br>+5 HM<br>+4 KH<br>-1 Mo<br>-2 Yo<br>-3 Lo<br><br><b>The Rankings</b> (Through Kairi vs. Claire Redfield)<br>1. UltimaterializerX (20)<br>2. Heroic Mario (17)<br>3. Karma Hunter (13)<br>4. Yoblazer (11)<br>5. Lopen (7)<br>6. Master Moltar (5)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=2665492" class="name">XIII_rocks</a> |
Posted 9/16/2006 3:57:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334933047">message detail</a>
 | #130</td></tr>
<tr class="even"><td>
Post Celes/The Boss now &gt;_&gt;<br>---<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738</a> Sign plz<br>Hi-ho, Hi-ho, <b>Z1m Zum, Z1m Zum</b>...our guru champ.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 9/16/2006 4:22:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334938339">message detail</a>
 | #131</td></tr>
<tr class="even"><td>
Yeah, do eet. =o<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i><br>Michelle.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3529965" class="name">Wii_TuRtLe</a> |
Posted 9/16/2006 4:26:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334939172">message detail</a>
 | #132</td></tr>
<tr class="even"><td>
Looks like Lopen gets this one.<br><br><b>TuRtLe</b><br>~~~<br>Turtle on his laptop | Contest analysis:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/16/2006 4:56:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334945457">message detail</a>
 | #133</td></tr>
<tr class="even"><td>
Kairi........................52.08% 56291<br>Claire Redfield.....47.92% 51795<br>TOTAL VOTES................108086<br><br>62.45% of the brackets predicted this match correctly.<br><br>You
would think the casuals would have a little more faith in Kairi...hmm.
Anyway, a pretty exciting match this was. If only more people cared
about each, it would have been huge. Kairi starts out with the lead,
Claire comes back and takes it around half-way though, then Kairi comes
back and crushes Claire with the day vote, which was what most people
predicted what would happen if Claire couldn't build up a big enough
lead.<br><br>Today, Tifa is making easy work of Ivy.<br><br>Ulti - 2<br>Lopen - 1<br>HM - 1<br>Moltar - 0<br>Yoblazer - 0<br>KH - 0<br>Guest - 0<br><br>Ulti's on a roll, as he gets another point.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Tifa vs. Ivy - Bracket: <b>Tifa</b> - Vote: <b>Ivy</b> (3/4)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 9/16/2006 4:57:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334945754">message detail</a>
 | #134</td></tr>
<tr class="even"><td>
Looks like Lopen's got this one.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/16/2006 5:02:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334946872">message detail</a>
 | #135</td></tr>
<tr class="even"><td>
<i>Post Celes/The Boss now &gt;_&gt;</i><br><br>I'll do it later, but
after looking at them, I can say there are some interesting
percentages. (I'm talking 4 within 1% and another 2 within 1%)<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Tifa vs. Ivy - Bracket: <b>Tifa</b> - Vote: <b>Ivy</b> (3/4)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/16/2006 7:31:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334977442">message detail</a>
 | #136</td></tr>
<tr class="even"><td>
Mmmm... come on, bullseye!  You can do it, Ivy!<br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/16/2006 8:56:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=334996411">message detail</a>
 | #137</td></tr>
<tr class="even"><td>
You guys used to have these things posted <i>six hours ago.</i>  Does one of your members live in the UK or something?<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/16/2006 9:23:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335002848">message detail</a>
 | #138</td></tr>
<tr class="even"><td>
<b>Limit Division:</b> <i>Round 1 - Match 6</i> &#8211; (4)The Boss vs. (5)Celes Chere <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>The Boss</b><br>Game/Series Known From: Metal Gear Solid <br><br>Known for her role in MGS3, The Boss enters her first Contest<br><br><b>Celes</b><br>Game/Series Known From: Final Fantasy<br><br>Another FF6 character? When will people realize that they&#8217;re so weak?<br><br>Wooo, another debated match between two fodderific females! My favorite. Time to analyze!<br><br>Billy the Casual Bracketmaker: This match is easy! Celes will win because she&#8217;s from Final Fantasy!<br><br>Woah
there Billy. Yes Celes is from Final Fantasy, but she&#8217;s from Final
Fantasy 6. Look at the other FF6 characters we&#8217;ve seen. Kefka, Ultros,
Terra&#8230;all weak. Will Celes be any different? I doubt it. Heck, all The
Boss has to do is be around Kefka level and she takes the match.<br><br>Billy: Do you really think The Boss will be that level?<br><br>It&#8217;s
a bit of a gamble, but I think so. She had a nice role in MGS3, and we
know how the MGS series is on GameFAQs. I bet enough of GameFAQs has
played the game and like The Boss enough to vote. Celes would have
potential if we hadn&#8217;t already seen Terra bomb last year. Pre-FF7
characters just aren&#8217;t strong.<br><br>Billy: I guess The Boss will win this match! Thanks Moltar, and now I know!<br><br>And knowing is only half the battle! <br><br><b>Moltar&#8217;s Bracket Says:</b> The Boss will win.<br><br><b>Moltar&#8217;s Prediction is:</b> The Boss: 54% - Celes: 46%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br><br>As
much as I'd love to see Celes win this (she's my favorite FF female), I
don't honestly get where all of the hype from this match is coming
from. Celes' ceiling is likely 2005 Terra, though it's probably a bit
lower given that Terra is the main character and all. And as someone
who has been involved with FF6 inside and out for almost ten years now,
I can say with near-certainty that most FF6 fans don't give a crap
about Celes. Favorite character polls among the fans almost always
churn out the same results: Sabin, Edgar, and Shadow scoring really
high, Mog and Locke being a step or two below them, and everyone else
being in "meh" status.<br><br>If Celes is <i>at all</i> weaker than
Terra, then The Boss would have to be serious bottom-feeder fodder to
lose this match. This thing is about who's weaker more than it is a
question of strength, though I could easily see The Boss being around
Ocelot's level.<br><br>All this said, the match picture is going to
matter here. Metal Gear Solid has a history of performing like utter
crap when given bad pics. As I see it, there are two possibilities for
this match's picture:<br><br> ONE<br><a class="linkification-ext" href="http://sweb.cz/ChrpaMartin/mgs3/boss.jpg" title="Linkification: http://sweb.cz/ChrpaMartin/mgs3/boss.jpg">http://sweb.cz/ChrpaMartin/mgs3/boss.jpg</a><br>vs<br><a class="linkification-ext" href="http://www.vgmuseum.com/art/ffa/Celes.jpg" title="Linkification: http://www.vgmuseum.com/art/ffa/Celes.jpg">http://www.vgmuseum.com/art/ffa/Celes.jpg</a><br><br>TWO<br><a class="linkification-ext" href="http://img.gamespot.com/gamespot/images/2006/059/reviews/928437_20060301_screen003.jpg" title="Linkification: http://img.gamespot.com/gamespot/images/2006/059/reviews/928437_20060301_screen003.jpg">http://img.gamespot.com/gamespot/images/2006/059/reviews/928437_20060301_screen003.jpg</a><br>vs<br><a class="linkification-ext" href="http://content.answers.com/main/content/wp/en/thumb/c/c4/150px-Celeschere.jpg" title="Linkification: http://content.answers.com/main/content/wp/en/thumb/c/c4/150px-Celeschere.jpg">http://content.answers.com/main/content/wp/en/thumb/c/c4/150px-Celeschere.jpg</a><br><br>If it's the latter, just cancel the match due to how crappy it'll look.<br><br>Prediction: The Boss with 54.26%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br>This
is another one of the most debated matches on the female half of the
bracket &#8211; and for good reason. These two characters, in all likelihood,
will end up being fodder. That makes this somewhat hard to choose when
you just know they&#8217;re going to end up being so weak. So who do the
voters care about more?
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/16/2006 9:24:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335002929">message detail</a>
 | #139</td></tr>
<tr class="even"><td>On one hand there is The Boss. She is one of the
most praised characters ever from the people who have played her game,
Metal Gear Solid 3. While she may not be a main character, she has a
clear focus and presence throughout the game that grabs people, even
moreso when those people watch the ending. Unfortunately, previous
Metal Gear contestants (Solid Snake aside) have shown that she probably
isn&#8217;t going to be worth too much. Revolver Ocelot is around Kefka
strength, Big Boss is around Terra&#8217;s strength and Liquid Snake is
somewhere close to this range as well. It doesn&#8217;t invoke much
confidence when you have other characters who play a significant role
in the series being so weak. <br><br>On
the other hand, Celes Chere comes from a very popular Final Fantasy VI.
Her problem is that this site seems to not care at all for FFVI&#8217;s
characters. Kefka is barely above the fodder level and Terra is fodder.
Two of the most popular characters in the game aren&#8217;t worth very much.
In all likelihood, Celes is going to end up <i>below</i> these two
characters, too. She does get some props for being a Final Fantasy
character this low, and while they doesn&#8217;t mean you&#8217;re going to win,
it&#8217;s always a nice advantage to have when we&#8217;re getting down this
low&#8230;unless you&#8217;re Kuja. <br><br>Looking at the stats, Terra is at
18.65% on BL and Kefka is at 22.71% on BL. Both of these are rather
weak in comparison to the rest of the field, and I would wager that
Celes&#8217;s <i>ceiling</i> is at Terra. But, the issue here is that Terra
may be overrated thanks to that Devil Division last year. If that&#8217;s the
case, she&#8217;s even <i>lower</i> than expected. Big Boss, on the other
hand, is at 17.62% on BL. That puts him near Terra&#8217;s area without even
bringing up the overrated bit. However, Big Boss is likely underrated
due to Samus&#8217;s value given to her in the stats or by SFF with Ganon or
whatever. That puts him in a much better position already. <br><br>Now I think that The Boss could wind up stronger, or <i>at least</i>
equal to, Big Boss. She played a huge role in that game and came away
as many people&#8217;s favorite. Big Boss has little done outside of Metal
Gear Solid 3 &#8211; mentioned in name only in MGS1 and MGS2. On top of that,
Big Boss could have potentially suffered from being given a picture of
his old MGS artwork. Even if Big Boss were stronger, it&#8217;s not by much,
and he should honestly not have too much trouble beating Terra. It
would still be close, but he&#8217;d definitely pull it out for numerous
reasons. <br><br>I just think that The Boss will be the bigger
favorite in the voter&#8217;s minds. Final Fantasy VI characters have not
been impressive in the least, Terra runs the risk of being overrated
(and I view her as the ceiling for Celes), Big Boss is potentially
underrated and I think The Boss is stronger, and it just seems like
people would be bigger fans of her. We&#8217;ll see how it plays out, but I
have complete confidence in The Boss bringing home a well deserved
victory in this contest. <br><br><b>Aitch Emm&#8217;s Bracket:</b> The Boss<br><br><b>Aitch Emm&#8217;s Prediction:</b> The Boss &#8211; 54.2% ; Celes Chere &#8211; 45.8%<br><br><b>Aitch Emm&#8217;s Vote:</b> The Boss *salutes*<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>While
this is a fairly disputed match, there really isn't much to analyze or
write at all. These are both brand new contest entrants who have
starred in exactly one game each. The fact that I've only played one of
the two games in question doesn't exactly make me the best candidate to
share his feelings about this match, but I'll give it a go.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/16/2006 9:24:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335003127">message detail</a>
 | #140</td></tr>
<tr class="even"><td>Surprise, then disappointment. Surprise, then
disappointment. Surprise, then disappointment. No, it's not what
happens when Hank Hill shakes George W. Bush's hand, it's what happens
when we see a FFVI character's match. Kefka has been in four contests
and has somehow managed at least one spectacularly disappointing
performance in each (it can be argued that he didn't do too badly
against Knuckles, but the way he was buried in the day was just sad to
watch).<br>Terra,
one of the game's protagonists, suffered an even worse humiliation at
the hands of Dante. What some were touting as a possible 1/8 upset
turned out to be a pointless 70/30 blowout. Surprise, then
disappointment. Now, it's Celes Chere's turn. While I know next to
nothing about FFVI, I hear that she's one of the game's main
characters, but she's not quite "as main" as Terra. The hell does that
mean? I have no idea, but I'm banking on FFVI's track record to come
through yet again.<br><br>While The Boss won't be strong, I feel some
people are underestimating her. Metal Gear Solid 3 was very successful
and well-received, especially on GameFAQs. The Boss was MGS3's main
antagonist, and fans of the game absolutely adore her. She had a
compelling story, lots of screen time and memorable scenes, and was a
total ****ing badass. I think she'll be a bit weaker than Ocelot, but
that should be more than enough to get her past the first round here.<br><br>My prediction: The Boss def. Celes Chere (54-46)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>This
is the first match I really struggled with when I was filling out my
bracket. The true analyst will compare Celes with Terra, and The Boss
with Big Boss. Last year, Dante and Auron beat each of the respective
latter comparisons with nearly the exact same percentage. So now it's
boiling down to Auron &lt; Dante? Big Boss &lt;= The Boss? Celes !=
Terra!? (Big Boss + Terra) &lt;= (The Boss OR Celes++)!?!? What is this
madness?<br><br>What, did you think I was "the true analyst" I was
talking about? Hell no. I didn't even really notice this when I was
filling the thing out. For me, it boiled down to this: the MGS3 fanbase
<i>adores</i> The Boss. Whereas Celes, like Terra, didn't seem to have that many <i>fans</i>
to me. Yeah, I thought Celes had more&#8230; but man, she's not Kefka. She's
not even Edgar or Sabin or Locke or Mog or&#8230; okay, you get the point.
Yeah, FF6 may be the more popular game, but MGS3 is nothing to sneeze
at! MGS3's big enough to overlook that advantage, and just steal the
votes with the more popular character. That's what I'm saying.<br><br>Oh, I must do my analysis crew duty? Very well&#8230; I'll effortlessly use my <i>riveting powers of analysis</i> to expose the output for all of those inequalities up there&#8230;<br><br>TRUE, TRUE, TRUE, FALSE. Thank you. Thank you. Amazing, I know!<br><br><b>Lopen's Prediction:</b> The Boss with 52.01%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br>The Boss<br><br>lol N/A<br><br>After
a big failed push from last year, the second biggest fan-favorite from
MGS3 (and arguably the second biggest fan favorite in the whole damn
series) makes her debut in the female bracket. I'm not as fond of The
Boss as most, though that's mainly due to a dislike of her character's
actions -- there's no denying her development and complexity, and that
has created a rabid following unlike any other. Ocelot may have
*handgestures*, but The Boss thrives on another thing entirely --
character.<br><br>This will ensure her to be fodder, without a shadow of a doubt. Fortunately for her, her opponent isn't much better off.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/16/2006 9:25:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335003304">message detail</a>
 | #141</td></tr>
<tr class="even"><td>
Celes Chere<br> <br>lol N/A<br><br>Hey, Celes.
Another big fan-favorite, only this time from FF6. While she doesn't
have *quite* the following The Boss does among FF6 fans -- Kefka,
Locke, and Shadow alone all trump her in fan-favoritism, at *least* --
she does happen to be from a more popular game. And she happens to be
playable, which is always nice.<br><br>Gah, damn fodder/fodder matches. Where the hell are Rinoa and Yuffie? &lt;_&lt;<br><br><i>Notable Releases Since Last Appearance</i><br><br>The Boss: Metal Gear Solid 3: Snake Eater (PS2)<br>Celes Chere: Final Fantasy VI/III US (SNES)<br><br><i>Upcoming Releases</i><br><br>The Boss: N/A<br>Celes Chere: N/A<br><br>Okay,
here's my reasoning. Big Boss would beat Terra in a match. If Ganondorf
was SFF'd at all, he's stronger. If Vincent overperformed on Crono at
all, he's stronger. Celes *probably* won't be too far off from Terra.
Maybe that's my own bias speaking (Terra &gt; Celes!) but I wouldn't
expect it to be radically different. The Boss is very hard to gauge
compared to Big Boss, because I'm not exactly sure what the hell people
were voting on in that match. If the main character of MGS3 had been
someone else (just bear with me on this), The Boss would easily be <i>many</i>
times stronger. If the name had said "Naked Snake" and he had an MGS3
picture, The Boss would be guaranteed to be Tanner level. But it's a
combination of both, and it's hard to call.<br><br>Solid Snake is
approximately one bajillion times stronger than any FF6 character.
Liquid would beat Kefka with ease. Raiden possibly could as well.
Ocelot is approximately even with Kefka, and I'd take him in a direct
match. And while I wouldn't take Big Boss to beat Kefka, he should
handle any other character that comes out of FF6, barring a dark horse
showing from someone like Shadow. That leaves The Boss...<br><br>Honestly,
it comes down to MGS3's power, and the ratio of playing it to
completing it on this site. If there's a 75% completion rate, The Boss
takes this with no problem. 50%? Eh. 25% or lower, Celes has this. I
think it's about 60-65%, and that makes me decently favor The Boss in
this matchup and my prediction. See ya on the other side, soldier.<br><br>Karma Hunter's Vote: The Boss. It's just a bracket vote, though. Celes just seems too plain and meh to vote for.<br><br><b>Karma Hunter's Krazy Prediction: The Boss with 52.78%.</b><br> <br>A small win predicted here for safety, but I really think this is going to be a Vergil/Ghaleon affair.<br><br><b>Upset Potential: 45%<br><br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br><br>For
****'s sake, FF6 characters should not be this damn weak. Kefka should
have never been competing with Pac-Man and losing to Diablo/Vercetti
(not to mention he's weaker than he's ever been ATM). Terra should
never have made Dante look like an elite. It goes against the game's
popularity, and unless FF6's hardcore fanbase is just bolstered by
franchise votes that abandon it when their characters are put to the
test...bah. Ensemble cast, Smensemble cast, the fact is I'm scared to
death of a FF6 character coming out and saying, "Hey, *I'm* the popular
one." It could happen now, and combine that with the fact that The Boss
could easily bomb anyway...this match is tough to call. The reason I'm
sticking with MGS is...well, that's what I <i>do.</i> Snake &gt; Link, yo.<br><br>Upset Prediction: Celes Chere with 59.5%.<br> <br><br><br><b>Guest&#8217;s Analysis</b> - <i>Shivan Reincarnated</i><br><br>"Oh my hero, so far away now<br>Will I ever see your smile?<br>Love goes away like night into day<br>It's just a fading dream...<br>I'm the darkness, you're the stars<br>Our love is brighter than the sun.<br>For eternity, for me there can be<br>Only you, my chosen one.<br>Must I forget you?<br>Our solemn promise?<br>Will autumn take the place of spring?<br>What shall I do? I'm lost without you.<br>Speak to me once more...
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/16/2006 9:26:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335003467">message detail</a>
 | #142</td></tr>
<tr class="even"><td>
We must part now. My life goes on,<br>But my heart won't give you up.<br>Ere I walk away, let me hear you say<br>I meant as much to you.<br>So gently, you touched my heart.<br>I will be forever yours.<br>Come what may, I won't age a day.<br>I'll wait for you, always."<br><br>One
of the most debated matches of Round has been The Boss/Celes. The
winner gets the honor of being throttled by Tifa. However the winner
will be the slight underdog Celes. One of the most colloquial arguments
I have heard is the fact that Final Fantsy VI characters are weak and
flop in this contest. This isn't exactly far from the truth and nobody
is denying that. What a lot of people are forgetting is the fact that
Metal Gear characters not named Solid Snake have done just as bad too.
Let's first look at Liquid Snake. In 2004 he sure seemed impressive. He
didn't win a match but he went to the brink with Frog. Liquid Snake was
then exposed in the villains contest after a deplorable win over Lavos
followed by a slaughtering at the hands of Sephiroth. It didn't help
that Frog got eradicated by Samus leaving him not too ahead of Final
Fantasy VI's Kefka in the X-Stats. Ocelot fared no better. He had an
ignominious win over <i>Nemesis</i> and the got beaten soundly by
Bowser. It only got worse for Ocelot as he lost to Pac-Man in Round 1.
The same Pac-Man that Kefka beat. Using the argument of "Ocelot got a
bad picture!" is harebrained. Kefka still defeated Pac-Man as a 12 seed
as Lettuce Kefka. At this time, Lettuce Kefka was really a huge
shocker. It was far worse than "crumpled leaf" Ocelot who at least is
somewhat perceptible . Kefka was the lower seed and only had 43.50% of
the brackets supporting him while Ocelot was a 2 seed and had 61.24%.
There is no excuse. However, the ruminations of Ocelot and Liquid snake
aren't exactly that important to the actual match. I merely used to
them to show that Metal Gear characters not named Solid Snake are weak
too. Now to Celes. Celes should be right around Terra. The only poll
with her is the outdated poll from early 2002.<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=847" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=847">http://www.gamefaqs.com/poll/index.html?poll=847</a><br><br>No,
Celes doesn't impress but she does rank ahead of Edgar and really close
to Terra. Then again, that poll is pretty worthless. It's 4 and a half
years old and got a meager 28,000 votes. People who use this poll to
argue Celes will be weak don't make a whole lot of sense. Look at this
poll -<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=840" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=840">http://www.gamefaqs.com/poll/index.html?poll=840</a><br><br>Bison
does absolutely horrible and guess how he turned out? Stronger than
Kefka. It would be a safe bet to say Celes would rank right around
Terra. Terra was placed as an 8 seed against Dante and was meant to be
fodder. She performed as fodder but I am convinced that she is stronger
than the stats giver credit for. For starters, she had a horrid pick.
Terra is known as the green-haired girl of Final Fantasy VI. This is
not a recognizable Terra. <a class="linkification-ext" href="http://www.gamefaqscontests.com/gallery/displayimage.php?album=6&amp;pos=20" title="Linkification: http://www.gamefaqscontests.com/gallery/displayimage.php?album=6&amp;pos=20">http://www.gamefaqscontests.com/gallery/displayimage.php?album=6&amp;pos=20</a>
. She has blond hair and her pic is the AMV Terra from Final Fantasy
Chronicles. We all know that Kefka doesn't exactly perform well with
his CGI strawberry K.I.S.S. picture. In fact, what was the only time
Kefka impressed? That's right, his match against Wesker in which he had
his sprite, not his amano artwork and not his CGI pic. Kefka absolutely
shredded Wesker with his sprite pic. Only one person in the Oracle
Challenge even picked Kefka to double Wesker, nobody picked him to
score over 70%. Keep in mind that this was after Wesker bombed against
Luca too. Chrono Trigger, a very comparable game to Final Fantasy VI
performs well with sprites. Frog and Magus obviously come to mind. It
wasn't Terra's fault that her amano artwork is as bad as Kefka's and
that her CGI pic shows her with the wrong hair color. It was Round 1,
Terra was placed as fodder and she had no means of getting a good
picture since it was Round 1 which is not the Sprite Round. Terra had
to suffer.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/16/2006 9:27:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335003704">message detail</a>
 | #143</td></tr>
<tr class="even"><td>For Celes, I'm thinking this won't be the case.
She really has two options. She could get her amano artwork which
actually isn't bad by any means. It's recognizable. She could also get
the Final Fantasy Anthology CGI pic which would a lot better than what
Terra got. Of course, I'm not saying Celes is going to be a powerhouse
but I expect her to have enough strength to beat The Boss who I have
little faith in.<br><br>The
Boss is a character exclusive to Metal Gear Solid 3. The best character
to compare The Boss too is not Ocelot or Liquid Snake. Big Boss is the
best character to compare The Boss too but The Boss will not be as
strong as Big Boss. Ocelot and Liquid Snake are not that strong of
characters despite being somewhat major villains. Especially Ocelot,
the guy was in all three Metal Gear Solid games and he still&#8230;. sucked
in a contest setting. Big Boss isn't exactly a minor character either.
Big Boss has a role in Metal Gear, Metal Gear 2: Solid Snake, Metal
Gear Solid, Metal Gear Solid 2 and is the protagonist in Metal Gear
Solid 3. Not to denounce The Boss's role or anything because she was a
major character, but Big Boss has a larger role overall in the MG
universe. Now people have argued that Big Boss would have done better
if he was named Naked Snake. Sure, there's no denying that. Old gruffly
Big Boss was no good for the Metal Gear fans. The thing is, there were
at least some people that voted for Big Boss thinking of Naked Snake.
Diehard Metal Gear fans are not stupid. I don't see The Boss comparing
to Big Boss which is sad because Big Boss did quite badly. Forgive me
if I have little faith in a character that comes from a game that has
sold less than half that of Metal Gear Solid 2. I highly doubt we'll be
seeing either of these characters in a contest setting ever again so
this will be Celes's match to win.<br><br>My Prediction: Celes Chere with 55.98%<br><br><br><br>Summary:
Awesome KotH reference Yo. And uh...Crew has The Boss winning, guest
has Celes winning. Looks like a good representation of Stats topic vs.
Board opinion
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=640243" class="name">Big Bob</a> |
Posted 9/16/2006 9:27:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335003803">message detail</a>
 | #144</td></tr>
<tr class="even"><td>
Hey Moltar, what's your email address?<br><br>I wanted to wait until after Kairi/Claire to send Riku/Yoshi.<br>---<br>September 22nd!  Amy Rose &gt; KOS-MOS<br>Currently Playing: Disgaea: Hour of Darkness, God of War
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/16/2006 9:27:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335003854">message detail</a>
 | #145</td></tr>
<tr class="even"><td>
<i>You guys used to have these things posted six hours ago. Does one of your members live in the UK or something?</i><br><br>I've been busy all day. Cut me some slack...<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Tifa vs. Ivy - Bracket: <b>Tifa</b> - Vote: <b>Ivy</b> (3/4)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/16/2006 9:28:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335004017">message detail</a>
 | #146</td></tr>
<tr class="even"><td>
<a class="linkification-ext" href="mailto:MasterMoltar@gmail.com" title="Linkification: mailto:MasterMoltar@gmail.com">MasterMoltar@gmail.com</a><br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Tifa vs. Ivy - Bracket: <b>Tifa</b> - Vote: <b>Ivy</b> (3/4)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 9/16/2006 9:28:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335004084">message detail</a>
 | #147</td></tr>
<tr class="even"><td>
Go guest analyst!<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/16/2006 9:29:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335004241">message detail</a>
 | #148</td></tr>
<tr class="even"><td>
Holy crap, doth mine eyes decieve me or is the Crew unanimous on this one? Damn it all. <br><br><i>The Boss is so screwed.</i><br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=264094" class="name">Heroic Mario</a> |
Posted 9/16/2006 9:32:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335004970">message detail</a>
 | #149</td></tr>
<tr class="even"><td>
No one else gave a salute? Pfft -- <i>lame!</i><br><br>---<br><i>...a lone figure shining in the toxic shadows. She comes dressed for war, and her wrath is terrible.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/16/2006 9:40:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=335007061">message detail</a>
 | #150</td></tr>
<tr class="even"><td>
Maybe if it were The Fury, I'd have saluted.  The heck with The Boss.  I wouldn't mind seeing Shivan get this point.  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=1">2</a></li>
<li>3</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=9">10</a></li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage3_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30499515&amp;page=2" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
<div id="copyright">
	<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
	<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
	<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
</div>
<script src="genmessage3_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</div></body></html>