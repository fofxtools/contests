<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	



<title>GameFAQs - GameFAQs Contests Message Board</title><meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage9_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage9_files/nogs.css"></head><body linkifytime="280" linkified="2" linkifying="false"><div id="container">
	<div id="gne_nav">
		<img src="genmessage9_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/events/x06/">X06</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage9_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30499515%26page%3D8"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage9_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage9_files/advertisement.gif" alt="advertisement" height="10" width="120"></div>
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage9_files/f.xhtml" marginwidth="0" marginheight="0" hspace="0" vspace="0" allowtransparency="true" frameborder="0" height="90" scrolling="no" width="728">
&lt;script language=javascript&gt;&lt;!-- randNum = ((new
Date()).getTime() % 2147483648) + Math.random(); document.write( "&lt;a
href='http://a.tribalfusion.com/i.click?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID="
+ randNum + "' target=_blank&gt;" + "&lt;img
src='http://a.tribalfusion.com/i.ad?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID="
+ randNum + "'" + " width=728 height=90 border=0 alt='Click
Here'&gt;&lt;/a&gt;"); // --&gt;&lt;/script&gt; &lt;noscript&gt; &lt;a
href="http://a.tribalfusion.com/i.click?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID=1576037958"
target=_blank&gt; &lt;img
src="http://a.tribalfusion.com/i.ad?site=GameSpot&amp;amp;adSpace=ROS&amp;amp;size=728x90&amp;amp;requestID=1576037958"
width=728 height=90 border=0 alt="Click Here"&gt;&lt;/a&gt;
&lt;/noscript&gt; </iframe><img src="genmessage9_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;page=8">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30499515" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=7">Previous Page</a> |
Page 9 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/25/2006 11:38:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336978747">message detail</a>
 | #401</td></tr>
<tr class="even"><td>
Pfft, these consistency rankings are the way to go. I'm what, #1 after today? SCORE<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 9/25/2006 11:51:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336980952">message detail</a>
 | #402</td></tr>
<tr class="even"><td>
<i><b>From DaruniaTheGoron Posted 9/26/2006 12:35:49 AM #399</b></i><br><i>Lopen's number 1 after today, and KH is almost number 1 in consistency.</i><br><br>Consistency is the better gauge.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=152338" class="name">Lopen</a> |
Posted 9/25/2006 11:55:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=336981646">message detail</a>
 | #403</td></tr>
<tr class="even"><td>
Dare you fools spit in the face of <i>tradition</i>?  Hmph!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/26/2006 6:29:47 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337007717">message detail</a>
 | #404</td></tr>
<tr class="even"><td>
Lopen is dead last in Yoblazer's thing, and is winning in Moltar's.  Odd how that happens...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 9/26/2006 7:44:52 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337012106">message detail</a>
 | #405</td></tr>
<tr class="even"><td>
Hit or miss Lopen strikes again!<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 9/26/2006 7:47:22 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337012269">message detail</a>
 | #406</td></tr>
<tr class="even"><td>
<i>I thought Leonhart (or whoever it was in the stats topic) was crazy for actually taking Sonic. </i><br><br>Crazy like a fox! And even crazier this year because Sonic &gt; Male Bracket!<br><br>And
the main reason Lopen is dead last in "consistency" is that he's taken
so many upset picks, and so he's losing points for it. <br>---<br>"...And then they made me their chief." - Captain Jack Sparrow
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=617" class="name">Who Cares?</a> |
Posted 9/26/2006 9:03:14 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337017921">message detail</a>
 | #407</td></tr>
<tr class="even"><td>
<i>Round 2 sign-ups will go up sometime Wednesday I'm guessing. A
seperate topic will be made then (and it will probably be in the
evening for those looking to camp out or something and wait for the
topic to go up).</i><br><br>Good deal...hopefully you'll put this up around 9pm EST?  I'm probably one of the few who wouldn't mind doing a female match.<br>---<br><b>Chun-Li's Road to the Female Final Four</b>: Currently giving Kasumi a Kikoushou to the face!<br>*Just 14 days until Tales of the Abyss*
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 9/26/2006 9:10:30 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337018528">message detail</a>
 | #408</td></tr>
<tr class="even"><td>
I got dibs on Squall/Snake, baby!<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/26/2006 7:10:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337124796">message detail</a>
 | #409</td></tr>
<tr class="even"><td>
Hey Moltar, if you have time could you bump up my prediction by 3.5%? Thanks.<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/26/2006 7:17:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337126468">message detail</a>
 | #410</td></tr>
<tr class="even"><td>
Joanna Dark.......60.23% 60488<br>Cortana..............39.77% 39944<br>TOTAL VOTES..............100432<br><br>65.75% of the brackets predicted this match correctly.<br><br>Joanna is able to pull the 60-40 on Cortana. Pretty boring match, if you ask me. Decent bracket support for Ms. Dark.<br><br>Today, Chun-Li is beating down Kasumi pretty badly.<br><br>Lopen - 4<br>Ulti - 4<br>Moltar - 3<br>KH - 1<br>Yoblazer - 1<br>Guest (Wigs) - 1<br>HM - 1<br><br>That Moltar fellow gets another point.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Chun-Li vs. Kasumi - Bracket: <b>Chun-Li</b> - Vote: <b>Chun-Li</b> (13/14)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=817211" class="name">XxSoulxX</a> |
Posted 9/26/2006 7:18:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337126651">message detail</a>
 | #411</td></tr>
<tr class="even"><td>
I should have kept today's analysis. -_-<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune<br>RIP Eddie Guerrero. 1967-2005. Deputy Chief!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/26/2006 7:21:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337127503">message detail</a>
 | #412</td></tr>
<tr class="even"><td>
Damn, Lopen is dead on again today.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/26/2006 7:26:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337128604">message detail</a>
 | #413</td></tr>
<tr class="even"><td>
Just throwing this out there. I think Yo and I have had the same
percentages for matches about half the time this Contest. I sometimes
change mine a percent or 2, but man, it's starting to get creepy!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Chun-Li vs. Kasumi - Bracket: <b>Chun-Li</b> - Vote: <b>Chun-Li</b> (13/14)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/26/2006 7:27:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337128826">message detail</a>
 | #414</td></tr>
<tr class="even"><td>
yo's stalking you!<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/26/2006 7:28:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337129302">message detail</a>
 | #415</td></tr>
<tr class="even"><td>
Oh, and Soul, I may let you do Lara/Alyx if I don't recieve the analysis for the match by 9:30 PM EST.<br><br>I'm actually curious to hear an argument for Alyx!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Chun-Li vs. Kasumi - Bracket: <b>Chun-Li</b> - Vote: <b>Chun-Li</b> (13/14)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/26/2006 7:34:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337130696">message detail</a>
 | #416</td></tr>
<tr class="even"><td>
<b>Moltar</b>: After looking at that picture for another minute, could you bump up my pick <i>another</i> 3.5% actually? (so 7% total) Thanks again. &lt;_&lt;<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/26/2006 7:39:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337132072">message detail</a>
 | #417</td></tr>
<tr class="even"><td>
Wow, Lopen is real close. Has anyone nailed the percentage on the dot before?<br>---<br>CB06 - Score: <b>13/14 </b>Rank: <b>Tied - 3075th </b>Yesterday's Pick:<b> Cortana</b> <br>Today's Pick: <b>Chun Li</b> Tomorrow's Pick: <b>Lara Croft</b> Losses: <b>Cortana</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/26/2006 7:39:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337132100">message detail</a>
 | #418</td></tr>
<tr class="even"><td>
darn you kh<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Chun-Li vs. Kasumi - Bracket: <b>Chun-Li</b> - Vote: <b>Chun-Li</b> (13/14)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=433611" class="name">ad00</a> |
Posted 9/26/2006 7:42:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337132931">message detail</a>
 | #419</td></tr>
<tr class="even"><td>
Where do I send my write up?<br>---<br>Einstein would turn over in his grave. Not only does God play dice, the dice are loaded.<br>Oracle: 1st / Runner of Winning Streak
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=817211" class="name">XxSoulxX</a> |
Posted 9/26/2006 8:46:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337150574">message detail</a>
 | #420</td></tr>
<tr class="even"><td>
Sent.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune<br>RIP Eddie Guerrero. 1967-2005. Deputy Chief!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/26/2006 8:53:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337152472">message detail</a>
 | #421</td></tr>
<tr class="even"><td>
Who was supposed to do the analysis today?<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=817211" class="name">XxSoulxX</a> |
Posted 9/26/2006 8:54:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337152799">message detail</a>
 | #422</td></tr>
<tr class="even"><td>
XIII is cool, I believe. <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune<br>RIP Eddie Guerrero. 1967-2005. Deputy Chief!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/26/2006 9:11:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337157292">message detail</a>
 | #423</td></tr>
<tr class="even"><td>
<b>Aeon Division:</b> <i>Round 1 - Match 16</i> &#8211; (2)Lara Croft vs. (7)Alyx Vance <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Lara</b><br>Game/Series Known From: Tomb Raider <br>Extrapolated Rank in 2002: 27th (21.80%)<br>Extrapolated Rank in 2003: 37th (22.85%)<br>Extrapolated Rank in 2004: 50th (13.91%)<br>Seed in 2002: 1<br>Seed in 2003: 7<br>Seed in 2004: 15<br>Lost in 2002 to Crono in Round 3<br>Lost in 2003 to Max in Round 1<br>Lost in 2004 to Samus in Round 1<br><br>Ahh, a true example of someone falling from the spotlight over the years.<br><br><b>Alyx</b><br>Game/Series Known From: Half-Life <br><br>Hopefully she ends up with a better reputation than her Half-Life comrade&#8230;but probably won&#8217;t.<br><br>And
we end the female bracket (cheers and such) with Lara vs. Alyx. I know
Lara Croft is crap now, but even name recognition alone should get her
through this match. I mean, look at Gordon. Alyx can&#8217;t be any stronger
than that. Sure, she has Half-Life 2, but still. She&#8217;s a non-playable
character who just assists you. How many decent competitiors have we
seen with that resume (Don&#8217;t answer that)?<br><br>Lara, on the other
hand, has a new (and good! Or so I hear) game out, and as I said
before, Lara Croft is a recognized name among casuals. She shouldn&#8217;t
have too much trouble here with Alyx me thinks.<br><br><b>Moltar&#8217;s Bracket Says:</b> Lara will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Lara: 71% - Alyx: 29%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>When LARA CROFT is primed to score a blowout, you know you ****ing suck. That's all that needs to be said.<br><br>Prediction: Lara with 66.65%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>Now this one blows my mind &#8211; why? <i>Half-Life got another freakin&#8217; character into this contest</i>. Given how poorly Gordon Freeman performed with only <i>one</i>
game under his belt, I&#8217;m not expecting much of anything from Alyx. She
should be above the absolute trash fodder that Manny Calavera and Yuri
are, but she ain&#8217;t going to be too much better either. <br><br>Lara
Croft performed really poorly in 2004, which makes this match something
of a concern (not much, but still), but when one takes into
consideration Tomb Raider Legends this removes all worry. It was given
plenty of positive remarks from critics and the game sold really well.
Added to that, it released on practically every system out right now &#8211;
from PlayStation 2 to Xbox 360 &#8211; <i>and</i> that Lara Croft usually
always makes these contests and she should do fine. I&#8217;m glad we&#8217;re done
with fodder v. fodder matches here though. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Lara Croft<br><br><b>Aitch Emm&#8217;s Prediction:</b> Lara Croft &#8211; 60% ; Alyx Vance &#8211; 40%<br><br><b>Aitch Emm&#8217;s Vote:</b> Lara Croft<br> <br> <br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>I'm
extremely pressed for time, so I'll make this quick. Lara Croft has
taken a huge fall from grace over the years, but she still has a
healthy number of games and is recognizable by nearly every gaming fan
on the Internet. Her opponent, Half-Life 2's Alyx Vance, simply doesn't
have that resume. She may come from the more popular game, but she's
hardly the star. The fact that most Half-Life fans simply don't care
about her and all other voters don't even know who she is will prove to
be her painful undoing.<br><br>My prediction: Lara Croft def. Alyx Vance (73-29)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/26/2006 9:12:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337157468">message detail</a>
 | #424</td></tr>
<tr class="even"><td>
<b>Lopen&#8217;s Analysis</b><br> <br><i>Finally</i> these women's matches
are over. I was really getting bored for a while there. I know, it
really cut into my quality. This match? It also bores me. Tomb Raider:
Some Game came out recently, and I guess it might give Lara a boost or
something. Uh&#8230; I don't know. It's not like she'll need it to defeat <i>Alyx Vance</i>.
This girl is from a game in which the main character gets defeated by
the likes of Tina Armstrong and Max Payne. Well, with Gordon Freeman
likely getting a win this year, I guess he needed to try and pass the
torch. Alyx Vance never wins? AVNW?<br><br>I guess it <i>could</i>
work, you know&#8230; if Alyx Vance had a snowball's chance in hell at ever
being seen again. You know what, I think I was too harsh to Marle a few
matches ago. Sure, I hate her&#8230; and sure&#8230; she doesn't have TJF and much
of the CT fanbase hate her&#8230; but at least she has <i>some</i> fans. I'm sure she'd crush Alyx Vance with 70%+. But no, on second thought, I won't say Marle <i>shouldn't</i>
have been replaced by Dizzy&#8230; I'll just get greedy, that's more my
style. Jam Kuradoberi should've been here instead of Alyx Vance!<br><br>Actually, I give Alyx a <i>slight</i>
chance to upset&#8230; very slight. Just because I think Tomb Raider hate
might be at an all time&#8230; but the recent Tomb Raider: Some Game, makes
it pretty unlikely. If I did Karma Hunter's thing I'd be like&#8230; "upset
chance: 2%" "Upset pick: Alyx Vance with 50.25%". But I <i>don't</i> do his thing, I know he wouldn't appreciate it&#8230; he'd want me to step off.<br><br><b>Lopen's prediction:</b> Lara Croft with 59.89% (continuing Freeman's time-honored above 40% tradition!)<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br> <br>Lara Croft<br> <br>Summer 2002 Contest<br>Extrapolated Strength --- 27th Place [21.80%]<br> Summer 2003 Contest<br>Extrapolated Strength --- 37th Place [22.11% ]<br>Summer 2004 Contest<br>Extrapolated Strength --- 53rd Place [13.91% ]<br> <br>Whoa,
Lara Croft? Uh, didn't we ban you from contests after 2004? Um, well,
hello again. Got a new game? Well, that's wonderful...um...<br> <br><i>Lara Croft?</i><br> <br>Alyx Vance<br> <br>lol N/A<br> <br>Wow, I am absolutely shocked that a side-character in <i>Gordon Freeman's</i> game got into the contest. This is a character I could seriously see Tanner beating head-to-head... <br> <br><i>Notable Releases Since Last Appearance</i><br><br>Lara Croft: Tomb Raider: Legend (Multi)<br>Alyx Vance: Half-Life 2 (PC)<br><br><i>Upcoming Releases</i> <br><br>Lara Croft: N/A<br>Alyx Vance: N/A<br> <br>Well,
the thing about this match is...no, no, forget it, I can't do this
anymore. For the love of all that is good and holy, WHY DID WE HAVE TO
HAVE A FEMALE BRACKET CEEJ? WHY??? At least the Villains Contest was in
the Spring, where I could safely ignore it! But this is taking up half
of the freaking character battle! It's not interesting, it's not funny,
it's just <i>boring!</i><br> <br>Sure, I'm whining. Sure, I'm
complaining, despite the fact that you hold these battles for us every
year (which I *am* actually grateful for). But it doesn't mean that you
don't have bad ideas. Games Contest by era? Bad idea. 2k4 bracket? Bad
idea. Female half? BAD IDEA.<br> <br>Who's up next? Solid Snake? Yeah,
stay right there. And you? Soma Cruz? Get yo' bad self over here. I
want you two to go at it, like, mercilessly. I want you two to put on a
clinic, have an insanely great match the likes of Halo/Starcraft could
not touch. I want to see over 500,000 total votes in your match, I want
it to seem like Google's giving linkage here. And then all the rest of
you guys? I want the <i>exact</i> same thing out of you. I want the
biggest voting matches, the greatest upsets, I want the Best. Contest.
EVER. to make up for what I've just had to sit through.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/26/2006 9:12:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337157624">message detail</a>
 | #425</td></tr>
<tr class="even"><td>And at the end of it all? Whoever comes out of it
-- I don't care if it's Crono or CATS -- I want you to break 99% on the
Female Champ, just so she and every single other female looks downright
pathetic compared to you guys. I want this to be a referendum that
states from every single GFAQs user that we will <i>not</i>
tolerate Lara/Alyx ever again!!! You're not a damn 2 seed Lara, you're
the thing that a real 2 seed breaks 80% on! darn you cjay darn you cjay
darn you cjay<br> <br>Karma Hunter's Vote: SNAAAAAAAAAAAAAAAAAAAAAAAAAAAAKE<br><br><b>Karma Hunter's Krazy Prediction: Lara Croft with 73.27%.</b><br> <br>Jeezus,
this could go anywhere...well, Ryo broke 40% on Lara back in the day,
but Alyx is likely a good deal weaker than Hazuki. But Lara may not get
as many anti-votes now as well (think Mario/Master Chief)...though she
certainly seems to be weaker as of 2k4. Hmm...well, let's meet 'em
halfway. Not quite the doubling, but close enough.<br><br>Upset Potential: 5%<br> <br>No way I'm giving Croft a free pass in any match after what we've seen out of her, but this is about as good as it gets.<br> <br>Upset Prediction: Alyx Vance with 55.21%<br> <br> <br><br><b>Guest&#8217;s Analysis</b> - <i>XxSoulxX</i><br><br>The match that <i>everyone</i>
has been waiting for. I hope everyone is prepared for the biggest upset
of the contest. Bigger then Knux &gt; Magus! Bigger then Hand &gt;
Thong-boy! Bigger then Mario &gt; Cloud &gt; Link!<br><br>Since 2002
and 2003 don't matter anymore (increase in votals and a new shift in
voting preference), let's skip all the way to 2004. This year is
significant because this was Lara's last year in the contest. She
managed to grab a 15 seed, and ran straight into Samus in the first
round. Before I get into that match, look at her seed in that contest
compared to her other ones. In 2002, she was given a 1 seed because of
her "iconic" status. She got her ass kicked. She let Chop Chop Master
Onion (You can search for this guy all you want, you still won't know
who he is) get over 30% on her! She followed up with allowing Ryo
Hazuki to get over 40% on her, then by getting less then 30% against
Crono. Ok, she finished not to bad, but she still stunk it up for two
rounds. This tells me that she does not deserve any sort of high seed
in these contests.<br><br>2003 came along, and the site was focused on
Square and everything related to that company. Lara only received
enough nominations to get a 7 seed. In 2004, she got a 15 seed. She was
snubbed in 2005. See a pattern here? Her "fan base" basically fell off
the face of this earth. So, how exactly did she get a 2 seed in this
contest? Blame it on the crappy nomination system. I bet that many
people were scratching their heads, trying to come up with the 7 female
characters. Any would do. Hell, I nominated a freaking porn star that
appears in one picture on one of the most obscure games ever! Of
course, most people would nominate who they remember. Therefore, Lara
would get a lot of nominations that way.<br><br>Yes, she's higher then
Alyx Vance, but like someone on Board 8 said: "Who the **** is Alyx
Vance and how did she end up in this contest?!". She got in on strength
alone, baby! I'll tell you that people didn't have to think long before
nominating her. The point I'm trying to make is that the seeding means
nothing. Lara is as weak as Crash Bandicoot. She deserves a very low
seed to match her strength.<br><br>One needs to look no further then
her 2004 match against Samus to prove how weak Lara really is. 17.61%.
Lara Croft only got 17.61% against Samus. She couldn't even break 20%!
And you can't deny that's her real strength, because Samus lost to
Cloud, who lost to Link. There was nothing fishy in those stats.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/26/2006 9:13:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337157895">message detail</a>
 | #426</td></tr>
<tr class="even"><td>We all know Lara is weak as ****. Anyone who says
otherwise hasn't been here very long. Many people predict that even
though Lara is weak as hell, it would be enough to beat Alyx Vance.
They believe that Alyx is as weak as Tanner. Well, this is to be
expected. It's Board 8! When someone asks for 5 PC games, most would
have to search the site for names. They basically have no clue who Alyx
is.<br><br>Frankly,
I don't feel the need to educate you on her personality or anything
like that. All that you have to know is that she isn't hated, and
there's no reason to dislike her. She's the semi-star of Half-Life 2
(with Gordon Freeman) and the main character in Half-Life 2: Episode 1.
Sure, she's not playable, but she's recognizable to everyone who has
played HL2.<br><br>How weak is Alyx? Weak. I'll be the first to admit
it. She's probably fodder. But, she'll be strong enough to beat Lara
Croft. Sure, Lara has Legend that was somewhat popular. If people are
expecting her to boost to her 2003 levels, they're in for a huge
surprise. She was falling in 2004, and she continued to fall throughout
2005, I believe. Her new game stopped her from falling, and probably
boosted her up to around her 2004 level again. But really, as good as
Legend was, people have forgotten completely about it. Ask anyone
that's not named XIII is cool, and you'll see. Hardly anyone has played
it here. I don't believe that there has been 1 topic talking about that
game before this contest. It was that unknown! The board right now is
pretty much dead. <i>Came and went in a blink of an eye!</i> I'm being
pretty generous with boosting her up to her 2004 level. I could see her
being even weaker. Also, it doesn't help that her picture is of her
before Legend.<br><br>Alyx will be stronger. Why? Because Gordon
Freeman is a hell of a lot stronger then her (67% before Episode 1).
I'm predicting Gordon gets around 70% on Lara Croft. Alyx is like the
Luigi to Gordon Freeman. She's his partner that kicks ass! The
difference between Mario and Luigi is the same difference between
Gordon and Alyx. Difference is though that Alyx appears on Gordon's
most popular game, while Luigi doesn't in Mario's most popular game. I
could see her falling between that 70%. In fact, I don't see how she
couldn't fall within that 70%. She's definitely weaker then Gordon, but
she can't be that much weaker. To compare, this would be like Link and
random green haired elf in Kokiri forest. There is no way a main
character will be that much weaker then Gordon Freeman.<br><br>Of course, can't forget the Lara Croft anti-votes!<br><br>And
really, that's the way I see it. I've been ridiculed for the past few
days, but in a few hours, I believe I'll have my revenge on all of you
doubters! And if I'm wrong, then so be it.<br><br><b>My prediction: Alyx Vance wins with 50.01%. I need 6 more words for 1000!</b><br><br> <br> <br>Crew Consensus: Majority goes with Lara Croft. Percentages are all over the place though. Oh, and Soul...good luck with that!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3685859" class="name">PartOfYourWorld</a> |
Posted 9/26/2006 9:15:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337158338">message detail</a>
 | #427</td></tr>
<tr class="even"><td>
By the way, that wasn't my mathematical snafu, was it, MOLTAR?
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/26/2006 9:15:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337158438">message detail</a>
 | #428</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>In my opinion - and I don't
think I'm alone - in that match picture, Alyx Vance looks like the most
generic female video game character ever. And, well......she's up
against Angelina Jolie.<br><br>My vote: Lara Croft<br>My bracket: Lara Croft<br>My prediction: Lara Croft with 77%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3685859" class="name">PartOfYourWorld</a> |
Posted 9/26/2006 9:16:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337158490">message detail</a>
 | #429</td></tr>
<tr class="even"><td>
*inserts dramatic music*
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=817211" class="name">XxSoulxX</a> |
Posted 9/26/2006 9:16:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337158686">message detail</a>
 | #430</td></tr>
<tr class="even"><td>
You guys are so screwed!<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune<br>RIP Eddie Guerrero. 1967-2005. Deputy Chief!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/26/2006 9:18:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337159193">message detail</a>
 | #431</td></tr>
<tr class="even"><td>
<i>By the way, that wasn't my mathematical snafu, was it, MOLTAR?</i><br><br>How about we pretend it is<i>!!</i><br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Chun-Li vs. Kasumi - Bracket: <b>Chun-Li</b> - Vote: <b>Chun-Li</b> (13/14)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 9/26/2006 9:19:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337159431">message detail</a>
 | #432</td></tr>
<tr class="even"><td>
Hey Moltar, female bracket is almost up. About time to start picking second round guest writers no?<br><br>Dibs on Kirby/Zero &lt;_&lt;<br><br><b>TuRtLe</b><br>~~~<br>I used my brain and statistics to make my bracket. Karma Hunter used MGS fanboyism. KH won. <b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3657433" class="name">LusterSoldier</a> |
Posted 9/26/2006 9:51:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337168224">message detail</a>
 | #433</td></tr>
<tr class="even"><td>
<i>My prediction: Lara Croft def. Alyx Vance (73-29)</i><br><br>Someone messed up on their math.<br>---<br><b>Luster Soldier</b> - Pwned by Repus_Yortsed<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=433611" class="name">ad00</a> |
Posted 9/26/2006 10:43:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337179602">message detail</a>
 | #434</td></tr>
<tr class="even"><td>
Still awaitin the email or wherever to send Moltar the write up for SS/Soma =P<br>---<br>Einstein would turn over in his grave. Not only does God play dice, the dice are loaded.<br>Oracle: 1st / Runner of Winning Streak
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/26/2006 11:17:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337186293">message detail</a>
 | #435</td></tr>
<tr class="even"><td>
Lopen just 1/4 of a percent off last match, damn.<br><br>And here, ad00; from earlier in the topic:<br><a class="linkification-ext" href="mailto:MasterMoltar@gmail.com" title="Linkification: mailto:MasterMoltar@gmail.com">MasterMoltar@gmail.com</a><br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/26/2006 11:24:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337187552">message detail</a>
 | #436</td></tr>
<tr class="even"><td>
<i> From: BlAcK TuRtLe </i><br><i>Hey Moltar, female bracket is almost up. About time to start picking second round guest writers no?<br><br>Dibs on Kirby/Zero &amp;lt;_&amp;lt;<br><br><b>TuRtLe</b></i><br><br>He said he's going to post a topic wednesday night for signups.<br>---<br>CB06 - Score: <b>14/15 </b>Rank: <b>Tied - 2815th </b>Yesterday's Pick:<b> Chun Li</b> <br>Today's Pick: <b>Lara Croft</b> Tomorrow's Pick: <b>Solid Snake</b> Losses: <b>Cortana</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=721959" class="name">Karma Hunter</a> |
Posted 9/26/2006 11:26:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337187758">message detail</a>
 | #437</td></tr>
<tr class="even"><td>
I sure hope Lara keeps this up, 'cause I need another point to get me back into contention in Moltar's dum rankings =P<br><br>(though I'll be on top in yo's after today for sure WOO)<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/26/2006 11:31:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337188687">message detail</a>
 | #438</td></tr>
<tr class="even"><td>
Chun-Li vs. Kasumi<br>+7 Lo<br>+6 Mo<br>+5 KH<br>+4 HM<br>+3 Ulti<br>+2 Yo<br>+1 Guest<br><br><b>The Rankings</b> (Through Chun-Li vs. Kasumi)<br>1. UltimaterializerX (67)<br>2. Karma Hunter (65)<br>3. Master Moltar (62)<br>4. Heroic Mario (61)<br>5. Yoblazer (53)<br>6. Lopen (47)<br>7. Board 8 (45)<br><br>And
Board 8 is now in last place, getting passed up by Lopen (who has
already gotten like 46 matches wrong). This means one thing and one
thing only: you n00bs better get your acts together before you even
think about smack talkin' The Crew.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=254355" class="name">Lugia2</a> |
Posted 9/27/2006 6:24:19 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337218193">message detail</a>
 | #439</td></tr>
<tr class="even"><td>
Well, Alyx is done.  Sorry Soul.  Is <i>this</i> why you're not in the crew any-<br><br>Oh, wait.  Mr. "Gannon will defeat Mega Man" is still in.  Ah, well...<br><br>Soul, you were kidding though, right?<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3662060" class="name">YoAriel33</a> |
Posted 9/27/2006 4:02:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337289225">message detail</a>
 | #440</td></tr>
<tr class="even"><td>
Lara Croft vs. Alyx Vance<br>+7 KH<br>+6 Yo<br>+5 Mo<br>+4 Ulti<br>+3 HM<br>+2 Lo<br>-1 Guest<br><br><b>The Rankings</b> (Through Lara vs. Alyx)<br>1. Karma Hunter (72)<br>2. UltimaterializerX (71)<br>3. Master Moltar (67)<br>4. Heroic Mario (64)<br>5. Yoblazer (59)<br>6. Lopen (49)<br>7. Board 8 (44)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3050550" class="name">TheKoolAidShoto</a> |
Posted 9/27/2006 4:04:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337289834">message detail</a>
 | #441</td></tr>
<tr class="even"><td>
LOL at Board 8. <br><br>DIBS ON GORDON/PHOENIX<br>---<br>Edited TNT Kill Bill line: "Buck: My name's Buck, and I'm here to (completely different voice) screw!"
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/27/2006 4:42:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337298749">message detail</a>
 | #442</td></tr>
<tr class="even"><td>
Chun Li.......................68.74% 71706<br>Kasumi......................31.26% 32611<br>TOTAL VOTES.....................104317<br><br>73.87% of the brackets predicted this match correctly.<br><br>Chun-Li
has no trouble here, as she's able to easily take out Kasumi. Looks
like this only further shows how useless the 2002 stats are today. <br><br>Today, Alyx...can't look any worse than she is. I mean, blown out against <i>Lara</i>?<br><br>Lopen - 5<br>Ulti - 4<br>Moltar - 3<br>KH - 1<br>Yoblazer - 1<br>Guest (Wigs) - 1<br>HM - 1<br><br>Hit for Lopen! Hit for Lopen!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Lara vs. Alyx - Bracket: <b>Lara</b> - Vote: <b>Lara</b> (14/15)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=3605206" class="name">wavedash101</a> |
Posted 9/27/2006 4:47:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337299963">message detail</a>
 | #443</td></tr>
<tr class="even"><td>
Hit or Miss Lopen strikes again!!!<br><br>---<br><b>Our shields cannot withstand wavedashing of this magnitude!</b><br>Board 8's Unofficial Master of the Phoenix Down
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/27/2006 9:07:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337364551">message detail</a>
 | #444</td></tr>
<tr class="even"><td>
<b>Patriot Division:</b> <i>Round 1 - Match 17</i> &#8211; (1)Solid Snake vs. (8)Soma Cruz <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Snake</b><br>Game/Series Known From: Metal Gear Solid <br>Extrapolated Rank in 2002: 9th (35.23%)<br>Extrapolated Rank in 2003: 8th (35.90%) <br>Extrapolated Rank in 2004: 11th (27.74%) - Adjusted Value: 12th (30.82%)<br>Extrapolated Rank in 2005: 8th (33.88%)<br>Seed in 2002: 2<br>Seed in 2003: 1<br>Seed in 2004: 2<br>Seed in 2005: 1<br>Lost in 2002 to Crono in the Elite 8<br>Lost in 2003 to Mega Man in the Elite 8<br>Lost in 2004 to Mega Man in the Elite 8<br>Lost in 2005 to Mario in the Final 4<br><br>Solid Snake leading the males. That&#8217;s awesome<br><br><b>Soma</b><br>Game/Series Known From: Castlevania<br><br>Soma Cruz makes his first Contest appearance here.<br><br>OH GOD YES! The female half is finally over! At least for now it is. First match on the male side is Snake vs. Soma. <br><br>Alright,
it isn&#8217;t much to start off with, but we&#8217;ll have to make due. Soma Cruz
probably won&#8217;t even be near Alucard in strength, and even if he was,
he&#8217;d still be no match for Snake. That&#8217;s not to say Soma will end up
like crap though. He should do decent enough. Also, with Snake looking
to be his strongest yet, this should be a good indicator of how well of
a chance he stands in the later rounds.<br><br><b>Moltar&#8217;s Bracket Says:</b> Snake will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Snake: 78% - Soma: 22%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br><br>It's
about goddamn time we see the men in action. I don't even care that the
first five matches are mortal locks. A female bracket is something we
never need to see again.<br><br>As for this match, uh... easy blowout
win for Snake despite Soma being awesome. What more can be said? The
only real thing we'll see here is Soma's position in relation to
Alucard's. I'd consider it a moral victory if Soma broke 30%, but I
doubt he does. His two roles are both on handhelds.<br><br>Prediction: Snake with 71.17%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br><br>We are <i>finally</i> finished with that horrifically dull female half &#8211; hallelujah! I have been waiting for this match for a <i>long</i>
time&#8230;yes, I know it&#8217;s a 1v8 match that has absolutely no shot at being
remotely interesting and will in all likelihood be another blowout &#8211;
but it features at least one good character! <br><br>Solid Snake is
coming out strong after this year&#8217;s E3, where a brand-new Metal Gear
Solid 4 trailer was shown and he was announced as a character in the
new Super Smash Bros. As a result, it appears that people have placed a
<i>ton</i> of confidence in him to take the entire bracket, at least if
the Top 50 is any indication. He should no doubt come out looking good
with his match against the untested Soma Cruz. <br><br>If I had to
wager, I would guess that Soma is actually a bit below Alucard&#8217;s
ranking in 2005, which is a bit off thanks to the strange match between
Snake/Sora. He should end up not being too bad, but clearly nowhere
near enough to even make this match remotely interesting. <i>Solid Snake is so taking out Mega Man</i>. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Solid Snake<br><br><b>Aitch Emm&#8217;s Prediction:</b> Solid Snake &#8211; 74% ; Soma Cruz &#8211; 26%<br><br><b>Aitch Emm&#8217;s Vote:</b> Solid Snake<br> <br> <br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Holy
****, men! Glorious men! Tough, burly, hairy, *glances at Soma*
effeminate, soft-spoken, smooth-skinned men! Watch out, girls; the boys
are back, and who better to kick off this beer drinking, chain smoking,
ass kicking sausage fest than the #1 badass in all of gamedom, Solid
Snake!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/27/2006 9:08:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337364775">message detail</a>
 | #445</td></tr>
<tr class="even"><td>As everyone here already knows, Snake is having
one hell of an outstanding year. Much like Link and (the then unnamed)
Twilight Princess did in 2004, Snake completely stole this year's E3,
dropping our jaws with MGS4 and then rocking our faces with his
surprise appearance in SSBB. He's high as a box-shaped kite and twice
as deadly, and I think with this double dose of super hype and the
recent release of MGS3: Subsistence, this could potentially be Snake's
best contest yet.<br><br>His
opponent, Some Cruz, is pretty weak stuff. He has starred in two
handheld Castlevania titles - one for the GBA and one for the DS.
Honestly, that's all I know about him, and for the sake of this match,
that's all anyone really needs to know. However, we still need to get
some sort of gauge on his strength to see how well Snake will do.<br><br>The
best strength indicator we have for Soma is Simon Belmont, who made his
lone contest appearance in 2002. According to pretty much any set of
X-Stats you use, Snake is projected to beat him somewhere between
75-77%. Now, I'm going to go high here for two reasons:<br><br>1. I
don't think Soma will be quite as strong as Belmont, who was the
series' first hero and has a recognizable name in his own right. <br>2.
I think Snake is coming into this contest very beloved by both the Sony
and Nintendo faithful. Obviously, this will help, especially when it
comes to squeezing out those last few percentage points from weaker
foes.<br><br>Prove me right, Snake. Prove me right.<br><br>My prediction: Solid Snake def. Soma Cruz (80-20)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>I
give Solid Snake the best shot at blowing out fodder of the weakest
sort out of anybody. No anti-votes, pretty well known, Snake's got it
all. He really should be the one going against Tingle, I think. He's
kinda wasted here. Why? Because I want to see Snake shut down a fool
90-10, and instead he's gonna shut down a fool 75-25.<br><br>What's
that? It's because I don't think Soma's the kind of fodder we want
here. In fact, I completely blame Soma for Castlevania's beating of
Halo that I didn't see coming. Yeap. Because I said to myself&#8230; if it's
that much more popular than Symphony of the Night, where is the support
coming from? The NES and SNES games? Yeah, they help, but that much? I
think the meat of that extra ground is coming from the newer Gameboy
games. Dawn of Sorrow, Aria of Sorrow, Dandelion Field of Sorrow. You
know, those games that feature our little buddy Soma. So I think he'll
have a decent fanbase out there, enough to avoid being destroyed. And
they're recent, too! That's all to the good!<br><br><b>Lopen's prediction:</b> Solid Snake with 75.78%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>SOLID SNAKE</b><br> <br><i>"Find something to believe in. And find it for yourself. And when you do, pass it on to the future."</i><br> <br>Summer 2002 Contest<br>Extrapolated Strength --- 9th Place [35.23%]<br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 8th Place [34.74%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 12th Place [30.82%]<br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 9th Place [33.88%]<br> <br>The
legend. The man who makes the impossible possible. The greatest
character to EVER exist, and that's before you get to the good stuff.
It's Solid Snake, people! SNAAAAAKE! And not only is he making another
deserved return to the GameFAQs Contests after his stellar Final Four
appearance last year, but he perhaps has the most potential out of any
contestant we've ever seen for the future. Metal Gear Solid 4 and,
AMAZINGLY, SSBB??? Unbelievable, and you can bet the main man's going
to be an absolute force when these hit --<br> <br>-- wait, not until mid-to-late 2007? Uh...on second thought, there's no time like the present. Snake for 2k6 Champ! WOO SNAKE<br><br><b>SOMA CRUZ</b><br> <br><i>"Having power doesn't mean you can abuse it. Haven't you learned your lesson?"</i><br> <br>N/A
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/27/2006 9:09:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337365052">message detail</a>
 | #446</td></tr>
<tr class="even"><td>
And up against the operative is the indomitable Castlevania breakout
star known as Soma Cruz!!! After a good-sized push from the board and
his fans to make it here, we're finally graced with the first
Castlevania protagonist not named Alucard since 2002. Simon Belmont
would be proud! Or something. Anyway, he's in an unwinnable match, so
his big objective here is to do respectably enough to get support for a
second go-around in this thing. And since this is a GBA/DS character
against a primarily PS1/PS2 character, there shouldn't be too much SFF
here (though people will blame "Konami SFF" if there's an
underperformance).<br> <br>But hey -- he made it, and should be happy -- he's in the male bracket. That means that he doesn't suck! WOO SOMA<br><br><i>Notable Releases Since Last Appearance</i><br><br>Solid Snake: Metal Gear Solid 3: Subsistence (PS2), Super Smash Brothers Brawl Trailer (Internet)<br>Soma Cruz: Castlevania: Aria of Sorrow (GBA), Castlevania: Dawn of Sorrow (DS)<br><br><i>Upcoming Releases</i><br><br>Solid Snake: Metal Gear Solid 4: Guns of the Patriots (PS3), Super Smash Brothers Brawl (WII)<br>Soma Cruz: N/A<br><br>Man,
this is a great match. I mean, Snake's a one seed and the top of the
male bracket. And Soma made into a contest, so that's cool too! There
should be lots of votes, making up for the atrocity that's happening
right now. The picture is decent, and for a match involving Snake
that's generally considered a miracle nowadays. I'm liking all of this.
Happiness for everyone!<br> <br>...oh, uh, match commentary? What?<br><br>Karma Hunter's Vote: <b>VOTE SNAKE</b><br><br><b>Karma Hunter's Krazy Prediction: Solid Snake with 80.22%.</b><br> <br>I'm going to suffer massively every single match thanks to overrating Snake. I don't particularly care.<br><br>Upset Potential: 0%<br> <br>SNAKE IS INVINCIBLE<br><br> <br><br><br><b>Guest&#8217;s Analysis</b> - <i>ad00</i><br><br>After
16 (not-so) exciting days of female bracket fun, most regulars are
eagerly looking forward to the start of the second half of the bracket
for excitement and upsets. Unfortunately for them, they likely won't
find it in this particular match.<br><br>The male contest starts off by
pitting a board and site favorite, Solid Snake, to contest newcomer and
hero of the latest Castlevania outings, Soma Cruz, inheritor of
Dracula's powers.<br><br>Solid Snake, of Metal Gear Solid fame, is an
old hand of the contest, part of the noble nine, and essentially a lock
for winning his division, and some say possibly taking the male side of
the bracket this year. It is doubtful, but that possibility will start
to be gauged by seeing just how well he does in this match.<br><br>While
many expect this match to be a blowout from a strong character pitted
against first-time fodder, I predict Soma to actually do respectfully
in this. Castlevania has emerged as a bit of a dark horse in these
contests. From Alucard's haphazard performances, to Castlevania beating
Halo and nearly edging out Kingdom Hearts in the BSE contest, the
series is a fan favorite, and draws very little animosity.<br><br>Focusing
specifically on Soma, many had been clamoring for his inclusion in the
contest since Aria of Sorrow came out, and doubly so when Dawn of
Sorrow became one of the first must-have DS titles very early in its
life cycle. The character is likeable, and as a hero drawing his power
from the source he came to eradicate, is almost a kind of anti-hero, on
par with Alucard.<br><br>But he is not Alucard, and the Sorrow games
lack the nostalgia appeal of SotN. Oh, and he's facing Snake. However
between the rallying to get him in, and the simple fact he is a strong
lead from a popular series, he should hold his own against even Snake.
Unfortunately for Soma, Snake shares his same strengths: great
character in a loved series, drawing no anti-votes.<br><br>Oracle Prediction: Snake with 77.77%<br>Revised Prediction: Snake with 75%<br><br> <br>Crew Consensus: Snake FTW! 70% range seems to be what we think.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=768178" class="name">Master Moltar</a> |
Posted 9/27/2006 9:10:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337365379">message detail</a>
 | #447</td></tr>
<tr class="even"><td>
Oh, and since I'm kind of busy tonight, I'll make the Round 2 female half sign-ups tommorrow evening.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Lara vs. Alyx - Bracket: <b>Lara</b> - Vote: <b>Lara</b> (14/15)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=508292" class="name">DpObliVion</a> |
Posted 9/27/2006 9:18:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337367362">message detail</a>
 | #448</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Without question, Solid
Snake would easily beat Alucard in a match. So poor Soma Cruz stands
absolutely no chance against the cardboard-covered soldier.<br><br>My vote: Solid Snake<br>My bracket: Solid Snake<br>My prediction: Snake with 84%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 9/27/2006 9:30:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337370037">message detail</a>
 | #449</td></tr>
<tr class="even"><td>
Can you only sign up for one match in the entire round, or 2 matches, one for female and one for male?<br>---<br>CB06 - Score: <b>14/15 </b>Rank: <b>Tied - 2815th </b>Yesterday's Pick:<b> Chun Li</b> <br>Today's Pick: <b>Lara Croft</b> Tomorrow's Pick: <b>Solid Snake</b> Losses: <b>Cortana</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30499515&amp;user=617" class="name">Who Cares?</a> |
Posted 9/27/2006 9:31:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30499515&amp;message=337370450">message detail</a>
 | #450</td></tr>
<tr class="even"><td>
iirc, you can only sign up for one per round &amp; first dibs for next
round goes to people who haven't already done a guest writeup.<br>---<br><b>Chun-Li's Road to the Female Final Four</b>: Kasumi's been Kikoushou'D! Awaiting next victim!<br>*Just 13 days until Tales of the Abyss*
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=7">8</a></li>
<li>9</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499515&amp;page=9">10</a></li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage9_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30499515&amp;page=8" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
<div id="copyright">
	<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
	<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
	<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
</div>
<script src="genmessage9_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</div></body></html>