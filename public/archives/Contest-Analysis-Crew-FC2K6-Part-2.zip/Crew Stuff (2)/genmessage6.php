<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage6_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage6_files/nogs.css"></head><body linkifytime="220" linkified="4" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage6_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/afterhours/">After Hours</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage6_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30854544%26page%3D5"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage6_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage6_files/advertisement.gif" alt="advertisement" height="10" width="120"></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage6_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage6_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 2
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;page=5">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30854544" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=4">Previous Page</a> |
Page 6 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=6">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=264094" class="name">Heroic Mario</a> |
Posted 10/8/2006 11:48:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339712969">message detail</a>
 | #251</td></tr>
<tr class="even"><td>
<i>You don't know how good that makes me feel, HM!</i><br><br>What was that? Huh? <i>!!</i><br><br>---<br>"<i>Master using it and you can have this.</i>"<br><a class="linkification-ext" href="http://img90.imageshack.us/img90/160/masterjg3.jpg" title="Linkification: http://img90.imageshack.us/img90/160/masterjg3.jpg">http://img90.imageshack.us/img90/160/masterjg3.jpg</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/8/2006 11:50:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339713563">message detail</a>
 | #252</td></tr>
<tr class="even"><td>
HM and I are in a tight race for closest prediction....it's right in
the middle. Of course, we have no outside competition to worry about,
hehe.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=795464" class="name">Tatl</a> |
Posted 10/9/2006 12:46:48 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339723238">message detail</a>
 | #253</td></tr>
<tr class="even"><td>
<i>I've got unwavering confidence in the plumber!</i><br><br>And it is rightfully placed...<br><br>Luigi is <b>BREAKING HIS CURSE THIS YEAR!</b><br><br>I've been saying it sense day one and no one has believed he would get passed Zero.<br><br>Look at your glorious Zero now!<br>---<br>"I reject your reality and substitute my own." ~ Adam Savage; Insanity Personified<br>"Crikey!" ~ Steve Irwin (R.I.P.); Perfection Personified
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=264094" class="name">Heroic Mario</a> |
Posted 10/9/2006 2:09:32 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339732968">message detail</a>
 | #254</td></tr>
<tr class="even"><td>
Never doubt the plumber's skillz!<br><br>---<br>"<i>Master using it and you can have this.</i>"<br><a class="linkification-ext" href="http://img90.imageshack.us/img90/160/masterjg3.jpg" title="Linkification: http://img90.imageshack.us/img90/160/masterjg3.jpg">http://img90.imageshack.us/img90/160/masterjg3.jpg</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/9/2006 2:12:08 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339733202">message detail</a>
 | #255</td></tr>
<tr class="even"><td>
DAMN IT!<br><br>I deserve the point! I called it.<br><br>If
I were a member of the crew, this would be 2 in a row for me, and that
makes me better than Yoblaze. I get the next one right, and you should
drop that monkey and let me in &gt;_&lt;;
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3793953" class="name">TehMissingLink</a> |
Posted 10/9/2006 4:17:39 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339741121">message detail</a>
 | #256</td></tr>
<tr class="even"><td>
Predicting the winner doesn't necessarily get you the point though. &gt;&gt;<br><br>---<br>"<i>Looking good, Princess, especially from this angle!</i>"
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/9/2006 4:18:57 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339741183">message detail</a>
 | #257</td></tr>
<tr class="even"><td>
<i>What was that? Huh? !!</i><br><br>*stabs you with a dinglehopper*<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=378235" class="name">Mario Man53245</a> |
Posted 10/9/2006 5:21:20 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339743822">message detail</a>
 | #258</td></tr>
<tr class="even"><td>
tag<br>---<br>"Nothing helps a bad mood like spreading it around" - Calvin
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=683142" class="name">transience</a> |
Posted 10/9/2006 5:27:08 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339744043">message detail</a>
 | #259</td></tr>
<tr class="even"><td>
good thing I wasn't up to write an analysis today!<br><br>um um um HAHAHA ZERO PICKERS<br>---<br>Query
"Results" failed: You have an error in your SQL syntax. Check the
manual that corresponds to your MySQL server version for the right
syntax to use near ' WHERE Gordon.IsWinner = True AND Predic <b>|| </b>Winner: Strider Hiryu - 57.11%
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=254355" class="name">Lugia2</a> |
Posted 10/9/2006 5:37:09 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339744444">message detail</a>
 | #260</td></tr>
<tr class="even"><td>
*Sees Poll*<br><br>GAH!  If Luigi breaks the 4000 barrier, than I will lose ANOTHER point!  <br><br>I guess Luigi is the new Knuckles.  He never loses the first round...<br><br>You know what?  The Female bracket REALLY sucks.  The Male one is full of cool matches that can make half the board go loco.<br><br>Oh, and HM?  You may have won this match (it's still not certain), but I refuse to believe that Ganon would have beaten Sonic<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3605206" class="name">wavedash101</a> |
Posted 10/9/2006 9:25:34 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339759453">message detail</a>
 | #261</td></tr>
<tr class="even"><td>
HM STRIKES BACK!!!<br>---<br><b>Our shields cannot withstand wavedashing of this magnitude!</b><br>Board 8's Unofficial Master of the Phoenix Down
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/9/2006 10:10:53 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339765103">message detail</a>
 | #262</td></tr>
<tr class="even"><td>
Well, if this holds up, than I will have something accomplished over
the entire Crew: I have predicted the winner right in every match.<br><br>I don't have a perfect bracket........but in my predictions, I've picked the winner right each time.<br><br>*laughs at Crew and brags*<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/9/2006 10:26:58 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339767339">message detail</a>
 | #263</td></tr>
<tr class="even"><td>
Man, I've missed all three of the debated first round matches.<br><br>*plays The Blues on his snarfblatt*<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/9/2006 11:16:58 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339775067">message detail</a>
 | #264</td></tr>
<tr class="even"><td>
Hey, yo, how does it feel to be in dead last? Grand I'm sure! <br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/9/2006 4:01:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339827472">message detail</a>
 | #265</td></tr>
<tr class="even"><td>
<i>HM STRIKES BACK!!!</i><br><br>Damn straight<i>!!</i><br><br>---<br><i>"Looking good, Princess, especially from this angle!</i>"
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/9/2006 4:08:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339829024">message detail</a>
 | #266</td></tr>
<tr class="even"><td>
KH, you're the only one in here not in the Guru Contest.....what's your
bracket looking like? Did you miss any others besides today? Just
curious.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/9/2006 4:30:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339834496">message detail</a>
 | #267</td></tr>
<tr class="even"><td>
I *was* perfect until today (=(). Fortunately, I have Kirby &gt; Zero.<br><br>In
addition to this, I have Aeris &gt; Zelda, Chun-Li &gt; Yuna, Yoshi
&gt; Dante, Snake &gt; Mega Man, Crono &gt; Samus, and Cloud &gt; Link<br><br>...yup!<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3568989" class="name">heroic tranny</a> |
Posted 10/9/2006 4:31:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339834707">message detail</a>
 | #268</td></tr>
<tr class="even"><td>
I'm glad you went nuts, because you might be my main competition with that Aeris pick!<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/9/2006 4:32:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339834873">message detail</a>
 | #269</td></tr>
<tr class="even"><td>
Hmm.....I have 2 of those.  Aeris &gt; Zelda and Yoshi &gt; Dante are the 2 upsets I'm banking on.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/9/2006 4:33:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339835045">message detail</a>
 | #270</td></tr>
<tr class="even"><td>
<i>In addition to this, I have Aeris &gt; Zelda, Chun-Li &gt; Yuna,
Yoshi &gt; Dante, Snake &gt; Mega Man, Crono &gt; Samus, and Cloud &gt;
Link</i><br><br>Whoa. <i>All</i> of those are wrong. Crazy, man!<br><br>---<br><i>"Looking good, Princess, especially from this angle!</i>"
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=152338" class="name">Lopen</a> |
Posted 10/9/2006 4:36:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339835724">message detail</a>
 | #271</td></tr>
<tr class="even"><td>
A pitiful attempt at a lie, KH.  Like anyone would buy you doubting the <i>King of SFF</i>!<br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=981127" class="name">Cavalier Lowen</a> |
Posted 10/9/2006 4:38:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339836176">message detail</a>
 | #272</td></tr>
<tr class="even"><td>
Looks like KH is going to be losing an awful lot of points in the next rounds with those picks (except Yoshi&gt;Dante), ouch!<br>---<br>Z1mZum owned me in the guru contest (by two points!).  Damn you Z1mZum!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/9/2006 4:47:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339838390">message detail</a>
 | #273</td></tr>
<tr class="even"><td>
Kirby.................................61.7% 75274<br>The Prince of Persia.....38.3% 46729<br>TOTAL VOTES........................122003<br><br>72.24% of the brackets predicted this match correctly.<br><br>Kirby
doesn't destroy The Prince like many thought. Perhaps Prince really is
stronger than Kratos? Either way, looks like EC may have found a strong
contender! (That's right, I'm giving him all the credit!)<br><br>Today, Luigi is beating Zero....can't say I predicted that.<br><br>Lopen - 7<br>Moltar - 5<br>KH - 5<br>Ulti - 4<br>Guest (Wigs, SilverNightmareX7, EC) - 3<br>HM - 3<br>Yoblazer - 2<br><br>2 points in a row for the Guest? What in the world?<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Luigi vs. Zero - Bracket: <b>Zero</b> - Vote: <b>Zero</b> (25/27)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=731135" class="name">WiggumFan267</a> |
Posted 10/9/2006 4:50:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339839301">message detail</a>
 | #274</td></tr>
<tr class="even"><td>
HAY GET OFF MY PROPERTY!!<br><br><br>*Casts Leyline of Singularity*<br><br><br><br>.....Oops.<br><br><br>---<br><i><b>Wigs (Now w/ 100% Less Fan!): ~Helping Bald People Since 1987~</b></i><br>Sonic's Victory Path: 2nd Victim: <i>Vince</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/9/2006 5:09:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339843906">message detail</a>
 | #275</td></tr>
<tr class="even"><td>
<i>Oh, and HM? Do you ever wonder if your pick may just be wrong?</i><br><br><b>WEEGI TIME!</b><br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 2</i>: W, 52-14 vs. Etna
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/9/2006 5:12:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339844537">message detail</a>
 | #276</td></tr>
<tr class="even"><td>
Credit is all mine!<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/9/2006 8:29:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339897681">message detail</a>
 | #277</td></tr>
<tr class="even"><td>
<b>Time Division:</b> <i>Round 1 - Match 29</i> &#8211; (1)Crono vs. (8)Captain Falcon<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Crono</b><br>Game/Series Known From: Chrono Trigger<br>Extrapolated Rank in 2002: 7th (37.43%)<br>Extrapolated Rank in 2003: 6th (38.14%) <br>Extrapolated Rank in 2004: 6th (37.18%) <br>Extrapolated Rank in 2005: 5th (36.54%)<br>Seed in 2002: 5<br>Seed in 2003: 4<br>Seed in 2004: 3<br>Seed in 2005: 2<br>Lost in 2002 to Mario in the Final 4<br>Lost in 2003 to Mario in the Elite 8<br>Lost in 2004 to Link in the Elite 8<br>Lost in 2005 to Mario in the Finals<br><br>That Goku-look alike finally gets his 1-seed!<br><br><b>Falcon</b><br>Game/Series Known From: F-Zero<br><br>Capt. Falcon makes his first Contest.<br><br>Another
rally character makes it, but in a wasted spot. Crono shouldn&#8217;t have
any trouble showing Falcon his moves here. Falcon may do decently, but
F-Zero isn&#8217;t too big on GameFAQs. SSB is though, and like Ness, that&#8217;s
where most of Falcon&#8217;s strength will probably come from. Speaking of
Ness, what would he get on Crono?<br><br><i>Ness (2005c) VS Crono (2005c)<br><br>Ness has a strength of 20.53.<br>Crono has a strength of 39.87.<br><br>Crono wins with 74.25% of the vote! <br>A win of 45,025 with 92,820 total votes cast.</i><br><br>Now add in Falcon being a bit stronger (because I can&#8217;t see Falcon losing to Ness, underrated or not) and&#8230;<br><br><b>Moltar&#8217;s Bracket Says:</b> Crono will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Crono: 73% - Falcon: 27%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>Crono is a lock here, but chalk down one more character from SSBM that's finally made a contest! Updated list of who's missing:<br><br>Falco<br><br>Marth<br><br>Ice Climbers<br><br>Jigglypuff<br><br>Roy<br><br>G&amp;W<br><br>(I don't count Sheik, Doc Mario, Young Link or Pichu for obvious reasons)<br><br>Prediction: Crono with 75%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>We are here today, ladies and gentlemen, with two <i>fierce</i>
guys! In one corner, we have the silent Crono with his slick bandana
and fire red hair! In the other, we have the Champion to end all
Champions; the man who makes winning bold, <i>CAPTAIN FALCON!</i> <br><br>&#8230;This match doesn&#8217;t need an analysis; it needs an <i>interview</i>. Behold. <br><br>Q: Got a message for your rivals?<br><br>A: I'm coming! <br><br>Q: What do you plan to do with the prize money?<br><br>A: Begin construction on the Neo Blue Falcon. <br><br>Q: Will you show us your face?<br><br>A: Beat me in a race, and I'll show you. <br><br>Q: Can I have your autograph?<br><br>A: Of course! *signs autograph* <br><br>Q: Got a message for your viewers?<br><br>A: I'll race anyone, anytime. <br><br>Q: Why did you become an F-Zero racer?<br><br>A: I was born to be an F-Zero racer! <br><br>Q: Nice F-Zero machine!<br><br>A: The Blue Falcon is the fastest machine on the circuit! <br><br>Q: Is it true that you are thinking about retiring?<br><br>A: Of course not. There are still rivals to be defeated. The battle is just beginning. <br><br>Q: What was the key to your victory?<br><br>A: Winning isn't about being lucky, it's about being bold. <br><br>Q: Think I could become a racer?<br><br>A: You're quite sharp, aren't you? You'd make a good racer. <br><br>Q: What's a pilot's essence?<br><br>A: The heart! (Falcon hits his chest) <br><br>Q: Listen to that crowd! Your fans love you!<br><br>A: *pumps fist in air* Yeeaaah! <br><br>Q: What do you do when you're not racing?<br><br>A: Chase prize money - I'm a bounty hunter! <br><br>Q: Congratulations on your stunning victory!<br><br>A: Thank you! *strikes pose* I couldn't have done it without my fans! <br><br>Q: Congratulations on your expert win!<br><br>A: Now you see the genius of the Falcon!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/9/2006 8:30:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339897818">message detail</a>
 | #278</td></tr>
<tr class="even"><td>
If there were any justice in this world, Captain Falcon would beat the <i>crap</i> out of Crono and shock the world by breaking the Noble Nine himself. We&#8217;re talking about a <i>true</i> champion right here. If you aren&#8217;t voting for Falcon come match time, you are <i>scum!</i> <br><br><b>Aitch Emm&#8217;s Bracket:</b> Crono<br><br><b>Aitch Emm&#8217;s Prediction:</b> Crono &#8211; 74% ; Captain Falcon &#8211; 26%<br><br><b>Aitch Emm&#8217;s Vote:</b> CAPTAIN FALCON<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>After
four years of waiting, Crono finally has his much deserved 1-seed. He
begins his quest for a contest title against the almost sure-to-be
strongest 8-seed in the bracket, Captain Falcon. Now, Crono won't have
any trouble here, but he certainly won't cruise to as easy a victory as
the other top seeded characters have seen; Falcon is just too much.
After all that we've recently, there's no way in hell I'm ever going to
doubt Super Smash Bros.' strength and influence unless it gives me a
damn good reason to, and Captain Falcon is a very popular star in both
of the series's games. For a 1/8 match, this shouldn't be too big a
blowout.<br><br>My prediction: Crono def. Captain Falcon (69-31)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Just imagine, for a second, that Captain Falcon was the star of Chrono Trigger instead.<br><br>*At the Millennial Fair, CF sees Marle*<br><b>Captain Falcon:</b> Show me your moves!<br>*Marle,
being the fool she is, takes this as an invitation to charge into
Captain Falcon. She is knocked unconscious immediately upon collision
with his beefy physique*<br>*Captain Falcon grabs a pendant off the ground*<br><b>Captain Falcon:</b> Yes! *thumbs up*<br><br>Captain Falcon casually leaves, and Marle is never seen again! <i>Yeeaaahh!</i><br><br>"She
got her ass kicked by Aeris, leave her alone already!" Okay&#8230; okay&#8230; I
know you're tired of the Marle hating&#8230; I've brought her up in three
write-ups already&#8230; but&#8230; but&#8230; it's fun, damn it! Okay, how about this?
Captain Falcon could be used to repair plot-holes! Surely you've
wondered <i>why</i> Gato randomly went into song and dance at the Millennial Fair, right? With Captain Falcon, it'd no longer be a mystery!<br><br>*Captain Falcon approaches Gato*<br><b>Captain Falcon:</b> Show me your moves!<br><b>Gato:</b> They call me Gato, I have metal joints, Beat me up, And earn 15 Silver Points (waah, I can't put music notes here)<b>Captain Falcon:</b> Yes!  *thumbs up*<br><br>See? Mystery solved! Gato was just following orders to show him his moves!<br><br>What?
Whaddaya mean Captain Falcon says more than "Show me your moves" and
"Yes!"? Give me a break! I've played every game in his series, that is,
both of the Smash Brothers games. That's all he says when he isn't
attacking! Really! He has yet to master the English language, with only
a few words in his vocabulary. I know this to be true. If Smash had a
story mode it'd totally go into depth on this!<br><br>Okay&#8230; okay, there
was a point to that whole bunch of nonsense, aside from amusing me. And
that was&#8230; the casual fan only knows of Captain Falcon as that guy in
Smash Brothers. Here we'll <i>really</i> see what happens when all you
have is the support of being playable in Smash. (Ness has Earthbound!
Small, but there!) How much is it? Better than Master Hand, but still
not much, I'm guessing. Kinda interesting for a 1v8 match, though.<br><br><b>Lopen's Prediction:</b> Crono with 78.49%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>CRONO</b><br><br><i>"Humans are such fragile, disjointed, imperfect things."</i><br>Summer 2002 Contest<br>Extrapolated Strength --- 7th Place [37.43%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 6th Place [38.14%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 5th Place [37.18%]<br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 6th Place [36.54%]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/9/2006 8:31:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339898037">message detail</a>
 | #279</td></tr>
<tr class="even"><td>
While historically the member of the NN whose strength has perplexed me
for years, Crono has earned my respect as an absolute force in these
things. The odds-on favorite to take the male half and with
not-too-shabby odds at taking the male bracket, Crono is looking for
another deep run in this battle. WOO CRONO<br><br><b>CAPTAIN FALCON</b><br><br><i>"You think YOU can beat me?! NO WAY!!!"</i><br>N/A<br> <br>Captain Falcon is one of those characters that you sorta wonder why they haven't got into the contest yet when freaking <i>Ness</i>
has made the cut. Nevertheless, with a healthy board rally the toughest
Nintendo bounty hunter around (take THAT Samus) is here...as a no-hoper
8 seed. Oh, well. Looking to do good so that he'll get some nom-support
for next year, etc, blah blah blah...<br> <br><i>Notable Releases Since Last Appearance</i><br> <br>Crono: N/A<br>Captain Falcon: Super Smash Brothers (N64), Super Smash Brothers Melee (GC)<br><br><i>Upcoming Releases</i><br>Crono: N/A<br>Captain Falcon: Super Smash Brothers Brawl (WII)<br> <br>...yeah, I never got any of that Ness &gt; Falcon junk. Um...Crono wins?<br> <br>Karma Hunter's Vote: Captain Falcon. FALCONNNNNNNNNNN VOTE!<br><br><b>Karma Hunter's Krazy Prediction: Crono with 72.18%.</b><br><br>I expect Falcon to show me some decent moves here!<br><br>Upset Potential: 0%<br><br>Yup.<br><br><br><br><b>Guest&#8217;s Analysis</b> - <i>TheRye</i><br><br>A match that is not really in dispute. <br><br><b> &#8220;&#8230;&#8221; &#8211;Crono </b>
Not only has Crono made appearances in every Summer Contest, but has
finished with extrapolated strengths of between 5th and 7th in each of
those contests. He is the prohibitive favorite to win the Male division
of the contest and is the sexy dark-horse pick to oust Samus in the
finals. The silent protagonist of Chrono Trigger has waged war against
Mario in all 4 previous summer contests and is looking to make it 5
with a Battle Royale trip this year. <br><br><b> &#8220;Show me your moves!&#8221; &#8211;Captain Falcon </b>
Captain Falcon is completely new to the contest, and drew an 8-seed
from a heavy board-nomination movement. Known as much for his
appearance in the Super Smash Brothers series as he is for his role in
the F-Zero series, the Captain hopes to rely on supporters of both to
at least keep this match from becoming embarrassing. <br><br>I assume that the rest of the Gurus will be taking care of the entire list of extrapolated history of Crono. <br><br><b> Intangibles: </b> <br><i> Picture advantage </i> <br><br>I think it&#8217;s safe to assume that CJay will be using these pictures for the match-pic (if not, probably something very similar). <br><br>Crono:<br><br><a class="linkification-ext" href="http://www.kikouken.com/comics/ct/crono.gif" title="Linkification: http://www.kikouken.com/comics/ct/crono.gif">http://www.kikouken.com/comics/ct/crono.gif</a> <br><br>Captain Falcon:<br><br><a class="linkification-ext" href="http://content.answers.com/main/content/wp/en/thumb/5/58/250px-Captain_Falcon.jpg" title="Linkification: http://content.answers.com/main/content/wp/en/thumb/5/58/250px-Captain_Falcon.jpg">http://content.answers.com/main/content/wp/en/thumb/5/58/250px-Captain_Falcon.jpg</a> <br><br>With
these photos, there might be a slight shift towards Captain Falcon
(based on a more similar look to his game than his opponent). Nothing
of real significance. This isn&#8217;t going to be a picture of
Terra/Kerrigan (original) proportions or anything. <br><br><i> SFF? </i>s<br><br>Probably non-existent, as there is really no overlap between fanbases of the racing/fighting and RPG genres. <br><br>TheRye&#8217;s bracket: Crono over Captain Falcon<br><br>TheRye&#8217;s prediction: Crono with 74.3%<br><br>TheRye&#8217;s
vote: Captain Falcon (what can I say, I&#8217;ve been campaigning for him to
get into the contest for the last year, I&#8217;m just happy he&#8217;s here)<br> <br> <br> <br>Crew Consensus: Crono wins the match, but Falcon doesn't end up looking too badly.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/9/2006 8:32:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339898610">message detail</a>
 | #280</td></tr>
<tr class="even"><td>
HM owes his CF interview fanboyism to <i>me</i>, and don't you all forget it!<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3605206" class="name">wavedash101</a> |
Posted 10/9/2006 8:34:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339899075">message detail</a>
 | #281</td></tr>
<tr class="even"><td>
HM analysis = uber win sundae with awesomesauce on top!<br>---<br><b>Our shields cannot withstand wavedashing of this magnitude!</b><br>Board 8's Unofficial Master of the Phoenix Down
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3568989" class="name">heroic tranny</a> |
Posted 10/9/2006 8:38:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339900396">message detail</a>
 | #282</td></tr>
<tr class="even"><td>
HM was born to be on the analysis crew!<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=254355" class="name">Lugia2</a> |
Posted 10/9/2006 9:06:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339908266">message detail</a>
 | #283</td></tr>
<tr class="even"><td>
Great Analyses!  Man, I forgot how you guys did at your best!<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3568989" class="name">heroic tranny</a> |
Posted 10/9/2006 9:16:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339910842">message detail</a>
 | #284</td></tr>
<tr class="even"><td>
transience's analysis:<br><br>I'm one of the
biggest F-Zero fans on this board and I really don't care about Captain
Falcon. he's a racing game character! (insert Tanner reference) who
plays racing games for characters? cause if they did, they'd see one of
the most unintentionally funny characters ever. the voice acting in
F-Zero GX is pretty much the only uplifting thing about Captain Falcon.<br><br>fortunately,
he's got SSBM behind him. like most people, I see CF as being similar
to Ness. SSBM alone is just about enough to get a character to the
fodder line, so CF will do okay for himself. add to it that Crono is
slightly "niche" and I think CF impresses and scares people who took
Crono to win the male bracket. they shouldn't be worried based on being
a couple percent off on a character they've never seen, but I could see
CF doing to Crono what Axel did to Mega Man.<br><br>Prediction: Crono with 70.56%<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/9/2006 9:18:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339911555">message detail</a>
 | #285</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>*dusts off my shoulder*<br><br>I
should just spend this analysis bragging about my Luigi pick in both
bracket and analysis (nice try, HM), since we got a boring 1 vs. 8
match here. But I guess I've had my fill of that so far. Wait,
no.....HAHAHAHA!!! Ok, now I've had my fill.<br><br>Anyway, it's cool
and all that Captain Falcon got in, too bad he will serve as nothing
more than fodder to Crono though. But you never know, he could put up a
surprising percentage with the SSB-factor.<br><br>My vote: Captain Falcon<br>My bracket: Crono<br>My prediction: Crono with 79%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/9/2006 9:23:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339912767">message detail</a>
 | #286</td></tr>
<tr class="even"><td>
Once again, despite not checking anyone else's predictions first, I end
up with either the highest or lowest percentage. And I thought <i>I</i> was overrating Captain Falcon....<br><br>On a side note....<br><br>Does anyone else think Captain Falcon sounds like he's saying "So be a moose!" in SSBM instead of "Show me your moves!"<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3605206" class="name">wavedash101</a> |
Posted 10/9/2006 9:24:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339913166">message detail</a>
 | #287</td></tr>
<tr class="even"><td>
Nope<br>---<br><b>Our shields cannot withstand wavedashing of this magnitude!</b><br>Board 8's Unofficial Master of the Phoenix Down
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/9/2006 9:25:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339913320">message detail</a>
 | #288</td></tr>
<tr class="even"><td>
Hmm, HM beats me for the undisputed point for Luigi/Zero. 59% I picked,
yeah......I guess you could say I went a little overboard there.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/9/2006 9:32:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339915345">message detail</a>
 | #289</td></tr>
<tr class="even"><td>
*points at comment made regarding Luigi winning with 53.17%*<br><br>undisputed my furry butt.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3052691" class="name">satai_delenn</a> |
Posted 10/9/2006 9:41:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339917739">message detail</a>
 | #290</td></tr>
<tr class="even"><td>
<i>Captain Falcon casually leaves, and Marle is never seen again! Yeeaaahh!</i><br><br>XD<br><br>Woo!!<br>---<br>Beating
FE5 and FE6 hard mode is a true test of manhood in the Japanese
culture. However. This explains why they have a lot of effeminate men.
~Sytha
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3605206" class="name">wavedash101</a> |
Posted 10/9/2006 9:43:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339918236">message detail</a>
 | #291</td></tr>
<tr class="even"><td>
^OMG where'd Marle go!!!!????<br>---<br><b>Our shields cannot withstand wavedashing of this magnitude!</b><br>Board 8's Unofficial Master of the Phoenix Down
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=826224" class="name">DiabloDrummer</a> |
Posted 10/9/2006 9:44:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339918639">message detail</a>
 | #292</td></tr>
<tr class="even"><td>
Bah, you don't count, Silver.<br><br>: )<br><br>---<br><i>Michelangelo didn't use the paint bucket</i> - tranny<br><b>*DpOblivion*</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/9/2006 9:45:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339918840">message detail</a>
 | #293</td></tr>
<tr class="even"><td>
Oh, and allow me to take the high spot over you for this one Dp.<br><br>Crono wins, 82.17%. Captain Falcon does not break 20% on Crono.<br><br>Crono,
has gotten a little weaker. But not on the level many of you guys are
indicating. Much like you guys overrated Zero, you guys are overrating
Falcon.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=981127" class="name">Cavalier Lowen</a> |
Posted 10/9/2006 9:45:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339918870">message detail</a>
 | #294</td></tr>
<tr class="even"><td>
And my analysis had Weeg with 54.56.<br><br>I'd say it's more between me and Silver than either of you guys.<br>---<br>Z1mZum owned me in the guru contest (by two points!).  Damn you Z1mZum!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=826224" class="name">DiabloDrummer</a> |
Posted 10/9/2006 9:48:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339919531">message detail</a>
 | #295</td></tr>
<tr class="even"><td>Well, I'm not gonna go all over Board 8 to find
the absolute best prediction. When I say "undisputed," I mean the Crew
+ just me. Cause I'm like, the unofficial member, kinda.<br><br>---<br><i>Michelangelo didn't use the paint bucket</i> - tranny<br><b>*DpOblivion*</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/9/2006 11:19:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339940619">message detail</a>
 | #296</td></tr>
<tr class="even"><td>
Ganondorf vs. Vincent Valentine<br>+7 Guest<br>+6 KH<br>+5 Ulti<br>+4 Lo<br>-1 Mo<br>-2 Yo<br>-3 HM<br><br>Kirby vs. The Prince of Persia<br>+7 Guest<br>+6 KH<br>+5 Mo<br>+4 Yo<br>+3 Ulti<br>+2 HM<br>+1 Lo<br><br>Luigi vs. Zero<br>+7 HM<br>-1 Ulti<br>-2 Yo<br>-3 Mo <br>-4 KH<br>-5 Guest <br>-6 Lo<br><br><br><b>The Rankings</b> (Through Luigi vs. Zero)<br>1. Karma Hunter (129)<br>2. Master Moltar (113)<br>3. Heroic Mario (106)<br>4. UltimaterializerX (103)<br>5. Yoblazer (99)<br>6. Board 8 (79)<br>7. Lopen (76)<br><br>We're
not even half done with this contest, and KH already seems to have
clinched it. I'd normally be somewhat frustrated, but if I can drop the
political correctness for a second, watching a fellow minority dominate
the traditionally white sport of Internet Video Game Polls Margin of
Victory Predictions just feels good. <br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3490877" class="name">Sir Auron</a> |
Posted 10/9/2006 11:24:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339941563">message detail</a>
 | #297</td></tr>
<tr class="even"><td>
Given what I have seen of KH's bracket, he's <i>hardly</i> clinched it at this point. &gt;&gt;<br><br>---<br>"That's a cruel, rotten, disgusting idea -- and I love it!"
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 10/10/2006 1:34:52 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339959314">message detail</a>
 | #298</td></tr>
<tr class="even"><td>
LOL ANALYSIS CREW. Man Board 8 got serv'd yesterday.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, PW:AA, KH:COM (Sora), Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/10/2006 3:20:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340036867">message detail</a>
 | #299</td></tr>
<tr class="even"><td>
<i>Crono wins, 82.17%. Captain Falcon does not break 20% on Crono.<br><br>Crono,
has gotten a little weaker. But not on the level many of you guys are
indicating. Much like you guys overrated Zero, you guys are overrating
Falcon.</i><br><br>Oops...<br><br><i>Given what I have seen of KH's bracket, he's hardly clinched it at this point. &gt;&gt;</i><br><br>Truth!!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Crono vs. Capt. Falcon - Bracket: <b>Crono</b> - Vote: <b>Falcon</b> (25/28)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/10/2006 3:23:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340037637">message detail</a>
 | #300</td></tr>
<tr class="even"><td>
Luigi................53.71% 69851<br>Zero................46.29% 60207<br>TOTAL VOTES............130058<br><br>71.81% of the brackets predicted this match correctly.<br><br>Ouch,
the casuals spanked us with that percentage. This almost makes up for
their stupid picks of Kratos &gt; Ryu. Anyway, Zero is beaten by Luigi.
I guess his numbers last year on Mario were legit, and he may still be
falling. Luigi, on the other hand, is finally starting to show he isn't
a chump.<br><br>Today, Falcon is fighting to not get tripled by Crono.<br><br>Lopen - 7<br>Moltar - 5<br>KH - 5<br>HM - 4<br>Ulti - 4<br>Guest (Wigs, SilverNightmareX7, EC) - 3<br>Yoblazer - 2<br><br>Gotta give it to HM. He's the only one on the Crew to predict a Luigi win. Crew bracket would be -1 now.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Crono vs. Capt. Falcon - Bracket: <b>Crono</b> - Vote: <b>Falcon</b> (25/28)
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=4">5</a></li>
<li>6</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=9">10</a></li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage6_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30854544&amp;page=5" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage6_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>