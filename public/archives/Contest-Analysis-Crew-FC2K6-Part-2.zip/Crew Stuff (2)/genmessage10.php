<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage10_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage10_files/nogs.css"></head><body linkifytime="230" linkified="0" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage10_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/afterhours/">After Hours</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage10_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30854544%26page%3D9"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage10_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage10_files/advertisement.gif" alt="advertisement" height="10" width="120"></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage10_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage10_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 2
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;page=9">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30854544" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=8">Previous Page</a> |
Page 10 of 10
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/13/2006 6:44:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340702691">message detail</a>
 | #451</td></tr>
<tr class="even"><td>
[This message was deleted at the request of the original poster]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/13/2006 6:45:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340703037">message detail</a>
 | #452</td></tr>
<tr class="even"><td>
Saturday evening? there goes my chance of a round 2 match!<br><br>maybe it's best that way, I look like a genius today and there's nowhere to go but down!<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/13/2006 6:50:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340703988">message detail</a>
 | #453</td></tr>
<tr class="even"><td>
Meh, actually, I might be busy tommorrow.<br><br>They'll go up in a few hours.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Master Chief vs. Sub-Zero - Bracket: <b>MC</b> - Vote: <b>MC</b> (28/31)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 10/13/2006 6:52:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340704307">message detail</a>
 | #454</td></tr>
<tr class="even"><td>
A few hours? Well, there goes my chances of getting Snake/Squall.<br>---<br><b>Squall Leonhart's Road to the Character Battle V Championship</b>:<br><i>Round 1</i>: Status of Tidus - <b>LIONHEART'D</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/13/2006 6:52:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340704329">message detail</a>
 | #455</td></tr>
<tr class="even"><td>
So like midnight-ish? Darn you moltar. Oh well, 2/2 makes me look smart, maybe it's better I don't go again.<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/13/2006 6:54:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340704798">message detail</a>
 | #456</td></tr>
<tr class="even"><td>
Hey now, there's still a chance if no one who hasn't done one before signs up! (Or signs up and then forgets/doesn't do it.)<br><br>And I was thinking in between 9-10 PM EST.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Master Chief vs. Sub-Zero - Bracket: <b>MC</b> - Vote: <b>MC</b> (28/31)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3602792" class="name">Garsha_III</a> |
Posted 10/13/2006 7:58:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340717686">message detail</a>
 | #457</td></tr>
<tr class="even"><td>
Moltar, you think you could rise Samus's percentage by 1? Just a change.<br>---<br>!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/13/2006 9:20:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340734471">message detail</a>
 | #458</td></tr>
<tr class="even"><td>
Alright, and male half round 2 sign-ups topic has been posted.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Master Chief vs. Sub-Zero - Bracket: <b>MC</b> - Vote: <b>MC</b> (28/31)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/13/2006 9:27:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340736014">message detail</a>
 | #459</td></tr>
<tr class="even"><td>
<b>Spazer Division:</b> <i>Round 2 - Match 33</i> &#8211; (1)Samus vs. (4)Ada Wong <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Samus</b><br>Round 1 &#8211; 81.85% vs. Nidoran F (18.15%)<br><br>Samus makes easy work out of Nidoran F.<br><br><b>Ada</b><br>Round 1 &#8211; 75.89% vs. Jade (24.11%)<br><br>Ouch, Jade is uber-fodder.<br><br>Well,
the woman in the red dress now faces the bounty hunter in the orange
suit. Not much to debate here, as Samus should have no troubles beating
Ada. Perhaps though, she&#8217;ll fare a little better than I originally
thought because of her impressive numbers on Jade.<br><br>&#8230;Or Samus
will do just as well and both Ada and Jade end up looking super weak.
Samus needs to impress soon though, as her Nidoran F numbers don&#8217;t say
&#8220;Bracket Winner&#8221; to me.<br><br><b>Moltar&#8217;s Bracket Says:</b> Samus will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Samus: 74% - Ada: 26%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>
As easy as it is to simply assume that Ada will suck in this match,
Leon's performance on Bowser makes me think otherwise. Samus will still
win with ease, but Ada might actually manage to, oh.... I dunno, avoid
a tripling perhaps. Stupid female half.<br><br>Prediction: Samus with 74.99%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br> <b>Samus Aran</b><br><br><i>Previous Matches:</i><br><br>Samus Aran &#8211; 81.85% -- 95,533<br><br>Nidoran F &#8211; 18.15% -- 21,180 <br><br><b>Ada Wong</b><br><br><i>Previous Matches:</i><br><br>Ada Wong &#8211; 75.89% -- 74,498<br><br>Jade &#8211; 24.11% -- 23,669 <br><br>With
the start of round 2, we return to the undeniably depressing female
bracket. Even more disappointing, we won&#8217;t really have any idea of how
Samus stacks up to the competition when she&#8217;s against the untested Ada
Wong. However, after Samus&#8217;s performance last round in which she didn&#8217;t
put up a blowout of epic proportions, many began to doubt what she
could do &#8211; but I think she&#8217;ll be reassuring everyone of what she can do
here. <br><br>Ada Wong shouldn&#8217;t be that bad of fodder considering she
does come from Resident Evil 2 and Resident Evil 4. The latter of which
is the most popular game in the entire series and a big reason why Leon
Kennedy was able to put up nearly 45% on the King of Koopas. Still, she
shouldn&#8217;t be comparable to Leon in the least and Samus is much higher
than Bowser can hope for right now. I expect this one to easily go
Samus&#8217;s way in a rather boring match-up. I don&#8217;t think we&#8217;re going to
see anything that diverts from the norm. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Samus Aran<br><br><b>Aitch Emm&#8217;s Prediction:</b> Samus Aran &#8211; 74% ; Ada Wong &#8211; 26%<br><br><b>Aitch Emm&#8217;s Vote:</b> Samus Aran<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>
I think Ada will do a pretty good job here. She looks great in the
picture (whereas Samus looks bleh), Nintendo has looked far from
invulnerable thus far, and Leon did extremely well on Bowser just a few
days ago. Thus, I think Ada will do a pretty good job here.<br><br>My prediction: Samus Aran def. Ada Wong (73-27)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>
I have no idea why I thought Wesker would be more popular than Ada.
That was stupidity. After finally finishing the whole game, I notice
Wesker's hardly got any screen time in RE4. Here I was thinking with
all the hype he was getting in the Villains Contest from his fans, he'd
do something cool. Here I was thinking that with him getting 45%
against Lloyd, he'd do something cool. Well you know what? He didn't do
anything cool beyond wearing sunglasses at night! He's got nothin' on
Ada! I guess maybe he's significant in RE1, but who cares about that
one?
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/13/2006 9:27:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340736077">message detail</a>
 | #460</td></tr>
<tr class="even"><td>
Ada Wong has potential&#8230; even if Jade was fodder, she smashed her <i>good</i>. I think Ada might actually be able to beat Jill or <i>especially</i>
that flopper Claire. RE4 is the revolution, man! RE4 dwarfs that other
crap, for real! So what am I going to do? I'm going to aim nice and low
here. Leon doing so well against Bowser makes me feel better about this
prediction&#8230; Ada might just surprise us all!<br><br><b>Lopen's Prediction:</b> Samus with 70.95%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br> lol x-stats history<br><br>Samus Aran<br><br>Summer 2002 Contest<br>Extrapolated Strength --- 4th Place [41.07%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 7th Place [36.72%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 4th Place [39.50%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 5th Place [38.21%]<br><br>And we're back to Round 2! Joy of joys, it's the female half again. -_- First up is another boring blowout! Yay. -_-<br>Samus
is looking to impress this time around after massively not meeting
expectations against the complete joke entry known as Nidoran F. Was it
a fluke, has Samus lost a step, or was she never there in the first
place? THIS MATCH WILL GIVE US NO ANSWERS TO THAT END<br> <br>Ada Wong<br> <br>lol N/A<br><br>Ada
is looking hot, and she's also looking good after her round one killing
of Jade. However, we're about to see exactly how much of that was
Jade's weakness in this match. Although Leon did impress against
Bowser, so Ada may be able to recapture some of that magic here...<br><br><i>Notable Releases Since Last Appearance</i><br><br>Samus Aran: Metroid Prime: Hunters (DS), Metroid Prime Pinball (DS), Super Smash Brothers Brawl Trailer (lol internet)<br>Ada Wong: Resident Evil 2 (PS), Resident Evil 4 (GC, PS2)<br><br><i>Upcoming Releases</i><br><br>Samus Aran: Metroid Prime 3: Corruption (WII), Super Smash Brothers Brawl (WII)<br>Ada Wong: Resident Evil: Umbrella Chronicles (WII)<br><br>I'll
be honest, I'm pretty interested in MC/SZ right now and I really don't
give a damn about this match. So I'll give you a quick statting --
Samus gets 67% on Leon 2k5, and Ada's getting nowhere near there. She
gets 73% on Jill 2k4, and...yeah, I'll give her a point above that and
be done with it, giving...<br><br>Karma Hunter's Vote: Ada. Another case of personality &gt; Samus<br><br><b>Karma Hunter's Krazy Prediction: Samus Aran with 76.46% .</b><br> <br>If Samus doesn't get this, it'll be a mild disappointment, but whatever.<br><br>Upset Potential: 0.0001%<br><br>Can't forget that RE4 was on the GC!<br><br>Upset Prediction: Ada Wong with 100%<br> <br><br> <br><b>Guest&#8217;s Analysis</b> - <i>Garsha</i><br><br><b>Samus's past performances:</b><br><br>2002: 5-seed, lost to (7)Sephiroth in Division Finals, 47.37%-52.63% (Ranked 4 with 41.07% vs. Base Link)<br>2003: 2-seed, lost to (1)Link in Division Finals, 37.94%-62.06% (Ranked 7 with 36.72% vs. 2K3 Cloud)<br>2004: 2-seed, lost to (1)Cloud Strife in Semi-Finals, 59.01%-40.99% (Ranked 4 with 39.50 vs. 2K4 Link)<br>2005: 1-seed, lost to (1)Mario in Quarter Finals, 59.79%-40.21% (Adjusted Rank at 5 vs. 2K5 Link)<br>2006: 1-seed, defeated (8)Nidoran F, 81.85%-18.15%<br><br>Samus easily wipes Nidoran out.<br><br><i>Performance in past round:</i><br><br>2002-2005: Did not participate.<br>2006: 4-seed, defeated (5)Jade, 75.89%-24.11%<br><br>Impressive performance by Ada.<br><br>CJayC
really did a mistake when splitting the bracket in a male and a female
bracket. Because of this, we see weaklings like Kairi and Lara Croft
winning matches and worthy opponents like Ganondorf, Zero, Tidus, and
Leon Kennedy getting robbed in the first round. We also see characters
Magus, Donkey Kong, Knuckles, and Frog being snubbed and pathetic
characters like Nidoran F and Roll in this contest. CJayC, don't EVER
do this again.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/13/2006 9:28:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340736313">message detail</a>
 | #461</td></tr>
<tr class="even"><td>Both characters have done impressively against
their opponents, but it's obvious that Samus will win this match. Has
Leon ever gotten 41% against Cloud? Nope. We can very much say that Ada
is weaker than Leon. Unadjusted 2K5 Samus is projected to get over 60%
against Leon, and Adjusted 2K5 Samus is projected barely double Leon
with 67.02% However, seeing that Ada showed a very impressive
performance against Jade, and the fact that Leon put up nearly 45%
against Bowser might show that Ada is a little more than just a
pushover, and might even be above the fodder line. Ada will boost and
benefit from the PS2 port of Resident Evil 4, and I wouldn't be
suprised if Ada broke 30% or even avoid the doubling. I can't see Samus
tripling Ada, seeing that RE4 is by far the most popular game in the
series, as well as one of the most popular games on the GameCube, but I
can see her breaking 70%, and Metroid Prime 3 hype could help that.<br><br>Oh, and my word to all of Board 8 and its horrible taste: <b>The Beatles &gt;&gt;&gt;&gt; Lolicon.</b><br><br><b>Garsha's prediction:</b> Samus Aran defeats Ada Wong-71.96%-28.04%. Gotta let my sister on this computer right now. She just turned 16 a few days ago.<br><br>*Catches the attention of many idiots*<br><br> <br> <br>Crew
Consensus: Samus's bounty this time is Ada. It looks like she'll win,
but by how much is what you want? Crew says low-to-mid 70's.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/13/2006 9:29:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340736504">message detail</a>
 | #462</td></tr>
<tr class="even"><td>
<i>Can't forget that RE4 was on the GC!<br><br>Upset Prediction: Ada Wong with 100%</i><br><br>so true<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 10/13/2006 9:34:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340737623">message detail</a>
 | #463</td></tr>
<tr class="even"><td>
Lolicon &gt; Life.<br>Beatles do not &gt; Life.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/13/2006 9:36:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340738045">message detail</a>
 | #464</td></tr>
<tr class="even"><td>
a new tradition - haiku of the match!<br><br>Samus sucked last round<br>Ada Wong, strong like Leon?<br>Samus still triples<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=468956" class="name">goku z</a> |
Posted 10/13/2006 9:37:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340738261">message detail</a>
 | #465</td></tr>
<tr class="even"><td>
Sister eh? lol<br>---<br><i>Long live Goku GT, lost August 2002 in the moderation wars of B8.</i> 10th Place, 2005 Character Battle
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/13/2006 9:42:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340739538">message detail</a>
 | #466</td></tr>
<tr class="even"><td>
Whoa, I'm the high guy here? I guess you guys really have lost a little faith in Nintendo...or Samus versus Nintendo, at least.<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/13/2006 9:43:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340739658">message detail</a>
 | #467</td></tr>
<tr class="even"><td>
I think it's Leon scaring people out of high picks.<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3793953" class="name">TehMissingLink</a> |
Posted 10/13/2006 10:05:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340744574">message detail</a>
 | #468</td></tr>
<tr class="even"><td>
I didn't lose faith in Nintendo so much as I think Ada will be pretty decent.<br><br>---<br>"<i>Looking good, Princess, especially from this angle!</i>"
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/13/2006 11:06:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340757186">message detail</a>
 | #469</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick, Late Analysis:</i><br><br>The only reason why Ada got out of the first round was because she was facing fellow fodder.  She has nothing on Samus.<br><br>My vote: Ada Wong<br>My bracket: Samus<br>My prediction: Too late<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/13/2006 11:06:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340757294">message detail</a>
 | #470</td></tr>
<tr class="even"><td>
Yeah, like I said, I was shocked I was the high guy. Well, thanks, LOSERS<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/14/2006 12:14:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340832078">message detail</a>
 | #471</td></tr>
<tr class="even"><td>
ya thats wat she said hahaha<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 10/14/2006 12:32:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340835400">message detail</a>
 | #472</td></tr>
<tr class="even"><td>Wow, I'm surprised that nearly everyone thought
Ada could avoid the tripling. That would require Jade to actually be
above 10% on BL...<br><br>My preliminary stats gave Samus 77-78% here, and that had Jade at 9% on BL...<br>---<br><b>Squall Leonhart's Road to the Character Battle V Championship</b>:<br><i>Round 1</i>: Status of Tidus - <b>LIONHEART'D</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/14/2006 12:33:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340835573">message detail</a>
 | #473</td></tr>
<tr class="even"><td>
^5 LEON IMHO. Oh, and go check out the sign-up topic, Bellis is giving up his spot to you for Snake/Squall.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=152338" class="name">Lopen</a> |
Posted 10/14/2006 12:35:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340835860">message detail</a>
 | #474</td></tr>
<tr class="even"><td>
Eh, Jade being able to hang tough with Manny or Guybrush wouldn't have
surprised me. Plus I was thinking Samus was probably a bit overrated by
the 2005 stats. <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/14/2006 12:36:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340836004">message detail</a>
 | #475</td></tr>
<tr class="even"><td>
Samus.... <i>overrated?</i> I guess your name is Lopen for a reason. (Being horrible at predicting, if you didn't catch it!)<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 10/14/2006 12:51:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340838923">message detail</a>
 | #476</td></tr>
<tr class="even"><td>
<i>Eh, Jade being able to hang tough with Manny or Guybrush wouldn't have surprised me.</i><br><br>After
seeing how horrible BG&amp;E's sales were, I was expecting her to be on
Yuri's level. Looks like she won't even be THAT high!<br>---<br><b>Squall Leonhart's Road to the Character Battle V Championship</b>:<br><i>Round 1</i>: Status of Tidus - <b>LIONHEART'D</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 10/14/2006 12:53:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340839479">message detail</a>
 | #477</td></tr>
<tr class="even"><td>
...Okay, where's the sign-up page for round 2?<br>---<br><b>Squall Leonhart's Road to the Character Battle V Championship</b>:<br><i>Round 1</i>: Status of Tidus - <b>LIONHEART'D</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3602792" class="name">Garsha_III</a> |
Posted 10/14/2006 12:57:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340840185">message detail</a>
 | #478</td></tr>
<tr class="even"><td>
Heh, I didn't expect Samus to nearly quadruple Ada. Guess I'm way off.
Leon's performance made me think that Ada would do OK. Samus is on her
way to win the tournament!<br>---<br>!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/14/2006 2:43:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340860464">message detail</a>
 | #479</td></tr>
<tr class="even"><td>
Master Chief.................49.05% 62932<br>Sub-Zero......................50.95% 65358<br>TOTAL VOTES.........................128290<br><br><b>20.27%</b> of the brackets predicted this match correctly.<br><br>Wow...I'm not surprised Subbie won. Seems Chief can't even beat midcarders now. Only a 5th of the brackets saw this coming.<br><br>Today, Samus is showing why she's the favorite to win.<br><br>Lopen - 7<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience) - 6<br>HM - 5<br>Moltar - 5<br>KH - 5<br>Ulti - 4<br>Yoblazer - 2<br><br>Guests move up again.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Samus vs. Ada - Bracket: <b>Samus</b> - Vote: <b>Samus</b> (28/32)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=640243" class="name">Big Bob</a> |
Posted 10/14/2006 3:00:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340863834">message detail</a>
 | #480</td></tr>
<tr class="even"><td>
Now do you see why so many people wanted to be part of the analysis crew?<br>---<br>Gordon
Freeman finally won, but somehow, the universe survived... thus
allowing me to tell said universe about how I was owned by <b>NClark128</b>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/14/2006 4:27:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340881193">message detail</a>
 | #481</td></tr>
<tr class="even"><td>
Crono vs. Captain Falcon<br>+7 Guest<br>+6 HM<br>+5 Ulti<br>+4 Mo<br>+3 KH<br>+2 Lo<br>+1 Yo<br><br>Bowser vs. Leon<br>+7 Guest<br>+6 Mo<br>+5 Lo (tie)<br>+5 Ulti (tie)<br>+3 KH<br>+2 HM (tie)<br>+2 Yo (tie)<br><br>Auron vs. Alucard<br>+7 HM<br>+6 Mo<br>+5 KH<br>+4 Lo<br>+3 Ulti<br>+2 Guest<br>+1 Yo<br><br>Master Chief vs. Sub-Zero<br>+7 Guest<br>-1 KH<br>-2 Yo<br>-3 Mo <br>-4 HM <br>-5 Lo<br>-6 Ulti <br><br>Samus Aran vs. Ada Wong<br>+7 KH<br>+6 Ulti<br>+5 HM (tie)<br>+5 Mo (tie) <br>+3 Yo<br>+2 Guest<br>+1 Lo<br><br><b>The Rankings</b> (Through Samus vs. Ada )<br>1. Karma Hunter (146)<br>2. Master Moltar (131)<br>3. Heroic Mario (122)<br>4. UltimaterializerX (116)<br>5. Board 8 (104)<br>5. Yoblazer (104)<br>6. Lopen (83)<br><br>Sorry for the delay.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/14/2006 4:29:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340881734">message detail</a>
 | #482</td></tr>
<tr class="even"><td>
Don't worry, guys! Ada will get the day vote!<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 10/14/2006 4:56:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340887444">message detail</a>
 | #483</td></tr>
<tr class="even"><td>
Guests sure are redeeming themselves. And they're so low on consistency
because the people who took upsets wanted to write an analysis for the
match they took the upset (Cortana, Alyx Vance, Sub Zero are a few
examples), and most of the upsets didn't pan out.<br>---<br>CB06 - Score: <b>28/32 </b>Rank: <b>Tied - 2044th </b>Yesterday's Pick:<b> Master Chief</b> <br>Today's Pick: <b>Samus</b> Tomorrow's Pick: <b>Rikku</b> Losses: <b>Cortana, Ganon, Zero, MC</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=945395" class="name">FantasyFreak999</a> |
Posted 10/14/2006 8:53:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340937644">message detail</a>
 | #484</td></tr>
<tr class="even"><td>
Did you get my analysis?<br>---<br>"Run, run, or you'll be well done!" <br>~Kefka, Final Fantasy 6~
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/14/2006 9:00:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340938981">message detail</a>
 | #485</td></tr>
<tr class="even"><td>
<b>Spazer Division:</b> <i>Round 2 - Match 34</i> &#8211; (3)Rikku vs. (2)Kairi <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Rikku</b><br>Round 1 &#8211; 75.00% vs. Lenneth (25.00%)<br><br>Rikku pulls an exact tripling on Lenneth<br><br><b>Kairi</b><br>Round 1 &#8211; 52.08% vs. Claire (47.92%)<br><br>Claire nearly pulls the upset, but Kairi is able to squeeze through.<br><br>Ha
Ha, ah, time for revenge, Kairi! I might have thought you were going to
turn up pathetic enough to lose to Claire, and you nearly did! Luckily,
the after-school vote pulled through for you. Still, now you get to
face true competition! Do your stuff, Rikku!<br><br>Anyway, bias aside,
things aren&#8217;t looking good for Rikku here. Kairi may get the backing
from KH fans against a non-Square opponent, but now we have Rikku.
She&#8217;s not only a main in the Final Fantasy series, but she also has her
cameo in the KH series. With Rikku stronger than Kairi, will we be
seeing a bit of Square SFF here? Who cares, Kairi is going to end up
looking pretty bad here. I&#8217;ll be <i>shocked</i> if she impresses against Rikku.<br><br><b>Moltar&#8217;s Bracket Says:</b> Rikku will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Rikku: 66% - Kairi: 34%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>As
badly as people want to see Kairi get completely killed here, it might
not happen. KH fans are complete freaks. Kairi, a character that does
almost nothing in any KH title, beat Claire Redfield in the first
round. These people would vote for Sora Turd over Anything if it came
down to it. I still think Rikku wins this easily, but Kairi might
surprise people.<br><br>Prediction: Rikku with 57.55%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br><b>Rikku</b><br><br><i>Previous Matches:</i><br><br>Rikku &#8211; 75% -- 83,124<br><br>Lenneth Valkyrie &#8211; 25% -- 27,704 <br><br><b>Kairi</b><br><br>Kairi &#8211; 52.08% -- 56,291<br><br>Claire Redfield &#8211; 47.92% -- 51,795 <br><br>This
match has been a foregone conclusion from the beginning. Even with
Kairi&#8217;s rather impressive performance against Claire Redfield, she
still stands absolutely no chance to beat the superior Square character
in this face off of awful Partystar favorites. Since we do have
something of concrete value on Rikku, we should be able to get a rough
idea of where Kairi will stand after this match, assuming there is no
severe SFF. <br><br>If Kairi does manage to make this interesting, I
would not only be shocked but have to agree that there was some serious
power from KH2 here. I have a hard time believing that pre-KH2 Kairi is
worth much of anything. KH2 Kairi is probably worth a bit more, but how
much more remains to be seen. It&#8217;d be rather humorous if Kairi <i>did</i> manage to make this interesting and make a close match out of it. I know it&#8217;d make Yoshi and Tingle looks <i>fantastic!</i> <br><br><b>Aitch Emm&#8217;s Bracket:</b> Rikku<br><br><b>Aitch Emm&#8217;s Prediction:</b> Rikku &#8211; 60% ; Kairi &#8211; 40%<br><br><b>Aitch Emm&#8217;s Vote:</b> Rikku<br> <br> <br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Very
cute picture. Kairi may have been able to beat a Resident Evil playable
character who has been absent from gaming for five years, but she won't
be a threat for a Final Fantasy playable character who's almost as new
to the gaming scene as she is. Rikku is simply stronger (stronger than
Kratos, who I wouldn't dream of <i>not</i> taking over Kairi), and any
SFF here will almost certainly go her way. As with the last match,
Kairi will get my vote, but that won't enough for the sweetest victory.<br><br>My prediction: Rikku def. Kairi (62-38)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>
Well, here's a match where I've only got one half of the duo right&#8230;
there are a lot of these this round! I had Claire here. And no, it
wasn't because I trusted the 2002 stats one bit, it's because I thought
Kairi was fodder.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/14/2006 9:00:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340939159">message detail</a>
 | #486</td></tr>
<tr class="even"><td>
And you know what? I <i>still</i> think she's
fodder! I don't care if she managed to squeak by Claire, that didn't
convert me. That just makes me think Claire dropped by <i>even more</i> than I thought she did. Rikku, on the other hand, we saw her last year, and she looked pretty good. Definitely not fodder.<br><br>Now,
considering they're both from popular PS2 RPGs, you could say it's
reasonable to expect a hint of the ol' "Same Fanbase Factor" here.
Sure, why not? Could be a bit. But when Rikku straight out kills her?
You can't blame it all on that&#8230; no you can't!<br><br><b>Lopen's Prediction:</b> Rikku with 68.10%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br> lol x-stats history<br><br>Rikku<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 30th Place [24.33%]<br><br>Rikku
takes care of Lenneth in the first round, though not by as much as I
anticipated -- possible overrating in that whole chain there? Not that
she's going to lose this match, obviously...but Samus is going to make
this entire division look downright PATHETIC if Rikku can't start
looking impressive, and fast.<br> <br>Kairi<br> <br>lol N/A<br><br>The
girl who made Speck of Dust a household name squeaks out in the closest
match of the female bracket, and her reward is a setup that is all too
familiar to anyone that was around for 2k3 (or to get burned by Sora in
2k4). Yay for having an unreliable value on a character that we'll
likely never see again because of it.<br><br><i>Notable Releases Since Last Appearance</i><br><br>Rikku: Kingdom Hearts 2 (PS2)<br>Kairi: Kingdom Hearts (PS2), Kingdom Hearts 2 (PS2)<br><br><i>Upcoming Releases</i><br><br>Rikku: N/A<br>Kairi: N/A<br><br>Would I ever take Kairi to get 45% on ANY Ryu?<br><br>Karma Hunter's Vote: Rikku. Kairi is just so...ugh.<br><br><b>Karma Hunter's Krazy Prediction: Rikku with 64.56% .</b><br><br>Not a clue here, so I'm just depending on Aeris' precedent to hold (and for Kairi to be far more worthless than Sora).<br><br>Upset Potential: 4%<br><br>Y'know,
Kairi can conceivably turn this into a Pokemon/Metroid or closer...just
because Aeris SFFed Sora doesn't mean Rikku can do the same, especially
when Rikku's role in KH2 is even more worthless than Kairi's and Rikku
ain't too adored by the FFX fanbase in the first place. Of course, I
don't think Kairi is much of anything, either...but if Claire really
maintains a semblance of popularity (like, say, near where I think Jill
is at), Kairi can conceivably win this. There is that pesky 45% on Ryu
there...but what if it was a fluke?<br><br>Agh, I'm just upset-hungry in the starved female bracket.<br><br>Upset Prediction: Kairi with 52%<br> <br><br> <br><b>Guest&#8217;s Analysis</b> - <i>FantasyFreak999</i><br><br>Well, here we have a Square vs. Square match, so you know that there will be SFF involved.  The question<br>is,
will it go to Rikku, who hails from the almighty Final Fantasy series,
or to Kairi, who comes to us from the Kingdom Heart series. <br><br>Sorry
Kairi, but FF beats out KH any day. Even without the SFF though, Rikku
would still beat out Kairi. If we look at the extrapolated ranks of
Rikku and Riku (wow, I never thought I&#8217;d actually put those two in the
same sentence), Rikku came out ahead of Riku. Seeing as how Riku is
easily more popular than Kairi, it pretty much means that she&#8217;s gonna
lose.<br><br>The real question now is how much Kairi is gonna lose by.
I think a doubling is a given, but can Rikku pull off a tripling? I&#8217;m
gonna say yes (It IS Kairi after all). I just cant see Kairi being that
strong, even if she is a product of Square.<br><br>FantasyFreak999&#8217;s pick: Rikku &#8211; 76.8%, Kairi &#8211; 23.2%<br> <br> <br> <br>Crew Consensus: Picks are literally all over the place for Rikku.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/14/2006 9:04:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340939946">message detail</a>
 | #487</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Rikku is popular from Final
Fantasy. Kairi is popular from Kingdom Hearts. There is no reason to
believe that Kingdom Hearts would beat Final Fantasy, unless it was the
main character of KH, and that's not the case. Rikku should SFF and win
this match fairly easily, especially since she had a cameo in Kingdom
Hearts 2. Goodbye perfect brackets.<br><br>My vote: Rikku<br>My bracket: Rikku<br>My prediction: Rikku with 73%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/14/2006 9:07:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340940508">message detail</a>
 | #488</td></tr>
<tr class="even"><td>
I can't possibly see Guest being right here. =/<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/14/2006 11:58:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340977384">message detail</a>
 | #489</td></tr>
<tr class="even"><td>
And for good reason, too.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=795464" class="name">Tatl</a> |
Posted 10/15/2006 12:08:54 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340979287">message detail</a>
 | #490</td></tr>
<tr class="even"><td>
<i>Only a 5th of the brackets saw this coming.</i><br><br>*Is in that group.*<br><br>I never questioned it, nor the Luigi/Zero match.<br><br>To all those who said Sub-Zero and/or Luigi had no chance of leaving the first round:<br><b>HA HA HA HA HA!!!!</b><br><br>I now return you to the end of the topic.<br>---<br>"I reject your reality and substitute my own." ~ Adam Savage; Insanity Personified<br>"Crikey!" ~ Steve Irwin (R.I.P.); Perfection Personified
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/15/2006 6:15:24 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=341009490">message detail</a>
 | #491</td></tr>
<tr class="even"><td>
Eep, my margin in yo's system is decreasing! I've been on a bit of a rough streak lately. =/<br><br><i>Guests
sure are redeeming themselves. And they're so low on consistency
because the people who took upsets wanted to write an analysis for the
match they took the upset (Cortana, Alyx Vance, Sub Zero are a few
examples), and most of the upsets didn't pan out.</i><br><br>Well, take
enough crazy picks and you're bound to get some hits, that's why Lopen
is in first in Moltar's system (and last in yo's). B8 is surely racking
up the hits in Moltar's system now that some of these picks are finally
paying off, but the fact remains that they're only above Lopen in yo's
system, tied with yoblazer himself -- and while I'll be the first to
admit that yo's bracketmaking skills are far superior to mine, this
hasn't been the best of contests for him so far.<br><br>aw yeah tangents ftl<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/15/2006 7:02:06 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=341009976">message detail</a>
 | #492</td></tr>
<tr class="even"><td>
Actually, it just turns out I can't count. Carry on then~! HAHAHAHAHAHAHAHA<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=909335" class="name">JonesSodaMaster 2</a> |
Posted 10/15/2006 10:07:18 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=341026150">message detail</a>
 | #493</td></tr>
<tr class="even"><td>
I like pie.<br>---<br>&amp;#9788;��!"#$%&amp;'()*+,-./0123456789:;?@ABCDEFGHIJK<br>LMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=909335" class="name">JonesSodaMaster 2</a> |
Posted 10/15/2006 10:07:52 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=341026235">message detail</a>
 | #494</td></tr>
<tr class="even"><td>
Pie=t3h awesome<br>---<br>&amp;#9788;��!"#$%&amp;'()*+,-./0123456789:;?@ABCDEFGHIJK<br>LMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=909335" class="name">JonesSodaMaster 2</a> |
Posted 10/15/2006 10:08:24 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=341026308">message detail</a>
 | #495</td></tr>
<tr class="even"><td>
Yes, I am taking this to 500.<br>---<br>&amp;#9788;��!"#$%&amp;'()*+,-./0123456789:;?@ABCDEFGHIJK<br>LMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=909335" class="name">JonesSodaMaster 2</a> |
Posted 10/15/2006 10:09:36 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=341026468">message detail</a>
 | #496</td></tr>
<tr class="even"><td>
OMG, Bob will so totally beat Steve because he is higher in the Lol X-Stats!<br>---<br>&amp;#9788;��!"#$%&amp;'()*+,-./0123456789:;?@ABCDEFGHIJK<br>LMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/15/2006 10:09:47 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=341026492">message detail</a>
 | #497</td></tr>
<tr class="even"><td>
...Blah.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=909335" class="name">JonesSodaMaster 2</a> |
Posted 10/15/2006 10:10:14 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=341026555">message detail</a>
 | #498</td></tr>
<tr class="even"><td>
Pie&gt;all<br>---<br>&amp;#9788;��!"#$%&amp;'()*+,-./0123456789:;?@ABCDEFGHIJK<br>LMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=909335" class="name">JonesSodaMaster 2</a> |
Posted 10/15/2006 10:10:51 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=341026637">message detail</a>
 | #499</td></tr>
<tr class="even"><td>
Dipsy&gt;Po&gt;Laa-Laa&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;Tinky Winky<br>---<br>&amp;#9788;��!"#$%&amp;'()*+,-./0123456789:;?@ABCDEFGHIJK<br>LMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=909335" class="name">JonesSodaMaster 2</a> |
Posted 10/15/2006 10:11:15 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=341026688">message detail</a>
 | #500</td></tr>
<tr class="even"><td>
[This message was deleted at the request of a moderator or administrator]
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=8">9</a></li>
<li>10</li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage10_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30854544&amp;page=9" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage10_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>