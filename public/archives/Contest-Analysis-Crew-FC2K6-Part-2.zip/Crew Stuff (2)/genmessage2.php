<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	



<title>GameFAQs - GameFAQs Contests Message Board</title><meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage2_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage2_files/nogs.css"></head><body>
<div id="container">
	<div id="gne_nav">
		<img src="genmessage2_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/afterhours/">After Hours</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage2_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30854544%26page%3D1"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage2_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage2_files/advertisement.gif" alt="advertisement" height="10" width="120"></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage2_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage2_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 2
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;page=1">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30854544" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">First Page</a> |
Page 2 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=2">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/1/2006 7:11:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338165763">message detail</a>
 | #051</td></tr>
<tr class="even"><td>
<i>THEJackSparrow | Posted 9/30/2006 8:55:55 PM | message detail  <br>This can only mean one thing...<br><br>Hit or miss Lopen hits! </i><br><br>And thus it was fulfilled.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 1</i>: 41-15 over Sephiroth
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/1/2006 7:13:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338166162">message detail</a>
 | #052</td></tr>
<tr class="even"><td>
I wish I could just make picks like, ".1% higher than Lopen is going."<br><br>Silly Lopen!<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/1/2006 7:58:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338178208">message detail</a>
 | #053</td></tr>
<tr class="even"><td>
Riku........................44.8% 56325<br>Yoshi.....................55.2% 69394<br>TOTAL VOTES...............125719<br><br>58.08% of the brackets predicted this match correctly.<br><br>KH2's
first real test! Riku was able to get 45% on Yoshi, which could be
looked at as pretty good. Does this mean KH2 has boosted him up, or is
Yoshi just looking not as strong as he used to? I guess we'll find out
soon. Only 58% called the match right too...ouch.<br><br>Today, Devil Division is overrated, eh? This performance by Dante doesn't make it seem so!<br><br>Lopen - 5<br>KH - 4<br>Ulti - 4<br>Moltar - 3<br>HM - 2<br>Yoblazer - 1<br>Guest (Wigs) - 1<br><br>HM, with his low Yoshi pick, gets the point.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/1/2006 8:06:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338180457">message detail</a>
 | #054</td></tr>
<tr class="even"><td>
I also haven't received the Guest write-up for Sora/Tingle yet, so it's up for grabs now.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Dante vs. Ryu H. - Bracket: <b>Dante</b> - Vote: <b>Dante</b> (18/19)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=264094" class="name">Heroic Mario</a> |
Posted 10/1/2006 8:09:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338181190">message detail</a>
 | #055</td></tr>
<tr class="even"><td>
Hey, Moltar, I'll have that Sora/Tingle write-up coming your way!<br><br>---<br>"<i>Master using it and you can have this.</i>"<br>http://img90.imageshack.us/img90/160/masterjg3.jpg
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/1/2006 8:13:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338182349">message detail</a>
 | #056</td></tr>
<tr class="even"><td>
What is your e-mail address?<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i><br>Michelle.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=264094" class="name">Heroic Mario</a> |
Posted 10/1/2006 8:14:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338182599">message detail</a>
 | #057</td></tr>
<tr class="even"><td>
Sent it to ya!<br><br>---<br>"<i>Master using it and you can have this.</i>"<br>http://img90.imageshack.us/img90/160/masterjg3.jpg
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=254355" class="name">Lugia2</a> |
Posted 10/1/2006 8:40:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338189671">message detail</a>
 | #058</td></tr>
<tr class="even"><td>
...Wait, isn't HM on the crew?<br><br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/1/2006 8:59:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338194895">message detail</a>
 | #059</td></tr>
<tr class="even"><td>
Yeah, but he sucks so much he's allowed to make second predictions.<br><br><br><br><br>BURN BABY BURN<br>---<br><b>Z1mZum</b> <i>performed a hit and run</i> on me in the Guru Contest.<br>It still hurts to be rear-ended like that.....
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=264094" class="name">Heroic Mario</a> |
Posted 10/1/2006 9:01:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338195598">message detail</a>
 | #060</td></tr>
<tr class="even"><td>
<i>...Wait, isn't HM on the crew?</i><br><br>I've been a little busy
lately, so I haven't been able to get my predictions in way ahead of
time. I just remembered a minute ago that I hadn't sent an analysis in,
so I whipped an awesome one together.<br><br>In short, yes, I'm on the crew.<br><br>---<br>"<i>Master using it and you can have this.</i>"<br>http://img90.imageshack.us/img90/160/masterjg3.jpg
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=254355" class="name">Lugia2</a> |
Posted 10/1/2006 9:03:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338196171">message detail</a>
 | #061</td></tr>
<tr class="even"><td>
Ah. It's just the juxtaposition of the two posts about someone
forgetting his Sora/Tingle analysis and you forgetting yours about the
very same match that confused me.<br><br>Doh.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/1/2006 10:02:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338211514">message detail</a>
 | #062</td></tr>
<tr class="even"><td>
<b>Destiny Division:</b> <i>Round 1 - Match 21</i> &#8211; (1)Sora vs. (8)Tingle <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Sora</b><br>Game/Series Known From: Kingdom Hearts<br>Extrapolated Rank in 2003: 39th (21.88%) <br>Extrapolated Rank in 2004: 13th (26.97%)<br>Extrapolated Rank in 2005: 30th (23.54%)<br>Seed in 2003: 6<br>Seed in 2004: 6<br>Seed in 2005: 2<br>Lost in 2003 to Aeris in Round 1<br>Lost in 2004 to Samus in Round 3<br>Lost in 2005 to Solid Snake in Round 3<br><br>Sora a 1-seed? What kind of shenanigans is this?!<br><br><b>Tingle</b><br>Game/Series Known From: Legend of Zelda<br><br>Tingle in a Contest? What kind of shenanigans is this?!<br><br>Well,
since I&#8217;m not a funny guy, I&#8217;ll leave the Tingle jokes up to the other
guys. All I need to add is that it should have been someone like Snake
facing Tingle. I mean, could Snake 90% the bastard-elf we all love to
hate? I&#8217;m afraid we&#8217;ll never know.<br><br>Instead, Tingle catches a
break and instead faces Sora, who couldn&#8217;t blow-out a Kairi-shaped
balloon. So yeah, now we&#8217;ll be seeing Tingle maybe avoid the tripling,
leading to &#8220;ZOMG TINGLE IZ THE STRAWNG!1!!1&#8221; Oh well, life goes on.<br><br><b>Moltar&#8217;s Bracket Says:</b> Sora will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Sora: 75% - Tingle: 25% <br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>I'm not going to dignify THIS crap with a response either.<br><br>Prediction: Sora with 82.99%<br> <br> <br><br><b>HM&#8217;s Analysis</b><br> <br>The
most hated Zelda character ever? Perhaps~! One of the weakest
characters to ever enter into a contest? Hell no! That&#8217;s right, folks,
Tingle is going to be <i>worth</i> something here! Sora may be coming
off of Kingdom Hearts II with a nice boost, but that won&#8217;t stop Tingle
from representing some of that awesome Zelda strength by avoiding a
tripling here! <br><br>The fact that Tingle even made it <i>into</i>
the contest is surprising enough. I do believe it&#8217;s because of the
nominations being put up on the day of LoZ/FF in the Series Contest.
But will the Zelda fanbase support him? If only for a joke, I think so.
I don&#8217;t think Tingle will end up being <i>really</i> bad fodder &#8211; he&#8217;d
destroy the likes of Alyx, Carmen Sandiego, Yuri, and Jade. I think
with a combination of joke votes, some Zelda support, and Sora not
being someone who has really proven to be a big blowout guy will
ultimately result in Tingle being able to pull a bit above 25%. <br><br>Remember &#8211; all of you &#8211; vote Tingle for great justice <i>!!</i> <br><br><b>Aitch Emm&#8217;s Bracket:</b> Sora<br><br><b>Aitch Emm&#8217;s Prediction:</b> Sora &#8211; 74% ; Tingle &#8211; 26%<br><br><b>Aitch Emm&#8217;s Vote:</b> TINGLE FOR LIFE!<br> <br> <br><br><b>Yoblazer&#8217;s Analysis</b><br> <br>I
haven't seen it mentioned yet, but it's interesting to note that other
than Jesus... err, CATS, every 8 seed is a contest rookie. It explains
why at least a few of the 1/8 matches have not gone quite as expected,
and it also explains why we aren't really using these surprising
results to gauge future matches. These characters are new. We have no
idea how strong or weak they are, so for now, we're just sitting back
and enjoying the ride.<br><br>And, of course, this is THE 1/8 match to
sit back and enjoy. Here we have not only a 1 seed who is known for
underperforming against fodder, but an 8 seed who may as well be the
biggest question mark in contest history. I rarely resort to insulting
others when it comes to contest debate, but if you ABSOLUTELY KNOW
WITHOUT A SHADOW OF A DOUBT that Tingle is going to bomb to hell, or if
you ABSOLUTELY KNOW WITHOUT A SHADOW OF A DOUBT that Tingle is going to
overperform because of his Zelda status, then I'm sorry, but you're a
fool. You know as much as we all do, which, in this case, is nothing.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/1/2006 10:02:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338211585">message detail</a>
 | #063</td></tr>
<tr class="even"><td>Tingle's range is staggering. He might get
anti-voted by the Zelda fanbase enough to allow Sora to creep into the
low or even mid-80's. Conversely, those crazy Zelda fans (the same ones
who beat Final Fantasy a few months ago and pushed Zelda to one of the
most impressive contest wins ever a few days ago) might rally behind
him enough so that he actually breaks 30%. Sound crazy? Why the hell is
it? If Agent 47 can come within inches of 30% against Sora, why can't
someone who has even a fraction of the Zelda fanbase on his side? If
Nidoran F can get jokes votes, why can't Tingle? Don't get me wrong;
Sora will be stronger this year, but he's nothing in the face of the
Zelda fanbase, and right now that fanbase has the <i>potential</i> to push a Deku Stick to 30% on anyone.<br><br>In
my opinion, a predictor can do one of three things: he can bank on
Tingle to draw enough Zelda and joke support to shock everyone, he can
bank on Tingle to get anti-voted by everyone and humiliate himself, or
he can bank on the result to end up somewhere in the middle. I'm gonna
take a risk and bank on at least some of the Zelda faithful to get
behind one of their own, no matter how damn pathetic he is.<br><br>My prediction: Sora def. Tingle (70-30)<br><br>By the way, if I'm not the low man today, I'll probably bust a gasket.<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Oh,
haha&#8230; this match is so funny. Oh yeah&#8230; look at Tingle, the ultimate
joke character. Oh man&#8230; haha. **** Tingle! **** that ****** ****** joke
8 seed for taking Raiden's *** **** ****** ******* place. *******! <i>DIE!</i><br><br><b>Lopen's Prediction:</b> SORA WINS WITH 100% OF THE VOTE.<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>SORA</b><br> <br><i>"I know now I don't need the Keyblade. I've got a better weapon. My heart."</i><br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 39th Place [21.17%]<br> <br>Summer 2004 Contest<br>Extrapolated Strength --- 21st Place [26.97% ]<br>Summer 2005 Contest<br>Extrapolated Strength --- 32nd Place [23.54% ]<br> <br>Arguably
the biggest oddball we've seen in these contests is back, and he's
primed to be better than ever! Yes, it's the somewhat-love-him-or-hate
him protagonist of Kingdom Hearts, Sora! Naturally, KH2 is still big
here, and Sora's personality is much more likable than it was in the
first game. It'll be nearly impossible for us to gauge his boost
correctly...but sadly for him, his path is utterly predictable. I don't
believe I've ever seen such a waste of a character. He'll be looking to
impress against Mega Man, though, and try to redeem his disappointing
finish last year. WOO SORA <br><b>TINGLE</b><br> <br><i>"Tingle! Tingle! Kooloo-limpah! Become...READABLE!"</i><br> <br>N/A <br> <br>Oh
Lord, how did Tingle get into the contest? I mean, lol ZeldaFAQs isn't
even appropriate here...getting another Zelda character would be
perfectly understandable, especially with the female side. But instead
of Epona, Malon, Majora's Mask, Saria, Navi, Tatl, <i>Tael</i>, Darunia, Ruto, Impa, Nabooru, Agahnim, Twinrova, Happy Shop Mask Dude or Running Man...you boneheads got <i>Tingle</i> into the contest? That's not nominating Zelda, that's nominating <i>the worst possible thing from Zelda ever.</i> I hate Tingle, hate everyone who nommed him, hate everyone who votes for him, and possibly hate myself.<br> <br>...<br> <br>WOO TINGLE<br> <br><i>Notable Releases Since Last Appearance</i><br><br>Sora: Kingdom Hearts 2 (PS2)<br>Tingle: N/A<br><br><i>Upcoming Releases</i><br><br>Sora: N/A<br>Tingle: N/A<br> <br>Giving a short response would be overdone and cliche at this point, I think.<br> <br>...boobs.<br><br>Karma Hunter's Vote: Not Tingle<br><br><b>Karma Hunter's Krazy Prediction: Sora with 76.58%.</b><br> <br>If
there is any God or justice in this world, Tingle will get tripled. So
I'm expecting him to break 35%, naturally, but this is my hopeful
prediction.<br><br>Upset Potential: 0%<br> <br>DIE TINGLE DIE
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/1/2006 10:03:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338211786">message detail</a>
 | #064</td></tr>
<tr class="even"><td>
<b>Guest&#8217;s Analysis</b> - <i>Lady_Ashe</i><br><br>Aha! We're in the
male bracket, y'know. A magical place where matches are exciting, and
no match shows this better than this one. It is Sora vs... Tingle. Hmm,
maybe I was thinking of the match after this one. Oh well.<br><br>First
off we have the hero of the Kingdom Hearts series, Sora! What is there
to say about Sora? Oh, not much. I mean, he hasn't been all that
impressive in previous competitions. Sure, he isn't fodder, but he
hasn't done anything amazing. Wait, what's this you say? Kingdom Hearts
2 is out, and Kairi, a non-playable character who spends most of her
time being captured managed to beat Claire? Claire isn't anything
special, but for Kairi to show any amount of strength at all, either
there is a huge KH2 boost or she scored big time on the loli factor.
I'm a little bit inclined to go with the former. What does this mean
for our hero? It means that he will most likely move up a fair amount
in terms of strength. If you don't believe me, take a look at his
seeding.<br><br><br>But enough about Sora. Let's find out who he is up
against, shall we? It is none other than the beloved map provider in so
many Zelda games, Tingle! Wait, nobody likes him and he can give Navi a
good run for her money on most annoying Zelda character. Well, he stars
in his own game, so that has got to be worth <i>something.</i> Nah, I
can't see him being anything but fodder. He is from the Legend of Zelda
series though, so NintendoFAQs may give him a few votes.<br><br>Well,
Sora has probably receivied a large KH2 boost, and Tingle is hated by a
large amount of people who have played the games that he is in. Due to
these factors, I am calling for this to be a blowout, and the only
thing that is stopping me from calling this a quadrupling is that the
contest is being held on NintendoFAQs.<br><br>Sora wins with 78.24%. I have a feeling this will be off from the rest of the crew, but I'm going with it all the same.<br><br>Oh, and as I depart, I have one last thing to say to all of you...<br><br>Tingle-Tingle, Kooloo-Limpah!<br> <br> <br>Crew Consensus: Sora for the win, but Tingle doesn't end up completely embarrassing himself.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/1/2006 10:06:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338212480">message detail</a>
 | #065</td></tr>
<tr class="even"><td>
Dante vs. Ryu Hayabusa<br>+7 Lo<br>+6 Mo<br>+5 KH<br>+4 Ulti<br>+3 Guest<br>+2 Yo<br>+1 HM<br><br><b>The Rankings</b> (Through Dante vs. Ryu)<br>1. Karma Hunter (96)<br>2. Master Moltar (87)<br>3. UltimaterializerX (82)<br>4. Heroic Mario (78)<br>5. Yoblazer (74)<br>6. Lopen (62)<br>7. Board 8 (57)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/1/2006 10:11:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338213497">message detail</a>
 | #066</td></tr>
<tr class="even"><td>
<i>right now that fanbase has the potential to push a Deku Stick to 30% on anyone.</i><br><br>Fortunately, I would happily vote a Deku Stick over Tingle.<br>---<br><b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=264094" class="name">Heroic Mario</a> |
Posted 10/1/2006 10:11:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338213621">message detail</a>
 | #067</td></tr>
<tr class="even"><td>
A Deku Stick is pretty awesome.<br><br>---<br>"<i>Master using it and you can have this.</i>"<br>http://img90.imageshack.us/img90/160/masterjg3.jpg
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/1/2006 10:12:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338213819">message detail</a>
 | #068</td></tr>
<tr class="even"><td>
Isn't Tingle going to be in TP? &gt;_&gt;<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i><br>Michelle.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=264094" class="name">Heroic Mario</a> |
Posted 10/1/2006 10:14:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338214329">message detail</a>
 | #069</td></tr>
<tr class="even"><td>
I haven't heard anything about Tingle in TP, myself.<br><br>---<br>"<i>Master using it and you can have this.</i>"<br>http://img90.imageshack.us/img90/160/masterjg3.jpg
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=304351" class="name">Mac Arrowny</a> |
Posted 10/1/2006 10:30:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338217537">message detail</a>
 | #070</td></tr>
<tr class="even"><td>
I'm pretty sure Nintendo promised <i>not</i> to put Tingle in TP, after they discovered that Americans hate him.<br>---<br>Pity for the guilty is treason to the innocent.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3052691" class="name">satai_delenn</a> |
Posted 10/1/2006 10:54:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338222385">message detail</a>
 | #071</td></tr>
<tr class="even"><td>
Lopen is my hero.<br>---<br>Beating FE5 and FE6
hard mode is a true test of manhood in the Japanese culture. However.
This explains why they have a lot of effeminate men. ~Sytha
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 10/1/2006 11:11:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338225873">message detail</a>
 | #072</td></tr>
<tr class="even"><td>
I know I didn't see someone diss the Deku Stick.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), FE8, Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/1/2006 11:16:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338226982">message detail</a>
 | #073</td></tr>
<tr class="even"><td>
Oh damn, where'd the time go?  I swear I haven't looked at the results of the match yet....<br><br><i>DpOblivion's Quick Analysis:</i><br><br>Just
another boring match before the first highly debated match of the
contest. Hell, I don't even think LoZ fans would vote for Tingle. Can
somebody please explain to me why....WHY.....<b>WHY IN THE ****</b> did Tingle make it in over Knuckles?<br><br>My vote: Sora<br>My bracket: Sora<br>My prediction: Sora with 108% (ok, really just 83%)<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=254355" class="name">Lugia2</a> |
Posted 10/2/2006 5:42:58 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338260284">message detail</a>
 | #074</td></tr>
<tr class="even"><td>
Lopen, shockingly, misses this by a mile. After being so close the last
few times, you'd think he wouldn't try a 100% prediction.<br><br>I guess Tingle gets a lot of joke votes...As a guy who likes Zelda more than KH, I still voted for Sora<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/2/2006 8:10:04 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338267896">message detail</a>
 | #075</td></tr>
<tr class="even"><td>
<i>Lopen, shockingly, misses this by a mile. After being so close the
last few times, you'd think he wouldn't try a 100% prediction.</i><br><br>Considering Tingle was involved, it was worth it.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 1</i>: 41-15 over Sephiroth
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=152338" class="name">Lopen</a> |
Posted 10/2/2006 3:57:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338335649">message detail</a>
 | #076</td></tr>
<tr class="even"><td>
In a just world, where Sora makes Tingle look like Tanner, the point is mine, anyway!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/2/2006 6:21:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338371105">message detail</a>
 | #077</td></tr>
<tr class="even"><td>
Dante.............................65.2% 77894<br>Ryu Hayabusa.............34.8% 41576<br>TOTAL VOTES......................119470<br><br>78.81% of the brackets predicted this match correctly.<br><br>Dante does better than Zero did on Hayabusa by 1.5%. Dante boost, Ryu drop? What does it mean!? We'll find out soon...<br><br>Today, Sora is tripling Tingle...yeah.<br><br>Lopen - 6<br>KH - 4<br>Ulti - 4<br>Moltar - 3<br>HM - 2<br>Yoblazer - 1<br>Guest (Wigs) - 1<br><br>Hit for Lopen! He had the highest Dante pick (surprise!)<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sora vs. Tingle - Bracket: <b>Sora</b> - Vote: <b>Sora</b> (19/20)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/2/2006 8:47:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338411967">message detail</a>
 | #078</td></tr>
<tr class="even"><td>
<b>Destiny Division:</b> <i>Round 1 - Match 22</i> &#8211; (4)Phoenix Wright vs. (5)Gordon Freeman <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Phoenix</b><br>Game/Series Known From: Phoenix Wright: Ace Attorney<br><br>HOLD IT! Phoenix actually made it in the Contest as a 4 seed? That&#8217;s like&#8230;a serious competitor spot!<br><br><b>Gordon</b><br>Game/Series Known From: Half-Life<br>Extrapolated Rank in 2002: 53rd (11.31%)<br>Extrapolated Rank in 2003: 53rd (15.86%)<br>Extrapolated Rank in 2004: 51st (13.40%)<br>Extrapolated Rank in 2005: 37th (20.88%)<br>Seed in 2002: 3<br>Seed in 2003: 7<br>Seed in 2004: 10<br>Seed in 2005: 4<br>Lost in 2002 to Tina in Round 1<br>Lost in 2003 to Max in Round 1<br>Lost in 2004 to Sam in Round 1<br>Lost in 2005 to Leon in Round 1<br><br>The loser we all love is back, and looking to&#8230;WIN?!<br><br>CjayC
knows about GFNW. Really, he has too. So why did he make this match?
Was it to end tradition? Was it because he likes Freeman? Was it
because the G-man made him? Can we just blame the female bracket? We
may never know, but we do know this. Gordon Freeman, the man who hasn&#8217;t
won a single match in his 4 years of Contest history at GameFAQs, faces
one of the biggest rallied characters we&#8217;ve ever seen, Phoenix Wright.
Let the &#8220;Objections!&#8221; begin.<br><br>The only reason this match is in
debate is because of GFNW. Since he&#8217;s never won before, why now? I
mean, he lost to Tina, Sam and Max. That&#8217;s a horrible record. But this
was pre-2005, and pre-Half. Life. 2.<br><br><b>OBJECTION!</b> Half-Life 2 did nothing for Gordon Freeman!<br><br>Wha?
You&#8217;re telling me the guy goes from losing to Sam Fisher to putting up
42% on Leon Kennedy (who avoided the doubling from MEGA MAN), and
Half-Life 2, the man&#8217;s only game in what, 8 years, did nothing for him?
Half-Life 2 pushed Gordon Freeman back into the gaming spotlight AND
was one of the biggest games of 2004, of course he&#8217;s going to get a
very nice boost. Not to mention, Leon had just come off RE4, the
biggest game of 2005.<br><br><b>HOLD IT!</b> Phoenix Wright also has a game and a fad behind him!<br><br>The
game sold poorly (and isn&#8217;t even all that popular on GameFAQs), and a
fad can only take you so far. CATS is the strongest fad character, and
AYB is much, much larger than the Objection fad. Phoenix won&#8217;t even be
near that. That&#8217;s not to say though, that a good chunk of Phoenix&#8217;s
strength will be from his fad supporters, and that should keep him from
being blown out by Freeman. But still&#8230;<br><br><b>OBJECTION!</b> Freeman lost to <i>Tina Freakin&#8217; Armstrong</i>!!<br><br>Yeah,
in 2002. Now he has HL2 behind him, and his name is more out there
because of that. This is Gordon&#8217;s match to lose. If Phoenix beats him,
then I can&#8217;t see Gordon beating anyone, and GFNW would be much stronger
than I had thought, but for now, Freeman wins, the universe implodes,
and everyone is left feeling violated&#8230;.most likely by EC.<br><br><b>Moltar&#8217;s Bracket Says:</b> Gordon Freeman will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Phoenix: 39% - Gordon: 61%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br><br>As
badly as I want Phoenix to win this, his chances are grim. His lone
shot is that he's equal to KOAC 2005 and that Gordon hasn't boosted AT
ALL from Half-Life 2 (KOAC beats the old fodder Gordons in stats).<br><br>The
first note isn't so hard to pull off, but Gordon not boosting at all
from HL2? Phoenix literally needs to get more votes than copies of his
game sold to win this. I'm not holding my breath, but damn if I didn't
wish I were losing a point more than here.<br><br>Prediction: Gordon with 63.33%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>This
match has been the subject of much debate for absolutely no reason
whatsoever. There are a few vocal Phoenix Wright supporters and as a
result, this match is actually anticipated to be something <i>good</i>. Well, I can safely say that the only thing good about this will be shutting up everyone on the Phoenix Wright bandwagon -- <i>they&#8217;re dreadfully annoying</i>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/2/2006 8:47:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338412149">message detail</a>
 | #079</td></tr>
<tr class="even"><td>
Gordon Freeman has a history in these contests of never being able to
win a match, despite being in the contest since 2002. This has gained
him the reputation of a loser who just cannot win a match no matter who
he is placed against. His opponents? Tina Armstrong (2002), Max Payne
(2003), Sam Fisher (2004), and Leon Kennedy (2005) &#8211; out of these
matches, which one of them looks out of place? Tina Armstrong back in
2002! Are the others completely understandable and even <i>expected</i>?
Yes, I think so. That means that Freeman has only had one match
throughout this contest history where he was expected to win and
didn&#8217;t. Regardless of this fact, people insist that he has lost to the
worst of characters in these contests and therefore cannot beat
absolute fodder like Phoenix Wright. <br><br>But let&#8217;s check out what
Phoenix Wright has going for him. Is it the measly 50,000 copies his
game has sold? Perhaps the generic looking anime design? Maybe the fact
he has some absurd &#8220;Objection!&#8221; fad behind him. These all sound like
reasons to win, right? Yeah&#8230;no. Phoenix Wright is only being given a
chance in this match because Gordon Freeman has never won &#8211; a dumb
reason if I have ever heard one. <br><br>Freeman should take care of
Phoenix Wright without much trouble here. He may be losing after the
first minute update and possibly the second five minute update, but
that will be it. If he isn&#8217;t losing then, this match will just get
uglier as time goes by. Phoenix&#8217;s best time is going to be around the
board vote, and if he cannot get a big lead there then his chances at
winning will be gone &#8211; not like he ever had a chance to begin with. <br><br>Gordon
is looking very good with Half-Life 2 in his corner &#8211; the same HL2 that
allowed him to put up 40% on Leon Kennedy &#8211; and it only helps that he
is sporting the Half-Life symbol in his picture once again. Expect this
one to not even be close. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Gordon Freeman<br><br><b>Aitch Emm&#8217;s Prediction:</b> Gordon Freeman &#8211; 60% ; Phoenix Wright &#8211; 40%<br><br><b>Aitch Emm&#8217;s Vote:</b> Gordon Freeman<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>I
want to write a long piece about how this will be one of the most
historic matches and days in Board 8 history, but I'm pretty dog on
tired (and I'm probably not even good enough to make it readable), so
I'll delve straight into the match itself.<br><br>The extremely
well-received Phoenix Wright is one of very few contest entrants to
have never appeared on a home console. Other than the charismatic
Wright, the only characters who share this honor (off the top of my
head, anyway) are Soma Cruz and those Golden Sun guys from 2003.
Without any Internet fads on his side, it's perfectly logical to assume
that Phoenix would be weaker than all three of them. He stars in only
one game, and that game has only sold about 50,000 copies since its
release in the US. As for the various Internet fads, I doubt they'll
help Phoenix much at all. The Objection site is absolutely nothing
compared to AYB, and we've all seen how strong CATS is these last four
years. I believe they have been overhyped and exaggerated, and I doubt
they'll do much to help Phoenix. All in all, the lawyer's resume seems
terrible if one wants to actually win a match, but when your opponent
is Mr. Board 8, you're going to get support whether you want it or not.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/2/2006 8:48:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338412421">message detail</a>
 | #080</td></tr>
<tr class="even"><td>Gordon Freeman is a beautiful man. Four times he
has been cast down, and, like a Phoenix rising from the ashes, four
times he has risen... wait, better not get carried away. Anyway, the
main argument against Gordon is that his performance against Leon
Kennedy last year was a fluke, and that his hilariously bad contest
history will get the better of him yet again. Personally, I think this
argument is a blissfully ignorant one. Isn't it convenient that
Gordon's lone "fluke" of an impressive performance comes on the heels
of his first game in over six years (and only his second game ever)?
Folks, Half-Life 2 was big. It was massively hyped and anticipated,
sold millions of copies, and was hailed by gamers and critics alike as
one of the great games of this era. Hell, it even did fairly decently
in the Game of the Year polls (a hell of a lot better than PW did,
anyway). Don't many people argue that Crono, Magus, and Frog would get
stronger if a new Chrono Trigger were released? Wouldn't you think
Alucard would boost if a big new Castlevania game released with him as
the star? Why should Gordon and Half-Life 2 be an exception? He's
stronger now than in years past, and even if he's lost some of his 2005
sizzle, he should still have enough to win this match. Universe over.
Thank god I was able to get ahold of The Little Mermaid a day early.<br><br>My prediction: Gordon Freeman def. Phoenix Wright (62-38)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Let not the 2005 stats fool you. Gordon Freeman <i>is</i> fodder. There was no <i>massive Half Life 2</i> boost. No no. Let me tell you why I think Gordon Freeman looked so good last year.<br><br>It was the first time he faced an opponent who didn't suck.<br><br>Now
try this on for size. I'm telling you Gordon Freeman has an odd
fanbase. He's got a highly devoted little core out there&#8230; and then he
struggles to get <i>any more votes</i> against <i>anything</i>. So
that means he can still put impressive numbers against Leon Kennedy,
but he'd still choke against the likes of Lloyd Irving, for example.
Put Freeman against Link, and I think he gets another "massive HL2
boost", if you catch my drift. "WOW GUYZ, LOOK, HE GOT 28% ON LINK!"<br><br>But, even though I don't buy Gordon Freeman is anything more than fodder, even after Half Life 2... his opponent is&#8230; <i>Phoenix Wright</i>. Some dude from some game about lawyers that you can't even try to find in stores. Gordon's bad, but Phoenix is worse!<br><br><b>Lopen's prediction:</b> Gordon Freeman with 53.24%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br> <br><b>PHOENIX WRIGHT</b><br> <br><i>"OBJECTION!"</i><br> <br>N/A<br> <br>Move over, Tales of Symphonia, King of All Cosmos, Manny Calavera, and Shadow of the Colossus! There's a new, <i>rabid</i>
Board 8 fad in town, and he goes by the name of Phoenix Wright! With
big thanks in part to his cult classic game that has captivated the
Board's hearts and minds, Phoenix Wright not only makes his debut in
the GameFAQs Contests, but does so in the 32 male field -- as a <i>4 seed.</i> That shows he has fans outside of Board 8 that nominated him. And he has a fad going for him as well, which is nice! Wow...<br> <br>...he's still going to be fodder of the worst kind. WOO PHOENIX <br> <br>Of course, for him it kinda helps that he's facing...<br> <br><b>GORDON FREEMAN</b><br> <br><i>"..."</i><br> <br>Summer 2002 Contest<br>Extrapolated Strength --- 53rd Place [11.31%]<br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 53rd Place [15.35%]<br> <br>Summer 2004 Contest<br>Extrapolated Strength --- 54th Place [13.40%]<br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 40th Place [20.88%]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/2/2006 8:49:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338412751">message detail</a>
 | #081</td></tr>
<tr class="even"><td>
Look at his quote. Look at his contest history. There's a reason why we
say GFNW, but this only tells a part of the story. He not only loses,
he loses to the most <i>pathetic</i> of competition (yet always breaks 40%). If that holds true here, he, again, has no chance.<br> <br>Should I believe in superstition? In the GameFAQs Contests? Uh...I can't believe I'm seriously asking myself this! WOO GORDON<br> <br><i>Notable Releases Since Last Appearance</i><br><br>Phoenix Wright: Phoenix Wright: Ace Attorney (DS)<br>Gordon Freeman: N/A<br><br><i>Upcoming Releases</i><br><br>Phoenix Wright: Phoenix Wright: Justice for All (DS)<br>Gordon Freeman: N/A<br><br>Y'know,
The Prince of Persia would have been much better here. He would have
caused considerable debate on if he could have beaten Gordon (because
let's face it, a ton of people think he'll be fodder of the worst
kind). He's a standard human character that GF has been used to facing.
We'd get to see him in a winnable match (and honestly, wouldn't
Kirby/PW be a fun match too?).<br> <br>But most importantly, THE
UNIVERSE GETS TO NOT IMPLODE! Bah. I just...*can't* see much of a way
for PW to win this. I'd take Sam Fisher, Max Payne, and even Tina
Armstrong to beat Wright. I can't see 40% on Leon Kennedy from him, I
can't see much of <i>anything</i> from him. I kinda expected him to be 8 seed fodder here, but now he gets to kill us all.<br> <br>Objection, you say? OVERRULED.<br><br>Karma Hunter's Vote: The Universe! (aka PW)<br><br><b>Karma Hunter's Krazy Prediction: Gordon Freeman with 57.72%.</b><br> <br>This could end up ANYWHERE, so I just went with a middle percentage.<br><br><b>Upset Potential: 25%<br> <br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br> <br>You'd think I'd give <i>Gordon Freeman</i> a free pass???<br> <br>There
are plenty of somewhat feasible arguments for Wright, ranging from
Gordon being overrated in 2k5 to the fad helping him out a la CATS to
his games being much more popular on GameFAQs than the real world. Or
maybe his picture is just cooler. But y'know what? That's
inconsequential.<br> <br>if PW wins, it's for one reason: Gordon. Freeman. <i>NEVER.</i> Wins. Period.<br> <br>Upset Prediction: Phoenix Wright with 53.48%<br><br><br><br><b>Guest&#8217;s Analysis</b> - <i>warning_crazy</i><br><br>http://objection.mrdictionary.net/go.php?n=1114367<br><br> <br> <br>Crew Consensus: Lots of confidence in Gordon winning...wow, I never thought I'd say something like that.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/2/2006 8:57:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338414861">message detail</a>
 | #082</td></tr>
<tr class="even"><td>
...No music on the objection? Massive fail.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i><br>Michelle.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/2/2006 8:58:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338415086">message detail</a>
 | #083</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Goodbye, perfect bracket; it
was nice knowin' ya. Yup, I ignored all logic, and just played along
with GFNW. And now I'm gonna pay for it, before my defense of Vincent
and Luigi can really matter.
Unless....miraculously........no......Gordon Freeman can't be that
bad.....can he??<br><br>My vote: Phoenix Wright (GFNW damn it!)<br>My bracket: Phoenix Wright<br>My prediction: *sigh....* Gordon Freeman with 54%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/2/2006 8:59:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338415563">message detail</a>
 | #084</td></tr>
<tr class="even"><td>
despite this match being fodder vs. fodder, I don't think I've ever
anticipated the first five minutes of a poll more than this one. I
can't wait to see what happens, because anything could.<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/2/2006 9:02:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338416467">message detail</a>
 | #085</td></tr>
<tr class="even"><td>
I'm interested to see how this is going to end up. It's rare when a
match could have such a wide range of percentage possibilities. Gordon
could go anywhere from losing, to winning with 70% of the vote.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sora vs. Tingle - Bracket: <b>Sora</b> - Vote: <b>Sora</b> (19/20)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=254355" class="name">Lugia2</a> |
Posted 10/2/2006 9:04:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338417014">message detail</a>
 | #086</td></tr>
<tr class="even"><td>
How does fodder get 4 seeds again?  KoaS sure didn't.  CATS couldn't-and can't.<br><br>I'm
sorry, but as someone who picked PW- though still uncertain over the
complete authority that is GFNW- I cannot see how such support is
ironclad.<br><br>Then again, the predictions of the crew were far more believable than the Guest's, but, somehow, I'm not converted...<br><br>Meh.  We'll see the back end of Phoenix tomorrow if board 8 consensus is right.<br><br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=941543" class="name">Shivan Reincarnated</a> |
Posted 10/2/2006 9:09:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338417746">message detail</a>
 | #087</td></tr>
<tr class="even"><td>
<i>How does fodder get 4 seeds again? </i><br><br><br>Kerrigan?<br><br><br>---<br><i>Let the snow fall deep, the rain drive down, and the wind buffet my cloak. I care not for I've a road worth walking</i> ~ Drizzt Do'Urden
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/2/2006 9:28:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338422903">message detail</a>
 | #088</td></tr>
<tr class="even"><td>
<i>How does fodder get 4 seeds again? </i><br><br>Max Payne, Sam
Fisher, Kerrigan, Suikoden, Sigma, Luca Blight, Terra, Joanna Dark, and
even Gordon Freeman himself would like to explain it to you sometime.
Don't think because Phoenix got a four-seed as well means he's suddenly
the favorite against Gordon.<br><br><br>As a side-note, Harmonica, if
you're reading, confirm that our two-week sig-bet is still on by 11:50,
or else I'm going to consider our bet off. The original bet was that
I'm taking Gordon Freeman to win with 60+%...so let me know real soon.<br>---<br><b>Z1mZum</b> <i>performed a hit and run</i> on me in the Guru Contest.<br>It still hurts to be rear-ended like that.....
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3623587" class="name">Gaddswell</a> |
Posted 10/2/2006 10:21:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338436659">message detail</a>
 | #089</td></tr>
<tr class="even"><td>
Don't worry Dp, you're not alone. My perfect dies with the universe.<br><br>Although I do have Ganon and Zero winning their matches.<br>---<br>By the time we localize the programs, kids don&#8217;t even know they&#8217;re from Japan any more. - 4Kids CEO Al Kahn
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=152338" class="name">Lopen</a> |
Posted 10/2/2006 11:24:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338450106">message detail</a>
 | #090</td></tr>
<tr class="even"><td>
The point is mine, gentlemen!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/2/2006 11:27:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338450704">message detail</a>
 | #091</td></tr>
<tr class="even"><td>
At least I corrected my mistake before the match started, that should
count for something. Yeah....I'm still perfect, in spirit....<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=264094" class="name">Heroic Mario</a> |
Posted 10/3/2006 1:27:39 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338466954">message detail</a>
 | #092</td></tr>
<tr class="even"><td>
<i>The point is mine, gentlemen! </i><br><br>Haw haw! The point will be <i>mine!</i><br><br>---<br>"<i>Master using it and you can have this.</i>"<br>http://img90.imageshack.us/img90/160/masterjg3.jpg
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3763340" class="name">TJam_and_Earl</a> |
Posted 10/3/2006 1:43:14 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338468264">message detail</a>
 | #093</td></tr>
<tr class="even"><td>
Tagging<br><br><br><br><br><br><br><br><br>Pheonix will win.<br><br>*Runs*<br>---<br><i>Well...[Daisy's] evil in a Nintendo sort of way...which is like a nice person who doesn't do evil things.</i> ~ Lil69Leo<br>Current Score: Perfect!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=254355" class="name">Lugia2</a> |
Posted 10/3/2006 5:14:14 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338478569">message detail</a>
 | #094</td></tr>
<tr class="even"><td>
Well of COURSE Payne and Fisher got 4 seeds! We didn't know they were
crap yet! Anyone remember the Kerrigan&gt;Vincent people? We mostly
took them seriously until Vincent tripled her!<br><br>Guys?
Mr. Fodder isn't behind by 4,000 votes yet. Wait until that before you
brag about who gets the point. Pride befoe the fall, or something like
that...<br><br>Looks like I lost my perfect too...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=1143722" class="name">Vlado</a> |
Posted 10/3/2006 5:15:49 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338478628">message detail</a>
 | #095</td></tr>
<tr class="even"><td>
<i>CATS couldn't-and can't.</i><br><br>Refer to the villain contest. Also, CJay has admitted that he keeps <i>certain</i> characters down in the seeds regardless of how many nominations they get. We can all figure out who he was talking about.<br>---<br><b>Vlado's Awards for Posting Excellence</b>:<br>http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30885086
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=1143722" class="name">Vlado</a> |
Posted 10/3/2006 5:20:31 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338478807">message detail</a>
 | #096</td></tr>
<tr class="even"><td>
Heh, apparently no one but WC took Phoenix.<br>---<br><b>Vlado's Awards for Posting Excellence</b>:<br>http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30885086
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2797132" class="name">appestats</a> |
Posted 10/3/2006 6:09:38 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338480829">message detail</a>
 | #097</td></tr>
<tr class="even"><td>
Tag
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/3/2006 6:11:28 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338480891">message detail</a>
 | #098</td></tr>
<tr class="even"><td>
ATTN: Guests<br><br>STOP MAKING ****TY PICKS KTHX.<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=964696" class="name">TheRye</a> |
Posted 10/3/2006 8:51:52 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338490232">message detail</a>
 | #099</td></tr>
<tr class="even"><td>
<i> ATTN: Guests<br><br>STOP MAKING ****TY PICKS KTHX. </i><br><br>I second that.<br>---<br>Congrats to <b> Z1mZum </b> and his Guru ownage<br>&#8220;TheRye is like Jesus, if Jesus ever played video games.&#8221; -Inviso
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/3/2006 8:53:46 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338490388">message detail</a>
 | #100</td></tr>
<tr class="even"><td>
Hit or miss Lopen hits again!<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 2</i>: Etna
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">1</a></li>
<li>2</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=9">10</a></li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage2_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30854544&amp;page=1" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage2_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>