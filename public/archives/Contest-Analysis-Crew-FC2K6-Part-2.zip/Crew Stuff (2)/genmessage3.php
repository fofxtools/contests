<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage3_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage3_files/nogs.css"></head><body linkifytime="271" linkified="4" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage3_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/afterhours/">After Hours</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage3_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30854544%26page%3D2"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage3_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage3_files/advertisement.gif" alt="advertisement" height="10" width="120"></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage3_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage3_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 2
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;page=2">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30854544" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=1">Previous Page</a> |
Page 3 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=3">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=254355" class="name">Lugia2</a> |
Posted 10/3/2006 2:17:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338527823">message detail</a>
 | #101</td></tr>
<tr class="even"><td>
<i> ATTN: Guests<br><br>STOP MAKING ****TY PICKS KTHX.<br><br>I second that.</i><br><br>I
third that. As a former PW supporter, I thought it needed a bit more
logic. The thought I was going through would've made it closer to 50%.
Oh well...<br><br>Actually, it looks like KH has this.  Lopen goes with the lowest...and loses.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/3/2006 2:42:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338532743">message detail</a>
 | #102</td></tr>
<tr class="even"><td>
MM whats your email again &gt;_&lt;; Gotta get to sending you Ganon/Vincent pretty soon =P
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3602792" class="name">Garsha_III</a> |
Posted 10/3/2006 3:08:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338538131">message detail</a>
 | #103</td></tr>
<tr class="even"><td>
Mind if I can know too?<br>---<br>George Harrison &gt; Flonne
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/3/2006 3:14:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338539357">message detail</a>
 | #104</td></tr>
<tr class="even"><td>
<a class="linkification-ext" href="mailto:MasterMoltar@gmail.com" title="Linkification: mailto:MasterMoltar@gmail.com">MasterMoltar@gmail.com</a><br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Phoenix vs. Gordon - Bracket: <b>Gordon</b> - Vote: <b>Gordon</b> (20/21)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=152338" class="name">Lopen</a> |
Posted 10/3/2006 3:26:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338541923">message detail</a>
 | #105</td></tr>
<tr class="even"><td>
<i>Don't get too cocky</i>...<br><br>Yeah, yeah.  Well, at least my Oracle looks good now!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/3/2006 3:40:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338545167">message detail</a>
 | #106</td></tr>
<tr class="even"><td>
Sora........................75.61% 93568<br>Tingle......................24.39% 30176<br>TOTAL VOTES..................123744<br><br>92.66% of the brackets predicted this match correctly.<br><br>It
may be Tingle, but he's still from Legend of Zelda. Even being one of
the worst characters in the series can put up nearly 25% on Sora.<br><br>Today, Freeman is <i>winning</i>...wow.<br><br>Lopen - 6<br>Moltar - 4<br>KH - 4<br>Ulti - 4<br>HM - 2<br>Yoblazer - 1<br>Guest (Wigs) - 1<br><br>Yay me.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Phoenix vs. Gordon - Bracket: <b>Gordon</b> - Vote: <b>Gordon</b> (20/21)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/3/2006 8:06:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338613199">message detail</a>
 | #107</td></tr>
<tr class="even"><td>
<i>Hit or miss Lopen hits again!</i><br><br>No foresight Leonhart strikes again!<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/3/2006 8:10:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338614080">message detail</a>
 | #108</td></tr>
<tr class="even"><td>
<b>Destiny Division:</b> <i>Round 1 - Match 23</i> &#8211; (3)Kratos vs. (6)Ryu <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Kratos</b><br>Game/Series Known From: God of War<br>Extrapolated Rank in 2005: 44th (18.70%) <br>Seed in 2005: 3<br>Lost in 2005 to Alucard in Round 1<br><br>The God of War is back and with another 3-seed. Impressive.<br><br><b>Ryu</b><br>Game/Series Known From: Street Fighter<br>Extrapolated Rank in 2002: 10th (34.62%)<br>Extrapolated Rank in 2003: 18th (30.69%) <br>Extrapolated Rank in 2004: 9th (29.84%) <br>Extrapolated Rank in 2005: 23rd (27.47%)<br>Seed in 2002: 4<br>Seed in 2003: 5<br>Seed in 2004: 9<br>Seed in 2005: 2<br>Lost in 2002 to Samus in Round 2<br>Lost in 2003 to Snake in the Round 3<br>Lost in 2004 to Sonic in Round 2<br>Lost in 2005 to Bowser in Round 2<br><br>While he looks less impressive over the years, the Street Fighter still remains one of the strongest.<br><br>Ouch,
another bad draw for Kratos. Last year, he faces the underseeded
Alucard and gets 45% on him, impressing a lot of people. Now he faces
Ryu, who is another underseeded opponent. Ryu should have no trouble
here, unless he&#8217;s fallen further off the map.<br><br>Don&#8217;t let Kratos&#8217;
2005 number fool you though, the God of War is pretty strong, and 40%
on Ryu is a nice number to shoot for (and in reach too).<br><br><b>Moltar&#8217;s Bracket Says:</b> Ryu will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Ryu: 60% - Kratos: 40%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br><br>All that whining about how the female side sucked, yet the male side hasn't been any less predictable so far.<br><br>Prediction: Ryu with 66.65%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>Believe it or not, this is one of my more <i>anticipated</i> matches of the first round. Why, you ask? Because I&#8217;m a <i>huge</i>
fan of Kratos. That man exudes badass on such a level that almost no
other character can match. The very definition of an anti-hero! Even
better is that Kratos should exceed expectations by quite a bit here,
and he&#8217;ll only grow stronger in the coming years thanks to God of War
II and his original title, God of War, still selling like hotcakes. <br><br>Kratos
came out last year and lost to Alucard in a 55-45 affair, which wasn&#8217;t
too bad considering he was a newcomer. The main issue was when Sora,
who Alucard faced after Kratos, got <i>beamed</i> by Solid Snake,
making the whole group look extremely weak. But regardless, Kratos has
reason to come out this year and receive a fairly significant boost.
Since the last contest, his game has sold an additional 600,000 copies
to bring the total in America to around 1.2 million. Last year, his
game had only sold 600,000 copies. So the exposure is definitely spread
out more and with his new game coming out in 2007, there is a definite
focus on him to put him a step above the one hit wonder action heroes
we see so often these days. <br><br>Ryu, on the other hand, came out
not looking as impressive last year by getting beat down hard by
Bowser. Still a very strong competitor, no doubt about it, but one that
is not <i>as</i> strong as he used to be; this should be beneficial to
Kratos, even moreso if Ryu is lower this year. Of course, this match is
not one that Kratos can win, unfortunately. <br><br>This probably
won&#8217;t be all that exciting, but Kratos is definitely going to surprise
a few folks who think that Ryu is just going to dominate the match.
Kratos should put on an impressive performance here and should bring
himself well above the fodder line. This is one of the characters that
we should see start to become a real strong force in these contests
over time. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Ryu<br><br><b>Aitch Emm&#8217;s Prediction:</b> Ryu &#8211; 58% ; Kratos &#8211; 42%<br><br><b>Aitch Emm&#8217;s Vote:</b> Kratos
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/3/2006 8:10:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338614206">message detail</a>
 | #109</td></tr>
<tr class="even"><td>
<b>Yoblazer&#8217;s Analysis</b><br> <br>Thanks to that jerkwad Sora, this
match is a bit tough to peg. While Ryu is one of the contest's more
consistent performers, Kratos was obviously behind a huge anomoly last
year (Snake/Sora). According to the stats, Ryu would beat the God of
War star with about 66%.<br><br>Of course, when one takes a quick look
at Kratos, it's clear that he won't get beaten so soundly. Last year,
he scored a very impressive 44.5% on Alucard, a contest veteran.
Unfortunately, we haven't had a decent read on Alucard since 2003, but
he did decently enough in his losses against Ganondorf and Sora, so
there's no reason for me to believe that he's fallen off the map or
anything. Kratos's first contest experience may have been a pretty good
one, but the big reason I believe he'll do well here lies in recent
popularity of his game.<br><br>Even though God of War was popular and
enjoyed healthy sales upon release, it has practically exploded ever
since becoming a Greatest Hits title. I think sales have actually
doubled since the smaller price tag, and this means an extremely steady
stream of popularity and exposure for Kratos. Right now, it certainly
looks as if Devil May Cry 3's increased sales have given Dante a small
shot in the arm, so the same will probably hold true for Kratos. I
expect him to be stronger this year. With God of War 2 on the horizon
and certain other projects on the PS3 (because Sony would be stupid not
to), Kratos has a huge upside; I think he definitely has the potential
to take the place of guys like Dante and Zero. Right now, however,
he'll have to settle for a respectable loss to Ryu.<br><br>My prediction: Ryu def. Kratos (56-44)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br><br>Ryu may have looked crappier than ever last year, but even <i>with</i>
that crappiness coming through, he still looked better than anything
Alucard has ever done. What does that mean? That means because Alucard
beat Kratos pretty easily last year, Ryu too should have a fairly easy
time taking out the God of War.<br><br>Percentage time? No, not yet.
Sure, I could just throw out a really high % and make you all go like
"haw haw hit or miss Lopen strikes again!", but that's not how I roll.
I want you to <i>feel</i> my thought process!<br><br>Okay, okay&#8230; check this out&#8230; <i>Mario/Street Fighter SFF</i>.
Crazy? Maybe, but just think about it! Ryu got 45% on Sonic, and he can
only manage a paltry 40% on Bowser? Wassapwitdat? I'll tell you
wassapwitdat! They were both hits on the SNES, and Mario rules the
SNES. Oh, sure, Genesis had Street Fighter as well&#8230; but man, it just
wasn't as hip to play Street Fighter on the Sega. It was mainly a SNES
game, it's true! And also, they're both from the old school, that means
Ryu loses all his "icon power" when he goes against Bowser. Yeap. Watch
out for Chun Li, too&#8230; she was also a victim of this nonsense!<br><br>&#8230; what? This makes sense! <i>Open your mind!</i><br><br><b>Lopen's prediction:</b> Ryu with 62.28%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br> <br>lol x-stats history<br> <br><b>KRATOS</b><br> <br><i>"The monster you've created has returned, to kill you.</i><br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 48th Place [18.70%]<br> <br>WOO KRATOS<br> <br><b>RYU</b><br> <br><i>"The fight is everything."</i><br> <br>Summer 2002 Contest<br>Extrapolated Strength --- 10th Place [34.62%]<br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 18th Place [29.70%]<br>Summer 2004 Contest<br>Extrapolated Strength --- 16th Place [29.84%]<br>Summer 2005 Contest<br>Extrapolated Strength --- 25th Place [27.47%]<br> <br>WOO RYU
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/3/2006 8:11:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338614496">message detail</a>
 | #110</td></tr>
<tr class="even"><td>
<i>Notable Releases Since Last Appearance</i><br><br>Kratos: N/A<br>Ryu: N/A<br><br><i>Upcoming Releases</i><br><br>Kratos: God of War II (PS2)<br>Ryu: N/A<br><br>I'm repeatedly watching Walt Disney's <i>The Little Mermaid</i> Two-Disc Special Platinum Edition DVD Boxset right now while waiting for the universe to implode.<br><br>Karma Hunter's Vote: Kratos.<br><br><b>Karma Hunter's Krazy Prediction: Ryu with 59.87%.</b><br><br>Upset Potential: 2.5%<br> <br>Upset Prediction: Kratos with 54.33%<br><br><br><br><b>Guest&#8217;s Analysis</b> - <i>meche313</i><br><br>My
turn to try and give Board 8 a breathe because they are getting such a
beating by the Crew for now, heh. Anyway, the match I'm about to
analyze is between two characters that some other videogame characters
worthy enough to get to a GameFaqs contest have there same name! Who
then? They are obviously Kratos and Ryu!<br><br>I personally took this
match because I like one of the characters or I really think the
underdog can give the other character a run for his money, but of the
remaining matches it was one that looked a bit too debated on the board
(not really between the gurus or veterans on this contest) but that's
why the crew is here afterall.<br><br>So let's go with the analysis.
Both of them had legit matches, no SFF nearby and there numbers seem
reliable enough at first glance. So with the lol x-stats Ryu should get
around 66%. Meche's predict...No! Wait a minute. It's not like that.
Let's really analyze! And what do we get? Oh, right. Ryu had a direct
match with Bowser! Remember that Bowser did too well against Solid
Snake, so he might be slightly overrated. Tidus was behind this, and
look at his match this year. Looks like total fodder. It might be SFF
at its best, but things certainly don't look well so far. What can we
say about Kratos? The opposite really. He was behind the
over-performance of Solid Snake against Sora. So what can we deduct?
That Snake really mess up the lol x-stats last year! Well...yeah, but
looking more into it, the match can actually be more close that what
the stats expect. Now, Street Fighter hang pretty well against post-RE4
RE series, so Ryu, even though last year looked to be his worst, he
shouldn't really fall off the map. Something important to note is that
even if Kratos gets God of War 3 tomorrow, he would lost anyway. And
that's that.<br><br>Meche's prediction: Ryu with 62.55%<br><br> <br>Crew Consensus: Kratos will do well on Ryu, but he isn't going to win. Ryu from the mid-high 50's to the mid-60's.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/3/2006 8:19:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338616855">message detail</a>
 | #111</td></tr>
<tr class="even"><td>
<i>That man exudes badass on such a level that almost no other character can match.</i><br><br>Too bad his opponent is one of those few who exceeds that level!<br><br>And KH stole the Ryu line from my write-up!<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 2</i>: Etna (0-1)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=264094" class="name">Heroic Mario</a> |
Posted 10/3/2006 8:32:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338620312">message detail</a>
 | #112</td></tr>
<tr class="even"><td>
Ryu never approaches that level!<br><br>---<br>"<i>Master using it and you can have this.</i>"<br><a class="linkification-ext" href="http://img90.imageshack.us/img90/160/masterjg3.jpg" title="Linkification: http://img90.imageshack.us/img90/160/masterjg3.jpg">http://img90.imageshack.us/img90/160/masterjg3.jpg</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/3/2006 8:33:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338620500">message detail</a>
 | #113</td></tr>
<tr class="even"><td>
Don't think I've forgotten about my PoP write-up either, I've just been
really busy with school, I'll probably write it tomorrow or the day
after.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=254355" class="name">Lugia2</a> |
Posted 10/3/2006 8:59:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338628304">message detail</a>
 | #114</td></tr>
<tr class="even"><td>
...Great. We're back to obvious matches, now that the Phoenix Wright
parade has imploded. Then again, Ganondorf/Vincent is in a few days.
And this time, my pick actually makes more sense than something like
VNW.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/3/2006 10:41:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338653424">message detail</a>
 | #115</td></tr>
<tr class="even"><td>
[This message was deleted at the request of the original poster]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/3/2006 10:43:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338653777">message detail</a>
 | #116</td></tr>
<tr class="even"><td>
Sora vs. Tingle<br>+7 Mo<br>+6 KH<br>+5 HM<br>+4 Guest<br>+3 Yo<br>+2 Ulti<br>+1 Lo<br><br>Phoenix Wright vs. Gordon Freeman<br>+7 KH<br>+6 HM<br>+5 Mo<br>+4 Yo<br>+3 Lo<br>+2 Ulti<br>-1 Guest<br><br>The Rankings (Through Phoenix vs. Gordon)<br>1. Karma Hunter (109)<br>2. Master Moltar (99)<br>3. Heroic Mario (89)<br>4. UltimaterializerX (86)<br>5. Yoblazer (81)<br>6. Lopen (66)<br>7. Board 8 (60)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/3/2006 10:58:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338656942">message detail</a>
 | #117</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>In the wake of Phoenix
Wright vs. Gordon Freeman, this match has been kind of forgotton.
Unless it's just because this is a much more obvious upset. And that's
all I have to say about that, because damn you Gordon Freeman.<br><br>My vote: Kratos, I suppose<br>My bracket: Ryu<br>My prediction: Ryu with 63%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=945395" class="name">FantasyFreak999</a> |
Posted 10/3/2006 11:02:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338658035">message detail</a>
 | #118</td></tr>
<tr class="even"><td>
...dammit!  Why did I pick Kratos?!  This match was so painfully obvious!<br>---<br>"Run, run, or you'll be well done!" <br>~Kefka, Final Fantasy 6~
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786704" class="name">mmmApplesauce</a> |
Posted 10/3/2006 11:19:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338661426">message detail</a>
 | #119</td></tr>
<tr class="even"><td>
How many times has the guest predicted the winner completely wrong now? <br><br>---<br>I love bananas.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/3/2006 11:27:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338662856">message detail</a>
 | #120</td></tr>
<tr class="even"><td>
The thing about Guest is that if you're signing up for a particular
match, and doing so early, chances are you're interested in it because
you think you have something unique to bring to the table -- typically,
this manifests itself in the form of an upset. If the prior matches
were randomly assigned to the same users we've seen so far you wouldn't
see nearly as many matches wrong.<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/3/2006 11:54:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338667094">message detail</a>
 | #121</td></tr>
<tr class="even"><td>
<i>KH is so smart</i><br>---<br><b>Z1mZum</b> <i>performed a hit and run</i> on me in the Guru Contest.<br>It still hurts to be rear-ended like that.....
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=964696" class="name">TheRye</a> |
Posted 10/4/2006 1:58:18 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338680879">message detail</a>
 | #122</td></tr>
<tr class="even"><td>
Has any Guest actually scored a +7?<br><br>---<br>Congrats to <b> Z1mZum </b> and his Guru ownage<br>&#8220;TheRye is like Jesus, if Jesus ever played video games.&#8221; -Inviso
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/4/2006 2:05:01 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338681363">message detail</a>
 | #123</td></tr>
<tr class="even"><td>
A +7 in Yo's system is equivalent to a point in Moltar's, so yeah, Guest has had one +7.<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/4/2006 4:18:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338766789">message detail</a>
 | #124</td></tr>
<tr class="even"><td>
Phoenix Wright...........41.8% 46204<br>Gordon Freeman........58.2% 64324<br>TOTAL VOTES......................110528<br><br>56.77% of the brackets predicted this match correctly.<br><br>Only
56.77% had Gordon winning? Either GFNW reaches farther than I thought,
or people just went "lol high seed winz" for every match.
Yeesh...anyway, Gordon wins with ease.<br><br>Today, Kratos is doing very well against Ryu.<br><br>Lopen - 6<br>KH - 5<br>Moltar - 4<br>Ulti - 4<br>HM - 2<br>Yoblazer - 1<br>Guest (Wigs) - 1<br><br>KH gunning for Lopen.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Kratos vs. Ryu - Bracket: <b>Ryu</b> - Vote: <b>Ryu</b> (21/22)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/4/2006 7:56:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338822700">message detail</a>
 | #125</td></tr>
<tr class="even"><td>
<b>Destiny Division:</b> <i>Round 1 - Match 24</i> &#8211; (2)Mega Man vs. (7)Axel <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Mega Man</b><br>Game/Series Known From: Mega Man<br>Extrapolated Rank in 2002: 3rd (42.91%)<br>Extrapolated Rank in 2003: 4th (38.60%)<br>Extrapolated Rank in 2004: 8th (32.39%) Adjusted Value: 6th (35.99%)<br>Extrapolated Rank in 2005: 6th (35.55%)<br>Seed in 2002: 6<br>Seed in 2003: 2<br>Seed in 2004: 1<br>Seed in 2005: 1<br>Lost in 2002 to Sephiroth in Round 3<br>Lost in 2003 to Sephiroth in the Final 4<br>Lost in 2004 to Link in the Final 4<br>Lost in 2005 to Crono in the Final 4<br><br>It&#8217;s that robot warrior that refuses to die, Mega Man!<br><br><b>Axel</b><br>Game/Series Known From: Kingdom Hearts<br><br>Owner of one of the hottest catchphrases of the year.<br><br>And
the Destiny division ends with another KH character, except this one is
on the losing side of things. Axel, who&#8217;s gotten his fame from KH:
Chain of Memories and KH2, faces Mega Man. Now, Axel may be a
fan-favorite, but Mega Man is&#8230;Mega Man. You don&#8217;t beat Mega Man, heck,
you don&#8217;t come close to Mega Man unless you are a Contest elite. <br><br>If
I wouldn&#8217;t even take Sora over Mega Man, I wouldn&#8217;t dare take Axel over
him. I can&#8217;t see Axel being worth much either. His fan-favorite status
from one of the year&#8217;s biggest games may keep him over 20%, but Mega
Man is looking good to triple this guy. Now commit THAT to memory!<br><br>Er&#8230;I mean, now get THAT memorized.<br><br><b>Moltar&#8217;s Bracket Says:</b> Mega Man will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Mega Man: 78% - Axel: 22%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>I consider it a moral victory if Axel breaks 20%, just because I love him so much..<br><br><b>GOT
IT MEMORIZED? GOT IT MEMORIZED? GOT IT MEMORIZED? GOT IT MEMORIZED? GOT
IT MEMORIZED? GOT IT MEMORIZED? GOT IT MEMORIZED? GOT IT MEMORIZED? GOT
IT MEMORIZED? GOT IT MEMORIZED? GOT IT MEMORIZED? GOT IT MEMORIZED? GOT
IT MEMORIZED? GOT IT MEMORIZED? GOT IT MEMORIZED? GOT IT MEMORIZED? GOT
IT MEMORIZED? GOT IT MEMORIZED? GOT IT MEMORIZED? GOT IT MEMORIZED? GOT
IT MEMORIZED? GOT IT MEMORIZED? GOT IT MEMORIZED? GOT IT MEMORIZED? GOT
IT MEMORIZED?</b> <br><br>Prediction: Mega Man with 75.57%<br> <br> <br><br><b>HM&#8217;s Analysis</b><br> <br>Mega Man once again gets the opportunity to blow away fodder. Yes, folks, Axel is <i>fodder</i> no matter how much you like him<i>!!</i>
I am rather surprised he even managed to get into the contest, but
we&#8217;ve seen that KH2 has had a definite affect on the nominations
judging by Sora&#8217;s #1 seed, Kairi&#8217;s #2 seed, and Riku&#8217;s #3 seed.
However, even with that KH2 effect, they&#8217;re only 2 &#8211; 1 right now as far
as wins are concerned and this is looking to make it a dead even 2 &#8211; 2!
<br><br>There&#8217;s really not much to go into with this match. Mega Man would beat <i>Sora</i>
with absolute ease, so someone like Axel better expect to be destroyed.
The only interesting thing about this match will be to see just how big
of a blowout this ends up being. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Mega Man<br><br><b>Aitch Emm&#8217;s Prediction:</b> Mega Man &#8211; 82% ; Axel &#8211; 18%<br><br><b>Aitch Emm&#8217;s Vote:</b> Mega Man<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>I'm
forced to keep it really short today. We know Mega Man will win, and we
know he is fantastic when it comes to stomping the weak. The question
now is whether or not Axel can get enough Kingdom Hearts support to
avoid this fate. Mega Man is expected to score 69% on last year's Riku,
and while Axel has the same amount of big games as Riku did at that
time (one), I expect Axel to be weaker. Even still, he should be able
to outperform Conker's 24% in 2005. He certainly deserves to.<br><br>My prediction: Mega Man def. Axel (75-25). Got it memorized lmaooooooo
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/4/2006 7:56:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338822866">message detail</a>
 | #126</td></tr>
<tr class="even"><td>
<b>Lopen&#8217;s Analysis</b><br> <br>I don't like matches like this. Why?
Well, for some reason I can't think of anything funny to say about Mega
Man or Axel&#8230; and really, Axel <i>should</i> be a gold mine! I mean, "Got it memorized?" practically sells itself!<br><br>And
then, also, this match isn't debatable either. Mega Man's evil, Mega
Man blows fools' faces off. And make no mistake about it, Axel's face
won't survive. No it won't. But he'll try to escape the blast, he'll
try. He's got the new KH2 on his side, and he's <i>huge</i> in that game! Everybody loves Axel! Axel would totally beat Kairi, man&#8230; I'm sure of it!<br><br>Axel's
not out to win, Axel's just out to make himself look good. That's the
best he can hope for. And I think he will. I think he'll surprise us
all. And this is coming from a man who has Mega Man winning the thing!
So fear not, Mega Man fans&#8230; if Axel obtains a good %, <i>it's all Axel!</i><br><br><b>Lopen's prediction:</b> Mega Man with 71.50%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>MEGA MAN</b><br><br><i>"I AM MORE THAN JUST A ROBOT!"</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 3rd Place [42.91%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 4th Place [38.60%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 6th Place [35.99%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 7th Place [35.55%]<br><br>All
right! Straight from the year 20XX (aka 2006), it's my main man, Mega
Man! While I've traditionally never been much of a MM guy outside of
the Legends games, in the past year or so he and I have become more or
less inextricably linked. Maybe it's the fact that I didn't know how to
charge Atomic Fire. Maybe it's the fact that he's been tied to my <i>now famous</i>
upset over that ditz Samus. But whatever the reason, he's back, and
he's ready to show us what perhaps the most consistent pillar of
strength in these contests can do! He'll easily dispatch his division,
and then lose respectably to Solid Snake in a massive upset. &lt;_&lt;<br><br>After
which he will go on to beat Samus in an even BIGGER upset! Doesn't make
sense, you say? Um, all will be revealed in time...yes...<br><br><b>AXEL</b><br><br><i>"Commit it to memory."</i><br><br>N/A<br><br>Wow.
Never expected to see Axel in one of these things, though I'm far from
disappointed. You can tell that Kingdom Hearts II had a big impact on
the nominations, because Axel is a character that I expect very little
from in this thing. His role in Kingdom Hearts II just wasn't that
great for me to think he can hang with the likes of Sora, Riku, or even
Kairi. I love the guy, but not even the full power of Kingdom Hearts
combined would be able to topple THE KING OF SFF.<br><br><i>Notable Releases Since Last Appearance</i><br><br>Mega Man: N/A<br><br>Axel: Kingdom Hearts II (PS2)<br><br><br><i>Upcoming Releases</i><br><br>Mega Man: N/A<br><br>Axel: N/A<br><br>Not
too much to say here. Just that if Axel performs well on THE KING OF
SFF that we're going to have to expect very big things from KH2 as this
contest goes on. Look out, Snake, Crono, and Link!!!<br><br>Karma Hunter's Vote: Axel. <b>Commit it to memory.</b><br><br><b>Karma Hunter's Krazy Prediction: Mega Man with 77.8%.</b><br><br>I feel like I'm going too high here, but the possibility of Axel just bombing like crazy is too palpable to ignore.<br><br>Upset Potential: 0%<br><br>GOT IT MEMORIZED?
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/4/2006 7:57:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338823102">message detail</a>
 | #127</td></tr>
<tr class="even"><td>
<b>Guest&#8217;s Analysis</b> - <i>Heroic Citan</i><br><br>The first thing
you may notice is that MM got a 2 seed. Let me assure you; that does
not matter. Did that hurt Crono last year? No. Mega Man's first
opponent is Axel, a fan-favorite from the Kingdom Hearts series. KH got
four representatives in this year. That's insane. This is the work of
KHII no doubt. But it doesn't matter here. Mega Man is in no danger of
doing bad here. Axel is not going to be as strong as Sora or Riku.
However, he isn't going to be nothing either. He'll certainly be
stronger than Conker but not by that much.<br> <br>Final Verdict: Mega Man wins with 73.81% <br><br>  <br><br>Crew
Consensus: Mega Man is going to win, and it won't be pretty for Axel.
Hard to say whether or not he'll get a good amount of KH backing.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=254355" class="name">Lugia2</a> |
Posted 10/4/2006 8:05:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338825265">message detail</a>
 | #128</td></tr>
<tr class="even"><td>
Lopen doesn't have the highest.  Neither does KH.  Now it's...<i>Moltar?!?</i><br><br>Okay, what are going to call the Karma Hunter Hunter?  KHH is just stupid.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/4/2006 9:15:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338843738">message detail</a>
 | #129</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Mega Man vs. who? It doesn't
matter, it's some fodder vs. Mega Man. Good, we need a boring match
thrown in here in the midst of this string of excitement.<br><br>My vote: Mega Man<br>My bracket: Mega Man<br>My prediction: Mega Man with 77%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/4/2006 10:16:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338858041">message detail</a>
 | #130</td></tr>
<tr class="even"><td>
Kratos vs. Ryu<br>+7 HM<br>+6 Yo<br>+5 KH<br>+4 Mo<br>+3 Lo<br>+2 Guest<br>+1 Ulti<br><br><b>The Rankings</b> (Through Kratos vs. Ryu)<br>1. Karma Hunter (114)<br>2. Master Moltar (103)<br>3. Heroic Mario (96)<br>4. UltimaterializerX (87)<br>4. Yoblazer (87)<br>6. Lopen (69)<br>7. Board 8 (62)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/4/2006 10:17:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338858348">message detail</a>
 | #131</td></tr>
<tr class="even"><td>
Aw, don't give up like that yo. Kratos might just SUDDENLY AND RANDOMLY DEFY VOTING TRENDS YEAH<br><br>...<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/4/2006 10:21:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338859049">message detail</a>
 | #132</td></tr>
<tr class="even"><td>
Victory is mine KH.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/4/2006 10:22:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338859292">message detail</a>
 | #133</td></tr>
<tr class="even"><td>
I don't see you on the Crew! A victory that is not Crew-sanctioned is hollow.<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/4/2006 10:24:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338859668">message detail</a>
 | #134</td></tr>
<tr class="even"><td>
Pfft... it won't be hollow when Ryu gets 57.15, dead on with my
prediction! And victory is mine more in the sense that you were wrong
about a match 3 times in one day. Now that's pathetic!<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/4/2006 10:26:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338860087">message detail</a>
 | #135</td></tr>
<tr class="even"><td>
That's not your victory, that's just my defeat. Which isn't even that rare.<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=152338" class="name">Lopen</a> |
Posted 10/5/2006 4:13:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=338972010">message detail</a>
 | #136</td></tr>
<tr class="even"><td>
Haha... <i>yes, Axel</i>, roll over Mega Man with the massive after school vote!  Victory is mine!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/5/2006 7:13:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339013875">message detail</a>
 | #137</td></tr>
<tr class="even"><td>
Kratos.....................42.89% 49713<br>Ryu..........................57.11% 66198<br>TOTAL VOTES.....................115911<br><br>48.99% of the brackets predicted this match correctly.<br><br>...This
is our first "upset" prediction percentage-wise of the Contest? This
match? THIS MATCH?! lol casuals and their higher seeds indeed. Ryu was
pretty much destined to win, but Kratos did perfrom very respectably.<br><br>Today, Axel is looking for 30% on Mega Man, and that's pretty good.<br><br>Lopen - 6<br>KH - 5<br>Moltar - 4<br>Ulti - 4<br>HM - 3<br>Yoblazer - 1<br>Guest (Wigs) - 1<br><br>HM looking to catch up...<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Mega Man vs. Axel - Bracket: <b>MM</b> - Vote: <b>Axel</b> (22/23)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/5/2006 7:27:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339017390">message detail</a>
 | #138</td></tr>
<tr class="even"><td>
Another hit for Lopen.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/5/2006 8:49:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339038425">message detail</a>
 | #139</td></tr>
<tr class="even"><td>
<b>Blast Division:</b> <i>Round 1 - Match 25</i> &#8211; (1)Sonic vs. (8)CATS <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Sonic</b><br>Game/Series Known From: Sonic<br>Extrapolated Rank in 2002: 5th (41.05%)<br>Extrapolated Rank in 2003: 10th (34.92%) <br>Extrapolated Rank in 2004: 7th (33.56%) <br>Extrapolated Rank in 2005: 7th (35.28%)<br>Seed in 2002: 1<br>Seed in 2003: 2<br>Seed in 2004: 1<br>Seed in 2005: 1<br>Lost in 2002 to Samus in Round 3<br>Lost in 2003 to Cloud in the Elite 8<br>Lost in 2004 to Samus in the Elite 8<br>Lost in 2005 to Mega Man in the Elite 8<br><br>That Blue Hedgehog is back!<br><br><b>CATS</b><br>Game/Series Known From: Zero Wing<br>Extrapolated Rank in 2002: 47th (13.30%)<br>Extrapolated Rank in 2003: 56th (13.52%) <br>Extrapolated Rank in 2004: 53rd (12.17%)<br>Extrapolated Rank in 2005: 46th  (17.64%)<br>Seed in 2002: 13<br>Seed in 2003: 16<br>Seed in 2004: 16<br>Seed in 2005: 8<br>Lost in 2002 to Ryu in Round 1<br>Lost in 2003 to Cloud in Round 1<br>Lost in 2004 to Link in Round 1<br>Lost in 2005 to Master Chief in Round 1<br><br>That old fad/joke character is back!<br><br>Finally,
we reach THE division to watch in this Contest, the Blast Division.
And&#8230;*INCOMING PUN ALERT*, this division is looking to be a <i>blast!</i><br><br>But
of course, we need to start out with the appetizer. Sonic versus CATS.
Yeah, no point to debate this one, so I&#8217;ll just comment on some things.
Last year, CATS did his best ever, getting over 30% of the vote against
Master Chief. He also had that nice, recognizable face picture in that
match. He has yet another good picture here, so that may help him out.
Also, while Sonic does well against fodder&#8230;he doesn&#8217;t overkill them. So
I think CATS may be able to break 20% in this match.<br><br>Other than that&#8230;I got nothing. On to the next one, and that&#8217;s bound to be a slobberknawker!<br><br><b>Moltar&#8217;s Bracket Says:</b> Sonic will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Sonic: 79% - CATS: 21%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>*plugs in Sonic 2005 against Villain Contest CATS in the Xst calc*<br><br>k<br><br>Prediction Percentage: Sonic with 78.05%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>Hey, look at that &#8211; CATS is back for <i>another</i>
contest! With his opponent being the Blue Hedgehog, this match will
allow us to get an idea of how Sonic is going to fare in strength in
comparison to 2005 &#8211; let&#8217;s hope for an underperformance of epic
proportions! Outside of the percentage, there won&#8217;t be anything too
exciting about this one. CATS has a history of being able to predict
the winner despite being fodder, so we&#8217;ll see if Sonic is looking like
a potential winner or a big loser (round 2, round 2!). <br><br><b>Aitch Emm&#8217;s Bracket:</b> Sonic the Hedgehog<br><br><b>Aitch Emm&#8217;s Prediction:</b> Sonic the Hedgehog &#8211; 76.5% ; CATS &#8211; 23.5%<br><br><b>Aitch Emm&#8217;s Vote:</b> Sonic the Hedgehog<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>I
may very well fall asleep for the next 18 hours, so this is a safety
placeholder more than anything. ALL YOUR BASE ARE BELONG TO US<br><br>My prediction: Sonic def. CATS (79-21)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Sonic
is in last analysis is concern. CATS gets new picture have this match.
It will new affect CATS from 12% on Link's Base to 19% on Link's Base,
perhaps higher. It is uncertain but one thing that is CATS is picture
power voted. The odds are turn CATS third picture is eggplant's
superior, this much is of surest.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/5/2006 8:50:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339038528">message detail</a>
 | #140</td></tr>
<tr class="even"><td>
Noting also CATS obtained on Master Chief 33%. Master Chief is not of competition of jokingly Felix struggling in 2005! &#8230; <i>but</i>,
some would say X-Box/Halo hate is main. This is not likely is faulty
problem. I tell you on this on date that was partially X-Box/Halo hate
but not all the way it is to be not. Slightly balance in that Master
Chief SFF CATS, he only is one with fanatic of fanbase. Also upset <b>DARKNESS</b> all is almost to be last year with proper facing. Undeniable support of CATS last fiercely upon date of face picture on.<br><br>CATS has no chance to win make his time, but survive tripling is truly.<br><br><b>Lopen is Prediction:</b> Taking of Sonic obtain and 74.18%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>SONIC THE HEDGEHOG</b><br><br><i>"What you see is what you get. Just a guy who loves adventure. I'm Sonic the Hedgehog!"</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 5th place [41.05%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 10th place [34.92%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 8th place [33.56%] <br><br>Summer 2005 Contest<br>Extrapolated Strength --- 8th Place [35.28%]<br><br>The
very silent but very real threat to take the male bracket (and
statistically, the main bracket), Sonic the Hedgehog is back in action
with another tough road ahead of him! He definitely impressed last year
in his nailbiter against Mega Man, and while he didn't pull it off, he
showed that he's better than he's been in a long time. However, he and
Snake are the only two Noble Niners to never have won a match over any
other NNer, and Sonic is the only NNer to never make the Final Four.
*sigh* Depressing, and he's not the favorite to do either of those
things this year by any means&#8230;but, hope springs eternal I suppose! WOO
SONIC<br><br> <br><br><b>CATS</b><br><br><i>"You appear to be preoccupied, gentlemen."</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 47th Place [13.30%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 56th Place [13.09%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 58th Place [12.17%]<br><br>Spring 2005 Contest<br>Extrapolated Strength --- 15th Place [19.66%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 49th Place [17.64%]<br><br>It
seems as though Gordon and CATS, two of our most beloved
laughingstocks, are finally coming into their own &#8211; doesn't it? Now,
while CATS is by no stretch of the imagination going to win a match a
la Mr. Freeman, since unlocking his true potential (that is, his face
picture), he gave Ansem a scare and has elevated himself to the level
of tough fodder. Let's see if he can keep up this good streak against
another Noble Niner! WOO CATS<br><br> <br><br><i>Notable Releases Since Last Appearance</i><br><br>Sonic the Hedgehog: Sonic Rush (DS)<br><br>CATS: N/A<br><br><br><i>Upcoming Releases</i><br><br>Sonic the Hedgehog: Sonic the Hedgehog (PS3, X360), Sonic and the Secret Rings (WII)<br><br>CATS: N/A<br><br> <br><br>Y'know,
this will probably be the first time we get a good reading on Face
CATS. With Face CATS being behind Ganondorf's overperformance in the VC
and then behind MC in 2k5, this seems to be our best shot to gauge how
well he can do. As well, we're going to be looking for Sonic to prove
himself to see if he has a shot at getting over the hump and perhaps
finally winning a match against a Noble Niner, perhaps even taking the
male bracket to face Samus&#8230;<br><br> <br><br>&#8230;third time's a charm? In any case, it all starts here.<br><br><br>Karma Hunter's Vote: Sonic. Not that it isn't cool to vote for CATS, but Sonic is nipping at the heels of <i>Mario</i> for my favoritism.<br><br> <br><br><b>Karma Hunter's Krazy Prediction: Sonic the Hedgehog with 77.8%.</b><br><br> <br><br>Too lazy to even switch up predictions. Bah!<br><br>Upset Potential: 0%
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/5/2006 8:51:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339038773">message detail</a>
 | #141</td></tr>
<tr class="even"><td>
&#8230;it's CATS.<br> <br><br><br><b>Guest&#8217;s Analysis</b> - <i>War13104</i><br> <br><b>All your base are belong to us!</b><br> <br>Once again, CATS gets in as a low seed, hoping to scrape on by. Could this be the year?<br> <br> <br>...<br> <br> <br> <br>...<br> <br> <br> <br>...<br> <br> <br> <br> <br>No.<br> <br> <br>Sorry,
Board 8, but CATS isn't losing again this time. Sonic overperformed
last year, and is now being compared to Ganondorf and <b>Vincent</b>. The same Vincent who only put up 80% on Sarah Kerrigan. This is Sonic's weakest year yet, and CATS will take advantage of it.<br> <br>Prediction: CATS with 62.3% at the first update.<br> <br>That's enough of a win for me, but CATS will show strong in the unfair normal voting.<br> <br>Final Prediction: Sonic the Hedgehog with 76.2%<br> <br> <br> <br>Crew Consensus: Sonic beats CATS, I know, surprise surprise. Sonic in the mid-to-high 70's.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=254355" class="name">Lugia2</a> |
Posted 10/5/2006 9:25:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339047529">message detail</a>
 | #142</td></tr>
<tr class="even"><td>
Wow. Shocking. People actually think that Sonic can take the Male
bracket over Mega Man and Crono? In my opinion, there's a better chance
of Ganondorf taking the male bracket than such a thing occuring.<br><br>As for CATS...come on, this isn't against Phoenix Wright or something!  At least 10/7 will be interesting...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/5/2006 9:37:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339050521">message detail</a>
 | #143</td></tr>
<tr class="even"><td>
<i>People actually think that Sonic can take the Male bracket over <b>Mega Man</b> and Crono?</i><br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2125" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2125">http://www.gamefaqs.com/poll/index.html?poll=2125</a><br><br>It's not like he didn't get close last time...<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=264094" class="name">Heroic Mario</a> |
Posted 10/5/2006 9:39:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339050934">message detail</a>
 | #144</td></tr>
<tr class="even"><td>
Or some people think CATS isn't as strong as he was last year. I want
Sonic to underperform like no other in this match, but I like my "safe"
prediction here.<br><br>---<br>"<i>Master using it and you can have this.</i>"<br><a class="linkification-ext" href="http://img90.imageshack.us/img90/160/masterjg3.jpg" title="Linkification: http://img90.imageshack.us/img90/160/masterjg3.jpg">http://img90.imageshack.us/img90/160/masterjg3.jpg</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/5/2006 9:40:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339051319">message detail</a>
 | #145</td></tr>
<tr class="even"><td>
Why do I keep missing the analyses going up?  Ugh.....<br><br><i>DpOblivion's Quick Analysis:</i><br><br>SONIC!!!!!  Finally, he gets his shot to kill CATS, this should be fun.<br><br>My vote: A-DUUUHHHH.....Sonic<br>My bracket: A-DUUUHHHH......Sonic<br>My prediction: Sonic with 86%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/5/2006 9:42:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339051736">message detail</a>
 | #146</td></tr>
<tr class="even"><td>
86%?!<br><br><i>Everyone not named Sonic is so screwed.</i><br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Mega Man vs. Axel - Bracket: <b>MM</b> - Vote: <b>Axel</b> (22/23)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/5/2006 9:43:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339051973">message detail</a>
 | #147</td></tr>
<tr class="even"><td>
I like Dp's analyses. It's refreshing to see someone who obviously doesn't look at the stats for his predictions. &lt;_&lt;<br><br>(seriously, not a knock against ya)<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/5/2006 9:43:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339051993">message detail</a>
 | #148</td></tr>
<tr class="even"><td>
It's Sonic....bias is involved.<br><br>At least I didn't put his % over what Link scored on CATS two years ago.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/5/2006 9:44:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339052216">message detail</a>
 | #149</td></tr>
<tr class="even"><td>
Thanks, KH. That's why I like doing it like this, instead of officially
with the Crew, so I don't have to take it too seriously. I just make it
up on the spot when it's time.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=640243" class="name">Big Bob</a> |
Posted 10/5/2006 9:45:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339052438">message detail</a>
 | #150</td></tr>
<tr class="even"><td>
Oddly enough, for the 4 remaining NN males, their stengths last year is inversely proportional to their potential this contest:<br><br>Crono - No reason to go up<br>Mega Man -  MMX Collection (mild), MMZX (mild)<br>Sonic - Sonic Rush (mild), new StH (low-mid) and SatSR (low-mid)<br>Snake - Metal Gear Solid 4 (big), Super Smash Bros. Brawl (big)<br>---<br>"My opinion matters more to me than yours does." - Ulti
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=1">2</a></li>
<li>3</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=9">10</a></li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage3_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30854544&amp;page=2" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage3_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>