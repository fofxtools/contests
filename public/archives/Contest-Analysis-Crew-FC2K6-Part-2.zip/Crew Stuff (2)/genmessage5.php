<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage5_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage5_files/nogs.css"></head><body linkifytime="281" linkified="1" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage5_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/afterhours/">After Hours</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage5_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30854544%26page%3D4"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage5_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage5_files/advertisement.gif" alt="advertisement" height="10" width="120"></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage5_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage5_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 2
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;page=4">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30854544" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=3">Previous Page</a> |
Page 5 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=5">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/7/2006 1:37:28 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339278275">message detail</a>
 | #201</td></tr>
<tr class="even"><td>
Wow, what a match. This is awesome.<br><br><i>?Wow,
that's some wall that everyone's put up. Even DP and Tranny put up nice
walls and they're not even part of the crew! Too bad not every match is
like this one.</i><br><br>Yeah, what a match.......even <i>three</i> paragraphs from me is a lot.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=254355" class="name">Lugia2</a> |
Posted 10/7/2006 6:29:55 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339294829">message detail</a>
 | #202</td></tr>
<tr class="even"><td>
Still only 2000 ahead!  Go Ganon!<br><br>Well,
I'm glad this isn't boring, anyway. I worried that it was, like the
"debatable" matches...Looks like Sonic may well get a free ride to
Round 3.<br><br>But then, only HM truely believed that was going to
happen anyway. And he might not, considering that TP might not be out
by then. And that TP isn't exactly walloping Vincent here...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/7/2006 3:56:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339374896">message detail</a>
 | #203</td></tr>
<tr class="even"><td>
Sonic the Hedgehog......80.75% 87757<br>CATS...............................19.25% 20925<br>TOTAL VOTES..........................108682<br><br>96.38% of the brackets predicted this match correctly.<br><br>Sonic has no problems breaking 80% on CATS. Not bad for the Blue Blur...<br><br>Today, Vincent is beating Ganon in a close match.<br><br>Lopen - 7<br>Moltar - 5<br>KH - 5<br>Ulti - 4<br>HM - 3<br>Yoblazer - 2<br>Guest (Wigs) - 1<br><br>Yo and I had the highest Sonic picks, so yay!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Ganondorf vs. Vincent - Bracket: <b>Ganondorf</b> - Vote: <b>Ganondorf</b> (24/25)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/7/2006 3:58:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339375327">message detail</a>
 | #204</td></tr>
<tr class="even"><td>
The whole crew underestimated Sonic.....I'm disappointed in you all.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/7/2006 4:00:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339375646">message detail</a>
 | #205</td></tr>
<tr class="even"><td>
I'm thinking I'm gonna be riding high in yo's system for a <i>long</i> time after this one...<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/7/2006 4:15:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339378808">message detail</a>
 | #206</td></tr>
<tr class="even"><td>
I suppose Lopen can start laughing at everyone for using "Who wins:
Dante or Auron?" as justification for picking Ganondorf while Lopen
used it to justify Vincent...<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 2</i>: W, 52-14 vs. Etna
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/7/2006 6:50:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339411811">message detail</a>
 | #207</td></tr>
<tr class="even"><td>
Looks like Ulti's got the point today.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/7/2006 6:51:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339412009">message detail</a>
 | #208</td></tr>
<tr class="even"><td>
[This message was deleted at the request of the original poster]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=683142" class="name">transience</a> |
Posted 10/7/2006 6:51:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339412091">message detail</a>
 | #209</td></tr>
<tr class="even"><td>
aw yeah, 0-1 in my analysis crew career! <br>---<br>Query
"Results" failed: You have an error in your SQL syntax. Check the
manual that corresponds to your MySQL server version for the right
syntax to use near ' WHERE Gordon.IsWinner = True AND Predic <b>|| </b>Winner: Strider Hiryu - 57.11%
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/7/2006 9:44:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339450288">message detail</a>
 | #210</td></tr>
<tr class="even"><td>
<b>Blast Division:</b> <i>Round 1 - Match 27</i> &#8211; (3)Kirby vs. (6)The Prince of Persia<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Kirby</b><br>Game/Series Known From: Kirby<br>Extrapolated Rank in 2002: 17th (25.54%)<br>Extrapolated Rank in 2003: 25th (26.34%) <br>Extrapolated Rank in 2004: 30th (20.62%) - Adjusted Value: 22nd (26.61%)<br>Extrapolated Rank in 2005: 12th (32.06%)<br>Seed in 2002: 14<br>Seed in 2003: 3<br>Seed in 2004: 5<br>Seed in 2005: 1<br>Lost in 2002 to Jill in Round 1<br>Lost in 2003 to Alucard in Round 2<br>Lost in 2004 to Squall in the Round 2<br>Lost in 2005 to Bowser in Round 3<br><br>Another of my favorite&#8217;s steps into action!<br><br><b>Prince</b><br>Game/Series Known From: Prince of Persia<br><br>And the Prince makes the field!<br><br>So&#8230;unless
the Prince is like&#8230;a beast, Kirby should have this match easily. The
more Kirby wins by, the better, as he needs to look good going into
next Round. And&#8230;*static*&#8230;winner of&#8230;*more static*&#8230;the match
is&#8230;*connection cuts off, screen goes black*<br><br>Donkey Kong: Yo, turn dem lights on!<br><br>*lights go on*<br><br>DK:
That&#8217;s better. This is your homeboy, Donkey Kong, taking over this
analysis. Change ya pants now, because its only gonna get better. I got
a new &#8220;wreck-cad&#8221; dropping this Tuesday from my Donkey Beatz label.
&#8220;Bananas and Grapes&#8221; Pick it up. I&#8217;m gonna let ya hear the hot new
single too. Check it, Nintendo 4 lyfe!<br> <br>*music starts*<br><br>They see me rollin'<br>They hatin'<br>I&#8217;m blowin'<br>And tryin to catch me ridin Kirby<br>Tryin' to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>My powers so wild<br>I'm suckin&#8217;<br>They hopin'<br>That they gon' catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br><br>(Kirby)<br>Yo it&#8217;s me, big Kirby, on the mic<br>Gonna tell a little story of what&#8217;s it&#8217;s like<br>To be me, a pink ball named Kirby<br>In a world that&#8217;s controlled by that damn Sony<br><br>I&#8217;m rollin&#8217; with my boyz in the neighboorhood<br>Life was so sweet and it all was good<br>So then one of Sony&#8217;s reps comes up to me<br>I could tell that the bastard worked for Kutaragi<br>I say, &#8220;Shouldn&#8217;t you be working on the PS3?<br>Or trying to move more of them PSPs?&#8221; (cuz DS is killin&#8217;)<br>He says, &#8220;Shut up, little toy, you&#8217;re coming with me.<br>It&#8217;d be best if you come quiet, and peacefully.&#8221;<br><br>So he thinks that just because my skin is pink<br>I don&#8217;t have no rights, and not allowed to think.<br>Just because I really like to blow and suck<br>I come around the city and I&#8217;m out of luck.<br>A Nintendo character can&#8217;t be that way<br>Well, I don&#8217;t give a **** &#8216;bout what society say.<br>I gotta go around and try to be me,<br>But it&#8217;s hard out there for a Kirby&#8230;<br><br>They see me rollin'<br>They hatin'<br>I&#8217;m blowin'<br>And tryin to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>My powahs so wild<br>I'm suckin'<br>They hopin'<br>That they gon' catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br><br>(DK)<br>Man, someone&#8217;s gotta go and help a brotha out.<br>Nintendo pride, yeah I know what that&#8217;s all about.<br>Gotta&#8217; show my love, for the Big Ol&#8217; N<br>And show you why they&#8217;re gonna win.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/7/2006 9:44:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339450387">message detail</a>
 | #211</td></tr>
<tr class="even"><td>
Sony may be leadin&#8217; now but they full of ****.<br>Going into a launch without a big name hit?<br>And only 5-thou units? Like Luthor, that&#8217;s <b>WROOONG</b>!<br>Just as lame as a gaming reference in a hip-hop song. (lolz)<br>And they supposed to be appealin&#8217; to all the gamers,<br>Not with crap like 599 and <i>RIIIDGE RACER</i><br>Microsoft&#8217;s also gunning, if you didn&#8217;t know<br>But no one really cares until the next Halo.<br><br>The system you should really get is the Wii<br>Fun for all the guys, girls, and the family<br>And you can play games starring as me,<br>Or my boy, the puff-ball named Kirby (Hiiii!)<br>Nintendo is the best, Nintendo is the greatest!<br>If you don&#8217;t like them, you&#8217;re as bad as a rapist!<br>A real heel, you don&#8217;t even deserve that feel<br>Nintendo and the Kirbies, keepin&#8217; it real.<br><br>They see me rollin';<br>They Haitian<br>Samoan<br>And tryin to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby<br>My powers so wild<br>I'm suckin'<br>They hopin'<br>That they gon' catch me ridin' Kirby.<br>Tryin' to catch me ridin' Kirby.<br>Tryin' to catch me ridin' Kirby.<br>Tryin' to catch me ridin' Kirby<br>Tryin' to catch me ridin' Kirby.<br><br>Aww
yeah, DK&#8230;Kirby&#8230;in the house! Donkey Beatz! Yeeah&#8230;more random shouting
at the end of the song!&#8230;Because that&#8217;s how real Kirbies do&#8230;Random
Shouting&#8230;aww yeah&#8230;&#8230;.Wait, you say we need one more verse?&#8230;.Why?&#8230;The
real song has another verse?&#8230;.Man, screw that&#8230;.This isn&#8217;t even a real
parody&#8230;.I only heard the original song like&#8230;once, I don&#8217;t know it&#8230;Yeah,
that&#8217;s why the rhymes and flow don&#8217;t match up with the original&#8230;I&#8217;m too
lazy to listen to the real version&#8230;.That damn song is still playing in
the background?&#8230;I need to go on&#8230;.Nintendo!&#8230;.Yeah!&#8230;What?&#8230;.You said Ridin
Dirty parodies are like.&#8230;so 2 months old?&#8230;.Aww crap&#8230;.Well, if my match
came sooner, it wouldn&#8217;t be outdated&#8230;..damn female bracket&#8230;.you know,
they killed my father&#8230;..violated my mother&#8230;.kidnapped my
brother&#8230;.female bracket&#8230;.cause of all the war and violence&#8230;.damn
it&#8230;.Man, someone kill that beat&#8230;.I&#8217;m tired of all this&#8230;.Kirby, out!<br><br><b>Moltar&#8217;s Bracket Says:</b> Kirby will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Kirby: 68% - The Prince: 32%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>I
think it's safe to just hand Prince the 2005 Kratos value and be done
with it. It's not like this match is in question, though it'll shed
light on whether or not Kirby was overrated last year.<br><br>Prediction: Kirby with 70.05%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>The
match picture for this match-up is absolutely hilarious &#8211; extremely
cute v. extremely dark! As it turns out, the extremely cute one is
looking to win with ease! Kirby comes into this contest looking to
solidify his amazing near-elite strength the showed off last year while
The Prince is looking to just show he&#8217;s made of <i>something</i> other than fodder.  <br><br>I&#8217;m
expecting Kirby to come into this match and show that his strength last
year was any type of fluke; he&#8217;ll be dominating this match from
beginning to end. There is some question about the Dream Division being
overrated or Kirby getting rSFF on Bowser, but hopefully with a nice
sized blowout, all of that can be put to rest. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Kirby<br><br><b>Aitch Emm&#8217;s Prediction:</b> Kirby &#8211; 72% ; Prince of Persia &#8211; 28%<br><br><b>Aitch Emm&#8217;s Vote:</b> Kirby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/7/2006 9:45:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339450550">message detail</a>
 | #212</td></tr>
<tr class="even"><td>
<b>Yoblazer&#8217;s Analysis</b><br> <br>Even though most of them are being
thrown to the wolves, I'm glad Leonhart's rally tournament got quite a
few new faces into the contest. My favorite of these first-timers is
undoubtedly The Prince of Persia, and it's just faaabulous to see him
here. Unfortunately, he's up against a fluffy, puffy, chewy, gooey
force that's just far too strong in Kirby. I'll be happy if The Prince
can break 30%, but I doubt he'll be able to do much better.<br><br>My prediction: Kirby def. The Prince of Persia (69-31)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>This
going to be brief... I kinda forgot about it. Anyway, for this match,
Kirby's gotta get more on the Prince of Persia than Zero got on Lloyd
Irving, or I'm not feeling the Kirby &gt; Zero pick I made. Well, I
guess it's <i>possible</i> Prince of Persia &gt; Lloyd, but somehow I
don't think so! ToS did well on the GotY polls&#8230; and Prince of Persia
games didn't. I know the GotY polls are unreliable&#8230; but PoP did so bad
in em that I can't take the Prince seriously.<br><br>Well, maybe they didn't do <i>quite</i>
as bad as I remember. I'm going to be honest here, I don't care enough
to check. But, I'm giving this match the dignity of a response, like it
deserves!<br><br>Sorry, EC, I know I just dissed your man by saying Lloyd &gt; him. But it's not like you read these anyway! (You <i>should</i>, though!)<br><br><b>Lopen's prediction:</b> Kirby with 74.07%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>KIRBY</b><br><br><i>"Haiii!"</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 17th Place [25.54%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 25th Place [25.49%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 22nd Place [26.61%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 13th Place [32.06%]<br><br>Hey,
Kirby! Speaking of Kirby, that's another candidate for Board 8's
favorite character, although that's really a byproduct of ol' ertyu
than anything else. The dum pink ball had a great run through last
year's bracket, stunning Tidus (and the board) before getting
dangerously close to a Bowser that ended up equaling Snake in the
stats. Kirby has gone from perennial midcarder to near-elite...perhaps.
This year is his chance to prove it, and it starts with this match. WOO
KIRBY<br><br><b>THE PRINCE OF PERSIA</b><br><br><i>"Most people think
time is like a river, that flows swift and sure in one direction. But I
have seen the face of time and I can tell you -- they are wrong."</i><br><br>N/A<br><br>If
ever there were a newcomer that deserved to kick ass in this bracket,
the Prince of Persia would be it. Witty, charming, badass, with
incredibly awesome swordplay and acrobatics along with the power to
control time, the Prince of Persia has it all. Sadly, he's just going
to be trying to not embarrass himself in this match -- and with the
blowouts we've seen happening routinely in this contest, I'm very
scared for him.<br><br>WOO THE PRINCE OF PERSIA<br><br><i>Notable Releases Since Last Appearance</i><br><br>Kirby: Super Smash Brothers Brawl Trailer (Internet)<br><br>Prince of Persia: Prince of Persia: Sands of Time, Prince of Persia: Warrior Within, Prince of Persia: The Two Thrones<br><br><i>Upcoming Releases</i><br><br>Kirby: Super Smash Brothers Brawl (WII)<br><br>Prince of Persia: N/A<br><br>Ugh.
This one is going to be ugly, I can just feel it. Man, I would give
ANYTHING for the Prince to win here. All my upsets could go up in
smoke, Smurf could win the contest, even Snake could lose to Squall
(pfft he'll be back better than ever after MGS4 and SSBB).
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/7/2006 9:45:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339450628">message detail</a>
 | #213</td></tr>
<tr class="even"><td>But sadly, PoP has no chance here. Even if Kirby
is vastly overrated (a possibility), I wouldn't take the puffball to
lose to, say, Ryu -- and if he did it would be by very little. Ryu beat
the hell out of Kratos even with the God of War doing better than
expected, and Kratos is just about PoP's ceiling.<br><br>Karma Hunter's Vote: The Prince of Persia. And I'd do it again if I got the chance <i>!!</i><br><br><b>Karma Hunter's Krazy Prediction: Kirby with 65.8%.</b><br><br>I fully expect to lose this point handily. I'll be dumbfounded if I'm not the low pick.<br><br>Upset Potential: 0%<br><br>There's always rewind though, right?<br> <br><br><br><b>Guest&#8217;s Analysis</b> - <i>Explicit Content</i><br><br>At
first glance this match may appear to be more obvious than that 3 year
old cold sore on KH's lip, roughly the size of thejp, but oh sir, you
would undoubtedly be wrong about that one. "But Kirby got 48% on
Bowser!" you say, yeah, <i>that's what she said.</i> . A wise man once
said "wat ever kirby es dum neway your just a fanboy neway," and he
clearly knew what he was talking about. But enough about Kirby, because
really, who cares for than androgynous pink ball of matter?<br><br>The
Prince of Persia - The Man, The Myth, The Sex Icon. When you're such a
badass you don't even need a name, you know you're going to kick some
serious ass, take a name or two even. Did you know according to the
2000 census, Persian men have the second biggest wang size out of all
races? Yeah, I bet you didn't, you ignorant buffoon. The men want him,
and the women want to be him, and when you're on a site that has the
sausage fest we do, the former is the Prince's key to victory. Who
doesn't go to bed at night dreaming of the Prince's silky, flowing
hair? His rippled chest? His, well you get the idea, the man is <i>sexy.</i>
I know what you're thinking to yourself right now "Could this be the
first 100% victory we've ever seen in these contests?!" unfortunately
not, you see, the only person who would dare vote against the Prince is
those dirty commie bastards. You're not a commie, are you? Well if you
don't want to be labeled as an American hating democratic girlie man, I
think you know where your vote better be going. I'll keep this short,
because honestly, why bother taking for an hour about this match when
Kirby is six feet under before the match has even begun.<br><br><b>EC's Prophetic Prediction: The Prince of Persia with 87% of the vote.</b><br><br><br>...<br><br>.....<br><br>.......<br><br>What
do you mean I can't pick the prince to win the match? Oh I'm onto your
games Moltar, you're just jealous that the Persians have eclipsed
African Americans in wang size. Oh you're one sick puppy.<br><br><b>EC's Remarkable Revised Prediction: Kirby with 62% of the vote.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/7/2006 9:48:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339451168">message detail</a>
 | #214</td></tr>
<tr class="even"><td>
KH = Dumbfounded<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 2</i>: W, 52-14 vs. Etna
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 10/7/2006 9:48:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339451179">message detail</a>
 | #215</td></tr>
<tr class="even"><td>
<i>I fully expect to lose this point handily. I'll be dumbfounded if I'm not the low pick.</i><br><br>&gt;_&gt;<br><br>Also, Moltar wins the internet.<br><br>---<br><b>Z1mZum</b>
won the Guru Contest. I picked Pokemon over Metroid, GTA over Warcraft,
Halo over CV, Street Fighter over RE, and FF over Zelda.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/7/2006 9:50:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339451786">message detail</a>
 | #216</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>If the Prince wins this
match, I will do a backflip. I'm not too worried about having to show
off my terrible athletic skill though, unfortunately. Kirby sucks, and
The Prince of Persia kicks ass. But that's just one man's opinion, not
the entire voting base's.<br><br>My vote: The Prince of Persia<br>My bracket: Kirby<br>My prediction: Kirby with 65%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/7/2006 9:51:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339451994">message detail</a>
 | #217</td></tr>
<tr class="even"><td>
Saying Kirby sucks is merely descriptive, not derogatory.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 2</i>: W, 52-14 vs. Etna
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/7/2006 9:51:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339452038">message detail</a>
 | #218</td></tr>
<tr class="even"><td>
It's okay Moltar, I'm low pick!  I guess I'm banking too heavily on anti-Kirby....<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/7/2006 9:52:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339452237">message detail</a>
 | #219</td></tr>
<tr class="even"><td>
<i>Saying Kirby sucks is merely descriptive, not derogatory.</i><br><br>Uhhh.....yeah.....that's it...yeah, I was just talking about them, I wasn't showing any bias or anything.  Yeah!<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/7/2006 10:52:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339465517">message detail</a>
 | #220</td></tr>
<tr class="even"><td>
Of course, I completely forget the insanity of EC is on this particular
match as well. Trying to go low for Prince here is like when I was
trying to go high for Dante in his match -- it just didn't work! =(<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786704" class="name">mmmApplesauce</a> |
Posted 10/8/2006 10:58:26 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339538151">message detail</a>
 | #221</td></tr>
<tr class="even"><td>
<i>Of course, I completely forget the insanity of EC is on this
particular match as well. Trying to go low for Prince here is like when
I was trying to go high for Dante in his match -- it just didn't work!
=(</i><br><br>Insane? OR ABOUT TO WIN BOARD 8 IT'S SECOND MATCH BWAHAHAHAHAHAHAHA.<br><br>---<br>I love bananas.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/8/2006 11:06:43 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339539611">message detail</a>
 | #222</td></tr>
<tr class="even"><td>
I love going with predictions that seem way under or over exaggerated
when I make them, and then they turn out good. Damn it, EC......oh
well, at least I beat the main crew.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3411892" class="name">WarThaNemesis</a> |
Posted 10/8/2006 11:13:41 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339540773">message detail</a>
 | #223</td></tr>
<tr class="even"><td>
Oh damn, I so want Vincent/Sonic or Squall/Snake, preferably Squal/Snake &gt;_&gt;<br>---<br>War13104 had something weak beating something strong and he looks smarter than you or something - TessaTestarossa
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/8/2006 12:02:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339549352">message detail</a>
 | #224</td></tr>
<tr class="even"><td>
Ganondorf.....................47.41% 60685<br>Vincent Valentine..........52.59% 67321<br>TOTAL VOTES.......................128006<br><br>39.39% of the brackets predicted this match correctly.<br><br>Ganon
looked like he was going to keep it interesting, but Vincent was just
too much for the King of Evil. Still, as least we know Ganon is very
strong, and I'm happy with that. Only 39% of the brackets saw this
coming.<br><br>Today, Prince is doing very well against Kirby.<br><br>Lopen - 7<br>Moltar - 5<br>KH - 5<br>Ulti - 4<br>HM - 3<br>Guest (Wigs, SilverNightmareX7) - 2<br>Yoblazer - 2<br><br>Woah, the Guests were actually able to get another point?<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Kirby vs. The Prince - Bracket: <b>Kirby</b> - Vote: <b>Kirby</b> (24/26)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/8/2006 4:21:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339604635">message detail</a>
 | #225</td></tr>
<tr class="even"><td>
Guest for two in a row baby!<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3623587" class="name">Gaddswell</a> |
Posted 10/8/2006 4:26:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339605587">message detail</a>
 | #226</td></tr>
<tr class="even"><td>
Guest (EC) is dead on!<br><br>Kirby 62%  58922<br>The Prince of Persia 38%  36117<br>TOTAL VOTES 95039<br>---<br>By the time we localize the programs, kids don&#8217;t even know they&#8217;re from Japan any more. - 4Kids CEO Al Kahn
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=683142" class="name">transience</a> |
Posted 10/8/2006 4:28:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339606075">message detail</a>
 | #227</td></tr>
<tr class="even"><td>
yoblazer is so screwed<br>---<br>Query "Results"
failed: You have an error in your SQL syntax. Check the manual that
corresponds to your MySQL server version for the right syntax to use
near ' WHERE Gordon.IsWinner = True AND Predic <b>|| </b>Winner: Strider Hiryu - 57.11%
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/8/2006 8:34:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339665509">message detail</a>
 | #228</td></tr>
<tr class="even"><td>
I wonder where Draco is...<br><br>Ahh well, 30 minutes and Luigi/Zero is up in the air for anyone to do.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Kirby vs. The Prince - Bracket: <b>Kirby</b> - Vote: <b>Kirby</b> (24/26)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2568612" class="name">Draco1214</a> |
Posted 10/8/2006 8:36:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339665858">message detail</a>
 | #229</td></tr>
<tr class="even"><td>
I thought I sent you mine a while back over AIM.<br>---<br>Character Battle V Score - <i>25/26 points</i><br>Current Prediction - <b>Kirby</b> vs. The Prince of Persia
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/8/2006 8:39:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339666788">message detail</a>
 | #230</td></tr>
<tr class="even"><td>
I don't recall you doing so...and if you did, I would have put in with the rest of the write-ups right away.<br><br>Or maybe I'm stupid and forgot to save it. Can you resend it then?<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Kirby vs. The Prince - Bracket: <b>Kirby</b> - Vote: <b>Kirby</b> (24/26)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2568612" class="name">Draco1214</a> |
Posted 10/8/2006 8:40:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339667207">message detail</a>
 | #231</td></tr>
<tr class="even"><td>
Sure thing.<br>---<br>Character Battle V Score - <i>25/26 points</i><br>Current Prediction - <b>Kirby</b> vs. The Prince of Persia
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/8/2006 8:56:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339671392">message detail</a>
 | #232</td></tr>
<tr class="even"><td>
<b>Blast Division:</b> <i>Round 1 - Match 28</i> &#8211; (2)Luigi vs. (7)Zero<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Luigi</b><br>Game/Series Known From: Super Mario<br>Extrapolated Rank in 2003: 30th (25.24%)<br>Extrapolated Rank in 2004: 41st (16.62%) - Adjusted Value: 30th (22.96%)<br>Extrapolated Rank in 2005: 20th (28.70%)<br>Seed in 2003: 3<br>Seed in 2004: 4<br>Seed in 2005: 2<br>Lost in 2003 to Squall in Round 2<br>Lost in 2004 to Yoshi in Round 2<br>Lost in 2005 to Tifa in Round 2<br><br>Mario&#8217;s flamboyant brother returns!<br><br><b>Zero</b><br>Game/Series Known From: Mega Man X<br>Extrapolated Rank in 2003: 14th (33.28%)<br>Extrapolated Rank in 2004: 10th (28.50%) - Adjusted Value: 11th (31.67%)<br>Extrapolated Rank in 2005: 18th (29.41%)<br>Seed in 2003: 7<br>Seed in 2004: 4<br>Seed in 2005: 3<br>Lost in 2003 to Sonic in Round 2<br>Lost in 2004 to Mega Man in Round 3<br>Lost in 2005 to Mario in Round 3<br><br>Mega Man v 2.343 is back as well.<br><br>Another
match that is too big for Round 1. Instead, this time its between two
Top 20 characters, and not two top 15&#8217;s. Who&#8217;s going to win? I&#8217;ll tell
you&#8230;<br><br>First, look at the 2005 rankings for them. Luigi&#8217;s best
year and Zero&#8217;s worst. It&#8217;s hard to see Luigi going from 45% on Yoshi
to 47% on Tifa. Yet he did it&#8230;With Zero, it&#8217;s hard to see him going
from 44% on Mega Man to 37% on Mario. So where am I going with this.<br><br>Luigi
may not be underrated, since it had been a while since we got a good
read on him, but Zero? Perhaps he is. It might be just me, but Zero&#8217;s
numbers on Mario just seem&#8230;low. He still ranks above Luigi, but I still
think he should be a little higher.<br><br>Of course, Luigi has
NintendoFAQs and the high ground (er&#8230;seed) in his corner, but come on,
before 2005, Zero would have been the obvious favorite to win. Luigi
should do well, but I don&#8217;t think Zero has fallen enough to lose this
match. I also don&#8217;t think Luigi has gained enough to win. His 2005
number just doesn&#8217;t settle with me.<br><br><b>Moltar&#8217;s Bracket Says:</b> Zero will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Luigi: 46% - Zero: 54%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br><br>Zero
is the Xst favorite in something like a 53-47 win, but everyone already
knows that. Though for those who need a reason, Zero's performance on
Sonic &gt;&gt;&gt; Tifa's.<br><br>That said, 2-7 and NintendoFAQs may
very well put Luigi into this match. Whether or not he'll win remains
to be seen, but I have faith in Zero pulling this one out. And for the
record, I think Luigi is the bigger threat to Zero in this fourpack
then Kirby is.<br><br>Prediction: Zero with 52.25%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>Look at this &#8211; <i>two</i>
debated matches in one division! Although most people feel this match
is clearly in favor of Zero, or at least people are confident in Zero,
I&#8217;m not so certain that he&#8217;s got what it takes to win here. That&#8217;s
right &#8211; I&#8217;m going with the upset of Luigi over Zero. There is a pretty
clear explanation for why this is the case, too. <br><br>There has
been much argument surrounding Zero&#8217;s value last year in the 2005 stats
&#8211; some citing that he was underrated due to Mario/Zero SFF &#8211; but the
reasoning behind it is rather nonsensical. I&#8217;m not sure how Mario is
supposed to SFF Zero when <i>Mega Man</i> couldn&#8217;t even do it. This
came up entirely because Zero apparently cannot drop, which in itself
is just a lame thought process; characters rise and drop every year
without reason.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/8/2006 8:58:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339671894">message detail</a>
 | #233</td></tr>
<tr class="even"><td>
So without Zero being underrated, this match looks <i>very</i>
good for Luigi. Right now, Zero is projected to win this match with
51.20%. That alone is enough to heavily consider Luigi in this
match-up, especially when &#8220;NintendoFAQs&#8221; in the plumber&#8217;s corner, but
there&#8217;s even more in his favor! New Super Mario Bros. recently released
on the Nintendo DS in May. As it turns out, Luigi was actually playable
in the game &#8211; and that should be common knowledge by now. Sure, his
role was nothing out of the ordinary, but the fact that you could play
as him in single player is bound to give him a nice boost, along with
the fact that another new Mario game released. <br><br>Even more
interesting is the jump in DS ownership since last year. Before the
2005 contest, DS ownership was at 33%; before the 2006 contest, DS
ownership was at an incredible 55%. It&#8217;s pretty clear that the DS Lite,
along with the appealing DS library, convinced a number of gamers to
jump to Nintendo&#8217;s hottest new system. <i>And even better</i>, New
Super Mario Bros. has become an instant hit since releasing in may by
selling over 4 million copies worldwide and over 1 million copies in
America. Its presence should be clearly felt here as it&#8217;s the latest
Mario game out. There&#8217;s also some slight benefit of this site heavily
shifting its preference toward Wii, which helps out Luigi more than
Zero easily. <br><br>I think Luigi heads into this match with a lot in
his corner and a lot of reason to take home a victory. Some doubt
Luigi&#8217;s strength last year while others think Zero&#8217;s impressive contest
history is enough to secure him a win &#8211; but I think both are foolish to
put faith in. In my bracket, I originally had Luigi until I was
convinced that Zero&#8217;s impressive <i>history</i> &#8211; keyword &#8211; was going
to give him enough to win. I have since wised up. This match is
certainly not out of his reach, and he&#8217;s clearly the favorite heading
in, but I&#8217;m willing to put my Crew points on the line for this one. <i>GO LUIGI!</i>  <br><br><b>Aitch Emm&#8217;s Bracket:</b> Zero<br><br><b>Aitch Emm&#8217;s Prediction:</b> Luigi &#8211; 51.2% ; Zero &#8211; 48.8%<br><br><b>Aitch Emm&#8217;s Vote:</b> Luigi<br>  <br> <br><br><b>Yoblazer&#8217;s Analysis</b><br><br>Here's
our third of three highly disputed first round matches. Before the
contest started, many Board 8ers were banking on the Luigi upset
because they perceived that Nintendo would be even stronger than year
than they were in 2005. While I was one of the proponents of this
theory, so far, that doesn't necessarily seem to be the case. It may be
a case of weird match-ups (Samus) or a big KH/Square boost (Yoshi,
Ganondorf), but Nintendo hasn't really lived up to my lofty
expectations through the contest's first four weeks.<br><br>If Riku can
keep it very respectable with Yoshi and Vincent can beat Ganon, I
really don't see much hope for Luigi here. Obviously, Zero isn't
Square, but he's still one of the most proven upper midcard guys we
have. I don't care if it was a few years ago; hitting the mid and upper
40s on Mega Man and Sonic is quite a feat, and it's one I don't see
Luigi equaling anytime soon. Really, this guy was so good in every one
of his matches pre-Mario, and had he done like 2% better against the
Italian tank, this wouldn't be debated at all. Considering 2K5 Mario
was a freak, I think it's only fair to give Zero the benefit of the
doubt at least once before calling him an overrated fraud. He's
certainly earned it.<br><br>I think Luigi may be strong enough to make
this closer than his match against Tifa, but I can't see him giving his
uber badass opponent a scare.<br><br>My prediction: Zero def. Luigi (53-47)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/8/2006 8:59:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339672021">message detail</a>
 | #234</td></tr>
<tr class="even"><td>
<b>Lopen&#8217;s Analysis</b><br> <br>Alright, let's face it: Had this match
taken place last year, there wouldn't be any debate at all. None. Zero
would be the huge favorite, and with good reason. Look at what Zero has
done over the years: 48% on Sonic, 44% on Mega Man, resounding
victories over solid mid-carders like Tommy Vercetti and Scorpion. What
had Luigi done? Smashed fodder, got "IT'S OVER"ed by Squall, got kicked
in the face by Yoshi. Nothing near what Zero did.<br><br>Last year,
Luigi looked better, much better. He thrashed KOS-MOS and put up a
decent little struggle against Tifa, who did alright against Sonic.
(but not nearly as well as Zero did) But did he look better than Zero?
That's debatable. Lloyd Irving, his second victim, is probably only
high fodder&#8230; but Ryu Hayabusa is a solid mid-carder that'd probably
beat KOS-MOS with relative ease. And 37% on Mario isn't <i>that</i> bad considering Mario's unfound stash of performance enhancing mushrooms he used last year.<br><br>So,
despite Luigi looking to be a threat to Zero last year according to
those "X-Stats", I'm just not feeling the upset potential. Now, Kirby,
on the other hand&#8230; looked <i>better</i> than Zero last year&#8230; ho ho ho&#8230;
*ahem*. Oh, and, you've gotta believe that any SFF in this match-up
goes to Zero, considering Mega Man himself couldn't even pull any on
him&#8230; whereas Mega Man destroyed Yoshi with it. I mean, I had a little
doubt that Mega Man and Zero were Mario characters before, but Yoshi
still managing to beat Riku this year makes me think it's probably the
case. And of course, that opens the gates to Mario/Zero SFF! <i>Yeeaahh</i>!<br><br><b>Lopen's Prediction:</b> Zero with 56.75%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>LUIGI</b><br><br><i>"Marioooooooooooo!"</i><br><br>Summer 2003 Contest<br>Extrapolated Strength --- 30th Place [24.43%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 30th Place [22.96%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 21st Place [28.70%]<br><br>Donkey
Kong is Nintendo's biggest choker, but he's far from their biggest
disappointment. No, that 'honor' goes to Luigi, a character that has
never made it past the second round despite often *very* favorable
seeding, and only recently has made his claim to be a legitimate
contender in these things. Gone are the days of perennial
midcardership, being doomed to being blown out worse than Jill
Valentine and embarrassed by Yoshi!<br><br>...or so we hope. WOO LUIGI<br><br><b>ZERO</b><br><br><i>"I will never die."</i><br><br>Summer 2003 Contest<br>Extrapolated Strength --- 14th Place [33.28%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 11th Place [33.96%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 19th Place [29.41%]<br><br>The
original Noble Nine breaker (well, the one who hasn't turned out to be
vastly overrated) is back again, and while not given very favorable
seeding, would historically be the vast favorite to take this fourpack.<br><br>...how
different NintendoFAQs makes things. Today Zero is looking to regain
some of that glory that was tarnished when Mario blew past him a little
*too* easily in last year's Sweet Sixteen. I say he'll get it! Um yeah
WOO ZERO<br><br><i>Notable Releases Since Last Appearance</i><br><br>Luigi: New Super Mario Brothers (DS)<br><br>Zero: Mega Man ZX (DS)<br><br><i>Upcoming Releases</i><br><br>Luigi: Super Smash Brothers Brawl (WII)<br><br>Zero: N/A<br><br>At
the time of writing, I have not seen the results of Vincent/Ganondorf.
So keep in mind that this analysis will likely sound completely
laughable in light of those results.<br><br>Anywho, I'm not really
scared for Zero in this matchup, Hayabusa or no. I'm all statted out
from Ganon/Vince, so I'll just say this -- I can't see GameFAQs
preferring Luigi to Zero.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/8/2006 8:59:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339672167">message detail</a>
 | #235</td></tr>
<tr class="even"><td>Although if Luigi does win here, I'll consider it
really bad for Mega Man in his inevitable match against Snake. The MM
series will really have had to lost a step for Zero to falter here.<br><br>Karma Hunter's Vote: Zero. Because beam sabers &gt; vacuum cleaners<br><br><b>Karma Hunter's Krazy Prediction: Zero with 54.6%.</b><br><br>Random picks FTW? I hope I'm not on a losing streak by the time I get back. :(<br><br><b>Upset Potential: 35%<br><br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br><br>I'm not so arrogant as to not see the stat upset in all this. But I just can't believe it. Still...<br><br>Upset Prediction: Luigi with 52.38%<br> <br><br><br><b>Guest&#8217;s Analysis</b> - <i>Draco1214</i><br><br>Past Contest Performances (credit goes to MMXCalibur&#8217;s site):<br><br>(2) Luigi<br>Summer 2003:<br>Northern Round 1 --- Defeated (14) Ratchet, 70550 [74.54%] - 24099 [25.46%]<br>Northern Quarterfinal --- Lost to (6) Squall, 46232 [39.79%] - 69958 [60.21%]<br>Extrapolated Strength --- 30th Place [24.43%]<br><br>Summer 2004:<br>Hyrule Round 1 --- Defeated (13) Pac Man, 51008 [67.73%] - 24299 [32.27%]<br>Hyrule Quarterfinal --- Lost to (5) Yoshi, 34382 [45.52%] - 41151 [54.48%]<br>Extrapolated Strength --- 30th Place [22.96%]*<br>*was behind Link/Yoshi SFF in 2004<br><br>Summer 2005:<br>Chaos Round 1 --- Defeated (7) KOS-MOS, 70232 [66.00%] - 36187 [34.00%]<br>Chaos Semifinals --- Lost to (3) Tifa, 47705 [46.64%] - 54588 [52.26%]<br>Extrapolated Strength --- 21st Place [28.70%]<br><br>(7) Zero<br>Summer 2003:<br>Eastern Round 1 --- Defeated (10) Scorpion, 70885 [62.84%] &#8211; 41916 [37.16%]<br>Eastern Quarterfinal --- Lost to (2) Sonic the Hedgehog, 47261 [47.66%] &#8211; 51903 [52.34%]<br>Extrapolated Strength --- 14th Place [33.28%]<br><br>Summer 2004:<br>20XX Round 1 --- Defeated (13) Protoman, 58317 [71.72%] - 22993 [28.28%]<br>20XX Quarterfinal --- Defeated (5) Tommy Vercetti, 49875 [61.84%] - 30775 [38.16%]<br>20XX Semifinal --- Lost to (1) Mega Man, 36800 [43.99%] - 46849 [56.01%]<br>Extrapolated Strength --- 11th Place [33.96%]<br><br>Summer 2005:<br>Mushroom Round 1 --- Defeated (6) Ryu Hayabusa, 57507 [63.00%] - 33771 [37.00%]<br>Mushroom Semifinal --- Defeated (2) Lloyd Irving, 65557 [73.25%] - 23938 [26.75%]<br>Mushroom Final --- Lost to (1) Mario, 39856 [37.14%] - 67452 [62.86%]<br>Extrapolated Strength --- 19th Place [29.41%]*<br>*possible Mario/Zero SFF. Likely higher up in the stats.<br><br>Looking
at their track records only, Zero seems like the obvious choice. After
all, Zero&#8217;s put up more impressive numbers than Luigi, and against
tougher opponents to boot. In 2003, Zero blew away Scorpion before
putting up over 47% against Sonic. Luigi, however, was a character
people had high expectations for and ended up flopping miserably,
failing to break 40% on the &#8220;massively hated&#8221; Squall Leonhart. In 2004,
Zero was expected to get killed by Mega Man thanks to SFF. He responds
by not only breaking 40%, but actually outperforming Snake, a
noble-niner! In contrast, Luigi finds yet another way to bomb as many
people expected him to SFF Yoshi or at least keep it close. In the end,
Luigi rolled over and died, letting the lovable green dinosaur score
55% on him.<br><br>However, in 2005, Luigi decided that he was tired of
his stigma as the forgotten brother of Mario and wanted some of the
spotlight. In a match many claimed would be close, Luigi exceeded
expectations and nearly doubled KOS-MOS after her new game came out and
made her look like fodder in the process. While he did end up losing a
somewhat debated match against Tifa, Luigi went out in style, scoring
over 47% on the popular FF7 vixen. Zero, on the other hand, looked
rather&#8230;unimpressive. He did just about expected on Ryu Hayabusa and
blew away Lloyd Irving. However it was his third round match that
worried many a Zero fan. He was supposed to perform respectably against
Mario and he responded by failing to break 40%.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/8/2006 9:00:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339672460">message detail</a>
 | #236</td></tr>
<tr class="even"><td>And now we have come to this match. Luigi looking
so good last year and Zero&#8217;s bombing against Mario have made this match
a lot more debatable than it really should be, in my opinion. While
Luigi has indeed come a long way since his days as a choker, Zero has
proven time and time again that he is near-elite material. Despite
underperforming against Mario, his match against Hayabusa was certainly
within the expectations placed upon him (though he did underperform a
tad), and his killing of Lloyd Irving further cements the fact that
Zero is a force to be reckoned with. Aside from his one bad match, Zero
shows no signs of his strength dropping and remains as much of a force
as ever.<br><br>Even
though Luigi has the Nintendo boost and NSMB on his side, I feel that
Zero is just too much for him. In my opinion, for Luigi to win this
match, he has to be just around the level of characters such as
Ganondorf, Tifa, and Vincent, which is something I cannot see
happening. Luigi does have a chance to upset Zero if his match vs.
Mario was in fact not a fluke/bad match/whatever but it really doesn&#8217;t
look all that likely. Zero&#8217;s already stronger than Luigi statistically
speaking even if you think Mario/Zero is legit. Basically, if Zero was
SFF&#8217;d at all, he wins comfortably.<br><br>So what is Zero fighting for?<br>1) To defeat Luigi with a comfortable margin.<br>2) To expose Kirby for the overrated puffball he is.<br>3) To lose to Sonic&#8230;in style.<br><br>Draco&#8217;s Bracket &#8211; Zero<br>Draco&#8217;s Vote &#8211; Luigi<br>Draco&#8217;s Prediction &#8211; Zero over Luigi with 54.76%<br> <br> <br><br>Crew Consensus: HM has Luigi, but everyone else is going for the upset with Zero. It should be close either way though.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/8/2006 9:03:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339673076">message detail</a>
 | #237</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>No match this contest has
pissed me off more than this one. The majority seems to think Zero will
win this match. Why? A secondary Mario character will beat a secondary
Mega Man character. The debate of this match is making me go crazy.<br><br>Then
again, what do I know. Zero could easily win, and I'll be eating my own
words. I'm just more confident in Luigi than everyone else, I guess.<br><br>My vote: Luigi<br>My bracket: Luigi<br>My prediction: Luigi with 59%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/8/2006 9:04:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339673355">message detail</a>
 | #238</td></tr>
<tr class="even"><td>
Ha! I knew I would could get point &gt;_&lt;;<br><br>lol Ganon 53% lol.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/8/2006 9:09:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339674531">message detail</a>
 | #239</td></tr>
<tr class="even"><td>
The entire Crew is losing a point in their bracket tomorrow, huh.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 10/8/2006 9:11:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339675194">message detail</a>
 | #240</td></tr>
<tr class="even"><td>
You obviously missed HM's craziness.<br><br>---<br><b>Z1mZum</b>
won the Guru Contest. I picked Pokemon over Metroid, GTA over Warcraft,
Halo over CV, Street Fighter over RE, and FF over Zelda.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/8/2006 9:12:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339675457">message detail</a>
 | #241</td></tr>
<tr class="even"><td>Oh! and my analysis since I can see that no one on
the contest crew got this one right.... HM doesnt count as being on the
crew anymore.... lol Ganon d. Sonic lolwtfbbq<br><br>Zero:
Insert wall of text here - mediocre character in a series that has done
almost nothing but go downhill since before he was a part of it and has
since become more of a strong cult game series than a mainstream game
series- continue wall of text.<br><br>Luigi: Insert supplemental wall
of text- mediocre character in a series that is still well respected
and enjoyed by the mainstream audiences of video gaming - continue wall
of supplemental text that includes all the x-stats and histories
everyone else has bothered to post.<br><br>Luigi wins, 53.17%. Yeah, the same % I used for Vincent/Ganon.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/8/2006 9:12:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339675467">message detail</a>
 | #242</td></tr>
<tr class="even"><td>
He's still losing a point in his bracket though.  Just, like me with PW vs. GF, we realized our mistake <i>after</i> the brackets were locked.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=254355" class="name">Lugia2</a> |
Posted 10/8/2006 9:16:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339676421">message detail</a>
 | #243</td></tr>
<tr class="even"><td>
Wow.  The Guest doesn't do an upset pick.<br><br>Oh, and HM?  Do you ever wonder if your pick may <i>just</i> be wrong?<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3605206" class="name">wavedash101</a> |
Posted 10/8/2006 9:17:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339676503">message detail</a>
 | #244</td></tr>
<tr class="even"><td>
B8 got three points baby!!!<br>---<br><b>Our shields cannot withstand wavedashing of this magnitude!</b><br>Board 8's Unofficial Master of the Phoenix Down
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=788233" class="name">PokemonPatriarch</a> |
Posted 10/8/2006 9:20:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339677481">message detail</a>
 | #245</td></tr>
<tr class="even"><td>
NintendoFaqs could be considered a magical happening from last year,
but I don't think it exists right now. While the females blew out their
respective opponents (two of which were same fanbase, and the other was
against a character more well known for her show), the males have
failed to impress. Yoshi (kinda like Frog...) got exposed by Riku,
Ganon failed expectations by not winning the most recent match, and
Kirby is far below expectations as well.<br><br>Luigi's
losing this one, and the only incidents of "NintendoFaqs" this season
I'd be willing to subscribe to are Zelda/Aeris and Samus/Crono.<br>---<br>Proud fanboy of the Ogre Battle saga!!!<br><b>~~~Allah Approves~~~ </b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3605206" class="name">wavedash101</a> |
Posted 10/8/2006 9:23:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339678222">message detail</a>
 | #246</td></tr>
<tr class="even"><td>
Ehh Samus over Crono would have been taken with out nintyfaqs help.
Zelda/Aeris is the only real case I think. Samus was actually more
dominate before last year, you could say.<br>---<br><b>Our shields cannot withstand wavedashing of this magnitude!</b><br>Board 8's Unofficial Master of the Phoenix Down
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/8/2006 10:18:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339692609">message detail</a>
 | #247</td></tr>
<tr class="even"><td>
Give me my damn point Moltar!<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=264094" class="name">Heroic Mario</a> |
Posted 10/8/2006 10:45:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339699146">message detail</a>
 | #248</td></tr>
<tr class="even"><td>
I've got unwavering confidence in the plumber<i>!!</i><br><br>---<br>"<i>Master using it and you can have this.</i>"<br><a class="linkification-ext" href="http://img90.imageshack.us/img90/160/masterjg3.jpg" title="Linkification: http://img90.imageshack.us/img90/160/masterjg3.jpg">http://img90.imageshack.us/img90/160/masterjg3.jpg</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/8/2006 10:46:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339699528">message detail</a>
 | #249</td></tr>
<tr class="even"><td>
You don't know how good that makes me feel, HM!<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3605461" class="name">chaosarcher07</a> |
Posted 10/8/2006 11:46:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339712652">message detail</a>
 | #250</td></tr>
<tr class="even"><td>
So far it appears that HM's confidence is justified.<br>---<br>My FC2K6 Bracket: 22/24 (missed Boss, phoenix)<br>Next match prediction: Sonic
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=3">4</a></li>
<li>5</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=9">10</a></li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage5_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30854544&amp;page=4" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage5_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>