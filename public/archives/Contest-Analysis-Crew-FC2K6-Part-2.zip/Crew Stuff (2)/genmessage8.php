<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage8_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage8_files/nogs.css"></head><body linkifytime="290" linkified="3" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage8_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/afterhours/">After Hours</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage8_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30854544%26page%3D7"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage8_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage8_files/advertisement.gif" alt="advertisement" height="10" width="120"></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage8_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage8_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 2
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;page=7">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30854544" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=6">Previous Page</a> |
Page 8 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=8">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/11/2006 9:11:13 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340199873">message detail</a>
 | #351</td></tr>
<tr class="even"><td>
Guest wins yesterday, making Board 8 3/4, and now me today, hopefully? 4/5, Board 8 is on a tear! <br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/11/2006 9:12:11 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340199966">message detail</a>
 | #352</td></tr>
<tr class="even"><td>
Everyone's trying to copy me.......<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=683142" class="name">transience</a> |
Posted 10/11/2006 9:14:51 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340200197">message detail</a>
 | #353</td></tr>
<tr class="even"><td>
nothing wrong with that! the more opinions the better. so long as
people aren't all HA HA I WAS RIGHT IN YOUR FACE ANALYSIS CREW SUX<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/11/2006 9:20:14 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340200615">message detail</a>
 | #354</td></tr>
<tr class="even"><td>
I find it humorous that yo has predicted every match, won twice, and
I've been in 2, and potentially going to win twice! In your face Fedor
fanboy!<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/11/2006 9:22:35 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340200837">message detail</a>
 | #355</td></tr>
<tr class="even"><td>
How'd you end up getting 2, EC? Cheater.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/11/2006 9:24:14 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340200975">message detail</a>
 | #356</td></tr>
<tr class="even"><td>
The person who was supposed to do this match never did it, and I made it last minute at 10:30 last night.<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/11/2006 11:01:33 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340210628">message detail</a>
 | #357</td></tr>
<tr class="even"><td>
<i>YOU CAN PUT IT ON THE BOOOOOOOOOARD...<b>YES!</b></i><br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/11/2006 3:24:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340251133">message detail</a>
 | #358</td></tr>
<tr class="even"><td>
<i>From DpObliVion Posted 10/11/2006 10:12:11 AM</i><br><i>Everyone's trying to copy me.......</i><br><br>No.Oh
god, **** no. I hate your writeups. The reason that I posted one is
because I was writing mine for the guest spot, but someone else ended
up getting in before I would have. Not wanting to let it go to waste, I
posted it anyways.<br><br>I'm going to be making my own topic once
round two starts, because I don't like the idea of spamming up the
Crew's topic when I'm not a member of it. You're not the first person
to do writeups for each match outside of the crew. You're just the
first one to do it in a topic that was made for the crew.<br><br>And on a lighter note, looking back on it, I'm glad I didn't make it in time for the guest spot this match. T_T<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3605206" class="name">wavedash101</a> |
Posted 10/11/2006 3:28:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340252086">message detail</a>
 | #359</td></tr>
<tr class="even"><td>
How the hell do you do it, EC? <br>---<br><b>Our shields cannot withstand wavedashing of this magnitude!</b><br>Board 8's Unofficial Master of the Phoenix Down
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/11/2006 3:30:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340252501">message detail</a>
 | #360</td></tr>
<tr class="even"><td>
Wang envy.<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/11/2006 3:30:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340252535">message detail</a>
 | #361</td></tr>
<tr class="even"><td>
...By <i>not</i> overcompensating Bowser in an attempt to make it look like he can beat Crono?<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 3</i>: Superman (0-2)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/11/2006 4:10:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340262312">message detail</a>
 | #362</td></tr>
<tr class="even"><td>
Crono............................74.16% 84090<br>Captain Falcon...........25.84% 29306<br>TOTAL VOTES.........................113396<br><br>83.11% of the brackets predicted this match correctly.<br><br>And
after the casuals impress me yesterday with their Luigi percentage,
they let me down with yet another pathetic Crono percentage. Overall,
Crono did as expected against Falcon.<br><br>Today, Leon is doing very well against Bowser.<br><br>Lopen - 7<br>Moltar - 5<br>KH - 5<br>Guest (Wigs, SilverNightmareX7, EC, TheRye) - 4<br>HM - 4<br>Ulti - 4<br>Yoblazer - 2<br><br>Another Guest point?!?! <br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Bowser vs. Leon - Bracket: <b>Bowser</b> - Vote: <b>Bowser</b> (26/29)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/11/2006 7:45:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340315391">message detail</a>
 | #363</td></tr>
<tr class="even"><td>
Putting Board 8 in a tie for a second? Go me!<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3605206" class="name">wavedash101</a> |
Posted 10/11/2006 7:55:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340317930">message detail</a>
 | #364</td></tr>
<tr class="even"><td>
B8's gonna win the game!<br>---<br><b>Our shields cannot withstand wavedashing of this magnitude!</b><br>Board 8's Unofficial Master of the Phoenix Down
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/11/2006 7:57:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340318560">message detail</a>
 | #365</td></tr>
<tr class="even"><td>
I just lost the game.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3478654" class="name">CleanExVeemon</a> |
Posted 10/11/2006 7:58:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340318743">message detail</a>
 | #366</td></tr>
<tr class="even"><td>
<i>Guest wins yesterday, making Board 8 3/4, and now me today, hopefully? 4/5, Board 8 is on a tear! </i><br><br>Better make it 5/6 after tomorrow!<br>---<br>How disturbing.<br>We are mr_BRIAN. Though We dislike underscores.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3657433" class="name">LusterSoldier</a> |
Posted 10/11/2006 8:50:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340332398">message detail</a>
 | #367</td></tr>
<tr class="even"><td>
<i>Another Guest point?!?! </i><br><br>I shall score at least 5 points for the Guest when it comes time for Jill/Peach.  Because I'm a nasty Oracle predictor myself.<br>---<br><b>Luster Soldier</b> - Pwned by Repus_Yortsed<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=7&amp;topic=30445079</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/11/2006 8:53:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340333020">message detail</a>
 | #368</td></tr>
<tr class="even"><td>
it's easy to win points when you make outlandish picks. that's what
board 8 does! that's why Lopen always wins those kinds of categories
when only the best prediction wins.<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3793953" class="name">TehMissingLink</a> |
Posted 10/11/2006 8:58:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340334466">message detail</a>
 | #369</td></tr>
<tr class="even"><td>
Oh crap! <br><br>Hey, Moltar, I'll send you my analysis for the next match here in a second!<br><br>---<br>"<i>Looking good, Princess, especially from this angle!</i>"
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/11/2006 9:47:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340346510">message detail</a>
 | #370</td></tr>
<tr class="even"><td>
<i>it's easy to win points when you make outlandish picks. that's what
board 8 does! that's why Lopen always wins those kinds of categories
when only the best prediction wins.</i><br><br>I have to agree Board 8 has made some seriously crappy picks, but the one's we've won on haven't been outlandish!<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/11/2006 10:01:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340350012">message detail</a>
 | #371</td></tr>
<tr class="even"><td>
All I can say is, I hope Board 8 is the low pick for this next match.<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/11/2006 10:01:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340350041">message detail</a>
 | #372</td></tr>
<tr class="even"><td>
<b>Time Division:</b> <i>Round 1 - Match 31</i> &#8211; (3)Auron vs. (6)Alucard<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Auron</b><br>Game/Series Known From: Final Fantasy X <br>Extrapolated Rank in 2003: 20th (28.73%) <br>Extrapolated Rank in 2004: 12h (27.38%) <br>Extrapolated Rank in 2005: 29th (23.58%) - Adjusted Value: 22nd (28.30%)<br>Seed in 2003: 8<br>Seed in 2004: 3<br>Seed in 2005: 2<br>Lost in 2003 to Cloud in Round 2<br>Lost in 2004 to Sephiroth in Round 3<br>Lost in 2005 to Ganondorf in Round 2<br><br>The coolest FFX character is back!<br><br><b>Alucard </b><br>Game/Series Known From: Castlevania<br>Extrapolated Rank in 2002: 26th (22.70%)<br>Extrapolated Rank in 2003: 22nd (27.56%) <br>Extrapolated Rank in 2004: 59th (10.37%) Adjusted Value: 19th (27.74%)<br>Extrapolated Rank in 2005: 36th (21.02%)<br>Seed in 2002: 6<br>Seed in 2003: 6<br>Seed in 2004: 9<br>Seed in 2005: 6<br>Lost in 2002 to Cloud in Round 3<br>Lost in 2003 to Sephiroth in Round 3<br>Lost in 2004 to Ganondorf in Round 1<br>Lost in 2005 to Sora in Round 2<br><br>Alucard with another 6-seed? Heh&#8230;<br><br>We
should just call this the Waster Division. Alucard, another strong
mid-carder, is fed to Auron in Round 1. Now pre-KH2, this might have
been a semi-debatable match. Now though? Nah&#8230;<br><br>We can also look
at Ganondorf, a common opponent between the two. Ganondorf did 3%
better against Alucard in 2004 than he did against Auron in 2005, plus
Ganon was stronger in 2005. Now Auron has had his big role in KH2 since
then, so he should take this match without much trouble.<br><br><b>Moltar&#8217;s Bracket Says:</b> Auron will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Auron: 62% - Alucard: 38%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>This
match is going to kill me solely because of how much I love the two
characters. It's also an obvious affair, but this may finally give us a
once-and-for-all reliable reading on Alucard. Plus we get to see how
much KH2 helped Auron!<br><br>Prediction: Auron with 58.88%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>Perhaps in any other year before last, this might have been <i>somewhat</i>
debated&#8230;but after Alucard&#8217;s loss to Sora and Auron putting up 46% on
Ganon, I think it&#8217;s safe to say that the winner of this one is an
absolute no-brainer. What will be interesting to see is how Auron
performs thanks to his new added KH2 strength and how Alucard will fare
after being the weakest he has ever been last year, at least by our
stats. <br><br>I think Auron is going to absolutely destroy Alucard in
this match. I have always had high hopes for Auron after Kingdom Hearts
II and after seeing Alucard weakened quite a by last year, I&#8217;m
expecting this to never be close, not even from the start. I&#8217;d predict
that Auron takes no time to shoot out to a lead and not do too bad with
the night vote before &#8211; thanks to KH2 &#8211; his monstrous day vote kicks
into gear. <br><br>It should be entertaining to see Auron this year
and I figure he&#8217;ll be joining the &#8220;near-elite&#8221; group too. After years
without having any kind of solid value on Auron, we should finally be
able to make something out of him this year. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Auron<br><br><b>Aitch Emm&#8217;s Prediction:</b> Auron &#8211; 64% ; Alucard &#8211; 36%<br><br><b>Aitch Emm&#8217;s Vote:</b> Auron<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br><i>My word</i>,
talk about a tough match to gauge. We haven't gotten a decent read on
Alucard since 2003, and we've likely never gotten a very clear read on
Auron. Add to that Auron's probable boost from KHII, and this is a
match that definitely requires some guesswork.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/11/2006 10:02:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340350134">message detail</a>
 | #373</td></tr>
<tr class="even"><td>I think one's best bet here is to use a common
opponent who can't SFF or get SFF'd by either of these guys. That
opponent is none other than the contest entrant I'd most love to spit
on this year, Ganondorf the Losing Bastard. In consecutive years,
Alucard and Auron scored 42.84% and 45.90% against Losing Bastard,
respectively. Now, assuming a constant Bastard, that results in an
Auron victory with about 53.33%. Of course, there are those who claim
that Bastard boosted between 2004 and 2005, so believing in that theory
(even slightly) will result in a bigger margin of victory for Auron.<br><br>Not
only do I believe that Bastard boosted slightly between those two
years, but I also think that Auron will get a nice boost from KHII and
that Alucard may have dipped a bit. Thus, I think Auron can and
probably will hit the high 50's here. If pre-KHII Sora can almost hit
55.5%, I don't see why 2006 Auron couldn't do a few percentage points
better.<br><br>My prediction: Auron def. Alucard (58-42)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Fear
not, I shall do a write up for this match yet! But... freelance style!
(I need a placeholder prediction so the crew writeups don't get held
up!)<br><br><b>Lopen's Prediction:</b>  Auron with 59.01%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>AURON</b><br><br><i>"This is my story. And you're not a part of it."</i><br><br>Summer 2003 Contest<br>Extrapolated Strength --- 20th Place [27.80%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 20th Place [27.38%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 22nd Place [28.30%]<br><br>Auron
is back and in style! After playing FFX at last, I finally seem to get
what people see in the guy. And once again, we have a character that I
seem to have a bit of a connection with here, as I suspect that despite
his perhaps disappointing performance last year, with KH2 he could
potentially be above the likes of Vincent and Squall. Of course, I'm
sort of alone in this belief. He has to go a long way toward proving me
right (or close to that), so I'm expecting a good showing from him
here! WOO AURON<br><br><b>ALUCARD</b><br><br><i>"The only thing necessary for evil to triumph is for good men to do nothing."</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 26th Place [22.70%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 22nd Place [26.67%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 19th Place [27.24%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 39th Place [21.02%]<br><br>Longtime
contest veteran Alucard, for his part, is just trying to regain some of
that respect that he lost when he was embarrassed by Sora and then Sora
was subsequently humiliated by Solid Snake. Is he as weak as the stats
indicate? Almost certainly not, but he may not be on that upper midcard
level that people once thought of him at, either. This match will be a
good start toward finding some answers on ol' LOL ALUCARD IS DRACULA
BACKWARDS. WOO ALUCARD<br><br>...<br><br>WOO THE PLAN &lt;_&lt;<br> <br><i>Notable Releases Since Last Appearance</i><br> <br>Auron: Kingdom Hearts 2 (PS2)<br>Alucard: N/A<br><br><i>Upcoming Releases</i><br><br>Auron: N/A<br>Alucard: N/A<br> <br>Back
in the day you could have made the case for an outside upset here, but
Auron has been far more impressive than Alucard historically and he's
also riding KH2. I think he'll be knocking on the door of the Noble
Nine, Alucard lost to <i>Sora.</i> Sorry, Plan Man.<br> <br>Karma Hunter's Vote: Auron. All part of The Plan!<br><br><b>Karma Hunter's Krazy Prediction: Auron with 61.45%.</b><br><br>Slander and lies, this is.<br><br>Upset Potential: 100%<br><br>Alucard can't possibly lose, LOL<br> <br> <br><br><b>Guest&#8217;s Analysis</b> - <i>Janus5000</i><br><br>Ah,
another exciting contest. With it comes many exciting matches, as well
as&#8230; less exciting ones. This match will, in all likelihood, be the
latter.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/11/2006 10:03:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340350381">message detail</a>
 | #374</td></tr>
<tr class="even"><td>Auron and Alucard have many similarities. For
starters, their names both begin with A. They both use swords. They,
uh&#8230; both lost to Ganondorf. Is that all? Probably not, but I think the
third one might be interesting so I'll stop listing random stuff.<br><br>Just
based on their matches with Ganon, Auron appears to have the advantage.
Not only did Auron do better, but there is a good chance that Ganondorf
benefited from The Boost in 2005. The Ganondorf Alucard faced&#8230; was
weaker than CATS. Well, he wasn't really, but he looked that way! Hah,
that was so awes- oh, hi Moltar. Forgot you were running this. I meant
to say that match was clearly SFF and Ganondorf is actually much
stronger. But don't let the adjusted stats from 2004 fool you, oh no &#8211;
that's just part of Magus' trickery. He's clearly hiding from Ganondorf
this year, as you may have noticed. While it's not safe to say where
Ganondorf truly was in 2004, it would be safer to say he has gone up
from there. <i>Use The Boost to get through!</i><br><br>Despite any
improvements Ganondorf may have had, Auron still comes along and does
better than Alucard on him. Alucard, in the mean time, gets 44% on Sora
&#8211; one percent or so worse than what Auron did on Ganondorf. Would you
take Sora over Ganondorf? I'm not too fond of the idea myself. Even so,
Alucard did worse on Sora than Auron did on Ganondorf, so even if that
match were to be close, Auron would still have an edge.<br><br>Then, of
course, there is Kingdom Hearts II. It has two things of interest &#8211;
recency and Auron. The game probably helped newer Square characters in
general, and a cameo can only help Auron. So while Auron already has
the edge, he has more reason to go up.<br><br>Don't be fooled by
Castlevania's run (okay&#8230; win) in the series contest &#8211; Alucard is
prominent in very few CV games, and even so, it lost to Kingdom Hearts.
This should tell you something about how big the three games are (or
two of them, anyway). Once more, a cameo can only help.<br><br>Poor Alucard. Your days of beating up little foxes and puffballs are over.<br><br>Fortunately,
there's still The Plan so that Auron can get screwed against Crono.
Square SFF&#8230; or sword SFF&#8230; or something. Maybe Auron will show up late
like KH!<br><br>Summary &#8211; <b>Auron</b> wins with <b>58.73%</b>.<br><br> <br> <br>Crew
Consensus: What's "The Plan" this year? To lose to Auron of
course...but that seems to simple for "The Plan". Alucard's got
something, but for now, Auron around 60%!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/11/2006 10:04:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340350503">message detail</a>
 | #375</td></tr>
<tr class="even"><td>
I'd like to give an early congrats to yoblazer!<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=863018" class="name">Janus5000</a> |
Posted 10/11/2006 10:04:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340350623">message detail</a>
 | #376</td></tr>
<tr class="even"><td>
Ulti? More like boxed.<br>---<br>"Those who cast the vote decide nothing. Those who count the vote decide everything."<br><a class="linkification-ext" href="http://www.scorehero.com/scores.php?user=2916&amp;diff=4" title="Linkification: http://www.scorehero.com/scores.php?user=2916&amp;diff=4">http://www.scorehero.com/scores.php?user=2916&amp;diff=4</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2584321" class="name">longbladeofhiko</a> |
Posted 10/11/2006 10:06:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340350967">message detail</a>
 | #377</td></tr>
<tr class="even"><td>
Tifa/The Boss Analysis will be ready soon!<br>---<br><b>WWEGSB Hardcore Legend Masa</b><br>I jobbed to <b>Z1mZum</b> in the Guru Contest. Did you?
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/11/2006 10:06:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340351032">message detail</a>
 | #378</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Unless you are Sonic, Snake,
Crono, or first party Nintendo, you are likely not going to beat a
Final Fantasy character. I hear all this talk about Alucard's plan, but
so far, Alucard's plan has involved pretty much nothing but losing to
Square characters. This should prove to be no exception.<br><br>My vote: Alucard<br>My bracket: Auron<br>My prediction: Auron with 54%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/11/2006 10:06:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340351074">message detail</a>
 | #379</td></tr>
<tr class="even"><td>
Janus? More like should've predicted .74 lower <i>!!</i> Oh well, here's to hoping the % falls between 58.37 and 58.8!<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/11/2006 10:09:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340351550">message detail</a>
 | #380</td></tr>
<tr class="even"><td>
<i>Unless you are Sonic, Snake, Crono, or first party Nintendo, you are
likely not going to beat a Final Fantasy character. I hear all this
talk about Alucard's plan, but so far, Alucard's plan has involved
pretty much nothing but losing to Square characters. This should prove
to be no exception.</i><br><br>Alucard's plan is actually making
whoever beats him look like a joke. 2K2, Cloud &gt; Alucard, Mario &gt;
Cloud. 2K3, Seph &gt; Alucard, Cloud &gt; Seph, 2K4, Ganon &gt;
Alucard, Link &gt; Ganon, 2K5, Sora &gt; Alucard, Snake &gt; Sora.<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/11/2006 10:10:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340351804">message detail</a>
 | #381</td></tr>
<tr class="even"><td>
I'm not sure how Sephiroth beating Alucard and then making a run for
the finals and looking on par with Link made him look like a joke, but
then again it takes a complex mind to understand the simplicity of EC <i>!!</i><br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=863018" class="name">Janus5000</a> |
Posted 10/11/2006 10:11:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340351943">message detail</a>
 | #382</td></tr>
<tr class="even"><td>
BSE: KH &gt; CV, KH shows up late for its next match.<br>---<br>"Those who cast the vote decide nothing. Those who count the vote decide everything."<br><a class="linkification-ext" href="http://www.scorehero.com/scores.php?user=2916&amp;diff=4" title="Linkification: http://www.scorehero.com/scores.php?user=2916&amp;diff=4">http://www.scorehero.com/scores.php?user=2916&amp;diff=4</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=152338" class="name">Lopen</a> |
Posted 10/11/2006 10:39:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340357802">message detail</a>
 | #383</td></tr>
<tr class="even"><td>
This match <i>should</i> answer alotta
questions, but both of these fools were kinda fishy last year. Auron?
Behind some supposed double SFF that people can only really speculate
on how bad it really was. Alucard? Behind key boy getting his face
kicked in by Solid Snake. <br><br>So, basically, this doesn&#8217;t really
answer any questions about where they stand for me. They&#8217;re both
mysterious&#8230; oh yeah! Me? I&#8217;m thinking Auron will do a little better
than Ganondorf did a couple of years ago. But, Ganondorf wasn&#8217;t the
mighty bacon-kin back then that he is today&#8230; no no! Hell, you might
think <i>Alucard&#8217;s</i> not the mighty bacon-kin right now that <i>he</i>
was back then&#8230; and it&#8216;s possible! If Auron outdoes Ganondorf, this does
not mean Auron &#8220;KH2 boosted&#8221; over Ganondorf. But you already knew that,
right? <br><br>This match is more interesting for next round, I think.  If Auron doesn&#8217;t <i>vastly</i>
outperform Chief, we&#8217;ve still got a match, kids! Believe it or not!
Master Chief v Crono round 2, coming soon, brother! (Hell, even if he <i>does</i>... because Master Chief is a straight out freak, man!)<br><br>Yes,
I'm implying a Sub Zero fresh off Armageddon + MC anti-votes could give
Alucard a run for his money. What are you going to do about it? <br><br><b>Lopen&#8217;s Prediction:</b>  Auron with&#8230; whatever I said up there.  (Worth the wait?  You bet it was!)<br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=795464" class="name">Tatl</a> |
Posted 10/12/2006 12:53:01 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340378158">message detail</a>
 | #384</td></tr>
<tr class="even"><td>
KH, I know it's kinda way to late for this, but...I figure you can use it for the second round matches.<br><br>Bowser does have an upcoming game.  Super Smash Brothers Brawl...even if he hasn't been confirmed, you know he'll be in there.<br><br>(To say that he won't appear in the game cannot be counted as an opinion, it's just plain stupidity.)<br>---<br>"I reject your reality and substitute my own." ~ Adam Savage; Insanity Personified<br>"Crikey!" ~ Steve Irwin (R.I.P.); Perfection Personified
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3623587" class="name">Gaddswell</a> |
Posted 10/12/2006 1:46:04 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340383049">message detail</a>
 | #385</td></tr>
<tr class="even"><td>
<i>Alucard's plan is actually making whoever beats him look like a
joke. 2K2, Cloud &gt; Alucard, Mario &gt; Cloud. 2K3, Seph &gt;
Alucard, Cloud &gt; Seph, 2K4, Ganon &gt; Alucard, Link &gt; Ganon,
2K5, Sora &gt; Alucard, Snake &gt; Sora.</i><br><br>You know, I can
actually see that. Auron this year will have the KH Day vote behind
him, but he'll be against MC, who is the Day Vote King. Auron will end
up underpreforming (or maybe even losing!). Then if Auron gets to
Crono, we have a Square vs Square match that he can't possibly win
(even with Final Fantasy and Chrono Trigger not SFFing each other).<br>---<br>By the time we localize the programs, kids don&#8217;t even know they&#8217;re from Japan any more. - 4Kids CEO Al Kahn
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/12/2006 7:05:52 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340397329">message detail</a>
 | #386</td></tr>
<tr class="even"><td>
After seeing what Auron is doing today, it reaffirms my belief in Samus &gt; Mario! Vincent is a legit threat to Sonic, folks!<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/12/2006 8:01:08 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340401005">message detail</a>
 | #387</td></tr>
<tr class="even"><td>
More like, KHII boosted Auron beats Ganondorf now!<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 3</i>: Superman (0-2)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/12/2006 8:01:40 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340401039">message detail</a>
 | #388</td></tr>
<tr class="even"><td>
But I suppose if we go with your way, we could legitimately reason Squall &gt; Snake, so both work!<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 3</i>: Superman (0-2)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/12/2006 3:14:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340453376">message detail</a>
 | #389</td></tr>
<tr class="even"><td>
Bowser...................55.45% 66925<br>Leon Kennedy........44.55% 53772<br>TOTAL VOTES.....................120697<br><br>71.09% of the brackets predicted this match correctly.<br><br>This
is not the Bowser that went 50-50 with Solid Snake last year! It can't
be! Leon definitely boosted from RE4 on the PS2 and being out for a
long time, but by as much as to turn a 62-38 match into a 55-45 one? Uh
ohs, Bowser.<br><br>Today, Auron is doing better than expected against Alucard.<br><br>Lopen - 7<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye) - 5<br>Moltar - 5<br>KH - 5<br>HM - 4<br>Ulti - 4<br>Yoblazer - 2<br><br>Darn it Crew, stop letting the Guests win points!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Auron vs. Alucard - Bracket: <b>Auron</b> - Vote: <b>Auron</b> (27/30)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3802849" class="name">King Bowser</a> |
Posted 10/12/2006 3:24:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340455430">message detail</a>
 | #390</td></tr>
<tr class="even"><td>
<i>I'd like to give an early congrats to yoblazer!</i><br><br>lol ec<br><br>---<br>"That's a cruel, rotten, disgusting idea -- and I love it!"
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/12/2006 5:46:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340487106">message detail</a>
 | #391</td></tr>
<tr class="even"><td>
<i>But I suppose if we go with your way, we could legitimately reason Squall &gt; Snake, so both work!</i><br><br>I
do believe Squall is very possibly on Snake's level, but I can't get
over his 2K2 beatdown. Something went weird, and it went in Snake's
favor. Squall &gt; Bowser is all but a lock in my mind.<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/12/2006 6:05:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340491932">message detail</a>
 | #392</td></tr>
<tr class="even"><td>
Very little, if anything, has held up from 2002 so far. I certainly
don't expect an overperformance in Snake/Squall. "SFF" or whatever you
want to call it is rare in matches where characters are close in
strength. Mario/Samus is an exception, not a rule.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 3</i>: W, 50-12 vs. Superman
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/12/2006 6:09:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340492866">message detail</a>
 | #393</td></tr>
<tr class="even"><td>
Exactly, which is why no one should buy into that silly KHF. 2K2 had
half the votals, and plenty of other people had weird crazy jumps and
downfalls in 2K3 that didn't appear in KH, and weren't from Square.<br><br>(Sorry, I'm on a KHF rant!)<br><br>Oh,
and wasn't it you that used to be clamoring for horrible Squall
underratedness in 2K2 thanks to Snake/Squall in order to talk about how
his strength was underrated, and he was stronger than most would
believe in 2K5?<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/12/2006 6:19:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340495258">message detail</a>
 | #394</td></tr>
<tr class="even"><td>
Yes, I believe there was potential for an overperformance <i>back then</i>.
Would it happen now? I don't think so. Snake and Squall are too close
in strength now. If it does happen, I won't be shocked, but I'm not
betting on it.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 3</i>: W, 50-12 vs. Superman
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/12/2006 6:33:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340498779">message detail</a>
 | #395</td></tr>
<tr class="even"><td>
I don't think they're much farther apart in strength in 2K2 either. I'm
not expecting it to get as ugly as 2K2 did, but I'm still expecting an
overperformance, and people laughing at you!<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/12/2006 6:44:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340501487">message detail</a>
 | #396</td></tr>
<tr class="even"><td>
Nah, Squall wasn't anywhere near Noble Nine level before 2003.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 3</i>: W, 50-12 vs. Superman
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/12/2006 9:04:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340537517">message detail</a>
 | #397</td></tr>
<tr class="even"><td>
<b>Time Division:</b> <i>Round 1 - Match 32</i> &#8211; (2)Master Chief vs. (7)Sub-Zero<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Master Chief</b><br>Game/Series Known From: Halo<br>Extrapolated Rank in 2003: 26th (26.15%) <br>Extrapolated Rank in 2004: 15th (26.96%) Adjusted Value: 14th (29.96%) <br>Extrapolated Rank in 2005: 21st (28.29%)<br>Seed in 2003: 3<br>Seed in 2004: 3<br>Seed in 2005: 1<br>Lost in 2003 to Aeris in Round 2<br>Lost in 2004 to Frog in Round 2<br>Lost in 2005 to Crono in Round 3<br><br>That kerwazy Chief is back!<br><br><b>Sub-Zero</b><br>Game/Series Known From: Mortal Kombat<br><br>Sub-Zero&#8230;actually made it? Hmmm&#8230;<br><br>*We now interrupt your regularly scheduled analysis for something more&#8230;special.*<br><br><b>Master Chief vs. Sub-Zero: The Beginning of the End</b><br><br>*The
scene starts off in a dark room. A large table is in the room,
illuminating it. A bunch of men dressed in black are sitting around
this table. In the background, a sign that reads &#8220;CS&amp;D Room&#8221; is
hanging above a door.*<br><br>creativename: So it is agreed then,
Lopen&#8217;s mom would get 45% on HM&#8217;s mom in the finals, that is, if HM&#8217;s
mom could beat EC&#8217;s mom. *Much agreement followed this*<br><br>Lopen: More like KH&#8217;s mom for the upset!<br><br>Random guy: lol lopen<br><br>Moltar: So what&#8217;s next then?<br><br>Yoblazer: Well, it seems today&#8217;s match is Master Chief vs. Sub-Zero.<br><br>KH: <i>Sub-Zero is so screwed</i>.<br><br>Draco: Not exactly, Master Chief isn&#8217;t all that strong, and Sub-Zero shouldn&#8217;t be all that weak.<br><br>Cyko: Scorpion level? Cause Chief would still win.<br><br>Leon: Sub-Zero and Scorpion aren&#8217;t connected, Sub should be stronger.<br><br>*400
posts about Chief being a wildcard, Sub-Zero&#8217;s strength, Sub-Zero vs.
DK, random inequalities, people making crazy claims, misuse of the
x-stats, calls of the winner over Crono and Halo vs. Mortal Kombat
later*<br><br>creativename: Ugh, we&#8217;ll just agree to disagree.<br><br>Random
n00b: No way, you guys can&#8217;t agree on anything! Lol stats topix, Magus
&gt; Knux lolol x-stats, hey can I speak my opinion. Sub-Zero will win
because more people know and like him.<br><br>*Siren goes off* STATS ROOM NOOB ALERT! STATS ROOM NOOB ALERT!<br><br>Ulti: Quick, get him out of here!<br><br>*Two bouncers then arrive, throwing out the n00b from the Stats Room.*<br><br>Ulti: See, I predicted something like that would happen, so I hired guards!<br><br>EC: Good good, you know if our Elitism Meter drops below 94.5%, bad things happen!<br><br>Moltar: Anyway, the match is starting, let&#8217;s direct our attention to the screen.<br><br>*The scene switches to the battlefield.*<br><br>Referee: Alright, the battle between Master Chief and Sub-Zero is about to begin. Competitors, are you ready?<br><br>Master Chief: I&#8217;m ready to win.<br><br>Sub-Zero: I&#8217;m ready to kill.<br><br>Referee: Then let the match&#8230;.begin!<br><br>*Master Chief pulls out an Sub-Machine Gun, but Sub-Zero hits him before he can even attack with a ball of ice.*<br><br>Sub-Zero: First Strike!<br><br>Master Chief: Hold on buddy, give my shield time to regenerate.<br><br>Sub-Zero: Uh&#8230;alright.<br><br>*A few seconds pass*<br><br>Sub-Zero: So&#8230;how&#8217;s the wife and kids?<br><br>Master Chief: Oh, they&#8217;re fine. Jimmy just started school.<br><br>Sub-Zero: That&#8217;s great!<br><br>*Shield
fully regenerates, and the two continue their epic battle, which I
cannot go into detail because of how great it is, so instead, I&#8217;ll just
take us back to the Stats topic.*<br><br>HM: Impressive, Sub-Zero is holding up better than we thought. Too bad Chief is going to run away with this by morning<i>!!</i><br><br>*transience bursts into the Stats Room, panting heavily*<br><br>transience: It&#8217;s crazy out there in Building 8. People everywhere and going crazy.<br><br>Mac: Good thing we have our refuge in here from that!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/12/2006 9:05:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340537815">message detail</a>
 | #398</td></tr>
<tr class="even"><td>
*Smurf enters the Stats room, a collective sigh is heard*<br><br>creativename: *quietly* Alright guys, let&#8217;s try to be nice.<br><br>Smurf:
I&#8217;m almost done with my Smurf Stats, guys! It has Mega Man out of the
noble nine, and&#8230;well, actually, the whole Noble Nine are Sonic
characters!<br><br>Leon: How&#8217;d you manage something like that?!<br><br>Smurf:
I found a way with the Smurf Stats! By the way, I have some insider
info to tell. I have a feeling that the Snubs are going to interfere,
with a few new members.<br><br>*Everyone gasps*<br><br>Moltar: Impossible, the Snubs were locked up after their interference last year!<br><br>Smurf: Yeah, someone let them out &gt;_&gt;;;;;;;;; In fact, I have a good feeling about it happening right&#8230;no-.<br><br>*Just as he says that, Giant Ocelot bursts through the Battle Arena.*<br><br>Ocelot: Bang, Bang, *****es! Ocelot is back with the Snubs!<br><br>Random n00b: Ur a prafet, smurf!<br><br>*Random n00b is thrown out, Elitism Meter remains high*<br><br>Ulti: Thanks n00b avenger!<br><br>XIII: It seems the Snub Army has grown since the last Contest. <br><br>Ocelot:
Now, my minions, go out and destroy! Liquid, Tails, Shadow! Show them
how it&#8217;s done! Knuckles, Magus, Frog, DK, Kefka, watch carefully!<br><br>*The 8 of them attack the Battle Arena for MASSIVE DAMAGE!*<br><br>SDR: So, I hugged a 11 year old-*destroyed*<br><br>Aeon: And then I said, that&#8217;s not a badger, that&#8217;s my so-*obliterated*<br><br>JP: I can&#8217;t believe Aeris made it back, I&#8217;m so happy I could jump up and do-*sent to the Shadow Realm*<br><br>Master Chief: Hey, what the hell?<br><br>Sub-Zero: Stop interrupting our epic battle!<br><br>Ocelot: Quiet, weaklings!<br><br>Master Chief: Weaklings? I didn&#8217;t lose to Pac-Man!<br><br>*Ocelot crushes them with his Master Hand*<br><br>charmander: This is bad, looks like the Contest regulars need to step in! Not the females though, they&#8217;re all off at the salon.<br><br>KH: Like they would have done anything anyway&#8230;<br><br>Soma: *crushed*<br>Squall: &#8230;Whatever. *leaves*<br>Tidus: I&#8217;ll take you down! HYYYYAAA! *crushed by one of Tails&#8217; tails*<br>Riku: The power of semi-<b>DARKNESS</b> will *crushed by a Black Wind*<br>Yoshi: *flutters off*<br>Dante: THIS PARTY&#8217;S GETTING CRAZY! *does some badass stuff, but defeated*<br>Ryu H.: I&#8217;m a Ninja, BELIEVE IT! *crushed*<br>Tingle: KOO-LIMPAH! *beats everyone within an inch of their life, but fails to finish the job*<br>Phoenix: OBJECTION! *Kefka runs towards him* HOLD IT! *is <b>BARRIER&#8217;D</b> to death*<br>Gordon: *jobs to gravity*<br>Kratos: I can only be defeated by one person here! Hopefully, I don&#8217;t have to face them *draws Shadow*&#8230;Oh crap *defeated*<br>Ryu: *Street dances*<br>Axel: Awesome catchphrase attack! Got it&#8230;.memor-*punched out by Knuckles*<br>CATS: *is laughed at*<br>Vincent and Ganondorf: *too busy playing Yu-Gi-Oh!!* Vincent: You might have beaten me in Pokemon, but now you&#8217;re in my house!<br>Kirby: *Getting high*<br>Prince: *Gets &#8220;I&#8217;m you, I&#8217;m your shadow&#8217;D&#8221;*<br>Luigi: *too busy wondering if he should wear pink or magenta*<br>Zero: What am I fighting fooooooor! *Jobs to Pink Shirt Luigi, then DK beats his bongos*<br>Capt: Falcon: *stuck on Mission 7 on Very Hard in F-Zero GX*<br>Bowser:
*announcer at Vincent and Ganondorf&#8217;s game, by the way, feel free to
insert your favorite Abridged Series line here, cause it&#8217;s the only
Abridged reference you&#8217;ll get*<br>Leon: Your Master Hand comes off? *Frog slays him*<br>Auron: *Doesn&#8217;t care, remains silent and badass staring out at the sky*<br>Alucard: *Atop the Battle Arena* Yes&#8230;this is all a part of my plan.<br><br>Moltar: Well, that was pathetic. <br><br>Creativename: We need to get&#8230;the Legendary Four.<br><br>Mnm: Woah, but don&#8217;t they only come together if we do a Buster Call? We don&#8217;t have time for that!<br><br>Draco: Hey, they&#8217;re there!<br><br>*Link, Sephiroth, Cloud and Mario are all standing in front of Giant Ocelot and his gang of Snubs.*
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/12/2006 9:06:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340538147">message detail</a>
 | #399</td></tr>
<tr class="even"><td>
Snake: Looks like the gang is all here. Now, Noble Nine, let&#8217;s fight! <br><br>Knuckles and Frog: We can&#8217;t beat him! *defeated by Melting Man and/or Solid **** Snake picture, I couldn&#8217;t tell*<br><br>Mega Man: Wee, blasting stuff is fun! *Hits Tails and Shadow*<br><br>Crono: &#8230;<i>!!</i> *Defeats Liquid and DK*<br><br>Sonic: *streaks by Kefka and Magus*<br><br>Ocelot: No!! Hey, where is Sora?<br><br>Snake: Let&#8217;s just say he&#8217;s&#8230;all tied up. The 1-seed Initiation Ritual is tough to pass.<br><br>Sonic: Yeah, he won&#8217;t be wanting to sit down for a week! <br><br>Ocelot: Eww&#8230;oh well, *crushes Snake, Mega Man, Sonic and Crono with Handgestures*<br><br>Mario: Looks like it&#8217;s up-a to us, guys!<br><br>Link: You&#8217;re so lame, Mario.<br><br>*Link
and Mario fight, and Cloud and Sephiroth are also in a flashy battle
about crap no one cares about. Back in the Stats Room, the room has
been flooded by n00bs*<br><br>Ulti: No, the Elitism, it&#8217;s too low!<br><br>Lopen: That&#8217;s it, it&#8217;s the end of the world! *Takes Dante over Main bracket*<br><br>KH: <i>Everyone is so screwed.</i><br><br>Bulding 8 people: We love Sony! The PS3 won&#8217;t flop and the Wii will! RIIIIDGE RACER &gt; Twilight Princess!<br><br>Moltar: The only way I can save the world now is&#8230;activate <b>DEUS-EX MACHINA</b>!
*Slams the button, summoning a giant robot, then hops inside and goes
berserk. I&#8217;m talking Eva Unit-01 berserk, on everything. World ends,
then is reborn and everything is set right, give or take a time paradox
and some religious references.*<br><br>Master Chief: <b><i>SUB-ZERO!!!!!</i></b>  <br><br>Sub-Zero: <b><i>MASTER CHIEF!!!!!</i></b><br><br>*The two collide, a big explosion follows, and both are on the ground. After several moments, Chief slowly stands back up.*<br><br>Referee: This game&#8217;s winner is&#8230;Master Chief! *two people cheering are heard*<br><br>Ulti: I predicted that! <br><br>CJayC: darn u ulti<br><br>*Scene ends with everyone flooding back into the stadium, since Samus is back from the salon and ready to beat Ada.*<br><br>Samus: Hi boys! ^_^ *wink* teehee<br><br><b><i>NOSEBLEEDS!!!!</i></b><br><br><b>Moltar&#8217;s Bracket Says:</b> Master Chief will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Master Chief: 56%  - Sub-Zero: 44% <br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>I
have Chief winning, but I'll just laugh my ass off if Sub-Zero pulls
this one out. The hilarious thing is that he very well may.<br><br>...actually, wait, no one with common sense cares about Mortal Kombat.<br><br>Prediction: Chief with 63.33%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>Why
oh why is this match so debated? It seems to me that there are merely a
few vocal Sub-Zero fans (excuse me while I vomit at the thought) who
think that Master Chief is somehow weak enough to lose to this Mortal
Kombat trash. Hopefully the Chief silences his critics after he beats
Sub-Zero without any problem in today&#8217;s match.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/12/2006 9:07:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340538270">message detail</a>
 | #400</td></tr>
<tr class="even"><td>There is some reason to suspect that Master Chief
is overrated in 2005, but the amount that people wanting to put him is
rather absurd to me. He&#8217;s <i>still</i> a strong contestant in these things and not just <i>anyone</i>
is going to beat him. The fact that he went nearly even with DK does
not speak down about the Chief; rather, it speaks of DK&#8217;s increased
strength from previous years past &#8211; and DK <i>is</i> pretty much a Mario character at this point. <br><br>I
have never had much faith in Sub-Zero and it baffles me that people
think he is going to be worth something. We have yet to see an instance
where a fighting game character outside of Ryu has performed <i>extremely</i>
well. Chun-Li would easily take care of Sub-Zero. And the real kicker
here is that I would not dare take Sub-Zero over DK. Easy enough &#8211;
Master Chief wins. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Master Chief<br><br><b>Aitch Emm&#8217;s Prediction:</b> Master Chief &#8211; 57% ; Sub-Zero &#8211; 43%<br><br><b>Aitch Emm&#8217;s Vote:</b> Master Chief (Mortal Kombat and all things associated with it suck horribly and should immediately cease to exist.)<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br><br>Poor,
poor Master Chief. You just can't seem to blow anyone out, can ya? You
had a terrible contest debut against some dude named Felix, the closest
loss in history against Frog, and, to this day are the only character
in Character Battle history to allow CATS to not only break 20%, but
30%. Wish every opponent were a Playstation platformer star, don't ya?
Hey, don't fret, Chief! You've actually held your own against stronger
opponents like Aeris and Crono! Just how in the hell do you manage to
pull that crap off, anyway?<br><br>Regardless, your next opponent is Sub-Zero, and he's no Crash Bandicoot. Subzy is without a doubt <i>the</i>
most popular MK character. Don't give me that bull about being equal
with Scorpion. If that were true, why is Sub-Zero the only MK character
with his own game? He's always been the most popular. He has old school
cred and a ton of recognizability. Like Ryu, people will remember their
youth (good times) when they see Sub-Zero, and that's something Chief
simply doesn't have.<br><br>My god, what I wouldn't give to see the
upset go down. It would be glorious. Sadly, however, I really doubt
Chief will underperform badly enough to actually lose. That doesn't
mean he won't get the piss scared out of him for the first few hours,
though. =P<br><br>My prediction: Master Chief def. Sub-Zero (54-46)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>People
don't believe in Master Chief, they don't believe the hype. Why's this,
anyway? I blame the hairy ape! It's all his fault! People just can't
see Auron struggling with the ape. Well, to be honest, I couldn't see
it either. But&#8230; let's think about this. After 2003 and 2004, could
anyone see Luigi beating Zero&#8230; with ease? How about Knux &gt; Magus?<br><br>Just
because we don't accept the position of the stinking ape doesn't mean
it's not true. Boosts gotta come from somewhere, and he did shut down
Sam Fodder pretty well. Okay, he's fodder&#8230; but he's <i>strong</i> fodder. We shouldn't necessarily assume Master Chief is overrated in the X-Stats just because "they don't look right".<br><br>So,
why am I bringing it up? Well, I'd say any hype this match is getting
is because people think MC's overrated. Well, guess what I'm saying? If
you know me, I'm saying he's <i>not</i>. Now, I do think this is a
fiercer Sub-Zero than anything Scorpion has ever dished out. However,
it's not because I think Sub-Zero &gt; Scorpion as much as a recent
Mortal Kombat: Armageddon. Though I won't entirely factor out the
possibility of Sub-Zero being a bigger competitor than Scorpion. There
are definitely signs he could be.<br><br>But you know what? It doesn't
matter! Master Chief's gonna kick that fool's face in. Master Chief's
near elite, you watch! He doesn't even <i>need</i> a weapon!<br><br><b>Lopen's Prediction:</b> Master Chief with 60.01%.
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=6">7</a></li>
<li>8</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=9">10</a></li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage8_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30854544&amp;page=7" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage8_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>