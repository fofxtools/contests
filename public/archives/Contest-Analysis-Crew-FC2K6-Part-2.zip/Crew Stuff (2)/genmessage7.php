<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage7_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage7_files/nogs.css"></head><body linkifytime="200" linkified="0" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage7_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/afterhours/">After Hours</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage7_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30854544%26page%3D6"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage7_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage7_files/advertisement.gif" alt="advertisement" height="10" width="120"></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage7_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage7_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 2
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;page=6">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30854544" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=5">Previous Page</a> |
Page 7 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=7">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3793953" class="name">TehMissingLink</a> |
Posted 10/10/2006 4:17:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340050694">message detail</a>
 | #301</td></tr>
<tr class="even"><td>
Up my prediction for tomorrow by 1.5% if you could, Moltar<i>!!</i><br><br>---<br>"<i>Looking good, Princess, especially from this angle!</i>"
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/10/2006 5:02:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340061535">message detail</a>
 | #302</td></tr>
<tr class="even"><td>
And with this, I am officially changing my pick to win the male bracket to the winner of Vincent/Sonic.<br><br>Oh how ye Crono has fallen &gt;_&gt;;
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=993802" class="name">Sir Crono</a> |
Posted 10/10/2006 5:14:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340064566">message detail</a>
 | #303</td></tr>
<tr class="even"><td>
HM is moving from one Nintendo villain to the next, but at least he's moving up in quality!<br>---<br>As you wish.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/10/2006 5:23:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340066794">message detail</a>
 | #304</td></tr>
<tr class="even"><td>
<i>Up my prediction for tomorrow by 1.5% if you could, Moltar!!</i><br><br>K.<br><br><i>HM is moving from one Nintendo villain to the next, but at least he's moving up in quality!</i><br><br>Bowser is top tier, but Ganon is still higher<i>!!</i><br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Crono vs. Capt. Falcon - Bracket: <b>Crono</b> - Vote: <b>Falcon</b> (25/28)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/10/2006 7:58:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340107676">message detail</a>
 | #305</td></tr>
<tr class="even"><td>
Slow down the bleeding Crono! You must finish between 74.15 to 74.67%<br><br>Guest is gonna make a roaring comeback, just wait and see! (Tomorrows Guest best be predicting Bowser with 58% or less!)<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/10/2006 8:00:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340108515">message detail</a>
 | #306</td></tr>
<tr class="even"><td>
<i><br>Bowser is top tier, but Ganon is still higher!!</i><br><br>Amen brother! Ganon - 35.75% on BL. Bowser - 33.5% on BL.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/10/2006 8:33:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340117340">message detail</a>
 | #307</td></tr>
<tr class="even"><td>
Bowser/Leon is up for grabs for any Guest in 30 minutes if I don't get it by then.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Crono vs. Capt. Falcon - Bracket: <b>Crono</b> - Vote: <b>Falcon</b> (25/28)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/10/2006 8:38:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340118620">message detail</a>
 | #308</td></tr>
<tr class="even"><td>
Leon? That guy from RE? I could do it, but it would be a half assed writeup. =/<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/10/2006 8:40:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340119142">message detail</a>
 | #309</td></tr>
<tr class="even"><td>
I'll give you one right in here if you want!<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/10/2006 8:41:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340119478">message detail</a>
 | #310</td></tr>
<tr class="even"><td>
Yeah, but you'll just post yours anyways if he doesn't use it. I won't. T_T<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/10/2006 8:41:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340119480">message detail</a>
 | #311</td></tr>
<tr class="even"><td>
I'll totally take Bowser/Leon Moltar. I have the most outrageous, and more importantly correct prediction of all!<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/10/2006 8:45:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340120403">message detail</a>
 | #312</td></tr>
<tr class="even"><td>
I'm looking to snatch my <i>second</i> straight Crew point! Woo!<br><br><br>THE KOOPA KING GOING TO GET ME A THIRD!<br><br>---<br><i>"Looking good, Princess, especially from this angle!</i>"
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/10/2006 8:50:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340121822">message detail</a>
 | #313</td></tr>
<tr class="even"><td>
Not so fast Starfox!<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/10/2006 8:57:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340123754">message detail</a>
 | #314</td></tr>
<tr class="even"><td>
I'm not going to be done in time. -_-<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/10/2006 9:52:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340137983">message detail</a>
 | #315</td></tr>
<tr class="even"><td>
<b>Time Division:</b> <i>Round 1 - Match 30</i> &#8211; (4)Bowser vs. (5)Leon Kennedy<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Bowser</b><br>Game/Series Known From: Super Mario<br>Extrapolated Rank in 2003: 13th (30.97%) <br>Extrapolated Rank in 2004: 31st (20.41%) Adjusted Value: 18th (28.88%)<br>Extrapolated Rank in 2005: 9th (33.49%)<br>Seed in 2003: 5<br>Seed in 2004: 7<br>Seed in 2005: 3<br>Lost in 2003 to Cloud in Round 3<br>Lost in 2004 to Mario in Round 2<br>Lost in 2005 to Solid Snake in the Elite 8<br><br>Rawr!<br><br><b>Leon</b><br>Game/Series Known From: Resident Evil<br>Extrapolated Rank in 2005: 26th (25.20%)<br>Seed in 2005: 5<br>Lost in 2005 to Mega Man in Round 2<br><br>&#8220;Leon!&#8221;<br><br>Bowser,
who went 50-50 with Snake last Contest&#8230;is wasted as a 4 seed. darn you
nominations and female bracket. It wouldn&#8217;t be as bad too if he was a 4
in Sora&#8217;s division, but no, it&#8217;s in Crono&#8217;s. Oh well&#8230;<br><br>His
opponent is also wasted here. Leon was able to avoid a doubling from
Mega Man last year, which is pretty good for a new character. With RE4
being out longer and on another console, he should be a bit stronger.
Of course, he&#8217;s still no match for Bowser. Let&#8217;s see if he shows us why
he&#8217;s the strongest non-Noble nine character.<br><br><b>Moltar&#8217;s Bracket Says:</b> Bowser will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Bowser: 61% - Leon: 39%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br><br>Was Bowser overrated in 2005?! Tune in at midnight to see!<br><br>(These easy matches are killing my material here.)<br><br>Prediction: Bowser with 61.11% <br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>Both
of these guys came out looking mighty impressive last year. For Bowser,
he nearly did the unthinkable by beating Snake and Leon turned heads by
putting on a very good performance against Mega Man despite not blowing
out Gordon Freeman. Heading into this contest, both of these two are
looking to see some slight increases in their strength and come out
proving that there was nothing overrated about them last year! <br><br>There&#8217;s
really nothing too debatable here as far as the match goes because
Bowser is going to win with ease, but what will be interesting to see
is if he can still maintain his 60%+ projection from last year. Leon
has had the PS2 release of Resident Evil 4 to help him out while Bowser
is coming off of NSMB and more of a Nintendo shift. I&#8217;m expecting both
of them to come out a bit stronger than they were last year, but it&#8217;ll
cancel out and remain at the same percentage. If Bowser significantly
overperforms or underperforms though, we may have to raise some
questions about that Dream Division&#8230;but I don&#8217;t think we&#8217;ll be worrying
about that. <br><br>It&#8217;s unfortunate that Leon couldn&#8217;t have been put into a better position in the bracket. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Bowser<br><br><b>Aitch Emm&#8217;s Prediction:</b> Bowser &#8211; 63% ; Leon Kennedy &#8211; 37%<br><br><b>Aitch Emm&#8217;s Vote:</b> Bowser<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Dull
match here. The only way this can get exciting is if Bowser beats Leon
badly enough to warrant whispers of the big baddie taking out Crono in
the next round. Seeing as how Nintendo's early performances so far have
been a mixed bag, I doubt that that will happen. Leon received a
significant sales boost with the PS2 port of Resident Evil 4 late last
year, so he should have maintained his 2005 level. I would be
completely shocked if Bowser were to somehow meet or exceed Mega Man's
percentage against Leon last year, but he should have the power to get
within a few percentage points.<br><br>My prediction: Bowser def. Leon Kennedy (63-37)<br> <br> <br> <br><b>Lopen&#8217;s Analysis</b><br> <br>I
can't think of anything to say about these dudes. 60% on Ryu vs&#8230; 60% on
Gordon Freeman? But, as your analysis writer, it is my duty to make
this match <i>seem</i> interesting&#8230; and so I shall.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/10/2006 9:53:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340138064">message detail</a>
 | #316</td></tr>
<tr class="even"><td>
Let us consult the X-Stats! What I am claiming is, Bowser is not as
strong as the X-Stats say! He has been rSFFing every opponent since the
2004 contest! His true form? It was against Mario! No no&#8230; no "SFF
adjusting there", that was all legit, baby! Let's take a look and see
how the match will <i>really</i> go!<br><br>Bowser (2004c raw) VS Leon Kennedy (2005c)<br>Bowser has a strength of 21.88.<br>Leon Kennedy has a strength of 27.50.<br> <br>Leon Kennedy wins with 60.22% of the vote!<br>A win of 18,841 with 92,193 total votes cast.<br><br>Now
you say&#8230; "how will Leon Kennedy resist Bowser's vile rSFF?". Well, it's
simple, zombies don't like Bowser. Yeah&#8230; easy win for <i>Miiister Kennedy</i>. Or was that <b>MISTAAAAHHHH&#8230; KENNEDY!!</b><br><br>Lopen's prediction: Leon Kennedy with 60.22% of the vote, X-Stats don't lie!<br><br><b>&#8230; KEN-NE-DY!</b><br><br>No,
no, that's not my prediction! Really! Sorry. That analysis was stupid,
random, filled with references you don't get, and blatantly lying. I
probably should've just gave a line about wasted Bowser and Leon
potential (Their bracket placement sucks big time, man! Damned Female's
bracket!) beyond that first paragraph and been done with it, but&#8230;
that's not fun!<br><br><b>Lopen's prediction:</b> Bowser with 61.11%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>BOWSER</b><br><br><i>"They have no IDEA what they're up against! I'm lightning in a bottle! I'm an earthquake in a can!"</i><br><br>Summer 2003 Contest<br>Extrapolated Strength --- 17th Place [29.97%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 18th Place [28.88%]<br><br>Spring 2005 Contest<br>Extrapolated Strength --- 3rd Place [40.45%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 10th Place [33.49%]<br><br>Yo, it's the <i>good</i>
Nintendo villain strutting his stuff now! For all the things I hate and
despise about Ganondorf, Bowser does them all right. Having great
humor, an interesting personality, being distinctive and unique, Bowser
is truly gaming's villain. If any character were to be worthy of
breaking the Noble Nine, Bowser would be the top candidate -- and he
very nearly pulled it off last year. Many have decried him as
"overrated" despite his fantastic performance, but the Koopa King is
looking to prove he's no fluke! WOO BOWSER<br><br><b>LEON KENNEDY</b><br><br><i>"This is no ritual, it's terrorism!"</i><br><br>Summer 2005 Contest<br>Extrapolated Strength --- 28th Place [25.20%]<br><br>Leon
Kennedy is back in style, representing the revitalization of the
Resident Evil series. After his shocking performance on Mega Man in
2005 (considering his lackluster showing against Gordon Freeman) he is
rewarded with an unwinnable match here. I mean, I like Jill, Claire,
and Ada as much as the next CATS, but no way did they deserve to get
much more favorable setups than Mr. Kennedy. I'd have called him a
virtual lock to the third round in Claire or Jill's place, but instead
he's being fed to Bowser. And it's a shame, too. WOO LEON<br> <br><i>Notable Releases Since Last Appearance</i><br> <br>Bowser: New Super Mario Brothers (DS)<br>Leon Kennedy: Resident Evil 4 (PS2)<br><br><i>Upcoming Releases</i><br><br>Bowser: N/A<br>Leon Kennedy: Resident Evil: Umbrella Chronicles (WII)<br> <br>Not
even in question, this one. Leon may do a bit better thanks to RE4
being on the PS2, but its main fanbase here is on the GC and that may
hurt him here (though it certainly didn't against THE KING OF SFF!!).<br> <br>Karma Hunter's Vote: Bowser. Though it is a tough choice!<br><br><b>Karma Hunter's Krazy Prediction: Bowser with 62.45%.</b><br><br>Going high (for me, anyway) after seeing what Luigi did to Zero. Make me proud, Koopa King!<br><br>Upset Potential: 0%<br><br>Not a chance <i>!!</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/10/2006 9:53:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340138259">message detail</a>
 | #317</td></tr>
<tr class="even"><td>
<b>Guest&#8217;s Analysis</b> - <i>Explicit Content</i><br><br>Okay, why are we even talking about this match? I mean seriously, Bowser is going to be defeating Crono next round right? <b>NOT SO FAST STARFOX!</b>
Bowser's lucky that he's high enough above Leon that he doesn't have to
worry about losing, but that doesn't mean he won't be worrying about
horribly underperforming! <br><br>Let's start with Bowser, or rather,
this mysterious "Nintendo Boost of 2K5." More like "Overrated Boost of
2K5" m i rite? Let's start at the top o' the ladder, with my good
friend, Mr. Mario Mario. At first glance it may appear that Mario came
out of nowhere, and decided to gangbang the competition with a whopping
6% boost, but really, let's put that baby in perspective. Mario goes
from taking Crono, and ***** slapping him every single year, to losing
miserably to him 2K4. Miserably being a relative term right there.
There was a massive push for Crono to finally take down the great
Mario, from people who were tired of seeing Mario own Crono year after
year, even I, yes, I, the great EC was caught up in it, and I -HATE-
everything CT. That game just reeks of suck and horrible, but I
digress. The point is, if someone who loves Mario as much as me (SM64
&gt; Sex), and hates CT as much as me (Having a beaver gnaw at your
balls &gt; CT), can be swayed, I'm sure there were others as well. So
basically, we take Mario 2K4 and boost him up to Crono's 2K4 value ---
39.87%, and that's assuming Mario simply goes 50/50 with him, which
isn't out of the ordinary. That massively cuts down on his boost, to a
reasonable 3%. Now it's time for everyones favorite plumber, and better
brother, Luigi! Oh I went there girlfriend. 2K3, Luigi loses in a board
heartbreaker to Squall (though I'm sure Leon was busting a nut, if he
was around at least!), Squall, Samus, and finally Samus, Link. Now we
all know the true king of SFF, (no not MM you silly goose), would be
able to score some sort of SFF on Samus, underrating Luigi in 2K3,
however no adjustments were ever made, and Samus would do some
redonkulous boosting the next year. Coincidence? I think not! Now let's
go to 2K4, where Luigi suffers a rSFF beatdown at the hands of Yoshi, a
character who Luigi would outperform indirectly any day of the week,
once again hiding his true strength, while Yoshi goes on to get
beatdown by Link, causing Luigi to get MASSIVELY underrated, setting up
a huge 2K5 boost, or rather, proving himself to always have been a
character with strength. And yes, Yoshi was adjusted up to his 2K3
numbers, but he had a nice match with Bowser that year, and I don't
think anyone would argue SFF, so even adjusted the duo are both
definitely underrated. Which leads us to Yoshi, who apparently didn't
boost in 2K5, that takes care of Yoshi's apparent boost in 2K5 as well.
See the trend? Donkey Kong, meat Master Chief, Master Chief, meet
completely ****ing up the x-stats, you sly devil you. And Samus? She
seemingly didn't boost at all, I definitely still think Mario rSFFed
her, and she was under adjusted, but not by much. So that keeps her
pretty constant with her previous year. Now when you put everything
into perspective, and look at everything on an individual match by
match basis, instead of just looking at the x-stats and saying "HOLY
BOOST SAUCE BATMAN!" it becomes apparent that this huge Mario/Ninty
boost really wasn't so big at all.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/10/2006 9:55:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340138721">message detail</a>
 | #318</td></tr>
<tr class="even"><td>
whoa, that's a wall<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/10/2006 9:55:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340138754">message detail</a>
 | #319</td></tr>
<tr class="even"><td>Moving on to Leon! Not nearly as much to say about
this one, and after that tangent, I'll try and keep it short. Leon did
pretty well for himself in 2K5, landing at 27.5% on BL, with the highly
acclaimed RE4 on GC recently out, no reason to assume anything fishy
went on there, but the problem comes in with the PS2 version of RE4
coming out since the last contest, AND selling more than than it's GC
counterpart. Taking everything into consideration with how boosts have
worked in the past, and I think a 2.5% boost for Leon is very fair. <br><br>Now, let's have some fun with lol x-stats, since I'm too lazy to calculate for myself.<br><br>Leon 2K5 - 27.5%. Adjusted up 2.5% for RE4. - Projected 2K6 Value - 30.00%BL (2K5 Ryu)<br>Bowser 2K5 - 36.5% Adjusted down 3% for Bowser/Snake. - Projected 2K6 Value - 33.5%BL (2K5 Tifa)<br><br>Ryu (2005c) VS Tifa (2005c)<br><br>Ryu has a strength of 29.98.<br>Tifa has a strength of 33.57.<br><br>Tifa wins with 55.35% of the vote! <br>A win of 10,175 with 95,144 total votes cast.<br><br>55.35% for Bowser it is!<br><br>But I'm too much of a dirty little girl to go that low, so I'll bump it up, because honestly, who is going to be as low as me?<br><br><b>Explicit Content's Horribly, And Disgustingly Right Prediction: Bowser with 56.5%</b><br> <br> <br> <br>Crew
Consensus: Will Bowser pulls a Smash Attack on Leon, or will
MIIISSTTAAAHHH KENNEEEEEDYYYY perform better than expected? Crew
expects something close to the Stats, but the Guest...not so much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/10/2006 9:57:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340139131">message detail</a>
 | #320</td></tr>
<tr class="even"><td>
Your mother's a wall!<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/10/2006 9:58:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340139360">message detail</a>
 | #321</td></tr>
<tr class="even"><td>
Someone <i>really really really</i> wants Bowser to be weaker than Ganon...<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/10/2006 9:58:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340139450">message detail</a>
 | #322</td></tr>
<tr class="even"><td>
Is it Jesus?<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/10/2006 9:59:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340139549">message detail</a>
 | #323</td></tr>
<tr class="even"><td>
Oh, and as a character Bowser &gt;&gt;&gt;&gt;&gt;&gt;&gt; *ahem* &gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; Ganon.<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/10/2006 9:59:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340139674">message detail</a>
 | #324</td></tr>
<tr class="even"><td>
lol ec<br><br>---<br><i>"Looking good, Princess, especially from this angle!</i>"
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/10/2006 9:59:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340139772">message detail</a>
 | #325</td></tr>
<tr class="even"><td>
transience's analysis:<br><br>I kinda agree with
HM here. RE4 for PS2 should be enough to counteract any NSMB boost. two
questions remain - if Bowser is overrated thanks to that picture vs.
Snake and if Leon Kennedy overperformed on Mega Man. I mean, he got
under 60% on <i>Gordon Freeman.</i> GF didn't look that good against Phoenix either. <br><br>so,
I think the stats will be pretty close to dead on here. if Bowser does
a number on Leon, I'll just assume it's Leon sucking instead of Bowser
kicking ass. CAUSE HE'S NOT BEATING CRONO HM<br><br>prediction: Bowser with 61.11%<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/10/2006 10:00:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340139912">message detail</a>
 | #326</td></tr>
<tr class="even"><td>
Nice % tranny!<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 10/10/2006 10:00:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340139958">message detail</a>
 | #327</td></tr>
<tr class="even"><td>
Samus&gt;Bowser&gt;CORNO&gt;Ganon&gt;CORN FLAKES&gt;Leon Kennedy&gt;Sephiroth<br><br>/Totally random inequality<br><br>---<br><i>Do you really need me to bring out the Ovaltine?</i>-Stripey12isback on why hes a war hero.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/10/2006 10:01:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340140172">message detail</a>
 | #328</td></tr>
<tr class="even"><td>
Just you wait, Tran Man! <br><br>When Bowser is laying the smacketh downeth on Crono, you'll be saying "I SO SHOULD HAVE LISTENED TO THAT GENIUS AITCH EMM!"<br><br>---<br><i>"Looking good, Princess, especially from this angle!</i>"
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/10/2006 10:01:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340140177">message detail</a>
 | #329</td></tr>
<tr class="even"><td>
whoa crap I picked Lopen's prediction<br><br>uhh 61.10% please<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/10/2006 10:02:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340140300">message detail</a>
 | #330</td></tr>
<tr class="even"><td>
<i>THAT GENIUS AITCH EMM</i><br><br>what<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/10/2006 10:02:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340140396">message detail</a>
 | #331</td></tr>
<tr class="even"><td>
<i>whoa crap I picked Lopen's prediction<br><br>uhh 61.10% please</i><br><br>Lopen AND Ulti. That's just freaky.<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/10/2006 10:03:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340140686">message detail</a>
 | #332</td></tr>
<tr class="even"><td>
whoa, what the? 61.11% is going to <i>happen</i><br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/10/2006 10:03:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340140699">message detail</a>
 | #333</td></tr>
<tr class="even"><td>
I'd laugh my ass off if Bowser took the male bracket, as HM being right
on the upset but betting on the wrong horse would tickle me to no end.<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/10/2006 10:04:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340140934">message detail</a>
 | #334</td></tr>
<tr class="even"><td>
I wouldn't mind tickling you to no end either.<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=46088" class="name">therealmnm</a> |
Posted 10/10/2006 10:08:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340141904">message detail</a>
 | #335</td></tr>
<tr class="even"><td>
mnm's analysis<br><br>Like the moon over<br>the day, my genius and brawn<br>are lost on these fools<br><br>Bowser with 66%<br>---<br>Currently playing: Grand Theft Auto 3, Castlevania:Curse of Darkness, Mega Man ZX
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/10/2006 10:09:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340142096">message detail</a>
 | #336</td></tr>
<tr class="even"><td>
Mario SFF'd Zero!<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/10/2006 10:10:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340142353">message detail</a>
 | #337</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Sigh, I got more important
things to do. Bowser is arguably the best non-Noble 9 character, and
he's going to stomp all over Leon.<br><br>*gets SMB castle theme music stuck in my head*<br><br>My vote: Bowser<br>My bracket: Bowser<br>My prediction: Bowser with 68%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/10/2006 10:11:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340142533">message detail</a>
 | #338</td></tr>
<tr class="even"><td>
Haha, it never fails....once again, I'm way above the Crew's predictions.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/10/2006 10:11:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340142637">message detail</a>
 | #339</td></tr>
<tr class="even"><td>
Mario is expected to get 68% on Leon... and that's without a PS2 RE4 boost.<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/10/2006 10:13:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340143038">message detail</a>
 | #340</td></tr>
<tr class="even"><td>
<i>I'd laugh my ass off if Bowser took the male bracket, as HM being
right on the upset but betting on the wrong horse would tickle me to no
end.</i><br><br>I would cry and laugh at the same time. Because it would be both sad and beautiful <i>all at once</i>.<br><br>---<br><i>"Looking good, Princess, especially from this angle!</i>"
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/10/2006 10:13:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340143145">message detail</a>
 | #341</td></tr>
<tr class="even"><td>
Mario totally rSFFed Bowser and Bowser only lost to Snake because Snake
got all those pity votes for his horrible picture YAY I DID IT!<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/10/2006 10:14:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340143208">message detail</a>
 | #342</td></tr>
<tr class="even"><td>
I guess I underestimate Leon.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/10/2006 10:14:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340143268">message detail</a>
 | #343</td></tr>
<tr class="even"><td>
Oh man I just got Karma Huntowned.<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/10/2006 10:15:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340143425">message detail</a>
 | #344</td></tr>
<tr class="even"><td>
This also means that Prince of Persia &gt; Ganondorf!<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/10/2006 10:15:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340143572">message detail</a>
 | #345</td></tr>
<tr class="even"><td>
Hm..... <b>BOWSER FOR CONTEST WINNER, BOWSER &gt; LEON WITH 69%</b><br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/10/2006 10:59:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340152732">message detail</a>
 | #346</td></tr>
<tr class="even"><td>
Screw it, I'm doing one.<br><br>Well, we have
certainly had some interesting matches recently and now that the brief
intermission of Crono over Captain Falcon is out of the way, we&#8217;re back
into the action! Who are our brave warriors going at it this time,
Jimma? Well Bobba, it looks like we have the underdog Leon Kennedy
going up against the King of the Koopa, Bowser!<br><br>Let&#8217;s take a
quick look at the underdog first. Leon Kennedy is one of the
protagonists one of the Resident Evil series. To be honest, I have
never played a Resident Evil game, so I can&#8217;t really say how good of a
character he is. However, after scouring the Internets, it seems to me
that Leon has evolved into the most popular character from the series
over time. Will this be enough to save him? We&#8217;ll find out soon enough,
but before that, let us take a look at his opponent.<br><br>Who do we
have here? Oh, it&#8217;s only by far the best Nintendo villain in this
contest, Bowser. This guy is just so damn badass, what with his
consistent churning out of plot twists, that not even Ganondorf can
come anywhere near him in terms of sheer awesomeness. He loves to let
Mario think that he has won, but really he is allowing Mario to get
overconfident for when he is going to unleash his true plan: All out
war against Mushroom Kingdom. Now, I&#8217;m not tactician, but clearly
anyone can see that the time to strike is now. This contest, Bowser is
going to defeat Mario once and for all, and to do so, he needs to start
by destroying the insignificant bug that is before him in the form of
Leon Kennedy.<br><br>So we know that Bowser is going to dominate Leon,
but exactly how badly will he slaughter him? I have absolutely no idea
how Leon should fare beyond x-stats, so I&#8217;m just going to go with that,
and bump Bowser up a few points for potential minor NintedoFAQs SFF. <br><br>My prediction? Bowser with 64.37% of the vote.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/10/2006 11:30:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340158505">message detail</a>
 | #347</td></tr>
<tr class="even"><td>
Bah, I was aiming for last second, and then CJayC had to go and delay it randomly. -_-<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/10/2006 11:31:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340158720">message detail</a>
 | #348</td></tr>
<tr class="even"><td>
[This message was deleted at the request of the original poster]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=546065" class="name">badazzbuddy117</a> |
Posted 10/11/2006 1:19:50 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340172158">message detail</a>
 | #349</td></tr>
<tr class="even"><td>
Explicit content ftw?<br>---<br>All hail the "Go Halo" monks!<br>Name: Poo MK friend code:352255-222249
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3623587" class="name">Gaddswell</a> |
Posted 10/11/2006 2:17:22 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340176830">message detail</a>
 | #350</td></tr>
<tr class="even"><td>
Wow, everyone's writing their own analysis now. It's starting to look
like the oracle topic, in a way. Might as well make this THE Analysis
topic and have everyone else just post here instead of making different
topics for each one.<br><br><br>So far it looks like EC wins today.<br><br>Bowser 55.99%  11065<br>Leon Kennedy 44.01%  8699<br>TOTAL VOTES 19764<br>---<br>By the time we localize the programs, kids don&#8217;t even know they&#8217;re from Japan any more. - 4Kids CEO Al Kahn
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=5">6</a></li>
<li>7</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=9">10</a></li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage7_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30854544&amp;page=6" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage7_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>