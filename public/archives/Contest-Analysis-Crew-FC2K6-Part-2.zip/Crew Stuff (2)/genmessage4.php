<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage4_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage4_files/nogs.css"></head><body linkifytime="261" linkified="1" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage4_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/afterhours/">After Hours</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage4_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30854544%26page%3D3"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage4_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage4_files/advertisement.gif" alt="advertisement" height="10" width="120"></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage4_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage4_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 2
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;page=3">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30854544" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=2">Previous Page</a> |
Page 4 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=4">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/5/2006 9:54:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339054632">message detail</a>
 | #151</td></tr>
<tr class="even"><td>
Lopen's analysis wins. he's too good at that.<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 10/5/2006 10:05:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339057222">message detail</a>
 | #152</td></tr>
<tr class="even"><td>
Agreed, nice analysis Lopen!<br>---<br>CB06 - Score: <b>22/23 </b>Rank: <b>Tied - 396th </b>Yesterday's Pick:<b> Ryu</b> <br>Today's Pick: <b>Mega Man</b> Tomorrow's Pick: <b>Sonic</b> Losses: <b>Cortana</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 10/5/2006 10:19:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339060207">message detail</a>
 | #153</td></tr>
<tr class="even"><td>
Just reaffirming my dibs on the Zero/Kirby guest analysis &lt;_&lt;<br><br><b>TuRtLe</b><br>~~~<br>I used my brain and statistics to make my bracket. Karma Hunter used MGS fanboyism. KH won. <b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=795464" class="name">Tatl</a> |
Posted 10/6/2006 1:32:06 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339087278">message detail</a>
 | #154</td></tr>
<tr class="even"><td>
I really want to see a CATS vs Gordon match...<br>---<br>"I reject your reality and substitute my own." ~ Adam Savage; Insanity Personified<br>"Crikey!" ~ Steve Irwin (R.I.P.); Perfection Personified
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/6/2006 2:31:37 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339091521">message detail</a>
 | #155</td></tr>
<tr class="even"><td>
Mega Man vs. Axel<br>+7 Lo<br>+6 Guest<br>+5 Yo<br>+4 Ulti<br>+3 KH<br>+2 Moltar<br>+1 HM<br><br><b>The Rankings</b> (Through Mega Man vs. Axel)<br>1. Karma Hunter (117)<br>2. Master Moltar (105)<br>3. Heroic Mario (97)<br>4. Yoblazer (92)<br>5. UltimaterializerX (91)<br>6. Lopen (76)<br>7. Board 8 (68)<br><br>I'm expecting an even split for Ganondorf/Vincent, so look for our first big shake-up in about a day.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=254355" class="name">Lugia2</a> |
Posted 10/6/2006 5:45:17 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339100062">message detail</a>
 | #156</td></tr>
<tr class="even"><td>
Lopen's was fun.<br><br>Ganon/Vincent tomorrow...well, <i>that</i> will be an interesting match.  <br><br>GGanon!<br><br>Also...who was the guy who said 21%?  It looks like he'll win.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/6/2006 12:41:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339134478">message detail</a>
 | #157</td></tr>
<tr class="even"><td>
Sonic the Hedgehog vs. CATS<br>+7 Mo (tie)<br>+7 Yo (tie) <br>+5 Ulti<br>+4 KH<br>+3 HM<br>+2 Guest<br>+1 Lo<br><br><b>The Rankings</b> (Through Sonic vs. CATS)<br>1. Karma Hunter (121)<br>2. Master Moltar (112)<br>3. Heroic Mario (100)<br>4. Yoblazer (99)<br>5. UltimaterializerX (96)<br>6. Lopen (77)<br>7. Board 8 (70)<br><br>It's
almost time for the biggest first round match of them all. Now, I
believe Moltar, HM, and I are all going for Ganondorf, so either things
will get a bit tighter up top, or Karma Hunter will have a massive lead.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/6/2006 1:43:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339142533">message detail</a>
 | #158</td></tr>
<tr class="even"><td>
lolz KH is about to take a fat lead.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/6/2006 1:45:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339142862">message detail</a>
 | #159</td></tr>
<tr class="even"><td>
Lopen, watch out, the Guests are comin for ya!<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/6/2006 1:50:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339143601">message detail</a>
 | #160</td></tr>
<tr class="even"><td>
DP, sadly I dont think Board 8 stands a chance.<br><br>Have you not seen the Vincent/Ganon &gt; Sonic topics?<br><br>We will be lucky if 6th place doesnt double up on Board 8 by the time its all said and done &gt;_&gt;;
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/6/2006 1:54:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339144212">message detail</a>
 | #161</td></tr>
<tr class="even"><td>
Yeah, I know, the guests pick far too many upsets for them to compete.
But Lopen's taken a few upsets too, leaving Board 8 just 7 points
behind him.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/6/2006 6:19:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339196066">message detail</a>
 | #162</td></tr>
<tr class="even"><td>
Mega Man...........69.87% 81959<br>Axel......................30.13% 35340<br>TOTAL VOTES................117299<br><br>90.42% of the brackets predicted this match correctly.<br><br>Axel broke 30%?! We're talking about Mega <i>Freakin'</i>
Man! The self-proclaimed (ok, maybe not self-proclaimed...) King of
SFF! Looks like the KH2 influence continues to impress, as Axel ends up
almost as strong as 2005 Riku.<br><br>Today, Sonic has over 80% on CATS.<br><br>Lopen - 7<br>KH - 5<br>Moltar - 4<br>Ulti - 4<br>HM - 3<br>Yoblazer - 1<br>Guest (Wigs) - 1<br><br>Lopen hits once again with a low Mega pick.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sonic vs. CATS - Bracket: <b>Sonic</b> - Vote: <b>Sonic</b> (23/24)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/6/2006 6:35:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339199403">message detail</a>
 | #163</td></tr>
<tr class="even"><td>
Hey, if Board 8 can beat Lopen, that could be considered a feat in itself!<br><br>And looking at these Vincent/Ganon write-ups, I got 3 things.<br><br>1) Looking to be split 4-3.<br>2) Lots of walls o' text<br>3) They're probably going up a little early.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sonic vs. CATS - Bracket: <b>Sonic</b> - Vote: <b>Sonic</b> (23/24)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3623587" class="name">Gaddswell</a> |
Posted 10/6/2006 6:41:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339200731">message detail</a>
 | #164</td></tr>
<tr class="even"><td>
Well, as long as the walls are interesting, then I don't mind them.<br>---<br>By the time we localize the programs, kids don&#8217;t even know they&#8217;re from Japan any more. - 4Kids CEO Al Kahn
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/6/2006 7:09:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339206424">message detail</a>
 | #165</td></tr>
<tr class="even"><td>
No wall o' text from me, yay!  Quick Analysis FTW.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/6/2006 7:47:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339213548">message detail</a>
 | #166</td></tr>
<tr class="even"><td>
*waits for it*<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/6/2006 8:10:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339218426">message detail</a>
 | #167</td></tr>
<tr class="even"><td>
<i>There was an error posting your message: The maximum allowed size
for a message is 4096 characters. Your message is 32079 characters long.</i><br><br>Alright, this is going to take a while...write-ups going up in 5.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sonic vs. CATS - Bracket: <b>Sonic</b> - Vote: <b>Sonic</b> (23/24)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/6/2006 8:11:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339218625">message detail</a>
 | #168</td></tr>
<tr class="even"><td>
haha. I'm looking forward to reading HM's wall. no, his mountain.<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/6/2006 8:11:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339218627">message detail</a>
 | #169</td></tr>
<tr class="even"><td>
Haha, wow....<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=834874" class="name">MarkSmith</a> |
Posted 10/6/2006 8:12:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339218796">message detail</a>
 | #170</td></tr>
<tr class="even"><td>
KH is prolly the only one who took Vincent. he's gonna win this in a land slide.<br>---<br>PROUDEST MEMBER OF THE FIGHTIN' TEXAS AGGIE CLASS OF 2010<br>Next game: who cares? Fire Fran!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/6/2006 8:13:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339218919">message detail</a>
 | #171</td></tr>
<tr class="even"><td>
knowing the crew, it's... 3-2, Vincent. dunno who the guest is.<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/6/2006 8:14:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339219239">message detail</a>
 | #172</td></tr>
<tr class="even"><td>
Moltar said the split was 4-3.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2568612" class="name">Draco1214</a> |
Posted 10/6/2006 8:15:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339219490">message detail</a>
 | #173</td></tr>
<tr class="even"><td>
HM, Moltar, and yo have Ganon.<br>Ulti, KH, and Lopen have Vincent.<br><br>It's up to the guest to decide the split.<br>---<br>Character Battle V Score - <i>23/24 points</i><br>Current Prediction - <b>Sonic the Hedgehog</b> vs. CATS
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/6/2006 8:16:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339219560">message detail</a>
 | #174</td></tr>
<tr class="even"><td>
I'm forgetting someone on the crew then.. oh well, no reason to give it away, let's see what they've got.<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/6/2006 8:16:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339219613">message detail</a>
 | #175</td></tr>
<tr class="even"><td>
ha, I forgot Moltar. go me!<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/6/2006 8:17:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339219857">message detail</a>
 | #176</td></tr>
<tr class="even"><td>
I'm interested to see which way the 4-3 falls.....would I make it a nice 5-3 advantage, or an interesting 4-4 tie?<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/6/2006 8:18:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339220149">message detail</a>
 | #177</td></tr>
<tr class="even"><td>
<b>Blast Division:</b> <i>Round 1 - Match 26</i> &#8211; (4)Ganondorf vs. (5)Vincent Valentine<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Ganondorf</b><br>Game/Series Known From: Legend of Zelda <br>Extrapolated Rank in 2003: 11th (34.72%) <br>Extrapolated Rank in 2004: 54th (12.10%) - Adjusted Value: 10th (32.38%)<br>Extrapolated Rank in 2005: 25th (25.69%) - Adjusted Value: 15th (30.83%)<br>Seed in 2003: 12<br>Seed in 2004: 8<br>Seed in 2005: 3<br>Lost in 2003 to Magus in Round 2<br>Lost in 2004 to Link in Round 2<br>Lost in 2005 to Samus in Round 3<br><br>The King of Evil makes his triumphant return!<br><br><b>Vincent</b><br>Game/Series Known From: Final Fantasy <br>Extrapolated Rank in 2005: 10th (32.60%)<br>Seed in 2005: 5<br>Lost in 2005 to Crono in the Elite 8<br><br>The star of 2005 also is back!<br><br>darn
you cjay. This is just too good for Round 1. Two top 15 characters
(heck, we could go even higher) are going at it right here. With the
match nearly split, and good points for both sides, this one could be
one for the books.<br><br>I&#8217;d rather not get into 2003 and 2004, so
that should shave off the word count by a good amount. Instead, let&#8217;s
jump right to the last Contest, and look at some things with this
Contest. <br><br>First off, Ganondorf. In 2005, he made his way past
Yuna in Round 1 with 61%. Now, that didn&#8217;t seem all that hot back then,
but Yuna looked very good in her match against Roll. Almost <i>too</i>
good. Moving on, next was Auron, whom Ganondorf beat with 54% in his
most impressive victory yet. Another FFX character had fallen. Now,
Auron&#8217;s Round 1 opponent? Big Boss. We saw The Boss in this Contest
easily beat Celes. I&#8217;d guess she&#8217;s around Terra&#8217;s level, which puts The
Boss over Big Boss. Does that mean anything? I dunno, but it&#8217;s food for
thought. Then Ganondorf potentially gets SFFed by Samus, who gets SFFed
by Mario. Does that mean Ganon, Auron and Yuna were all underrated?
Yuna looked to be, so Ganon may be as well. And don&#8217;t give me anything
about how unholy it is to have Yuna anywhere near Tidus. I wouldn&#8217;t be
surprised if Yuna was indirectly equal to or a little stronger than
Tidus. He just looks worse every year.<br><br>Vincent does have a bit
of breathing room though, as he is a bit above Ganon&#8217;s adjusted number.
In 2005, he smashed Kerrigan, but that doesn&#8217;t tell us much. He then
beat Dante with 54%. Not as impressive as 54% on Auron in my opinion
(as I know that some think otherwise), but let&#8217;s not get into that.
Then he goes toe-to-toe with Squall, who smashed Tidus&#8217;s face into the
ground. Finally, he bows out to Crono with 45% of the vote. Did I buy
Vincent&#8217;s value back then? Nah, I thought he was overrated. Now though?
With DoC and AC on his side, his 2005 value may be legit (2006 Squall
and Dante don&#8217;t disagree), and he might be even stronger! <br><br>So,
then we come to this match. A few Ganon supporters (who will remain
nameless), banked on Twilight Princess to perhaps bring Ganon up to
beat Vincent&#8230;and then some. Well, TP isn&#8217;t coming out before the match,
so Ganon lost his Free Pass to Round 2. Still, I wouldn&#8217;t say he&#8217;s out
yet.<br><br>Vincent may be the statistical favorite going in, but
Ganondorf is underrated. He&#8217;s behind double-SFF (that&#8217;s right, a
minimal amount against Samus, and no clue on how much Mario got on
Samus), so we don&#8217;t have a good read on him. Vincent may also be
overrated, but as I said before, it is unlikely now.<br><br>Another
factor, and probably the biggest thing Ganondorf has going for him, is
the Nintendo voter shift that has taken place since 2005. While FF7 is
the most popular game, Legend of Zelda is the most popular series, and
as we saw with Zelda in action earlier, and breaking 100K votes on her
opponent, I think the love for the series is helping the characters
out. Zelda isn&#8217;t that strong on her own, it&#8217;s the LoZ fanbase backing
her. Will they back Ganon? They sure did against Auron and Sephiroth,
and I don&#8217;t see why they wouldn&#8217;t here.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/6/2006 8:19:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339220269">message detail</a>
 | #178</td></tr>
<tr class="even"><td>If it seems like I&#8217;m &#8220;defending Ganondorf&#8221; here,
it&#8217;s because I kind of...am. I do have him winning this match, and he
is my favorite character. But hey, this&#8217;ll probably be the most
un-biased write-up (at least compared to the others)! I feel that since
Vincent may seem stronger, I have to show why I think Ganondorf will
pull through. In a big match like this, you have to look at everything.
Bracket voting (favoring Ganon I&#8217;d guess), Day the match takes place
(Saturday, which equals high vote totals), Picture (No biases for
either). This probably won&#8217;t end up that close when it&#8217;s all done, but
for now? Yeah, it&#8217;s tough. Ganondorf by a hair. This match is either
going to answer a ton of questions about Ganon&#8217;s and Vincent&#8217;s true
strengths and the Devil Divison, or raise a lot more.<br><br><b>Moltar&#8217;s Bracket Says:</b> Ganondorf will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Ganondorf: 52% - Vincent: 48%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br><br><i>I was bored:<br><br>Auron scored 45.95 on Ganondorf. Dante scored 45.99% on Vincent.<br><br>33.02%
; that's Auron's BL value if you take his 2005 match with Ganondorf and
plug him into the Villain Contest. Dante's BL value from last summer is
32.73%.<br><br>(32.73 / 33.02) * 50 = 49.56% is what Dante supposedly
scores on Auron, but these two are only even if you assume the
villain's contest is accurate.<br><br>Basically, Ganondorf being
favored against Vincent is based off of warped stats from when everyone
thought Magus 2003 was legit, and a villain's contest in which
Sephiroth was anti-voted to hell and back in the last two rounds. Is
Ganon really that close to Mario of his own accord?<br><br>If Ganon is
overrated at ALL by our stats (and he is; none of the high readings we
have on him are valid), Vincent might win that match in an easier
fashion that people expect. Vincent might be overrated a bit due to FF7
&gt; CT SFF, but if he pulled 44.62% on Crono due to Advent Children
then his value is kind of accurate by accident. And he's had his own
game since last year. And he might even see some KH2F go his way.<br><br>Barring
NintendoFAQs showing its muscle again (a real possibility, of course),
I really think Vincent might be due to surprise some people in a couple
of weeks.<br><br>~*ST*~</i><br><br>Since posting that, Dante has kind
of gone out and helped prove Vincent NOT being overrated. I seriously
think it'll take some warped NintendoFAQs crap and bracket voting if
Ganon wants to have his ass saved here. What's sad is that it may
actually happen.<br><br>Prediction: Vincent with 51.49%<br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br><i>Do you realize who you are dealing with?! I am Ganondorf!</i> <br><br>We <i>finally</i> arrive at <i>the</i>
match of the first round! The two titans collide &#8211; the King of Evil
against the King of Depression! There has been much debate about this
match-up and most people have clearly taken their sides here. Both of
them stand an equally good chance of winning and have different things
going for them &#8211; but only one is <i>really</i> to be favored here! <br><br>If
it were not readily apparent by now, everyone should be aware of the
voter shift we have seen here toward Nintendo. Since the last contest,
I feel some of that <i>continued</i> with the large jump in DS
ownership and the amazing presence Nintendo at E3 &#8211; Wii is the most
anticipated thing here at GameFAQs right now. Obviously, Ganon benefits
heavily from this.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/6/2006 8:19:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339220423">message detail</a>
 | #179</td></tr>
<tr class="even"><td>
In more contest related performances, we have seen The Legend of Zelda basically <i>plow</i>
right through everything in the Series Contest. It did the unthinkable
among board members by beating Final Fantasy. If it wasn&#8217;t clear before
that there was a clear shift toward Nintendo in the past couple of
years, it was <i>now</i>. As for this contest, Zelda has come out looking very strong by not only scoring the biggest blowout of the contest (85%), but <i>also</i>
scoring the most individual votes of any contestant (101,000). That is
extremely impressive no matter how you slice it, especially since Zelda
is the only character to ever break the 100,000 individual vote
barrier. On the other side of the spectrum, <i>Tingle</i> managed to put up an impressive 25% against a KH2 boosted Sora. <i>Tingle</i> of all characters &#8211; he&#8217;s hardly the most liked character in the world despite how he should be<i>!!</i> -- managed to avoid a tripling to a strong character.  <br><br>I
think the signs are definitely there that Zelda is still an extremely
dominant force in these contests. It&#8217;s reassuring to know that the
Zelda franchise isn&#8217;t slipping up this year. <br><br>Now, for
something more Ganon specific, we can look at his previous match-ups.
Ganon in his long contest history has had the luxury of facing <i>tons</i> of Square characters, most of which he has beaten. In 2003, he beat Tidus and <i>barely</i> lost to Magus during the &#8220;Year of Square.&#8221; In the Villain Contest, he beat Ansem and got 41% on <i>Sephiroth</i>.
In 2005, he beat Yuna with 60%+ and beat Auron with 54%. That&#8217;s a
rather impressive history against Square characters. He has never lost
to a Final Fantasy, in fact, with less than 40% of the vote. Vincent is
likely to be stronger than any non-Sephiroth FF character, so this
match has a bit more challenge to it, but Ganon&#8217;s clearly capable of
pulling it out without a lot of trouble. <br><br>A lot of people will
cite Dirge of Cerberus and Advent Children as reasons for why Vincent
will be able to clear the hurdle and beat Ganon. I think some need to
remember that despite this being Vincent, he&#8217;s <i>still</i> up against the main villain of the <i>Zelda</i> series. But, back to the point, Dirge of Cerberus puts him in the &#8220;main role&#8221; of a game&#8230;but it&#8217;s a <i>really</i>
crappy game and it didn&#8217;t sell well &#8211; 200,000 copies in America during
its first month. I doubt this will amount to very much at all &#8211; and if
the Devil Division was overrated in 2005 then this will only help him
get back to his previous level &#8211; and Advent Children <i>probably</i> won&#8217;t do much either. Considering Vincent&#8217;s role, it&#8217;s unlikely that he got any <i>new</i> fans or pre-existing fans to like him <i>more</i> as a result. I doubt his boost is much more than a percentage point or two at this point. <br><br>If you look at this from a statistical standpoint, this doesn&#8217;t <i>seem</i> like a match that should be receiving <i>that</i>
much attention. There is a bit of a gap between Vincent and Ganon and
then we can factor in Vincent&#8217;s new stuff and there you go&#8230;but that
would be taking the faulty stats <i>way</i> too seriously. Despite how
there wasn&#8217;t tons of SFF matches in 2005, the stats are still off base
on a lot of things. Ganon&#8217;s actual value in 2005 should be <i>at least</i>
two percent higher, which puts him slightly ahead of Vincent. There is
also the possibility that the Devil Division was overrated in 2005 and
that Vincent&#8217;s value is not the one he was given. If you lower that by
2%, <i>then</i> factor in his new stuff, you get him right back around
where he was before. Ganon by all means should be underrated heavily by
those stats &#8211; I think he is actually at or around Bowser in 2005. That
gives him a pretty clear advantage, Devil Division overrated or not.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/6/2006 8:20:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339220557">message detail</a>
 | #180</td></tr>
<tr class="even"><td>
I&#8217;m not going to examine <i>all</i> the
possibilities here, but I will just say that Ganon should be much
higher than the stats indicate, which end up justifying this debated
match. What we have here is a match of the titans, two near-elite
characters on the edge of the Noble Nine with every reason to move onto
the next round. In the end, I think Ganon is going to get by Vincent
without <i>too</i> much of a problem. He is the main villain of The
Legend of Zelda, he has the benefit of a possible continued Nintendo
increase, he&#8217;s got Twilight Princess right around the corner, and Zelda
has just been too impressive lately to ignore. Ganon should get out of
this one with enough to turn heads and have people sweating about the
match with Sonic in the next round. <i>That&#8217;s just how the KING OF EVIL ROLLS!</i> <br><br><i>Now! Let us put an end to that which binds us together!</i> <br><br><b>Aitch Emm&#8217;s Bracket:</b> Ganondorf<br><br><b>Aitch Emm&#8217;s Prediction:</b> Ganondorf &#8211; 53.5% ; Vincent &#8211; 46.5%<br><br><b>Aitch Emm&#8217;s Vote:</b> GANONDORF<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>The first round match everyone has been waiting for is finally here. Such a shame I'm experiencing massive writer's block, huh?<br><br>Vincent
looks good. He won three matches in his contest debut, and if memory
serves me correctly, he and Diablo are the only contest newcomers
(entrants who debuted in 2003 or later) to accomplish such an
impressive feat. Of course, Vincent's opposition was far more powerful
than Diablo's. A 54% win over Dante followed by a respectable 44.6%
loss to Crono pretty much cements your status as a power player. This
year, he's looking to come into this contest even stronger. He has
Advent Children, Dirge of Cerberus (his only starring role ever) and
possibly some Square fan influx from Kingdom Hearts II. Seriously, why
the hell would anyone take this guy to lose in Round 1?<br><br>Because
his opponent is from The Legend of Zelda. Does anyone want to argue how
absolutely on fire this series is right now? After its incredible run
through the series contest, Zelda's ridiculous win days ago, and the
hype for Twilight Princess, I hope the answer is no. And that's a good
thing, because Ganondorf will need a lot of this power to defeat
Vincent. Would he have beaten Vincent last year? Personally, I still
think so. A lot of people like talking about character's losses (the
matches that will end up indicating their stats standings). Personally,
since both Vincent and Ganondorf's losses are suspect to SFF
(especially Ganon's), I prefer to look at their wins. Vincent put up
54% on Dante and Ganon put up 54% on Auron. Nice and simple; all we
have to figure out is which one is stronger. So, who wins in 2005 -
Dante or Auron? I'm not saying it isn't debatable, but my money would
definitely be on Auron.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/6/2006 8:21:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339220662">message detail</a>
 | #181</td></tr>
<tr class="even"><td>However, this isn't 2005, and Ganondorf probably
won't have enough in the tank to win if he's stayed static. Fortunately
for him, I don't think that's the case. Yes, we've all heard the
arguments before. Nintendo is stronger this year. The DS has put up
some terrific sales. The anticipation for Wii has completely
overshadowed the PS3 since May. Blah blah blah. Even with these big
changes since last year, some people don't see it as enough for the
villain. Well, I know something they don't. I know something that, for
some reason, is hardly mentioned around these parts. Yes, <b>I know something</b>,
and it's the reason for Ganondorf's soon-to-be-victory. It's called The
Legend of Zelda:Twilight Princess. I have no idea why, but it seems
most of this board is very ignorant to the sheer hype Twilight Princess
has going for it on GameFAQs right now. This site wants Twilight
Princess. This site needs Twilight Princess. If given the chance, there
is no doubt in my mind that the entirety of GameFAQs would stomp on the
heads of six or seven hundred small children to obtain Twilight
Princess. There is a hunger for it. There is a pulse for it. It is,
without a shadow of a doubt, the most anticipated release since these
contests began, and it's almost here.<br><br>Welcome to ZeldaFAQs, ladies and gentlemen. gg Mr. Valentine<br><br>My prediction: Ganondorf def. Vincent Valentine (53-47)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Most debated match yet? Yeah, I'd say so. Let's look at what the two did last year, shall we? Well, let's not look at <i>everything</i>.
Let's just look at the second round, okay? We've got ~46% on Auron vs.
~46% on Dante. The match pretty much boils down to which do you think
was more of a competitor last year, Auron or Dante?<br><br>Me? Well,
I'm thinking&#8230; well, you know who I'm thinking! Dante would totally beat
Auron last year! Really! Okay, I bet you'd like some justification. How
about this? Dante and Auron got comparative numbers on Terra and Big
Boss last year. Who would I take in that match? Well, I don't think
she'd win by <i>that much</i>, but I'd have to take Terra. Big Boss is
a Metal Gear footnote, weakest MGS entry we've seen by far I'd say. He
might get some votes from MGS3, but even that I'd call a shaky base.
For reasons involving mooching I won't get into for the sake of
spoilers.<br><br>Anyway, let's forget about Dante and Auron for a
minute, I'm clearly biased in that matter anyway. How about Samus and
Crono? Samus smashed him 60-40, Crono only 56-44ed Vincent. Samus got
smashed 60-40 by Mario, Crono lost 53-47. You want to say there was
SFF? Go ahead, I won't argue with it, Something Fishy probably did go
down&#8230; but there really isn't any <i>100%</i> guarantee. And, in either case I don't buy it being enough to make the two look equal even through <i>the wonders of extrapolation!</i><br><br>Oh,
and what about Dirge of Cerberus (okay, a flop) and Advent Children
(okay, a movie)? I doubt these will make Vincent more popular by leaps
and bounds, but they'll be more than enough to counter any <i>Twilight Princess hype.</i><br><br>Oh, and by the way, when I'm right about this one, you'd better believe it means Dante would trump that Ganondorf fool! (<i>Don't get too cocky,</i> Lopen! Hey, you&#8230; shaddap!)<br><br><b>Lopen's prediction:</b> Vincent with 54.80%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>GANONDORF</b><br> <br><i>"See how much your precious Triforce is worth!"</i><br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 11th Place [33.60%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 10th Place [32.38%]<br><br>Spring 2005 Contest<br>Extrapolated Strength --- 2nd Place [41.83%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 15th Place [30.83%]<br><br>Man,
just looking back on those values...is there any character who has been
as overrated as Ganondorf has? Even when he gains, he just gets more
overrated to compensate for it (see Villains Contest).
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/6/2006 8:21:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339220784">message detail</a>
 | #182</td></tr>
<tr class="even"><td>I'm sorry, I'm getting off on the wrong foot. Er,
Ganon supporters may want to look away, be duly warned here. I say this
because I used to be one of you.<br><br>Ganondorf
is one of those characters I used to expect big things from -- BIG
THINGS. After seeing what Sephiroth could do as compared to Cloud,
Ganondorf seemed primed to take that position for Link. In 2003, if he
had been on the other side of the bracket, I would have taken him to
the finals. <i>The finals.</i> Instead I could 'only' take him to Link
-- and he couldn't even do that! Ganondorf ended up losing to Magus in
a poll that I was ABSOLUTELY SURE was rigged -- after all, how could
the great Ganondorf lose to some no-name from Chrono Trigger?<br><br>(um you're talking to a guy who had Simon Belmont &gt; Crono in 2k2 so bear with me)<br><br>In
2004 he met my expectations, though the way it was set up made it
almost impossible for the Dorf to lose out on that one. He lost to
Link, and lost hard -- but I thought nothing of it.<br><br>And in 2005
it was just more of the same for me and Ganon. I nearly took the man
over Samus in the Summer, I nearly took him over <i>Sephiroth</i> in the Villains Contest.<br><br>And yet now, here I am, standing against him. What has changed?<br><br>Frankly, my dear -- <i>everything</i> has.<br> <br> <b>VINCENT VALENTINE</b><br> <br><i>"Guess I have no choice. It's time...to save the world."</i><br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 11th Place [32.60%]<br><br>I think I should start with saying that the fact that Vincent's insanely long bio was written by Heroic Mario is pure comedy.<br><br>My
former personal favorite Final Fantasy character (well, tied with
Squall), Vincent's history in the contests for me is very opposed to
Ganondorf's. I never expected much from Vincent when I first saw him in
the bracket -- sure, I took him over Kerrigan like every sane person
did, but that was about it. I was under the impression that Dante would
just be too much for him. To my surprise and delight (though perhaps
not my bracket's), Vincent would go on to clinch the Devil Division
championship and reach the Elite Eight.<br><br>Vincent is also a
character that has had many arguments made for overrating him -- heck,
just looking at that rank and X-Stat placing makes me want to take back
half the stuff I said about Ganondorf. Just like Ganon he's hard as
hell to place, a total ***** to gauge, and to make matters worse he's
got the total question mark of his own game, Dirge of Cerberus.<br><br>Fun.<br><br><i>Notable Releases Since Last Appearance</i><br><br>Ganondorf: N/A<br>Vincent Valentine: Advent Children (Film), Dirge of Cerberus (PS2)<br><br><i>Upcoming Releases</i><br><br>Ganondorf: Twilight Princess (WII)<br>Vincent Valentine: N/A<br><br>Match
of the round right here, folks! It's massively anticipated. It's
massively hyped. It's entailed ooodles of debate for a year and some,
and it's all culminating right here!<br><br>So, like every supremely
hyped match since Mario/Cloud, we're almost certainly going to get a
fizzle that ends in an anticlimactic boring win that leaves everyone
wanting more.<br><br>This is probably the thing that has me leaning toward Ganondorf the most. No, wait, that's not it -- it's because he's <i>Nintendo</i>, because he's <i>ZELDA.</i>
Y'know, super-strong, nigh-unbeatable,
kinda-obnoxiously-overrated-but-still-getting-it-on-GC-launch-day
Zelda! And when you're Nintendo, when you're Zelda, you have a habit of
turning debated matches into fizzles -- Ganondorf did this exact thing
with Auron a year ago, and many would say he's primed to do it again.
The same reasons for him being overrated existed back then as well,
too, and Auron still lost hard.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/6/2006 8:22:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339220923">message detail</a>
 | #183</td></tr>
<tr class="even"><td>I refuse to call the Nintendo character anything
but a favorite in any match against a non-Noble Nine character
(provided it isn't something stupid like Tingle &gt; Sora). That's
gonna make me give this favorite status to Ganondorf. You put a gun to
my head and ask me who's gonna win -- I'm saying him.<br><br>Karma Hunter's Vote: Vincent F'ing Valentine.<br><br>Favorite Prediction: Ganondorf with 51.44%<br> <br>Yawn.<br><br><b>Upset Potential: 45%<br><br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br> <br>Now -- who's ready for some ANALYSIS???<br><br>Truth
be told, if Vincent is where the 2k5 stats say he is and if Ganondorf
isn't on Snake's level, Vincent wins. Simple as that. Now, the doubt
there sort of plays into this whole ambiguity concerning this match --
but after seeing this round play out, I've become a hell of a lot more
confident here.<br><br>Vincent's prospects depend on him not overrating
the Devil Division thanks to the AC leak and whatnot. Dante and Squall
have done their <i>damndest</i> to exceed all expectations and beat
their first round opponents to holy hell. Sure, you can argue KH2 and
SFF for Squall, and I know *I* was arguing SFF for Dante (no, I don't
buy DMC3 continuing to sell well for jack). But they certainly don't
look like they've lost a step, not one bit. The advantage goes to
Vincent on that.<br><br>Meanwhile, I want you to look at today's match.
From the time of writing, and assuming a static Sonic and that CATS
doesn't get the day vote, Ganondorf's not exactly looking like he's hot
stuff. Now sure, you may want to argue that Hybrid CATS is different
from Face CATS, but by this much? If anything, I don't think Ganondorf
-- at least the one we saw last year -- is capable of hanging with
Sonic. The match that he had with Diablo also lends itself to this, and
does so much more concretely. I just like using CATS 'cuz he's funny.
Um... &lt;_&lt;<br><br>Ganondorf also has that not-so-great performance
on Yuna. I'm sorry, but try as I may, I can't really see Yuna competing
with Tidus. I'll give him the edge no matter what -- and it's even
worse for him considering Kirby may have overperformed on Bowser,
making Tidus even WEAKER. Even giving Ganondorf the percentage he got
on Yuna on Tidus 2k4...well, that <i>still</i> puts him under Vincent. OUCH.<br><br>Hey,
I'll give credit where credit is due. Ganondorf beat Auron (in a match
that I'm actually upset about, in retrospect). Vincent's run was nice,
but he never really got to test himself against a good Ninty character.
If he had beat the hell out of, say, Zelda -- I'd be a lot more
comfortable with him. In fact, to me everything here depends on
Vincent. He's such a big wildcard to me. He SHOULD have this match, by
almost every stretch of the imagination. Even if DoC does something
like 1%, it should merely be a clincher for him.<br><br>But he's untested. And worse, he's untested <i>Square.</i>
I'd be more comfortable with Squall or Auron right now. And sure, he's
in a one point match -- but at this point, I think I'd trade the prizes
just for bragging rights over HM.<br><br>And finally...<br><br><b><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2499" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2499">http://www.gamefaqs.com/poll/index.html?poll=2499</a></b><br><br>Samus can't SFF a Speck of Dust, G-dorf. Go to hell.<br><br>That's right! YOU HEARD ME, OH FOLLOWERS OF STATS IN A INTERNET POLL CONTEST!!!<br><br>Ganondorf will go no farther! The King of Evil's reign ends here, and it ends <i>tonight!</i>
No longer will the tyranny of sub-par villainy rule over these lands!
Vincent Valentine shall break the bonds that hold this contest in the
jaws mundane predictability!<br><br>And this will only be the
beginning!!! Aeris will defeat Zelda. Cloud will cap off a second
unprecedented upset over Link. And then Solid Snake will randomly take
the whole thing for good measure. Balance will be brought to the
contest Force, once and for all.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/6/2006 8:23:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339221235">message detail</a>
 | #184</td></tr>
<tr class="even"><td>Do you hear me, Ganon?! This is it for you -- show
me your Twilight, and I shall show you the Road to Dawn! Not one more
step, not one more match, not one more <i>vote!</i><br><br>IT<br><br><b>ENDS</b><br><br><b><i>HERE!!!</i></b><br><br><b>Karma Hunter's Krazy Prediction: Vincent Valentine with 53.34% of the vote.</b><br><br><br><br><b>Guest&#8217;s Analysis</b> - <i>SilverNightmareX7</i><br><br><br>First,
my own special tribute to the characters of whom both Ganon and Vincent
could have easily broken 60% on seeded above them:<br> <br>#3 Riku<br>#4 Phoenix Wright (rofl goodbye GFNW)<br>#3 Kratos (lol roflz first round loser of 2005CB gets an upper seed?)<br>#3 Kirby (I know, Ganon had a shot at Kirby earlier, but Kirby has gotten weaker, Ganon has gotten stronger)<br>#2 Luigi<br>#2 Master Chief (I am pulling for Sub-Zero so badly.....)<br>#1 Sora (is lucky he didnt face CATS in round 1)<br> <br>There
are 26 characters in the male bracket who are not members of the noble
nine or Vincent/Ganon. And I would guess about 24 of those 26 would
never stand a real chance at beating these two. While the Noble Nine
may never be broken, Vincent, Ganon, Bowser have proven themselves as
the best of the rest as far as male characters go. Squall is probably
the only character outside of these three that could ever possibly hope
to beat them on the male side of the bracket. But Squall wont get his
chance to prove himself this year, unless he cracks the noble nine
himself. Maybe next year. Everyone below Squall, is fodder, and stand
no chance at surviving a match against a character in the Noble Nine
nor the best of the rest. It is a tragedy two serious contenders are
going at it in the first round, and this really does feel like it would
have been a great quarterfinal match......<br> <br>That being said,
nothing can change that this year and hopefully no one else will ever
have to analyze this match ever again in the first round.<br> <br>Ganondorf<br> <br>Ganon
easily has one of the more odd looking contest histories going by
win/loss percentages. He opened his career in 2003 by narrowly edging
Tidus, then losing to an over-hyped Magus in a race just as close. In
2004 he beat Alucard with a 57%, and then got absolutely CRUSHED by
Link in the second round, pulling only 12% of the vote. Never before
had SFF been so prominent. But with his results from those two
contests, it was pretty obvious where Ganon stood. As a relatively
average mid-card character. Enter Spring 2005. Ganon runs over the
competition to face THE Sephiroth in the finals, and pulls almost 42%.
Bowser also performed well against Sephiroth getting just over 40%. A
lot of people took it as being one of two things. Either Sephiroth was
greatly weakening, or Ganon/Bowser had a steep rise in power. SC2k5
didnt do much to prove either theory. Sephiroth proceeded to crush
Mario and lose in respectable fashion to Link. Ganon did very average,
beating Auron with a less than flattering 54% before getting beaten
relatively soundly by Samus. Bowser on the other hand, was within .6%
of taking down Solid Snake. My own theory is that because the
competition of the Spring 2005 contest was so weak, it made Sephiroth
himself weaker within that specific tournament. That and Snake just
doesnt have the power he used to. I could easily see Ganon or Vince
taking him down. If its one thing that Ganon has shown consistency at,
its he can win close matches against mediocre opposition, and goes down
with a quickness when the going gets tough. Unfortunately, someone who
pulls 45% on Crono in their contest debut, isnt someone whom many would
consider to be mediocre opposition. But does that make Vincent tough
enough?
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/6/2006 8:25:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339221564">message detail</a>
 | #185</td></tr>
<tr class="even"><td>
Vincent Valentine<br> <br>Vincent screwed over
many a bracket last year. A mere 12.7% had him as their Devil Division
Champion. I was one of them =P For many, it was hard to determine what
Vincent would be able to do. Some people had him losing to Sarah
Kerrigan in the opening round and only 25% of Gamefaqs had him pinned
to beat Dante in the second round. For those of us 12.7% who knew damn
well Vincent was going to the Quarterfinals, here is how that judgment
was made:<br> <br>Vincent is easily debatable as the second or third
coolest character in FFVII. Maybe even the coolest. Square-Enix
realized this themselves and gave him his own game, as well as making
him one of the more visible characters within FFVII:AC. He even got
into Ehrgeiz. Being it was his first contest however, I had to put him
as being about as strong as Aeris, perhaps even a little bit stronger.
Whom would have won Vincent's 8-pack before losing to Crono
respectably. Sure enough, thats what happened.<br> <br>IMHO Vincent
comes into this tournament a little stronger than last tournament. A
lot of people were unsure of where he stood last year and first timers
tend to underperform against stronger mid-card characters. (just look
at Ganon in 2003.... rofl Kirby 52% lolz) He has gotten a lot more
visibility with his game and with actual release of FFVII:AC in english
on DVD/PSP.<br> <br>The Prediction...<br> <br>So what about this year?
Ganon comes in about as over-rated as Magus was last year (and I called
Knux beating him). Even with a win here, I dont see Ganon as being
capable of pulling off a win against Sonic. When the competition gets
tough, Ganon phails. Vincent, is the brackets best shot at cracking the
Noble Nine. Ganon has what it takes to make this match a lot closer
than it should be, and I would not be shocked to see the match end with
Vincent winning by only a .5%~ margin, but many would agree with this
statement:<br> <br>Vincent is almost as cool/as cool/cooler than Sephiroth/Cloud.<br> <br>You cant in any way even try to say that about Ganon to Link or even Zelda while holding a straight face.<br> <br>As stand alone characters taken out of their games, Vincent is simply a lot cooler and more intriguing than Ganon.<br> <br>And that is why, Vincent emerges with a 53.17% win.<br> <br> <br> <br>Crew
Consensus: We got a split folks, 4 for Vincent, 3 for Ganondorf. It's
LoZ vs. FF, the match of Round 1. Good arguments on both sides, and the
only thing we can do now is wait...
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/6/2006 8:25:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339221636">message detail</a>
 | #186</td></tr>
<tr class="even"><td>
Win. Time to start reading.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3685859" class="name">PartOfYourWorld</a> |
Posted 10/6/2006 8:26:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339221903">message detail</a>
 | #187</td></tr>
<tr class="even"><td>
Holy **** @ Heroic Mario getting pwned in write-up girth. YOU GONNA TAKE THAT, HM?!?!?!?!?
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/6/2006 8:27:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339222117">message detail</a>
 | #188</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Here it is, the first really
big, completely disputed match of the contest....Ganondorf vs. Vincent!
Ignoring the 3 and a half beers that are in me at the moment, I must
give my quick input.<br><br>I'd like to think that Vincent has been
totally overrated after only participating in just the last character
contest. But then again, he <i>is</i> from Final Fantasy VII, so that
alone would give him great strength. But is it really enough? I mean, I
doubt I'd pick someone like Aeris to beat Ganondorf. Uh oh, I'm having
second thoughts now about this match......so it's time to just get this
over with.....<br><br>This is basically LoZ vs. FFVII, and that's
scary. You would think that Ganondorf would certainly be stronger than
Vincent, but you never know, and that's what makes this match so
interesting. I really don't know why I picked who I did....I guess it
was just an instinctual pick, and that's why I made it.....then again,
Phoenix Wright was an instinctual pick with no real logic to back it
up.......<br><br>My vote: Ganondorf<br>My bracket: Vincent<br>My
prediction: Yeah, so I was all ready to pronounce Vincent the winner in
this match, but now I have my doubts. Bah, I can't back down. Vincent
with 50.13%!<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/6/2006 8:27:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339222131">message detail</a>
 | #189</td></tr>
<tr class="even"><td>
good, good, good show. now I'm actually upset I'm going out on a friday night. WHAT IS WRONG WITH ME<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/6/2006 8:29:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339222617">message detail</a>
 | #190</td></tr>
<tr class="even"><td>
Wow, I'm definitely gonna have to read these.....too bad I'll have to
wait until the match has already started, because I've had too much to
drink at the moment.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/6/2006 8:35:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339223993">message detail</a>
 | #191</td></tr>
<tr class="even"><td>
screw this<br><br><i>tranny's analysis</i><br><br>as
a few people mentioned, each opponent scored the same percentage on
Dante and Auron respectively. to me, that's what the match comes down
to - who was stronger in 2k5, Dante or Auron?<br><br>my answer is
Auron. we've never had a good read on him, but that doesn't change the
fact that he obviously has some strength here. Auron &gt; Ganon was a
pretty popular upset pick last year despite what Ganondorf put on
Sephiroth in the Villain Contest. Auron is at <i>least</i> worth 30% on Base Link, and quite possibly a little bit higher. <br><br>Vincent
was the Starcraft of 2k5. I underestimated the hell out of him and he's
only looking stronger this year - Advent Children US release, his own
game and a possible Square voter influx thanks to Kingdom Hearts 2. is
this enough to make up the difference between Auron 2k5 and Dante?<br><br>I
don't think so. I don't think AC is worth much at all and while DOC
will make a difference, not enough people have played it to really make
a significant difference. plus it apparently sucked. on the other hand,
this site is <i>silly</i> about Zelda right now, to the point that
half the site considers the Wii release date the most anticipated day
of the year. there's a good reason for that - Twilight Princess. this
match is dead-even to me without that, but those hyped voters will put
Ganondorf over the edge.<br><br>my vote: Ganondorf (not because I like him, I just like Vincent less)<br>my bracket: Ganondorf<br>my prediction: Ganondorf with 52.22%<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=316393" class="name">Tediz247</a> |
Posted 10/6/2006 8:37:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339224405">message detail</a>
 | #192</td></tr>
<tr class="even"><td>
Ulti's analyses have seemed so weak ever since Halo/Starcraft, but
that's probably because that was one of the best things ever written by
anyone. I keep hoping for one to top it, but it hasn't come yet. Maybe
for Snake/Mega Man &gt;_&gt;<br>---<br><i>That... was her final mission. And like a true soldier, she saw it through to the end.</i><br><b>ZSB [aX]</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/6/2006 8:38:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339224600">message detail</a>
 | #193</td></tr>
<tr class="even"><td>
I wouldn't be surprised in the least bit if Ganondorf won this match,
despite my picking Vincent. At least my unexcusable PW pick ruining my
perfect makes me not care as much about the outcome of this match.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=834874" class="name">MarkSmith</a> |
Posted 10/6/2006 8:55:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339228156">message detail</a>
 | #194</td></tr>
<tr class="even"><td>
Ulti's Halo-Starvraft analysis was good because it told us something
new. We all already kn ow how to analyze the x-stats from every angle.
His call on battlenet rallying though was very accurate.<br>---<br>PROUDEST MEMBER OF THE FIGHTIN' TEXAS AGGIE CLASS OF 2010<br>Next game: who cares? Fire Fran!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=1313568" class="name">Jmast7</a> |
Posted 10/6/2006 9:02:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339229649">message detail</a>
 | #195</td></tr>
<tr class="even"><td>
Yoblazer, that was awesome. Simply awesome. =)<br>---<br>"I've
tried 'em all, I really have, and the only church that truly feeds the
soul, day in, day out, is the Church of Baseball." - Annie Savoy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=254355" class="name">Lugia2</a> |
Posted 10/6/2006 9:07:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339230658">message detail</a>
 | #196</td></tr>
<tr class="even"><td>Dear lord, no one can predict this match. Well,
except HM and Ulti, who are the only ones positively certain about the
outcome. And are at opposite ends to boot. Looks like we'll find out
what happens tomorrow.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3623587" class="name">Gaddswell</a> |
Posted 10/6/2006 11:21:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339257890">message detail</a>
 | #197</td></tr>
<tr class="even"><td>
Wow, that's some wall that everyone's put up. Even DP and Tranny put up
nice walls and they're not even part of the crew! Too bad not every
match is like this one.<br>---<br>By the time we localize the programs, kids don&#8217;t even know they&#8217;re from Japan any more. - 4Kids CEO Al Kahn
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=795464" class="name">Tatl</a> |
Posted 10/7/2006 12:03:51 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339265631">message detail</a>
 | #198</td></tr>
<tr class="even"><td>
It's matches like these that make me mad.<br><br>I have to work tomorrow until after midnight (central)...<br><br>By the time I get home, this match will have ended and I won't get to watch the last update reveil itself.<br><br>Why are all the good matches on days I can't watch them...<br>---<br>"I reject your reality and substitute my own." ~ Adam Savage; Insanity Personified<br>"Crikey!" ~ Steve Irwin (R.I.P.); Perfection Personified
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 10/7/2006 12:59:45 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339273587">message detail</a>
 | #199</td></tr>
<tr class="even"><td>
Tediz, do not test me. I'm lazy and that's all.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), Castlevania: LoI
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/7/2006 1:29:55 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=339277415">message detail</a>
 | #200</td></tr>
<tr class="even"><td>
If possible, and since no one seems to be calling dibs on second round matches, can I get Squall/Snake?
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=2">3</a></li>
<li>4</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=9">10</a></li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage4_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30854544&amp;page=3" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage4_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>