<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage9_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage9_files/nogs.css"></head><body linkifytime="180" linkified="2" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage9_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/afterhours/">After Hours</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage9_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D30854544%26page%3D8"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><img src="genmessage9_files/c.gif" height="1" width="1"><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage9_files/advertisement.gif" alt="advertisement" height="10" width="120"></div>
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage9_files/2006.htm" marginheight="0" marginwidth="0" topmargin="0" leftmargin="0" allowtransparency="true" frameborder="0" height="90" scrolling="no" width="728">
&lt;script language="JavaScript" type="text/javascript"&gt;
document.write('&lt;a
href="http://adlog.com.com/adlog/e/r=10153&amp;amp;s=685047&amp;amp;t=2006.10.15.17.21.57&amp;amp;o=1:&amp;amp;h=pi&amp;amp;p=&amp;amp;b=4&amp;amp;l=En_US&amp;amp;site=6&amp;amp;pt=&amp;amp;nd=&amp;amp;pid=&amp;amp;cid=&amp;amp;pp=&amp;amp;e=&amp;amp;rqid=01c17-gne-ad3452B80022430B3F&amp;amp;event=58/http://clk.atdmt.com/ATA/go/cntnsbra0350000337ata/direct/01/2006.10.15.17.21.57"
target="_blank"&gt;&lt;img
src="http://view.atdmt.com/ATA/view/cntnsbra0350000337ata/direct/01/2006.10.15.17.21.57"/&gt;&lt;/a&gt;');
&lt;/script&gt;&lt;noscript&gt;&lt;a
href="http://adlog.com.com/adlog/e/r=10153&amp;amp;s=685047&amp;amp;t=2006.10.15.17.21.57&amp;amp;o=1:&amp;amp;h=pi&amp;amp;p=&amp;amp;b=4&amp;amp;l=En_US&amp;amp;site=6&amp;amp;pt=&amp;amp;nd=&amp;amp;pid=&amp;amp;cid=&amp;amp;pp=&amp;amp;e=&amp;amp;rqid=01c17-gne-ad3452B80022430B3F&amp;amp;event=58/http://clk.atdmt.com/ATA/go/cntnsbra0350000337ata/direct/01/2006.10.15.17.21.57"
target="_blank"&gt;&lt;img border="0"
src="http://view.atdmt.com/ATA/view/cntnsbra0350000337ata/direct/01/2006.10.15.17.21.57"
/&gt;&lt;/a&gt;&lt;/noscript&gt;</iframe><img src="genmessage9_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 2
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;page=8">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,30854544" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=7">Previous Page</a> |
Page 9 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/12/2006 9:07:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340538397">message detail</a>
 | #401</td></tr>
<tr class="even"><td>
<b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>MASTER CHIEF</b><br><br><i>"I think we're just getting started."</i><br><br>Summer 2003 Contest<br>Extrapolated Strength --- 26th Place [25.31%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 14th Place [29.96%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 23rd Place [28.29%]<br><br>And
now for the character who has been dubbed by many as the biggest
oddball in contest history. Master Chief has seen and done most
everything one might think of in his contest career. He's been
underestimated, he's been massively overrated (and arguably multiple
times), he was involved in the closest match in contest history, he's
made the biggest successful comeback in contest history...every year he
is a massively entertaining character to watch, and this is due to the
contrast between the massive anti-votes he gets for being Halo/XBox and
the massive unconditional support he receives from the Halo/XBox
fanbase that is here. He sure as hell ain't linear, he's probably not
even transitive, and he is once again in a position where a match is
his to lose. So...put on a show for me, Chief! WOO MASTER CHIEF<br><br><b>SUB-ZERO</b><br><br><i>"Let's get something straight...I am not a ninja. I am Lin Kuei!"</i><br><br>N/A<br><br>The
last of the Nomination Rally Winners that made it into the contest,
Sub-Zero happens to also be the one with the only winnable match. And
it's a bit of a longshot, too -- but if there's one character that you
want to face in a longshot upset, you better believe that character is
Master Chief. Out to prove where MK stands in the scheme of things
nowadays (and with Armageddon just releasing a few days ago), this is a
shot at redemption and to prove his place as a permanent midcarder
contender. However, he'll likely have to win just to get that much
respect...after all, no one's going to take his X-Stat placing
seriously if he loses, right? WOO SUB-ZERO<br><br><i>Notable Releases Since Last Appearance</i><br> <br>Master Chief: N/A<br>Sub-Zero: Mortal Kombat (ARC), Mortal Kombat II (ARC), Mortal Kombat: Armageddon (Multi)<br><br><i>Upcoming Releases</i><br><br>Master Chief: Halo 3 (X360)<br>Sub-Zero: N/A<br> <br>Whoa,
an interesting match to cap off the first round! Once again, we've got
a midcarder opponent going up against Master Chief...and the last time
this happened, MC ended up having to make the biggest comeback of all
time to win the match. However, the way he went out against Crono makes
his true strength a little fuzzy. How much did Donkey Kong boost, I
ask? I'd take Sub-Zero over the Donkey Kongs I saw before 2k5, but with
the Nintendo boost (and Halo 2) this match becomes a lot more difficult.<br><br>It
sounds really weird to think of the Chief as 'proven' competition, but
he is the *more* proven competitor here...we know he won't just roll
over and die, whereas Subby has a slight chance of doing that if MK
really has fallen off the map. That's enough for me to give MC the
slight nod here, though I'm anything but confident.<br> <br>Karma Hunter's Vote: Sub-Zero. I've always been a bit of an MK mark, at least more than a Halo mark...<br><br><b>Karma Hunter's Krazy Prediction: Master Chief with 52.86%.</b><br><br>I see this being another MC/Felix affair, with Halo 2 making the difference...<br><br><b>Upset Potential: 40.55%<br><br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br><br>Don't
count Sub-Zero out by any stretch of the imagination, of course.
Scorpion's 2k2 and 2k3 values are nearly equal to Master Chief's 2k3
value, and with MC playing down to competition I feel confident in
saying Scorpion would have won in those years. Then there's Scorpion's
2k4 value, but that's behind an underrated Auron -- bringing Sephy up
to his 2k3/2k5 levels and accounting for some potential Seph/Auron SFF,
Scorpion has perhaps been one of the more consistent competitors
throughout contest history.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/12/2006 9:08:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340538530">message detail</a>
 | #402</td></tr>
<tr class="even"><td>Now, of course, MC likely seals the deal much like
he did with Frog if you add in Halo 2. However, there is a good chance
that Scorpion is significantly weaker than Sub-Zero...and if Sub-Zero's
difference is good enough, he can compete with the post-Halo 2 Chief.
Add in the new MK game that *just* came out, and...I'm really scared
for MC here. I'd love to see the upset, though -- and if it happens,
this will be the third time in the last three character-based contests
that the 7 seed has upset the 2 seed in the last match of the first
round.<br><br>Let's do it!<br><br>Upset Prediction: Sub-Zero with 51.89%<br> <br><br><br><b>Guest&#8217;s Analysis</b> - <i>transience</i><br> <br>Master Chief (2005c) VS Scorpion (2004c)<br><br>Master Chief has a strength of 30.87.<br>Scorpion has a strength of 20.65.<br><br>Master Chief wins with 66.55% of the vote!<br>A win of 30,137 with 91,030 total votes cast.<br><br>easy, right? Sub-Zero's a palette swap of Scorpion and MC is projected to double Scorpion, right?<br><br><b>no.</b><br><br>why?
well, a thousand reasons. it's a well-known fact that Master Chief
exists to screw up x-stats. he has a sizable fanbase that votes for him
unconditionally over everyone else and an anti-fanbase that votes
against him in the same manner. the stronger the opponent is, the
better Master Chief ends up looking. put him up against Link and he
probably scores 35%. Master Chief's contest resume includes a comeback
victory against Donkey Kong, the biggest choker in contest history, and
a 7 vote loss to Frog who then overperformed on Solid Snake thanks to
one of the most unfair pictures in history. his other highlights
beating down Crash (who people care about even less than MC) and
allowing some guy named Felix to get 47% on him. I'm not even sure if
this Felix guy originates in a video game or not.<br><br>Scorpion, on
the other hand, is behind Sephiroth/Auron SFF that's unaccounted for in
2004. his 2003 value is much higher and is far more reliable unless MK
characters just took a drastic drop in 2004 for no apparent reason.
let's judge Scorpion's 2003 value vs. the guy MC went 50/50 with, Frog:<br><br>Scorpion (2003c) VS Frog (2005c)<br><br>Scorpion has a strength of 24.74.<br>Frog has a strength of 24.97.<br><br>Frog wins with 50.46% of the vote!<br>A win of 792 with 86,013 total votes cast.<br><br>wow,
that's a lot closer! no surprise. to be fair, MC has since had Halo 2.
how much did it do for him? it doesn't look like very much. CATS from
this year projects MC at something like 25% and Sam Fisher might be
even lower. he clearly has increased, though how much is up for debate
and we might never know.<br><br><br>anyway, back to Sub-Zero. is he stronger than Scorpion? let me bring up the poll everyone else has probably already referenced:<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1788" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1788">http://www.gamefaqs.com/poll/index.html?poll=1788</a><br><br>Sub-Zero
did significantly better than Scorpion in this poll. does that mean
that he's way stronger? no, probably not, maybe a percentage point or
two. but if Sub-Zero:Scorpion is anything like Ryu:Ken, this match
isn't even debatable. it's unlikely, but possible.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/12/2006 9:08:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340538552">message detail</a>
 | #403</td></tr>
<tr class="even"><td>
what the<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/12/2006 9:09:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340538846">message detail</a>
 | #404</td></tr>
<tr class="even"><td>Sub-Zero combats Halo 2 with a whole slew of new
MK games. those games seem to come out every two weeks these days and
people buy them by the millions. the big x-factor for this match is the
new MK game, Armageddon, which came out a day or two ago. how much is
it going to matter? it's impossible to say, but it's clear that it's
bringing MK fans to the site. the game is #2 and #22 (PS2 and XBox
respectively) on the top 50 list and the PS2 message board already has
1575 topics and over 20,000 messages. (and holy crap, every single one
of them is moronic.) by the time this gets posted, I bet MKA is #1 and
the XBox version is in the top 10. if Sub-Zero gets a "Super Mario
Sunshine"-esque boost like Mario seemed to in 2002, Master Chief's
going to have a hard time even keeping it close. the people who are
calling for MC getting 60%+ are nuts and I don't think this match ends
up with one side having more than 55%. everything is set up in
Sub-Zero's favour and I think he's<br>going to pull it off.<br><br>transience's prediction: <b>SUB-ZERO WINS</b> with 51.69%<br> <br> <br> <br>Crew
Consensus: Ahh, these write-ups represent the match pretty well. Chief
is unpredictable, and Subbie is an unknown. No one is sure of what will
happen here!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=46088" class="name">therealmnm</a> |
Posted 10/12/2006 9:11:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340539217">message detail</a>
 | #405</td></tr>
<tr class="even"><td>
<i>*Master Chief pulls out an Sub-Machine Gun, but Sub-Zero hits him before he can even attack with a ball of ice.*</i><br><br>I read that as "Sub-Zero hits him before he can even attack in the balls with ice"<br>---<br>Currently playing: Grand Theft Auto 3, Castlevania:Curse of Darkness, Mega Man ZX
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 10/12/2006 9:12:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340539406">message detail</a>
 | #406</td></tr>
<tr class="even"><td>
And Moltar wins the internets. Again.<br><br>---<br><i>Do you really need me to bring out the Ovaltine?</i>-Stripey12isback on why hes a war hero.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=788233" class="name">PokemonPatriarch</a> |
Posted 10/12/2006 9:15:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340540322">message detail</a>
 | #407</td></tr>
<tr class="even"><td>I like Transience's guts in predicting Sub Zero,
but just by looking at the reviews from the diverse crew above, you can
tell that at least this board hates Subby's guts.<br><br>However, he's getting my vote tomorrow. Why? Well let's just say I'm a PokemonProstitute when it comes to the MK series. n_n<br>---<br>Proud fanboy of the Ogre Battle saga!!!<br><b>~~~Allah Approves~~~ </b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3602792" class="name">Garsha_III</a> |
Posted 10/12/2006 9:19:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340541215">message detail</a>
 | #408</td></tr>
<tr class="even"><td>
Man, guests do really make bad predictions. I'm next. I promise my prediction will be nowhere near as bad as the others.<br>---<br>George Harrison &gt; Flonne
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/12/2006 9:23:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340542310">message detail</a>
 | #409</td></tr>
<tr class="even"><td>
I didn't like Moltar's or Tranny's writeups. =/<br><br>I'm going to have to go with KH's prediction on this one.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3708259" class="name">MastaHealer</a> |
Posted 10/12/2006 9:24:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340542550">message detail</a>
 | #410</td></tr>
<tr class="even"><td>
Thanks for the entertaining write up, Moltar!<br>---<br>*is <b>wavedash101</b>*<br>Satai gets Biggest Surprise EVER Award! ^_^
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/12/2006 9:26:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340542899">message detail</a>
 | #411</td></tr>
<tr class="even"><td>
that's because you have no soul.<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/12/2006 9:36:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340545278">message detail</a>
 | #412</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Like I care.....it's Game 1,
and the Mets are winning! (See, I'm free to plug these things when I'm
not officially part of the Crew.)<br><br>Okay, okay, I'll say something
about the match. First of all, I'm so glad Sub-Zero got in....he's
easily my favorite Mortal Kombat character, and seeing Scorpion get in
several times over him was painful.<br><br>But I don't care how "hated"
Halo may be here.....Mortal Kombat doesn't pull the weight around here
enough to contend with Master Chief. Though an upset is not completely
out of the question, it would be a great surprise.<br><br>My vote: Sub-Zero<br>My bracket: Master Chief<br>My prediction: Master Chief with 56%<br><br>(OMG, my prediction is like, in the middle compared to the Crew!)<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/12/2006 9:37:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340545483">message detail</a>
 | #413</td></tr>
<tr class="even"><td>
<i>that's because you have no soul.</i><br><br>Indeed, stats topic humor and subtle board bashing for the win!<br><br>And Halo and MK aren't exactly two series that are loved on this board...<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Auron vs. Alucard - Bracket: <b>Auron</b> - Vote: <b>Auron</b> (27/30)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=788233" class="name">PokemonPatriarch</a> |
Posted 10/12/2006 9:44:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340547308">message detail</a>
 | #414</td></tr>
<tr class="even"><td>
Forgive me for asking this out of ignorance, but what makes Mortal
Kombat hated on this board other than the fact that it's a fighting
series?<br><br>Is it because the series has lost what makes it unique/has gone stale?<br><br>Is
it because the characters lack any creative design, the peak of the
this being during MK Trilogy, when we had seven ninjas, five sluts, and
three cyborgs?<br><br>Or is it just because?<br>---<br>Proud fanboy of the Ogre Battle saga!!!<br><b>~~~Allah Approves~~~ </b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=759072" class="name">cyko</a> |
Posted 10/12/2006 9:53:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340549408">message detail</a>
 | #415</td></tr>
<tr class="even"><td>
Moltar's write-up was made of pure awesomeness.<br><br>---<br><i>i have officially been <b>Z1mZum'D </b>in the guru contest.</i><br><b>Vincent Valentine to win the Blast Division!!</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/12/2006 9:54:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340549685">message detail</a>
 | #416</td></tr>
<tr class="even"><td>
from what I gather, MK is "shallow". mind you, very few people care
about fighting games in general on this board, but the ones that do
condemn MK for not having the depth or balance or challenge of other
games.<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=576102" class="name">meche313</a> |
Posted 10/12/2006 9:57:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340550279">message detail</a>
 | #417</td></tr>
<tr class="even"><td>
Good job Moltar. That was just too good. For some reason of all the
lines the one that made me laugh the most was Link telling Mario that
he sucks.<br>---<br>Happy Happyists <b>4th</b> on the Oracle Team Challenge. <b>3rd</b> on Spread Betting!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/12/2006 9:57:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340550390">message detail</a>
 | #418</td></tr>
<tr class="even"><td>
Yeah, and it gets overshadowed by Street Fighter and Soul Calibur.<br><br>Heck, I'd bet even Guilty Gear is preffered here.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Auron vs. Alucard - Bracket: <b>Auron</b> - Vote: <b>Auron</b> (27/30)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/12/2006 9:59:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340550890">message detail</a>
 | #419</td></tr>
<tr class="even"><td>
maybe amongst the fighting game elitist types, but MK is probably more popular overall since more people have played it. <br><br>and it's not like you need to like MK to like Sub-Zero.. he's recognized universally and is a ninja. that's good enough.<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2270469" class="name">Undeniable</a> |
Posted 10/12/2006 10:00:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340551056">message detail</a>
 | #420</td></tr>
<tr class="even"><td>
One day SNK will be respected by all...<br>~~~<br><i>Deejay is as serious as they come. Beneath his sexy, stereotypical exterior beats the heart of a true angry black man.</i> - Titan44
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3802849" class="name">King Bowser</a> |
Posted 10/12/2006 10:00:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340551129">message detail</a>
 | #421</td></tr>
<tr class="even"><td>
Guilty Gear is <i>lightyears</i> better than
Mortal Kombat, which is a raging piece of crap that has long over
stayed its weclome. Pretty much every fighting series I can name off
the top of my stomps Mortal Kombat -- Street Fighter, King of Fighters,
Guilty Gear, Soul Calibur, Tekken (yes, even Tekken), Virtua Fighter,
Last Blade, and so on.<br><br><br>It can come back again when it decides to actually be a good <i>fighting game</i>
with actual depth as opposed to being a shallow piece of garbage that
only has a claim to fame because of its ridiculous violence. <br><br><br><br><br>---<br>"That's a cruel, rotten, disgusting idea -- and I love it!"
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/12/2006 10:02:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340551504">message detail</a>
 | #422</td></tr>
<tr class="even"><td>
hey HM, I double dog dare ya to stop the Black Turtle act with Mortal Kombat!<br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3802849" class="name">King Bowser</a> |
Posted 10/12/2006 10:03:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340551622">message detail</a>
 | #423</td></tr>
<tr class="even"><td>
Not until Sub-Zero loses!<br><br>---<br>"That's a cruel, rotten, disgusting idea -- and I love it!"
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/12/2006 10:03:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340551723">message detail</a>
 | #424</td></tr>
<tr class="even"><td>
<b>SUB-ZERO WINS</b><br>---<br>xyzzy<br>"12 percent of those who liked opera had experimented with magic mushrooms." - Reuters
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3602792" class="name">Garsha_III</a> |
Posted 10/12/2006 10:04:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340551887">message detail</a>
 | #425</td></tr>
<tr class="even"><td>
*imagines Dizzy in a contest*<br><br>*imagines Tails getting 80% on her*<br><br>Oh dear.<br>---<br>George Harrison &gt; Flonne
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/12/2006 10:26:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340556550">message detail</a>
 | #426</td></tr>
<tr class="even"><td>
Let me attempt to sum up the Crew arguments for this one, if I may.<br><br>Moltar - wtf massive tangent<br>Ulti - lol laziness<br>HM - I HATE MORTAL KOMBAT<br>yo - Uh yeah MC wins<br>Lopen - MASTER CHIEF IS INVINCIBLE<br>KH - Uh yeah this'll be close MC wins<br>tran - uh yeah this'll be close Sub-Zero wins<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=152338" class="name">Lopen</a> |
Posted 10/12/2006 11:11:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340565260">message detail</a>
 | #427</td></tr>
<tr class="even"><td>
XD Karma Hunter.  <br><br>Master Chief's just giving Sub Zero a head start, in true MC form... MASTER CHIEF IS INVINCIBLE!<br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=46088" class="name">therealmnm</a> |
Posted 10/12/2006 11:41:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340570503">message detail</a>
 | #428</td></tr>
<tr class="even"><td>
Wow, I just now finished reading the crew's analyses. Talk about
overrating MC or underrating Sub-Zero... I thought it was a consensus
that this would be a close match. Yet I saw people busting out 60-40ish
wins by Master Chief? I thought I would be pushing it by having MC win
by 52%...<br>---<br>Currently playing: Grand Theft Auto 3, Castlevania:Curse of Darkness, Mega Man ZX
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=152338" class="name">Lopen</a> |
Posted 10/12/2006 11:44:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340570919">message detail</a>
 | #429</td></tr>
<tr class="even"><td>
I have to admit I was pretty surprised not to see my prediction <i>not</i> be the highest.  I have an excuse, I was indulging in Master Chief hype.  You've gotta expect it from <i>me</i>.<br><br>Er... <i>he shall still win with 60%!  Go!</i><br>---<br><b>MASTER CHIEF IS INVINCIBLE!</b><br><i>*waves M$ Flag*</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=683142" class="name">transience</a> |
Posted 10/13/2006 12:16:52 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340575575">message detail</a>
 | #430</td></tr>
<tr class="even"><td>
*gets lucky*<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=795464" class="name">Tatl</a> |
Posted 10/13/2006 12:25:22 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340576630">message detail</a>
 | #431</td></tr>
<tr class="even"><td>
Tranny wins this time around.<br><br>Another point for board eight.<br>---<br>"I reject your reality and substitute my own." ~ Adam Savage; Insanity Personified<br>"Crikey!" ~ Steve Irwin (R.I.P.); Perfection Personified
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/13/2006 12:25:46 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340576680">message detail</a>
 | #432</td></tr>
<tr class="even"><td>
Crew = OWNED.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=1157140" class="name">Kaxon</a> |
Posted 10/13/2006 12:44:48 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340579044">message detail</a>
 | #433</td></tr>
<tr class="even"><td>
Moltar's analysis was awesome.<br>---<br>....TCELES B HSUP
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=254355" class="name">Lugia2</a> |
Posted 10/13/2006 5:58:48 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340597596">message detail</a>
 | #434</td></tr>
<tr class="even"><td>
AND THE TRADITIONAL LOSING OF THE POINT OF THE ANALYSIS CREW IN THE LAST MATCH OF ROUND 1 CONTINUES!<br><br>We've
seen this before. Moltar writes a cool write-up, almost everyone doubts
the underdog, and the underdog wins! With the exception of the BSE
contest, this has been happening for two years...<br><br>...So why did I put MC in my bracket?<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/13/2006 7:40:13 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340602626">message detail</a>
 | #435</td></tr>
<tr class="even"><td>
Pfft! Shows how much <i>you</i> know Moltar. The elitism standard has been raised to 95% for the last 3 months.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/13/2006 7:40:43 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340602663">message detail</a>
 | #436</td></tr>
<tr class="even"><td>
Oh and, Guest gets another point, woo-hoo!<br><br>Board 8's coming for you!<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3216520" class="name">TheSwizzle</a> |
Posted 10/13/2006 7:47:46 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340603176">message detail</a>
 | #437</td></tr>
<tr class="even"><td>
<i>Pfft! Shows how much you know Moltar. The elitism standard has been raised to 95% for the last 3 months.</i><br><br>It's a hex. Same thing happening to Ocelot in last year's write-up.<br><br>Albeit the guy was <i>melting</i> in his match pic, but still  a vexing curse nonetheless. &gt;_&gt;<br>---<br><i>"If at first you don't succeed, find out if the loser gets anything."</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/13/2006 11:15:39 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340622732">message detail</a>
 | #438</td></tr>
<tr class="even"><td>
Love that write-up, Moltar! I really liked my role!<br><br><i>...actually, wait, no one with common sense cares about Mortal Kombat.</i><br><br>LOL Ulti<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 3</i>: W, 50-12 vs. Superman
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/13/2006 4:08:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340670657">message detail</a>
 | #439</td></tr>
<tr class="even"><td>
Board 8 is on an absolute tear, watch out analysis crew!<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/13/2006 4:18:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340672708">message detail</a>
 | #440</td></tr>
<tr class="even"><td>
<i>It's a hex. Same thing happening to Ocelot in last year's write-up.</i><br><br>AND with Kuja/Master Hand...talk about bad luck.<br><br>And
while I was confident in MC, I knew Sub-Zero had chance to pull the
upset. I felt the same way about Pac-Man/Ocelot, especially in the
final hours before the match.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Master Chief vs. Sub-Zero - Bracket: <b>MC</b> - Vote: <b>MC</b> (28/31)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/13/2006 4:21:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340673255">message detail</a>
 | #441</td></tr>
<tr class="even"><td>
Auron...........................64.4% 74808<br>Alucard........................35.6% 41357<br>TOTAL VOTES........................116165<br><br>70.08% of the brackets predicted this match correctly.<br><br>KH2
seems to have helped out Auron a bit. Possibly combined with an Alucard
drop as well it seems. Anyway, Auron keeps up his streak of winning his
Round 1 matches in the mid-60's.<br><br>Today, Sub-Zero is pulling the upset!<br><br>Lopen - 7<br>HM - 5<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye) - 5<br>Moltar - 5<br>KH - 5<br>Ulti - 4<br>Yoblazer - 2<br><br>HM gets the point with the highest Auron pick.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Master Chief vs. Sub-Zero - Bracket: <b>MC</b> - Vote: <b>MC</b> (28/31)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/13/2006 4:24:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340673784">message detail</a>
 | #442</td></tr>
<tr class="even"><td>
Guest moving into 2nd place?!<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/13/2006 5:26:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340686418">message detail</a>
 | #443</td></tr>
<tr class="even"><td>
Hey Moltar, could you bump up my Samus prediction by 2%? Thanks.<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 10/13/2006 6:24:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340698812">message detail</a>
 | #444</td></tr>
<tr class="even"><td>
Go Guest!<br>---<br><b>Squall Leonhart's Road to the Character Battle V Championship</b>:<br><i>Round 1</i>: Status of Tidus - <b>LIONHEART'D</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3602792" class="name">Garsha_III</a> |
Posted 10/13/2006 6:25:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340698965">message detail</a>
 | #445</td></tr>
<tr class="even"><td>
I've got my analysis ready as a guest. Who do I email to?<br>---<br>!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/13/2006 6:28:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340699453">message detail</a>
 | #446</td></tr>
<tr class="even"><td>
<a class="linkification-ext" href="mailto:MasterMoltar@gmail.com" title="Linkification: mailto:MasterMoltar@gmail.com">MasterMoltar@gmail.com</a><br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Master Chief vs. Sub-Zero - Bracket: <b>MC</b> - Vote: <b>MC</b> (28/31)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/13/2006 6:32:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340700236">message detail</a>
 | #447</td></tr>
<tr class="even"><td>
Wait.. round 2 signups already happened? I'm shocked and outraged! I
demand Dante/Yoshi this instant! Oh well... Lopen will do me justice. <br><br><br>....saying that just <i>feels</i> awful.<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 10/13/2006 6:32:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340700378">message detail</a>
 | #448</td></tr>
<tr class="even"><td>
He's only done the female half for round 2.<br><br>...Because you better believe I'm waiting for claim Snake/Squall!<br>---<br><b>Squall Leonhart's Road to the Character Battle V Championship</b>:<br><i>Round 1</i>: Status of Tidus - <b>LIONHEART'D</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/13/2006 6:38:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340701521">message detail</a>
 | #449</td></tr>
<tr class="even"><td>
Oh thank god, like I want to waste my time analysing an estrogen filled match. <br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=30854544&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/13/2006 6:39:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=30854544&amp;message=340701716">message detail</a>
 | #450</td></tr>
<tr class="even"><td>
Actually, despite being a huge Dante fanboy, I'd rather have Vincent/Sonic... either way!!<br><br>---<br>I'm so hardcore.
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=7">8</a></li>
<li>9</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30854544&amp;page=9">10</a></li>
</ul>
</div>


</div>
<div id="sponsored_links">
	<iframe src="genmessage9_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=30854544&amp;page=8" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage9_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>