document.writeln("<!-- TF 728x90 IFrame non-VAR code -->");
document.writeln("<iframe src=\"http://a.tribalfusion.com/f.ad?site=GameSpot&adSpace=ROS&size=728x90&requestID=1576037958\" width=728 height=90 marginwidth=0 marginheight=0 hspace=0 vspace=0 frameborder=0 scrolling=no allowTransparency=true>");
<!--Begin Jserver Skip-->
         <!--
           randNum = ((new Date()).getTime() % 2147483648) + Math.random();
           document.write(
             "<a href='http://a.tribalfusion.com/i.click?site=GameSpot&adSpace=ROS&size=728x90&requestID=" + randNum + "' target=_blank>" +
             "<img src='http://a.tribalfusion.com/i.ad?site=GameSpot&adSpace=ROS&size=728x90&requestID=" + randNum + "'" +
               " width=728 height=90 border=0 alt='Click Here'></a>");
         // -->
<!--End Jserver Skip-->
document.writeln("<noscript>");
document.writeln("<a href=\"http://a.tribalfusion.com/i.click?site=GameSpot&adSpace=ROS&size=728x90&requestID=1576037958\" target=_blank>");
document.writeln("<img src=\"http://a.tribalfusion.com/i.ad?site=GameSpot&adSpace=ROS&size=728x90&requestID=1576037958\" ");
document.writeln("width=728 height=90 border=0 alt=\"Click Here\"></a>");
document.writeln("</noscript>");
document.writeln("</iframe>");
document.writeln("<!-- TF 728x90 IFrame non-VAR code -->");
document.writeln("<img src='http://ds.contextweb.com/IMPCNT/ccid=798/CCID=798/acc_random=525003936/pageid=525003936/aamgeoip=172.166.126.57/AAMB3/SITE=GAMESPOTOPO/AAMSZ=728X90/AREA=HOBBIESINTERESTS' width=1 height=1 border=0>");document.close();