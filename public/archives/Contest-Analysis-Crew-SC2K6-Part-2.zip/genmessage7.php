<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">

<title>GameFAQs: Message List</title><link rel="stylesheet" type="text/css" href="genmessage7_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage7_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage7_files/bc.css"></head><body linkifytime="270" linkified="37" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage7_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage7_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29209811%26page%3D6"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<a href="http://adlog.com.com/adlog/c/r=10153&amp;s=669723&amp;t=2006.07.30.22.06.24&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=00c17-gne-ad444C8F1BA1583FA4/http://www.gamespot.com/pc/action/hitman4/index.html?q=hitman" target="_blank"><img src="genmessage7_files/Hitman_leader_buyit.jpeg" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage7_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew - Part 2</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29209811&amp;page=6">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29209811" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">First
          Page</a> |
          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=5">Previous
          Page</a> |
          Page 7 of 10          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=7">Next
          Page</a>
          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=9">Last
          Page</a>
      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/22/2006 10:20:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321783374">message detail</a>
 | #301</td></tr>
<tr class="even">
<td>
It HAS sold more than KH2 though, I believe, plenty more...not to
mention it was shipped with the system for awhile (is it still, or has
that changed?).<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/22/2006 10:21:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321783609">message detail</a>
 | #302</td></tr>
<tr class="even">
<td>
No kidding. KHII has been out for four months, and SSBM has been out for nearly 5 years.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/22/2006 10:22:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321783908">message detail</a>
 | #303</td></tr>
<tr class="even">
<td>
Right, and the match is happening in an hour.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/22/2006 10:25:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321784453">message detail</a>
 | #304</td></tr>
<tr class="even">
<td>
But you know better than to use sales numbers in this argument. The
only time when that becomes relevant when a game has a very small
amount of sales.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/22/2006 10:30:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321785771">message detail</a>
 | #305</td></tr>
<tr class="even">
<td>
I'm just saying KH2 may not have made the rounds yet, despite being GotY thus far.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/22/2006 10:32:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321786140">message detail</a>
 | #306</td></tr>
<tr class="even">
<td>
Kingdom Hearts II has made plenty of rounds. I doubt KH beats Castlevania without it.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/22/2006 11:37:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321801636">message detail</a>
 | #307</td></tr>
<tr class="even">
<td>
Hit-or-miss Lopen continues!<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29209811" class="name">DaruniaTheGoron</a> |
Posted 7/22/2006 11:59:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321806812">message detail</a>
 | #308</td></tr>
<tr class="even">
<td>
<i> From: LeonhartForever </i><br><i><i>I think the hype for SSBB</i><br><br>And that's where you get off track.</i><br><br>o rly?<br><br>*sees SSB winning with 58%*<br><br>Many
social boards used to be pro-Sony and are now pro-Nintendo again which
will effect voting, and think Snake in SSB is awesome. I suppose I
should have said "I think the hype for the Wii/SSBB". Yes I know Sonic
isn't Sony, but the newfound love for Nintendo will help any Nintendo
entrant.<br><br>Or maybe I'm way off on my analysis. Whatever, I'm 26/28 right now and I'm happy with that.<br><br>Btw
Lopen, I apologize for my lawling at you, sometimes people are just way
off, like I was today. I foresaw a very close match today, but it's not.<br>---<br><b>Sp2k6:<i> 24/26</i> Rank: <i>Tied for 752nd</i> Losses: <i>Halo, GTA</i><br>Yesterday's Pick: <i>Mario</i> Today: <i>SSB</i> Tomorrow:<i> FF</i></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/22/2006 11:59:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321806975">message detail</a>
 | #309</td></tr>
<tr class="even">
<td>
<i>o rly?</i><br><br>ya rly.<br><br>Hype doesn't do anything at all in contests. <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29209811" class="name">DaruniaTheGoron</a> |
Posted 7/23/2006 12:04:26 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321807981">message detail</a>
 | #310</td></tr>
<tr class="even">
<td>
I never said it was a major factor, only a factor which would propel it
to a slight win. I think hype does SOMETHING, not nothing.<br>---<br><b>Sp2k6:<i> 24/26</i> Rank: <i>Tied for 752nd</i> Losses: <i>Halo, GTA</i><br>Yesterday's Pick: <i>Mario</i> Today: <i>SSB</i> Tomorrow:<i> FF</i></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3546173&amp;board=8&amp;topic=29209811" class="name">_Seer_</a> |
Posted 7/23/2006 12:11:49 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321809525">message detail</a>
 | #311</td></tr>
<tr class="even">
<td>
Bump<br>---<br><b>DEFENCE, DEFENCE</b><br>Seeraamaazu</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/23/2006 12:12:12 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321809596">message detail</a>
 | #312</td></tr>
<tr class="even">
<td>
I only mentioned SSBB hype because many people compared CV/Halo to
Sonic/SSB, and I was trying to prove across all levels why SSB &gt;
Halo.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/23/2006 12:14:48 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321810134">message detail</a>
 | #313</td></tr>
<tr class="even">
<td>
<i>Master Moltar | Posted 7/22/2006 9:15:10 PM | message detail  | #043<br>Analyses posted in the Crew topic. In short, the Crew has Sonic 5-4.<br><br>You know what this means, SSB is going to win easily!</i><br><br>Hmm...<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Sonic vs. Super Smash Bros. - Bracket: <b>SSB</b> - Vote: <b>SSB</b> (24/26)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29209811" class="name">DaruniaTheGoron</a> |
Posted 7/23/2006 12:15:09 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321810200">message detail</a>
 | #314</td></tr>
<tr class="even">
<td>
I think Snake in SSBB is swaying at least a <i>few</i> MG fans who were unsure who to vote for.<br>---<br><b>Sp2k6:<i> 24/26</i> Rank: <i>Tied for 752nd</i> Losses: <i>Halo, GTA</i><br>Yesterday's Pick: <i>Mario</i> Today: <i>SSB</i> Tomorrow:<i> FF</i></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/23/2006 12:19:44 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321811103">message detail</a>
 | #315</td></tr>
<tr class="even">
<td>
<i>o rly?<br><br>*sees SSB winning with 58%*</i><br><br>Getting the match right =/= Getting the right argument<br><br>Super Smash Brothers is winning for many reasons, of which Super Smash Brothers Brawl is a negligible one.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=667635&amp;board=8&amp;topic=29209811" class="name">Agent M</a> |
Posted 7/23/2006 12:22:38 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321811769">message detail</a>
 | #316</td></tr>
<tr class="even">
<td>
Right, and to give an example, Link vs. Cloud in 2k4 had all sorts of
arguments about TP and AC affecting their performances. So suddenly
hype is dismissed as a non factor?</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/23/2006 12:23:07 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321811879">message detail</a>
 | #317</td></tr>
<tr class="even">
<td>
I never thought hype was the reason Link won SC2K4.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3658858&amp;board=8&amp;topic=29209811" class="name">SuperiorSnake</a> |
Posted 7/23/2006 12:25:29 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321812366">message detail</a>
 | #318</td></tr>
<tr class="even">
<td>
Sigh.<br><br><br>Hype is completely insigificant. The people who
are hyped about it were likely ones to already be voting for SSB or
whatever it may be. I sincerely you doubt any number of people worth
mentioning were going to vote Sonic until they heard about SSBB.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/23/2006 12:26:37 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321812588">message detail</a>
 | #319</td></tr>
<tr class="even">
<td>
I'll admit I got about as excited as anybody else here when Super Smash
Brothers Brawl was announced, and there was no doubt about voting for
Sonic.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/23/2006 12:40:07 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321815235">message detail</a>
 | #320</td></tr>
<tr class="even">
<td>
<i>58.12% (I'd have gone higher, but I'm a sucker for unoriginal %ages!)</i><br><br>I meant to comment on this earlier Lopen, but I did catch your cheap-shot.  =P<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/23/2006 3:37:31 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321840108">message detail</a>
 | #321</td></tr>
<tr class="even">
<td>
Hey, hey, hey.  That .12% was just a coincidence!  <br><br>58.12%
was the Mega Man/Mario Kart final %. Wow, what a shocker. Can't say I'm
complaining, though... in fact, when the contest started I'd have
expected SSB to get this on... <i>Devil May Cry</i>, which was <i>supposed</i> to squeak by Sonic.  <br><br>Eh.  I'm not complaining.  I prefer SSB, anyway.  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1288566&amp;board=8&amp;topic=29209811" class="name">gtonizuka49</a> |
Posted 7/23/2006 3:46:33 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321840863">message detail</a>
 | #322</td></tr>
<tr class="even">
<td>
+9 Lopen<br>+8 yo<br>+7 mnm<br>+6 HM<br>+5 Leon<br>+4 Soul<br>+3 Moltar<br>+2 Ulti<br>+1 HaRRicH<br><br><b>The Rankings</b> (Through Super Mario Bros./Warcraft)<br>1. Master Moltar (95)<br>2. XxSoulxX (80)<br>3. UltimaterializerX (77)<br>4. yoblazer33 (75)<br>5. Leonhart (74)<br>6. Lopen (71)<br>7. HaRRicH (57)<br>7. Heroic Mario (57)<br>9. therealmnm (56)<br><br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29209811" class="name">Lugia2</a> |
Posted 7/23/2006 8:21:25 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321857438">message detail</a>
 | #323</td></tr>
<tr class="even">
<td>
SSB V Sonic: MK v MM <b> Take 2 </b><br><br>Crew goes 5-4, match
not really close (I blame SFF, since MM, MK, Sonic, and SSB are all
considered Nintendo-ish franchises). Old, established, one player game
Vs. hyped, multi-player, new-ish upstart.<br><br>Well, this time the upstart didn't follow the script...Fun!  <br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/23/2006 11:43:27 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321880180">message detail</a>
 | #324</td></tr>
<tr class="even">
<td>
I'm gettin' pretty sick of hearing calls for SFF every time something Sonic-related loses to something Nintendo-related.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/23/2006 11:50:19 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321881385">message detail</a>
 | #325</td></tr>
<tr class="even">
<td>
<i>I'm gettin' pretty sick of hearing calls for SFF every time something Sonic-related loses to something Nintendo-related.</i><br><br>Same here, but with Mega Man instead of Sonic. But can't argue with facts though... &gt;_&gt;<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2266918&amp;board=8&amp;topic=29209811" class="name">KamikazePotato</a> |
Posted 7/23/2006 12:05:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321884170">message detail</a>
 | #326</td></tr>
<tr class="even">
<td>
tag<br><br>---<br>Angsty_Lou: Everything has a sexual connotation if you just look long and hard enough.<br>Theo72: U SED LONG AND HARD LOL</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/23/2006 12:37:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321889677">message detail</a>
 | #327</td></tr>
<tr class="even">
<td>
Mega Man's arguable and we've seen more solid evidence of it. Sonic
though...outside of Sonic the character, show me where his games should
have some strength.<br><br><br><br>THE BEST OF 1999: Dreamcast<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=32" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=32">http://www.gamefaqs.com/poll/index.html?poll=32</a><br><br>THE BEST OF 1999: Neo-Geo Pocket<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=35" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=35">http://www.gamefaqs.com/poll/index.html?poll=35</a><br><br>THE BEST OF 1999: Game of the Year<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=38" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=38">http://www.gamefaqs.com/poll/index.html?poll=38</a><br><br>Of all of this year's most anticipated upcoming games, which do you most want?<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=678" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=678">http://www.gamefaqs.com/poll/index.html?poll=678</a><br><br>BEST OF 2001: Best Dreamcast Game of the Year<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=767" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=767">http://www.gamefaqs.com/poll/index.html?poll=767</a><br><br>Which scheduled February release are you most looking forward to?<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=792" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=792">http://www.gamefaqs.com/poll/index.html?poll=792</a><br><br>Which upcoming Sega game are you most looking forward to?<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1017" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1017">http://www.gamefaqs.com/poll/index.html?poll=1017</a><br><br>Which scheduled November GameCube release are you most interested in?<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1065" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1065">http://www.gamefaqs.com/poll/index.html?poll=1065</a><br><br>BEST OF 2002: Best GameBoy Advance Game<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1127" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1127">http://www.gamefaqs.com/poll/index.html?poll=1127</a><br><br>BEST OF 2002: Best GameCube Game<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1128" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1128">http://www.gamefaqs.com/poll/index.html?poll=1128</a><br><br>Which upcoming Sega title are you most looking forward to?<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1242" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1242">http://www.gamefaqs.com/poll/index.html?poll=1242</a><br><br>Which scheduled June release are you most looking forward to?<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1281" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1281">http://www.gamefaqs.com/poll/index.html?poll=1281</a><br><br>Which series has had the best transition from 2D to 3D?<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1417" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1417">http://www.gamefaqs.com/poll/index.html?poll=1417</a><br><br>Which first-quarter GameCube game are you most looking forward to?<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1481" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1481">http://www.gamefaqs.com/poll/index.html?poll=1481</a><br><br>Which first-quarter Xbox game are you most looking forward to?<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1482" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1482">http://www.gamefaqs.com/poll/index.html?poll=1482</a><br><br>Which company's games are you most fanatical about?<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1580" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1580">http://www.gamefaqs.com/poll/index.html?poll=1580</a><br><br>Division 16 Round 2: Sonic the Hedgehog 2 vs. Super Mario World<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1638" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1638">http://www.gamefaqs.com/poll/index.html?poll=1638</a><br><br>If you could only buy one company's games ever again, which would you choose?<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1815" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1815">http://www.gamefaqs.com/poll/index.html?poll=1815</a><br><br>BEST OF 2004: Best Game Boy Advance Game<br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1869" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1869">http://www.gamefaqs.com/poll/index.html?poll=1869</a><br><br>Top 100 List<br>Sonic 2, the only Sonic rep on the drop-down list, is #38.<br><br><br><br>Those
are lots of polls and info that show he shouldn't be too strong,
despite his icon status and carrying the Genesis. Sonic 2 made the Game
Contest because it received the most #1 Genesis nominations and it was
#2 in the favorite-Sonic-game poll, so even if it's not THE favorite of
the Sonic fans, it's very reasonably close and has a huge overlap with
the other game that could say it's #1 (S&amp;K)...and suddenly, when
Sonic 2 lost big to SMW despite ALL this kind of information, SFF is
suddenly accused because of a RIVALRY? More people believe more SFF was
seen in Sonic 2/SMW than CT/Secret of Mana, two RPGs on the same system
by the same company, because of a rivalry?! You would think they would
stick more to their guns then in a rivalry...<br><br>...but whatever...<br><br>...now
though, people are saying the entire Sonic series is being SFF'd by the
two SSB games that're out, and I'm tired of this quick. If you would,
please take the time to re-read my analysis...hell, if you like,
replace Halo with KH whenever possible...and tell me this doesn't make
more sense. For a two-game series, this is both the series with the
absolute-strongest game and has its two games on seperate systems.
Sonic the character does great for itself, although not quite so much
when compared to other Noble Niners...but its games, please, I want to
be done with this. There is no more SFF in this match than there is
between any other match with two popular series.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/23/2006 12:55:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321892811">message detail</a>
 | #328</td></tr>
<tr class="even">
<td>
Super Mario Bros....81.13% 97775<br>Warcraft.................18.87% 22741<br>TOTAL VOTES..................120516<br><br>76.46% of the brackets predicted this match correctly.<br><br>Is it just me, or is that prediction percentage kinda low? Anyway, SMB easily beats Warcraft with over 81% of the vote.<br><br>Today,
I'm going to have to go with HaRRich and say there's little to no SFF
here. Sonic's games just aren't as strong as its characters.<br><br>Soul - 4<br>Lopen - 3<br>HaRRich - 3<br>Moltar - 3<br>Ulti - 2<br>HM - 2<br>Yoblazer - 1<br>Leon - 1<br>Mnm - 0<br><br>Lopen gets another point. He's been on fire lately.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Sonic vs. Super Smash Bros. - Bracket: <b>SSB</b> - Vote: <b>SSB</b> (24/26)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29209811" class="name">UltimaterializerX</a> |
Posted 7/23/2006 1:01:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321893945">message detail</a>
 | #329</td></tr>
<tr class="even">
<td>
Had I seen that match pic before writing my thing, I <i>never</i> would have picked Sonic to win this for the Crew.<br><br>It's also an unfair pic to the max, given that those sprites are nowhere to be found in the SSB "series".<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29209811" class="name">THEJackSparrow</a> |
Posted 7/23/2006 1:04:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321894536">message detail</a>
 | #330</td></tr>
<tr class="even">
<td>
<i>SFF is suddenly accused because of a RIVALRY?</i><br><br>No, that's
not why. Of course, people have no problem accusing Shadow of an
overperformance on Mario for the same reasons, but no, it's not because
they're rivals. It's because they're two games with extremely high play
rates during a time when they were the two most popular things around.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29209811" class="name">UltimaterializerX</a> |
Posted 7/23/2006 1:09:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321895346">message detail</a>
 | #331</td></tr>
<tr class="even">
<td>
SFF = Some Frivolous Factor<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/23/2006 1:09:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321895483">message detail</a>
 | #332</td></tr>
<tr class="even">
<td>
What I'm saying though is that that, other than them both being popular in that generation, why would there be SFF?<br><br>As
for Shadow, we already know that was a huge anomaly in SONIC's favor,
so who's to say Sonic 2 or the Sonic series hasn't been over-performing
against other Nintendo contestants? I think we agree that's not the
case, but Mario/Shadow does nothing for your case that Sonic's done
worse than he's supposed to against other Nintendo contestants.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/23/2006 1:11:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321895923">message detail</a>
 | #333</td></tr>
<tr class="even">
<td>
Just to note, I think you're goin' to come back and tell me that I'm
not quite getting what you're saying about the high play-rates and the
SFF...but what I'm saying is that there are so many other cases of one
highly-played games, series, or character faces another where there's
no SFF worth noting. Why Sonic 2/SMW? Why Sonic/SSB?<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29209811" class="name">THEJackSparrow</a> |
Posted 7/23/2006 1:16:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321896948">message detail</a>
 | #334</td></tr>
<tr class="even">
<td>
I never said there was SFF here. I'm not the one who's been claiming
that. If you can't see why there would be SFF in SMW/Sonic 2, I don't
know what to tell you. Mario/Shadow just tells us that anomalies
between the two CAN happen. The overlap is there.<br><br>And honestly, if Sonic 2 (what you think is the strongest Sonic game) is only worth 26.82% on Super Smash Brothers Melee <i>alone</i>
(I'm willing to say that there is at least a good number of people out
there who have played Super Smash Brothers for N64 but not Melee), how
is Sonic the series even <i>this</i> close? If his series IS that weak
at the top, the whole series in and of itself shouldn't add nearly 20%,
not counting what Melee gains from SSB.<br><br>In other words, this match in and of itself goes against your argument.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/23/2006 1:24:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321898362">message detail</a>
 | #335</td></tr>
<tr class="even">
<td>
Yes, and the anomaly shows that the main mascot of Nintendo, when
facing arguably the second/third-strongest Sonic character, will make
said-character look as strong as Sonic himself. With that kind of an
anomaly, it's hard to say Nintendo ever gets an advantage over Sonic,
wouldn't you say?<br><br>Seriously though, I don't think that anomaly could be repeated, so I'd like to see it be dropped from here on out if you agree.<br><br><br>Remember
when people on the Halo board were saying it didn't deserve to beat CV
because it was only a two-game series? Remember how big of a following
Sonic once had? Did you know that Sonic is still considered a classic
series? I dare say that Sonic's STATUS is stronger than his games, and
that helps when he's facing any two-game series, even if it's
far-and-away the strongest two-game series in the contest. Why would
Sonic doing "this good" suddenly prove my argument wrong?<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29209811" class="name">SquallidSnake</a> |
Posted 7/23/2006 1:28:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321899255">message detail</a>
 | #336</td></tr>
<tr class="even">
<td>
So you're saying people are voting for Sonic based on status? If
Castlevania had beaten Kingdom Hearts, too, then maybe I'd consider
that. But no, I don't think Sonic's status is the reason for keeping it
this close. If Sonic's games just aren't popular, as you say, then why
would people suddenly vote for them in this case? We very rarely see a
much weaker entry overperform to a great extent (really, Chrono Trigger
characters are the only ones I've seen do it).<br><br><i>With that kind of an anomaly, it's hard to say Nintendo ever gets an advantage over Sonic, wouldn't you say?</i><br><br>No,
I wouldn't say that. I'd say it just shows that an anomaly is possible,
one way or the other. Zelda as a whole will crush anything Metroid with
SFF, but we saw Samus (from the weaker series) pull perhaps a measure
of SFF on Ganondorf (from the stronger series). <br><br>And in my
opinion, Mario's games are stronger than he is, and Sonic is stronger
than his games. That's why you can see Sonic characters overperform on
Mario characters and Mario games overperform on Sonic games.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/23/2006 1:38:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321901374">message detail</a>
 | #337</td></tr>
<tr class="even">
<td>
Sonic's status stays with him in every match, because it's friggin'
Sonic. What I'm saying though is that he may be able to take advantage
of some of SSB's fans in the same way that CV was able to take
advantage of some of Halo's fans. Let Sonic and CV face bigger series
like, say...well hell, let's say CV/Sonic took place -- neither one of
them would have that advantage over their opponent anymore.<br><br>As
for your Samus example, Samus is already a good deal stronger than
Ganon though, and Ganon didn't do better than what was statistically
expected of him...he beat board expectations, sure, but not statistical
ones. Also, for what it's worth, Samus arguably avoided SFF when she
faced Link in 2k3. I know you have your own theory and I know WW-Link
could have been the difference maker, but it's still reasonable to
believe...so if Link couldn't SFF her, why would Ganon?<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/23/2006 1:40:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321901753">message detail</a>
 | #338</td></tr>
<tr class="even">
<td>
That's a bad argument to make with me because I personally believe Link
DID SFF her because saying Samus dropped after her first game in eight
years makes less sense than SMW/Sonic 2 having no SFF.<br><br>And as I've demonstrated before, Samus getting SFF'd in 2003 makes some other things seem less...radical.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/23/2006 2:00:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321905810">message detail</a>
 | #339</td></tr>
<tr class="even">
<td>
Okay, but even then, Samus didn't let Ganon get past 40% on her,
despite Ganon being from the stronger series. Mario is arguably as
strong as Samus and is a notch higher in the Nintendo totem poll, Sonic
is from a weaker series, Sonic is a weaker character than Mario, and
Shadow is not to Sonic as Ganon is to Link...yet Shadow still managed
45% on Mario.<br><br>How wouldn't this go in Sonic's favor, again?<br><br>I
get what you're saying about Mario's games &gt; Mario and Sonic &gt;
Sonic's games, but think about how extreme and ridiculous of a change
it would have to go from letting Shadow -- a character from two (maybe
three?) Sonic games in its least-popular era -- get 45% on Mario when
he should have got about 36%...then Sonic's #1/#2 game (before Shadow
ever existed) get 29% on Mario's #3/#4 game when "it should have got
40+%". That's nothing short of bizarre.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/23/2006 2:05:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321906959">message detail</a>
 | #340</td></tr>
<tr class="even">
<td>
If anything, Shadow being able to do that despite only being in one
game at the time testifies to how much more Sonic is as a character
compared to his games. It goes along with your argument of Zelda being
able to SFF Metroid to death but Samus arguably being able to resist
SFF against Link.<br><br>Zelda &gt; Link<br><br>Samus &gt; Metroid<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/23/2006 2:09:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321907795">message detail</a>
 | #341</td></tr>
<tr class="even">
<td>
Point taken, but if that's the case, then I don't see how you could say
that Sonic 2 was SFF'd strongly by SMW when Mario's games
&gt;&gt;&gt;&gt; Sonic's games already.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/23/2006 2:10:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321907963">message detail</a>
 | #342</td></tr>
<tr class="even">
<td>
I don't see how you could argue that Link to the Past SFF'd Super Metroid when it already much stronger than it anyway.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/23/2006 2:14:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321908864">message detail</a>
 | #343</td></tr>
<tr class="even">
<td>
Oh, you mean two two games that were by the same company and were on
the same system, not to mention having other cases of SFF between
Metroid and LoZ/Mario I could point to?<br><br>Me either.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3292020&amp;board=8&amp;topic=29209811" class="name">LessThan3Presea</a> |
Posted 7/23/2006 2:16:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321909315">message detail</a>
 | #344</td></tr>
<tr class="even">
<td>
Yeah, like how Wind Waker SFF'd Metroid Prime, right?<br><br>Oh wait.<br><br>In other words, not everything holds up the same across the board. Saying "It didn't happen here!" doesn't disprove anything.<br>---<br>"A huge void in her heart. It is filled not by darkness, but kindness from others." - Presea Combatir, the Empty Soul</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/23/2006 2:19:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321909849">message detail</a>
 | #345</td></tr>
<tr class="even">
<td>
Tell me LoZ:WW &gt; LoZ:LttP and that MP is noticably stronger than SM.
Besides, there were still people who thought there was SFF in that
match.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3292020&amp;board=8&amp;topic=29209811" class="name">LessThan3Presea</a> |
Posted 7/23/2006 2:20:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321910088">message detail</a>
 | #346</td></tr>
<tr class="even">
<td>
<i>that MP is noticably stronger than SM</i><br><br>An arguable point due to, believe it or not, SFF. <br>---<br>"A huge void in her heart. It is filled not by darkness, but kindness from others." - Presea Combatir, the Empty Soul</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3292020&amp;board=8&amp;topic=29209811" class="name">LessThan3Presea</a> |
Posted 7/23/2006 2:29:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321912047">message detail</a>
 | #347</td></tr>
<tr class="even">
<td>
In any event, let's move on.<br><br>Final Fantasy/Mega Man Analyses! Whoo!<br>---<br>"A huge void in her heart. It is filled not by darkness, but kindness from others." - Presea Combatir, the Empty Soul</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/23/2006 2:29:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321912058">message detail</a>
 | #348</td></tr>
<tr class="even">
<td>
Heh...well-played.<br><br>Between the Top 100 List, knowing SM
was behind SFF, knowing MP was behind Starcraft, and knowing the
fanbase is fairly split about the 2D/3D issue, and this poll though:<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1528" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1528">http://www.gamefaqs.com/poll/index.html?poll=1528</a><br><br>I
think it's fair to say that neither one is a big favorite over the
other, but SM has the edge. To say MP would noticably be stronger than
SM would be an extreme call.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3232077&amp;board=8&amp;topic=29209811" class="name">DoABarrelSoul</a> |
Posted 7/23/2006 5:45:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321955763">message detail</a>
 | #349</td></tr>
<tr class="even">
<td>
Alright, just sent mine in. Sorry about the shortness, but I'm stuck at a relatives house. <br>---<br>The official "Nominate Fox McCloud for SC2K6" alt.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/23/2006 5:57:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321958631">message detail</a>
 | #350</td></tr>
<tr class="even">
<td>
<b>Ultima Division:</b> <i>Round 2 - Match 23</i> &#8211; (1)Final Fantasy vs. (4)Mega Man <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Final Fantasy</b><br>Round 1 &#8211; 85.98% vs. Diablo (14.02%)<br><br>Final Fantasy makes Diablo look like fodder&#8230;ouch.<br> <br><b>Mega Man</b><br>Round 1 &#8211; 58.12% vs. Mario Kart (41.88%)<br><br>In a hotly-debated match, Mega Man makes the Mario Kart supporters look bad.<br><br>LoZ in Round 1 &#8211; Dominant<br>Mario in Round 1 &#8211; Even more dominant<br>FF in Round 1 &#8211; The most dominant<br><br>LoZ in Round 2 &#8211; Dominant<br>SMB in Round 2 &#8211; Just as dominant<br><br>And
now it&#8217;s time for FF&#8217;s turn in Round 2. LoZ did well against MMX, and
SMB did just as well on WarCraft. Now it&#8217;s Final Fantasy&#8217;s turn to flex
its muscles. Now, I think MM is stronger than MMX and WarCraft, but FF
is also stronger than SMB and LoZ, so&#8230;yeah. MM will be lucky to avoid a
quadrupling.<br><br><b>Moltar&#8217;s Bracket Says:</b> Final Fantasy will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Final Fantasy: 80% - Mega Man: 20%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>Mega
Man beating Mario Kart was nice, but its reward was a round two clash
against the odds-on favorite to win this contest. The best that MM can
hope for is to prove that there is a chink in FF's armor. Personally, I
doubt this happens.<br><br>Prediction: Final Fantasy with 70.96%<br> <br><br><br><b>Soul&#8217;s Analysis</b><br><br>
I'm in a rush and not at home, so this will be pretty quick. FF =
Strongest series in the contest. MM is good, but won't be strong enough.<br><br><b>My prediction: FF wins with 78.99% of the vote.</b><br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>While
Mega Man did have an impressive first round win that crushed the
brackets and spirits (and, in my case, the account) of many, it's about
to run into an immovable wall. Apart from almost certainly being the
strongest contest entry we've ever seen, Final Fantasy had an
absolutely jaw-dropping Round 1 win against Diablo. As bad as this is
going to look, Mega Man is actually lucky that he gets to face the
beast early - it'll probably help him a bit in the X-Stats, if
anything. I'm not sure if even FF can manage to outdo Zelda's
performance against Mega Man X, but I've learned not to underestimate
the Big Three. Watch out for showers of blood.<br><br>Final Fantasy<br>+ Strongest game on this site<br>+ Several other very popular games<br>+ Spans several consoles and eras<br>+ It's the backbone of GameFAQs<br>+ Credibility up the wazoo<br>+ Ridiculous first round performance<br>- Nada<br><br>Mega Man<br>+ HOLY **** THOUSANDS OF GAMES (potentially)<br>+ Age<br>+ Credibility up the wazoo<br>- No SotN or WoW to anchor it<br>- It's all for naught<br><br>My prediction: Final Fantasy def. Mega Man (77-23)<br> <br><br><br><b>Mnm&#8217;s Analysis</b><br>  <br>Battle Music: Still More Fighting (FF7) <br><br>Well,
Mega Man got its chance to shine in this contest, and now it comes to
an end! Mega Man humbled me in the MM/MK matchup. But Mega Man has no
chance in this matchup. Final Fantasy is crushing everything in its
path to the finals. Mega Man's goal is to try to reach 30%. It
definitely ought to stand up better to FF than Mega Man X did with LoZ,
although it still could look pretty ugly&#8230; <br><br>Bracket: FF<br><br>Vote: FF<br><br>Prediction: FF with 73.25%</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">1</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=1">2</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=2">3</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=3">4</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=4">5</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=5">6</a></li>
<li>      7</li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=7">8</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=8">9</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=9">10</a></li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage7_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29209811&amp;page=6" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage7_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>