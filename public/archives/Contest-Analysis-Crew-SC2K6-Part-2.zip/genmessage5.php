<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">

<title>GameFAQs: Message List</title><link rel="stylesheet" type="text/css" href="genmessage5_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage5_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage5_files/bc.css"></head><body linkifytime="290" linkified="7" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage5_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage5_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29209811%26page%3D4"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<a href="http://adlog.com.com/adlog/c/r=10153&amp;s=657803&amp;t=2006.07.30.22.06.01&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=01c17-gne-ad544C8F1BE1597D6D/http://www.gamespot.com/pc/strategy/prisontycoon/index.html?q=prison%20tycoon" target="_blank"><img src="genmessage5_files/prison_leader.gif" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage5_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew - Part 2</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29209811&amp;page=4">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29209811" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">First
          Page</a> |
          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=3">Previous
          Page</a> |
          Page 5 of 10          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=5">Next
          Page</a>
          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=9">Last
          Page</a>
      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/20/2006 3:20:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321205324">message detail</a>
 | #201</td></tr>
<tr class="even">
<td>
Solid **** Factor.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29209811" class="name">UltimaterializerX</a> |
Posted 7/20/2006 6:57:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321258527">message detail</a>
 | #202</td></tr>
<tr class="even">
<td>
Fire Emblem's picture isn't any better.<br><br>~*ST*~<br>---<br><b>*<i>TRUE</i> RKO King of Board 8*</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/20/2006 6:57:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321258647">message detail</a>
 | #203</td></tr>
<tr class="even">
<td>
I dunno. That blue chick on the right looks pretty hot.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/20/2006 7:01:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321259482">message detail</a>
 | #204</td></tr>
<tr class="even">
<td>
<b>Snake Division:</b> <i>Round 2 - Match 20</i> &#8211; (3)Castlevania vs. (2)Kingdom Hearts <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Castlevania</b><br>Round 1 &#8211; 55.02% vs. Halo (44.98%)<br> <br><b>Kingdom Hearts</b><br>Round 1 &#8211; 73.12% vs. Harvest Moon (26.88%)<br><br>It&#8217;s
rare when a match occurs that completely changes my outlook on what&#8217;s
to come. Castlevania/Halo, was one of those matches. Remember that
match? The one where Castlevania took the lead, won the day vote over
Halo and easily won the match? Yep, that match opened my eyes to
something, and that is...<br><br>Hold that thought for a minute, first
let me talk about KH&#8217;s performance. Now, Sora and Kingdom Hearts have
never been known to blow anything out, even fodder. Sora could only get
70% on Agent 47, and KH could only get 73% on Harvest Moon. Still, Sora
did go on to beat Alucard last year, and now KH is looking to score
another win over the Castlevania series.<br><br>Now, why did
Castlevania win over Halo? It wasn&#8217;t because of just SotN. Even though
the Halo games are individually stronger, as a series, Castlevania has
got it beat. Castlevania needed the strength from all the games
spanning over it&#8217;s 20 year life-span. This is a SERIES Contest, and as
you can also see from Sonic and Mega Man winning their matches easy,
people are voting as if it is.<br><br>What does this mean? It means a
newer series with only a few games doesn&#8217;t look so hot in front of an
older series with a bunch of games. Scenario sound familiar? Yep, first
Castlevania/Halo and now, Castlevania/Kingdom Hearts.<br><br>I
originally had KH over Halo in my bracket, and now I even doubt that KH
will do as well as Halo against Castlevania. KH should do a bit better,
being Square, not Xbox and having a recent game, but I don&#8217;t know. I
won&#8217;t be surprised if KH does win (yay bracket), but I&#8217;m hoping on the
Castlevania bandwagon for this match.<br><br><b>Moltar&#8217;s Bracket Says:</b> Castlevania will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Castlevania: 52% - Kingdom Hearts: 48%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>Other
people might go really extensive in analyzing this, but I can explain
this one in very simple terms. From day one, I felt that Halo was
stronger than Kingdom Hearts. Castlevania <i>killed</i> Halo and
wouldn't even allow it to win the day vote. 10% is far too much ground
to make up for a series that I feel was weaker than the loser of that
upset.<br><br>KH is also in the same boat as Halo. Small series, a
recent smash hit sequel and overestimation abound as per said sequel.
And I wouldn't make the mistake of looking at Sora/Alucard to try
predicting this match, either; Castlevania the series seems to be <i>far</i>
stronger than Alucard the character, and I can't really say the same
about KH and Sora. KH may do better than Halo did, but at this point
I'd really be surprised if it won.<br><br>Prediction: Castlevania with 54.35% <br><br> <br> <br><b>Soul&#8217;s Analysis</b><br><br> <i>Castlevania defeated Halo with 55.02%<br>Kingdom Hearts defeated Harvest Moon with 73.12%</i><br><br>Alright! A match worthy of analysis! Final-****ing-ly.<br><br>Castlevania
pulled off the win of the contest last round. Alucard, Soma and crew
pulled off the upset of the round when it defeated Master Chief and his
flagship series with over 55% of the vote. Only 31% of the brackets
predicted that match right. I wish I could say that I was smart enough
to even think Castlevania could defeat Halo, but alas, the thought
never crossed my mind. To this day, I still don't understand how Halo
lost, but oh well. Not like I'm complaining, since Castlevania kicks
all sorts of ass!</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/20/2006 7:01:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321259664">message detail</a>
 | #205</td></tr>
<tr class="even">
<td>
Kingdom Hearts had a much easier match to call, and the predictions
showed. Although it had such an easier match, it didn't put up strong
numbers against a fodderific series like Harvest Moon. That could mean
either one of two things: Harvest Moon had some hidden strength and we
all underestimated it, or Kingdom Hearts is being overestimated to all
hell here. It could be either or both, but I'm betting it's the latter.<br><br>So
far, all we've seen from Kingdom Hearts is one lousy performance after
another. Kingdom Hearts almost lost to Soul Calibur in the games
contest a few years back, and now not even getting 75% on Harvest Moon.
In the top 100 games, Kingdom Hearts finished in 16th, one lower then
Castlevania's top game Symphony of the Night. Therefore, it should be
an easy match to call right? Castlevania has this match won, right?<br><br>Not so fast Bil... I mean, umm... Jimmy. &gt;_&gt; (Damn you Moltar!)<br><br>There
are a few wildcards to look at. Kingdom Hearts just had a new game come
out. I believe it's called Kingdom Hearts 2. That generated a lot of
interest for the series, as can be seen by the time it remained number
1 in FAQs and message board use. Also, let's not forget that Sora
already defeated Alucard last year in the summer contest. Therefore,
Kingdom Hearts has this match won, right?<br><br>Not so fast Jimbo my boy.<br><br>Sure,
all those factors could give Kingdom Hearts an edge over Castlevania,
but we're forgetting one major factor here. It's called "the voters
don't give two ****s about the past results and vote for whoever they
want" factor (and I'm not going to abbreviate it either, so piss off).
There is a new voting pool on this site, as evidenced by just about
every match for the past year or so. How else would you explain
Castlevania beating Halo?<br><br>Basically, I'll give it to you
straight. Castlevania is going to win it. Not because of its killing of
Halo compared to KH's underperformance. Not because of Alucard, Julius
and Soma kicking all sorts of ass. No, none of those. The real reason
why Castlevania is going to win?<br><br>Ask Alucard.<br><br><b>My Prediction: Castlevania wins with 52.50% of the vote.</b><br> <br><br><br><b>Leon&#8217;s Analysis</b><br> <br>I&#8217;ll
be honest: I have no idea what to think of this match. I really don&#8217;t.
I don&#8217;t see anything from either&#8217;s first round match that makes me
definitively lean to one or the other. Most of this write-up will
probably be me trying to convince myself who will win.<br><br>On the
one hand, Castlevania was very impressive against Halo, beating it with
55%. It effectively neutralized the infamous XBox day vote and didn&#8217;t
surrender more than a handful of five minute updates (in which Halo
didn&#8217;t win by more than 10 votes or so), winning by about 11,000 votes.
Castlevania proved that it was far more than just Symphony of the Night
and could draw a fair amount of strength from the rest of the series.
Exactly how much has yet to be seen, but this match has set the trend
of long-running, well-established series with a lot to draw from in
terms of number of games and fanbase diversity doing much better in
comparison to relatively new series with few games and large fanbase
overlap. This match should give us an even better idea of how much this
theory holds up.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/20/2006 7:02:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321259729">message detail</a>
 | #206</td></tr>
<tr class="even">
<td>
On the other hand, Kingdom Hearts disappointed by general board
expectations, but what else is new, right? We tend to overestimate its
strength (or underestimate the strength of its opponent) every time. It
was expected to have a good shot at the Sweet Sixteen in the Games
Contest (and perhaps a sexy upset pick for the Elite Eight), but then
flat out bombed by needing a comeback to beat Soul Calibur before
becoming the only effortless win that StarCraft had. Then last year,
Agent 47 was supposed to be &#8220;Neo Tanner,&#8221; but Sora struggled even to
get 70% on him, but we underestimated the Hitman series there. In a
very similar fashion, Kingdom Hearts failed to triple Harvest Moon, a
series many were expecting to be one the weakest in this contest. Once
again, I think this is a matter of underestimating the opponent, and I
admit to doing the same. I had no idea that Harvest Moon had a game
that sold nearly half a million. If I had known that beforehand, the
results would not have surprised me that much. You&#8217;ve also got several
proponents who maintain that Kingdom Hearts is incapable of blowing
anything out, regardless of weakness, though I don&#8217;t particularly buy
that.<br><br>Come
to think of it, this scenario sorta reminds me of the Games Contest.
There was a lot of hype surrounding the potential Halo/Kingdom Hearts
matchup, but then the former was upset in one of the biggest first
round upsets ever (in terms of brackets busted) and the latter
disappointed general expectations. And yet, despite this, the majority
of the board remained very confident that Kingdom Hearts was going to
beat the upstart underdog anyway (I should know. I was one of those who
thought StarCraft had no chance), even if there is every indication
that the opposite could happen. Really, the main difference is that
Kingdom Hearts didn&#8217;t just squeak by its opponent (heck, if it had,
this match wouldn&#8217;t be debatable, but now I&#8217;m just rambling).<br><br>Halo
proved to be stronger than Kingdom Hearts before, but will it now? I&#8217;ll
say that it won&#8217;t be. I think Kingdom Hearts II (and maybe even Chain
of Memories, since it did make the series multiplatform, though I
wouldn&#8217;t expect this to do THAT much) did more for its series than Halo
2, at least at this point in time. It&#8217;s still the biggest game on the
site, it&#8217;s on the most widely owned console, and it&#8217;s developed by one
of the top two companies. Plus, I think it actually expanded the
fanbase somewhat, as you&#8217;re actually seeing Kingdom Hearts and Chain of
Memories increase their sales recently. <br><br>So&#8230;will there be
enough of a gap between Halo and Kingdom Hearts to catch Castlevania?
You&#8217;ve read this far for me to say&#8230;I still have no idea. I feel like
that episode of &#8220;The Simpsons&#8221; where it&#8217;s up to Homer to save
Springfield from a nuclear meltdown, and he has no idea what to do.
Then he just closes his eyes, does a game of eeny-meeny-miny-moe, and
then pushes a button. As a matter of fact, that sounds like a good
idea. Here&#8217;s hoping I can &#8220;pull a Homer.&#8221;<br><br>*closes eyes*<br><br>Eeny&#8230;meeny&#8230;miny&#8230;moe&#8230;<br><br><i>Leonhart&#8217;s Prediction</i>: <b>Castlevania with 52.41%</b><br><br><br><br><b>HM&#8217;s Analysis</b><br> <br><b>Castlevania</b><br><br><i>Previous Matches :</i><br><br>Castlevania &#8211; 55.02% -- 61,076<br><br>Halo &#8211; 44.98% -- 49,930 <br><br><b>Kingdom Hearts</b><br><br><i>Previous Matches :</i><br><br>Kingdom Hearts &#8211; 73.12% -- 81,735<br><br>Harvest Moon &#8211; 26.88% -- 30,051 <br><br>Well,
you won&#8217;t find many people saying they expected this match to happen,
and I happen to be one of them. The night leading up to the
Castlevania/Halo match, I was rooting for Castlevania to pull the
upset, but I never figured it would really be something that would
happen. Interestingly, the one time I deviated from the idea that a
long running, established series would do better than was giving credit
for, it cost me a point. I chose Sonic over SSB and Mega Man over Mario
Kart, but never followed through with Castlevania.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/20/2006 7:02:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321259890">message detail</a>
 | #207</td></tr>
<tr class="even">
<td>
In the previous round, Castlevania totally shocked most of the Crew and
the Stats topic by not only beating Halo but also winning the day vote.
It built up a pretty large lead over the night &#8211; 5,000 before the
morning/day vote kicked in &#8211; and continued to build that lead into the
day. The only time that Halo was even in the lead was at the first
freeze. It was basically all Castlevania from beginning to end. It does
make sense why Castlevania won the day vote and pretty much controlled
the match &#8211; it has history, namesake, and a crapload of games on
practically every console released. Halo was limited to merely the
Xbox, a system GameFAQs does not even have 50% ownership, and only had
two games in its series. Pretty easy to see why Castlevania won in
hindsight, but still impressive regardless. Many of the reasons it won
here should translate over to its match with Kingdom Hearts, too. <br><br>Kingdom
Hearts, on the other hand, was rather unimpressive in its match against
Harvest Moon. Things were not looking good when Kingdom Hearts failed
to even triple what was likely a very fodderific series. It is possible
that we underestimated Harvest Moon, but even taking that into
consideration, Kingdom Hearts still did not impress. The one positive
thing about the match is the vote totals, which were the highest at the
time, and the individual vote total for Kingdom Hearts, which topped
80,000. It may not be the biggest advantage, but it&#8217;s something. The
accusation that newly established series are weaker than we&#8217;re
suspecting may hold some truth. Kingdom Hearts does only have three
games in its series, all from this generation. That might very well
spell trouble against Castlevania. <br><br>For this match, I feel as
though Castlevania is going to be able to pull this one off in a close
one. As with its match against Halo, it has the advantage of being on
multiple consoles going from the NES to PS2. It hits pretty much every
system you can think of and the games are <i>good</i>, which is
definitely an added benefit. It is entirely possible that Symphony of
the Night could beat the original Kingdom Hearts, too, which should
help things out for Castlevania. It has the diversity necessary to win
this match and it has the series history on top of that. <br><br>Kingdom
Hearts is a new franchise that only got jumpstarted this generation.
Some people want to accuse newer games of flopping because of not
having an established history, and while there is some truth to that,
it does not seem to really apply here. Kingdom Hearts has the added
benefit of having the most popular game on the site right now by far in
Kingdom Hearts II. It is likely that it boosted the series as a whole
up quite a bit, which should help it overcome the problem of being
overrated by StarCraft, but it is still at a disadvantage against
Castlevania. It is something to note that Kingdom Hearts has almost
always ranked below Halo in the stats, whether it is a Games Contest, a
Character Battle, or even the Top 100 List. Kingdom Hearts II should
help it outdo Halo, but I cannot imagine it being by much. <br><br>For
the most part, Castlevania has all the necessary things needed to pull
this match off. It already showed it can take the day vote, it showed
it has the power to take down a big casual franchise, and it clearly
has the support of all its other games outside of SotN, which I
initially doubted. Kingdom Hearts is not going to just roll over and
die, and if it won, I wouldn&#8217;t be too terribly surprised given Kingdom
Hearts II. But I&#8217;m rooting for and expecting a close Castlevania
victory, giving us an all Konami division final (WOO!) <br><br><b>Aitch Emm&#8217;s Bracket :</b> Kingdom Hearts<br><br><b>Aitch Emm&#8217;s Prediction :</b> Castlevania &#8211; 53% ; Kingdom Hearts &#8211; 47%<br><br><b>Aitch Emm&#8217;s Vote :</b> Castlevania</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/20/2006 7:03:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321260062">message detail</a>
 | #208</td></tr>
<tr class="even">
<td>
<b>Yoblazer&#8217;s Analysis</b><br> <br>Hmm... seeing as how my three
longest analyses are my three contest losses, I should probably shorten
things up from now on. Also, since my bracket is already done, there's
no reason (other than foolish pride) for me to stick with it in the
face of solid evidence.<br><br>For the most part, this contest has thus
far gone to the old timers. While Grand Theft Auto, Devil May Cry, and
Halo have been stinking it up, Castlevania, Mega Man, and the other
gray-haired heavy hitters have brought their A games. Now, Kingdom
Hearts has a few very big disadvantages it must overcome to get this
one. For starters, it's essentially a two-game series. I'm not
insulting Chain of Memories, but everyone knows where this series gets
its strength. Also, unless we count Fire Emblem's U.S. history, KH is
actually the youngest series in this contest. Hell, even Halo has
nearly a year on it. It's very young and green, but it does have two
very popular games. Kingdom Hearts' ace in the hole, of course, is the
recently released Kingdom Hearts II. This fantastic game has been
GameFAQs' most popular for almost four months. It's the reason many of
us, myself included, pictured the Square-Disney hybrid doing so well.
After what we've seen so far, can that red-hot recency earn KH the win
over a series as credible and established as Castlevania? I have my
doubts.<br><br>Castlevania has already shown us what it can do. It has
shown us that people care enough to put it over Halo without trouble.
Its central game, Symphony of the Night, has a legion of devoted fans,
and it's obvious now that it was heavily underrated in 2004. There are
several smaller Castlevania titles, spread throughout many systems and
eras, to help the series along. The series also carries one of the most
well known and respected names in the gaming industry; that can never
hurt.<br><br>Do I think Kingdom Hearts is stronger than Halo? Yes. Do I
think it's strong enough to swing the 10% that Castlevania held over
Halo? Could be, but I'm doubting it at this point. This one should be
really close, but the current evidence points toward Castlevania, so
I'm going against my bracket and letting it ride on the circle of the
moon (lol).<br><br>Castlevania<br>+ Lots of games<br>+ Spans many systems and eras<br>+ Strong main game<br>+ Great performance less than two weeks ago<br>- Kingdom Hearts (probably) has two stronger games<br><br>Kingdom Hearts<br>+ Two very strong games<br>+ Most popular new release on the site<br>- Only three games (only two of which have actual strength)<br>- It's a rookie<br>- Pretty blah performance less than two weeks ago<br><br>My prediction: Castlevania def. Kingdom Hearts (52-48)<br> <br><br><br><b>Mnm&#8217;s Analysis</b><br>  <br>Battle Music: The 13th Dilemna (KH2) <br><br>Okay,
so what was initially supposed to be a nice, detailed analysis of KH
vs. Halo has been reduced to a quick analysis of Castlevania vs. KH.
Not that I don't care about this match or anything, but I don't have
time anymore for lengthy analyses! It's a shame, because I absolutely
adore both series and <i>could</i> write on forever about each of them. <br><br>Anyways,
basically this match will be a test to how strong and dedicated the
Square fanbase is on this site. No RPG outside of Final Fantasy has
impressed in this contest at <i>all</i>. Castlevania also proved that
it is a legit power in this contest as it easily dispatched Halo's best
effort. The Castlevania/Halo matchup proved once and for all that
Castlevania is <i>much</i> more than Symphony of the Night. That could
prove fatal for Kingdom Hearts. Kingdom Hearts only chance in this
match is if Final Fantasy lends some of its power to Kingdom Hearts. Of
course, with Kingdom Hearts not even being able to triple Harvest Moon,
it <i>still</i> may not be enough to topple the Castlevania franchise.  Castlevania's Cinderella run lives on! <br><br>Bracket: Kingdom Hearts<br><br>Vote: Castlevania<br><br>Prediction: Castlevania with 52.14%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/20/2006 7:04:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321260190">message detail</a>
 | #209</td></tr>
<tr class="even">
<td>
<b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Castlevania<br>Earlier this contest:<br>---CV - 55.02% on Halo<br>---KH - 73.12% on Harvest Moon<br>Top 100 List comparison:<br>---C:SotN - #15<br>---KH - #16<br>Best Game Ever x-stat comparison:<br>---C:SotN - 20.27% (was behind GE007/LoZ:OoT)<br>---KH - 34.7% (was behind Starcraft)<br><br>Well,
most people are surprised but happy to see Castlevania make it to the
second round, and it's hard to blame them (though Halo got my vote).
Kingdom Hearts making it here was...ya know, <i>planned</i> from the
beginning, so this will be a fun clash to see which series gets the
honor of being potentially-SFF'd by Metal Gear next round. Here's what
I'm looking at for this battle though:<br><br>---&gt; One big downfall
most of us failed to recognize (enough) is that Halo's such a new
series...but KH is over a year younger than Halo is, so there's a knock
against it.<br>---&gt; According to the Top 100 List, Halo (#9) &gt;
C:SotN (#15) &gt;= KH (#16). If this has any merit, then there's an
advantage CV has over KH that it didn't have for Halo -- I would think
both Halo and Halo 2 could beat C:SotN, but the overlap for those two
is huge. Meanwhile, if GE/LoZ:OoT had enough SFF and KH gained alot
stat-wise from being behind Starcraft, then the Top 100 List could be
justified there and C:SotN would actually be stronger than one of KH's
console games (C:SotN &gt; KH:CoM is an unproven fact). Even if that is
the case, people still like to discredit C:SotN's #15 for having a
dedicated fanbase...but since so many of us users participated in it,
you cannot tell me Board 8 didn't have a part in over-rating KH either,
so they're probably close to even.<br>---&gt; KH2, while the current
GotY it seems, probably hasn't been played enough here to beat C:SotN
yet (if ever, who knows?). You can't ignore it's the most recent huge
hit, but I doubt it's outdoing many CV fans' love for C:SotN, at least
not yet.<br>---&gt; CV beat Halo worse than I would have thought KH could have beat it.<br><br>You
can't rule out KH, but the main things it has going for it that Halo
doesn't is a big recent hit and a handheld game. Although I have KH
&gt; Halo in my bracket, I'm going against it in my analysis for the
first time ever.<br><br>Castlevania wins with 55.12%<br> <br><br><br><b>Lopen&#8217;s Analysis</b><br> <br>Halo
will win this match, and her&#8230; eh&#8230; wha? Okay, well, Halo isn't here, but
this doesn't make my analysis of the match really all that different.
I'd said last round that I believed Castlevania was the more dangerous
foe for Halo, I just underestimated it. I think Kingdom Hearts would
lose to Halo, and here's why, in enumerated list form!:<br><br>1. In
the 2004 games contest, Halo looked better than Kingdom Hearts against
the very same opponent. Not by a landslide, but by a few %. Halo also
outdid KH on the top 100 list, the same top 100 list I feel was skewed
a bit towards the Halo hating Board 8, and Halo 2 was one of the two
write-ins to even get on there.<br><br>2. Since that point, Halo's
become more accepted. X-Box hate has slowly been going down&#8230; and you
can't have an X-Box without Halo. Trust me on that&#8230; the Box needs Halo
to even run.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3251974&amp;board=8&amp;topic=29209811" class="name">trannyscience</a> |
Posted 7/20/2006 7:04:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321260351">message detail</a>
 | #210</td></tr>
<tr class="even">
<td>
a sweep?!<br>---<br>yzzyx</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/20/2006 7:05:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321260460">message detail</a>
 | #211</td></tr>
<tr class="even">
<td>
3. Halo 2 meant <i>so</i> much more for the Halo series than
Kingdom Hearts 2 did for the KH series. Just generally, in life. I
mean, the hype for Halo 2 was ab-freaking-surd. It probably outsold
KH2's total sales in one day. (Yes I'm exaggerating&#8230; back off!) This
doesn't necessarily translate to GameFAQs, but I don't see why it
shouldn't at least somewhat. KH2 doesn't exactly have the most
impressive of resumes, anyway. Only ~27% thought it was the best game
of this year <i>so far</i> when against&#8230; lackluster opponents. Sure,
the play rate might've gone up, but Halo 2 managed to get around that
against GTA: SA and MP2, with about as much playtime to be had for it
at the polling point.<br><br>There's also one important thing to consider: The nature of the Halo fan base. We vote it over pretty much <i>anything</i>,
at least that's what Master Chief's showings seem to imply. And I'd
have guessed that even without seeing Master Chief, just by casual
observation of the fans. What does that mean? That means even if KH is
Halo's equal, or Halo's superior, it can still do crappier against
Castlevania because of the support falling out from under it more
easily.<br><br>Here's the next casualty to the recent series flopping
spree, right here. Castlevania's magnificent iconia is gonna make
Kingdom Hearts look a little silly here. Poor KH. I'm <i>probably</i> gonna vote Castlevania here, but I love you too!<br><br><b>Lopen's Prediction:</b> Castlevania with 60.07%.<br> <br> <br><br> <br>Comments:
Upset fever has hit the Crew. CV's performance last round has convinced
us that it does have a very good chance of beating KH, and that's what
we're predicting.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2568612&amp;board=8&amp;topic=29209811" class="name">Draco1214</a> |
Posted 7/20/2006 7:06:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321260581">message detail</a>
 | #212</td></tr>
<tr class="even">
<td>
WTF @ Lopen's prediction.<br>---<br><b><i>Organization XIII - Number III - Xordac</i></b><br>Currently Playing - Suikoden V, Capcom vs. SNK 2</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3251974&amp;board=8&amp;topic=29209811" class="name">trannyscience</a> |
Posted 7/20/2006 7:07:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321260806">message detail</a>
 | #213</td></tr>
<tr class="even">
<td>
his Halo got beat, so he just ups Castlevania's strength rather than lowering Halo's. same with Sonic.<br>---<br>yzzyx</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/20/2006 7:08:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321261195">message detail</a>
 | #214</td></tr>
<tr class="even">
<td>
So...I'm stuck between 52.14% and 52.50%?<br><br>Great.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1288566&amp;board=8&amp;topic=29209811" class="name">gtonizuka49</a> |
Posted 7/20/2006 7:12:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321261981">message detail</a>
 | #215</td></tr>
<tr class="even">
<td>
Let's hope for a real barn burner. Either way, tomorrow's match is a win/win for me.<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/20/2006 7:12:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321262002">message detail</a>
 | #216</td></tr>
<tr class="even">
<td>
Did you people even <i>read</i> my analysis? Call it blatant
fanboyism if you want... but why should I doubt that Halo would beat
Kingdom Hearts any more than I did when the contest started? There's
been nothing to show for it. Hell, I even gave you people a reason that
Halo would outdo KH <i>even if</i> they were in all other ways equal!  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/20/2006 7:49:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321270523">message detail</a>
 | #217</td></tr>
<tr class="even">
<td>
Moltar, I sent you all of my analyses through Zelda/Metroid. Let me know if you got them.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/20/2006 7:50:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321270851">message detail</a>
 | #218</td></tr>
<tr class="even">
<td>
...<br><br>Everyone picked Castlevania? &gt;_&lt;!<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29209811" class="name">UltimaterializerX</a> |
Posted 7/20/2006 7:52:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321271315">message detail</a>
 | #219</td></tr>
<tr class="even">
<td>
Yep, so of course Kingdom Hearts is going to kill in this match.<br><br>~*ST*~<br>---<br><b>*<i>TRUE</i> RKO King of Board 8*</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/20/2006 7:53:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321271565">message detail</a>
 | #220</td></tr>
<tr class="even">
<td>
*sighs*<br><br>I might have gone with Kingdom Hearts for the sake of it if I had known everyone else was going to pick Castlevania.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=640243&amp;board=8&amp;topic=29209811" class="name">Big Bob</a> |
Posted 7/20/2006 7:54:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321271841">message detail</a>
 | #221</td></tr>
<tr class="even">
<td>
*jaw drops at the whole analysis crew*<br><br>NONE of you predicted Kingdom Hearts?  Castlevania may be stronger than we thought, but KH still has a chance to win this!<br><br>And
considering KH/HM had the highest vote totals at that point in the
contest, I think HM may not be as fodderrific as we thought. I'm still
supporting KH here.<br>---<br>This space reserved for a new sig.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/20/2006 7:57:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321272343">message detail</a>
 | #222</td></tr>
<tr class="even">
<td>
Yeah, it <i>is</i> kinda sad.  You're telling me <i>none</i> of
you KH pickers expected KH to beat Halo by more than 55%? Because I
definitely expected Halo to beat KH by more than that, if only by
slightly more. <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/20/2006 7:58:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321272727">message detail</a>
 | #223</td></tr>
<tr class="even">
<td>
Well, it's more of what Kingdom Hearts did against Harvest Moon that
has me doubting it moreso than my pre-contest expectations of what it
would do to Halo.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/20/2006 8:09:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321275308">message detail</a>
 | #224</td></tr>
<tr class="even">
<td>
Hey Leon, have you got around to writing that heroes/zeroes thing for the last round? <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/20/2006 8:12:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321275905">message detail</a>
 | #225</td></tr>
<tr class="even">
<td>
Nah, that's usually Slow's gimmick, and he didn't do it.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/20/2006 8:13:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321276137">message detail</a>
 | #226</td></tr>
<tr class="even">
<td>
Ah right. Ok then.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29209811" class="name">Tatsumaki Senpuu</a> |
Posted 7/20/2006 8:38:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321282337">message detail</a>
 | #227</td></tr>
<tr class="even">
<td>
I'm liking where I sit right now. I only wish Harrich would have gone under 53%!<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29209811" class="name">UltimaterializerX</a> |
Posted 7/20/2006 8:39:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321282584">message detail</a>
 | #228</td></tr>
<tr class="even">
<td>
<i><b>From Lopen Posted 7/20/2006 8:57:01 PM #222</b></i><br><i>Yeah, it <i>is</i> kinda sad.  You're telling me <i>none</i> of you KH pickers expected KH to beat Halo by more than 55%?</i><br><br>I didn't expect KH to win that at all, hence my short writeup.<br><br>~*ST*~<br>---<br><b>*<i>TRUE</i> RKO King of Board 8*</b><br>Currently Playing:  Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/20/2006 8:52:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321285875">message detail</a>
 | #229</td></tr>
<tr class="even">
<td>
I like my positioning in this one.  Come on, CV...don't fail me now.  Cost me more points!<br><br>I agree with the sentiment that this shouldn't have been a sweep...but, ya know...I know <i><b>I</b></i> am not switching.  Anybody else, go ahead, but I'm happy right here, heh.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=304351&amp;board=8&amp;topic=29209811" class="name">Mac Arrowny</a> |
Posted 7/20/2006 8:54:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321286274">message detail</a>
 | #230</td></tr>
<tr class="even">
<td>
<i>Yep, so of course Kingdom Hearts is going to kill in this match.</i><br><br>Just like Elder Scrolls killed Street Fighter, mirite? &gt;_&gt;<br>---<br>Pity for the guilty is treason to the innocent.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29209811" class="name">BlAcK TuRtLe</a> |
Posted 7/20/2006 8:54:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321286472">message detail</a>
 | #231</td></tr>
<tr class="even">
<td>
Wow, the whole crew went with CV on this one eh?<br><br>Kind of makes my pick a little less unique.<br><br>55.03%!<br><br>.01% higher than against Halo FTW!<br><br><br><b>TuRtLe</b><br>~~~<br>Like Darth Maul, the bastard child of Michael Flatley and Hellboy. -trancer1</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3052691&amp;board=8&amp;topic=29209811" class="name">satai_delenn</a> |
Posted 7/20/2006 9:31:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321295108">message detail</a>
 | #232</td></tr>
<tr class="even">
<td>
So...if Metal Gear is only getting ~65% on Fire Emblem...will it beat
Castlevania? (I think if KH wins tomorrow, it will lose to Metal Gear.
But I'm with you guys, I think Castlevania beats KH.)<br><br>My first instinct is to say yes, Metal Gear &gt; Castlevania, but...the more I think about it, the more I'm not sure. &lt;_&lt;<br>---<br>"I know now, without a doubt. Kingdom Hearts...is waffles!"<br>I'll Avada Kedavra ya into a hearse! -Ed Bellis...thank you, B8 rap battle</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29209811" class="name">Tatsumaki Senpuu</a> |
Posted 7/20/2006 10:09:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321304909">message detail</a>
 | #233</td></tr>
<tr class="even">
<td>
Metal Gear is in no danger of losing before its match against Zelda.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/20/2006 10:19:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321307384">message detail</a>
 | #234</td></tr>
<tr class="even">
<td>
One thing that interests me in this match: assuming Halo and KH are
dead-even, I still wonder how the percentages go...since Halo was on
one system that I believe no CV game ever visited, while KH is on two
systems, both of which CV has visited.<br><br>Don't call it SFF, but I'm intrigued.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/20/2006 10:44:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321313598">message detail</a>
 | #235</td></tr>
<tr class="even">
<td>
<i>So...if Metal Gear is only getting ~65% on Fire Emblem...will it beat Castlevania? </i><br><br>Oh,
yeah... I started the Castlevania &gt; Metal Gear bandwagon when Fire
Emblem was only getting 32% on it. Now it's even worse. Basically,
unless Castlevania loses, or <i>squeaks</i> by KH, I'm thinking Castlevania is looking really good going into face Metal Gear.  Like it or not, there <i>are</i> advantages Castlevania has going into that matchup aside from a better looking contest resume.  <br><br>But,
I also said in my MG/FE writeup that FE could be in a way like a "mini
Halo". I've seen how rabid the FE fans seem to be. Or maybe there's
another reason. Can't condemn something just because it isn't winning
by as much as we'd like to see. Thing is I'd had the hunch that
Castlevania would at least keep it close for a while. <br>---<br>Raiden is still [<i>!!</i>] nominations short!  <i>Oh, no, I'm telegraphing my next bold prediction for my topic!</i><br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3201793&amp;board=8&amp;topic=29209811" class="name">Ed Bellis</a> |
Posted 7/20/2006 10:47:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321314369">message detail</a>
 | #236</td></tr>
<tr class="even">
<td>
XD<br><br>This is why I need to be on the Analysis Crew!<br>---<br>This was Ed Bellis.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/20/2006 10:51:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321315414">message detail</a>
 | #237</td></tr>
<tr class="even">
<td>
Yeah, I was also kinda surprised we all went with Castlevania. Then
again, it has all the right signs going for it at the point. KH still
has a chance, but the odds favor CV more at this point, which is why I
think it was a clean sweep.<br><br>And Metal Gear looks to beat either CV or KH comfortably at this point. (Konami beatdown or Snake/Sora II)<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Metal Gear vs. Fire Emblem - Bracket: <b>MG</b> - Vote: <b>MG</b> (18/20)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3052691&amp;board=8&amp;topic=29209811" class="name">satai_delenn</a> |
Posted 7/21/2006 12:53:30 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321343656">message detail</a>
 | #238</td></tr>
<tr class="even">
<td>
Hmm. At this point I'd rather KH win this one (even aside from personal
bias), because Metal Gear&gt;KH seems obvious but Metal
Gear&gt;Castlevania worries me...<br>---<br>"I know now, without a doubt. Kingdom Hearts...is waffles!"<br>I'll Avada Kedavra ya into a hearse! -Ed Bellis...thank you, B8 rap battle. <i>Heh heh, my evil plan is working...! &gt;_&gt;</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=439221&amp;board=8&amp;topic=29209811" class="name">Canadian Carnage</a> |
Posted 7/21/2006 12:55:15 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321343960">message detail</a>
 | #239</td></tr>
<tr class="even">
<td>
If Castlevania wins, Its a toss up between Metal Gear and it.<br><br>If KH wins... well Metal Gear is going to blow it out of the water with a 20 split lol.<br><br><br>---<br>"<b>NO CLOUD IS NOT IN THE GAME, GO AWAY</b>" -  pictish freak</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29209811" class="name">DaruniaTheGoron</a> |
Posted 7/21/2006 1:14:41 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321347306">message detail</a>
 | #240</td></tr>
<tr class="even">
<td>
lawl @ Lopen. KH: Square + RPG + Recent smash hit = no way it could
have lost by that much. Sure the Halo hate has died down a bit at
GameFAQs, but it's still HALO for god's sake. It's one of the most
hated games here.<br>---<br>...little Weezing it's gonna stand up against my ****in' Charizard? Just get back on your bike and keep <br>pretending to be cool with your lame ass mohawk ****er. - phoenix1487 <b><i>Sp2k6: 20/22</i> tied for 1990th</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/21/2006 1:40:40 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321351444">message detail</a>
 | #241</td></tr>
<tr class="even">
<td>
Hindsight is 20/20, Goron.  I'm sure you might've said similar things about other matches.  <br><br>"Lawl
2x GotY contention no way could Pokemon make it that close", or maybe
"Lawl D2 is huge no way could FF blow it out that bad". <br><br>So I horribly botched <i>two</i>
predictions this round! It surely won't be my last botching, I'm sure!
And hey, I aced two as well! Either way, this performance is
disappointing me. I'm back to thinking Castlevania will be making
itself look good at best. Who knows? It could storm the day vote! It
beat the mighty <i>Halo</i> day vote after all!  <br><br>(No, not enough to make me win this point... though that would be <i>awesome</i>!)<br><br>Heck, I wouldn't really mind KH coming back and making us all look like fools, either.  I love both series.  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <i>Who am I to try and stop a finely crafted evil plan?</i><br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29209811" class="name">Tatsumaki Senpuu</a> |
Posted 7/21/2006 1:50:02 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321352829">message detail</a>
 | #242</td></tr>
<tr class="even">
<td>
Are people actually <i>supporting</i> this Castlevania over Metal Gear nonsense? Come now -- that match is <i>easy</i>. Metal Gear with ease.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29209811" class="name">Lugia2</a> |
Posted 7/21/2006 5:37:57 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321372616">message detail</a>
 | #243</td></tr>
<tr class="even">
<td>
Nice to see the contenders staying close.  Then again, this whole contest has been insane.<br><br>I
mean, Pokemon has been screwing around our expectations for two
matches, first for killing SO, then for staying somewhat close to
Metroid.<br><br>Then comes Castlevania.  You know what happened.<br><br>Warcraft beating GTA- with little cheating, just mass-rallying.<br><br>FF
killed Halo, getting guys like Moltar to decide the entire contest due
to a single match. (Which is odd. Moltar isn't the type to say things
like ZELDA BEAT VIVI!!!! zELDa&gt; Snake LOLOLOLO! Same with Tifa and
"Cloud like numbers," of course) 'Course, Zelda shut up SOME of those
guys later on.<br><br>MM v MK made all the debate around it seem unnecessary.<br><br>And now the one match no one expected to even occur-KH V CV, within 800 votes of eachother.<br><br>Hopefully, our fun won't end with this round...<br><br>Come on Zelda V FF!  <br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/21/2006 3:05:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321457511">message detail</a>
 | #244</td></tr>
<tr class="even">
<td>
Metal Gear.........65.23% 74017<br>Fire Emblem......34.77% 39457<br>TOTAL VOTES...............113474<br><br>82.08% of the brackets predicted this match correctly.<br><br>To
no one's surprise, Metal Gear beats Fire Emblem. FE did do better than
many expected though. I mean, from this match it looks to be more than
just fodder! Or perhaps, MG isn't as strong as we thought...either way,
FE &gt; SC = SH doesn't seem right to me.<br><br>Today, you would think if Castlevania beat Halo's day vote, it could beat KH's. Guess not.<br><br>Soul - 4<br>HaRRich - 3<br>Moltar - 3<br>Lopen - 2<br>Ulti - 2<br>HM - 2<br>Yoblazer - 1<br>Leon - 1<br>Mnm - 0<br><br>HaRRich gets the point easy with his low pick.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Castlevania vs. Kingdom Hearts - Bracket: <b>KH</b> - Vote: <b>KH</b> (20/22)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/21/2006 3:09:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321458418">message detail</a>
 | #245</td></tr>
<tr class="even">
<td>
+9 HaRRich<br>+8 Ulti<br>+7 Leon<br>+6 Yo<br>+5 Moltar<br>+4 Mnm<br>+3 Soul<br>+2 HM<br>+1 Lopen<br><br><b>The Rankings</b> (Through Metal Gear/Fire Emblem)<br>1. Master Moltar (93)<br>2. UltimaterializerX (82)<br>3. XxSoulxX (81)<br>4. Leonhart (73)<br>5. Lopen (71)<br>6. yoblazer33 (68)<br>7. HaRRicH (64)<br>8. Heroic Mario (57)<br>9. therealmnm (52)<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Castlevania vs. Kingdom Hearts - Bracket: <b>KH</b> - Vote: <b>KH</b> (20/22)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29209811" class="name">UltimaterializerX</a> |
Posted 7/21/2006 3:13:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321459509">message detail</a>
 | #246</td></tr>
<tr class="even">
<td>
Ulti: Always close, but never getting points outright.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/21/2006 5:25:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321489093">message detail</a>
 | #247</td></tr>
<tr class="even">
<td>
Ha ha ha... we're the worst Analysis Crew <i>ever</i>.  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=863018&amp;board=8&amp;topic=29209811" class="name">Janus5000</a> |
Posted 7/21/2006 5:28:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321489810">message detail</a>
 | #248</td></tr>
<tr class="even">
<td>
It's an improvement from the last CV match.<br>---<br>"Those who cast the vote decide nothing. Those who count the vote decide everything."</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3005840&amp;board=8&amp;topic=29209811" class="name">tehduck16</a> |
Posted 7/21/2006 5:54:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321495740">message detail</a>
 | #249</td></tr>
<tr class="even">
<td>
&gt;_&gt; You guys shouldn't do sweeps on the iffy matches.<br>---<br>*-*KINGDOM HEARTS ROAD TO THE FINALS*-*<br>Victim #2: Castlevania.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29209811" class="name">Lugia2</a> |
Posted 7/21/2006 6:51:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321508344">message detail</a>
 | #250</td></tr>
<tr class="even">
<td>
tehduck, they didn't mean to.  At least one of them said he would jump if he knew it would be a CV sweep.<br><br>Oh, and I thought I was kidding.  I guess my bracket is still down only two points!<br><br>It's going to die though.  I put KH&gt;MGS...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">1</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=1">2</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=2">3</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=3">4</a></li>
<li>      5</li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=5">6</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=6">7</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=7">8</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=8">9</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=9">10</a></li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage5_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29209811&amp;page=4" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage5_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>