<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">

<title>GameFAQs: Message List</title><link rel="stylesheet" type="text/css" href="genmessage8_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage8_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage8_files/bc.css"></head><body linkifytime="280" linkified="8" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage8_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage8_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29209811%26page%3D7"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<a href="http://adlog.com.com/adlog/c/r=10153&amp;s=657805&amp;t=2006.07.30.22.06.34&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=01c17-gne-ad144C8F19B1584FE8/http://www.gamespot.com/pc/sports/probassfishing2003/index.html?q=pro%20bass" target="_blank"><img src="genmessage8_files/probass_leader.gif" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage8_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew - Part 2</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29209811&amp;page=7">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29209811" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">First
          Page</a> |
          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=6">Previous
          Page</a> |
          Page 8 of 10          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=8">Next
          Page</a>
          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=9">Last
          Page</a>
      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/23/2006 5:58:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321958745">message detail</a>
 | #351</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>Welcome to Round 4 of the &#8220;Now top
THAT!&#8221; battle between the Legend of Zelda and Final Fantasy. The Legend
of Zelda gets nearly 90% on Civilization and becomes the first to break
100,000 individual votes? Hah, that&#8217;s nothing for Final Fantasy! Try
107,000 individual votes against Diablo despite doing exactly 4% worse,
raking in 14,000 more total votes! Naturally, the Legend of Zelda is
responding in kind. As I&#8217;m writing this, the Legend of Zelda is pushing
nearly 81% against Mega Man X, still looking to break 100,000
individual votes again, and is currently on pace to hit the highest
vote total of the contest so far. So what now, Final Fantasy? <br><br>On
the surface, it looks like Final Fantasy has the perfect opponent to
gauge how it stands in respect to the Legend of Zelda. It&#8217;s Mega Man
without the X! However, if it does a little worse in this match, don&#8217;t
lose heart. There are a couple of reasons why this could happen. First
of all, there is a chance that Zelda got some measure of SFF against
Mega Man X due to both spending a good bit of time on the SNES.
Secondly, it&#8217;s important to take into consideration that there will
likely be a fair portion of voters who will not be voting for Mega Man
solely for the Classic series. I don&#8217;t know exactly how much of an
effect either one has, but they are certainly possible factors. <br><br>Of
course, if Final Fantasy does worse against Mega Man, Board 8 will
automatically make the Legend of Zelda the favorite to win the contest.
If Final Fantasy somehow does better, Board 8 will refer back to the
Favorite Mega Man Series poll and STILL say the Legend of Zelda is the
favorite to win the contest. For some reason, the board is insistent on
doing whatever it takes to make it look like Final Fantasy isn&#8217;t the
hands-down favorite to win this contest. Nearly 86% on Diablo? Oh,
Diablo must be bad fodder, even though there isn&#8217;t really anything in
any contest pointing to that! NintendoFAQs? More like Board
NintendEIGHT, am I right? <br><br><i>Leonhart&#8217;s Prediction</i>: <b>Final Fantasy with 78.44%</b> <br><br><br><br><b>HM&#8217;s Analysis</b><br> <br><b>Final Fantasy</b><br><br><i>Previous Matches :</i><br><br>Final Fantasy &#8211; 85.98% -- 107,648<br><br>Diablo &#8211; 17,560 <br><br><b>Mega Man</b><br><br><i>Previous Matches :</i><br><br>Mega Man &#8211; 58.12% &#8211; 62,075<br><br>Mario Kart &#8211; 41.88% &#8211; 44,727 <br><br>&#8230;  <br><br><i>&#8220;Holy crap.&#8221;</i> <br><br>That
about sums up my feelings on both FF/Diablo and MM/MK. I never
suspected that either of them would get such a high percentage,
especially Final Fantasy. Mega Man managed to continue the line of the
older series with a large number of games beating the more new series
with a smaller amount of games. It is unfortunate, however, that Mega
Man has to face <i>Final Fantasy</i> so soon. If Final Fantasy&#8217;s performance is any indication, this match is going to ugly. <br><br>In the last round, Final Fantasy <i>completely</i>
turned heads when it absolutely demolished Diablo; it turned what would
otherwise be a pretty strong series into looking like pure fodder. You
really cannot mess with someone who has power like that. Final
Fantasy&#8217;s performance sent a clear message of destruction to The Legend
of Zelda. The fact that it can turn even a semi-powerful series into
looking like fodder should give one an idea of how bad this match is
going to end up being.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/23/2006 5:58:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321958887">message detail</a>
 | #352</td></tr>
<tr class="even">
<td>
Mega Man on the other hand did really well against Mario Kart by nearly
snatching up 60%. It seems like most hotly debated matches really
aren&#8217;t turning out to be even semi-close these days. There was a pretty
big split on who thought Mario Kart would win and who thought Mega Man
would win &#8211; it was 5 &#8211; 4 Mario Kart for the Crew &#8211; and it was really
surprising to see the match not even start off close. Even with the
impressive performance under its belt, it is up against an absolute
monster. It stands no chance of doing anything except maybe breaking
20%. <br><br>Yeah.
This match would get more analysis, but it is really quite unnecessary.
The most interesting thing about this match is going to be how it
compares to LoZ/MMX. Let it be known, if Final Fantasy puts up a better
performance against Mega Man than Zelda does against MMX, we&#8217;re not
going to see anything even give Final Fantasy a sweat. The strongest
entity we&#8217;ll ever see in a contest? Yeah &#8211; Final Fantasy. <br><br><b>Aitch Emm&#8217;s Bracket :</b> Final Fantasy<br><br><b>Aitch Emm&#8217;s Prediction :</b> Final Fantasy &#8211; 79% ; Mega Man &#8211; 21%<br><br><b>Aitch Emm&#8217;s Vote :</b> Final Fantasy<br> <br> <br> <br><br><b>HaRRich&#8217;s Analysis</b><br><br> Predicted winner:  Final Fantasy<br>Earlier this contest:<br>---FF - 85.98% on Diablo<br>---MM - 58.12% on Mario Kart<br>Top 100 List comparison:<br>---FF7 - #1, FF3/6 - #10, FFX - #12, FF8 - #17, FFT - #19, FF9 - #42, FF2/4 - #50, FF - #76, FFTA - #89<br>---MM - N/A (had no games on the drop-down list)<br>Best Game Ever x-stat comparison:<br>---FF7
- 50% (Best. Game. Ever. champion), FF3/6 - 39.4%, FFX - 36.86%, FF -
32.24%, FFT - 28.69% (was behind FF7/MGS), FFTA - 24.27% (SFF'd by FFX)<br>---MM - N/A (no rep)<br><br>Congrats
Mega Man -- MM/MK was the first time I was ever cost a point by not
picking you (though Zero has before...damn you, Scorpion). Now, you
will be punished with a harsh vengeance that not even I can control.
Thank CJayC later.<br><br>Final Fantasy was simply generous by being in
the bottom of the bracket, so the rest of the series could look good
before it showed off. Before we ever saw FF in action, we saw LoZ
damn-near get 90% against Civilization, Mario break 92% against Madden,
MG embarrass SC and anybody who made that upset pick, and Metroid go
past 70% on Kirby...then we saw the first update in FF/Diablo. Mega
Man, despite comfortably beating Mario Kart, could never match any one
update FF had against Diablo -- sad as it may be -- and I wouldn't
expect MM to take the board vote either from FF. Heck, FF very well may
even have the power to get on MM what LoZ got on MMX (which would be
amazing considering LoZ likely SFF'd MMX, and <i>especially</i>
amazing if most voters consider MM to be all of the Mega Man games).
The people who said Diablo's just a weakling and LoZ &gt; FF based off
of the first round are going to be rudely awakened this time.<br><br>Final Fantasy wins with 79.12%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/23/2006 5:59:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321959022">message detail</a>
 | #353</td></tr>
<tr class="even">
<td>
<b>Lopen&#8217;s Analysis</b><br> <br>You know what I said a few days ago
about the really big beasts FF, Mario, and LoZ winning with more % than
you'd expect against lesser series? In effect, "SFFing" them? Well, I
think Mega Man is a big enough dude to at least try and stop the pain
against this juggernaut. He's got a massively large fanbase out there,
too, and his popularity age is older than Final Fantasy's, the Mega Man
NES games were way bigger than the NES Final Fantasy game (games for
you Japanese voters!). Oh, yeah, he's surely at a disadvantage in the
SNES eras and above, but he's undoubtedly got the NES vote! He might
even have a bit of a tussle for the SNES vote! MMX1-3 and MM7 were
fairly popular at least. (yeah I'm still including the X series when
I'm thinking Mega Man, I'll be sure to blame undershooting the % on
this too, should it happen)<br><br>Now, don't get me wrong, were this
Mario, or Zelda, I'd have them beating poor ol' Mega Man into the dirt
a bit harder&#8230; but I think Mega Man's got enough of his own turf to work
with that FF doesn't have. And I think he's one of the more popular
series here, so even in the case of overlap he won't be <i>annihilated</i>.<br><br>Think
of it like one of those signs at the amusement parks. "You must be this
tall not to be totally destroyed". Okay, so they didn't say "totally
destroyed"&#8230; and in this case we're talking popularity instead of
height&#8230; but you get it, right? Mega Man is tall enough to ride, and
will at least try to hold his own. (won't it be sad if I'm the highest
one here, though? Yeah, right...)<br><br><b>Lopen's Prediction:</b> Final Fantasy with 66.50%<br> <br><br> <br> <br>Comments: FF gon' win, and of course Lopen has to go against the consensus.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29209811" class="name">DaruniaTheGoron</a> |
Posted 7/23/2006 6:58:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321972725">message detail</a>
 | #354</td></tr>
<tr class="even">
<td>
I think Lopen actually has an alright shot of being right on this one.
Mega Man isn't *that* weak, although I think FF will have to
underperform big time to get 66.5%. I'm liking Ulti's pick and my
personal prediction would be 71%.<br>---<br><b>Sp2k6:<i> 24/26</i> Rank: <i>Tied for 752nd</i> Losses: <i>Halo, GTA</i> </b>but im gonna cry if he (Sonic) loses. <br><b>Yesterday's Pick: <i>Mario</i> Today: <i>SSB</i> Tomorrow:<i> FF</i></b> - Zikten on the Sonic/SSB match</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/23/2006 7:05:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321974381">message detail</a>
 | #355</td></tr>
<tr class="even">
<td>
Not much breathing room for a lot of people here. There are about 4 or 5 people within 2% of each other.<br><br>And hit-or-miss Lopen lives on! He's either gonna get this one right or end up being dead last again.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3232077&amp;board=8&amp;topic=29209811" class="name">DoABarrelSoul</a> |
Posted 7/23/2006 7:15:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321976553">message detail</a>
 | #356</td></tr>
<tr class="even">
<td>
You know, it's sad that the first thing I do on an update is look at Leon's prediction. Every single time.<br>---<br>The official "Nominate Fox McCloud for SC2K6" alt.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/23/2006 7:17:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321977020">message detail</a>
 | #357</td></tr>
<tr class="even">
<td>
Heh, this is four straight matches where Soul and I have been within one percent of each other on our predictions.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=640243&amp;board=8&amp;topic=29209811" class="name">Big Bob</a> |
Posted 7/23/2006 7:21:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321978005">message detail</a>
 | #358</td></tr>
<tr class="even">
<td>
*sigh* I knew SSB would win handily, and once again I am saddened that Sonic couldn't pull an upset.<br><br>Very happy to hear Kingdom Hearts owned the Analysis Crew, though.<br><br>And O_O at Super Mario Bros. getting 80%..<br>---<br>This space reserved for a new sig.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/23/2006 7:34:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321981149">message detail</a>
 | #359</td></tr>
<tr class="even">
<td>
Truth be told, after Castlevania and Sonic didn't do as well as I'd
thought, I was gonna bring Mega Man's % down a bit, but eh... I was
screwed last round for changing %s, I'll just let it roll. <br><br>I'm a bit surprised that anyone even went as low as Ulti, though.  I too, am liking Ulti's pick, here.  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/23/2006 7:35:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321981461">message detail</a>
 | #360</td></tr>
<tr class="even">
<td>
So someone else concurs that Ulti has good positioning.<br><br>We remember what happened the last time that happened!<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/23/2006 7:48:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321984850">message detail</a>
 | #361</td></tr>
<tr class="even">
<td>
Actually, I don't.  I'm going to assume you earned a point, as you remember it so clearly!!  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29209811" class="name">SquallidSnake</a> |
Posted 7/23/2006 7:50:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321985215">message detail</a>
 | #362</td></tr>
<tr class="even">
<td>
Darunia has already said he likes Ulti's positioning, so the fate has been decided.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29209811" class="name">DaruniaTheGoron</a> |
Posted 7/23/2006 8:02:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321988355">message detail</a>
 | #363</td></tr>
<tr class="even">
<td>
<i> From: SquallidSnake </i><br><i>Darunia has already said he likes Ulti's positioning, so the fate has been decided.</i><br><br>o_O ... k?<br>---<br><b>Sp2k6:<i> 24/26</i> Rank: <i>Tied for 752nd</i> Losses: <i>Halo, GTA</i> </b>but im gonna cry if he (Sonic) loses. <br><b>Yesterday's Pick: <i>Mario</i> Today: <i>SSB</i> Tomorrow:<i> FF</i></b> - Zikten on the Sonic/SSB match</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29209811" class="name">SquallidSnake</a> |
Posted 7/23/2006 8:03:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321988602">message detail</a>
 | #364</td></tr>
<tr class="even">
<td>
I'm referring to HaRRicH a couple of days ago saying he liked Ulti's
positioning for Mario/Warcraft, and then Ulti ended up being off by 20%.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29209811" class="name">Lugia2</a> |
Posted 7/23/2006 11:23:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322040544">message detail</a>
 | #365</td></tr>
<tr class="even">
<td>
It's pretty early in the match, but given that FF lost some percentage
(I know: %age doesn't = votes, but that doesn't matter here), it should
stabilize soon.<br><br>Looks like it's going to be Ulti's point...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1288566&amp;board=8&amp;topic=29209811" class="name">gtonizuka49</a> |
Posted 7/23/2006 11:42:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322044677">message detail</a>
 | #366</td></tr>
<tr class="even">
<td>
+9 mnm (tie)<br>+9 yo (tie)<br>+7 HaRRicH<br>+6 Moltar<br>-1 Leon<br>-2 Soul<br>-3 HM<br>-4 Ulti<br>-5 Lopen<br><br><b>The Rankings</b> (Through Sonic the Hedgehog/Super Smash Bros.)<br>1. Master Moltar (101)<br>2. yoblazer33 (84)<br>3. XxSoulxX (78)<br>4. Leonhart (73)<br>4. UltimaterializerX (73)<br>6. Lopen (66)<br>7. therealmnm (65)<br>8. HaRRicH (64)<br>9. Heroic Mario (54)<br><br>Moltar is practically guaranteed first place, but the race for second is still wide open.<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29209811" class="name">DaruniaTheGoron</a> |
Posted 7/24/2006 12:46:29 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322057670">message detail</a>
 | #367</td></tr>
<tr class="even">
<td>
Well for one I never said I liked his POSITIONING, just his pickof
70.96 or whatever. And if the %age goes down to 72 or lower (which I
think it will), he'll get the point, so maybe I'm not a curse :)<br>---<br><b>Sp2k6:<i> 26/28</i> Rank: <i>Tied for 367th</i> Losses: <i>Halo, GTA</i> </b>but im gonna cry if he (Sonic) loses. <br><b>Yesterday's Pick: <i>SSB</i> Today: <i>FF</i> Tomorrow:<i> SF</i></b> - Zikten on the Sonic/SSB match</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/24/2006 12:50:42 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322058492">message detail</a>
 | #368</td></tr>
<tr class="even">
<td>
At this point, I like mnm's chances at the point.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/24/2006 12:54:01 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322059126">message detail</a>
 | #369</td></tr>
<tr class="even">
<td>
This sucks... I was going to raise my prediction 5%. I hate you, Mega
Man! Why do you keep swerving me like this? Change or don't change it, <i>what do you want?</i><br><br>Actually, I don't hate you, I love you and want you to fight for an extra 5% over the day!!<br><br>Or maybe 50%.  If you want to set your sights high.  You know, just a suggestion.  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29209811" class="name">UltimaterializerX</a> |
Posted 7/24/2006 3:26:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322184653">message detail</a>
 | #370</td></tr>
<tr class="even">
<td>
<i>Final Fantasy is so screwed.</i><br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29209811" class="name">SquallidSnake</a> |
Posted 7/24/2006 3:48:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322190701">message detail</a>
 | #371</td></tr>
<tr class="even">
<td>
Yep, this is definitely mnm's point.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/24/2006 5:44:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322217915">message detail</a>
 | #372</td></tr>
<tr class="even">
<td>
Curious to see how far-ranging the RE predictions go.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/24/2006 5:56:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322220958">message detail</a>
 | #373</td></tr>
<tr class="even">
<td>
&gt;_&gt;<br><br>Sent.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/24/2006 7:40:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322246808">message detail</a>
 | #374</td></tr>
<tr class="even">
<td>
Sonic the Hedgehog.....42.34% 53423<br>Super Smash Bros........57.66% 72755<br>TOTAL VOTES...........................126178<br><br>46.03% of the brackets predicted this match correctly.<br><br>Another
hotly debated match turns out to be nothing more than an easy victory.
In this case, it was SSB that prevailed over Sonic, proving once again
that a small number of strong games &gt; a large number of weaker games.<br><br>Today, Final Fantasy is almost tripling Mega Man. Can we just give it the Contest already?<br><br>Soul - 4<br>Lopen - 3<br>HaRRich - 3<br>Moltar - 3<br>Yoblazer - 2<br>Ulti - 2<br>HM - 2<br>Mnm - 1<br>Leon - 1<br><br>Mnm gets his first point finally! To steal some of the glory though, Yoblazer also gets a point.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Final Fantasy vs. Mega Man - Bracket: <b>FF</b> - Vote: <b>MM</b> (26/28)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/24/2006 7:41:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322247119">message detail</a>
 | #375</td></tr>
<tr class="even">
<td>
And based on today, I'm going to be in the basement after this match.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/24/2006 7:47:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322248736">message detail</a>
 | #376</td></tr>
<tr class="even">
<td>
<b>Ultima Division:</b> <i>Round 2 - Match 24</i> &#8211; (6)Street Fighter vs. (2)Resident Evil <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Street Fighter</b><br>Round 1 &#8211; 64.77% vs. The Elder Scrolls (35.23%)<br><br>The Elder Scrolls was untested, but it didn&#8217;t have the strength to take down Street Fighter.<br> <br><b>Resident Evil</b><br>Round 1 &#8211; 87.76% vs. Shadow Hearts (12.24%)<br><br>Wow, Shadow Hearts will be nothing more than fodder.<br><br>The
final match of Round 2, and it&#8217;s not a bad one either. This one has
gotten some talk lately, but not as much as the other hotly debated
matches. In fact, most of talk for this match was during the
bracket-making period. Most people decided that Resident Evil would win
this with ease, but the Street Fighter supporters are speaking out.<br><br>Alright,
we really can&#8217;t tell much about this match from Round 1, with TES being
untested and SH being too fodder-ific. Still, if we were to judge on R1
performances alone, RE would win there.<br><br>So I&#8217;ll take a different
approach on this match. Overall, Resident Evil is the stronger Capcom
franchise by a bit. Also, the RE series has one thing that SF doesn&#8217;t
have. A big recent release, and the name of the game is RE4. Pre-RE4, I
might have given SF the edge here, but with RE4 in RE&#8217;s corner, this
match is all but over. Street Fighter 2, SF&#8217;s biggest game, isn&#8217;t all
THAT strong. I mean, it did lose to SMRPG (omg SF2 lost?!?!), and while
RE didn&#8217;t fare too well against MGS, I&#8217;d argue RE2 and most definitely
RE4 are stronger than it.<br><br>The only thing SF has going for it now is the nostalgia factor, and I doubt that&#8217;s going to be enough. RE wins quite easily.<br><br><b>Moltar&#8217;s Bracket Says:</b> Resident Evil will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Street Fighter: 42% - Resident Evil: 58%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>Here
we have two Capcom series. One features Resident Evil 4 and has a
strong stake in every gaming generation since the PSX days. The other
is a series that no one other than the most hardcore of fighting game
fans (which are easily some of the most annoying in gaming; idiot SSBM
fans only brought an existing mentality into a mainstream audience,
rather than creating it outright) has cared about since the early 90s.
What more can possibly be said?<br><br>Prediction: Resident Evil with 66.65%<br> <br><br><br><b>Soul&#8217;s Analysis</b><br><br> <br><i>SF defeated Elder Scrolls with 64.77%<br>RE defeated Shadow Hearts with 87.76%</i><br><br>Here is the last contested match for a long while, and sadly it's an easy choice.<br><br>Street
Fighter defeated Elder Scrolls easily last round, but it was nothing
compared to the blowout that RE gave to Shadow Hearts. Both looked very
impressive last round. This round is a lot different though. Resident
Evil is the clear favorite, for a few reasons. I could get into them
all, but it's really obvious that the biggest reason is because of
Resident Evil 4. RE4 is pretty popular on this site, but would that
popularity equal contest strength? I hope so.<br><br>I'm predicting
Street Fighter will get closer then what a lot of people are thinking
though. It's a pretty strong series on this site, but I doubt it will
be stronger then Resident Evil. Although, Knuckles did beat Magus...<br><br><b>My prediction: Resident Evil wins with 51.50% of the vote.</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/24/2006 7:47:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322248873">message detail</a>
 | #377</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>After their first round matches, I was
hoping I&#8217;d feel a bit more confident one way or the other on this one.
I&#8217;ve had Street Fighter beating Resident Evil in my bracket from the
very beginning, but it&#8217;s never something I&#8217;ve had a great deal of
confidence about. It seems that nearly all of the intangibles are in
Resident Evil&#8217;s favor. There&#8217;s the Favorite Capcom Series poll that
favors Resident Evil even before RE4 came out, and there&#8217;s the fact
that RE4 was the overwhelming Game of the Year. <br><br>Really, I want
to take Street Fighter as an upset pick in the off chance that it
happens since I&#8217;ll likely be the only one on the Crew to take it. But
then again, I don&#8217;t want to take an upset just for the sake of having
an upset, and I&#8217;m not feeling good about it at this point. Street
Fighter did score 65% on the Elder Scrolls, but we don&#8217;t know what
that&#8217;s worth. Sure, Oblivion is a potential Game of the Year threat,
but as we&#8217;ve seen repeatedly, just one game isn&#8217;t enough to put a
series over the top. And I suppose it&#8217;s possible just having the title
&#8220;Elder Scrolls&#8221; could have worked against it, too. For some reason,
people were surprised when Resident Evil scored 85% against Shadow
Hearts, but that was basically what I expected. Quite a few series in
this contest could push 85% on it, though nearly 88% is impressive
nonetheless. <br><br>Maybe I&#8217;m the only one who&#8217;s getting concerned by
this, but Fire Emblem did noticeably better against Metal Gear than
Soul Calibur did, putting the fighting series on almost equal ground
with Silent Hill. It&#8217;s hard to tell if it was the horrible Metal Gear
picture or what, but seeing one survival horror series being equal to a
fighting series has me concerned. After all, I wasn&#8217;t expecting
anything at all from Silent Hill. I figured Soul Calibur would be far
ahead of it. Fighting games generally aren&#8217;t held in high regard on
this site, and this seems to drive that point in further. However,
Street Fighter is probably the one exception to this rule, as it is
widely respected by most gamers for its impact on the industry. Yet
respect isn&#8217;t tantamount to popularity, so I don&#8217;t know if that&#8217;s worth
very much. <br><br>And while Resident Evil 4 is the reigning Game of
the Year, bear in mind that Grand Theft Auto is a master at performing
well in those polls (while Warcraft has sucked whenever it&#8217;s been
involved in one), and it certainly didn&#8217;t look like a monster in this
contest. We&#8217;ve also seen examples in favorites polls where the
&#8220;favored&#8221; one doesn&#8217;t win (Bowser &gt; Yoshi being the main example we
have of this, though for some reason, Yoshi still beat Luigi, who
actually did better than Bowser in that poll). In other words, who
knows exactly which way it&#8217;s going to lean? <br><br>Resident Evil is
the favorite in this match, and probably rightfully so. Resident Evil 4
was huge and rejuvenated the series, while it&#8217;s been a long time since
Street Fighter had a noteworthy release (Street Fighter Alpha 3 in
1998, and I didn&#8217;t even realize it had been THAT long until I looked it
up). While both are Capcom, don&#8217;t expect any SFF or something like
that. Two radically different genres here. I suppose if Street Fighter
has an advantage, it&#8217;s the play rate. Nearly everyone has played one
game at one point in their life, and in the &#8220;Favorite Survival Horror
Series&#8221; poll, &#8220;I don&#8217;t play those kind of games&#8221; came in second with
18.77% of the vote, though Resident Evil got over 45% there as well.
It&#8217;s easily the tops in its genre, though I&#8217;d wager Street Fighter is
the tops in its genre, too. <br><br>Unlike a lot of people around
here, I believe Street Fighter actually has a good chance to win, but
the odds are not in its favor. Yet it might be my love for Street
Fighter (and my indifference toward Resident Evil) that&#8217;s giving me
that impression, but&#8230;I&#8217;ve decided to take my chances on the upset here.
<br><br><i>Leonhart&#8217;s Prediction</i>: <b>Street Fighter with 51.99%</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/24/2006 7:48:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322248974">message detail</a>
 | #378</td></tr>
<tr class="even">
<td>
<b>HM&#8217;s Analysis</b><br> <br> <b>Street Fighter</b><br><br><i>Previous Matches :</i><br><br>Street Fighter &#8211; 64.77% -- 71,526<br><br>The Elder Scrolls &#8211; 35.23% -- 38,904 <br><br><b>Resident Evil</b><br><br><i>Previous Matches :</i><br><br>Resident Evil &#8211; 87.76% -- 97,696<br><br>Shadow Hearts &#8211; 12.24% -- 13,627 <br><br>And
we finally arrive at one of the last heavily debated matches of the
contest with Street Fighter and Resident Evil. Their performances in
the previous round did not really spread any new light on this match,
but a lot of people were shocked to see Resident Evil put up such big
numbers on Shadow Hearts, even if it was absolute fodder. Street
Fighter did not put up a performance that was impressive or
disappointing, though some felt it was the end of the line when it met
Resident Evil. <br><br>This has always been one of the most heavily
debated matches in the entire contest, and I know it was the only match
I actually went back in my bracket and changed my winner. Initially, I
figured I would go ahead and choose Street Fighter to pull out the win,
but I never really had any solid reasoning behind that choice &#8211; it just
felt right. Once you start looking at all the advantages that Resident
Evil has in its favor, though, you begin to realize that this match
probably will not all <i>that</i> hard.  <br><br>As far as contest
history goes, we have seen performances from both Street Fighter and
Resident Evil numerous times. In the character battle, Ryu has always
been one of the strongest entries whereas Resident Evil has never
really produced a notable one. Jill started out good but eventually met
a hard decline in more recent years. There were some other Resident
Evil entries in 2002, but they&#8217;d likely be around the fodder area now.
However, with the release of Resident Evil 4, we saw Leon Kennedy bust
into the character contest and prove to be one of the best newcomers in
the bracket, second to only Tifa and Vincent, I believe. He&#8217;s very
close to Ryu, who is still a strong entry himself. <br><br>In the
games contest, both series were represented with Resident Evil and
Street Fighter II. Once again, both of them ended up rather close in
the stats, but favoring Street Fighter. However, we saw what was likely
Street Fighter&#8217;s strongest singular game and only not Resident Evil&#8217;s.
In all likelihood, it has two stronger games &#8211; Resident Evil 2 and
Resident Evil 4 &#8211; and that does not even mention being underrated
through SFF. Most of the signs are here, at least, to point to Resident
Evil having stronger games, and it has the added advantage of being a
long running series with tons of games. <br><br>The real deal breaker
here for me, though, was the fact that Resident Evil got one of the
biggest games of the generation &#8211; Resident Evil 4. It was not just a
hyped release, but this was a <i>resurrection</i> of a franchise. It
completely reinvented the way Resident Evil is played and the quality
of the series shot up as a result. People who didn&#8217;t care for Resident
Evil prior (Hi!) started anticipating RE5. The game just oozed quality
in every way. I think that almost assuredly tips the balance in favor
of Resident Evil, especially now that it is on both the PlayStation 2
and GameCube. The two largest console fanbases at GameFAQs have been
exposed to the game. Interestingly, no Street Fighter game has come out
on the GameCube this generation, for whatever it is worth. <br><br>If
we are to look at sales, Resident Evil is Capcom&#8217;s highest selling
franchise at 28 million copies sold. Street Fighter and Mega Man are
tied at second with 24 million each. The number of games is only about
ten or so behind Street Fighter, I believe, which completely removes
the idea that Resident Evil does not have enough games to compete. The
only other factor is that Street Fighter is much older than Resident
Evil, but I sincerely doubt it matters that much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/24/2006 7:48:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322249122">message detail</a>
 | #379</td></tr>
<tr class="even">
<td>
This match is completely in favor of Resident Evil, I feel. I admit
that without RE4 I would be debating this match much more, but as it
stands, I cannot see Street Fighter even thinking about winning this
one. I&#8217;m not sure how the rest of the Crew is going to pick, but I have
a feeling they&#8217;ll be siding with Resident Evil, too. There is just too
much in RE&#8217;s favor. <br><br><b>Aitch Emm&#8217;s Bracket :</b> Resident Evil<br><br><b>Aitch Emm&#8217;s Prediction :</b> Resident Evil &#8211; 54% ; Street Fighter &#8211; 46%<br><br><b>Aitch Emm&#8217;s Vote :</b> Street Fighter <br><br><br><br><b>Yoblazer&#8217;s Analysis</b><br> <br> <br>Before
I begin, a humble word of warning to all RE fans: expect a picture so
horrid in its lopsidedness that it rivals the infamous Tidus/Super
Smash Tsunami... thing. The Street Fighter sprites are legendary and
recognized the world over. I don't know what CJayC is planning to use
for Resident Evil, but I can bet it will look terribly out of place
and, well, it'll just look like ass. For the few RE supporters who
don't yet realize this - you have been forewarned.<br><br>Now, this
match did spark some debate early on, but most of that has been put to
rest after the first round. While Street Fighter failed to double The
Elder Scrolls, Resident Evil shocked the hell out of everyone by nearly
hitting <i>88%</i> against Shadow Hearts. Granted, its opponent is the
weakest series in the bracket, but that does not take away from RE's
incredible performance. It didn't just double, triple, or even
quadruple Shadow Hearts; it pounded it to a level usually reserved for
the contest elites. Make no mistake, to hit the high 80's, you MUST
have some legitimate strength, and that's what Resident Evil proved to
any and all the doubters.<br><br>Outside of the contest, it seems to me
that all the intangibles are stacked in Resident Evil's favor. The
influential survival horror series burst onto the scene in 1996, just
as 3D gaming was on a rise and Street Fighter's popularity was
beginning to taper. During those few years, it's almost as if there was
a shift of power within the Capcom empire. RE took the crown off SF's
head and ran with it. It became Capcom's best selling series. It became
Capcom's biggest series. While Street Fighter took a back seat to 3D
fighters such as Tekken and Soul Calibur, RE was the undisputed king of
its genre, and every new release was met with great anticipation and
solid sales.<br><br>Resident Evil had the late 90's, yes, but no one
can deny the immense popularity and fan devotion Street Fighter gained
during the early 90's. It doesn't matter if GameFAQs is into fighters
or not; EVERYONE has played Street Fighter. Tons of people have very
powerful emotional attachments to it, and I'd wager that it carries a
nostalgia factor eclipsed only by a certain Italian plumber. When you
consider that, this match has all the ingredients of a classic.<br><br>Of
course, then Capcom had to go and introduce Resident Evil to the
Nintendo audience. Since 2002, Nintendo has thrice tasted what the
premier survival horror series has to offer: first with the highly
acclaimed REMake, second with the not-so-acclaimed but original and
exclusive RE0, and last but <i>certainly</i> not least, with the
outstanding RE4, which was overwhelmingly voted as the best and most
popular game of all time. Street Fighter may have its age and a fanbase
full of fond memories, but Resident Evil 4 gives RE the final push in
the right direction.<br><br>Street Fighter<br>+ Great history and credibility<br>+ Nostalgia factor rivaled by very few<br>+ Whored out like a mother<br>+ Established a genre<br>- Ho-hum first round performance<br>- What have you done for me lately?<br><br>Resident Evil<br>+ Incredible first round performance<br>+ Good history and credibility<br>+ Hugely popular game was released just last year<br>+ Whored out like a mother<br>+ Established a genre<br>- It's going to get dismantled soon enough<br><br>My prediction: Resident Evil def. Street Fighter (59-41)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/24/2006 7:49:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322249252">message detail</a>
 | #380</td></tr>
<tr class="even">
<td>
<b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: The Third Malformation of 'G' (RE2)<br><br>Super
busy today, so another super short analysis. A couple of years ago,
Resident Evil/Street Fighter would probably have been a toss-up. Street
Fighter dominated in the 16-bit era, while Resident Evil was extremely
popular during the 32-bit era. Since then, Resident Evil has had RE4,
and that alone is the difference. RE definitely will not be blowing out
SF though. I put *zero* stock in RE's beating of Shadow Hearts. <i>Nobody</i> cares about Shadow Hearts on this site.  <i>Any</i>
well known/popular series would have blown it out. Street Fighter
probably would have done about as well. Street Fighter itself turned a
supposed debated match with The Elder Scrolls into a standard beating.
It definitely has some strength. Just not enough to top Resident Evil.
RE4 gives Resident Evil a comfortable win.<br><br>Bracket: Resident Evil<br>Vote: Street Fighter<br>Prediction: Resident Evil with 56.35%<br> <br><br><b>HaRRich&#8217;s Analysis</b><br><br> Predicted winner:  Resident Evil<br>Earlier this contest:<br>---SF - 64.77% on The Elder Scrolls<br>---RE - 87.76% on Shadow Hearts<br>Top 100 List comparison:<br>---RE4 - #14, RE - #53 (Fun-fact: RE Code: Veronica was on the drop-down list but didn't finish in the top 100)<br>---SF2 - #47<br>Best Game Ever x-stat comparison:<br>---RE - 16.86% (was behind FF7/MGS)<br>---SF2 - 24.08%<br><br>I'll
be brief because I've typed alot lately and I've talked about this
match...alot. Don't forget Dilated Chemist, you and I have a sig-bet on
this match that lasts the rest of the contest:<br><br>1)  <a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=523" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=523">http://www.gamefaqs.com/poll/index.html?poll=523</a><br>2)  <a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1454" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1454">http://www.gamefaqs.com/poll/index.html?poll=1454</a><br>3)  Both of those polls were before RE4 came out.<br>4)  RE4 &gt; SF2...in fact, RE4 on Gamecube or PS2 alone (your choice) SF2.<br>5)  RE's had more big hits for its series.<br>6)  RE's put out a more recent respected release than SF.<br>7)  RE has sold more than SF.<br>8)  Before the PS2 release, Leon -- solely off of RE2 and RE4 -- could nearly beat Ryu, the icon of SF.<br><br>Resident Evil wins with 59.12%<br> <br><br><br><b>Lopen&#8217;s Analysis</b><br> <br>Man, I said I wasn't going to reference <i>any</i> polls in my analyses, but for this one, I just have to! It's the warcry of the RE supporter, and I'd hate to leave it behind.<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1454" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1454">http://www.gamefaqs.com/poll/index.html?poll=1454</a><br><br>So,
you've got that all absorbed? Now the gist of what people seem to be
saying is "Street Fighter was beaten by Resident Evil in this poll, and
Resident Evil had the big time hit Resident Evil 4 since then so it's a
lock!". Okay, but here're the problems, suckas.<br><br>1. You don't
think the Marvel vs. voters are going to vote for Street Fighter in the
event of Street Fighter vs. Resident Evil? I'd say it's all but
assured. You add that to Street Fighter, and Street Fighter's winning
by about 3%.<br><br>2. Mega Man took the majority of the vote. Who do
you think a Mega Man voter's more likely to vote for? The fresh new PS
series, or the old school Street Fighter? Me, I'm thinking Street
Fighter is a lot more likely to take second place with these fellows
than RE is.<br><br>Basically, what I'm saying is&#8230; hold this match back when that poll was taken, and RE doesn't <i>win</i> at all! It <i>loses</i>. I'd go as far as to take around a 60-40 in favor of SF, in fact. Now, since then, RE <i>has</i> had RE4, a recent GotY, but man, I can't trust the significance of <i>one release</i>
when it comes to a series. Not enough to turn what I think is around a
20% difference. Look at Metroid, look at GTA! They've both been more
impressive in recent GotY polls than RE could hope for, and look where
it got them! Both series disappointed. There's more to voting than just
the strong games. Nostalgia and age shall best you, RE4!</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/24/2006 7:50:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322249432">message detail</a>
 | #381</td></tr>
<tr class="even">
<td>
Oh, sure, Resident Evil looked like a house of <i>fiyah</i> last round, but I'm not convinced Street Fighter does any worse. It's <i>just Shadow Hearts</i>, people. No one cares about it, they'd have rather voted for Guilty Gear, remember?<br><br><b>Lopen's Prediction:</b> Street Fighter with 54.54%<br><br> <br> <br>Comments: The majority of the Crew is backing RE, while Leon and Lopen are for SF. Let's see how this goes.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/24/2006 7:52:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322250077">message detail</a>
 | #382</td></tr>
<tr class="even">
<td>
Good thing I didn't side with Resident Evil. Soul and I would've been within one percent yet again!<br><br>But bad thing Lopen sided with Street Fighter, too! NOOOOOO!<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/24/2006 7:54:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322250679">message detail</a>
 | #383</td></tr>
<tr class="even">
<td>
Holy hell. I totally missed that Street Fighter the first time I looked at it. <br><br>You were one second away from a yelling you would have never forgotten!<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/24/2006 9:10:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322269104">message detail</a>
 | #384</td></tr>
<tr class="even">
<td>
Looks like yoblazer was right about the picture.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29209811" class="name">DaruniaTheGoron</a> |
Posted 7/24/2006 9:19:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322271284">message detail</a>
 | #385</td></tr>
<tr class="even">
<td>
The Crew is in favour of RE.<br><br>Hopefully the old trends continue and the crew gets another debated match wrong.<br>---<br><b>Sp2k6:<i> 26/28</i> Rank: <i>Tied for 467th</i> Losses: <i>Halo, GTA</i> </b>but im gonna cry if he (Sonic) loses. <br><b>Yesterday's Pick: <i>SSB</i> Today: <i>FF</i> Tomorrow:<i> SF</i></b> - Zikten on the Sonic/SSB match</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29209811" class="name">DaruniaTheGoron</a> |
Posted 7/24/2006 9:20:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322271644">message detail</a>
 | #386</td></tr>
<tr class="even">
<td>
Oh God yes... I just looked at the picture. Totally in SF's favour.<br>---<br><b>Sp2k6:<i> 26/28</i> Rank: <i>Tied for 467th</i> Losses: <i>Halo, GTA</i> </b>but im gonna cry if he (Sonic) loses. <br><b>Yesterday's Pick: <i>SSB</i> Today: <i>FF</i> Tomorrow:<i> SF</i></b> - Zikten on the Sonic/SSB match</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=640243&amp;board=8&amp;topic=29209811" class="name">Big Bob</a> |
Posted 7/24/2006 9:29:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322273691">message detail</a>
 | #387</td></tr>
<tr class="even">
<td>
Meh, Resident Evil still wins handily.<br><br>Street Fighter winning would be a huge upset to me.<br><br>Actually,
the only thing that's shocked me this entire contest was Castlevania
beating the crap out of Halo. And maaaaybe Pokemon's run.<br>---<br>This space reserved for a new sig.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3294206&amp;board=8&amp;topic=29209811" class="name">champion88</a> |
Posted 7/24/2006 10:06:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322282799">message detail</a>
 | #388</td></tr>
<tr class="even">
<td>
this is an awesome thread</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/24/2006 11:14:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322301253">message detail</a>
 | #389</td></tr>
<tr class="even">
<td>
Gawd I need this point badly. Slip after slip, can today finally end my streak?<br><br>The one time Leon does not tail me too. Heh.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3662060&amp;board=8&amp;topic=29209811" class="name">YoAriel33</a> |
Posted 7/25/2006 1:31:07 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322330120">message detail</a>
 | #390</td></tr>
<tr class="even">
<td>
Final Fantasy vs. Mega Man<br>+9 mnm<br>+8 yo<br>+7 Ulti<br>+6 Leon<br>+5 Soul<br>+4 HM<br>+3 HaRRicH<br>+2 Moltar<br>+1 Lopen<br><br><b>The Rankings</b> (Through Final Fantasy/Mega Man)<br>1. Master Moltar (103)<br>2. yoblazer33 (92)<br>3. XxSoulxX (83)<br>4. UltimaterializerX (80)<br>5. Leonhart (79)<br>6. therealmnm (74)<br>7. Lopen (67)<br>7. HaRRicH (67)<br>9. Heroic Mario (58)<br><br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3191556&amp;board=8&amp;topic=29209811" class="name">LegendarySnake</a> |
Posted 7/25/2006 1:45:02 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322332276">message detail</a>
 | #391</td></tr>
<tr class="even">
<td>
At this point, Soul and HM are the only ones with realistic Resident Evil predictions.<br>---<br>I am the man who makes the impossible possible. I am the man, the legend: Solid Snake!</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29209811" class="name">Tatsumaki Senpuu</a> |
Posted 7/25/2006 2:06:45 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322335328">message detail</a>
 | #392</td></tr>
<tr class="even">
<td>
I sent you the analyses for round 3 with the exception of FF v. RE/SF.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/25/2006 3:21:40 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322344246">message detail</a>
 | #393</td></tr>
<tr class="even">
<td>
So Resident Evil's gonna beat Street Fighter easily, eh? <br><br>"But...but...the picture!"<br><br>Yeah, yeah, yeah. Say what you want.<br><br>(Note that I'm writing this at 4:20 A.M. EST, so who knows how close this will actually end up being)<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/25/2006 3:23:25 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322344414">message detail</a>
 | #394</td></tr>
<tr class="even">
<td>
Street Fighter will <i>rip RE apart</i> with the day vote.  The point is mine!  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29209811" class="name">DaruniaTheGoron</a> |
Posted 7/25/2006 4:14:59 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322349396">message detail</a>
 | #395</td></tr>
<tr class="even">
<td>
I hope you're right for once Lopen.<br>---<br><b>Sp2k6:<i> 28/30</i> Rank: <i>Tied for 460th</i> Losses: <i>Halo, GTA</i> </b>but im gonna cry if he (Sonic) loses. <br><b>Yesterday's Pick: <i>FF</i> Today: <i>SF</i> Tomorrow:<i> Zelda</i></b> - Zikten on the Sonic/SSB match</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/25/2006 11:47:00 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322399681">message detail</a>
 | #396</td></tr>
<tr class="even">
<td>
Final Fantasy..........74.19% 100574<br>Mega Man.................25.81% 34988<br>TOTAL VOTES.......................135562<br><br>92.62% of the brackets predicted this match correctly.<br><br>Wow, FF broke 100K votes again without even tripling Mega Man. That's <i>scary</i>. Anyway, FF won that one easy.<br><br>Today, Street Fighter was looking to make it interesting, and instead is getting buried with the day vote.<br><br>Soul - 4<br>Lopen - 3<br>HaRRich - 3<br>Moltar - 3<br>Mnm - 2<br>Yoblazer - 2<br>Ulti - 2<br>HM - 2<br>Leon - 1<br><br>Another point for Mnm! He's moving on up.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Street Fighter vs. Resident Evil - Bracket: <b>RE</b> - Vote: <b>RE</b> (28/30)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/25/2006 12:14:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322405748">message detail</a>
 | #397</td></tr>
<tr class="even">
<td>
"Buried" with the day vote? It's not even a 2000 vote lead.<br><br>Either way, looks like Soul's point.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/25/2006 3:50:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322458867">message detail</a>
 | #398</td></tr>
<tr class="even">
<td>
Well, it was a joke... but I take offense at the "for once"!<br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29209811" class="name">UltimaterializerX</a> |
Posted 7/25/2006 4:20:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322466780">message detail</a>
 | #399</td></tr>
<tr class="even">
<td>
I should start waiting until match pics are out before writing.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29209811" class="name">THEJackSparrow</a> |
Posted 7/25/2006 4:27:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322468404">message detail</a>
 | #400</td></tr>
<tr class="even">
<td>
Or you should stop blaming match pictures. There was no way your
prediction was going to be anywhere close to correct for this match
anyway.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">1</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=1">2</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=2">3</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=3">4</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=4">5</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=5">6</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=6">7</a></li>
<li>      8</li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=8">9</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=9">10</a></li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage8_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29209811&amp;page=7" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage8_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>