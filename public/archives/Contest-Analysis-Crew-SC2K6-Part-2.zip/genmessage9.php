<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">

<title>GameFAQs: Message List</title><link rel="stylesheet" type="text/css" href="genmessage9_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage9_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage9_files/bc.css"></head><body linkifytime="370" linkified="12" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage9_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage9_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29209811%26page%3D8"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage9_files/B1942706.xhtml" marginwidth="0" marginheight="0" hspace="0" vspace="0" bordercolor="#000000" frameborder="0" height="90" scrolling="no" width="728">
&lt;SCRIPT language='JavaScript1.1'
SRC="http://ad.doubleclick.net/adj/N3828.GameSpot/B1942706.9;abr=!ie;sz=728x90;ord=2006.07.30.22.06.47?"&gt;
&lt;/SCRIPT&gt;
&lt;NOSCRIPT&gt;
&lt;A
href="http://adlog.com.com/adlog/e/r=10153&amp;s=676411&amp;t=2006.07.30.22.06.47&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=00c17-gne-ad544C8F1BE158BB5D&amp;event=58/http://ad.doubleclick.net/jump/N3828.GameSpot/B1942706.9;abr=!ie4;abr=!ie5;sz=728x90;ord=2006.07.30.22.06.47?"&gt;
&lt;IMG
SRC="http://ad.doubleclick.net/ad/N3828.GameSpot/B1942706.9;abr=!ie4;abr=!ie5;sz=728x90;ord=2006.07.30.22.06.47?"
BORDER=0 WIDTH=728 HEIGHT=90 ALT="Click Here"&gt;&lt;/A&gt;
&lt;/NOSCRIPT&gt;
</iframe><img src="genmessage9_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0"><img src="genmessage9_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew - Part 2</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29209811&amp;page=8">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29209811" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">First
          Page</a> |
          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=7">Previous
          Page</a> |
          Page 9 of 10          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=9">Last
          Page</a>
      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=174920&amp;board=8&amp;topic=29209811" class="name">FFDragon</a> |
Posted 7/25/2006 4:27:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322468658">message detail</a>
 | #401</td></tr>
<tr class="even">
<td>
With a better pic, this match isn't even close.<br>---<br>Married to PepsiPlunge June 01, 2005: HERO'S PLUNGE!<br>(Metal Gear Solid 2)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29209811" class="name">THEJackSparrow</a> |
Posted 7/25/2006 4:30:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322469330">message detail</a>
 | #402</td></tr>
<tr class="even">
<td>
Of course it isn't. Because we can prove that.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3147227&amp;board=8&amp;topic=29209811" class="name">MnMZero</a> |
Posted 7/25/2006 5:49:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322489553">message detail</a>
 | #403</td></tr>
<tr class="even">
<td>
Because you can?  You can't prove it either way... You can still speculate though.<br>---<br>*Is therealmnm*<br><b>Proud Supporter of Mega Man X in Best. Series. Ever. Contest</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/25/2006 5:51:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322489938">message detail</a>
 | #404</td></tr>
<tr class="even">
<td>
I never said I could prove it, but then again, I don't have to. I'm not the one looking for excuses here.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/25/2006 6:43:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322502777">message detail</a>
 | #405</td></tr>
<tr class="even">
<td>
Yo, Moltar. I've sent in all of my round 3 analyses. Let me know if you got them.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/25/2006 10:28:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322560012">message detail</a>
 | #406</td></tr>
<tr class="even">
<td>
<b>Hyrule Division:</b> <i>Round 3 - Match 25</i> &#8211; (1)Legend of Zelda vs. (2)Metroid<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Legend of Zelda</b> - <i>Just imagine it after Twilight Princess!</i><br>Round 1 &#8211; 89.97% vs. Civilization (10.03%)<br>Round 2 &#8211; 80.32% vs. Mega Man X (19.68%)<br><br>MMX fails to break even 20% on the LoZ series.<br> <br><b>Metroid</b> - <i>Going to be just another victim.</i><br>Round 1 &#8211; 70.57% vs. Kirby (29.43%)<br>Round 2 &#8211; 52.56% vs. Pokemon (47.44%)<br><br>Pokemon ends up stronger than most of us thought and gives Metroid a challenge.<br><br>Round
3, another Zelda match, oh boy. I guess since FF got 100K against MM
without even getting the tripling, it&#8217;s time for Zelda to show off.<br><br>Before
Metroid stuggled with Pokemon, LoZ was beating MMX with over 80% of the
vote. Now, the original Mega Man series was abole to avoid getting
doubled by Final Fantasy. So this means either the original is stronger
or MMX suffered some SFF&#8230;or a combination of both. Whatever the case,
with LoZ able to SFF anything from Nintendo while Metroid can&#8217;t seem to
SFF anything from Nintendo, this is looking back for Samus&#8217; series.<br><br>That&#8217;s
not it too. We&#8217;ve already seen Link to the Past take on Super Metroid
and triple it. Now add in the rest of both series and you can add in a
little more for Zelda. Metroid could end up weaker than MMX, but I
think it can at least scrape up 20%. <br><br><b>Moltar&#8217;s Bracket Says:</b> Legend of Zelda will win.<br><br><b>Moltar&#8217;s Prediction is:</b> LoZ: 78% - Metroid: 22%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1646" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1646">http://www.gamefaqs.com/poll/index.html?poll=1646</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1639" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1639">http://www.gamefaqs.com/poll/index.html?poll=1639</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1633" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1633">http://www.gamefaqs.com/poll/index.html?poll=1633</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2122" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2122">http://www.gamefaqs.com/poll/index.html?poll=2122</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2115" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2115">http://www.gamefaqs.com/poll/index.html?poll=2115</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1361" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1361">http://www.gamefaqs.com/poll/index.html?poll=1361</a><br><br>And let's not forget about Samus's most recent debacle concerning all-Nintendo matches featuring her presence: <a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2442" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2442">http://www.gamefaqs.com/poll/index.html?poll=2442</a><br><br>Samus/Kirby was an anomaly, to be frank.<br><br>Prediction: Zelda with 80.99%<br> <br><br><br><b>Soul&#8217;s Analysis</b><br><br><i>LoZ defeated Mega Man X with 80.32%<br>Metroid defeated Pokemon with 52.56%</i><br><br>Another round, another SFF beatdown by Legend of Zelda! Hooray!<br><br>This
whole division is going to hell. Seriously. Mega Man is going to be the
second strongest game in this division, and it couldn't even break 20%
against Zelda. SFF, you killer of all things good.<br><br>Not much more
you can say about this match, really. Metroid underperformed in the
last round, and I'll be shocked as all hell if it outranks MMX.<br><br><b>My prediction: Legend of Zelda wins with 81.25% of the vote.</b><br> <br> <br> <br><b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: Boss Battle 2 (Ridley, SM)<br> <br>Well,
we all know what happens when The Legend of Zelda hooks up with another
Nintendo series right? SFF up the wazoo. Just ask Super Metroid and
Super Mario 64, who are still feeling their respective beatings in the
Spring 2004 Games Contest. And this is the strongest Zelda entity that
we've seen in a contest setting so far. Metroid has been showing
tendencies to <i>get</i> SFF'd, and it's allowing Pokemon to stay
close to it only serves as an omen to how bad LoZ will beat it. While
Metroid Prime's showing against The Wind Waker showed a little bit of
promise, the sheer numbers behind the Zelda franchise will kill
Metroid. Seeing how LoZ beat MMX about 80/20, if Metroid can avoid the
tripling, call it a moral victory. I personally think that Metroid is
stronger than Mega Man X, but it's also more susceptible to SFF from
LoZ. Look for a similar beating. <br> <br>Bracket: The Legend of Zelda<br>Vote: Metroid<br>Prediction: The Legend of Zelda with 79.5% (preparing to be boxed in...)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/25/2006 10:28:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322560174">message detail</a>
 | #407</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>Two matches, two 100,000+ vote
performances by the Legend of Zelda. That alone should speak for
itself. It&#8217;s also showing to be a massive vote draw as expected, as its
match against Mega Man X ended up being the third highest <i>ever</i>.
It already had a cakewalk to the finals of this contest, but it&#8217;s
looking to be even easier than we originally expected all the time.
With Metroid struggling to beat Pokemon (granted, we knew it was going
to destroy it anyway, but now it looks to be even uglier than
originally anticipated) and Metal Gear failing to double up Fire
Emblem, the Legend of Zelda may never know what it feels like to be
under 70% until the finals. <br><br>As far as Metroid is concerned, it was looking pretty good after a 70% showing against Kirby seemingly showed that it <i>was</i>
capable of pulling off SFF at all, but then&#8230;Pokemon happened. It was an
unexpected struggle for Metroid all day, as it was in the 52% range for
most of the match and at times had difficulty building its lead,
occasionally losing updates. The 6000 vote win was the second closest
match up to that point, which virtually nobody would have figured
before the Series Contest began. I figured it would have probably get
tripled by the Legend of Zelda, but now I&#8217;m doubting whether or not it
can avoid the quadrupling. <br><br>Keep in mind that A Link to the
Past tripled Super Metroid in the Games Contest, and Ocarina of Time
likely would&#8217;ve done a little better. I don&#8217;t know if it&#8217;s stronger
than Metroid Prime or not, though I wager it&#8217;d be close. In its favor,
Prime did manage to avoid being SFF&#8217;d by The Wind Waker, but it seems
like that would be one of the least likely Zelda games to manage SFF.
While I think Metroid could likely beat Mega Man X, I think the overlap
with the Legend of Zelda is greater and it will get beaten a little
worse. <br><br><i>Leonhart&#8217;s Prediction</i>: <b>The Legend of Zelda with 82.16%</b><br><br><br><br><b>Yoblazer&#8217;s Analysis</b><br> <br>Everyone
already knew this match's result before the contest started; the
difficulty revolves around predicting just how ugly it will look. After
watching Zelda maul Mega Man X and Metroid shockingly struggle with
Pokemon, the answer is looking clear - pretty damn ugly. The Legend of
Zelda is the god of all things SFF, and Metroid has shown, on more than
one occasion, that it is very unimpressive when it comes to swaying the
Nintendo fans. We all remember the 74/26 loss A Link to the Past gave
Super Metroid in 2004. The question now is whether or not this match
will be even more lopsided. I believe that all the other Zelda games do
more to strengthen their series (it <i>does</i> have the second
strongest game on the site, after all) than Metroid can, so the answer
is yes. Zelda earns its third straight quadrupling.<br><br>The Legend of Zelda<br>+ Two of the four most popular games on the site<br>+ Many more popular games<br>+ The holy grail of Nintendo fans<br>+ SFF wrecking machine<br>+ Credibility up the wazoo<br>+ Extremely impressive Round 2 win<br>- None here<br><br>Metroid<br>+ Lots of credibility<br>+ Old school hit and the Primes to get it on the right track again<br>- Very spotty SFF history<br>- Bad, bad Round 2 win<br>- It's up against Zelda<br><br>My prediction: The Legend of Zelda def. Metroid (81-19)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/25/2006 10:29:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322560300">message detail</a>
 | #408</td></tr>
<tr class="even">
<td>
<b>HM&#8217;s Analysis</b><br> <br><b>The Legend of Zelda</b><br><i>Previous Matches :</i><br><br>The Legend of Zelda &#8211; 89.97% -- 100,163<br>Civilization &#8211; 10.03% -- 11,169 <br><br>The Legend of Zelda &#8211; 80.32% -- 104,400<br>Mega Man X &#8211; 19.68% -- 25,577 <br><br><b>Metroid</b><br><i>Previous Matches :</i><br><br>Metroid &#8211; 70.57% -- 75,098<br>Kirby &#8211; 29.43% -- 31, 312 <br><br>Pokemon &#8211; 47.44% -- 59,428<br>Metroid &#8211; 52.56% -- 65,831 <br><br>Last
round was rather interesting both matches, but particularly Metroid&#8217;s.
It was a total shock to everyone when Pokemon actually made things <i>somewhat</i>
interesting at the beginning of the match. On Zelda&#8217;s side, it totally
blew out Mega Man X in a SFF-esque fashion. It also went on to gather
up its second straight match with 100,000+, which is extremely
impressive against an actual noteworthy opponent. <br><br>The Legend
of Zelda showed absolutely no mercy last round when it completely
decimated Mega Man X. I certainly never suspected it would be able to
quadruple Mega Man X, even with potential SFF. Link was only able to
double Mega Man, but the series that he comes from absolutely dominated
the Blue Bomber&#8217;s series. The other notable thing about this match is
the fact that Zelda got another 100,000+ votes, which is another
unprecedented feat. One thing is pretty clear &#8211; Zelda is not allowing
Final Fantasy to get all the attention. <br><br>Metroid, on the other
hand, totally bombed against Pokemon. Many of us were expecting a large
blowout, certainly larger than what Metroid did against Kirby. But
Pokemon was able to make things somewhat interesting. We knew that
Samus was not able to SFF things and that the Metroid series as a whole
was susceptible to SFF, but <i>wow</i>. Perhaps this speaks of
Pokemon&#8217;s strength over Metroid&#8217;s weakness, but we&#8217;ll unfortunately
never be able to find out with Zelda ready to lay a SFF smack down. <br><br>Yeah.
This match really does not require much analysis at all. It is clear
that Zelda is Nintendo&#8217;s top series in this contest. It has the ability
to SFF just about anything related to Nintendo, so this match should be
a fine example of that. It sucks that we won&#8217;t get a good read on this
division &#8211; I wanted to see how well Star Ocean held up &#8211; but it&#8217;s
unlikely it will ever matter because we&#8217;re not likely to ever get this
contest again. <br><br><b>Aitch Emm&#8217;s Bracket :</b> The Legend of Zelda<br><br><b>Aitch Emm&#8217;s Prediction :</b> The Legend of Zelda &#8211; 82% ; Metroid &#8211; 18%<br><br><b>Aitch Emm&#8217;s Vote :</b> The Legend of Zelda<br> <br> <br> <br><br><b>Lopen&#8217;s Analysis</b><br> <br>Well,
the way I see it, Metroid collapses in situations against Nintendo. You
saw Pokemon take it down to size&#8230; even though that was part Pokemon not
being as hated as we think. Er&#8230; anyway, I think at base Metroid's a bit
more popular than Mega Man X&#8230; but not as much as some would make us
believe. I also think that Mega Man X will hold up against Nintendo a
bit better than Metroid... because of the PS games, or because it's not
Metroid. I don't know.<br><br>So, what does this all mean? It means
that they're going to cancel out, of course! Legend of Zelda is gonna
win by about the same as it beat Mega Man X by. Let's subtract 2% from
my last pick for good measure. Why two? Because it's the first <i>prime</i> number.<br><br>&#8230; what?<br><br><b>Lopen's Prediction:</b> Legend of Zelda with 78.59%.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/25/2006 10:29:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322560519">message detail</a>
 | #409</td></tr>
<tr class="even">
<td>
<b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Legend of Zelda<br>Earlier this contest:<br>---LoZ - 89.97% on Civilization, 80.32% on Mega Man X<br>---Metroid - 70.57% on Kirby, 52.56% on Pokemon<br>Top 100 List comparison:<br>---LoZ:OoT - #2, LoZ:LttP - #4, LoZ - #30, LoZ:WW - #45, LoZ:MM - #46<br>---Super
Metroid - #24, Metroid Prime - #29, Metroid - #65, MP2: Echoes - #74
(Metroid Fusion was on the drop-down list yet didn't make the Top 100
List)<br>Best Game Ever x-stat comparison:<br>---LoZ:OoT - 46.18%
(32-64 Division runner-up), LoZ:LttP - 41.61% (16 Division runner-up),
LoZ:WW - 37.29% (was behind Starcraft), LoZ - 34.49% (8 Divison
runner-up)<br>---Metroid Prime - 33.4% (may have been SFF'd by LoZ:WW,
was behind Starcraft), Super Metroid - 21.63% (SFF'd by LoZ:LttP),
Metroid - 17.53% (SFF'd by SMB3)<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=525" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=525">http://www.gamefaqs.com/poll/index.html?poll=525</a><br><br>Yeah...LoZ alone beat all the other Nintendo franchises <i>combined</i>
-- including Metroid and before LoZ:WW -- so there's no way this match
is in question as to who's winning. However, look at a few things
there: one, that was held before the Gamecube was released...so, while
there was no LoZ:WW, Metroid's stock has risen a LOT; MP, MP2, MF, MZM,
MP:H, and maybe some other abbreviations I forgot. Two, skim over some
of the Metroid-related matches, and you'll see that Samus is both
rarely ever dishing SFF (only arguably in Samus/Isaac and
Metroid/Kirby) and often hurting because of SFF (SMB3/Metroid,
LoZ:LttP/SM, LoZ:WW/MP perhaps, and Mario/Samus)...yet, Samus herself
has resisted SFF against Link before, too, despite her biggest games
showing weakness to LoZ and Samus being SFF'd hard by a weaker Nintendo
character. Three, forget the poll and just compare the series -- as far
as generations go, LoZ has outdone Metroid in everything it does, and
it arguably has done the same if you compare systems or compare their
games in order of their strength (LoZ:OoT/SM, LoZ:LttP/MP, LoZ/Metroid,
and so on.....). Last, the leaderboard...if the leaderboard changes any
for this match, I'll slap somebody. Everybody on there should have LoZ
&gt; Metroid by now.<br><br>Legend of Zelda wins with 76.12%<br> <br><br> <br>Comments: Sorry they're a bit late. Connection problems. Anyway, LoZ from anywhere between the high 70's to low 80's.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29209811" class="name">UltimaterializerX</a> |
Posted 7/25/2006 10:29:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322560547">message detail</a>
 | #410</td></tr>
<tr class="even">
<td>
LOVE my positioning in this match.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/25/2006 10:34:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322561684">message detail</a>
 | #411</td></tr>
<tr class="even">
<td>
Ahh, Soul, we meet again!<br><br>This time, HM's boxed in, and I'm at the top! Huzzah! Now I can root for Zelda to <i>destroy</i> Metroid!<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/25/2006 10:36:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322562229">message detail</a>
 | #412</td></tr>
<tr class="even">
<td>
I can't believe I'm the third <i>lowest</i> prediction.  That's kinda ridiculous.  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1288566&amp;board=8&amp;topic=29209811" class="name">gtonizuka49</a> |
Posted 7/25/2006 10:45:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322564594">message detail</a>
 | #413</td></tr>
<tr class="even">
<td>
Just to make things a bit easier:<br><br>Leon - 82.16<br>HM - 82.00<br>Soul - 81.25<br>yo - 81.00<br>Ulti - 80.99<br>mnm - 79.50<br>Lopen - 78.59<br>Moltar - 78.00<br>HaRR - 76.12<br><br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/25/2006 10:49:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322565590">message detail</a>
 | #414</td></tr>
<tr class="even">
<td>
&gt;_&lt;<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1288566&amp;board=8&amp;topic=29209811" class="name">gtonizuka49</a> |
Posted 7/25/2006 10:50:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322565855">message detail</a>
 | #415</td></tr>
<tr class="even">
<td>
<b>&gt;_&lt;</b><br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/25/2006 10:52:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322566374">message detail</a>
 | #416</td></tr>
<tr class="even">
<td>
Just keep in mind that the last time Zelda had a match, I had the
highest prediction then, too, and the one boxed in right below me got
the point.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29209811" class="name">DaruniaTheGoron</a> |
Posted 7/25/2006 10:53:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322566618">message detail</a>
 | #417</td></tr>
<tr class="even">
<td>
Harrich is winning this point, BOOK IT! Zelda with 74.8%.<br>---<br><b>Sp2k6:<i> 28/32</i> Rank: <i>Tied for 460th</i> Losses: <i>Halo, GTA</i> </b>but im gonna cry if he (Sonic) loses. <br><b>Yesterday's Pick: <i>SF</i> Today: <i>Zelda</i> Tomorrow:<i> Metal Gear</i></b> - Zikten on the Sonic/SSB match</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1288566&amp;board=8&amp;topic=29209811" class="name">gtonizuka49</a> |
Posted 7/25/2006 11:08:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322570851">message detail</a>
 | #418</td></tr>
<tr class="even">
<td>
Street Fighter vs. Resident Evil<br>+9 Soul<br>+8 HM<br>+7 mnm<br>+6 Moltar<br>+5 yo<br>+4 HaRRicH<br>+3 Ulti<br>-1 Leon<br>-2 Lopen<br><br><b>The Rankings</b> (Through Street Fighter/Resident Evil)<br>1. Master Moltar (109)<br>2. yoblazer33 (97)<br>3. XxSoulxX (92)<br>4. UltimaterializerX (83)<br>5. therealmnm (81)<br>6. Leonhart (78)<br>7. HaRRicH (71)<br>8. Lopen (65)<br>9. Heroic Mario (66)<br><br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3432221&amp;board=8&amp;topic=29209811" class="name">Razordragon</a> |
Posted 7/25/2006 11:09:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322571160">message detail</a>
 | #419</td></tr>
<tr class="even">
<td>
8. Lopen (65)<br>9. Heroic Mario (66)<br><br>wtf mate.<br>---<br>Yoshifan PWN'd me. Kingdom Hearts is better than Castlevania.<br>SMB&gt;LOZ. That's right. (Sig bet until 8/22)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29209811" class="name">DaruniaTheGoron</a> |
Posted 7/25/2006 11:22:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322574525">message detail</a>
 | #420</td></tr>
<tr class="even">
<td>
****, I bet everything on Metroid in the spread betting thing. Oh well. I'm a fool :(<br>---<br><b>Sp2k6:<i> 28/32</i> Rank: <i>Tied for 2162nd</i> Losses: <i>Halo, GTA</i> </b>but im gonna cry if he (Sonic) loses. <br><b>Yesterday's Pick: <i>SF</i> Today: <i>Zelda</i> Tomorrow:<i> Metal Gear</i></b> - Zikten on the Sonic/SSB match</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/25/2006 11:32:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322577054">message detail</a>
 | #421</td></tr>
<tr class="even">
<td>
<i>Harrich is winning this point, BOOK IT</i><br><br>More like Leonhart is winning this point!<br><br>And I needed this one.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/26/2006 1:35:07 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322602969">message detail</a>
 | #422</td></tr>
<tr class="even">
<td>
Heh, I at first had LoZ getting 80.12%, but I gave the MP games alot of
extra credit...and we see where I'm at now because of it.<br><br>Great.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3672772&amp;board=8&amp;topic=29209811" class="name">TheGreatAlucard</a> |
Posted 7/26/2006 1:41:50 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322604098">message detail</a>
 | #423</td></tr>
<tr class="even">
<td>
Leon steals another point from me!<br><br>---<br>All that is necessary for evil to triumph...is for good men to do nothing... -- <i>Alucard</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/26/2006 2:23:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322713181">message detail</a>
 | #424</td></tr>
<tr class="even">
<td>
Heh, that's true. I got the Mario/Madden point from you because my prediction was just a <i>little</i> higher.<br><br>*makes note to do that more often*<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29209811" class="name">UltimaterializerX</a> |
Posted 7/26/2006 3:09:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322725444">message detail</a>
 | #425</td></tr>
<tr class="even">
<td>
8. Lopen (65)<br>9. Heroic Mario (66)<br><br>Nice math.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/26/2006 4:41:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322751690">message detail</a>
 | #426</td></tr>
<tr class="even">
<td>
Street Fighter.......49.27% 60308<br>Resident Evil........50.73% 62087<br>TOTAL VOTES..................122395<br><br>55.8% of the brackets predicted this match correctly.<br><br>Street Fighter comes close, very close, but Resident Evil manages to win, bad pic and all.<br><br>Today, Legend of Zelda is winning, like you expected otherwise.<br><br>Soul - 5<br>Lopen - 3<br>HaRRich - 3<br>Moltar - 3<br>Mnm - 2<br>Yoblazer - 2<br>Ulti - 2<br>HM - 2<br>Leon - 1<br><br>Another point for Soul!<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Legend of Zelda vs. Metroid - Bracket: <b>LoZ</b> - Vote: <b>Metroid</b> (30/32)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3662060&amp;board=8&amp;topic=29209811" class="name">YoAriel33</a> |
Posted 7/26/2006 7:31:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322796591">message detail</a>
 | #427</td></tr>
<tr class="even">
<td>
<i>8. Lopen (65)<br>9. Heroic Mario (66)<br><br>Nice math.</i><br><br>I lose.<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3672772&amp;board=8&amp;topic=29209811" class="name">TheGreatAlucard</a> |
Posted 7/26/2006 7:51:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322801629">message detail</a>
 | #428</td></tr>
<tr class="even">
<td>
'blazer is just anti-HM<i>!!</i><br><br>---<br>All that is necessary for evil to triumph is for good men to do nothing. -- <i>Alucard</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29209811" class="name">Tatsumaki Senpuu</a> |
Posted 7/26/2006 8:09:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322806257">message detail</a>
 | #429</td></tr>
<tr class="even">
<td>
I just sent you my Final Fantasy v. Resident Evil analysis, so tell me if you have any problems receiving it<i>!!</i><br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/26/2006 9:12:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322823324">message detail</a>
 | #430</td></tr>
<tr class="even">
<td>
<b>Snake Division:</b> <i>Round 3 - Match 26</i> &#8211; (1)Metal Gear vs. (2)Kingdom Hearts<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Metal Gear</b> - <i>MEAL GEAR?!?!</i><br>Round 1 &#8211; 69.9% vs. Soul Calibur (30.1%)<br>Round 2 &#8211; 65.23% vs. Fire Emblem (34.77%)<br><br>Metal Gear fails to double Fire Emblem last round.<br> <br><b>Kingdom Hearts</b> - <i>KINDGOM HEARTS!!!!</i><br>Round 1 &#8211; 73.12% vs. Harvest Moon (26.88%)<br>Round 2 &#8211; 51.33% vs. Castlevania (48.67%)<br><br>In a close match, Kingdom Hearts barely squeaks by Castlevania<br><br>In
our next match in Round 3, we have Metal Gear vs. Kingdom Hearts, which
looks to be the closest match of Round 2. Still, that isn&#8217;t really
saying much.<br><br>Last Round, Metal Gear had a bit of trouble with
Fire Emblem. While many of us expected FE to be weaker than Soul
Calibur, it ended up doing much better. Seems we underestimated it.
Kingdom Hearts, on the other hand, came very close to losing against
Castlevania. In the end, it was the day vote that gave it the victory. <br><br>So,
is MG in any trouble because it failed to double Fire Emblem while KH
beat Castlevania which beat Halo with 55%? No, it isn&#8217;t, and-<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2116" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2116">http://www.gamefaqs.com/poll/index.html?poll=2116</a>
Oops, I seemed to have dropped this. Oh well, biased match pic and all,
KH most likely &gt; Sora, and KH the series is stronger now that KH2 is
out, but still that&#8217;s quite the gap to make up. Metal Gear has this in
the bag, but it&#8217;ll be impressive if it could break 60%<br><br><b>Moltar&#8217;s Bracket Says:</b> Metal Gear will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Metal Gear: 57% - Kingdom Hearts: 43%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>This
is such an odd match. As much as I'd like to think that Kingdom Hearts
will do well, Snake/Sora kind of makes you wonder if KH is in for
another colossal beating. And given that there aren't any stats that
will give us a decent idea of how this match will go, it's all
guesswork. The only thing people will be certain of is that MGS wins,
though Karma Hunter made a great post in a recent stats topic about how
KH has a decent enough chance. I'm just too lazy to dig it up.<br><br>Prediction: MGS with 57.89%<br> <br><br><br><b>Soul&#8217;s Analysis</b><br><br><i>Metal Gear defeated Fire Emblem with 65.23%<br>Kingdom Hearts defeated Castlevania with 51.33%</i><br><br>Probably the most entertaining division of the entire contest ends with an easy to call match.<br><br>Metal
Gear showed some weakness last round by letting Fire Emblem get 34%. Of
course, we don't know how strong FE could be, but it's Metal Gear! You
know, the "fourth strongest series in this contest"? Well, I guess you
can throw that claim out the window after that performance.<br><br>Kingdom
Hearts went into the last round as the slight favorite (although you
wouldn't believe it after reading this topic for that match), and
performed rather well. It started out pretty bad, but was able to
complete the comeback and win with 51% of the vote. Pretty impressive
considering the stregth of Castlevania.<br><br>So, who's coming out on
top of this one? Metal Gear. Why? Simply because it's more popular
here. We all saw what Snake did to Sora, and you should expect the same
thing here. Yeah, characters do not equal series, but I just don't see
how this battle can turn out differently from the last match. People
can say that Sora underperformed based on the picture, but I just don't
think a picture can have that much of an effect.<br><br><b>My prediction: Metal Gear wins with 60.01% of the vote</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/26/2006 9:13:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322823690">message detail</a>
 | #431</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br>  <br>All Kingdom Hearts needs to perform
well is the complete and utter lack of expectations. In the Games
Contest, it was predicted to win its four-pack easily and possibly
contend for an Elite Eight spot. What does it do? Struggle to defeat
Soul Calibur and fails to put up much of a fight against StarCraft.
Sora gets doubled by Aeris in SC2K3, leaving him completely devoid of
expectation by most of the board. What does he do? Answer: Double up
HK-47 (see what I did there?) and get 60% on Ryu Hayabusa before
getting a respectable performance on Samus. In SC2K5, Sora was supposed
to make Agent 47 look like Neo Tanner, and he barely breaks 70%,
leaving his match against Alucard in question. He wins comfortably,
leaving people to think he could do very well on Solid Snake. He gets
beaten nearly as badly as he did against Samus. Seeing a pattern here? <br><br>Fast
forward to this Series Contest. Before the contest, Kingdom Hearts was
the easy favorite to win its four-pack on Board 8 and was even
considered to be a sexy upset pick over Metal Gear. In the first round,
Kingdom Hearts is expected to put a beatdown of epic proportions on
Harvest Moon, and it doesn&#8217;t even end up tripling it. Coupled with
Castlevania getting 55% on Halo (which outperformed Kingdom Hearts in
the Games Contest anyway), and suddenly, expectations disappear. It
becomes the minority pick for the second round, and even this very
Analysis Crew unanimously picks Castlevania to win. Naturally, Kingdom
Hearts comes back from 1200 votes to win by 3400 in the end. Why would
you expect anything different? <br><br>And going into this match with
Metal Gear, Kingdom Hearts has no aspirations of an upset on the board,
which plays right into its hands. It doesn&#8217;t have to worry about
impressing. It can just do its thing, yo. On the opposite end, Metal
Gear was looking to dominate coming into this match after scoring 70%
on Soul Calibur. But then Fire Emblem humbled the top seed a bit,
managing to avoid the doubling when it was thought to be pure fodder
coming into the contest. I don&#8217;t know if the sprite round is to blame
or if we just underestimated Fire Emblem. It&#8217;s hard to say, but it
doesn&#8217;t really matter in the grand scheme of things. <br><br>Of
course, I&#8217;d imagine a lot of people are going to be pointing back to
Solid Snake/Sora as a basis for an overperformance in this match, but
I&#8217;m not buying it. Kingdom Hearts is so much more than Sora, no doubt
about that. Solid Snake IS Metal Gear, for all intents and purposes. I
don&#8217;t really know what that&#8217;s worth though. However, I&#8217;ll probably be
in the minority and think that Kingdom Hearts will actually do fairly
well for itself here. Expect Metal Gear to start the match with close
to 60% and watch Kingdom Hearts whittle away at that percentage all day
long. <br><br><i>Leonhart&#8217;s Prediction</i>: <b>Metal Gear with 55.44%</b><br> <br> <br> <br><b>HM&#8217;s Analysis</b><br><br><b>Metal Gear</b><br><i>Previous Matches :</i><br><br>Metal Gear &#8211; 69.89% -- 77,349<br>Soul Calibur &#8211; 30.11% -- 33,321 <br><br>Metal Gear &#8211; 65.23% -- 74,017<br>Fire Emblem &#8211; 34.77% -- 39,457 <br><br><b>Kingdom Hearts</b><br><i>Previous Matches :</i><br><br>Kingdom Hearts &#8211; 73.12% -- 81,735<br>Harvest Moon &#8211; 26.88% -- 30,051 <br><br>Castlevania &#8211; 48.67% -- 62,435<br>Kingdom Hearts &#8211; 51.33% -- 65,851 <br><br>The
last round was rather interesting for both of these series from my
perspective. I had anticipated that Fire Emblem would have the strength
to avoid a tripling, much less a doubling, but it managed to do so
without too much problem. I, of course, have reason to believe that
this had more to do with various other factors over simply Metal Gear&#8217;s
weakness, like many have suspected. Kingdom Hearts put up a surprising
performance in that it actually managed to defeat Castlevania,
something I did not consider much of a possibility, but perhaps that
was my bias clouding my judgment. Either way, both matches have no
effect on the result of this match, where Metal Gear shall win with
ease.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/26/2006 9:14:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322823894">message detail</a>
 | #432</td></tr>
<tr class="even">
<td>
While it is true that Metal Gear did not manage to double Fire Emblem,
it would be a bit foolish to believe that it was Metal Gear&#8217;s weakness
before looking at all of the other various factors. In truth, there is
no one dominant factor, I believe, that made this result happen;
rather, it was a bunch of factors that contributed to it. I almost
think people are foolishly putting the blame on Metal Gear and it being
&#8220;exposed.&#8221; Make no mistake; Metal Gear is still a powerhouse franchise
in this contest. I still would not take anything over it outside of the
Big Three, though many would disagree with me on this. In order to
justify the high percentage that I&#8217;ll be using in this match, it is
necessary to show why I think Metal Gear did not disappoint, but
instead, it was Fire Emblem showing us its strength. <br><br>First
and foremost, Fire Emblem is likely to have increased its strength
significantly since its appearance in the Games Contest. When the match
against FFTA took place, it had only been released for <i>four months</i>,
which is hardly any time to gather up good strength. Since then, it has
released two other games and has increased awareness exponentially.
Both of those releases &#8211; another Game Boy Advance release and a
GameCube release &#8211; sold reasonably well. There is even another Fire
Emblem game heading to the Wii. Sure, this series is not a powerhouse
by any means, but it still would not be bottom of the line fodder like
many had suspected. <br><br>Secondly, the match picture, I believe,
played an interesting role in this one. Since it is sprite round, Metal
Gear was blessed with the unrecognizable sprites from the Metal Gear
games back in the 80s. It is a pretty well known fact that Solid Snake
does not perform well when he is given a sprite, so the same should
likely hold true for Metal Gear as well. But perhaps the most
interesting aspect of this is that the name of the series represented
is &#8220;Metal Gear,&#8221; not &#8220;Metal Gear Solid.&#8221; Sure, we all realize that
Metal Gear Solid is definitely taken into consideration, but in this
match picture we saw the old games combined with the &#8220;Metal Gear&#8221; name
that could have led people to believe that this was the original Metal
Gear franchise against Fire Emblem. Not the biggest factor, but still
worth mentioning. <br><br>Lastly, Fire Emblem is the up and coming
Nintendo RPG series. From what we have seen of this contest, Nintendo
related series have performed extremely well. It would be no surprise
to see Fire Emblem continue that line of better than expected
performances. That leads into the idea of FE possibly receiving some
SFF against FFTA back in the Games Contest. Both are in the same genre,
both were popular (FFTA far moreso) at the time, and both were on the
same system. On top of that, it&#8217;s possible that FFTA might have
suffered some SFF against Final Fantasy X. So its strength in the Games
Contest is underrated on top of the inevitable increase in strength
from having more games released since. <br><br>Overall, all of this
adds up to Metal Gear not necessarily being &#8220;exposed&#8221; or showing
weakness, but rather, Fire Emblem showing it is now bottom of the line
fodder like many had anticipated. It actually carries plenty of
strength here, and it should not be terribly surprising after this
match. All that said it still got beat down heavily against Metal Gear,
no matter how you slice it. This match is not going to stop Metal Gear
from laying a nice beating on Kingdom Hearts, I think.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/26/2006 9:14:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322824005">message detail</a>
 | #433</td></tr>
<tr class="even">
<td>
As for Kingdom Hearts, it performed pretty well against Castlevania in the previous round. We got to see that the day vote <i>still</i>
does exist, as it managed to take Castlevania&#8217;s built up 1,100 vote
lead and end up winning by over 3,000 itself. It still had a close
encounter with Castlevania, which ruins its shot completely at even
giving Metal Gear a scare here. And, in all likelihood, Kingdom Hearts
loses this match without Kingdom Hearts II, so its effect is definitely
present. The only worrisome thing here is that Kingdom Hearts showed it
does have a solid day vote still, and Metal Gear is notorious for
having a bad day vote. No worry about the lead, but the percentage is
likely to be brought down by quite a bit in the match. <br><br>Metal
Gear has absolutely nothing to worry about when it comes to winning
this match-up. You have numerous people on the board saying that
Kingdom Hearts may have a chance or that they predicted it to beat
Metal Gear, but that <i>never</i> made any sense. There is nothing
that Kingdom Hearts has in its favor over Metal Gear at all. I mean, if
you are on the fence, Snake/Sora should be a clear warning sign that
things are likely to be <i>worse</i> than you initially expect due to whatever fanbase overlap there may be.  <br><br>When
you compare games, I feel that every single Metal Gear Solid game
outranks the original Kingdom Hearts. Metal Gear Solid is obviously
underrated due to FFVII SFF, Metal Gear Solid 3 is likely to be
stronger than Metal Gear Solid 2, and Kingdom Hearts itself is
overrated through StarCraft&#8217;s run &#8211; the actual cheated votes were never
removed. That puts KH/MGS2 essentially at 50/50, and I&#8217;ll favor Metal
Gear Solid 2 in that match every time (I&#8217;ll always go with the Metal
Gear related entry whenever it has a realistic shot at winning, and
even sometimes unrealistic. Believe &#8211; 2007). That means Kingdom Hearts
has to rely on a <i>monstrous</i> boost from Kingdom Hearts II, which
is incredibly unlikely. I would still take MGS over KH and KHII with
ease, and MGS3 is not far off from where KHII might be, if it is even
above the original KH. <br><br>The other <i>potential</i> chance that
Kingdom Hearts had at having some advantage was to get a match against
Metal Gear in the sprite round, but that has come and gone. It is
almost assured that we&#8217;re going to see some type of picture from the
Metal Gear Solid portion of the series, which means there will be no
worry about the picture being bad or any voters being confused on what
they are voting for. Heh, the last time these two entries met
(Snake/Sora), it had the greatest picture in contest history &#8211; and
perhaps one of the most biased &#8211; so things certainly don&#8217;t look in
favor of KH there either. <br><br>So yeah, just about <i>everything</i>
imaginable points to Metal Gear winning, and with ease. Even going by
this contest, Metal Gear has taken out two respectable franchises
without much of a problem. Anyone hoping for Kingdom Hearts to pull
this out is a wee bit crazy. The sales, the popularity, the games, the
contest experience, previous matches &#8211; everything points to Metal Gear
winning. No one in the Crew is going to be going with a potential
upset, so the difference here will be the confidence in Metal Gear&#8217;s
ability to win big. Me? I have plenty of confidence in it. <br><br>To
me, this match is all about seeing Metal Gear live up to my statements
about never falling under 58% in this division. I have never doubted
that Metal Gear would be a real force in this contest &#8211; the fourth
strongest series no matter what &#8211; and this division not having any <i>really</i>
strong opponents has never made me think Metal Gear would end up that
way just because it is facing what a certain Stats topic poster likes
to call &#8220;chumps.&#8221; If Metal Gear can at least meet the percentage I&#8217;m
predicting, I&#8217;ll be going for the 30%+ prediction in the next round,
solidifying that Metal Gear is on a tier of its own in the extrapolated
stats.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/26/2006 9:15:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322824216">message detail</a>
 | #434</td></tr>
<tr class="even">
<td>
<b>Aitch Emm&#8217;s Bracket :</b> Metal Gear.<br><br><b>Aitch Emm&#8217;s Prediction :</b> Metal Gear &#8211; 59% ; Kingdom Hearts &#8211; 41%<br><br><b>Aitch Emm&#8217;s Vote :</b> Metal Gear &#8211; Best. Series. Ever. baby!<br> <br><br> <br><br><b>Yoblazer&#8217;s Analysis</b><br> <br>With
25 matches safely in the books, we've finally come to one where I'm
split on which entrant to vote for. I love the hell out of both these
series and want to see them both do well. Can't have everything you
want, I guess.<br><br>I see Kingdom Hearts as the "reliable middleman"
of the contest. It hasn't overpowered anything, it hasn't really
impressed anyone, but it has done its job by making it this far. One
lower-end blowout of Harvest Moon and a close match with Castlevania
later, it's going up against Metal Gear in the divisional finals. The
top-seeded Metal Gear, which had a poor showing against Fire Emblem (MG
always performs poorly in the sprite round, so it's no big deal), will
be looking to rebound here, and it should be able to do so. Of course,
none of this really matters, because if Kingdom Hearts can't score 52%
on Konami's #2, I see no reason to believe that it could beat Konami's
#1. That's all there is to it. Consolation prize: I'll probably end up
giving it my vote due to Hot Mermaid Factor.<br><br>Metal Gear<br>+ Three very popular games in the last eight years<br>+ Tons of credibility and some old school influence<br>+ Spans a surprising amount of consoles and eras<br>- That prissy little Elf boy is up next, Snake. Can't take him, can ya?<br><br>Kingdom Hearts<br>+ Two very strong games<br>+ Most popular new release on the site<br>+ The most popular non-video game character in Ariel<br>- Only three games (only two of which have actual strength)<br>- It's a rookie<br>- Hasn't really impressed yet<br><br>My prediction: Metal Gear def. Kingdom Hearts (58-42)<br><br> <br><br><b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: Forze del Male (Kingdom Hearts)<br><br>This
match is looking to be interesting even though I don't think who will
win should be debated at all. As I've said before, Kingdom Hearts is a
much newer series than Metal Gear, and among fans of both it would be
quite hard to displace Metal Gear, which is already a huge favorite of
many gamers. This will probably be Metal Gear's last chance to impress
as the Big Three have decimated all in their path. Metal Gear <i>may</i>
have shown a bit of weakness against Fire Emblem, but given its
Nintendo pedigree, it was hardly surprising. Kingdom Hearts doesn't
have the full support of the Nintendo fanbase, so this matchup will
probably be a free for all among those voters. <br><br>Kingdom Hearts
has already proven its strength by knocking out Castlevania, which
handled Halo pretty easily. That pretty much puts all the debates away
about Kingdom Hearts being weaker than Halo and Halo 2 supposedly doing
more for its series than Kingdom Hearts 2 has done for KH. As I've said
before, Kingdom Hearts has come a long way since being the button
masher with Disney and FF characters in it. It's placed its own stamp
as a game, with memorable villains and moments comparable to the best
of RPGs. Granted it still might not be Metal Gear strong, but it has
made its mark. It won't quite roll over against Metal Gear. After
seeing Fire Emblem avoid the doubling, I wouldn't expect Metal Gear to
beat Castlevania more than 60-40. Since Kingdom Hearts is stronger than
Castlevania, I say it breaks 40%, SFF be damned!<br><br>Bracket: Metal Gear<br>Vote: Kingdom Hearts<br>Prediction: Metal Gear with 57.35%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/26/2006 9:16:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322824418">message detail</a>
 | #435</td></tr>
<tr class="even">
<td>
<b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Metal Gear<br>Earlier this contest:<br>---MG - 69.89% against Soul Calibur, 65.23% on Fire Emblem<br>---KH - 73.12% on Harvest Moon, 51.33% on Castlevania<br>Top 100 List comparison:<br>---MGS - #8, MGS3 - #21, MGS2 - #41<br>---KH - #16<br>Best Game Ever x-stat comparison:<br>---MGS2 - 32.52%, MGS - 28.7% (may have been SFF'd by FF7), MG - 14.13%<br>---KH - 34.7% (was behind Starcraft)<br><br>I'll
keep it fairly short, but, essentially, MG wins. We've seen Solid
over-perform big against Sora, we've seen two Konami-favorite polls
where MG outdoes CV comfortably and KH barely beat CV this contest (nor
did Sora impress that much against Alucard last year), MG has several
more games, MG has been around MUCH longer (what is it, a 15-year gap
between MG and KH?) and has spanned several systems, MG's biggest game
is bigger than any KH game -- hell, with MGS3:S out now, it's <i>possible</i>
MGS3 is bigger than any KH game, MG obliterated Soul Calibur and KH
barely beat SC in the Game Contest, both Revolver and an SFF'd Liquid
outdid Ansem in the Villain Contest stats...did I cover all the bases?
Oh yeah, and MG rules. If it wasn't for FE gettin' about 35% on MG,
that would be what I'd predict for KH...but since I'm nice and will
assume MG/KH won't have an over-performance like Solid/Sora, I'll bump
it up a lil'.<br><br>Metal Gear wins with 61.12%<br> <br><br><br><b>Lopen&#8217;s Analysis</b><br><br>First, I thought Halo would be here. Then, I thought Castlevania would be here. Now, we're left with <b>KINGDOM HEEAAARRRTTSSS!!!</b>
Sorry. Well, I didn't think Metal Gear was going to be some sort of
unstoppable beast when this contest started. I figured it'd win the
division, but not by some sort of landslide. I was thinking Halo or
Castlevania might have an outside chance of beating it. And the contest
itself has me doubting it even more. Round 1 it came in looking good
enough&#8230; but in round 2, round 2 was inexcusable. It couldn't even <i>double</i>
Fodder Emblem! Pathetic! Had Castlevania handled KH (by handled, I mean
a big win) like I thought it would, I'd have had CV taking this&#8230; I
tried to start a bandwagon, you know! But alas, it didn't. KH squeaked
by.<br><br>So&#8230; how much more popular is Metal Gear than Castlevania? Probably not <i>that</i>
much, really. That old "best Konami series" poll has Metal Gear with
the advantage, but Castlevania has some advantages that Metal Gear
doesn't. More games, a much better system spread. Symphony of the Night
isn't much less popular here than MGS, arguably Metal Gear's most
popular game. Heck, part of me wants to take Kingdom Hearts here, just
so we can't get made absolute fools of again&#8230;<br><br>But, that would be
"playing the Price is Right games", and no one wants to see that,
right? I don't honestly think KH will win this. A chance? Yeah. A
chance, but not one I'll take. And there's always the chance that Metal
Gear will beat it into the dirt hard like Snake/Sora's match of last
year implies will happen. But I think KH will hold up better than that.
Much better.<br><br><b>Lopen's Prediction:</b> Metal Gear with 52.50%.<br> <br> <br> <br>Comments: Nothing to see here other than HM fanboyism and a Metal Gear win.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/26/2006 9:16:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322824518">message detail</a>
 | #436</td></tr>
<tr class="even">
<td>
Writing a book there, HM?<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29209811" class="name">Tatsumaki Senpuu</a> |
Posted 7/26/2006 9:17:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322824825">message detail</a>
 | #437</td></tr>
<tr class="even">
<td>
Yeah. It's called "Metal Gear Owns You(r) Soul."<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/26/2006 9:18:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322825025">message detail</a>
 | #438</td></tr>
<tr class="even">
<td>
Man, and I thought <i>my</i> write-up was long.<br>---<br>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden<br>Presea, Chun-Li, Tifa, Celes, Quistis, Amy Rose</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/26/2006 9:18:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322825053">message detail</a>
 | #439</td></tr>
<tr class="even">
<td>
And right when I thought I had the highest pick locked up, I noticed I missed someone.<br><br>Damn you Harrich!<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3662060&amp;board=8&amp;topic=29209811" class="name">YoAriel33</a> |
Posted 7/26/2006 10:14:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322841359">message detail</a>
 | #440</td></tr>
<tr class="even">
<td>
The Legend of Zelda vs. Metroid<br>+9 Leon<br>+8 HM<br>+7 Soul<br>+6 yo<br>+5 Ulti<br>+4 mnm<br>+3 Lopen<br>+2 Moltar<br>+1 HaRRicH<br><br><b>The Rankings</b> (Through The Legend of Zelda/Metroid)<br>1. Master Moltar (111)<br>2. yoblazer33 (103)<br>3. XxSoulxX (99)<br>4. UltimaterializerX (88)<br>5. Leonhart (87)<br>6. therealmnm (85)<br>7. Heroic Mario (74)<br>8. HaRRicH (72)<br>9. Lopen (68)<br><br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/26/2006 10:15:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322841677">message detail</a>
 | #441</td></tr>
<tr class="even">
<td>
I'll pass up Ulti with my MG/KH pick. Bank on it!<br>---<br>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden<br>Presea, Chun-Li, Tifa, Celes, Quistis, Amy Rose</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3662060&amp;board=8&amp;topic=29209811" class="name">YoAriel33</a> |
Posted 7/26/2006 10:54:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322852040">message detail</a>
 | #442</td></tr>
<tr class="even">
<td>
HaRR - 61.12<br>Soul - 60.01<br>HM - 59.00<br>yo - 58.00<br>Ulti - 57.89<br>mnm - 57.35<br>Moltar - 57.00<br>Leon - 55.44<br>Lopen - 52.50<br><br>All for Metal Gear.<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/27/2006 12:37:01 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322876979">message detail</a>
 | #443</td></tr>
<tr class="even">
<td>
The day vote shift will be interesting to see.<br>---<br>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden<br>Presea, Chun-Li, Tifa, Celes, Quistis, Amy Rose</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/27/2006 2:01:45 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322891266">message detail</a>
 | #444</td></tr>
<tr class="even">
<td>
Man... I'm making <i>horrible</i> predictions lately.  Good thing the scoring system is unofficial and doesn't count!  &gt;_&gt;<br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=484834&amp;board=8&amp;topic=29209811" class="name">BlAcK TuRtLe</a> |
Posted 7/27/2006 11:45:07 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322953821">message detail</a>
 | #445</td></tr>
<tr class="even">
<td>
Looks like this match will probably end up in the 58.5-59% range<br><br><br><b>TuRtLe</b><br>~~~<br>Like Darth Maul, the bastard child of Michael Flatley and Hellboy. -trancer1<br>Nominate <b>Carmen Sandiego</b> for Character Battle V</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/27/2006 2:56:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=322997556">message detail</a>
 | #446</td></tr>
<tr class="even">
<td>
At this point, unless Metal Gear <i>really</i> bombs in percentage, this looks like either HM's or yo's point.<br>---<br>Squall, Tidus, The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden<br>Presea, Chun-Li, Tifa, Celes, Quistis, Amy Rose, Mei Ling</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/27/2006 5:25:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323034972">message detail</a>
 | #447</td></tr>
<tr class="even">
<td>
The Legend of Zelda.....84.7% 114009<br>Metroid..............................15.3% 20595<br>TOTAL VOTES..........................134604<br><br>89.78% of the brackets predicted this match correctly.<br><br>LoZ
received over 114K vote against Metroid? Ouch, that's some bad SFF
combined with the Metroid series just overall not being all that
strong. Samus is leagues ahead of it.<br><br>Today, Metal Gear is having an easy time against Kingdom Hearts.<br><br>Soul - 5<br>Lopen - 3<br>HaRRich - 3<br>Moltar - 3<br>Leon - 2<br>Mnm - 2<br>Yoblazer - 2<br>Ulti - 2<br>HM - 2<br><br>Leon had the highest pick, so he gets the point.<br>---<br>Moltar Status: Wanting you to <b>Nominate Shadow the Hedgehog!</b><br>Metal Gear vs. Kingdom Hearts - Bracket: <b>MG</b> - Vote: <b>MG</b> (34/36)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29209811" class="name">THEJackSparrow</a> |
Posted 7/27/2006 9:17:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323089949">message detail</a>
 | #448</td></tr>
<tr class="even">
<td>
This one is basically yo's.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/27/2006 9:25:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323092067">message detail</a>
 | #449</td></tr>
<tr class="even">
<td>
<b>Mushroom Division:</b> <i>Round 3 - Match 27</i> &#8211; (1)Super Mario Bros. vs. (2)Super Smash Bros.<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Super Mario Bros.</b> - <i>Featuring Mario, Luigi, Toad, Peach, Yoshi and Bowser!</i><br>Round 1 &#8211; 92.21% vs. Madden NFL (7.79%)<br>Round 2 &#8211; 81.13% vs. Warcraft (18.87%)<br><br>SMB destroys Warcraft in Round 2 with over 80% of the vote.<br> <br><b>Super Smash Bros.</b> - <i>Featuring Mario, Luigi, Toad&#8230;Peach&#8230;&#8230;.Yoshi&#8230;..and&#8230;.Bowser?!</i><br>Round 1 &#8211; 76.37% vs. Dragon Quest (23.63%)<br>Round 2 &#8211; 57.66% vs. Sonic (42.34%)<br><br>SSB wins easily in a heavily debated match against Sonic.<br><br>The
Road to an all 1 seed Final Four grows closer as Super Mario Bros. goes
up against Super Smash Bros. If this match doesn&#8217;t just scream SFF, I
don&#8217;t know what does. Hell, both series have Super and Bros. in the
titles!<br><br>Anyway, Super Mario Bros. strongest game, SMB3, is
stronger than SSB:M. SMB is also a much larger series, and while that
didn&#8217;t help Sonic, SMB has plenty of strong games to pull from. Add on
to the fact that SMB is already looking to SFF SSB and you have got
yourselves a blowout. Shame too, because SSB could potentially be the
4th strongest series in the Contest.<br><br><b>Moltar&#8217;s Bracket Says:</b> Super Mario Bros. will win.<br><br><b>Moltar&#8217;s Prediction is:</b> SMB: 76% - SSB: 24%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>Most
boring late-round contest match in a LONG ****ing time, though I'd love
to know what warped logic people have for thinking SSB will win. This
has SFF written all over it, though SSB's insane fanbase might keep it
over 30%. Or not.<br><br>Prediction: Mario with 79.99%<br> <br><br><br><b>Soul&#8217;s Analysis</b><br><br><i>SMB defeated Warcraft with 81.13%<br>SSB defeated Sonic with 57.66%</i><br><br>Same Fanbase Factor. The killer of many potential interesting matches. The killer of stats. It's not a pretty sight to see.<br><br>And
look what we have here? Mario Vs. a Mario spinoff. This match was hyped
to go either way, but really, think about this. It's Mario Vs. Mario
spinoff. Mario will come out on top, and with the added SFF, will look
stronger then the series actually is.<br><br>The question on a lot of
people's mind is what will be the fourth strongest series in this
contest? FF, LoZ and SMB have all cemented themselves as the best of
the best, but which series would follow them? As of right now, SSB and
Metal Gear are the favorites for that elusive fourth spot. Sadly, SSB
has to deal with SFF in this round, so Metal Gear will look like the
clear winner after all is said and done. Does that mean MG could beat
SSB? Sadly, we might never know...<br><br><b>My prediction: Super Mario Bros. wins with 75.01% of the vote</b><br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br><br>Some
people thought SSB would be taking this. Well, I'm here to tell you
that's just foolishness. SSBM is popular here, but you know what? Signs
point to Super Mario Brothers 3 being <i>more</i> popular here. And
you know what? I don't think the N64 game adds enough to even offset
that. You put Super Mario Brothers 3 vs. Super Smash Brothers (the
whole series) here, and I'm taking Super Mario Brothers 3. Kinda sad if
that's true, because that means one Mario game beats every Sonic game
57-43%+. Some rivalry, huh?<br><br>Come on&#8230; you like tangents. And now, here comes another match where the almighty Mario shows his power by SFFing <i>anything</i>.
He hardly even has to stretch here, though. He can see SSB's Nintendo
shaped cardboard box parked on his freshly cut grass. Needless to say,
he's not pleased. Is Final Fantasy <i>so screwed</i> here?<br><br><b>Lopen's Prediction:</b> Super Mario Brothers with 77.77%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/27/2006 9:26:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323092238">message detail</a>
 | #450</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>First of all, well done, Super Smash
Brothers. Well done. The match against Sonic was very impressive, I
must say. However, your road ends here. That much is obvious. After
all, Super Mario Brothers scored over 81% on Warcraft, a series that
would destroy Dragon Quest head-to-head, which Super Smash Brothers
beat by less. With that said, I don&#8217;t think Super Mario Brothers will
get the massive SFF that some people are predicting. I think SSBM could
hold its own against Mario 3 and perhaps beat the rest of the series.
But really, this is a boring match to analyze seriously. With that
said: <br><br>J.R.: MARIO PINS SONIC CLEANLY IN THE MIDDLE OF THE RING
TO CAP OFF A DOMINANT PERFORMANCE BY SUPER SMASH BROTHERS IN THIS
MATCH! <br><br>*As Mario celebrates with Link and Samus, the name
&#8220;Super Smash Brothers&#8221; appears on the Jumbotron screen declaring the
winner. However, as they celebrate, a familiar-looking Koopa peaks out
from under the ring* <br><br>WAIT, BOWSER IS CRAWLING OUT FROM UNDER
THE RING! WHAT IS HE DOING?! OH MY! HE JUST ATTACKED SAMUS FROM BEHIND!
WHAT IN THE WORLD IS GOING ON HERE?! IS HE BETRAYING THE SMASH
BROTHERS?! <br><br>*Link scurries out of the ring and grabs a steel chair. He slides back into the ring, looking to take on Bowser* <br><br>HANG
ON, LINK HAS GRABBED A STEEL CHAIR AND HE&#8217;S COMING BACK TO THE RING!
MARIO IS ASKING FOR THE CHAIR! LOOKS LIKE HE WANTS TO SETTLE THIS
HIMSELF! <br><br>*Mario takes the steel chair from Link and stares
down Bowser menacingly. Then suddenly, Mario turns around and slams
Link over the head with the chair* <br><br>NO! THIS CAN&#8217;T BE
HAPPENING! MARIO JUST KNOCKED OUT LINK WITH THE STEEL CHAIR! THE
CARNAGE! THE MAYHEM! JUST WHAT IS GOING ON HERE?! WHY WOULD MARIO TURN
HEEL AND JOIN BOWSER?! WHY MARIO WHY?! <br><br>*Mario grabs the microphone* <br><br>Mario:
I&#8217;ve-a been a-carrying Super Smash Brothers on my back for too long!
Mama mia! ENOUGH IS ENOUGH AND IT&#8217;S-A TIME FOR A CHANGE! Hit it! <br><br>*The word &#8220;Smash&#8221; is erased from the Jumbotron screen and is replaced with the word &#8220;Mario&#8221;* <br><br>Mario: <b>Super Mario Brothers with 74.26%</b> says I just whipped&#8230; <br><br>Yeah, you know the rest.<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Like
Zelda vs. Metroid, this is a same-company match with an obvious result;
the trick is trying to determine just how bad the beatdown will be.
When it comes to Nintendo's series, this contest has taught me one
central lesson: Super Smash Bros. is, unquestionably, the third
strongest, ranking ahead of Metroid, Mario Kart, Pokemon, Kirby, and
all the other runts. Now, we all know Zelda is stronger than Mario, and
I predicted about 80/20 for Zelda/Metroid, so I think this one will be
closer right off the bat. Also, unlike any game in the Metroid arsenal,
I think Super Smash Bros.' popularity and console carrying ability over
the past five years makes it very SFF-resistant. Will it still get
SFF'D by something as beastly as Super Mario Bros.? Sure. Will it be as
bad as Metroid? No way.<br><br>Super Mario Bros.<br>+ Several games from which to draw popularity<br>+ Most of those games are pretty damn strong in their own right<br>+ Most recognized series in gaming history<br>+ Broke Warcraft over its knee<br>- Nothing<br><br>Super Smash Bros.<br>+ A beast of a title in SSBM<br>+ SSB, while somewhat forgotten, also has a large fanbase and fantastic sales<br>+ Great performance against Sonic<br>- Only two games<br>- The Nintendo fanbase won't side with it here<br><br>My prediction: Super Mario Bros. def. Super Smash Bros. (75-25)</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">1</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=1">2</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=2">3</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=3">4</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=4">5</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=5">6</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=6">7</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=7">8</a></li>
<li>      9</li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=9">10</a></li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage9_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29209811&amp;page=8" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>
<script src="genmessage9_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>