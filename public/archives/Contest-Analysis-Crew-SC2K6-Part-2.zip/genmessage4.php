<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">

<title>GameFAQs: Message List</title><link rel="stylesheet" type="text/css" href="genmessage4_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage4_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage4_files/bc.css"></head><body linkifytime="421" linkified="9" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage4_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage4_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29209811%26page%3D3"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<a href="http://adlog.com.com/adlog/c/r=10153&amp;s=675961&amp;t=2006.07.30.22.05.52&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=00c17-gne-ad144C8F19B1597B32/http://www.gamespot.com/tournaments/bfme2aug06/index.php/" target="_blank"><img src="genmessage4_files/bfme2_tourney_leader.jpeg" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage4_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew - Part 2</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29209811&amp;page=3">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29209811" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">First
          Page</a> |
          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=2">Previous
          Page</a> |
          Page 4 of 10          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=4">Next
          Page</a>
          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=9">Last
          Page</a>
      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/17/2006 4:13:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320445594">message detail</a>
 | #151</td></tr>
<tr class="even">
<td>
The Elder Scrolls.........35.23% 38904<br>Street Fighter................64.77% 71526<br>TOTAL VOTES......................110430<br><br>65.96% of the brackets predicted this match correctly.<br><br>A
decent performance from both sides. TES is a brand new entry, and we
really didn't know how it would fare against a popular franchise like
Street Fighter. Needless to say, it didn't do too bad. Messed up alot
of brackets in the process too.<br> <br>Today, Residend Evil is blowing Shadow Hearts away. Shouldn't have expected anything more from Grade-A Fodder though.<br><br>Moltar - 3<br>Soul - 3<br>Ulti - 2<br>HaRRich - 2<br>HM - 2<br>Yoblazer - 1<br>Leon - 1<br>Mnm - 0<br>Lopen - 0<br><br>Yay, I get a point!<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Resident Evil vs. Shadow Hearts - Bracket: <b>RE</b> - Vote: <b>RE</b> (13/15)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/17/2006 4:19:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320447084">message detail</a>
 | #152</td></tr>
<tr class="even">
<td>
+9 Moltar<br>+8 Heroic Mario<br>+7 Soul<br>+6 Lopen<br>+5 mnm<br>+4 Leonhart<br>+3 Ulti<br>+2 HaRRicH<br>+1 yoblazer<br><br><b>The Rankings</b> (Through The Elder Scrolls/Street Fighter)<br>1. Master Moltar (74)<br>2. XxSoulxX (60)<br>3. UltimaterializerX (57)<br>4. Lopen (51)<br>5. yoblazer33 (48)<br>5. Heroic Mario (48)<br>7. Leonhart (45)<br>8. therealmnm (42)<br>9. HaRRicH (39)<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Resident Evil vs. Shadow Hearts - Bracket: <b>RE</b> - Vote: <b>RE</b> (13/15)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/17/2006 9:53:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320529208">message detail</a>
 | #153</td></tr>
<tr class="even">
<td>
<b>Hyrule Division:</b> <i>Round 2 - Match 17</i> &#8211; (1)Legend of Zelda vs. (5)Mega Man X <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Legend of Zelda</b><br>Round 1 &#8211; 89.97% vs. Civilization (10.03%)<br><br>Legend of Zelda easily makes it past Civilization. I mean&#8230;really easily.<br> <br><b>Mega Man X</b><br>Round 1 &#8211; 72.61% vs. Suikoden (27.39%)<br><br>In a seeding upset we all saw coming, MMX tops Suikoden<br><br>Round
2 is here, and what we start off with is a potential SFF-fest. How fun.
Only question here is how much SFF will suffer. We all saw what Link
did to Mega Man.<br><br>Anyway, let&#8217;s lengthen this a little. Last
round, Zelda did the impossible and garned 100,000 votes&#8230;for itself.
That&#8217;s incredible. MMX did decently against Suikoden, though we did
expect a little bit better. Many of us were interested in how MMX would
fare in a Contest setting, since it&#8217;s always Mega Man Classic getting
the attention. Well, this match probably won&#8217;t tell us much. Nintendo
sides with Mega Man, but Legend of Zelda is more important to Nintendo
fans than MMX, and thus we have SFF. <br><br>MMX may get some Sony/Capcom support, but that&#8217;s about it. <br><br><b>Moltar&#8217;s Bracket Says:</b> Legend of Zelda will win.<br><br><b>Moltar&#8217;s Prediction is:</b> LoZ: 77% - MMX: 23%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>This
match is going to be Link/Mega Man version 2.0, only likely worse. The
only "drama" we'll see in this match will be whether or not MMX breaks
30%. And yeah, I seriously think Zelda is strong enough to SFF the MMX
series that badly.<br><br>Prediction: Zelda with 72.13%<br> <br><br><br><b>Soul&#8217;s Analysis</b><br><br> <i>LoZ defeated Civilization with 89.97%<br>MMX defeated Suikoden with 72.61%</i><br><br>Round
2 begins with a favorite to win the contest, Zelda. Being that it is
one of the favorites, this match should be a very easy to predict
match, right? Right.<br><br>As strong as Mega Man is, it's still
considered Nintendo by GameFAQs. Want proof? Just look at Yoshi last
summer. Or look at Mega Man himself two years ago. Hell, you can even
look at Zero when he faced Mario last year. All those characters
underperformed greatly. This is because people think Mega Man is
Nintendo. Thus, Mega Man X will get his ass kicked, SFF style in this
match. Comprende?<br><br><b>My prediction: LoZ wins with 75.00% of the vote.</b><br> <br> <br> <br><b>HaRRich&#8217;s Analysis</b><br> <br>Legend of Zelda <b>VERSUS</b> Mega Man X<br>Predicted winner:  Legend of Zelda<br>Earlier this contest:<br>---LoZ - 89.97% against Civilization<br>---MMX - 72.61% against Suikoden<br>Top 100 List comparison:<br>---LoZ:OoT - #2, LoZ:LttP - #4, LoZ - #30, LoZ:WW - #45, LoZ:MM - #46<br>---MMX - N/A (had no games on the drop-down list)<br>Best Game Ever x-stat comparison:<br>---LoZ:OoT
- 46.18% (32-64 Division runner-up), LoZ:LttP - 41.61% (16 Division
runner-up), LoZ:WW - 37.29% (was behind Starcraft), LoZ - 34.49% (8
Divison runner-up)<br>---MMX - N/A (no rep)<br><br>Does anybody
remember Link/Mega Man? Expect a lot of the same, but worse; many
people consider Link and Mega Man to be the representation of their
entire series, and this match will feature only MMX instead of the
entire Mega Man series. LoZ already has the old-school vote on
lock-down thanks to LoZ:LttP (and the original LoZ, too, but that's
beside the point), which is where many of the MMX games reside. It's
been said that the MMX games on the Playstation aren't near as good or
as popular as the SNES ones, which would get trumped by LoZ:MM or
LoZ:WW (maybe even some of the Gameboy games)...oh, and LoZ:OoT too.
This match will make Suikoden look horrible, for sure.....<br><br>Legend of Zelda wins with 76.12%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/17/2006 9:54:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320529318">message detail</a>
 | #154</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>Ha, I <i>told</i> you that the Legend of
Zelda wouldn&#8217;t break 90% on Civilization, didn&#8217;t I? Man, I love being
right. Well, with that little bit of gloating out of the way, let&#8217;s
move on to analyzing the first match of the second round.<br><br>As you
would expect from finally seeing the entirety of the second strongest
series on this site put together as one entry, the Legend of Zelda put
on one of the most dominant performances we&#8217;ve ever seen. Even in the
very first match of the contest, we saw some record-breaking numbers.
It became the first entry ever to break 100,000 votes on its own (heh,
and we were doubting that we&#8217;d see any <i>match</i> break 100,000
before the Final Four), beating Cloud Strife&#8217;s old record by 6000
votes. The Legend of Zelda (the series) beat out the Legend of Zelda
(original NES game) for the largest margin of victory by about 800
votes, which is even more impressive when you consider that
Civilization managed more than twice as many votes as Adventure. It
placed at #7 for highest winning percentage, and it placed at #5 for
highest prediction percentage. Overall, this is the sort of thing you
would expect from a contender for the championship.<br><br>On the other
hand, Mega Man X disappointed by the expectations of some (though it
did just about as I predicted) against Suikoden by failing to triple
it. The match also drew 9000 fewer votes than the Legend of Zelda&#8217;s
match, and for some reason, 22.16% of the brackets actually thought
Suikoden could win this one, making it the biggest &#8220;bracket buster&#8221; of
the Hyrule Division. On the bright side, we finally got to see more
than X&#8217;s forehead in a match picture!<br><br>Of course, we didn&#8217;t even
have to see the first round matches to know that Zelda is going to win
this match, and easily at that. The only question is: By how much?
There is also the issue with whether or not Mega Man X will suffer any
noticeable amount of SFF in this match. While the majority of the
series has been on a Sony console, the first three games were released
on the Super Nintendo, thus putting in a measure of fanbase overlap. In
my opinion, when you throw an entire series into the mix&#8212;especially one
with several games&#8212;you drastically increase the probability of overlap
anyway. Sharing a console is just icing on the cake and likely makes
the SFF a little more severe.<br><br>I suppose one thing to take into
consideration when considering the percentage is the difference in
strength between Civilization and Suikoden. We already know that
Suikoden is a weak cult series (though I think the series is not a
bottom feeder like the characters, but it&#8217;s still very weak), but what
about Civilization? I mean, it&#8217;s a well-received PC series with good
sales, and PC games generally aren&#8217;t totally weak (even Half-Life did
well for itself). Yet, for some reason, I&#8217;d feel rather squeamish about
taking it to beat Suikoden at the moment (I suppose that&#8217;s because it
seems weird to pick anything that barely scored 10% to win ANY match).
Naturally, SFF will probably throw off any projections I could make,
and it seems nearly impossible to gauge it in this situation. <br><br><i>Leonhart&#8217;s Prediction</i>: <b>The Legend of Zelda with 80.77%</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/17/2006 9:55:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320529487">message detail</a>
 | #155</td></tr>
<tr class="even">
<td>
<b>HM&#8217;s Analysis</b><br> <br><b>The Legend of Zelda</b><br><i>Previous Matches:</i><br>The Legend of Zelda &#8211; 89.97% -- 100,163<br>Civilization &#8211; 10.03% -- 11,169<br><br><b>Mega Man X</b><br><i>Previous Matches:</i><br>Mega Man X &#8211; 72.61% -- 74,270<br>Suikoden &#8211; 27.39% -- 28,018<br><br>Unfortunately,
this is where Mega Man X&#8217;s run comes to an end. After a pretty solid
beat down of Suikoden (I think Suikoden didn&#8217;t do too bad, myself),
Mega Man X has to go up and face one of two beasts in this tournament &#8211;
Zelda. In the last round, LoZ went and set records by being the only
competitor to ever hit 100,000 votes on its own and shattering Cloud&#8217;s
record as the most votes by a single competitor &#8211; 96,000 votes. It is
pretty clear and present who is going to win this one, and without any
trouble at all. <br><br>Even with a blowout coming, Mega Man X
shouldn&#8217;t do too badly, all things considered. I suspect it&#8217;ll perform
a little worse than Mega Man performed on Link, which was met with some
pretty nasty SFF. Some of the crew thinks that LoZ is going to SFF MMX,
which never made a lick of sense to me. Merely because MMX started on a
Nintendo platform does not mean it is liable to get SFFed by Nintendo
series. It really doesn&#8217;t matter that much, though, because a blowout
is a blowout. <br><br>The Legend Zelda will continue the dominance of
its division until it meets Metal Gear and ultimately Final Fantasy in
the finals. Again, it&#8217;s quite a shame that MMX&#8217;s run had to come to
such an abrupt end when it could have gone places almost anywhere else
in the bracket. Hopefully there isn&#8217;t much SFF like people are calling
for so we don&#8217;t get odd extrapolated stats &#8230;<br><br><b>Aitch Emm&#8217;s Bracket :</b> The Legend of Zelda<br><b>Aitch Emm&#8217;s Prediction :</b> The Legend of Zelda &#8211; 72% ; Mega Man X &#8211; 28%<br><b>Aitch Emm&#8217;s Vote :</b> Mega Man X<br><br> <br><br><b>Yoblazer&#8217;s Analysis</b><br> <br>
Let's get Round 2 started! With half the contest left to go, everyone
knows there are only three more remotely debatable matches left.
Everyone also knows this is not one of them. Taking their first round
results into consideration, there is absolutely no question that The
Legend of Zelda goes into this match as the overwhelming favorite.
True, Final Fantasy had the opening round's most jaw-dropping
performance, but that doesn't suddenly erase Zelda's juggernaut status
on this site, and it will prove that for us today.<br><br>Mega Man X,
on the other hand, was not particularly impressive against Suikoden,
failing to earn the tripling on a very cultish RPG series. Perhaps it
is nowhere near as all-encompassing as its older brother. When people
see Mega Man, they might think not only about the NES games, but about
everything else - everything that makes Mega Man a legend and one of
the most established names in our industry (maybe I should have thought
of this before picking Mario Kart, LOL). When people see Mega Man X,
they see one series. It may carry some pop, but it's still only one
series. When you consider the FACT that A Link to the Past would garner
over 50% in a poll against every single MMX game, you begin to see how
bleak this really is. Now let's add Ocarina of Time, the original
Legend of Zelda (which, don't be fooled, is one of the more popular
games here), Majora's Mask, Wind Waker, and its host of other games,
and we'll get a nice bloodbath.<br><br>I undershot both Zelda and Final
Fantasy's percentages in the first round. After a nice wake-up call,
I'll be sure not to do that again.<br><br>The Legend of Zelda<br>+ Two of the four most popular games on the site<br>+ Many more popular games<br>+ The holy grail of Nintendo fans<br>+ SFF wrecking machine<br>+ Credibility up the wazoo<br>- None here<br><br>Mega Man X<br>+ Pretty popular in its own right<br>+ Good amount of games<br>- Not as legendary or broad as the original Mega Man<br>- This will be much more embarrassing than Link/Mega Man 2004<br><br>My prediction: The Legend of Zelda def. Mega Man X (80-20)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/17/2006 9:55:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320529698">message detail</a>
 | #156</td></tr>
<tr class="even">
<td>
<b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: X vs. Zero (MMX5) <br><br>Okay, I've been thoroughly owned this past round.  This is actually the <i>worst</i> I've done in any contest I've entered in the first round, by both actually matches correct <i>and</i>
predicting how strong I think each contestant will be. AM I LOSING MY
TOUCH?!?!?!!?! Anyways, this write-up will be rather short, as I have a
<i>ton</i> of things to do (find an apartment, find furniture, start my new job&#8230; you know, basic real world stuff&#8230;.).   <br><br>The
Legend of Zelda tore through Civilization with no problem whatsoever,
proving that it will most likely be a major force in this contest.
However, with Mega Man's performance against Mario Kart, maybe the Mega
Man games have more legs in this contest than I thought. Of course
seeing how Mega Man himself has both SFF'd and been SFF'd by Nintendo
characters; maybe Mega Man/Mario Kart was a result of SFF tiering. I'm
not quite ready to say that MMX will be able to stand up to LoZ even if
Mega Man easily dispatched Mario Kart. However, I still don't think it
will be a <i>total</i> flop. The popularity of Zero shows that the
Mega Man X fanbase is pretty solid. It should still get a fair amount
of support against LoZ. But it won't come close to making a match of
it, unfortunately. Too bad, as MMX is probably my second or third
favorite series in this contest. <br><br>Bracket: Legend of Zelda<br><br>Vote: MMX<br><br>Prediction: Legend of Zelda with 69.58%<br>  <br> <br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Another
speed bump on Zelda's path to the finals. I wish Mega Man X was
considered more than a speed bump here, but it isn't. Not to fault Mega
Man X, very few series would be considered anything more than a speed
bump.<br><br>The real questions here are: 1. How much is Zelda going to win by? 2. How much <i>should</i>
it win by to be perceived as a threat to FF's walk to the title? Both
tough questions to answer, at this point. All things aside, I think if
Zelda got even a tripling on Mega Man X it'd be looking really good
right here. I'm not sure where that puts MMX in the eventual stats or
anything&#8230; I'm just going offa what looks impressive for that match.<br><br>But,
we've all seen Mega Man's Nintendoesque attitude, we know he can do
weird stuff if paired up against the likes of Yoshi or Link. There's a
significant overlap there&#8230; and series have been giving out blowouts
like it's nobody's business. I think Mega Man X is a pretty popular
series, despite my prediction&#8230; but I don't think X-Stats are going to
be worth anything in this contest when all's said and done anyway.<br><br><b>Lopen's Prediction:</b> Legend of Zelda with 80.59%<br><br><br> <br>Comments: Yep, LoZ wins. Very easily too.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29209811" class="name">THEJackSparrow</a> |
Posted 7/17/2006 9:59:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320530523">message detail</a>
 | #157</td></tr>
<tr class="even">
<td>
Feel the pain of the BOX, Lopen!<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/17/2006 10:48:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320543041">message detail</a>
 | #158</td></tr>
<tr class="even">
<td>
Lopen's bracket says:  "Box will win".<br>Lopen's vote:  Box<br>Lopen's prediction:  Box with 70.12%.  <br><br>You shall never succeed!  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/17/2006 11:15:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320549500">message detail</a>
 | #159</td></tr>
<tr class="even">
<td>
Might be a tight fit in that box!<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/17/2006 11:17:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320549834">message detail</a>
 | #160</td></tr>
<tr class="even">
<td>
I'm just showing you how to get boxed in <i>properly</i>, kid.  I'm still very much in this match!  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/17/2006 11:18:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320550053">message detail</a>
 | #161</td></tr>
<tr class="even">
<td>
Zelda is just teasing you.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/18/2006 11:54:28 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320641730">message detail</a>
 | #162</td></tr>
<tr class="even">
<td>
Resident Evil...........87.76% 97696<br>Shadow Hearts......12.24% 13627<br>TOTAL VOTES...................111323<br><br>96.21% of the brackets predicted this match correctly.<br><br>Resident
Evil knocks Shadow Hearts all the way to the back of the fodder line
with the biggest non-Noble Nine blowout we've ever seen in these
Contests. RE almost also broke 100K votes, which would have been quite
the feat.<br><br>Today, LoZ continues its path of dominance by nearing 81% on MMX.<br><br>Soul - 4<br>Moltar - 3<br>Ulti - 2<br>HaRRich - 2<br>HM - 2<br>Yoblazer - 1<br>Leon - 1<br>Mnm - 0<br>Lopen - 0<br><br>Soul had the highest RE pick, so he gets the point.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Legend of Zelda vs. Mega Man X - Bracket: <b>LoZ</b> - Vote: <b>LoZ</b> (14/16)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/18/2006 11:58:38 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320642613">message detail</a>
 | #163</td></tr>
<tr class="even">
<td>
+9 Soul<br>+8 Leon<br>+7 HM<br>+6 Ulti<br>+5 Moltar<br>+4 HaRRich<br>+3 Mnm<br>+2 Yo<br>+1 Lopen<br><br><b>The Rankings</b> (Through The Resident Evil/Shadow Hearts)<br>1. Master Moltar (79)<br>2. XxSoulxX (69)<br>3. UltimaterializerX (63)<br>4. Leonhart (53)<br>5. Lopen (52)<br>5. Heroic Mario (52)<br>7. yoblazer33 (50)<br>8. therealmnm (45)<br>9. HaRRicH (43)<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Legend of Zelda vs. Mega Man X - Bracket: <b>LoZ</b> - Vote: <b>LoZ</b> (14/16)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/18/2006 1:42:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320665813">message detail</a>
 | #164</td></tr>
<tr class="even">
<td>
Ooh, looks like my pick is nearly spot on. Good thing I lowered it, too, or Lopen would have this one easily.<br><br>While I won't be catching up to 3rd place with this match, I'll be closing the gap, at least.<br><br>*makes note to shoot absurdedly high more often*<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/18/2006 4:52:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320713188">message detail</a>
 | #165</td></tr>
<tr class="even">
<td>
Looks like this point is going down to the wire.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/18/2006 6:37:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320738088">message detail</a>
 | #166</td></tr>
<tr class="even">
<td>
<b>Hyrule Division:</b> <i>Round 2 - Match 18</i> &#8211; (3)Pokemon vs. (2)Metroid <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Pokemon</b><br>Round 1 &#8211; 65.73% vs. Star Ocean (34.27%)<br><br>Pokemon shows us that&#8230;people just hate Pikachu, they don&#8217;t mind the games.<br> <br><b>Metroid</b><br>Round 1 &#8211; 70.57% vs. Kirby (29.43%)<br><br>Metroid destroys Kirby, but we all saw that coming.<br><br>Well, we go from one SFF-affair&#8230;to possibly another. Yay!<br><br>Last
round, Pokemon proved most of us wrong by easily beating Star Ocean.
Many people underestimated the series because of the hate and its match
with Xenogears. Of course, Star Ocean could just be that weak, but
whatever. Metroid, which faced a Nintendo series weaker than it, won
its first round match. Now it gets to face Pokemon, another series
primarily identified with Nintendo.<br><br>So that means we get to see
how SFF-resistant Pokemon is in this match. Now, Metroid is known for
not being too good SFF-wise, but it&#8217;s Pokemon, so it will probably win
on its strength alone.<br><br><b>Moltar&#8217;s Bracket Says:</b> Metroid will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Pokemon: 30% - Metroid: 70%<br> <br><br><br><b>Soul&#8217;s Analysis</b><br><br><i>Pokemon defeated Star Ocean with 65.74%<br>Metroid defeated Kirby with 70.57% </i><br><br>A Nintendo Vs. Nintendo match. Know what that means? Same Fanbase Factor. Ooooh. Aaaah.<br><br>Basically,
this comes down to which series you think the Nintendo fans will side
with. In this case, it's pretty simple. Pokemon is not as hated as
before, but it's still hated. Metroid should win this one as it's not
hated by the masses.<br><br>H-H-H-Here we go!<br>So they're finally here performing for you,<br>If you know the words you can join in too,<br>Put your hands togeather if you want to clap,<br>As we take you through this monkey rap, HUH!<br><br>DK. Donkey Kong!!<br><br>He's the leader of the bunch, you know him well,<br>He's finally back, to kick some tail,<br>His coconut gun can fire in spurts,<br>If he shoots ya, it's gunna hurt,<br>He's bigger, faster and stronger too,<br>He's the first member of the DK crew!<br><br>Huh!!<br>DK, Donkey Kong!!<br>DK, Donkey Kong is here!!<br><br>This Kong's got style, so listen up dudes,<br>Shecan shrink in size to suit her mood,<br>She's quick and nimble when she needs to be,<br>She can flout through the air and climb up trees,<br>If you choose her, you'll not choose wrong,<br>With a skip and a hop, she's one cool Kong!<br><br>Huh!!<br>DK, Donkey Kong!!<br><br>He has no style, he has no grace,<br>This Kong has a funny face,<br>He can handstand when he needs to,<br>And stretch his arms out just for you,<br>Inflate himself just like a baloon,<br>This crazy Kong just digs this tune!<br><br>Huh!!<br>DK, Donkey Kong!!<br>DK, Donkey Kong is here!!<br><br>He's back again and about time too,<br>And this time he's in the mood,<br>He can fly real high with his jetpack on,<br>With his pistols out he's one tough Kong,<br>He'll make you smile when he plays his tune,<br>But Kremlings beware 'cause he's after you!<br><br>Huh!!<br>DK, Donkey Kong!!<br>Huh!!<br><br>Finally he's here, he's here for you,<br>It's the last member of the DK crew,<br>This Kong's so strong, it isn't funny,<br>He'll make a Kremling cry out for mummy,<br>He can pick up a boulder with relative ease,<br>Makes crushing rocks seem such a breeze,<br>He may move slow, he can't jump high,<br>But this Kong is one heck of a guy!<br><br>Huh!!<br><br>C'mon Cranky take it to the fridge!<br><br>Walnuts, peanuts, pineapple smells,<br>Grapes, melons, oranges and coconut shells,<br>Walnuts, peanuts, pineapple smells,<br>Grapes, melons, oranges and coconut shells,<br><br>Oh yeah!!<br><br><b>My Prediction: Donkey Kong knocks out Samus and Metroid with barrels and oranges. And Metroid wins with 68.95% of the vote. </b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/18/2006 6:37:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320738224">message detail</a>
 | #167</td></tr>
<tr class="even">
<td>
<b>Hyrule Division:</b> <i>Round 2 - Match 18</i> &#8211; (3)Pokemon vs. (2)Metroid <br><br><b>Ulti&#8217;s Analysis</b><br> <br>*Pokemon kills Star Ocean early*<br><br>OMG METROID LOSEZ!<br><br>*Pokemon's percentage levels later*<br><br>OMG POKEMON WINS CLOSE!<br><br>*Metroid <i>kills</i> Kirby*<br><br>OMG METROID CAN ACTUALLY SFF THINGS IT WINZ!1<br><br>Typical Board 8, calling entire contests when meaningless matches have barely begun.<br><br>Anyway,
though Pokemon hate has all but died off, people are letting what
happened to Samus last summer cloud their brain. Remember
Xenogears/GSC? Xenogears would still whip the entire Pokemon series'
ass --- <i>any game in it.</i> Relax. Metroid is still beloved enough to win this, methinks.<br><br> Prediction: Metroid with 63.63%<br> <br> <br><br><b>Leon&#8217;s Analysis</b><br> <br>*Samus Aran checks her Series Contest to-do list*<br><br>1. SFF Kirby<br><br>&#8220;Check. Let&#8217;s see&#8230;Next on the list&#8230;&#8221;<br><br>2. SFF Pokemon<br><br>&#8220;That shouldn&#8217;t be a problem. After that&#8230;&#8221;<br><br>3. Get SFF&#8217;d by the Legend of Zelda<br><br>&#8220;Man, this list gets easier as I go!&#8221;<br><br>In
its first match, Metroid seemingly proved that it was actually capable
of dishing out SFF instead of always taking it by scoring a tad over
70% against Kirby. Then again, perhaps the pink puffball&#8217;s series
actually IS that weak, but we&#8217;ll probably never know. It doesn&#8217;t really
matter in the grand scheme of things though. Metroid would have won
with ease anyway. Honestly, you&#8217;ve got <i>at least</i> three Metroid games before you get to the most popular Kirby game, but I digress.<br><br>Pokemon
was supposed to be involved in one of the closer matches of the first
round, but it destroyed Star Ocean from the very beginning and ended up
with a near doubling, even with the big shot of Pikachu plastered on
its side of the match picture. Some people didn&#8217;t think the series had
that kind of blowout potential, but it certainly looks like the hate
has died down in the last couple of years. While it appears that Star
Ocean is fodder, having all of the Pokemon games together under one
label (particularly Red/Blue/Yellow, which I expected to be the most
popular set anyway) definitely helped to make this an even bigger
blowout. Even Xenogears couldn&#8217;t have kept this match close, I think. <br><br>As
for this match, Metroid&#8217;s odds of blowing this one are slim to none.
I&#8217;d take Kirby to beat Star Ocean head-to-head, and it outperformed
Pokemon against the stronger opponent, SFF notwithstanding. There&#8217;s no
idea of gauging how much was in that match, but I couldn&#8217;t have seen
Kirby breaking 40% on it one way or the other. And sure, while Metroid
is prone to getting SFF&#8217;d, Pokemon is even worse. Samus Aran and
Metroid have always been a solid third place on the Nintendo pecking
order on GameFAQs. If you think that Pokemon will ever be the one
dishing out SFF, you&#8217;re crazy. <br><br>Then you&#8217;re left with two
questions: 1) Is Pokemon stronger than Kirby? And 2) How ugly is the
SFF for this one? Before its match with Star Ocean, I would&#8217;ve answered
the first question in the negative. Now&#8230;I think it probably is. As for
the second question, I think it can avoid taking as bad of a beating as
Kirby did, but it probably still gets doubled. I&#8217;d love to see Pokemon
put up a fight and break 40% here though.<br><br><i>Leonhart&#8217;s Prediction:</i> <b>Metroid with 67.12%</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/18/2006 6:38:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320738408">message detail</a>
 | #168</td></tr>
<tr class="even">
<td>
<b>HM&#8217;s Analysis</b><br> <br><b>Metroid</b><br><i>Previous Matches:</i><br>Metroid &#8211; 70.57% -- 75,098<br>Kirby &#8211; 29.43% -- 31, 312<br><br><b>Pokemon</b><br><i>Previous Matches:</i><br>Pokemon &#8211; 65.74% -- 71,579<br>Star Ocean &#8211; 34.26% -- 37,037<br><br>Even though <i>Star Ocean</i> should be here right now, Pokemon <i>somehow</i>
managed to slip by (I claim cheating) and is up against a fellow
Nintendo franchise in Metroid. This one is probably going to be one of
the worst beatings of the second round due to the weakness of Pokemon
(No, folks, it beating Star Ocean does not give it any strength) and
the strength of Metroid. Add in any potential SFF and this one is gonna
be a nasty affair. <br><br>Pokemon did the unexpected last round and
gave a real beating to Star Ocean. Personally, I was shocked that
Pokemon was able to actually beat <i>something</i> with over 55% of
the vote. Still, even with a near doubling, Pokemon is not something to
be feared nor is it a series with any type of real strength. That
match, more than anything, proved that Star Ocean is absolutely not
cared for in the slightest on this site. I suppose the evidence was
there and I just missed it. At any rate, Pokemon is in for a beating
here.<br><br>Metroid demolished Kirby worse than most people expected,
which was good to see because it should speak pretty well of Metroid&#8217;s
strength in this contest. It has a pretty simple path of beating down
two Nintendo franchises and losing out to one &#8230; you know, I never
noticed before, but this division is filled to the brim with Nintendo
series. It&#8217;s a shame we couldn&#8217;t see Kirby and Metroid in different
parts of the bracket where there could be some real action going on.
Anyway, Metroid is undoubtedly one of GameFAQs&#8217; favorite series and
it&#8217;ll continue to show in this match. <br><br>So yeah, this&#8217;ll be
another boring match in the Hyrule Division. I expect Metroid to do
nearly a quadrupling here. It might seem a bit high, but it wouldn&#8217;t
surprise me at all if it went even higher. But, if Pokemon manages to
avoid a tripling, consider me a believer that Pokemon has some notable
strength. <br><br><b>Aitch Emm&#8217;s Bracket :</b> Metroid<br><b>Aitch Emm&#8217;s Prediction :</b> Metroid &#8211; 79% ; Pokemon &#8211; 21%<br><b>Aitch Emm&#8217;s Vote :</b> Metroid<br> <br><br><br><b>Yoblazer&#8217;s Analysis</b><br> <br>Is
this a boring division or what? While Pokemon was very impressive
against the pathetic Star Ocean, there's no need to second-guess this
match's result. After Mario Kart's disappointing performance, there's
no way I'd take it against Metroid, and I'm very, VERY weary of taking
Super Smash Bros. over Samus's series, either. What does that mean? It
means that Metroid obeys the traditional chain of command and likely <i>is</i>
the third strongest Nintendo series. It has old school credibility and
a very popular SNES game in Super Metroid. Unfortunately, it took the
N64 generation off, but it came back with a vengeance on the Gamecube
via the outstanding Prime titles, which have given Metroid a real shot
in the arm.<br><br>As a series, Pokemon's strength seems to have
increased dramatically. This is understandable when considering that,
for better or worse, it has been the biggest thing in our industry in
the past decade. It might not be very popular on GameFAQs, but it's
credible and influential enough to get the job done on something like
Star Ocean. Metroid, on the other hand, is simply out of its league.<br><br>Pokemon<br>+ Impressive first round match shows us this is the strongest Poke-entry to date<br>+ Tons of influence<br>+ Might hold up better than Kirby<br>- Pretty low on the Nintendo ladder<br>- Very little console love<br><br>Metroid<br>+ Quite possibly Nintendo's #3<br>+ Lots of credibility<br>+ Old school hit and the Primes to get it on the right track again<br>- You've got Link next, Ms. Aran<br><br>My prediction: Metroid def. Pokemon (69-31)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/18/2006 6:39:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320738501">message detail</a>
 | #169</td></tr>
<tr class="even">
<td>
<b>Mnm&#8217;s Analysis</b><br>  <br>Battle Music: Boss Battle 1 (Super Metroid Kraid Fight) <br><br>Super
busy now, so the next few write-ups will be pretty short. Pokemon
already has had its time to shine in this contest after beating Star
Ocean in a "debated" match. Unfortunately, Metroid is where its path
will end. Metroid has the unfortunate opportunity YET AGAIN to see its
demise at the hands of a SFF beating from the Legend of Zelda. Which is
too bad, since it could very well be one of the strongest entities
outside of the big three. Look for Metroid to take out its frustration
on Pokemon in this match. I call a tripling&#8230; <br><br>Bracket: Metroid<br><br>Vote: Metroid<br><br>Prediction: Metroid with 75%<br> <br><br><br><b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Metroid<br>Earlier this contest:<br>---Pokemon - 65.73% against Star Ocean<br>---Metroid - 70.57% against Kirby<br>Top 100 List comparison:<br>---Pokemon R/B/Y - #28, Pokemon G/S/C - #59<br>---Super
Metroid - #24, Metroid Prime - #29, Metroid - #65, MP2: Echoes - #74
(Metroid Fusion had the drop-down list and was still snubbed)<br>Best Game Ever x-stat comparison:<br>---Pokemon G/S/C - 16.79% (was behind FF7/Xenogears)<br>---Metroid
Prime - 33.4% (may have been SFF'd by LoZ:WW, was behind Starcraft),
Super Metroid - 21.63% (SFF'd by LoZ:LttP), Metroid - 17.53% (SFF'd by
SMB3)<br><br>So Pokemon impressed against Star Ocean, great -- it turns
out SO was fodder all along. Pokemon probably is stronger than we give
it credit for, but still...SO disappointed way too much to get any
respect from me in this. Meanwhile, Metroid beat Kirby's ass <i>worse</i>
than Pokemon beat SO. Yes, one could say SFF, but even then, to see
that Metroid actually does have the power to cast SFF instead of
receiving it is great news for it, especially considering that a
Samus/Kirby match would be much closer...besides, I figure SFF is
pretty small in that match (although existant). Considering many people
would take Kirby over Pokemon, the outcome seems obvious already in
Pokemon/Metroid...and that's because it is. However, I'm goin' to take
this further since I'm doubting Kirby &gt; Pokemon:<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=525" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=525">http://www.gamefaqs.com/poll/index.html?poll=525</a><br><br>In
a battle of being the favorite Nintendo series, Metroid gets about 5%
more than Pokemon to take third place (behind LoZ and Mario,
naturally). That poll was also held in May of 2001, which was before
the Gamecube was even released. That means there is no Metroid Prime
(Overall GotY, 2002), Metroid Prime 2: Echoes (3rd in Overall GotY,
2004), Metroid: Zero Mission (GBA GotY, 2004), Metroid Fusion (GBA
GotY, 2002), or Metroid Prime: Hunters (which had demos shipped with
the DS) at the time of that poll. Granted, Pokemon has had more
releases since then too, but NOTHING like the Metroid series has had
this generation. The handheld Metroid games can combat with most
Pokemon titles, I would figure, and at least two of the console Metroid
titles would beat any Pokemon title. To Pokemon's credit, it will outdo
Kirby's performance, but I would expect Star Ocean to look <b>horrible</b> after this match...and wait until LoZ/Metroid takes place.....<br><br>Metroid wins with 66.12%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/18/2006 6:39:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320738638">message detail</a>
 | #170</td></tr>
<tr class="even">
<td>
<b>Lopen&#8217;s Analysis</b><br> <br>Before the contest started, I'd have
said "Kirby's probably stronger than Pokemon". Oh, sure, I thought the
Pokemon hate had gone down, but I didn't think it was a serious player,
just enough to beat Star Ocean without sweating it. Still, what it did
last round was impressive. I don't think Star Ocean is <i>that</i>
much less popular than Suikoden. It might not be at all. And if you
think that, you've got Pokemon looking to be about as much a force as
Mega Man X.<br><br>Now, don't get me wrong, here, I don't think
Pokemon's a threat to win this match, but I think it'll surprise. In
fact, you might as well just take my Kirby/Metroid percentage here, and
take the whole damn analysis sans the smores references, too. Pokemon
won't just roll over. And Metroid's bad at SFF until further notice.
Pokemon's definitely got a fan base here. It may not have reared its
head for the other contests, but I do think Pokemon &gt;&gt; Pokemon
GSC and Pikachu. Last round just reassured me of that.<br><br><br>Pokemon could be considered a lot like a Kirby on SSJ3 oh my gawd powerup for seven episodes! (making fun of DBZ <i>is</i>
fun!) , when you think about it. Both are mainly from the Gameboy, with
mild support from SSBM and random N64/GC releases&#8230; but Pokemon's games
are that much more popular. The main edge that Kirby had was the
lovable character, and I just don't think people are letting that
influence voting very much. Pokemon should do much better. <br><br><b>Lopen's Prediction:</b> Metroid with 57.08%<br> <br> <br>Comments: Yeah, we all know Metroid is going to win...but by how much? We're ALL over the place for this match.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/18/2006 7:05:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320745010">message detail</a>
 | #171</td></tr>
<tr class="even">
<td>
Interesting that HaRRicH's and my predictions are exactly 1% apart.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/18/2006 7:17:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320747751">message detail</a>
 | #172</td></tr>
<tr class="even">
<td>
I always end mine as __.12%, so I'm totally blaming that on you.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3251974&amp;board=8&amp;topic=29209811" class="name">trannyscience</a> |
Posted 7/18/2006 7:18:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320747948">message detail</a>
 | #173</td></tr>
<tr class="even">
<td>
I always seem to end mine in .45 for some reason.<br>---<br>xyzzy</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/18/2006 7:19:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320748186">message detail</a>
 | #174</td></tr>
<tr class="even">
<td>
Always, you say?<br><br>*makes note to end predictions in .13% and hope to get the same first two numbers as HaRRicH*<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/18/2006 7:20:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320748329">message detail</a>
 | #175</td></tr>
<tr class="even">
<td>
Well, except for SMB/Madden.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2273363&amp;board=8&amp;topic=29209811" class="name">shadow8021</a> |
Posted 7/18/2006 9:33:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320780461">message detail</a>
 | #176</td></tr>
<tr class="even">
<td>
Wow, only 2 people picked Metroid to outdo iut's percentage on Kirby on Pokemon.<br>---<br>Series Contest Score: 14/16<br>Today's Pick: The Legend of Zelda</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29209811" class="name">DaruniaTheGoron</a> |
Posted 7/18/2006 11:25:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320809429">message detail</a>
 | #177</td></tr>
<tr class="even">
<td>
<i> From: shadow8021 </i><br><i>Wow, only 2 people picked Metroid to outdo iut's percentage on Kirby on Pokemon.</i><br><br>Because Pokemon has seena  resurgance on this site.<br><br>Anyway, good job Lopen, you already have this one in the bag.<br>---<br>...little Weezing it's gonna stand up against my ****in' Charizard? Just get back on your bike <br>and keep pretending to be cool with your lame ass mohawk ****er. - phoenix1487 <b><i>Sp2k6: 14/16</i></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29209811" class="name">Lugia2</a> |
Posted 7/19/2006 7:49:35 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320864621">message detail</a>
 | #178</td></tr>
<tr class="even">
<td>
Can't do any predictions now, but it looks like Pokemon is a LOT stronger than we give it credit for.<br><br>I mean- 47%!?!?!  More than 40!?!?!?<br><br>Oh well.  Looks like HM got screwed over.  Again.<br><br>At least you still got the bracket point! ;)<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/19/2006 12:12:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320903874">message detail</a>
 | #179</td></tr>
<tr class="even">
<td>
The Legend of Zelda....80.32% 104400<br>Mega Man X....................19.68% 25577<br>TOTAL VOTES..........................129977<br><br>95.59% of the brackets predicted this match correctly.<br><br>Holy
3rd most popular match of all time, Batman! LoZ continues on its path
of dominace by beating MMX wih over 80% of the vote AND cracking 100K
votes for the second time thus far.<br><br>Today, Pokemon continues to prove to us that we did underestimate it, as its going toe-to-toe with Metroid.<br><br>Soul - 4<br>Moltar - 3<br>Ulti - 2<br>HaRRich - 2<br>HM - 2<br>Lopen - 1<br>Yoblazer - 1<br>Leon - 1<br>Mnm - 0<br><br>Lopen gets his first point, even though his percentae was boxed in. Very nice.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Pokemon vs. Metroid - Bracket: <b>Metroid</b> - Vote: <b>Metroid</b> (16/18)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/19/2006 12:18:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320905108">message detail</a>
 | #180</td></tr>
<tr class="even">
<td>
+9 Lopen<br>+8 Yo<br>+7 Leon<br>+6 Moltar<br>+5 HaRRich<br>+4 Soul<br>+3 Ulti<br>+2 HM<br>+1 Mnm<br><br><b>The Rankings</b> (Through Legend of Zelda/Mega Man X)<br>1. Master Moltar (85)<br>2. XxSoulxX (73)<br>3. UltimaterializerX (66)<br>4. Lopen (61)<br>5. Leonhart (60)<br>6. yoblazer33 (58)<br>7. Heroic Mario (54)<br>8. HaRRicH (48)<br>9. therealmnm (46)<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Pokemon vs. Metroid - Bracket: <b>Metroid</b> - Vote: <b>Metroid</b> (16/18)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/19/2006 7:55:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321017356">message detail</a>
 | #181</td></tr>
<tr class="even">
<td>
<b>Snake Division:</b> <i>Round 2 - Match 19</i> &#8211; (1)Metal Gear vs. (4)Fire Emblem <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Metal Gear</b><br>Round 1 &#8211; 69.9% vs. Soul Calibur (30.1%)<br> <br>Soul Calibur isn&#8217;t an easy opponent, as it showed MG last round.<br><br><b>Fire Emblem</b><br>Round 1 &#8211; 57.05% vs. Silent Hill (42.95%)<br><br>In the Battle of the Fodder, FE gets the victory over Silent Hill.<br><br>Aren&#8217;t
the opponents supposed to get tougher as the tourney progresses? That&#8217;s
definitely not the case here. Neither FE or SH should have made it to
Round 2 because of how weak they are, but I guess it doesn&#8217;t hurt to
make Metal Gear look good. Facing the strongest 8 seed in Round 1 and
failing to break 70% isn&#8217;t the best start.<br><br>Still, it&#8217;s not like
Metal Gear is in any threat to lose its divison. Fire Emblem is
undoubtedly weaker than Soul Calibur. The only two things it has going
for it are that it&#8217;s a Nintendo RPG, and Marth and Roy are in SSB:M,
which was enough to get it over Silent Hill. Metal Gear is no Silent
Hill though, and it has just about everything else going for it. Expect
a thrashing, folks.<br><br><b>Moltar&#8217;s Bracket Says:</b> Metal Gear will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Metal Gear: 77% - Fire Emblem: 23%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>Fiore
Emblem had its little run of glory, but a 55-45 win over something as
****ing cult as Silent Hill spells really bad news against something as
established as MGS. NintendoFAQs isn't going to stop FE from getting
killed here.<br><br> Prediction: MGS with 71.23%<br> <br><br><br><b>Soul&#8217;s Analysis</b><br><br> <i>Metal Gear defeated Soul Calibur with 69.89%<br>Fire Emblem defeated Silent Hill with 57.05%</i><br><br>Another
match, another easy win for Snake and co. Fire Emblem may have Nintendo
backing, but Snake is noble nine for a reason. Yes, characters =/=
series, but come on now. Fire Emblem had a hard time defeating Silent
Hill. Metal Gear got just a little under 70% against a much tougher
opponent in Soul Calibur.<br><br>You know, it's been a while since I
actually wrote up a decent analysis. If you're looking for one here,
keep on going. I'm sure HM will have more then enough written for the
entire crew.<br><br><b>My prediction: Metal Gear wins with 77.77% of the vote.</b><br> <br> <br><br><b>Yoblazer&#8217;s Analysis</b><br> <br>Everyone
ready for my first and only one paragraph analysis? Awesome, because
writing an intricate masterpiece for this match would accomplish
nothing more than wasting my time. While Fire Emblem may be Nintendo,
it is (by far) the newest and weakest of all Nintendo series. It got
here not by virtue its own strength, but by being lucky enough to draw
a first round opponent that has an extremely small fanbase on GameFAQs.
I feel that its future in the US is a bright one, as it's the only true
non-spinoff RPG series that Nintendo has to offer. Even still, it's
only a baby right now, and after Metal Gear's 70/30 beatdown of Soul
Calibur, we should all be expecting something ugly.<br><br>Metal Gear<br>+ Three very popular games in the last eight years<br>+ Tons of credibility and some old school influence<br>+ Spans a surprising amount of consoles and eras<br>- Nothing for the rest of the division, really<br><br>Fire Emblem<br>+ Made it this far<br>+ Has a bright future<br>+ Nintendo<br>- It's going to get killed<br><br>My prediction: Metal Gear def. Fire Emblem (76-24)<br> <br><br><br><b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: Duel (MGS) <br><br>This
is probably the most boring match of the second round. I don't mind at
all that I won't be around for most of the match. I don't even care to <i>see</i> how strong Fire Emblem is.  Bottom line is that it's going to get crushed in this matchup.   <br><br>Bracket: Metal Gear<br><br>Vote: Metal Gear<br><br>Prediction: Metal Gear with 77.74%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/19/2006 7:55:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321017524">message detail</a>
 | #182</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>It&#8217;s hard to believe that this division
has essentially been decided after one round when it was considered to
be debatable before the contest began. Metal Gear exceeded nearly
everyone&#8217;s expectations by getting nearly 70% on Soul Calibur (it&#8217;s a
shame I had to miss that one because I would&#8217;ve gone crazy with glee,
being the Metal Gear mark that I am). Then Castlevania went 55/45 on
Halo (and a past Favorite Konami Series poll shows that Metal Gear is
the company&#8217;s favorite son by a good margin), and Kingdom Hearts failed
to exceed Metal Gear&#8217;s performance by 5% on Harvest Moon. Basically,
the division was handed to it on a silver platter and it didn&#8217;t even
have to do very much to get it. We knew that Metal Gear had lucked out
in its divisional draw by not getting some of the strongest competitors
out there, but it turns out to be an even better draw for it than we
thought as we&#8217;ve seen newer, less established series struggle so far.<br><br>And
Metal Gear will actually have less competition from its second round
opponent than it did against Soul Calibur. While Fire Emblem won its
first match with little trouble, keep in mind that it was against
Silent Hill. Harkening back to the Favorite Konami Series poll I
mentioned earlier, Silent Hill got less than 7% in it, and it was
beaten out by <i>Yu-Gi-Oh</i>. In other words, you&#8217;re looking at a
really weak franchise, and Fire Emblem wasn&#8217;t exactly dominant there
(by non-Ulti standards, at any rate). However, it saddens me to see
that there are actually people around the board who believe it has a
chance to beat Metal Gear because &#8220;It&#8217;s Nintendo.&#8221; That mentality
instantly makes any debate frustrating because it doesn&#8217;t matter how
logical your argument is. It&#8217;s automatically debunked by such a
BRILLIANT response. Anyway, that&#8217;s a rant for another time.<br><br>Despite
Fire Emblem being Nintendo, it&#8217;s far from a powerhouse. Even though
it&#8217;s actually a long-running series, it&#8217;s still new to the American
shores. As we&#8217;ve seen in this contest so far, that&#8217;s not a comforting
sign. Also keep in mind that this site isn&#8217;t a big fan of RPGs that
don&#8217;t start with &#8220;Final&#8221; and end with &#8220;Fantasy&#8221; (or &#8220;Tactics,&#8221; but you
get the idea). Throw it up against one of the strongest non-Nintendo,
non-Square franchises, and you have all the signs of a massacre. But
just how bad could this one be&#8230;? Let&#8217;s look into that, shall we?<br><br>In
the Games Contest, Metal Gear Solid broke 70% on the original Resident
Evil. Obviously, it didn&#8217;t beat the most popular entry of the series,
but when you consider the fact that Resident Evil has slaughtered
Silent Hill in a couple of &#8220;Favorite Survivor-Horror Game&#8221; polls (where
&#8220;I don&#8217;t play those kind of games&#8221; came in second, by the way), this
points to a big blowout. Also, Resident Evil and Fire Emblem were
nearly equal in the stats (with a small edge to RE), but when you
realize that the former is almost certainly underrated (though I admit
that it&#8217;s possible that FE is as well, but I don&#8217;t think it&#8217;ll be to
the same extent since I believe there&#8217;s a possibility that MGS
overperformed on RE a bit, too), that widens the gap a bit.<br><br>And
while Soul Calibur certainly bombed in the first round against Metal
Gear, I&#8217;d still feel comfortable taking it to beat Fire Emblem. I don&#8217;t
think it&#8217;d be THAT close either. I&#8217;m going to be waiting to see how
high Metal Gear can go, and I&#8217;ll love every minute of it.<br><br><i>Leonhart&#8217;s Prediction</i>: <b>Metal Gear with 75.44%</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/19/2006 7:56:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321017589">message detail</a>
 | #183</td></tr>
<tr class="even">
<td>
<b>HM&#8217;s Analysis</b><br> <br><b>Metal Gear</b><br><i>Previous Matches :</i><br>Metal Gear &#8211; 69.89% -- 77,349<br>Soul Calibur &#8211; 30.11% -- 33,321<br><br><b>Fire Emblem</b><br><i>Previous Matches:</i><br>Fire Emblem &#8211; 57.05% -- 57,798<br>Silent Hill &#8211; 42.95% -- 43,512<br><br>This
will be one of the more enjoyable matches for me simply due to Metal
Gear getting another shot at blowing out an opponent &#8211; something we do
not get to see <i>that</i> often! I think this has potential to get
that awesome title of &#8220;Blowout of the Round&#8221; because of both Fire
Emblem&#8217;s weakness and Metal Gear&#8217;s strength &#8211; it&#8217;ll be the fourth
strongest series in the extrapolated stats, as I called for back during
the beginning of this contest<i>!!</i><br><br>Last round, we saw Metal
Gear exceed expectations by thrashing Soul Calibur with an impressive
70%. Some might say that it was due to Soul Calibur being overrated in
the stats by StarCraft, but this contest <i>does</i> take into
consideration all three games in the series. Of course, Metal Gear is
just far too strong for any of that to matter, as evident by the
blowout. I think that match dealt more with Metal Gear&#8217;s strength over
Soul Calibur&#8217;s weakness. <br><br>Fire Emblem managed to pull a nice
57% against a somewhat debated match against Silent Hill. Its
performance was nothing particularly impressive nor did it really
exceed expectations by very much. When it comes down to two series that
GameFAQs really does not care much for, the Nintendo series is likely
to be the one to come out on top. However, even with Fire Emblem&#8217;s win
over Silent Hill, there is no chance of it doing anything noteworthy
against Metal Gear. <br><br>This match seems to be getting some
unnecessary attention from random people on Board 8. It seems like
every day there is another topic asking about the winner of Metal Gear
and Fire Emblem, despite its rather ordinary performance against Silent
Hill. The best thing I can possibly come up with as to why this is even
remotely the case is because Fire Emblem is associated with Nintendo
and clearly it means it stands a chance &#8211; I laugh. <br><br>Metal Gear
is undoubtedly going to be one of the strongest series in this contest
&#8211; I think it&#8217;ll even put a good showing against Zelda. Even though it <i>is</i>
against Fire Emblem, I think this match will help to show what kind of
strength Metal Gear actually has backing it. Some may look at Soul
Calibur&#8217;s blowout as it being overrated and this match as Fire Emblem
being weak, but I think both are showing more for Metal Gear than
anything else. I have faith this&#8217;ll definitely be a few percentage
points above a tripling.<br><br>Ultimately, Fire Emblem is just another
stepping stone to a division victory for Metal Gear. This one is going
to be a blowout, folks, so be expecting some <i>huge</i> numbers to be
displayed by Solid Snake&#8217;s franchise. I&#8217;ll go ahead and make a bold
prediction in this very analysis that says Metal Gear not only wins
this division but also never falls below 58% in the final percentage<i>!!</i><br><br><b>Aitch Emm&#8217;s Bracket :</b> Metal Gear<br><b>Aitch Emm&#8217;s Prediction :</b> Metal Gear &#8211; 78% ; Fire Emblem &#8211; 22%<br><b>Aitch Emm&#8217;s Vote :</b> Metal Gear</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/19/2006 7:57:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321017873">message detail</a>
 | #184</td></tr>
<tr class="even">
<td>
<b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Metal Gear<br>Earlier this contest:<br>---MG - 69.89% against Soul Calibur<br>---FE - 57.05% against Silent Hill<br>Top 100 List comparison:<br>---MGS - #8, MGS3 - #21, MGS2 - #41<br>---FE (GBA) - #54<br>Best Game Ever x-stat comparison:<br>---MGS2 - 32.52%, MGS - 28.7% (may have been SFF'd by FF7), MG - 14.13%<br>---FE - 16.59% (was behind FFTA/FFX)<br><br>Metal Gear wins due to this...<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2430" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2430">http://www.gamefaqs.com/poll/index.html?poll=2430</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1453" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1453">http://www.gamefaqs.com/poll/index.html?poll=1453</a><br>#8 + #21 + #41 &gt; #54<br><br>...but
I'm going to pretty much repost (then edit) something I said during
FE/SH to explain why I think MG will "only" win by so much. Ahem:<br><br>"Fire
Emblem might actually be able to match Soul Calibur's performance
and/or compete with SC. I've heard a fair share of talk that it did as
well as it did against Kingdom Hearts because of SC2, and I think it
goes without saying that SC and SC2 are the two biggest parts of the SC
series -- SC3 is practically forgotten in terms of popularity with
them. So, if that's the case, that would almost be like the SC series
losing to KH...and KH was behind Starcraft, so -- now that we've seen
SC be beaten down by MG, Castlevania skeet-skeet on Halo, and KH
failing to triple Harvest Moon -- we now have more reason to believe
some of the games behind Starcraft became over-rated. How over-rated,
that's your call, but the unadjusted stats have it at 34.28%, and
that's not even first taking away the 600 cheat-votes CJayC confirmed
in Starcraft/SSBM...<br><br>...now, from there, let's talk about FE. As
we've all mentioned before, FE had been out a grand total of four
months when its match against FFTA started, which isn't the best chance
in the world for a game to get. Furthermore, FFTA then faced FFX in the
next round, so there was likely SFF in that match. So, you look at the
stats...and FE has 16.59%, so it has to go up some -- again, your call
on how much. There's been at least one more American release of FE
since then on the handhelds, and I know FE:PoR got (a distant)
runner-up in the Gamecube GotY this past year (behind RE4, obviously)...<br><br>...from
there, you may throw in the Nintendo boost, that it'd be an (S)RPG
against a fighter and that it'd be Nintendo VS Namco (which has done
work before for Nintendo, if you're aching to push for SFF in some
fashion) if we're talking about FE/SC, there being two more diverse
fanbases in MG/FE than MG/SC if we're talking MG/FE...whatever. FE/SH
still managed to break 100,000 votes though, so perhaps neither series
are <i>as</i> obscure as we once thought, and it may also be worth mentioning that SC got #51 while FE got #54 on the Top 100 List....."<br><br>I'm
not taking that risk of FE matching SC, but using that logic --
assuming there are no faults in it (there very well could be though) --
it would make it look like FE can avoid the tripling and maybe come
close to SC's performance. I'll pick with that risk in mind.<br><br>Metal Gear wins with 71.12%<br> <br><br><br><b>Lopen&#8217;s Analysis</b><br> <br>Okay,
I had Metal Gear vs. Silent Hill here. But, make no mistake about it,
the reason I thought Silent Hill would win is because they were both so
weak that raw exposure advantage would win SH the match. Well you know
what? I still think that. Not <i>all</i> of that, but the gist of it&#8230; that neither one could draw 60% on hunk of stale bread&#8230; <i>trilogy</i>. (It's a series, after all!)<br><br>The only thing that has me doubting Metal Gear's blowout potential here is the <i>loyalty</i>
of the Fire Emblem fans. I've seen their rabidness on Board 8. But I'm
not sure if that's generally the case. At best for Fire Emblem, we've
got a really weak version of Halo&#8230; that is a series that can resist
blowouts just because its fans will vote it over almost <i>anything</i>.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/19/2006 7:57:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321017912">message detail</a>
 | #185</td></tr>
<tr class="even">
<td>
But&#8230; but&#8230; I've seen the same rabidness on B8 for things like Shadow Hearts and Suikoden. Nevermind, I'll go with my gut, here.<br><br><b>Lopen's Prediction:</b> Metal Gear with 87.58%<br><br> <br> <br>Comments: Metal Gear wins! We're all also saying FE is going to get it worse than Soul Calibur did.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3658858&amp;board=8&amp;topic=29209811" class="name">SuperiorSnake</a> |
Posted 7/19/2006 8:46:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321029628">message detail</a>
 | #186</td></tr>
<tr class="even">
<td>
... What the hell, <i>Lopen</i>. You best not get the point, that's all I have to say. <i>I</i> was supposed to be the highest one! <br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/19/2006 8:48:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321029945">message detail</a>
 | #187</td></tr>
<tr class="even">
<td>
I thought it was a typo at first, to be honest.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Pokemon vs. Metroid - Bracket: <b>Metroid</b> - Vote: <b>Metroid</b> (16/18)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/19/2006 8:56:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321031903">message detail</a>
 | #188</td></tr>
<tr class="even">
<td>
Haha! Soul AND mnm got boxed in! I've actually got a little breathing room this time.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/19/2006 9:04:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321033908">message detail</a>
 | #189</td></tr>
<tr class="even">
<td>
Oh damn, that sucks. <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/19/2006 10:26:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321054666">message detail</a>
 | #190</td></tr>
<tr class="even">
<td>
Wow.  I thought I may have aimed a <i>little</i> high, but jeez.  So much faith in Fire Emblem.  This is freakin <i>Metal Gear</i>,
people! All Metal Gear has to do is break 82 and some odd % to get me
the point. Easy win! My round 2 shut out shall continue! <br>---<br>Raiden is still [<i>!!</i>] nominations short! <i>Have you been... to the well of knowledge!?</i><br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29209811" class="name">Tatsumaki Senpuu</a> |
Posted 7/19/2006 10:26:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321054737">message detail</a>
 | #191</td></tr>
<tr class="even">
<td>
I sent in the rest of my round 2 analysis save for SF/RE. Tell me if you don't get it.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29209811" class="name">Tatsumaki Senpuu</a> |
Posted 7/19/2006 10:27:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321055095">message detail</a>
 | #192</td></tr>
<tr class="even">
<td>
<i>Wow. I thought I may have aimed a little high, but jeez. So much
faith in Fire Emblem. This is freakin Metal Gear, people! All Metal
Gear has to do is break 82 and some odd % to get me the point. Easy
win! My round 2 shut out shall continue!</i><br><br>I would love to see
Metal Gear get as high as possible -- even breaking 90%! But, you know,
you're not getting the point. I'm getting my <i>second</i> Metal Gear point, yo.<br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29209811" class="name">SquallidSnake</a> |
Posted 7/20/2006 12:31:03 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321083747">message detail</a>
 | #193</td></tr>
<tr class="even">
<td>
Looks like HaRRicH's point to lose now.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/20/2006 12:34:41 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321084439">message detail</a>
 | #194</td></tr>
<tr class="even">
<td>
I blame this entirely on Solid's sprite, by the way.  A Raiden sprite would've <i>easily</i> made up the 20%.  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2562507&amp;board=8&amp;topic=29209811" class="name">H__RR____H</a> |
Posted 7/20/2006 1:22:03 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321092124">message detail</a>
 | #195</td></tr>
<tr class="even">
<td>
Here's to hoping I get to keep this point -- lord knows I need it.<br>---<br><i>Damn, most of my dates involve mocking and/or beating up people like you and your bride-to-be, so I really have no advice</i> --Horatio</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/20/2006 1:07:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321173029">message detail</a>
 | #196</td></tr>
<tr class="even">
<td>
Pokemon....47.44% 59428<br>Metroid........52.56% 65831<br>TOTAL VOTES.......125259<br><br>57.29% of the brackets predicted this match correctly.<br><br>Wow,
we sure did underestimate Pokemon. When people said they took it over
Metroid, many thought they had no chance of being right. Well, Pokemon
nearly had the upset. In the second closest match of the Contest (ha),
Metroid beats Pokemon.<br><br>Today, either Fire Emblem is doing really good, or Metal gear very bad.<br><br>Soul - 4<br>Moltar - 3<br>Lopen - 2<br>Ulti - 2<br>HaRRich - 2<br>HM - 2<br>Yoblazer - 1<br>Leon - 1<br>Mnm - 0<br><br>2 points in a row for Lopen, nice job.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Metal Gear vs. Fire Emblem - Bracket: <b>MG</b> - Vote: <b>MG</b> (18/20)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/20/2006 1:14:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321174673">message detail</a>
 | #197</td></tr>
<tr class="even">
<td>
+9 Lopen<br>+8 Ulti<br>+7 HaRRich<br>+6 Leon<br>+5 Soul<br>+4 Yo<br>+3 Moltar<br>+2 Mnm<br>+1 HM<br><br><b>The Rankings</b> (Through Metroid/Pokemon)<br>1. Master Moltar (88)<br>2. XxSoulxX (78)<br>3. UltimaterializerX (74)<br>4. Lopen (70)<br>5. Leonhart (66)<br>6. yoblazer33 (62)<br>7. Heroic Mario (55)<br>7. HaRRicH (55)<br>9. therealmnm (48)<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Metal Gear vs. Fire Emblem - Bracket: <b>MG</b> - Vote: <b>MG</b> (18/20)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1313568&amp;board=8&amp;topic=29209811" class="name">Jmast7</a> |
Posted 7/20/2006 1:46:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321181973">message detail</a>
 | #198</td></tr>
<tr class="even">
<td>
<i>Today, either Fire Emblem is doing really good, or Metal gear very bad.</i><br><br>So... which is it? &lt;_&lt; <br><br>Or it is a combination of both?<br>---<br>"I have never cared for the Yankees, and for a very good reason: The Yankees are evil." <br>&#8211; Dave Barry</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/20/2006 2:33:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321193506">message detail</a>
 | #199</td></tr>
<tr class="even">
<td>
Both, probably.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29209811" class="name">SquallidSnake</a> |
Posted 7/20/2006 3:09:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321202572">message detail</a>
 | #200</td></tr>
<tr class="even">
<td>
I think we just underestimated Fire Emblem, though Silent Hill is getting very close to being equal with Soul Calibur.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">1</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=1">2</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=2">3</a></li>
<li>      4</li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=4">5</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=5">6</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=6">7</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=7">8</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=8">9</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=9">10</a></li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage4_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29209811&amp;page=3" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage4_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>