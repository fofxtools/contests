<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">

<title>GameFAQs: Message List</title><link rel="stylesheet" type="text/css" href="genmessage3_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage3_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage3_files/bc.css"></head><body linkifytime="291" linkified="12" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage3_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage3_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29209811%26page%3D2"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<a href="http://adlog.com.com/adlog/c/r=10153&amp;s=675961&amp;t=2006.07.30.22.05.37&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=00c17-gne-ad644C8F1C21569834/http://www.gamespot.com/tournaments/bfme2aug06/index.php/" target="_blank"><img src="genmessage3_files/bfme2_tourney_leader.jpeg" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage3_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew - Part 2</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29209811&amp;page=2">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29209811" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">First
          Page</a> |
          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=1">Previous
          Page</a> |
          Page 3 of 10          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=3">Next
          Page</a>
          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=9">Last
          Page</a>
      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=546065&amp;board=8&amp;topic=29209811" class="name">badazzbuddy117</a> |
Posted 7/15/2006 2:11:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319951755">message detail</a>
 | #101</td></tr>
<tr class="even">
<td>
hmm percent going down...maybe ulti might get this one<br>---<br>All hail the "Go Halo" monks! RE 4 rules<br>Name: Poo MK friend code:352255-222249</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/15/2006 3:18:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319964988">message detail</a>
 | #102</td></tr>
<tr class="even">
<td>
Alright, Mega Man.  58.22%.  FIGHT!  You can do it!  <br><br>Man, it sucks, I'd have aced this prediction if I hadn't upped it by 2%.  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/15/2006 3:54:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319972408">message detail</a>
 | #103</td></tr>
<tr class="even">
<td>
...Too bad that I won't be in fifth place for long.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/15/2006 4:01:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319973807">message detail</a>
 | #104</td></tr>
<tr class="even">
<td>
Also, it looks like Lopen is his own worst enemy! <br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/15/2006 4:04:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319974573">message detail</a>
 | #105</td></tr>
<tr class="even">
<td>
MEGA MAN IS MERELY MAKING IT INTERESTING!<br><br>DO NOT DOUBT THE BOMBER'S %AGE DRAWING SKILL!  THE DAY VOTE IS OVER!<br><br>(watches post get marked for all caps posting)<br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/15/2006 6:51:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320009533">message detail</a>
 | #106</td></tr>
<tr class="even">
<td>
<b>Ultima Division:</b> <i>Round 1 - Match 15</i> &#8211; (3)Elder Scrolls vs. (6)Street Fighter <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Elder Scrolls</b><br>Yeah,
Elder Scrolls! You know, the series with Morrowind and recently
released Oblivion on the Xbox 360? Yeah, they&#8217;re in the Elder Scrolls
series.<br> <br><b>Street Fighter</b><br>Street Fighter is one of, if
not, the most popular fighting franchises there are. Most everyone has
played a Street Fighter game. Even the current generation can play it
with all the Collections coming out.<br><br>WTF at the backwards
seeding in this match. Street Fighter is pretty popular, yet it only
received a 6 seed, while many didn&#8217;t even know Oblivion and Morrowind
came from the Elder Scrolls series and it got a 3 seed. Interesting&#8230;<br><br>Billy the Casual Bracketmaker: Oh wowie gee, does this mean Elder Scrolls will win since it&#8217;s the higher seed?<br><br>No,
Billy. We can&#8217;t look at it like that. Elder Scrolls might be seeded
higher, but Street Fighter is the more popular series. Also, look at
this. Many people are banking on the Street Fighter name to carry it in
this match. As for Elder Scrolls, it is possible that the only reason
it&#8217;s seeded so highly is because of the new game, Oblivion, on the Xbox.<br><br>Billy: So&#8230;what are you saying?<br><br>I&#8217;m
saying, Billy, that the casual voter might not recognize the Elder
Scrolls name. And if they do, they&#8217;ll most likely be voting for it
because of Oblivion, or possibly Morrowind. The Street Fighter series,
on the other hand, is a series pretty much everyone recognizes, and I
think that will be a big factor in this match.<br><br>Billy: Does that mean you have Street Fighter winning, Moltar?<br><br>Yes, yes it does.<br><br>Billy: And now I know!<br><br>And knowing is half the battle!<br><br><b>Moltar&#8217;s Bracket Says:</b> Street Fighter will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Elder Scrolls: 34% - Street Fighter: 66%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>These seeds aren't reversed because...?<br><br>Anyway,
this match would be in question if it were "Oblivion v Street Fighter
2". But I'm willing to bet that most Oblivion players don't even know
"The Elder Scrolls" is attached to Oblivion's name. Sorry I can't write
more than "SF2 causes SF to win", but I've never played a game in the
TES series :(<br><br>Prediction: Sf with 59.24%<br> <br><br><br><b>Soul&#8217;s Analysis</b><br> <br>WTF SF2 LOST?!?!?!? (Let's see how many people put this in)<br><br>Anyways, this will be another seeding upset. Poor 3 seeds... can never seem to catch a break in these contests.<br><br>Yes,
Street Fighter will win this. Reason? Elder Scrolls is a PC game not
from Blizzard. Simple right? Street Fighter is definitely not the
strongest series in this division, but it should be able to defeat
Oblivion rather easily.<br><br><b>My prediction: Street Fighter wins with 61.15% of the vote.</b><br> <br> <br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Are
you kidding me? After what we've seen these past dozen days, this match
should not even be a blip on the radar. Had this contest taken place
last year (pre-Oblivion), everybody, and I mean EVERYBODY, would be
calling for the tripling. Is Oblivion supposed to reverse all that? Is
it suddenly supposed to render Street Fighter's monumental impact on
our industry meaningless? Will it erase the memories of brothers
huddled over the television, getting in a quick round of Ken vs. Ryu
in-between X-Men and Spiderman on Saturday mornings? Will it erase the
memories of friends digging through their pockets, searching
desperately for that one last quarter at the arcade? Will it erase
cheat codes that got you color-swapped characters (a BLUE RYU?!)? Will
Oblivion erase <i>Street Fighter</i>? HELL ****ING NO.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/15/2006 6:52:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320009631">message detail</a>
 | #107</td></tr>
<tr class="even">
<td>
The Elder Scrolls<br>+ Oblivion<br>- I'm lmao thinking of all the people who won't know what "Elder Scrolls" even is<br><br>Street Fighter<br>+ IT'S STREET FIGHTER<br>- Uhh... it uh... for this match, you see... **** this, where's my SNES?!<br><br>My prediction: Street Fighter def. The Elder Scrolls (73-27)<br> <br> <br> <br><b>Leon&#8217;s Analysis</b><br> <br>Honestly,
this is a difficult match to gauge, as far as what the percentages will
be. I really don&#8217;t know what to expect from The Elder Scrolls. It could
do anything from win this match to becoming like the last 3 seed who
faced a 6th seeded Street Fighter (That&#8217;s Albedo against Bison, for
those of you who need some help figuring that one out). It&#8217;s obvious
that Oblivion is popular and is a heavy contender for Game of the Year
just about anywhere, but its main problem is that it&#8217;s on two platforms
that aren&#8217;t exactly popular on GameFAQs: XBox 360 and the PC. Well, I
shouldn&#8217;t say that the PC isn&#8217;t popular, but compared to many video
game sites, it isn&#8217;t. <br><br>We don&#8217;t have much to work with as far
as the Elder Scrolls is concerned. The newest installment, Oblivion,
has consistently been in the top 5 FAQs since its release, but that
doesn&#8217;t really mean too much. We saw GTA: San Andreas at the top of the
list when Carl Johnson lost to Ness. The only poll we have to work with
was one taken around a month ago asking what the voters thought the
Game of the Year was so far. Oblivion didn&#8217;t unexpectedly well (or
Kingdom Hearts II did unexpectedly poorly, depending on who you ask),
finishing second with 22.1%, only 5.53% behind KHII. In my opinion,
Oblivion doing that well wasn&#8217;t THAT surprising. After all, it has been
heavily praised nearly everywhere, and gamers seem to agree that it is
that good.<br><br>The Street Fighter series is one that needs no
introduction. It is one of the most respected and revolutionary series
in the entire video gaming industry. In fact, that is what many
expected would carry it to a victory over Super Mario RPG in the Games
Contest. However, this was not meant to be, as it collapsed during the
Nintendo morning vote and lost the lead it had built during the early
hours of the poll. The series certainly won&#8217;t suffer from lack of name
recognition, which is something many Elder Scrolls fans are fearing. <br><br>We&#8217;ve
also seen four Street Fighter characters throughout the history of the
Character Contest. However, they have almost become infamous for bad
luck in contest draws. Ryu is easily the strongest representative and
is a high midcarder, but even so, he&#8217;s only had enough favor to make
the Sweet Sixteen ONCE. Ken Masters was stuck against Noble Niners in
both of his contest appearances, and Chun-Li made her debut in 2005
against Bowser, who had just made the Final Four of the Villains
Contest and had broken 40% on Sephiroth. In other words, she had no
chance. Bison actually won a match in the Villains Contest. Granted, it
was against pathetic competition, but he won. He actually had a fairly
decent chance of making the Final Four, getting the closest in the Ruin
Division to Diablo, though he was never able to catch him once daybreak
hit. Now in spite of their lackluster overall record, Street Fighter
characters have shown themselves to be decent midcarders (and a high
midcarder in Ryu&#8217;s case).<br><br>In regards to this match, the decisive
factor for me is which series I could see winning this match the most
easily. If Elder Scrolls wins, I think it would be have to be a
struggle. I could see Street Fighter winning this match easily. Elder
Scrolls does have an advantage when it comes to recency as Oblivion is
one of the biggest games of 2006, and it&#8217;s been a long time since we&#8217;ve
had a big Street Fighter release (and we may never have another one).
Yet in the end, I have to side with the classic fighting series.<br><br><i>Leonhart&#8217;s Prediction:</i> <b>Street Fighter with 59.99%</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/15/2006 6:53:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320009764">message detail</a>
 | #108</td></tr>
<tr class="even">
<td>
<b>HM&#8217;s Analysis</b><br> <br>Match number two featuring a Capcom
franchise &#8211; CJayC just loved packing these in the Ultima Division. The
most intriguing thing about this match is why there are people actually
giving Elder Scrolls anything resembling a chance in this one. It is
pretty hard for me to understand just what Elder Scrolls is bringing to
the table in strength and popularity that Street Fighter &#8211; one of the
most classic and well known series of all-time &#8211; cannot match. Elder
Scrolls, thanks to Oblivion, got into the contest, but it isn&#8217;t going
to do any surprising, unless you&#8217;re expecting it to win &#8230;<br><br>There
is not much that needs to be covered in this one, so I&#8217;ll try to keep
it relatively short. We all know that Street Fighter is a historic
franchise, it produces pretty strong characters (Ryu, Ken, Chun-Li,
Bison), and none of them ever end up being fodder, despite being from a
fighting game franchise. We have seen Street Fighter II perform in the
games contest before, and while it was not the <i>best</i> of performances, it was still more than good enough to beat with Elder Scrolls game with ease. <br><br>Elder
Scrolls is being looked at due to Oblivion, and likely its performance
in the recent &#8220;Best Game of the Year so far?&#8221; Well, it did not perform <i>that</i>
well in the poll. The other notable thing might be that Oblivion is
currently rocking the Top FAQ listings, but I would point out that
there have not been many notable games that need FAQs as much as games
like Oblivion. But then you just need to examine the most recent &#8220;Got
Xbox 360?&#8221; poll &#8230;<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2303" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2303">http://www.gamefaqs.com/poll/index.html?poll=2303</a><br><br>As one can see there, there is a good 83% that do not currently own an Xbox 360. Yes, Oblivion <i>is</i>
on the PC, too, but I really do not think this game has made nearly the
impact that is warranted to overcome something like Street Fighter. I
would take Street Fighter II over <i>any</i> Elder Scrolls game &#8211; and
I wouldn&#8217;t think twice about it. With so many popular games spanning so
many generations and so many consoles, it is hard to choose against
something like Street Fighter. Rack up another victory for Capcom&#8217;s
franchises.<br><br><b>Aitch Emm&#8217;s Bracket Says :</b> Street Fighter will win.<br><br><b>Aitch Emm&#8217;s Prediction :</b> Street Fighter 62% -- Elder Scrolls 38%<br><br><b>Aitch Emm&#8217;s Vote :</b> Street Fighter<br> <br><br> <br><b>Mnm&#8217;s Analysis</b><br><br>Battle Music: Ryu&#8217;s Marvel vs. Capcom Theme<br><br>I fail to see why people are saying this should be a debated match.  We have the Elder Scrolls vs. <i>Street Fighter</i>.  Elder Scrolls&#8230; vs. <i>Street Fighter</i>
as a series. I understand that Oblivion is probably a pretty popular
game, and I won&#8217;t even say garbage like &#8220;people won&#8217;t know that
Oblivion is an Elder Scrolls game&#8221;. But still, there is exactly <i>one</i>
poll that Elder Scrolls did well in. That&#8217;s the poll asking what the
GotY is so far. Oblivion did decent, netting a solid 22%, but more
notable is the fact that over 30% of the voters hadn&#8217;t played <i>any</i>
of the games yet. Don&#8217;t forget that many times, the Xbox fanbase has
shown good support to its representative in those types of polls, so
given Oblivion&#8217;s fanfare, it was <i>expected</i> that Oblivion did
well in that poll. That one poll still gives me very little reason to
believe that The Elder Scrolls are more popular on this site than
Street Fighter. The other Elder Scrolls games are basically a
non-factor as none have shown to have any type of popularity on this
site whatsoever.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/15/2006 6:54:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320009990">message detail</a>
 | #109</td></tr>
<tr class="even">
<td>
So this is basically Oblivion vs. Street Fighter. Some people talk like
Street Fighter itself doesn&#8217;t have any strength. Let&#8217;s not forget that
Street Fighter II didn&#8217;t just lose to any game in the games contest. It
lost to Super Mario RPG. Elder Scrolls is no SMRPG. And even then, SFII
still got about 44% on SMRPG, which is damn good. I&#8217;ve heard an
argument that Star Wars: KOTOR is higher than SFII in the games
X-stats, but for one, those X-stats are hardly the bible, and two,
Elder Scrolls is no Star Wars. Oblivion doesn&#8217;t even have as long as
KOTOR did to establish itself. <br><br>Also,
don&#8217;t forget that we&#8217;re talking about the Street Fighter series in its
entirety. As much as you may want to believe, Street Fighter II isn&#8217;t <i>all</i>
there is to the Street Fighter series. We&#8217;re talking fans of the Alpha
games, SFIII, and probably even the Vs. games, as they are pretty much
SF games at heart. And don&#8217;t forget that Street Fighter Alpha Anthology
recently dropped on us just in time for the contest. I don&#8217;t see how
Elder Scrolls has a chance in this match. The PC and Xbox fanbase will
make sure that it performs respectably, but I don&#8217;t know how it can
actually take down the Street Fighter series.<br><br>Bracket: Street Fighter<br>Vote: Street Fighter<br>Prediction: Street Fighter with 68.65%<br> <br><br><br><b>HaRRich&#8217;s Analysis</b> <br><br>Predicted winner:  Street Fighter<br>Top 100 List comparison:<br>---TES - N/A (had no games on the drop-down list)<br>---SF2 - #47<br>Best Game Ever x-stat comparison:<br>---TES - N/A (no rep)<br>---SF2 - 24.08% (<b>SF2 LOST <i>?!</i></b>)<br><br>Oblivion
may be second-in-line for GotY right now, but it's mainly confined to
the 360, the sequel to the Xbox that hasn't even been out a year yet.
Morrowind may be liked by some (including myself at times), but you
would be silly to think that's where much of TES's strength will be
coming from. Any other game in the series feels like a non-factor to
me, mainly because I never heard of their names (I feel like a real
prick, like Colbert...suh-weet)...and I figure that TES may lose the
occasional vote simply because people may not realize Morrowind or
Oblivion are part of the series -- the series name is more over-looked
by the friends I know that any other series I can think of off the top
of my head. While both TES games I mentioned do have the PC on their
side, I do NOT want to take my chances on two PC/Xbox/360-only
non-linear RPGs to beat the SF series. I would take Super Mario RPG
over the entire TES series, and the SF series is bound to be stronger
than SF2 by itself. The SF series has also been around much longer and
has been seen on more systems with more games than TES, and the SF
series was essentially the beginning of a popular genre. TES should do
fine for itself, but it will be a long-shot to pull off the win.<br><br>Street Fighter wins with 59.12%<br> <br><br><br><b>Lopen&#8217;s Analysis</b><br> <br>You've
got some people signaling the upset alarms at this one. Well you know
what I'm saying? Forget it. Go back to your homes and cook your quiche
in peace! The Elder Scrolls has all the ingredients for disaster. Let's
go over em, numerical list style.<br><br>1. It's a series that draws
its power from the PC (weakest current gen rep on the site) and the
X-Box. (get this&#8230; second weakest current gen rep on the site)<br><br>2. The name "The Elder Scrolls". What kinda crap is that? It's not something I'd <i>immediately</i>
associate with Morrowind or Oblivion before analyzing this bracket to
death. It's a thinker of a series title. I maintain that voters don't
take excessive time to think. "What's an Elder Scroll, mommy? Is it
something old people use when they go potty?"</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/15/2006 6:55:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320010191">message detail</a>
 | #110</td></tr>
<tr class="even">
<td>
3. Elder Scrolls hasn't really done anything to make me think it can
conquer one and two, despite having plenty of chances to do so. "Oh&#8230;
oh&#8230; Oblivion turned heads in the "game of the year so far?" poll!" No&#8230;
it really didn't. It didn't do <i>poorly</i>,
but it still didn't get much more than 20%. Morrowind was also in an
old poll or two, and I don't think it did too admirably either.<br><br>Yes, fellows, OMG SF2 LOST!? to Mario RPG. But I'm sick and tired of people bringing it up like that's a <i>bad thing</i>. You think any Elder Scrolls game could pull 45% on Super <i>Mario</i> <b><i>RPG</i></b>?
Come on! That's a crazy combination! It was a big game for the SNES.
Chrono Trigger made it look less fearsome, but being two of the must
have RPG games for the SNES, it's possible Something Fishy Found its
way into that match. Street Fighter 2 is not as weak as it looks I
stand by that.<br><br>And you know what? I'm also tired of people claiming Street Fighter 2 is <i>all</i>
that Street Fighter has! It's not. I know that the prime time for
Street Fighter was back in those classic SNES days, warring with Mortal
Kombat for supremacy, but the later games are <i>not</i> a complete
non-factor! Ask Morrigan and Strider, with their "coincidentally" close
X-Stat values in 2002. Ask them. Oh, they're lovebirds, they were made
for each other. That's a cute couple, but damn it, no, that's not it!
They're both popular choices in Marvel vs. Capcom 1 and 2! <i>That's</i>
why they both happened to land so close together. Sure, Terry Bogard
and SNK dudes may suck it up, but I think Capcom fighters still have a
fan base on this site. Beyond just SF2. Watch out for the Alpha games
and even the vs. crossovers to help Street Fighter out in this match.<br><br>This
is the Albedo/M. Bison of the contest right here. More known entity
goes against some fairly unproven RPG fan base. Entity is still the
favorite, but some people believe that entity may lose. People are
humbled when entity bludgeons the tar out of unproven RPG fan base.
Entity&#8230; yeah&#8230; makes Street Fighter sound cool, am I right?<br><br><b>Lopen's Prediction:</b> Street Fighter with 68.44%<br> <br> <br> <br>Comments: All Street Fighter here. Percentages are all over the place though. It's real hard to gauge TES.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/15/2006 6:57:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320010695">message detail</a>
 | #111</td></tr>
<tr class="even">
<td>
Ah Leon. One of these days you won't find yourself boxed in. I'm sure of it!<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/15/2006 6:58:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320010948">message detail</a>
 | #112</td></tr>
<tr class="even">
<td>
At least I wasn't boxed in the worst this time. Ulti's got it a little worse than me.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29209811" class="name">Tatsumaki Senpuu</a> |
Posted 7/16/2006 8:57:00 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320127782">message detail</a>
 | #113</td></tr>
<tr class="even">
<td>
Yoblazer -- 73%<br>Mnm -- 68.65%<br>Lopen -- 68.44%<br>Moltar -- 66%<br>Aitch Emm -- 62%<br>Soul -- 61.15%<br>Leonhart -- 59.99%<br>Ulti -- 59.24%<br>HaRRich -- 59.12%<br><br><br>Right
now it is look like it's between me and Moltar. Street Fighter is
getting plummeting in percentage. It all depends on what side of 64% it
ends on<i>!!</i><br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=238823&amp;board=8&amp;topic=29209811" class="name">Daranix</a> |
Posted 7/16/2006 12:24:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320154643">message detail</a>
 | #114</td></tr>
<tr class="even">
<td>
Tag.<br>---<br><i>...in accordance with the prophecies.</i><br><i>Wind!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/16/2006 12:48:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320158917">message detail</a>
 | #115</td></tr>
<tr class="even">
<td>
Mega Man........58.12% 62075<br>Mario Kart........41.88% 44727<br>TOTAL VOTES............106802<br><br>62.96% of the brackets predicted this match correctly.<br><br>Not
bad, Mega Man. The MM series easily beats Mario Kart in a match many of
us thought to be pretty close. Looks like the older, bigger series wins
once again.<br><br>Today, Street Fighter is holding its own against Elder Scrolls. It's falling in the middle of all of our predictions.<br><br>Soul - 3<br>Ulti - 2<br>Moltar - 2<br>HaRRich - 2<br>HM - 2<br>Yoblazer - 1<br>Leon - 1<br>Mnm - 0<br>Lopen - 0<br><br>Ulti had the closest MM prediction, so the point is his.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Elder Scrolls vs. Street Fighter - Bracket: <b>SF</b> - Vote: <b>SF</b> (12/14)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/16/2006 12:53:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320159829">message detail</a>
 | #116</td></tr>
<tr class="even">
<td>
+9 Ulti<br>+8 Lopen<br>+7 Heroic Mario<br>+6 Moltar<br>-1 Soul<br>-2 Leonhart<br>-3 HaRRicH<br>-4 yoblazer<br>-5 mnm<br><br><b>The Rankings</b> (Through Mega Man/Mario Kart)<br>1. Master Moltar (65)<br>2. UltimaterializerX (54)<br>3. XxSoulxX (53)<br>4. yoblazer33 (47)<br>5. Lopen (45)<br>6. Leonhart (41)<br>7. Heroic Mario (40)<br>8. therealmnm (37)<br>9. HaRRicH (37)<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Elder Scrolls vs. Street Fighter - Bracket: <b>SF</b> - Vote: <b>SF</b> (12/14)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/16/2006 12:57:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320160497">message detail</a>
 | #117</td></tr>
<tr class="even">
<td>
<i>9. HaRRicH (37)</i><br><br>My my my, look how far I have sunk.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29209811" class="name">THEJackSparrow</a> |
Posted 7/16/2006 1:56:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320171828">message detail</a>
 | #118</td></tr>
<tr class="even">
<td>
Moltar has taken control in the points system.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29209811" class="name">SquallidSnake</a> |
Posted 7/16/2006 3:16:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320188619">message detail</a>
 | #119</td></tr>
<tr class="even">
<td>
Will I get boxed in yet again? We're about to find out!<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/16/2006 4:15:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320200747">message detail</a>
 | #120</td></tr>
<tr class="even">
<td>
Here's to hoping!<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/16/2006 5:12:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320212322">message detail</a>
 | #121</td></tr>
<tr class="even">
<td>
<b>Ultima Division:</b> <i>Round 1 - Match 16</i> &#8211; (2)Resident Evil vs. (7)Shadow Hearts <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Resident Evil</b><br>This
survival horror franchise has been creeping us out with bad zombies and
voice acting since the PS days. The latest installment, Resident Evil
4, is IMO, the best in the series.<br> <br><b>Shadow Hearts</b><br>Yeah,
it&#8217;s that one RPG game, you know&#8230;Shadow Hearts! Of course you know
Shadow Hearts, everyone does! There&#8217;s 3 of them too, but I&#8217;m sure you
knew that as well!<br><br>Popular franchise Resident Evil vs. Obscure
Japanese RPG series. Oh woe is me, who do I pick? I guess I&#8217;ll go with
Resident Evil. Ok, analysis done, new topic.<br><br><b>Top 3 Matches I&#8217;m looking Forward to Next Round</b><br><br>3.
Street Fighter vs. Resident Evil - Many people are banking on RE4 to
give it the edge over the SF franchise. Also, there is a pre-RE4 poll
that has RE &gt; SF in regards to Best Capcom franchises. Still, that
doesn&#8217;t mean one can count out SF. <br><br>2. Castlevania vs. Kingdom
Hearts - After Castlevania upset Halo, people have been saying it has a
good shot to take out KH. It&#8217;s less-than-impressive performance on
Harvest Moon also didn&#8217;t help it. Older series have been doing very
well so far in this Contest, so Castlevania is looking good to score
another upset. <br><br>1. Sonic vs. Super Smash Bros. - The match of
Round 2 IMO. There are strong cases for both games to win this match,
Sonic being it&#8217;s longevity while SSB has the power of SSB:M on its
side. Another old school, series with many games vs. a newer one with
only 2 games. However, two very powerful games on a Nintendo-heavy
site. It will be very interesting to see which way this one will go.<br><br><b>Moltar&#8217;s Bracket Says:</b> Resident Evil will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Resident Evil: 81% - Shadow Hearts: 19%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>HAAAAAAAAAHAHAHAHAHA<br><br>Resident
Evil is going to kill this match, and we'll see just as much whining as
we did during Samus/Yuri. It'll be hilarious and pathetic. I should
bother getting around to playing the.... three SH games I own. I should
also write more than like 4 sentences per match, eh? &lt;_&lt;<br><br>Prediction: RE with 81.45%<br> <br><br><br><b>Soul&#8217;s Analysis</b><br> <br>*Yawn*<br><br>Yeah.<br><br><b>My prediction: Resident Evil wins with 86.35% of the vote.</b> <br><br> <br><br><b>HM&#8217;s Analysis</b><br> <br>Number
three in the Capcom line of winners; we have the second seed Resident
Evil against a cult PS2 RPG series. Truthfully, this does not really
need much analysis at all because Shadow Hearts is fodder and would do
no better in any other place in the bracket. It is almost somewhat sad
that something like this got in over Chrono or Ghouls &#8216;N Ghosts (SHUT
UP, it&#8217;s awesome). <br><br>Anyway, this match only sets up for a beast
of a showdown between Resident Evil and Street Fighter &#8211; another hotly
debated match, though favor lies with Resident Evil. We&#8217;ll get a first
hand look here at just how popular Resident Evil really is. It&#8217;s hard
to judge based off of a match against fodder, but I think we can all
expect Resident Evil in the division finals if this starts approaching
Final Fantasy and Zelda-like numbers &#8211; 80%+, maybe? <br><br>&#8230; Yeah.
Round 2 is just around the corner, so I can get back to the good
analyses soon enough. The King of Survival Horror easily takes this
one, and the showdown to decide Capcom&#8217;s second strongest franchise is
right around the corner &#8211; King of Horror or King of Fighting? Who shall
it be<i>!!</i><br><br><b>Aitch Emm&#8217;s Bracket Says :</b> Resident Evil will win.<br><br><b>Aitch Emm&#8217;s Prediction :</b> Resident Evil 83% -- Shadow Hearts 17%<br><br><b>Aitch Emm&#8217;s Vote :</b> Resident Evil.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/16/2006 5:12:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320212397">message detail</a>
 | #122</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>Ahh, the end of the first round is in
sight, and we get to relax a bit going into the second round, finishing
off with a blowout. If Shadow Hearts had been placed against any of the
big three, it would be in danger of receiving the biggest blowout of
the contest. As it stands, it&#8217;s still going to get killed, but not as
badly as some other series.<br><br>Honestly, it&#8217;s difficult to be more
obscure than Shadow Hearts is. It has a few rabid fanboys on Board 8,
but most people have never played it. As with most cult classic RPGs,
it does have some hardcore devotees, but it won&#8217;t amount to much,
especially going up against something like Resident Evil. The only
contest experience that Shadow Hearts can claim is the Yuri Hyuga in
SC2K5 being on the receiving end of the biggest blowout of the contest
against Samus Aran and finishing dead last in the stats (yes, behind
even Luca Blight, Sarah Kerrigan, and Manny Calavera). In fact, he
didn&#8217;t even prove to be worth 10% on SC2K5 Link.<br><br>The Resident
Evil series is the best-selling Capcom series of all-time (yes, even
above Mega Man with its 100+ games and Street Fighter). In other words,
it has its fair share of fans. It has also had representation in every
GameFAQs contest, though with some mixed results. Jill Valentine made
the Sweet Sixteen in SC2K2 as a 3 seed, knocking out Kirby and
Bomberman before bowing out to eventual contest champion Link. She
returned in SC2K3 as an 11 seed, but she barely broke 40% on Squall
Leonhart, though she actually did slightly better than Luigi, whom some
thought could be a powerhouse. Her final contest appearance to date was
SC2K4 as a 14 seed, where she had two chances against Ryu Hayabusa but
eventually fell short by 27 votes, at that time a record for the
closest match in contest history. Jill&#8217;s strength appeared to decrease
in every contest she was in, which may or may not be a good sign for
the Resident Evil series.<br><br>The primary villain of the series,
Albert Wesker, made two appearances in 2005. In the Villains Contest,
he was considered a sexy upset pick to beat Kefka in the second round.
However, when he failed to break 40% on Luca friggin&#8217; Blight, everyone
knew THAT wasn&#8217;t happening. In fact, he didn&#8217;t even reach 30% on Kefka,
though many of his fans were hoping he had underperformed due to the
Final Fantasy VI clown finally getting a sprite (granted, it was a
sprite that ONLY people who had actually gotten to the end of the game
would recognize, but still). That turned out not to be the case, as he
turned out to be weak enough to lose to Lloyd Irving in SC2K5, though
he did better than most people were expecting (primarily due to
overestimation of the Tales of Symphonia hero).<br><br>Making his debut
in SC2K5 was the main character of the 2005 Game of the Year, Resident
Evil 4, was THE Leon Kennedy. A beneficiary of my Nomination Rally
Contest, he received the honor of getting to continue the eternal
legacy of GFNW, facing the Half-Life star in the first round. Several
were expecting this finally to be the time that Gordon Freeman scored
less than 40%, but this was not the case. Maybe it was due to Half-Life
2, or maybe it was due to getting a close-up picture that showed the
Half-Life symbol, but our favorite loser managed to hold Leon Kennedy
under 60% in that match. For some reason, the casuals never learn the
golden rule (and apparently HaRRicH doesn&#8217;t either, as he seriously
considered picking the loser), as Gordon Freeman actually ended up
being the FAVORITE to win this match. <br><br>With a second round
match with Mega Man on the horizon, things weren&#8217;t looking good for
Leon Kennedy. Sure, defeat was certain even before the contest started,
but now it was looking to be <i>ugly</i>. However, he surprised us all
by pulling a performance comparable to Final Fantasy X hero Tidus in
2004, breaking 35% in the loss and making Gordon Freeman look like more
than fodder! What an oddity that turned out to be.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/16/2006 5:13:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320212521">message detail</a>
 | #123</td></tr>
<tr class="even">
<td>
The only look we&#8217;ve gotten at a Resident Evil game in the Games Contest
was the original Resident Evil, pitted as a 13 seed against Metal Gear
Solid, where it didn&#8217;t even break 30%. However, nobody expected it to
be the most popular entry in the series THEN, and it <i>definitely</i>
isn&#8217;t NOW. With the immense popularity of Resident Evil 4, the series
has received a much-needed revival in fan interest. It won Game of the
Year in 2005 with absolute ease and placed 14th on the GameFAQs Top 100
List (and this was BEFORE the Playstation 2 release, so it could be
even stronger now). The original Resident Evil also placed 53rd, which
isn&#8217;t too shabby at all.<br><br>Really, I gave this match about six
more paragraphs worth of analysis than this match actually needed.
Resident Evil wins this one going away.<br><br><i>Leonhart&#8217;s Prediction:</i> <b>Resident Evil with 83.57%</b> <br> <br><br> <br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>You
know how little thought I've given to this match? I honestly, solemnly,
right-hand-on-my-chest, cross-my-eye-or-hope-to-die swear that I'm
still not sure whether or not it actually <i>is</i> Shadow Hearts
that's up against Resident Evil. It could very well be some other
obscure RPG series that I know nothing about. Seiken Densetsu? Secret
of Mana or something? It really doesn't matter.<br><br>Resident Evil
would win this match in 1996 or 2006. Its Spring 2004 showing against
Metal Gear Solid should not be cause to simply throw away its potential
as a series. It has had many games on many, many consoles. Of course,
since early 2005, it has probably been the hottest series in all of
gaming, as the immensely popular Resident Evil 4 gave it a real shot in
the arm. This one won't be close.<br><br>Resident Evil<br>+ Good history and credibility<br>+ Hugely popular game was released just last year<br>+ Whored out like a mother<br>+ Established a genre<br>- Could Street Fighter surprise us next round? The prospect of an upset certainly seems more interesting now.<br><br>This RPG<br>+ It probably has a fanbase somewhere<br>- KotOR deserved this spot<br><br>My prediction: Resident Evil def. Japanese RPG (78-22)<br> <br><br><br><b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: The Second Malformation of &#8220;G&#8221; (RE2 2nd form of William Birkin)<br><br>Finally,
we get to the last match of the first round. I honestly don&#8217;t have much
to say about this match. I know next to nothing about Shadow Hearts,
and feel no need to really talk about it. This is basically another
chance for Shadow Hearts fans to let their series shine in a contest
setting. It already got one representative in the contest in Yuri
Hyuga, who was blown out by Samus. And now due to board heavy
nominations, Shadow Hearts gets in as a series. I still think that it
should have gave way to the Ninja Gaidens, Secret of Manas, and Teenage
Mutant Ninja Turtles of the world. &lt;_&lt;<br><br>We already know the
popularity of RE on this site. Before the release of RE4, the series
was already pretty popular, and since then, RE4 has shown to be an
immensely popular game. And I definitely don&#8217;t think that RE4
represents the strength of the series. It has plenty more to draw from.
I&#8217;ll save more analysis for next round though.<br><br>Bracket: Resident Evil<br>Vote: Resident Evil<br>Prediction:  Resident Evil with 78.52%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/16/2006 5:13:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320212656">message detail</a>
 | #124</td></tr>
<tr class="even">
<td>
<b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Resident Evil<br>Top 100 List comparison:<br>---RE4 - #14, RE - #53 (Fun-fact:  RE Code: Veronica was on the drop-down list but didn't finish in the top 100)<br>---SH - N/A (had no games on the drop-down list)<br>Best Game Ever x-stat comparison:<br>---RE - 16.86% (was behind FF7/MGS)<br>---SH - N/A (no rep)<br><br>The
only hint of a sign I know that may respresent the strength of Shadow
Hearts (ha, strength.....) is the only hint I need to see for this
match: Yuri got 12.68% against Samus last year. Nevermind the fact that
RE4 is out -- I would take the rest of the RE series to double SH, <i>then</i>
throw in a post-PS2 RE4 and you've got some fun. For the record,
assuming Samus is just a lil' stronger than Crono (where I have him in
my stats -- 36.62%), Leon Kennedy <i>before</i> RE4 hit the PS2 would
be expected to get 81.57% on Yuri...and I believe Leon is only in
two-three of the RE games. I'll cut SH a bit of slack compared to that
number since series =/= games =/= characters, but I do fully expect it
to be ugly.<br><br>Resident Evil wins with 79.12%<br> <br><br><br><b>Lopen&#8217;s Analysis</b><br> <br>All things are born from <b>SHADOW</b> and all things so end. No, no&#8230; that's not it. Maybe were this series called <b>DARKNESS</b> Hearts I'd be having more fun with this analysis. But no, it's&#8230; <i>Shadow</i>
Hearts. I hate you in these contests, Shadow Hearts. You and your buddy
Suikoden, you just keep coming back for more and more and more
beatings. You have nothing new to offer. We know you're gonna get beat,
and we know roughly how hard you're gonna get beat, too. Though at
least I like the Suikoden games, I can't say the same for you!<br><br>Eh&#8230;
I'm just bitter because this is easily the least interesting 7/8 seed,
and were it not here, Guilty Gear may have taken its place. Yeah&#8230; now
I'll admit Guilty Gear is almost certainly fodderific too. But Guilty
Gear is fodder that I personally love, and fodder we haven't seen yet.
Unlike this <i>Shadow Hearts</i>.<br><br>&#8230;what? Who said I'm unbiased?
I wasn't feeling funny and this match sure as hell isn't up in the air.
May as well draw some heat from SH fans. Die Yuri Hyugan pigs, die!<br><br><b>Lopen's Prediction:</b> Resident Evil with 74.01%<br> <br> <br> <br>Comments: Yeah...Shadow Hearts isn't winning.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1561532&amp;board=8&amp;topic=29209811" class="name">Tatsumaki Senpuu</a> |
Posted 7/16/2006 5:14:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320212807">message detail</a>
 | #125</td></tr>
<tr class="even">
<td>
<i>Leonhart&#8217;s Prediction: Resident Evil with 83.57% </i><br><br>Not again<i>!!</i><br><br>---<br>"Building the future and keeping the past alive are one in the same thing." -- <i>Solid Snake</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/16/2006 5:26:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320215103">message detail</a>
 | #126</td></tr>
<tr class="even">
<td>
<i>For some reason, the casuals never learn the golden rule (and
apparently HaRRicH doesn&#8217;t either, as he seriously considered picking
the loser)</i><br><br>As opposed to actually picking the loser and
seeing that the loser -- believe it or not -- statistically doesn't
look as weak as Clay Aiken? I'm content with that.<br><br><br><br><br><br><br>Kuja.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=945395&amp;board=8&amp;topic=29209811" class="name">FantasyFreak999</a> |
Posted 7/16/2006 8:06:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320248744">message detail</a>
 | #127</td></tr>
<tr class="even">
<td>
I'm just hoping that SH doesn't do as badly as Madden (I loves me my Shadow Hearts).<br>---<br>"Run, run, or you'll be well done!" <br>~Kefka, Final Fantasy 6~</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=800805&amp;board=8&amp;topic=29209811" class="name">ExThaNemesis</a> |
Posted 7/16/2006 8:10:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320249726">message detail</a>
 | #128</td></tr>
<tr class="even">
<td>
<i>I'm sure other Crew members have eons of text and stats about why
they think their pick will win, but I'm taking the much simpler route.
The name "Mega Man" is going to encompass every single one of Mega
Man's games with voters. No one is going to go "Zomg MMX is in the
contest this isn't a part of teh Mega Man lolzorz". Mario Kart is going
to be damn strong, but I think Mega Man will be stronger. If Mega Man
can avoid potential Nintendo SFF, it should win this. It might even win
it easily.<br><br>Prediction: MM with 56.25%</i><br><br>Crew = OWNED<br><br>lol Mario Kart<br><br>~*ST*~<br>---<br><b>|B|A|S|E|B|A|L|L|<br><i>--My Anti-Drug--</i></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=863018&amp;board=8&amp;topic=29209811" class="name">Janus5000</a> |
Posted 7/16/2006 8:27:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320253383">message detail</a>
 | #129</td></tr>
<tr class="even">
<td>
lol gloating<br>---<br>"Those who cast the vote decide nothing. Those who count the vote decide everything."</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/16/2006 10:54:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320288064">message detail</a>
 | #130</td></tr>
<tr class="even">
<td>
I really don't know why anybody is expecting Shadow Hearts to break 20%
in this match. HaRRicH was on the right track with the whole "Leon
Kennedy breaks 80% on Yuri by himself," and decided to go in the
opposite direction, as if for some reason he was expecting Shadow
Hearts to add more to Yuri than Resident Evil will to Leon Kennedy,
even though he specifically mentioned that he's only the star of two of
the games.<br><br>In other words, he makes no sense, but that's to be expected.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/16/2006 10:59:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320289229">message detail</a>
 | #131</td></tr>
<tr class="even">
<td>
Oh, and I'm not boxed in! And I one-upped Heroic Mario to boot!<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/16/2006 11:06:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320291146">message detail</a>
 | #132</td></tr>
<tr class="even">
<td>
Woohoo! Keep this up RE!<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/16/2006 11:07:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320291288">message detail</a>
 | #133</td></tr>
<tr class="even">
<td>
Bah, Soul shouldn't win a point for the "Analysis Crew." It was a whole two words long!<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/16/2006 11:09:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320291714">message detail</a>
 | #134</td></tr>
<tr class="even">
<td>
Maybe we just can't comprehend how deep it was...I mean, he is on track for the point.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Resident Evil vs. Shadow Hearts - Bracket: <b>RE</b> - Vote: <b>RE</b> (13/15)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/16/2006 11:12:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320292551">message detail</a>
 | #135</td></tr>
<tr class="even">
<td>
Yeah, I tried to give some respect to the games =/= characters thing,
and I've noticed I've been going too conservative lately too. I think
I'll need to start making changes to the rest of my analyses I haven't
already turned in.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/16/2006 11:13:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320292803">message detail</a>
 | #136</td></tr>
<tr class="even">
<td>
<i>Yeah, I tried to give some respect to the games =/= characters thing</i><br><br>But it was only logical that you should favor <i>Resident Evil</i> more because of it, not Shadow Hearts.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/16/2006 11:19:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320294113">message detail</a>
 | #137</td></tr>
<tr class="even">
<td>
<i>It was a whole two words long!</i><br><br>Pfft. You're lucky I even added that Yeah in there. <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/16/2006 11:23:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320295083">message detail</a>
 | #138</td></tr>
<tr class="even">
<td>
Two words for a blowout match or 2000?  I'm not sure which I'd rather read, actually.  <br><br>I kid, Leonhart.  <br>---<br>Raiden is still [<i>!!</i>] nominations short!  <i>I'm actually only half kidding!</i><br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/16/2006 11:40:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320298789">message detail</a>
 | #139</td></tr>
<tr class="even">
<td>
Hey, I read your entire Devil May Cry analysis, knowing you were 100% wrong! <br><br>By
the way, Moltar, if it's fair for me to ask this (if it's not, just
tell me. That's fine): How is my prediction for LoZ/MMX looking? A lot
higher? In the same general area?<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/16/2006 11:41:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320299117">message detail</a>
 | #140</td></tr>
<tr class="even">
<td>
Compared to everyone else, that is.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/16/2006 11:42:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320299191">message detail</a>
 | #141</td></tr>
<tr class="even">
<td>
Just because I think you were longwinded doesn't mean I didn't read it!  I wouldn't want to imply that.  I read them <i>all</i>.  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/16/2006 11:47:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320300380">message detail</a>
 | #142</td></tr>
<tr class="even">
<td>
Highest so far, Leon.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Resident Evil vs. Shadow Hearts - Bracket: <b>RE</b> - Vote: <b>RE</b> (13/15)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/16/2006 11:51:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320301314">message detail</a>
 | #143</td></tr>
<tr class="even">
<td>
Is it the highest by far or by a little bit? I was thinking about
lowering it back to where it originally was, but I want to see if I
have some breathing room or not.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/16/2006 11:53:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320301755">message detail</a>
 | #144</td></tr>
<tr class="even">
<td>
...is that fair?  It's one thing to ask, but another to change afterwards.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/16/2006 11:55:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320302255">message detail</a>
 | #145</td></tr>
<tr class="even">
<td>
Ehh, fine. Just lower my prediction by 2%.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/16/2006 11:58:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320302819">message detail</a>
 | #146</td></tr>
<tr class="even">
<td>
"Strategic percentage placing?"  Hmph.  Oh, sure, I'd be one point richer if I'd done that... but at <i>what cost</i>!?<br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/17/2006 12:03:03 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320303722">message detail</a>
 | #147</td></tr>
<tr class="even">
<td>
It's not so much strategy as it is frustration with getting boxed in.
I'd really be fine sticking with it as it is, but I don't want to risk
the point because I shot a <i>little</i> too high. And I don't want to lower it only to find out my lowering it caused somebody to be barely above me.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/17/2006 12:09:48 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320305078">message detail</a>
 | #148</td></tr>
<tr class="even">
<td>
At least you <i>have</i> a point! It's a big part luck on these
even if you do generally make better predictions... just look at the
discrepancy in the point system/score system. <br><br>I still prefer the point system, even if it does make me look worse.  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/17/2006 12:14:40 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320306034">message detail</a>
 | #149</td></tr>
<tr class="even">
<td>
And I partially want to borrow a page out of Soul's book and just shoot the highest on a blowout.<br><br>Of course, the last time I shot the highest was GTA/Warcraft.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/17/2006 1:57:44 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=320322652">message detail</a>
 | #150</td></tr>
<tr class="even">
<td>
Shoot to thrill baby. Shoot to thrill.<br><br>And I'm finding it extremely difficult to write about these easy, easy matches. Jeez, I got to find more jokes. <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">1</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=1">2</a></li>
<li>      3</li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=3">4</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=4">5</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=5">6</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=6">7</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=7">8</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=8">9</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=9">10</a></li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage3_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29209811&amp;page=2" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage3_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>