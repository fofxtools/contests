<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">

<title>GameFAQs: Message List</title><link rel="stylesheet" type="text/css" href="genmessage10_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage10_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage10_files/bc.css"></head><body linkifytime="310" linkified="7" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage10_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage10_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29209811%26page%3D9"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<a href="http://adlog.com.com/adlog/c/r=10153&amp;s=675154&amp;t=2006.07.30.22.06.56&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=00c17-gne-ad544C8F1BE158BE55/http://www.gamespot.com/promos/2006/gtr2-demo/index.html" target="_blank"><img src="genmessage10_files/gtr2_demo_leader.jpeg" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage10_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew - Part 2</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29209811&amp;page=9">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29209811" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">First
          Page</a> |
          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=8">Previous
          Page</a> |
          Page 10 of 10      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/27/2006 9:27:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323092402">message detail</a>
 | #451</td></tr>
<tr class="even">
<td>
<b>HM&#8217;s Analysis</b><br><br><b>Super Mario Bros.</b><br><i>Previous Matches :</i><br><br>Super Mario Bros &#8211; 92.21% -- 108,723<br>Madden NFL &#8211; 7.79% -- 9,186 <br><br>Super Mario Bros. &#8211; 81.13% -- 97,775<br>WarCraft &#8211; 18.87% -- 22,741 <br><br><b>Super Smash Bros.</b><br><i>Previous Matches :</i><br><br>Super Smash Bros &#8211; 76.37% -- 90,789<br>Dragon Quest &#8211; 23.63% -- 28,092 <br><br>Sonic the Hedgehog &#8211; 42.34% -- 53,423<br>Super Smash Bros. &#8211; 57.66% -- 72,755 <br><br>Can you say &#8230; <i>Same Fanbase Factor</i>? I can! This will probably be one of the larger SFF matches we see in the contest because this just <i>screams</i>
fanbase overlap. Both hugely popular Nintendo series and one of them is
among the untouchable Big Three. Yeah, that has a recipe for
destruction. Fortunately, the better of the two series will be winning
this affair<i>!!</i> <br><br>Super Mario Bros. in the last round put on
a rather shocking performance to me. When it started off the match with
~85% of the vote, I began to speculate that its chances at winning the
entire contest might be looking good just because of the similar
performance it was having when compared to Final Fantasy. Eventually,
though, that percentage came down to something a bit more realistic,
but still a bit above my expectations. SMB managing to quadruple
Warcraft speaks well of its own strength &#8211; something SSB has to fear,
even before SFF enters the equation. <br><br>Super Smash Bros. &#8230; well,
it shocked the crap out of me. I did not expect it to win so easily
against Sonic, but it was over the moment it started. It was an
impressive win, even with any potential SFF between the two, but
nothing that even begins to put this match into question. This began to
beg the question about whether or not SSB could really end up as the
fourth strongest series in the contest, even about Metal Gear, but I
clearly have my own doubts about that. <br><br>Unfortunately, we were
once again denied a Mario/Sonic showdown, instead getting this SFF fest
between two popular Nintendo series. The biggest question about this
match is just how high SMB can get and if just how much SFF it is going
to be getting. Another unfortunate aspect of this is we get no good
read on this division whatsoever thanks to SFF. It is probably not like
we&#8217;ll need it, even if we had another contest because so much would
likely change between all of the series in this contest, but yeah. <br><br><br>This
match will likely be boring, and likely devastating to the few people
who think SSB stands a chance at getting rSFF for the win. SMB gets one
last dominate performance before facing the <i>real</i> beast of this contest in Final Fantasy. It&#8217;ll finally get its competition shortly &#8230; <br><br><b>Aitch Emm&#8217;s Bracket :</b> Super Mario Bros.<br><br><b>Aitch Emm&#8217;s Prediction :</b> Super Mario Bros. &#8211; 75% Super Smash Bros. &#8211; 25%<br><br><b>Aitch Emm&#8217;s Vote :</b> Super Mario Bros.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/27/2006 9:28:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323092660">message detail</a>
 | #452</td></tr>
<tr class="even">
<td>
<b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: Bowser Boss Battle (Super Mario World)<br><br>I'll
try to make this short. Super Smash Bros. is going to have a hell of a
tough time with this matchup. In fact, it is going to get killed. Super
Smash Bros. has shown that it indeed carries plenty of strength on this
site. There's just one thing though... It <i>never</i> has had to go
up against another Nintendo entity in this contest, so there's no
indication on how it would hold up in a SFF match. This is a hell of a
way to find out, as this is probably one of the worst matchups SSB can
face. Basically <i>EVERY</i> Super Smash Bros. fan is a Mario Bros. fan, and it will show in this matchup.<br><br>I
also want to go and state how much I respect the Super Mario Bros.
series in this contest. It has shown zero signs of weakness in this
contest, and that will hold up for this match also. Put it this way, I
think Super Mario Bros. beats down Super Smash Bros. at <i>least</i> 70-30 <i>before</i>
SFF, so once the SFF is introduced, it will probably get ugly. Sure,
SSB will get some vocal support, but that won't hold up against the
legions of its fans that are bigger Mario Bros. fans. Seeing how Final
Fantasy destroyed Mega Man (which handled Mario Kart), I think SMB will
give SSB the same kind of beating, if not worse. The match pic is the
nail in the coffin. <br><br>I also want to go on record and say that
the match I am anticipating the most from this point on is not LoZ/FF,
but SMB/FF. I may be in the minority in thinking that SMB will give FF
a decent fight (40%+). Plus, that match pretty much indicates what
happens in LoZ/FF. Anyways, I'm looking for a SMB blowout!<br><br>Bracket: SMB<br>Vote: SMB<br>Prediction: Super Mario Bros. with 80%<br><br> <br><br><b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Super Mario Bros.<br>Earlier this contest:<br>---SMB - 92.21% on Madden NFL, 81.13% on Warcraft<br>---SSB - 76.37% on Dragon Quest, 57.66% on Sonic<br>Top 100 List comparison:<br>---SMB3 - #5, SM64 - #13, SMB - #22, SMW - #23, SMW2:YI - #82<br>---SSBM - #6<br>Best Game Ever x-stat comparison:<br>---SMB3 - 39.9% (8 Division champion), SMW - 34.24%, SM64 - 21.93% (SFF'd by LoZ:OoT, has since had SM64DS released)<br>---SSBM - 37.57% (128 Division champion)<br><br>SMB
has done nothing but impress thus far, yet the same can be said for
SSB...just not to the same degree. Furthermore, this will be an SFF
match that could possibly test the age-groups voting here. Although I
would be very tempted to take SSBM &gt; SMB3, practically any Nintendo
fan who has been playing games since the NES (or earlier) will vote for
SMB here. I'd think the large majority of the Genesis/SNES-initiated
will also vote for SMB. Gamers who started with the PSX/N64 will be
torn, though I think they'd side with SSB, and gamers who start with
this generation are almost-certainly siding with SSB...but think about
how many more voters here started before games went 3D, where Mario
will own SSB, then think about how many gamers started with the
PS2/Xbox/Gamecube, where SSB will break SMB -- the 32-64 bit era won't
make much of a difference here, I figure...<br><br>...yeah, so SMB has
the strong advantage there. From there, let's just break it down and
compare system releases. Yes, SSBM owns SMS on the Gamecube, but SSB
would lose (probably somewhat-respectably) to SM64. From there, pile
all of Mario's other games in there, and SSB loses big again. So then
let's just match games: SMB3 would probably beat SSBM in a close one,
SM64 would beat SSB...then pile the rest again, and SSB just can't
catch a break. Expect it to be bad, though I'm goin' to predict that an
SFF'd SSB would still outdo Warcraft. At least the right Super _____
Bros. series wins.....<br><br>Super Mario Bros. wins with 80.12%<br> <br><br> <br> <br><br>Comments:
Clean sweep for Super Mario Bros. I'm surprised alot of the board
thinks that SSB is going to break 30% though. Maybe I shouldn't be...</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3588357&amp;board=8&amp;topic=29209811" class="name">transients</a> |
Posted 7/27/2006 9:29:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323092936">message detail</a>
 | #453</td></tr>
<tr class="even">
<td>
board 8 expects a much closer match than the crew.<br>---<br><b>NOMINATE JAY SOLANO (Operation Shadow) for 2k6!</b><br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29527124" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29527124">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29527124</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/27/2006 9:30:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323093120">message detail</a>
 | #454</td></tr>
<tr class="even">
<td>
Wow. <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>stingers, Rad, longblade, and Ryoko owned me in a sig bet and all I got was this lousy T-Shirt</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1288566&amp;board=8&amp;topic=29209811" class="name">gtonizuka49</a> |
Posted 7/27/2006 9:31:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323093403">message detail</a>
 | #455</td></tr>
<tr class="even">
<td>
Looks like most of us think Mario will land right around the tripling range.<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2568612&amp;board=8&amp;topic=29209811" class="name">Draco1214</a> |
Posted 7/27/2006 9:32:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323093604">message detail</a>
 | #456</td></tr>
<tr class="even">
<td>
Wow, I had ~75% in my Oracle, and I thought <i>I</i> was overshooting.<br><br>Wouldn't be surprised if it broke 80%, though.<br>---<br><b><i>Organization XIII - Number III - Xordac</i></b><br>Currently Playing - Suikoden V, Street Fighter Alpha 3, New Super Mario Bros.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29209811" class="name">THEJackSparrow</a> |
Posted 7/27/2006 9:33:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323093900">message detail</a>
 | #457</td></tr>
<tr class="even">
<td>
*high fives Soul*<br><br>We boxed in HM <i>and</i> yoblazer!<br><br>And
if the board somehow turns out to be right about Super Smash Brothers
doing better than expected, I get the point because I have the lowest
prediction!<br><br>Of course, if SMB destroys it, I get last.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2303557&amp;board=8&amp;topic=29209811" class="name">FlamboyantSpy</a> |
Posted 7/27/2006 9:33:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323093901">message detail</a>
 | #458</td></tr>
<tr class="even">
<td>
Awww.... I was expecting ranges from High 50's to low 80's.<br><br>---<br><b>Explicit Content</b><br>Cheer Up Emo Kids</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3662060&amp;board=8&amp;topic=29209811" class="name">YoAriel33</a> |
Posted 7/27/2006 10:52:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323114379">message detail</a>
 | #459</td></tr>
<tr class="even">
<td>
Amazingly, if Kingdom Hearts finishes with 41.72%, Leon and HaRRicH will tie despite having very different predictions.<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29209811" class="name">THEJackSparrow</a> |
Posted 7/27/2006 10:53:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323114535">message detail</a>
 | #460</td></tr>
<tr class="even">
<td>
It's possible, too!<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29209811" class="name">THEJackSparrow</a> |
Posted 7/27/2006 10:55:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323115063">message detail</a>
 | #461</td></tr>
<tr class="even">
<td>
What? NOOOOO! Why did Kingdom Hearts have to go backwards for the first time in forever!<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29209811" class="name">THEJackSparrow</a> |
Posted 7/27/2006 11:31:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323124096">message detail</a>
 | #462</td></tr>
<tr class="even">
<td>
...Looks like having the lowest pick is going to pay off, heh.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1288566&amp;board=8&amp;topic=29209811" class="name">gtonizuka49</a> |
Posted 7/28/2006 12:11:32 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323133562">message detail</a>
 | #463</td></tr>
<tr class="even">
<td>
Metal Gear vs. Kingdom Hearts<br>+9 yo<br>+8 Ulti<br>+7 HM<br>+6 mnm<br>+5 Moltar<br>+4 Soul<br>+3 HaRRicH<br>+2 Leon<br>+1 Lopen<br><br><b>The Rankings</b> (Through Metal Gear/Kingdom Hearts)<br>1. Master Moltar (116)<br>2. yoblazer33 (112)<br>3. XxSoulxX (103)<br>4. UltimaterializerX (96)<br>5. therealmnm (91)<br>6. Leonhart (89)<br>7. Heroic Mario (81)<br>8. HaRRicH (75)<br>9. Lopen (69)<br><br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/28/2006 12:12:59 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323133922">message detail</a>
 | #464</td></tr>
<tr class="even">
<td>
Well...I didn't see THIS coming.<br>---<br>Moltar Status: Wanting you to <b>Nominate Shadow the Hedgehog!</b><br>Super Mario Bros. vs. Super Smash Bros. - Bracket: <b>SMB</b> - Vote: <b>SSB</b> (38/40)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/28/2006 12:13:10 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323133965">message detail</a>
 | #465</td></tr>
<tr class="even">
<td>
BOLD PREDICTION: I will be ONE point behind Ulti after this match. Bah.<br>---<br>Squall, Tidus, The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden<br>Presea, Chun-Li, Tifa, Celes, Quistis, Amy Rose, Mei Ling</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29209811" class="name">DaruniaTheGoron</a> |
Posted 7/28/2006 12:15:09 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323134448">message detail</a>
 | #466</td></tr>
<tr class="even">
<td>
Leon's got this pick easy.<br>---<br><b>Sp2k6:<i> 36/40</i> Rank: <i>Tied for 1478th</i> Losses: <i>Halo, GTA, SF</i> </b>Nominate Nidoran F and CATS <br><b>Yesterday's Pick: <i>Metal Gear</i> Today: <i>SMB</i> Tomorrow:<i>FF</i></b> in the character contest!</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29209811" class="name">SquallidSnake</a> |
Posted 7/28/2006 1:36:08 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323149423">message detail</a>
 | #467</td></tr>
<tr class="even">
<td>
Feels strange saying I've got this one easily when I might not even be
within 10% of being correct. I am kinda surprised that nobody went
lower.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/28/2006 1:36:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323241243">message detail</a>
 | #468</td></tr>
<tr class="even">
<td>
Man, I can't believe you guys were calling for the tripling here! You should've been more conservative, like me!<br>---<br>Squall, Tidus, The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden<br>Presea, Chun-Li, Tifa, Celes, Quistis, Amy Rose, Mei Ling</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3662060&amp;board=8&amp;topic=29209811" class="name">YoAriel33</a> |
Posted 7/28/2006 1:39:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323241886">message detail</a>
 | #469</td></tr>
<tr class="even">
<td>
*continues smacking his head against desk*<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/28/2006 2:56:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323260746">message detail</a>
 | #470</td></tr>
<tr class="even">
<td>
Metal Gear...............58.31% 80177<br>Kingdom Hearts.......41.69% 57336<br>TOTAL VOTES....................137513<br><br>46.21% of the brackets predicted this match correctly.<br><br>Not
even half the brackets had Metal Gear winning its division, wow.
Anyway, in a match with some very high vote totals, Metal Gear easily
beats Kingdom Hearts. KH still did pretty well though.<br><br>Today, SSB is sure doing well against SMB.<br><br>Soul - 5<br>Yoblazer - 3<br>Lopen - 3<br>HaRRich - 3<br>Moltar - 3<br>Leon - 2<br>Mnm - 2<br>Ulti - 2<br>HM - 2<br><br>Yo joins the 3 point club.<br>---<br>Moltar Status: Wanting you to <b>Nominate Shadow the Hedgehog!</b><br>Super Mario Bros. vs. Super Smash Bros. - Bracket: <b>SMB</b> - Vote: <b>SSB</b> (38/40)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3662060&amp;board=8&amp;topic=29209811" class="name">YoAriel33</a> |
Posted 7/28/2006 4:11:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323278292">message detail</a>
 | #471</td></tr>
<tr class="even">
<td>
Super Mario Bros. vs. Super Smash Bros.<br>+9 Leon<br>+8 HM (tie)<br>+8 yo (tie)<br>+6 Soul<br>+5 Moltar<br>+4 Lopen<br>+3 Ulti<br>+2 mnm<br>+1 HaRRicH<br><br><b>The Rankings</b> (Through Super Mario Bros./Super Smash Bros.)<br>1. Master Moltar (121)<br>2. yoblazer33 (120)<br>3. XxSoulxX (109)<br>4. UltimaterializerX (99)<br>5. Leonhart (98)<br>6. therealmnm (93)<br>7. Heroic Mario (89)<br>8. HaRRicH (76)<br>9. Lopen (73)<br><br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/28/2006 9:18:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323348865">message detail</a>
 | #472</td></tr>
<tr class="even">
<td>
+1 for me this match, too.  Man, this sucks, heh...at least it's the unofficial way.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/28/2006 9:39:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323353866">message detail</a>
 | #473</td></tr>
<tr class="even">
<td>
<b>Ultima Division:</b> <i>Round 3 - Match 28</i> &#8211; (1)Final Fantasy vs. (2)Resident Evil<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Final Fantasy</b> - <i>If we&#8217;re talking in power, FF is more scary than ANY horror game.</i><br>Round 1 &#8211; 85.98% vs. Diablo (14.02%)<br>Round 2 &#8211; 74.19% vs. Mega Man (25.81%)<br><br>Mega Man is able to avoid the tripling from FF.<br> <br><b>Resident Evil</b> - <i>I&#8217;d like to order one Jill Sandwich, please.</i><br>Round 1 &#8211; 87.76% vs. Shadow Hearts (12.24%)<br>Round 2 &#8211; 50.73% vs. Street Fighter (49.27%)<br><br>In the closest match of Round 2, RE squeaks by SF.<br><br>The
final match of Round 3&#8230;what a boring round this was. You know what,
this one is going to be another blow out too! Not because it&#8217;s Final
Fantasy, but because of SFF!<br><br>No, not that SFF were two
characters from the same company share a fanbase and the majority sides
with the stronger character. But the weird kind where two seemingly
un-related series share just one thing in common and something weird
happens so we just label it SFF! A good example of this is how Metal
Gear flops every time it faces something FF7 related. One could say
that since FF7 and MGS were two popular Playstation games and share a
similar fanbase, Sony fans will side with the stronger game. In this
case, FF7.<br><br>Now, we haven&#8217;t seen FF directly own something
RE-related, but Resident Evil got slaughtered in 2004 by MGS, which
went on to get slaughtered by FF7. So does logic apply here? Who
knows&#8230;Then again, RE2 and RE4 are stronger than the original RE anyway,
so maybe it was just very weak.<br><br>Anyway, I would already say Mega
Man is stronger than Resident Evil, so RE is getting tripled. Now add
in some fishysticks and FF wins with around 80%. <br><br>I now demand everyone take 5 seconds to laugh at Shadow Hearts.<br><br><b>Moltar&#8217;s Bracket Says:</b> Final Fantasy will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Final Fantasy: 79% - Resident Evil: 21%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>Blowout
expected, and a blowout we shall have. The question is whether RE beats
MM's score on FF or not, though I doubt it does. I'm fairly sure MM is
the favorite Capcom series on GameFAQs, though that was before Resident
Evil 4...<br><br>Prediction: FF with 75.01%<br> <br><br><br><b>Soul&#8217;s Analysis</b><br><br><i>FF defeated Mega Man with 74.19%<br>Resident Evil defeated Street Fighter with 50.73%</i><br><br>WHAT A SLAWBERKNOCKER!<br><br>Let's
see where we lie here. Final Fantasy killed Mega Man, while Resident
Evil struggled against Street Fighter. On the Capcom totem pole, Mega
Man is stronger then Resident Evil, which is stronger then Street
Fighter. So basically, the result of this match will be Final Fantasy
winning with more then 74.19%. How much stronger is Mega Man compared
to Resident Evil?<br><br>Mega Man got 64% on Leon Kennedy, proving that
RE4 has some strength on this site. Other then RE4, the only other RE
game that has some popularity is RE2, but it's all overshadowed by RE4.
So if Leon can only get 64% on Mega Man, I'm thinking Final Fantasy is
about to get another blowout here. My x-stats calculations are entirely
off, so best estimates...<br><br><b>My prediction: Final Fantasy wins with 83.01% of the vote.</b><br> <br><br><br><b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: The Dark Messenger (FFIX)<br><br>For
some reason, I could care less about this matchup. We all know that
Final Fantasy is going to destroy Resident Evil. The question is by how
much. In the games contest, there is good indication that RE may have
been SFF'd by MGS, which in turn was SFF'd by FFVII. Now RE directly
faces the FF juggernaut, except this time with a <i>tad</i> of the
Nintendo fanbase supporting it with the huge success of RE4. It won't
matter though. FF has its eyes on Mario Bros. and Zelda, and RE is just
a blip on the radar. 20% = success for Resident Evil.<br><br>Bracket: FF<br>Vote: FF<br>Prediction: Final Fantasy with 79%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/28/2006 9:39:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323353990">message detail</a>
 | #474</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>While Final Fantasy didn&#8217;t quite triple
Mega Man, it still found a way to impress, somehow breaking 100,000
individual votes yet again and pulling in the second highest vote total
these contests have <i>ever</i> seen. 135,000 votes in a blowout?
Final Fantasy is proving that it is THE vote-drawing power in this
contest. While the Legend of Zelda is pulling in higher percentages
(though this has been expected for various reasons), Final Fantasy has
consistently been pulling in more overall votes. Either way, the final
match is shaping up to be loaded, and while I think Final Fantasy is
still the favorite, the Legend of Zelda still has the potential to
surprise. <br><br>However, the only thing we&#8217;re really going to find
out in this particular match is the Capcom pecking order. We&#8217;ve already
discovered that Resident Evil is slightly favored over Street Fighter
(though people would argue that the only reason Street Fighter got so
close was because of the extremely unbalanced picture), but how do they
compare to Mega Man? To be quite honest, I can&#8217;t see either one
surpassing the Blue Bomber, and definitely not BOTH of them (which is
basically what would have to be the case if Resident Evil outdoes Mega
Man), but yet somehow, it wouldn&#8217;t be a total shock. Some people are
also calling for some measure of &#8220;SFF&#8221; by Final Fantasy against
Resident Evil, though I&#8217;m not so sure about that one. It has shown
itself to be capable of overperforming on series primarily featured on
the Playstation, so once again, it wouldn&#8217;t be a total surprise. <br><br>Really
though, the fun thing to see about this match is how low can Shadow
Hearts go in the stats! If Final Fantasy manages a quadrupling or
better, Yuri and company will register at less than 5% in the stats!
How exciting! With that, Shadow Hearts will now create a triumvirate of
suck, joining Tanner and Adventure for a combined force that couldn&#8217;t
even defeat Mr. Driller! Now go for that quadrupling, Final Fantasy!
Tranny&#8217;s indie cred is riding on this one! <br><br><i>Leonhart&#8217;s Prediction</i>: <b>Final Fantasy with 80.08%</b><br> <br> <br><br><b>Yoblazer&#8217;s Analysis</b><br> <br>Final
Fantasy showed us it was vulnerable against Mega Man, but it will be
back in cyborg-like form tonight. Actually, you know somethin'? I think
that Zelda assumes the role of "cyborg" better than any other series.
It seems to destroy everything in its path without thought, emotion, or
mercy. It's simply executing protocol. Final Fantasy, on the other
hand, is the "great warrior." Like any human, it is subject to flashes
of its own mortality (Mega Man) but its great victories are truly out
of this world (Diablo).<br><br>...Anyway, despite REMake, RE0, and RE4,
we all know a majority of Resident Evil fans are Playstation fans. We
also know that Final Fantasy dominates all things Playstation with an
iron fist, and after watching what <i>Metal Gear Solid</i> did to
Resident Evil two years ago before getting destroyed itself, no one
should expect anything impressive from Capcom's series. Bottom line -
ugly match.<br><br>Final Fantasy<br>+ Strongest game on this site<br>+ Several other very popular games<br>+ Spans several consoles and eras<br>+ It's the backbone of GameFAQs<br>+ Credibility up the wazoo<br>- Nothing<br><br>Resident Evil<br>+ Incredible first round performance<br>+ Good history and credibility<br>+ Hugely popular game was released just last year<br>+ Whored out like a mother<br>+ Established a genre<br>- Its Playstation fanbase will abandon it in great numbers<br>- It's going to get killed<br><br>My prediction: Final Fantasy def. Resident Evil (81-19)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/28/2006 9:40:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323354126">message detail</a>
 | #475</td></tr>
<tr class="even">
<td>
<b>HM&#8217;s Analysis</b><br><br><b>Final Fantasy</b><br><i>Previous Matches :</i><br><br>Final Fantasy &#8211; 85.98% -- 107,648<br>Diablo &#8211; 17,560 <br><br>Final Fantasy &#8211; 74.19% -- 100,574<br>Mega Man &#8211; 25.81% -- 34,988 <br> <br><br><b>Resident Evil</b><br><i>Previous Matches :</i><br><br>Resident Evil &#8211; 87.76% -- 97,696<br>Shadow Hearts &#8211; 12.24% -- 13,627 <br><br>Street Fighter &#8211; 49.27% -- 60,308<br>Resident Evil &#8211; 50.73% -- 62,087 <br><br>Surprisingly,
Resident Evil barely managed to scrap by in the last round against
Street Fighter. On the other hand, Final Fantasy put up a rather
expected performance that did sway its chances of winning one way or
the other. This match should not be a good gauge of anything either
given the fact that it could potentially result in some SFF being at
play here. Still, you have to figure it will need to perform well in
the wake of Zelda&#8217;s continued dominance in this contest. <br><br>Last
round, Final Fantasy started out rather weird by not even doubling Mega
Man at the first five minutes of the poll. This led many to speculate
that the home of the Blue Bomber had basically snatched up the spot as
the fourth strongest series in the contest. But, to surprise too many,
Final Fantasy went on a rampage and went from not even doubling to
nearly <i>tripling</i> by the end of the match. Final Fantasy&#8217;s
mid-70s performance puts it right where it needs to be to continue to
look good at snatching up the championship. <br><br>Resident Evil,
however, put on a rather poor performance going by expectations. Those
of us who sided with the survival horror series overshot just how
strong Resident Evil would be or undershot just how strong Street
Fighter would be. I, myself, went with a solid 54% for Resident Evil,
which wasn&#8217;t too far from the final percentage. Still, Street Fighter
definitely impressed by nearly getting the upset that a couple of
others were hoping for. Regardless of its performance, it stands no
chance against the beast in this round. <br><br>Ultimately, this match
is going to be a complete blowout. It will be interesting to see if
there is any type of SFF in this match-up. If it exceeds 80%, I&#8217;m
almost convinced there would be, but if Resident Evil can hold strong
and keep this in between 75% - 79%, I&#8217;d be genuinely impressed by its
performance. That said, I cannot imagine Final Fantasy failing to break
80% here, even if it&#8217;s only by a little. <br><br><b>Aitch Emm&#8217;s Bracket :</b> Final Fantasy<br><br><b>Aitch Emm&#8217;s Prediction :</b> Final Fantasy &#8211; 80.15% ; Resident Evil &#8211; 19.85%<br><br><b>Aitch Emm&#8217;s Vote :</b> Final Fantasy</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/28/2006 9:41:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323354351">message detail</a>
 | #476</td></tr>
<tr class="even">
<td>
<b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Final Fantasy<br>Earlier this contest:<br>---FF - 85.98% on Diablo, 74.19% on Mega Man<br>---RE - 87.76% on Shadow Hearts, 50.73% on Street Fighter<br>Top 100 List comparison:<br>---FF7 - #1, FF3/6 - #10, FFX - #12, FF8 - #17, FFT - #19, FF9 - #42, FF2/4 - #50, FF - #76, FFTA - #89<br>---RE4 - #14, RE - #53 (RE Code: Veronica was on the drop-down list yet didn't make the Top 100 List)<br>Best Game Ever x-stat comparison:<br>---FF7
- 50% (Best. Game. Ever. champion), FF3/6 - 39.4%, FFX - 36.86%, FF -
32.24%, FFT - 28.69% (was behind FF7/MGS), FFTA - 24.27% (SFF'd by FFX)<br>---RE - 16.86% (was behind FF7/MGS)<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=523" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=523">http://www.gamefaqs.com/poll/index.html?poll=523</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1454" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1454">http://www.gamefaqs.com/poll/index.html?poll=1454</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2447" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2447">http://www.gamefaqs.com/poll/index.html?poll=2447</a><br><br>It's a given that Resident Evil is going to lose, and RE4 is the only thing that could <i>possibly</i>
help RE match Mega Man's performance against Final Fantasy...but seeing
how it did against Street Fighter and I can't see MM &gt;= SF, I'm not
counting on it. I'd also be cautious about FF maybe even SFF'ing RE --
if FF7 SFF'd MGS after MGS SFF'd RE and if that chain held true so that
FF7 could SFF RE, then alot of the RE series would be up for SFF
against FF...but that's probably ignorable unless we see this become an
85-15 match.<br><br>Final Fantasy wins with 77.12%<br> <br><br><br><b>Lopen&#8217;s Analysis</b><br><br>Final Fantasy smashes things, it smashes em good.<br><br><b>Lopen's Prediction:</b> Final Fantasy with 82.61%.<br><br>&#8230;<br><br>Not
enough? Want to read more of my great writing? Fine&#8230; I'll just say that
Street Fighter would do better here. Yeah, PS SFF will help to <i>crush</i>
the enemy. Not to a Metroid-like pulp, mind you, because the big gun
RE4's pretty isolated from the evil Final Fantasy dominion, so it'll be
spared. There aren't any Gamecube FF titles, right? Oh, no&#8230; FINAL
FANTASY CRYSTAL CHRONICLES!? WHY!??????<br><br><b>Lopen's Prediction:</b>(hey, it's the same!) Final Fantasy with 82.61%.<br> <br> <br> <br>Comments: Final Fantasy has got this. Hopefully we're closer this time though.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/29/2006 11:07:42 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323454584">message detail</a>
 | #477</td></tr>
<tr class="even">
<td>
Super Mario Bros..........61.76% 76533<br>Super Smash Bros........38.24% 47386<br>TOTAL VOTES........................123919<br><br>62.89% of the brackets predicted this match correctly.<br><br>Well,
that didn't go as bad as we all thought. SSB is able to hold it's own
against the SMB franchise, which is pretty surprising to me. That
speaks volumes for SSB's strength.<br><br>Today, Final Fantasy is pulling the tripling on Resident Evil. Now that's something I expected.<br><br>Soul - 5<br>Leon - 3<br>Yoblazer - 3<br>Lopen - 3<br>HaRRich - 3<br>Moltar - 3<br>Mnm - 2<br>Ulti - 2<br>HM - 2<br><br>Though Leon was WAAAAY off, he still had the lowest SMB pick, and therefore gets the point.<br>---<br>Moltar Status: Wanting you to <b>Nominate Shadow the Hedgehog!</b><br>Final Fantasy vs. Resident Evil - Bracket: <b>FF</b> - Vote: <b>RE</b> (42/44)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29209811" class="name">THEJackSparrow</a> |
Posted 7/29/2006 3:07:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323499113">message detail</a>
 | #478</td></tr>
<tr class="even">
<td>
Moltar, I sent the next two analyses to you.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/29/2006 10:04:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323585841">message detail</a>
 | #479</td></tr>
<tr class="even">
<td>
<b>Final Four:</b> <i>Match 29</i> &#8211; (1)Legend of Zelda vs. (1)Metal Gear<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Legend of Zelda</b> - <i>Match Weapon: Master Sword</i><br>Round 1 &#8211; 89.97% vs. Civilization (10.03%)<br>Round 2 &#8211; 80.32% vs. Mega Man X (19.68%)<br>Round 3 &#8211; 84.70% vs. Metroid (15.30%)<br><br>Legend of Zelda beats Metroid worse than it did to MMX&#8230;wow.<br> <br><b>Metal Gear</b> - <i>Match Weapon: Cardboard Box</i><br>Round 1 &#8211; 69.9% vs. Soul Calibur (30.1%)<br>Round 2 &#8211; 65.23% vs. Fire Emblem (34.77%)<br>Round 3 &#8211; 58.31% vs. Kingdom Hearts (41.69%)<br><br>Metal Gear has no trouble with Kingdom Hearts.<br><br>Well, an all 1-seed final four. Surprisingly enough, we&#8217;ve never had one before. Let&#8217;s see how this turns out.<br><br>In
the first match of the Final Four, Legend of Zelda, aka &#8220;The Series
that blows out things&#8221; takes on Metal Gear. So far, Metal Gear hasn&#8217;t
been all that impressive. A good win over SC, an unimpressive win over
FE, and a respectable win over KH. Legend of Zelda? Well, it hasn&#8217;t
failed to shock the heck out of us yet.<br><br>Needless to say, Zelda&#8217;s
free trip to the finals continues, as Metal Gear is just another victim
in its path. At least Metal Gear should do much better than Zelda&#8217;s
previous three opponents, seeing as how it does have quite a bit of
strength and isn&#8217;t from Nintendo. I&#8217;d consider 30% good enough and if
MG can escape the doubling, well, that&#8217;s a moral victory.<br><br><b>Moltar&#8217;s Bracket Says:</b> Legend of Zelda will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Legend of Zelda: 68% - Metal Gear: 32%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>Master Moltar 1 (9:58:14 PM): LoZ/MG?<br><br>Auto response from Ultimaterializer (9:58:15 PM): Warcraft 3.<br><br>Ultimaterializer returned at 10:00:12 PM. <br>Ultimaterializer (10:00:14 PM): oops<br>Ultimaterializer (10:00:21 PM): uh, here:<br>Ultimaterializer
(10:01:37 PM): "Wow, I totally forgot to write an analysis for this
match. Uh.... Zelda wins obviously, the only question is whether or not
Zelda will put a scare into all of the 'zomg FF cannot possibly lose'
drones."<br>Ultimaterializer (10:01:45 PM): <b>Prediction: Zelda with 73.33%</b><br>Master Moltar 1 (10:02:33 PM): I should just c/p this whole convo as the analysis<br>Ultimaterializer (10:02:38 PM): Do it<br>Master Moltar 1 (10:03:34 PM): Consider it done<br> <br><br><br><b>Soul&#8217;s Analysis</b><br> <br><i>LoZ defeated Metroid with 84.70%<br>Metal Gear defeated Kingdom Hearts with 58.31%</i><br><br>FINAL FOUR HOLY ****!<br><br>And what an unpredictable final four we have here as well! &gt;_&gt;<br><br>Yeah,
ok, I'm lying. This final four was very, very easy to call. All the top
seeds advanced to the elite eight, and all the number 1 seeds advanced
to the final four. BORING!<br><br>By the looks of things, we have one more match that could be interesting. This isn't it. Wait..... No, it isn't.<br><br>Metal
Gear is looking like the fourth strongest series in this contest, but
there is a huge gap between third and fourth. Zelda would be the
second, and there's a pretty wide gap between second and third as well.
Basically, there's a <i>huge</i> gap between second and fourth. Don't believe me? Let me show you it in a diagram.<br><br>Final
Fantasy (first) &gt; Legend of Zelda (second) &gt;&gt;&gt; Super Mario
Bros. (third) &gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt; Metal Gear
(fourth).<br><br>Need another diagram?<br><br><a class="linkification-ext" href="http://img207.imageshack.us/img207/1839/diagramme3.png" title="Linkification: http://img207.imageshack.us/img207/1839/diagramme3.png">http://img207.imageshack.us/img207/1839/diagramme3.png</a><br><br>Basically,
by my proof, it's quite apparent that Legend of Zelda will win this
match easily. What? You say you wanted a good match? Sorry bro/sis, but
you're looking at the wrong place. Come back in a couple of days.<br><br><b>My prediction: Legend of Zelda wins in a boring match. And LoZ does it with 68.79% of the vote. </b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/29/2006 10:05:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323585973">message detail</a>
 | #480</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>Yeah, we knew the Legend of Zelda was
going to SFF Metroid into the ground, but&#8230;we were kind of expecting to
be able to identify its remains, at the very least! Nearly 85% and over
114,000 individual votes? Overkill much? Yeah, that&#8217;s what I thought.
At this point, I&#8217;m starting to think that the Legend of Zelda derives
pleasure from making Metroid suffer because it does such a good job of
it. Either way, this has got to be one of the more impressive runs
we&#8217;ve seen in a contest. Never falling below 80% and breaking 100,000
individual votes in every match? Yeah, that speaks for itself. <br><br>Metal
Gear, on the other hand, was considered to be vulnerable to an upset
before the contest began, but it encountered very little resistance.
According to the divisional stats (for what little that&#8217;s worth. This
contest has a lot of oddities that don&#8217;t make sense), only Kingdom
Hearts and Castlevania are capable of even breaking 40% on Metal Gear.
From the looks of things, there are probably only two other series that
could beat it outside of the Big Three (Mega Man and Super Smash
Brothers), and even then, it wouldn&#8217;t be a given. <br><br>This match
is going to be an ugly one. Even in my wildest fanboy dreams, breaking
30% is about the most I can hope for. I believe that Metal Gear is the
fifth strongest series in this contest (and if it&#8217;s behind Mega Man,
it&#8217;s not by much), and I still believe that Final Fantasy is stronger
than the Legend of Zelda. Mega Man was able to avoid the tripling
against Final Fantasy (albeit barely), so I believe Metal Gear can
avoid the tripling here. It might be close, but I think it can manage
that much. The performance Super Smash Brothers put up on Super Mario
Brothers gives me a little more hope, though I&#8217;m more feeling that
shows that even Mario&#8217;s series isn&#8217;t on the same level as Final Fantasy
and the Legend of Zelda. <br><br><i>Leonhart&#8217;s Prediction</i>: <b>The Legend of Zelda with 69.69%</b><br> <br> <br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>In
terms of percentage beatdowns, we have not seen any entrant in contest
history as dominant as The Legend of Zelda. It has brought down the
hammer in each of its three matches, perfectly playing the role of an
unrelenting, merciless machine every single time. Seriously, <i>85%</i> on Metroid? WHAT THE **** IS THAT?<br><br>Of
course, there is a reason for Zelda's jaw dropping performances (other
than its own awesome strength). Not counting Civilization, which was
fodder, Zelda has been put in a pair of SFF matches. Mega Man X's main
power unquestionably comes from his SNES games, basically rendering it
a Nintendo series. Metroid, as we all know, has a very spotty history
when facing other Nintendo entities, and Zelda took advantage of that
very well. Metal Gear is a slightly different animal. As of now, it can
claim to be one of the five most popular series on GameFAQs, but more
importantly, it shares absolutely no fanbase overlap with Zelda (well,
none in the traditional SFF sense), so this will be the Legend of
Zelda's first match against a non-fodder, non-Nintendo entity. Will it
still win comfortably? Yes. Will it look as dominant as it has been the
past four weeks? No. Time to show us you're in this to win it all, Link!<br><br>The Legend of Zelda<br>+ Two of the four most popular games on the site<br>+ Many more popular games<br>+ The holy grail of Nintendo fans<br>+ SFF wrecking machine<br>+ Credibility up the wazoo<br>+ First three wins have been incredible<br>- None here<br><br>Metal Gear<br>+ Three very popular games in the last eight years<br>+ Tons of credibility and some old school influence<br>+ Spans a surprising amount of consoles and eras<br>- It's simply outclassed<br><br>My prediction: The Legend of Zelda def. Metal Gear (72-28)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/29/2006 10:05:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323586099">message detail</a>
 | #481</td></tr>
<tr class="even">
<td>
<b>HM&#8217;s Analysis</b><br><br><b>The Legend of Zelda</b><br><i>Previous Matches :</i><br><br>The Legend of Zelda &#8211; 89.97% -- 100,163<br>Civilization &#8211; 10.03% -- 11,169 <br><br>The Legend of Zelda &#8211; 80.32% -- 104,400<br>Mega Man X &#8211; 19.68% -- 25,577 <br><br>The Legend of Zelda &#8211; 84.7% -- 114,009<br>Metroid &#8211; 15.3% -- 20,595 <br><br><b>Metal Gear</b><br><i>Previous Matches :</i><br><br>Metal Gear &#8211; 69.89% -- 77,349<br>Soul Calibur &#8211; 30.11% -- 33,321 <br><br>Metal Gear &#8211; 65.23% -- 74,017<br>Fire Emblem &#8211; 34.77% -- 39,457 <br><br>Metal Gear &#8211; 58.31% -- 80,177<br>Kingdom Hearts &#8211; 41.69% -- 57,336 <br><br>Woohoo!
We&#8217;re finally at the end of the contest and the final four contestants
to make it are no surprise at all. However, even with the four
strongest series from each division making it out, this match <i>still</i>
isn&#8217;t going to be close, unfortunately. The Legend of Zelda has sported
an extremely impressive run by never falling under 80% and getting
100,000 in every single one of its matches. It looks absolutely
monstrous coming into this match. On the other hand, Metal Gear had a
pretty impressive run through its division too. My prediction of Metal
Gear never falling under 58% turned out to be true, which was great for
me, and it never once had any trouble with the competitors it faced. <br><br>Last
round, The Legend of Zelda pretty much dominated as expected. It was an
obvious match filled to the brim with SFF, which ended up making the
stats for this match look <i>really</i> funny when unadjusted.
Alongside the continued domination, Zelda also put up an impressive
114,000 individual votes, which I believe is a record. It seems to just
be picking up steam as we go along here. It will be very interesting to
see if it can once again put forth another 100,000 vote gain against
something like Metal Gear, which will have absolutely no SFF to speak
of in the match. <br><br>In the Snake Division, Metal Gear was able to
easily dispose of Kingdom Hearts. The upset that many felt was possible
before the contest began was crushed right off the bat when Metal Gear
put up 60%+ numbers. Not even with Metal Gear&#8217;s bad day vote could stop
that match from being ugly. The good thing about this match more than
anything was that Metal Gear&#8217;s hopes of snatching up that fourth
strongest series are still very well alive. Now, more than anything, we
get to see Metal Gear&#8217;s true strength against Zelda. There should be no
SFF, no strange occurrence, and no way to under perform. <br><br>The
most interesting thing about this match will be to see how well Metal
Gear can do. Depending on how well it does will determine where it sits
in the final stats. For Zelda, this match means trying to impress
enough to shock the masses and for everyone to start giving it a chance
against Final Fantasy in the finals. Personally, I have always felt
that Metal Gear stood a very good chance at avoiding the doubling here,
and I&#8217;m going to stick by that even now. <br><br>Metal Gear, to my
knowledge, has never gone up against something Zelda related. Solid
Snake has never faced Link in a contest before, Liquid Snake/Revolver
Ocelot never faced Ganondorf in the villains contest, and Metal Gear
Solid never faced Ocarina of Time. This should be the first encounter
between Metal Gear and Zelda. There should be absolutely no fanbase
overlap whatsoever between these two games either, making it even
better for Metal Gear since Zelda seems capable of SFFing anything it
has a slight relation to.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/29/2006 10:06:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323586222">message detail</a>
 | #482</td></tr>
<tr class="even">
<td>
Like I said before, the most important thing to me about this match is
seeing Metal Gear perform will enough to avoid a doubling. If it can do
that, I&#8217;ll be ecstatic considering it will have all but wrapped up the
fourth strongest series in this contest. It should get Metal Gear some
more respect among people here, too, since we have some lamers who
think Kingdom Hearts stood a chance (HAW HAW). Besides, this is only
the beginning &#8230; 2007 &#8230; Believe &#8230; Solid Snake &gt; Link &#8230; <br><br><b>Aitch Emm&#8217;s Bracket :</b> The Legend of Zelda<br><br><b>Aitch Emm&#8217;s Prediction :</b> The Legend of Zelda &#8211; 65.2% ; Metal Gear &#8211; 34.8%<br><br><b>Aitch Emm&#8217;s Vote :</b> Metal Gear<br> <br> <br><br><b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: Hyrule Temple (SSBM)<br><br>Busy
as usual, so another quick one. I think Metal Gear will probably be at
its strongest against Zelda. For some reason, I think Metal Gear does
pretty well against Nintendo since the fanbase are about as separate as
you can get. The NES games and Twin Snakes aside, Metal Gear is pretty
much a Playstation brand, and the majority of its fanbase comes <i>from</i>
the Playstation games. To clarify that, Metal Gear is rooted into
Playstation the same way that Mega Man is rooted into Nintendo. There
may be games on other platforms, but the roots of the fanbase comes
from Nintendo/Playstation. <br><br>Anyways, in Snake's last true test,
he performed really well on Mario and got his highest x-stats value.
Look for Metal Gear to stand up to the challenge. Sure it is going to
get killed, but it will do it in a respectable manner. I wouldn't be
surprised if Metal Gear breaks 30%, although asking for much more will
be rather optimistic. Zelda has still been a monster in this contest,
so Metal Gear better be wary.<br><br>Bracket: Legend of Zelda<br>Vote: Legend of Zelda<br>Prediction: Legend of Zelda with 72.65%<br><br> <br><br><b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Legend of Zelda<br>Earlier this contest:<br>---LoZ - 89.97% on Civilization, 80.32% on Mega Man X, 84.7% on Metroid<br>---MG - 69.89% against Soul Calibur, 65.23% on Fire Emblem, 58.31% on Kingdom Hearts<br>Top 100 List comparison:<br>---LoZ:OoT - #2, LoZ:LttP - #4, LoZ - #30, LoZ:WW - #45, LoZ:MM - #46<br>---MGS - #8, MGS3 - #21, MGS2 - #41<br>Best Game Ever x-stat comparison:<br>---LoZ:OoT
- 46.18% (32-64 Division runner-up), LoZ:LttP - 41.61% (16 Division
runner-up), LoZ:WW - 37.29% (was behind Starcraft), LoZ - 34.49% (8
Divison runner-up)<br>---MGS2 - 32.52% , MGS - 28.7% (may have been SFF'd by FF7), MG - 14.13%<br><br>Huzzah
for the Final Four, where we can finally get our best ideas possible on
LoZ/FF before it actually happens. That said, I'm tired and I want to
finish off this analysis...so check this: Link &gt; Solid Snake, Zelda
gets 45% on Solid, Ganon is arguably the most likely to upset Solid,
LoZ's biggest game getting 46.18% against FF7 &gt; MG's biggest game
getting 28.7% on FF7, LoZ:WW would be able to compete with or beat MGS2
or MGS3, the original LoZ would beat the ever-loving hell out of the
original MG games (pre-MGS) and it very well could beat MGS2 or MGS3.
LoZ has two games in the top five of the Top 100 List while MGS had one
game in the top twenty (though I bet MGS3 would have broke in now that
MGS3:S is out, being #21 and all), any LoZ match has been more
impressive than any MG match, and Nintendo &gt; Konami here. Enjoy the
match, MG -- you deserved to barely lose to SMB in the championship
this contest.....<br><br>Legend of Zelda wins with 67.12%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/29/2006 10:07:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323586533">message detail</a>
 | #483</td></tr>
<tr class="even">
<td>
<b>Lopen&#8217;s Analysis</b><br> <br>Zelda's track record: Fodder-&gt;Sorta
SFF Match-&gt;Hardcore SFF Match. Tough road, I know. Now we finally
get to see how powerful it really is. Will it win? Of course it'll win!
(Prove me wrong, please!) I'm just going to try and track a percentage,
here. No no&#8230; don't worry, I'm going to go off on a tangent about Mega
Man first!<br><br>Alright, so before the contest, I was thinking that
Mega Man just might be a more popular series than Metal Gear here&#8230; I
mean Mega Man firmly beats Snake every time, right? I still think
that's possible right now&#8230; Mega Man didn't <i>totally</i> collapse
against the evil FF. And Metal Gear might've done better on KH (because
I'm pretty sure KH would beat Mario Kart) than it should've because of
a less severe case of the ole Snake/Sora fishiness. Metal Gear fans
like their RPGs, what can I say?<br><br>Fear not! I'm going somewhere with this&#8230; analogy time! Final Fantasy : Mega Man <b>::</b> (Legend of Zelda + 8) : Metal Gear. Whaddaya mean "Legend of Zelda + 8" doesn't make sense? Work on your Maths, kid.<br><br><b>Lopen's Prediction:</b> Legend of Zelda with 66.50%<br> <br> <br> <br>Comments: Metal Gear doesn't get doubled = screwed LoZ<br>Metal Gear doesn't get tripled  = screwed FF<br>Metal Gear falls in between = Just right</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1288566&amp;board=8&amp;topic=29209811" class="name">gtonizuka49</a> |
Posted 7/29/2006 10:17:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323588698">message detail</a>
 | #484</td></tr>
<tr class="even">
<td>
Ulti - 73.33<br>mnm - 72.65<br>yo - 72.00<br>Leon - 69.69<br>Soul - 68.79<br>Moltar - 68.00<br>HaRR - 67.12<br>Lopen - 66.50<br>HM - 65.20<br><br>I've got 1.47% to work with. Make it happen, Zelda!<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=993802&amp;board=8&amp;topic=29209811" class="name">Sir Crono</a> |
Posted 7/29/2006 10:18:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323588939">message detail</a>
 | #485</td></tr>
<tr class="even">
<td>
Here's hoping Zelda hovers right around but doesn't quite cross 70%.<br><br>Though as a Metal Gear fanboy, I hope Heroic Mario's right.<br>---<br>As you wish.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1288566&amp;board=8&amp;topic=29209811" class="name">gtonizuka49</a> |
Posted 7/30/2006 12:11:18 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323615509">message detail</a>
 | #486</td></tr>
<tr class="even">
<td>
Final Fantasy vs. Resident Evil<br>+9 Ulti<br>+8 HaRRicH<br>+7 mnm (tie)<br>+7  Moltar (tie)<br>+5 Leon<br>+4 HM<br>+3 yo<br>+2 Lopen<br>+1 Soul<br><br><b>The Rankings</b> (Through Super Mario Bros./Super Smash Bros.)<br>1. Master Moltar (128)<br>2. yoblazer33 (123)<br>3. XxSoulxX (110)<br>4. UltimaterializerX (108)<br>5. Leonhart (103)<br>6. therealmnm (100)<br>7. Heroic Mario (93)<br>8. HaRRicH (84)<br>9. Lopen (75)<br><br>Had Final Fantasy finished 00.01% higher, HaRRicH would have gotten the top spot.<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=993802&amp;board=8&amp;topic=29209811" class="name">Sir Crono</a> |
Posted 7/30/2006 12:12:26 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323615773">message detail</a>
 | #487</td></tr>
<tr class="even">
<td>
Ulti's looking good to take this one, too, considering Metal Gear's day vote history.<br><br>Though the odd thing is...Zelda's percentages have been oddly stable in every match.<br>---<br>As you wish.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2562507&amp;board=8&amp;topic=29209811" class="name">H__RR____H</a> |
Posted 7/30/2006 2:06:21 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323635263">message detail</a>
 | #488</td></tr>
<tr class="even">
<td>
<i>Had Final Fantasy finished 00.01% higher, HaRRicH would have gotten the top spot.</i><br><br>**** you, FF.<br>---<br><i>Damn, most of my dates involve mocking and/or beating up people like you and your bride-to-be, so I really have no advice</i> --Horatio</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29209811" class="name">Lugia2</a> |
Posted 7/30/2006 9:17:10 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323667257">message detail</a>
 | #489</td></tr>
<tr class="even">
<td>
Zelda is on 71% now...There goes the "No doubling" predictions. Oh
well. Doesn't guarantee a LoZ&gt;FF either. Maybe we can read the tea
leaves of the SMB+FF match.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/30/2006 11:48:51 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323686467">message detail</a>
 | #490</td></tr>
<tr class="even">
<td>
Final Fantasy.............76.06% 103552<br>Resident Evil..............23.94% 32602<br>TOTAL VOTES........................136154<br><br>87.42% of the brackets predicted this match correctly.<br><br>As
predicted, Resident Evil ends up looking weaker than Mega Man. Final
Fantasy triples it easily and once again garners over 100K votes.<br><br>Today, Legend of Zelda is putting up an impressive performance on Metal Gear.<br><br>Soul - 5<br>Ulti - 3<br>Leon - 3<br>Yoblazer - 3<br>Lopen - 3<br>HaRRich - 3<br>Moltar - 3<br>Mnm - 2<br>HM - 2<br><br>Ulti gets the point and joins the rest of the people with 3.<br>---<br>Moltar Status: Wanting you to <b>Nominate Shadow the Hedgehog!</b><br>Legend of Zelda vs. Metal Gear - Bracket: <b>LoZ</b> - Vote: <b>MG</b> (46/48)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/30/2006 2:12:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323713288">message detail</a>
 | #491</td></tr>
<tr class="even">
<td>
Now that I'm sober and home, I apologize about my rude comment to FF --
it was uncalled for, and overly harsh. Therefore, let me retry this.
Ahem...<br><br><br><br>...<b>**** you, Final Fantasy.</b><br><br>u can teli meen it by the b-tags m i rite<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1288566&amp;board=8&amp;topic=29209811" class="name">gtonizuka49</a> |
Posted 7/30/2006 7:43:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323785913">message detail</a>
 | #492</td></tr>
<tr class="even">
<td>
The Legend of Zelda vs. Metal Gear<br>+9 Ulti<br>+8 mnm<br>+7 yo<br>+6 Leon<br>+5 Soul<br>+4 Moltar<br>+3 HaRRicH<br>+2 Lopen<br>+1 HM<br><br><b>The Rankings</b> (Through The Legend of Zelda/Metal Gear)<br>1. Master Moltar (132)<br>2. yoblazer33 (130)<br>3. UltimaterializerX (117)<br>4. XxSoulxX (115)<br>5. Leonhart (109)<br>6. therealmnm (108)<br>7. Heroic Mario (94)<br>8. HaRRicH (87)<br>9. Lopen (77)<br><br>One
might say that it's now a two-horse race for the top spot, but Ulti's
really been on fire lately, so nothing is certain. Plus, with this
great performance by Zelda, we might get an Analysis Crew split for the
final match.<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=993802&amp;board=8&amp;topic=29209811" class="name">Sir Crono</a> |
Posted 7/30/2006 8:10:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323792317">message detail</a>
 | #493</td></tr>
<tr class="even">
<td>
I can still get 3rd, I can still get 3rd.<br>---<br>As you wish.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/30/2006 8:59:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323804703">message detail</a>
 | #494</td></tr>
<tr class="even">
<td>
New topic is up, so you can just get this to 500...if you want.<br>---<br>Moltar Status: Wanting you to <b>Nominate Shadow the Hedgehog!</b><br>Legend of Zelda vs. Metal Gear - Bracket: <b>LoZ</b> - Vote: <b>MG</b> (46/48)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/30/2006 9:01:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323805049">message detail</a>
 | #495</td></tr>
<tr class="even">
<td>
500?<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>stingers, Rad, longblade, and Ryoko owned me in a sig bet and all I got was this lousy T-Shirt</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/30/2006 9:01:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323805130">message detail</a>
 | #496</td></tr>
<tr class="even">
<td>
LoZ &gt; FF<br><br>Book it.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>stingers, Rad, longblade, and Ryoko owned me in a sig bet and all I got was this lousy T-Shirt</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3662060&amp;board=8&amp;topic=29209811" class="name">YoAriel33</a> |
Posted 7/30/2006 9:02:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323805309">message detail</a>
 | #497</td></tr>
<tr class="even">
<td>
Ariel &gt; Snake<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=993802&amp;board=8&amp;topic=29209811" class="name">Sir Crono</a> |
Posted 7/30/2006 9:02:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323805328">message detail</a>
 | #498</td></tr>
<tr class="even">
<td>
Leonhart &gt; Soul <br><br>Book it.<br>---<br>As you wish.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2303557&amp;board=8&amp;topic=29209811" class="name">FlamboyantSpy</a> |
Posted 7/30/2006 9:02:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323805371">message detail</a>
 | #499</td></tr>
<tr class="even">
<td>
EC &gt; SOWL<br><br>---<br><b>Explicit Content</b><br>Cheer Up Emo Kids - Team Tranny Did!</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=993802&amp;board=8&amp;topic=29209811" class="name">Sir Crono</a> |
Posted 7/30/2006 9:02:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=323805421">message detail</a>
 | #500</td></tr>
<tr class="even">
<td>
Jack Sparrow &gt; Ariel<br>---<br>As you wish.</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">1</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=1">2</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=2">3</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=3">4</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=4">5</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=5">6</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=6">7</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=7">8</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=8">9</a></li>
<li>      10</li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage10_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29209811&amp;page=9" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage10_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>