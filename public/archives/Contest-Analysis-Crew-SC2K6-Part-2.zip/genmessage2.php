<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">

<title>GameFAQs: Message List</title><link rel="stylesheet" type="text/css" href="genmessage2_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage2_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage2_files/bc.css"></head><body linkifytime="370" linkified="6" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage2_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage2_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29209811%26page%3D1"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<a href="http://adlog.com.com/adlog/c/r=10153&amp;s=668272&amp;t=2006.07.30.22.05.23&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=00c17-gne-ad144C8F19B1597092/http://www.gamespot.com/pc/action/kingkong/index.html" target="_blank"><img src="genmessage2_files/kingkong_buyit_leader.jpeg" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage2_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew - Part 2</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29209811&amp;page=1">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29209811" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">First
          Page</a> |
          Page 2 of 10          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=2">Next
          Page</a>
          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=9">Last
          Page</a>
      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/13/2006 4:04:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319495216">message detail</a>
 | #051</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>Diablo really got a raw deal in this
contest. It could&#8217;ve done some damage if it had received some better
seeding, but alas, that is not the case. Now it basically becomes the
first step on the road to Final Fantasy&#8217;s championship. The series
should at least do respectably here for what you would normally expect
out of an 8 seed, but as far as being competitive, forget it. No knock
on Diablo, since not many series could be competitive against Final
Fantasy.<br><br>In these contests, we&#8217;ve only seen Diablo the
character. In the Villains Contest, he took advantage of the weak
competition to make a run to the Final Four before getting destroyed by
Ganondorf. He returned in the Summer Contest, where he had a lackluster
win over Kratos Aurion before getting ripped apart even harder by Sonic
the Hedgehog. However, this is Blizzard we&#8217;re dealing with, and the
Diablo series has its fair share of rabid followers. While it may not
be as popular as StarCraft (though who knows, Diablo II placed 20th on
the Top 100 List, only two spots below StarCraft), it&#8217;ll be a strong
series, which once again upsets me that it got such poor seeding and a
bad draw.<br><br>Of course, Final Fantasy needs no introduction.
GameFAQs was basically founded upon Final Fantasy VII, and it&#8217;s still
proven to be the site&#8217;s most popular game even to this day. On a couple
of instances, it has been shown that perhaps one-fourth of the site
considers it to be their favorite game ever, a ridiculous statistic,
especially when you realize that 75% of the site has played it. That&#8217;s
essentially saying that one out of every three people on GameFAQs who
have played Final Fantasy VII think it&#8217;s the best game ever. Sure,
there are some minor issues with such a statistic, but the point of its
massive popularity cannot be questioned even so.<br><br>Final Fantasy
VII is already the site&#8217;s most popular game, so how much stronger can
it get when you add the rest of the series on top of it? Well, that&#8217;s
what we&#8217;re about to find out. This should probably be the strongest
entry we have ever seen (and probably ever will see) in any contest.
The Final Fantasy name carries power. On the GameFAQs Top 100 List, we
have FIVE games from the series in the top 20 (counting Final Fantasy
Tactics), seven in the top 50, and nine overall (counting Final Fantasy
Tactics Advance). Basically, every major release since the series moved
over to the Playstation made the list, except for Final Fantasy X-2,
Final Fantasy XI, and Final Fantasy: Crystal Chronicles (I&#8217;m not
including the ports and re-releases of the older games, though Final
Fantasy I and Final Fantasy IV both made the list as well). Basically,
the series is really popular, as if you needed me to tell you that.
This match is essentially going to be trying to show up the Legend of
Zelda&#8217;s first round performance. It&#8217;ll be ugly.<br><br><i>Leonhart&#8217;s Prediction:</i> <b>Final Fantasy with 76.90%</b><br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>What
a waste&#8230; what a waste. My heart's just not in this match. Diablo's not
a fodder series, it's not! But it's getting fed to Final Fantasy, and
Final Fantasy's not a picky eater, it has an appetite for fodder and
non fodder alike. Final Fantasy consumes all series, big and small. It
is tyrannous, and evil&#8230; all but a lock to win the contest. Diablo <i>will</i>
do better than we expect considering the opponent, Diablo's fairly
popular here. But man, it's facing Final Fantasy! This is totally
unfair! That's all I have to say!<br><br><b>Lopen's Prediction:</b> Final Fantasy with 71.66%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/13/2006 4:05:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319495432">message detail</a>
 | #052</td></tr>
<tr class="even">
<td>
<b>HM&#8217;s Analysis</b><br> <br>Final Fantasy &#8211; AKA &#8220;The Champion&#8221; &#8211;
begins its road the championship with an easy match against Diablo. It
would seem that Blizzard entries can&#8217;t seem to get any luck this year
because both of them are up against considerably stronger series.
That&#8217;s right, Blizzard Burned People, there is no sense in bringing up
your silly rallies or united community when you&#8217;re up against a beast
like Final Fantasy. <br><br>This match should be an absolute breeze
for the series holding GameFAQs&#8217; favorite game. Diablo is certainly a
strong series that deserved better than an 8 seed, but it still won&#8217;t
stop it from getting absolutely pummeled in this match-up. A doubling
in this match is guaranteed, but a tripling won&#8217;t quite happen. Even
with Final Fantasy&#8217;s power, Diablo is still not something that will get
<i>completely</i> wasted like that. <br><br>So yeah, this match is just
a stepping stone for Final Fantasy, as steamrolls the division and the
entire contest. But when you combine Final Fantasy VII, Final Fantasy
VI, Final Fantasy X, and Final Fantasy VIII all together &#8211; along with
others &#8211; what do you expect? Heh.<br><br><b>Aitch Emm&#8217;s Bracket Says :</b> Final Fantasy will win.<br><br><b>Aitch Emm&#8217;s Prediction :</b> Final Fantasy 70% -- Diablo 30%<br><br><b>Aitch Emm&#8217;s Vote :</b> Final Fantasy.<br><br><br><br><b>Yoblazer&#8217;s Analysis</b><br> <br>And
here we have it: the overwhelming tournament favorite is finally set to
take center stage. This is Final Fantasy's first opportunity to prove
that it deserves its kingly status, and unlike the other two members of
the Big Three, it's actually up against a legitimate series. Will the
1-seed's opening performance rival that of Zelda and Mario's blistering
starts, or can Diablo cause some people to second guess the
all-but-guaranteed Final Fantasy contest win?<br><br>My money is on
Final Fantasy to impress. As we have already seen, voters are favoring
the older, more established series, and on GameFAQs, it's hard to find
anything more established than Square's premier RPG series. Final
Fantasy has all sorts of powerful weapons at its disposal. Most
importantly, of course, is the GameFAQs trump card: Final Fantasy VII.
This influential RPG has been our most popular game for nine years, and
fans always vote for it in droves. Also, this will mark the first time
that Final Fantasy VIII and IX, Square's other two million-sellers for
the original Playstation, will be allowed some sort of non-character
contest representation. In addition, Final Fantasy has FFVI and FFX.
These are two of the most popular games from their respective
generations, and they should do a great job of garnering votes from
both the old school and newer fans. As if that weren't enough, there
are tons of other Final Fantasy games, from the old to the new, from
the console realm to the handheld realm, and all of them will be
bringing additional power for the mother series to draw from.<br><br>Let's
not make the mistake of assuming Diablo is fodder; it almost certainly
is not. Diablo 2 has a massive Internet fanbase, and Diablo himself has
done pretty well in his contest appearances. Also, I'm writing this a
few hours after GTA/Warcraft, so we just saw a Blizzard series surprise
the hell out of most of us. That shows me that Diablo has, if nothing
more, the definite potential to win a match in this contest. Sadly,
that potential will not be realized.<br><br>Final Fantasy<br>+ Strongest game on this site<br>+ Several other very popular games<br>+ Spans several consoles and eras<br>+ It's the backbone of GameFAQs<br>+ Credibility up the wazoo<br>- Won't blow out fodder as effectively as Zelda or Mario, but that's hardly a big deal<br><br>Diablo<br>+ Solid Internet fanbase<br>+ Blizzard!!!!!<br>+ Diablo the character has a decent contest history<br>- None of that matters<br><br>My prediction: Final Fantasy def. Diablo (79-21)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/13/2006 4:06:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319495621">message detail</a>
 | #053</td></tr>
<tr class="even">
<td>
<b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Final Fantasy<br>Top 100 List comparison:<br>---FF7 - #1, FF3/6 - #10, FFX - #12, FF8 - #17, FFT - #19, FF9 - #42, FF2/4 - #50, FF - #76, FFTA - #89<br>---Diablo 2 - #20<br>Best Game Ever x-stat comparison:<br>---FF7
- 50% (Best. Game. Ever. champion), FF3/6 - 39.4%, FFX - 36.86%, FF -
32.24%, FFT - 28.69% (was behind FF7/MGS), FFTA - 24.27% (SFF'd by FFX)<br>---Diablo - N/A (no rep)<br><br>Don't even bother telling me I shouldn't add the FFT games to FF's credit, by the way, unless you like acid in your pants.<br><br>I'll
go ahead and point out that FF is the big favorite of the contest, and
we have already seen in two different ways that FF7 is this site's
favorite game. Cloud was GameFAQs's favorite character in 2003, the
year KH was released, and we've seen both KH2 and FF:AC be released in
America this year. #1+#10+#12+#17+#19 &gt; #20 and Starcraft &gt;
Diablo 2, according to the Top 100 List. Diablo 2 is almost certainly
where most of Diablo's strength will come from, whereas FF can still
survive nicely without FF7 (and FF7 easily beats Diablo). Diablo's
shown that rallying for Diablo (the character) isn't particularly
strong, though it's something to watch out for when it's facing
opponents with a common strength...<br><br>...the FF series
&gt;&gt;&gt;&gt;&gt; M. Bison, however, and thus it is so that Diablo
will have no successful under-dog run this contest.<br><br>Final Fantasy wins with 70.12%<br><br>Diablo<br>+ Solid Internet fanbase<br>+ Blizzard!!!!!<br>+ Diablo the character has a decent contest history<br>- None of that matters<br><br>My prediction: Final Fantasy def. Diablo (79-21)<br><br><br>Comments: We all have Final Fantasy beating Diablo, but interesting that all our percentages land in between 70 and 79%.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/13/2006 4:11:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319496851">message detail</a>
 | #054</td></tr>
<tr class="even">
<td>
Crap, boxed in.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1264709&amp;board=8&amp;topic=29209811" class="name">LoopZoopTheBest</a> |
Posted 7/13/2006 4:14:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319497517">message detail</a>
 | #055</td></tr>
<tr class="even">
<td>
Thank the gods HaRRicH didn't pick 79.12%.<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/13/2006 7:37:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319545986">message detail</a>
 | #056</td></tr>
<tr class="even">
<td>
HaRRicH got a double prediction, AND he plagiarized yoblazer!<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1264709&amp;board=8&amp;topic=29209811" class="name">LoopZoopTheBest</a> |
Posted 7/13/2006 8:55:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319564628">message detail</a>
 | #057</td></tr>
<tr class="even">
<td>
Wait a minute... HE DID!!!!<br><br>HARRICH. EXPLAIN YOURSELF.<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/13/2006 9:11:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319568270">message detail</a>
 | #058</td></tr>
<tr class="even">
<td>
<i>Diablo<br>+ Solid Internet fanbase<br>+ Blizzard!!!!!<br>+ Diablo the character has a decent contest history<br>- None of that matters<br><br>My prediction: Final Fantasy def. Diablo (79-21)</i><br><br><br>Just
so there's no confusion, that's not a part of my analysis. That
said...I like yo's prediction better than mine. Damn me and my refusal
to edit my picks each round once the round starts!<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29209811" class="name">THEJackSparrow</a> |
Posted 7/13/2006 9:13:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319568739">message detail</a>
 | #059</td></tr>
<tr class="even">
<td>
<i>Just so there's no confusion, that's not a part of my analysis</i><br><br>Of course it's <i>easy</i> to admit to plagiarism after you've already been caught!<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/13/2006 9:16:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319569581">message detail</a>
 | #060</td></tr>
<tr class="even">
<td>
Yes, blame HaRRich. Meanwhile, I'll just casually sneak out the backdoor and run<i>!!</i><br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Super Smash Bros. vs. Dragon Quest - Bracket: <b>SSB</b> - Vote: <b>SSB</b> (9/11)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29209811" class="name">therealmnm</a> |
Posted 7/13/2006 9:59:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319580475">message detail</a>
 | #061</td></tr>
<tr class="even">
<td>
Basically, with Final Fantast most likely winning the contest...
Whatever percentage Diablo gets will be its x-stat value. I'm kinda
surprised at those 21% predictions for Diablo. You think the gap
between Final Fantasy and the rest of the field is THAT large where
strong midcard series will be in the 20-22% range?<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1264709&amp;board=8&amp;topic=29209811" class="name">LoopZoopTheBest</a> |
Posted 7/13/2006 11:33:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319603664">message detail</a>
 | #062</td></tr>
<tr class="even">
<td>
Super Smash Bros. vs. Dragon Quest<br>+9 Soul<br>+8 Lopen<br>+7 mnm (tie - unbelievable)<br>+7 Moltar (tie - unbelievable)<br>+5 Ulti<br>+4 Leon<br>+3 HM (tie)<br>+3 yo (tie)<br>+1 HaRRicH<br><br><b>The Rankings</b> (Through Super Smash Bros./Dragon Quest)<br>1. Master Moltar (51)<br>2. XxSoulxX (48)<br>3. yoblazer33 (42)<br>4. UltimaterializerX (40)<br>5. therealmnm (39)<br>6. HaRRicH (38)<br>7. Leonhart (36)<br>8. Lopen (33)<br>9. Heroic Mario (32)<br><br>Looks like Moltar and Soul have separated themselves from the pack a bit.<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/13/2006 11:33:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319603804">message detail</a>
 | #063</td></tr>
<tr class="even">
<td>
<i>You think the gap between Final Fantasy and the rest of the field is
THAT large where strong midcard series will be in the 20-22% range?</i><br><br>*looks at the poll*<br><br>Yep.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/13/2006 11:36:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319604411">message detail</a>
 | #064</td></tr>
<tr class="even">
<td>
yoblazer - 79%<br>Moltar - 77%<br>Leonhart - 76.90%<br>Soul - 76.42%<br>Ulti - 75.24%<br>Lopen - 71.66%<br>mnm - 71.05%<br>HaRRicH - 70.12%<br>Heroic Mario - 70%<br><br><br>Yeah, go ahead and give this point to yoblazer.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/13/2006 11:37:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319604596">message detail</a>
 | #065</td></tr>
<tr class="even">
<td>
Ouch. Boxed. Double boxed.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=829368&amp;board=8&amp;topic=29209811" class="name">Tai</a> |
Posted 7/13/2006 11:37:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319604733">message detail</a>
 | #066</td></tr>
<tr class="even">
<td>
tag<br>---<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=579987" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=579987">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=579987</a> - Wanna report a TOS violation! Go to Snack Attack and we can help!</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1264709&amp;board=8&amp;topic=29209811" class="name">LoopZoopTheBest</a> |
Posted 7/13/2006 11:39:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319605030">message detail</a>
 | #067</td></tr>
<tr class="even">
<td>
Doubt you'll have to worry about that second box, Soul. Ho-lee...<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/13/2006 11:39:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319605144">message detail</a>
 | #068</td></tr>
<tr class="even">
<td>
Man, I'll have gone from first to seventh by the end of this match.  Oh, how the mighty have fallen...<br><br><br><br>...<b>BUT I GET UP AGAIN -- YOU'RE NEVER GONNA KEEP ME DOWN <i>!!</i></b><br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=46088&amp;board=8&amp;topic=29209811" class="name">therealmnm</a> |
Posted 7/13/2006 11:41:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319605597">message detail</a>
 | #069</td></tr>
<tr class="even">
<td>
O_O at FF.  Too bad I'm simply not into RPGs as much as I used to be... Otherwise, I'd be extremely happy right now.<br>---<br><b>Nominate Carmen Sandiego for SC2k6</b><br>Currently playing: Fable, MGS3:S, GTA:SA, MMAC</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/13/2006 11:43:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319606058">message detail</a>
 | #070</td></tr>
<tr class="even">
<td>
FF officially won this Contest on it's first update.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Final Fantasy vs. Diablo - Bracket: <b>FF</b> - Vote: <b>FF</b> (10/12)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/14/2006 12:10:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319693827">message detail</a>
 | #071</td></tr>
<tr class="even">
<td>
Super Smash Bros......76.37% 90789<br>Dragon Quest.............23.63% 28092<br>TOTAL VOTES.........................118881<br> <br>81.25% of the brackets predicted this match correctly.<br><br>SSB
does a bit better than most expected by tripling Dragon Quest. We
thought its name might carry a little more weight around here, but I
guess not.<br><br>Today, Final Fantasy is making Diablo look like Grade-A Fodder. Just wow...<br><br>Soul - 3<br>Moltar - 2<br>HaRRich - 2<br>HM - 2<br>Leon - 1<br>Ulti - 1<br>Yoblazer - 0<br>Mnm - 0<br><br>Soul is on fire. Two points in two days.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Final Fantasy vs. Diablo - Bracket: <b>FF</b> - Vote: <b>FF</b> (10/12)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/14/2006 3:23:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319738667">message detail</a>
 | #072</td></tr>
<tr class="even">
<td>
I have a feeling I'm going to get boxed in again for MM/MK.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/14/2006 3:27:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319739709">message detail</a>
 | #073</td></tr>
<tr class="even">
<td>
I'll be <i>very</i> surprised if I get boxed in on this next one.  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=758581&amp;board=8&amp;topic=29209811" class="name">steve illumina</a> |
Posted 7/14/2006 3:30:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319740432">message detail</a>
 | #074</td></tr>
<tr class="even">
<td>
I am SO joining this crew next contest...my credentials speak for themselves :)  Good stuff, keep it up.<br>---<br><b>Steve Illumina: Sage of Board 8, Hated by Fanbabies, Loved by the Masses.<br>Score: 13-0. Next Win: Mega Man!</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/14/2006 3:32:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319741013">message detail</a>
 | #075</td></tr>
<tr class="even">
<td>
Well, you don't have to be <i>good</i> at contests to be a Crew member, just look at me... er... I mean... just look at Leonhart!  <br><br>You're <i>so</i> going down on KH/Castlevania, Steve-o!  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/14/2006 3:33:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319741256">message detail</a>
 | #076</td></tr>
<tr class="even">
<td>
Psh, Lopen, you're so bad that Moltar doesn't even acknowledge you on the scoreboard anymore!<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/14/2006 3:44:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319743614">message detail</a>
 | #077</td></tr>
<tr class="even">
<td>
While I'm thinking about it...Moltar, raise my LoZ/MMX prediction by 5%.<br><br>I was going to wait until this match to decide my Mario/Warcraft percentage, but...I still don't know where to lean.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=407155&amp;board=8&amp;topic=29209811" class="name">charmander6000</a> |
Posted 7/14/2006 6:55:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319785855">message detail</a>
 | #078</td></tr>
<tr class="even">
<td>
<i>From: steve illumina<br>I am SO joining this crew next contest...my credentials speak for themselves :) Good stuff, keep it up.<br><br>From: Lopen <br>Well, you don't have to be good at contests to be a Crew member, just look at me... er... I mean... just look at Leonhart! </i><br><br>Tell me about it I've already beaten the Analysis Crew 3 times (including today). /bragging<br><br>Fire Emblem vs. Silent Hill<br>Kingdom Hearts vs. Harvest Moon<br>Final Fantasy vs. Diablo<br>---<br>"I was trying to escape. Obviously, it didn't work." - President Bush</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/14/2006 7:22:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319791883">message detail</a>
 | #079</td></tr>
<tr class="even">
<td>
<b>Ultima Division:</b> <i>Round 1 - Match 14</i> &#8211; (4)Mega Man vs. (5)Mario Kart <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Mega Man</b><br>No,
not the X series. This is the Classic Mega Man series. This is the Mega
Man that we always see in match pics. There&#8217;s a Mega Man 8, and also a
bunch of spin-off series and whatnot keeping the Blue Bomber alive.<br> <br><b>Mario Kart</b><br>The
Mario Kart series is one of my favorite Mario spin-off series. Mario
Kart DS was recent released, joining the ranks of the other popular
Mario Kart games such as 64 and Super Circuit.<br><br><b>MATCH OF ROUND 1 RIGHT HERE FOLKS!!</b><br><br>Alright,
when I first saw this match in the bracket, I didn&#8217;t think much of it.
Mega Man wins, move on to the next match. However, once I saw people
confused over this match, I decided to take a second look. I then saw
what was so hard about this match, and that I couldn&#8217;t just count out
the Mario Kart franchise because, well, it&#8217;s huge.<br><br>Mario Kart
has had a presence on pretty much all of Nintendo&#8217;s big consoles. They
also sell very well and are looked at as fun games. Mario Kart 64,
Double Dash, and even the handheld ones like Super Circuit and DS are
hits. Behind the SSB series, Mario Kart could be the next strongest
Mario spin-off. Also like SSB, most Mario fans like the series. You&#8217;d
be hard-pressed to find a group of people that like the Mario series,
but hate Mario Kart (lol Ulti), so definitely expect it to show some
strength.<br><br>Then on the other hand, there&#8217;s Mega Man. Now, if you
ask most people who picked Mega Man why they did, they&#8217;ll either
respond with something like, &#8220;Well, Mega Man does well in the Contests,
and he has to draw his strength from somewhere, right?&#8221; or &#8220;If all the
Mega Man fans, X included, vote for the Classic series, it&#8217;s sure to
win.&#8221; There&#8217;s something wrong with that though. Since Mega Man X is
it&#8217;s own entry, would fans be picky enough to vote for the X series,
but not the Classic? Or perhaps vote the X series over Mario Kart, but
Mario Kart over the Classic series.<br><br>However, since the Contest
has started, a better argument could be built for Mega Man. We saw with
Castlevania that a series that is older and has spanned on several
consoles fares better over a new, very popular series. Of course, Mario
Kart is no Halo, but the Mega Man series is older and has more games to
draw its strength from.<br><br>What I&#8217;m saying is, Mario Kart is
strong, and Mega Man is most likely going to need the backing of the
whole Mega Man franchise to win. Will he get all that backing? My
bracket says yes, but I&#8217;m not sure myself. This is the one match where
I&#8217;m not confident in either side, but I&#8217;m going to stick with my guns
and say Mega Man will win in a close one. <br><br><b>Moltar&#8217;s Bracket Says:</b> Mega Man will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Mega Man: 51% - Mario Kart: 49%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>I
fear this match for two reasons. One, this "Mario Kart is a side
series" BS is nonsense. Mario Kart has a very real chance at winning
this thing. But on the other end, a killing by Mega Man may mean that
Sonic is due to destroy Smash Brothers. This is one of those "tread
lightly" deals, and this match has me torn on Sonic/Smash more than
Sonic/Smash itself does. At any rate...<br><br>I'm sure other Crew
members have eons of text and stats about why they think their pick
will win, but I'm taking the much simpler route. The name "Mega Man" is
going to encompass every single one of Mega Man's games with voters. No
one is going to go "Zomg MMX is in the contest this isn't a part of teh
Mega Man lolzorz". Mario Kart is going to be damn strong, but I think
Mega Man will be stronger. If Mega Man can avoid potential Nintendo
SFF, it should win this. It might even win it easily.<br><br>Prediction: MM with 56.25%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/14/2006 7:23:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319792003">message detail</a>
 | #080</td></tr>
<tr class="even">
<td>
<b>Soul&#8217;s Analysis</b><br> <br>Here we go. The big round 1 match. Hell, probably the biggest match in the contest.<br><br>Mega
Man is legendary, no doubt about that. I believe the character has
appeared in more games then anyone else. He has a huge repetoire of
games at his disposal, along with many different features and weapons.
He is also part of the noble nine, which means that the character is
very strong. We've never seen any Mega Man game in any contest, and
that's mostly because the fanbase can't decide which one to rally for.<br><br>Mario
Kart is different. It is Mario's third biggest series (after the
platformer and SSB). It also has had no representation in the games
contest, although many predict that any of the MK games could be pretty
strong.<br><br>So basically, this looks like a very good match, but
Mega Man should win it. Well, I don't believe that. Sure, it is going
to be a good match. Maybe even great. But the fact is, I think that
Mario Kart is going to kick Mega Man's butt.<br><br>Mega Man will
definitely be strong. Some people will think that this encompasses
every Mega Man game out, so it will garner all those votes. But really,
when it comes down to it, MM will only be as strong as it's top games.
MM2, MM3, MM4 (I never played a MM game, so just going by popular
consensus), MMX2, MMX4 and whatever else is popular. The reason why MK
will win though is because almost every MK game is as popular as those
MM games, and some are even more popular. MK64 would be able to defeat
every MM game there, in my opinion.<br><br>Mario Kart also has the
added benifit of being more consistent and more current. Yes, I know
that MMrandomletter(s) are still coming out every two/three weeks, but
they're barely talked about at all. Mega Man's strength comes from the
SNES and NES, and perhaps the PS. Mario Kart could syphon a lot of
those SNES votes because of the SNES MK game. It also has very popular
games on N64, Gamecube and the DS.<br><br>I could go into game sales
and what not, but there is no need. Mario Kart is still being talked
about to this day. It's still very popular amongst voters, and
therefore that's why I believe it's going to win.<br><br><b>My prediction: Mario Kart wins with 50.57% of the vote.</b><br> <br><br><br><b>Leon&#8217;s Analysis</b><br> <br>Here
it is, perhaps the most debated and split match of the entire contest.
Upon my first glance at the bracket, Mega Man seemed like the obvious
choice, but after having some time to think about it, this one became
deceptively tricky. <br><br>Some people were quick to dismiss Mario
Kart because it was just a &#8220;side series,&#8221; but it&#8217;s just as much of a
side series as Super Smash Brothers is, and I doubt many people on this
board would consider taking Mega Man over that series. And perhaps it
wasn&#8217;t so much that Mario Kart is a side series as it was facing the
series of a Noble Niner, the Mega Man Classic. However, there are a few
things to consider:<br><br>1. The Classic Mega Man series has been
defunct for years (since 1997, to be exact) and has since moved on to
other series. Perhaps the release of the Mega Man Anniversary
Collection has helped to counteract this, but maybe not.<br><br>2.
While Mega Man has had his fair share of releases&#8212;an understatement, to
be sure&#8212;most of them haven&#8217;t had stellar sales numbers. While sales
numbers aren&#8217;t indicative of strength, as we have well established in
the past, this is something to consider when compared to the massive
success EVERY Mario Kart has enjoyed.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/14/2006 7:23:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319792091">message detail</a>
 | #081</td></tr>
<tr class="even">
<td>
3. No Mega Man game appeared in the Games Contest and no Mega Man game
appeared on the GameFAQs Top 100 List. This is a tentative point, but
at least something worth mentioning. The fanbase split could account
for the absence in each case, as well as no Mega Man game on the
drop-down list for the Top 100 List. I really wonder why there wasn&#8217;t
at least ONE on the list. That doesn&#8217;t make any sense.<br><br>4.
There is the possibility that Mega Man Classic isn&#8217;t even the favorite
variation of the series. There is a semi-recent poll (compared to OTHER
favorites polls anyway) which shows Mega Man X as the favorite version.
This also brings into question one other thing: While Mega Man as a
character is of Noble Nine quality, just how much of that is the result
of the Classic series? It&#8217;s tough to argue that ALL of it comes from
that, even if all we ever see is Blue Bomber in match pictures. There
is also the slight possibility (which seems to be what a lot of Mega
Man supporters are banking on) that the voters will pool together every
series under one label, even if it&#8217;s only supposed to be Classic. I
think that&#8217;s basically what it has to rely on to win this match.<br><br>While
we have yet to see anything Mario Kart in a contest, it&#8217;s really hard
to deny that the series will have a measure of strength. The sales
numbers speak for themselves. It&#8217;s probably the most popular &#8220;side
series&#8221; ever in that regard, to the point where it&#8217;s hard just to
consider it a side series. Mario Kart 64 was one of the top selling
games period for the Nintendo 64. It&#8217;s a game that just about everybody
can enjoy (well, except for Ulti), even people who aren&#8217;t regular
gamers. It&#8217;s a game you can just pick up and have fun with, no matter
who&#8217;s playing.<br><br>However, the one question I have about Mario Kart
is this: While it is a universally liked series, how many have it as a
&#8220;favorite?&#8221; I know I do, but anecdotal evidence isn&#8217;t exactly the best
to go by. It seems to be more of a casual enjoyment kind of thing, but
I don&#8217;t really know. I really wanted to be stubborn and stick with my
Mega Man pick in my bracket, but the more I&#8217;ve thought about it, the
more things seem to be in Mario Kart&#8217;s favor. I think this match could
swing either way, however. It&#8217;s not an easy call.<br><br><i>Leonhart&#8217;s Prediction</i>: <b>Mario Kart with 51.04%</b><br><br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br>Ah,
yes, we finally get to what is arguably the biggest match of the first
round. Like many other hotly debated matches, Mega Man/Mario Kart falls
under the &#8220;one point&#8221; deal in that you only have to worry about losing
one point here &#8211; the next opponent is the contest winner so this is
understandable. Regardless, it does not stop people from bickering and
arguing like it were the entire division resting on this match &#8211; and it
would be much cooler if that were the case (I&#8217;m always up for the Blue
Bomber winning divisions). Even with all the debate, however, it would
seem that most of the board members are siding with Capcom&#8217;s number one
franchise, at least according to the BOP, which has a 77 &#8211; 36 split. As
for myself, I&#8217;m clearly one who resides in the Mega Man Camp. It&#8217;s a
familiar camp that I have grown used to over the years, so let&#8217;s get to
explaining by the Blue Bomber and co. will be blasting Mario Kart right
out of the contest.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/14/2006 7:24:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319792223">message detail</a>
 | #082</td></tr>
<tr class="even">
<td>
I think &#8211; more than any other franchise &#8211; that Mega Man truly benefits
from being put under one singular title to vote for. The biggest snub
from the Spring 2004 Contest was undoubtedly a Mega Man game; it was
downright shocking to see not one Mega Man game present with so many
titles that he has under his belt&#8230;but that&#8217;s just the problem. There
are so many Mega Man games and a large number of them are so good that
it is hard for people to decide upon a singular game to push into a
contest environment. It is quite true that this particular &#8220;Mega Man&#8221;
does not encompass the entire series; rather, it just focuses on the
original part of the franchise (Mega Man 1 &#8211; 8), not the X series or
Battle Network series or the Zero series. However, it is well known
that the classic Mega Man series is the second most popular series of
the entire group.<br><br>Mario
Kart &#8230; well, what can be said? It perhaps the most successful spin-off
series of all-time from any company and any series; all of the games in
the series go on to sell over a million copies in America. Mario Kart
is easily accessible to a wide range of people and has no restrictions
on who can enjoy it. There is no pure simulation (Gran Turismo) nor
purposely trying to crash and cause destruction (Burnout); instead, it
focuses on the standard &#8220;race around the track&#8221; with a hint of chaos
from the various items like shells, lightning bolts, and so forth. It
is certainly not going to be a weak franchise, especially on a site
that has such a favor toward Nintendo products, but it <i>still</i> isn&#8217;t necessarily going to be a powerhouse &#8230;<br><br>What
truly makes this match hard is that we have no previous data on Mario
Kart or Mega Man &#8211; character contests not included. There are no polls
that are dedicated to either series in such a manner that shows that
people prefer one over the other or that one is a clear favorite for
this match. Some people believe that Mario Kart is <i>more</i> more
now than any Mega Man title, and there is some truth to this. Mega Man
as sad as it is, is no longer the gaming powerhouse nor retains the
quality that the franchise once had. But, the fact that the series
isn&#8217;t as good as it used to be shouldn&#8217;t stop it from performing like
the beast it has always been. I don&#8217;t think &#8216;What have you done for me
recently?&#8217; is going to apply here very much. These are both old school
franchises that have become so well established that how they are
recently should not affect them negatively. After all, this is a match
with a series that has most of its roots on the NES. <br><br>It
remains arguable as to whether or not Mega Man Classic is the strongest
of the Mega Man series, but a poll taken not too long shows that Mega
Man X is the more preferred series, though MMC is not far behind.<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1834" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1834">http://www.gamefaqs.com/poll/index.html?poll=1834</a><br><br>Some
people may not agree, but I really don&#8217;t think people are necessarily
going to be voting with only one series in mind. If someone is voting
for &#8220;Mega Man X,&#8221; they may just include the X games since those will
initially pop into their head. But are they going to neglect the rest
of the franchise? I don&#8217;t think so. I think you are going to have a
number of people voting based on their liking of Mega Man as a whole,
especially in this match. As of now, we have no indication that CJayC
is going to bother clarifying whether or not it&#8217;ll have &#8220;(Classic)&#8221; or
&#8220;(Original)&#8221; beside it. We have seen him do it in that poll, but it
isn&#8217;t specified in the bracket. If it isn&#8217;t that may even further
reinforce the idea of Mega Man being voted on by those who like all the
games, as opposed to just the original. Even if it is, I can&#8217;t imagine
people only voting based on the liking of the original games. You have
to think that people are going to vote with more games in mind than
that. People are not going to ignore &#8220;Final Fantasy Tactics&#8221; just
because it didn&#8217;t make it; they&#8217;ll likely just vote for it as if it
were apart of &#8220;Final Fantasy.&#8221;</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/14/2006 7:24:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319792325">message detail</a>
 | #083</td></tr>
<tr class="even">
<td>
Furthermore, I think Mega Man <i>does</i> have to get his
popularity from somewhere. A case can be made that people would like a
character like Sonic based upon his character personality and attitude,
but the same case cannot be made for Rock, who is has no stand out
personality or attitude that makes him likable apart from his games.
He, more than anything else, encompasses the entire series into one.
When you see Mega Man performing in the contest, you&#8217;re seeing the
series at its best, at least I think so. While the original Mega Man
may not be <i>that</i> strong, it doesn&#8217;t need to be in order to
overcome Mario Kart. Mario Kart is undoubtedly popular, but I have my
doubts on how much people <i>care</i> for the series to the point of
having it as a favorite. We all enjoy Mario Kart, but I have trouble
believing that it is held in high regard with people. It&#8217;s a fun series
and not much else; it&#8217;s not exactly &#8220;favorite&#8221; material. <br><br>If
asked the question, &#8220;Would you take an original Mega Man game over a
Mario Kart game?&#8221; To that, I would answer &#8220;Yes.&#8221; I believe Mega Man 2,
or Mega Man 3, would be able to contend well with whatever Mario Kart
game you want to throw out there. It may not <i>win</i>, but the match
should be given just as much attention as this match is being given.
Mega Man is a huge favorite amongst gamers; this should really be no
surprise. Some might think it&#8217;s crazy to think a Mega Man game could
match any Mario Kart game, but I have no clue why one would feel that
way. Just because a series is large in quantity does not mean it lacks
quality or attention. Mega Man was an NES icon right up there with
Mario. Both were rulers of the roost back in the day, and both were
insanely popular. Initially, only a few people played Mega Man, but
word of mouth caught on and you have most of the most popular and
classic gaming character/franchises in the game industry today. <br><br>Is
Mario Kart a weak slouch? No, not at all. This match should be close
because Mario Kart does carry plenty of strength with its name. It is a
fun little series that remains exceptionally popular to this day, but
while we all enjoy Mario Kart games, I have a hard time believing that
many people look at it as a &#8220;favorite.&#8221; I think Mega Man is definitely
going to take this one, and I have never thought otherwise. The series
is classic, the series has plenty of entries, and it is the source of
the Blue Bomber&#8217;s popularity. You can expect Mega Man to perform well
in this match and bow out respectively to Final Fantasy in the
following round.<br><br><b>Aitch Emm&#8217;s Bracket Says :</b> Mega Man will win.<br><br><b>Aitch Emm&#8217;s Prediction :</b> Mega Man 53% -- Mario Kart 47%<br><br><b>Aitch Emm&#8217;s Vote :</b> Mega Man.<br> <br><br><br><b>Yoblazer&#8217;s Analysis</b><br> <br>After
two big upsets, it's almost difficult to believe that this was easily
the most debated match of the contest. Brackets will be broken. Gurus
will be eliminated. People will be a-whinin'. All because of one humble
little first round match. From what we've seen so far, it is clear that
people are favoring the old and established over the youthful and
unproven. Most would argue that because of this, things are looking
pretty good for Mega Man. I'd agree, but let's delve into this one a
little further.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/14/2006 7:25:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319792441">message detail</a>
 | #084</td></tr>
<tr class="even">
<td>
So far, which series have been the most disappointing? Up until this
point (about five hours into Sonic/Devil May Cry), I think the answer
is clear. Halo. Grand Theft Auto. Devil May Cry. What is the grand
consensus as to why they've all really stunk it up? Simply put, it's
because they lack credibility and age. They're up-and-comers. They're
new, untested, and have not had the time and exposure necessary to
really build that emotional connection with the voter. Sure, they're
popular now, but were they popular then? GTA wasn't. Halo and Devil May
Cry sure weren't. Mario Kart was. I've heard some recent talk that
Mario Kart will suffer the same fate as those disappointing series, and
I must wonder why. The series began in 1992. It's been around longer
than Pokemon and almost as long as Sonic. Pardon the terrible pun, but
Mario Kart has gone around the track a few times. Wait... it was a
brilliant pun! Analysis over!<br><br>My prediction: Mario Kart def. Mega Man (75-25)<br><br>Alright,
maybe a bit more. To deny the claim that Mario Kart has garnered quite
the fanbase over the years is very bold, to say the very least. The
series has had a multi-million selling title on every major Nintendo
system (console and handheld, mind you) since the Super Nintendo. Do
you know how many other series have done that? Mario, Zelda, and
nothing else. Nice company. Actually, Zelda doesn't have that
million-seller on the DS just yet. Hmm... looks like it's just Mario
and Mario Kart. Once again, nice company.<br><br>Sales and fanbase
potential is all well and good, but how has the series fared on
GameFAQs? Unfortunately, Mario Kart has never had any true contest
representation. There are no exclusive Mario Kart characters, and none
of its games made it into the Spring 2004 bracket. Of course, we can
use other pieces of evidence to help us along. Super Mario Kart, the
lone Mario Kart game on the Top 100 drop down list, ranked in as
GameFAQs' 61st favorite game. Not great, but not bad; at least it made
the list, after all. Also, Mario Kart DS had a very impressive showing
in the 2005 GOTY polls, edging out God of War and proving to be this
site's second favorite game of the year. No other handheld title had
ever done so well in our annual polls. To me, that was a central bit of
evidence: if a handheld Mario Kart title could beat something as
critically acclaimed as God of War, just what could the console games
do? It intrigued me, and I decided to take the risk.<br><br>I think
that's enough talk about Mario Kart, however, because everyone here
should know that this match rests with Mega Man's potential. After
Pokemon and Kirby, it's apparent that voting trends in this contest are
much different than in any character contest, so the whole "People will
see Mega Man and vote for it even if they only like the character"
argument is pretty much trashed. However, if people perceive Mega Man
to be not just the classic NES games, but all of the newer titles,
spin-offs, and the legend that they embody, then Mario Kart is in some
serious trouble. If people see Mega Man and think "Mega Man X" or "Mega
Man Battle Network" or "Mega Man Zero" or hell, "Mega Man Soccer," then
Mario Kart is in some serious trouble. However, if people view "Mega
Man" as just the classic games, that is, six NES titles and one SNES
title, then Mario Kart has some room to breathe. Do I think that that
will happen? Honestly, I wouldn't bet on it. For all my debating and
account betting, I still think (as I have since the start) Mega Man is
the favorite. However, we've already seen the second and third most
debated matches of this opening round go to the underdogs. May as well
make it three for three. =)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/14/2006 7:26:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319792569">message detail</a>
 | #085</td></tr>
<tr class="even">
<td>
Mega Man<br>+ HOLY **** THOUSANDS OF GAMES (potentially)<br>+ Age<br>+ Credibility up the wazoo<br>- No SotN or WoW to anchor it<br>- His classic games alone may not do the trick<br><br>Mario Kart<br>+ Several high selling, popular (potentially) games<br>+ Age<br>+ More credibility than people are giving it credit for<br>+ Established a genre<br>- Very little contest/poll history<br>- Spinoff status just might hurt it<br>- SSB might have stolen some of its thunder<br><br>My prediction: Mario Kart def. Mega Man (53-47)<br> <br><br><br><b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: Mega Man 2 Boss Theme <br><br>Finally!
The match of the first round! Okay, when you first look at this match
and see Mega Man vs. Mario Kart, you&#8217;d probably think that Mega Man
would easily take a Mario side series. Think again. I guess people
automatically think that since Mega Man is such a popular character
that his game series must also be popular. Nope. I&#8217;ll repeat. Games are
on a totally different spectrum than characters. Mega Man games are
nowhere <i>near</i> being as close to the top games as Mega Man is close to the top characters.  That&#8217;s one thing that you <i>must</i>
think about before you really consider this match. I&#8217;ll break down Mega
Man and point out a few things that will probably hold it back in this
match. <br><br>First, there&#8217;s the presence of Mega Man X in this
contest. There is a split in the Mega Man fanbase, and as polls have
shown, Mega Man X is the favorite Mega Man series on this site. Zero&#8217;s
contest strength is evidence of that. People may assume that fans of
the Mega Man X series would also vote for Mega Man. That is definitely
not true. Maybe against fodder that nobody cares about, but definitely
not against a series as popular as Mario Kart. The Mega Man X series
has definitely gathered its own separate fanbase. As I stated before,
Mega Man X was <i>the</i> SNES Mega Man game. Sure a couple more
classic Mega Man released, but by that time, Mega Man X had already
established itself as the alpha male in the Mega Man series. Most fans
Mega Man gained since the SNES days are probably X fans.<br><br>So with
the X series present in the contest, voters most likely will not see
Mega Man as an embodiment of the entire series. If Mega Man had its
match first, then <i>maybe</i> you might get some people that think
that, but with Mega Man X having an early match and already being
established as a separate series in this contest, that won&#8217;t happen.
It&#8217;s not like voters vote blindly each and every day. There&#8217;s a reason
why contest vote totals are always much higher than normal polls.
Voters are aware that there is a contest going on, and many follow
along what&#8217;s happening. They <i>will</i> know that Mega Man is a
separate entity in this contest. Ceej will probably make it apparent in
the match, maybe labeling it Mega Man (classic), and giving it a match
pic with Mega Man, Dr. Wily, and some Robot Masters to let voters know
they are voting on the classic series. And when it comes to the classic
series, what games are <i>really</i> popular? MM2, MM3, and&#8230; what?
Sure, the games as a whole make the series pretty popular&#8230; but I don&#8217;t
think that matters when it&#8217;s facing Mario Kart.<br><br>&#8220;But Mario Kart is just a side series!&#8221;  No, Mario Kart is the <i>granddaddy</i>
of Mario side series. Hell, Mario Kart has been around longer than half
the series in this contest. It has done plenty to establish itself as a
popular brand of gaming over the course of its 14 years. It has sold
millions across multiple Nintendo systems. When you look at sales on
every system that has Mario Kart, you usually see Mario, Mario Kart,
Zelda, and then everything else. Yes, Mario Kart games sell more than
even Zelda games. Mario Kart: Double Dash would probably be the highest
selling game ON the Gamecube had SSBM not gotten such a head start on
it. Mario Kart definitely has a very large fanbase to draw from.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/14/2006 7:26:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319792781">message detail</a>
 | #086</td></tr>
<tr class="even">
<td>
But I won&#8217;t simply use sales as my argument on why I think Mario Kart
takes this. Let&#8217;s talk about its popularity. Mario Kart&#8217;s general
popularity among gamers is uncanny. <i>Anybody</i>
can pick it up and have fun with it. Casuals, hardcore gamers, kids,
girlfriends&#8230; the series appeals to almost everybody. It doesn&#8217;t have
one single defining game like SSBM that is a huge favorite, but it
definitely has widespread popularity. Even then, I still say that Mario
Kart 64 would have done some <i>heavy</i> damage in the games contest.
Plus, we&#8217;ve also seen how popular Mario Kart DS is among gamers on this
site. Being a handheld game, runner-up to RE4 for game of the year is
actually pretty impressive. I personally think Mario Kart DS
reestablished the popularity of the series. Had MKDS not been released,
I would have thought harder about this match.<br><br>But yeah, I
acknowledge that Mega Man is a popular character on this site. But like
Kirby, I think his popularity is due to being a face of the video game
industry for so long. I don&#8217;t think his games are really <i>that</i>
popular, especially if you&#8217;re talking about only the classic series.
And even then, it&#8217;s not fair to use the strength of Mega Man the
character because there <i>is</i> no one character that defines the
Mario Kart series. I also reiterate that being a side series will mean
little in this match. Remember, this is a site that had Final Fantasy
Tactics nearly take down Metal Gear Solid, and that has SSBM as one of
the most popular games on the site overall. Even Super Mario RPG ended
up being pretty strong, and I definitely think Mario Kart is more
popular over all than SMRPG. I wouldn&#8217;t take <i>any</i> Mega Man game over SMRPG.<br><br>Bracket: Mario Kart<br>Vote: Mario Kart<br>Prediction: Mario Kart with 55%<br> <br><br><br><b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Mario Kart<br>Top 100 List comparison:<br>---MM - N/A (had no games on the drop-down list)<br>---SMK - #61<br>Best Game Ever x-stat comparison:<br>---MM - N/A (no rep)<br>---MK - N/A (no rep)<br><br>I
fear this match. I loathe this match. I host the board where this match
was first discussed -- long before the bracket was released. Thanks for
checking out the RAP board, CJay. =P<br><br>Ah, if only he really did
check out the board...but, anyway, yes, this match gives me the
heeby-jeebies. What I'm going to do for this match is simply give the
pros and cons of picking each series because there's a great case for
each. You already know I picked Mario Kart, so, here goes.....<br><br>MEGA MAN:<br>+ Its name could easily be taken as being the entire Mega Man series.<br>+ Mega Man is a Noble Niner who has made the Final Four three times, everytime with classic MM pictures.<br>+ Mega Man has to get his strength from <i>somewhere</i>.<br>- Its picture may make people realize it's just the original games.<br>- MMX's presence in the bracket may make some voters aware it's not the entire MM series on the line.<br>- Link has SFF'd Mega Man hard before, and Mario arguably SFF'd Zero.<br>- We have never seen a Mega Man game in a bracket or list.<br>-
Its age may hinder it. Not just the original series, but the age of the
gap between now and when people last cared about new Mega Man games.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/14/2006 7:27:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319792941">message detail</a>
 | #087</td></tr>
<tr class="even">
<td>
MARIO KART:<br>+ It's Mario, the king of Nintendo, in his most popular side-series.<br>+ MK64 is likely a good deal more popular than SMK, and SMK was #61 on the Top 100 List.<br>+ Every MK game has sold 1,000,000+ copies (I hear).<br>+ MKDS was the runner-up for GotY last year.<br>+ One could argue that Mario's side-series is the reason why Yoshi did so well in both of the Mario-polls...<br>- ...yet Mega Man SFF'd Yoshi last year.<br>-
It's still a side-series; one should be cautious about letting it come
too close to SMB's popularity so it doesn't get over-rated.<br>- A racing series -- even a light-hearted party-kart series like this -- over classic platforming is risky.<br>- Mario Kart 64 lacked Koopa Troopa, which was perhaps the biggest flaw the N64 ever saw.<br><br>Mario Kart wins with 51.12%<br> <br><br><br><b>Lopen&#8217;s Analysis</b><br> <br>This
is a hotly debated match, but I think Mario Kart is being overhyped.
Yes, it is a popular series, but like Sonic, it lacks the truly "big
gun" it needs, but I'd say to an even greater extent. Sure, plenty <i>like</i> Mario Kart, but it's just not a <i>favorite</i>.
You may think I'm being harsh when I say this, but in a lot of ways I
think Mario Kart might be sort of like the Pac-Man of the series
contest. Able to do decently well against many, but if against a
favorite with a similar old school appeal, it could just totally
collapse. And I think it will.<br><br>I'm <i>trying</i> to stay away
from the character/series comparisons when I can, but I've just gotta
here. There was a character battle match in the last contest, Mega
Man/Yoshi. You remember that one, right? Mega Man would not take any of
Yoshi's crap, Mega Man got equipped with blow the **** out of Yoshi&#8230;
beam&#8230; and doubled Yoshi in votes. Why do I bring this up? Because Yoshi
is the perennial favorite of the Mario Kart series. Not really a huge
factor in the pro Mega Man argument, but it can't hurt. (a grim omen!)<br><br>Mario
Kart supporters in this match tend to have the belief that Mega Man
will not get votes from voters who like the Mega Man X series. I don't
believe this will be the case. It might lose <i>some</i> votes, but I don't think it's going to be all or even most of the Mega Man X fans. Why? A couple of reasons:<br><br>1. Many voters don't pay <i>that</i>
much attention to the contests. Based on the outcome of the various
"got your bracket in yet?" polls, I'd guess somewhere between a third
and a half of the website's daily voting pool doesn't vote in <i>every</i> match. There's a variance of who shows up from day to day. Many voters won't even have <i>seen</i>
the Mega Man X match, and would almost certainly treat MMX as part of
the series if this is the case, it's the natural thing to do.<br><br>2.
Of the voters that do pay attention, how many are really going to
analyze their pick? Instinctively, when you think of the idea of Mega
Man, how many of you can honestly say that Zero things about Mega Man X
enter your mind? Average voter will not pause and say "whoa whoa, Mega
Man X4 was awesome, but I'd better not vote Mega Man because of it!
Mega Man X had its chance and that would be wrong!". I think the votes
in this contest will largely come down to "favorite game from either
series?", because of <i>instinctive voting</i>.<br><br>And because Mario Kart does not seem to generally be a <i>favorite</i>
among the people, Mega Man will suck the votes away. Mega Man 2, Mega
Man 3, Mega Man X, even MM5 and MMX2, X3, and X4 to a lesser extent.
They're all big time. If I were <i>guaranteed</i> that all voters
would vote only because of the Mega Man series alone, I might struggle
with this one a bit, but Mega Man X will have an influence, and it'll
push Mega Man over the top here.<br><br><b>Lopen's Prediction:</b> Mega Man with 60.18%<br><br><br><br>Comments: It's the first match the Crew is split on. Mario Kart wins here 5-4. I smell bragging rights for the winning side!</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1264709&amp;board=8&amp;topic=29209811" class="name">LoopZoopTheBest</a> |
Posted 7/14/2006 7:44:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319796692">message detail</a>
 | #088</td></tr>
<tr class="even">
<td>
The crew actually favors Mario Kart? Well, I'm ****ed. Nice knowing you guys.<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=453709&amp;board=8&amp;topic=29209811" class="name">jonthomson</a> |
Posted 7/14/2006 7:48:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319797572">message detail</a>
 | #089</td></tr>
<tr class="even">
<td>
<i>The crew actually favors Mario Kart? Well, I'm ****ed. Nice knowing you guys.</i><br><br>The crew favoured Halo and GTA lolololol :-)<br>---<br>Jon Thomson - CATS, Jay Solano, Ridley, Scorpion, Alien Hominid, Duke Nukem, The Prince, Johnny Rocketfingers, two TBA</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=1264709&amp;board=8&amp;topic=29209811" class="name">LoopZoopTheBest</a> |
Posted 7/14/2006 7:55:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319798978">message detail</a>
 | #090</td></tr>
<tr class="even">
<td>
Exactly.<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/14/2006 7:59:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319799859">message detail</a>
 | #091</td></tr>
<tr class="even">
<td>
Boxed in...horribly. I've got about a .25% margin of error. Crap.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/14/2006 9:09:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319814881">message detail</a>
 | #092</td></tr>
<tr class="even">
<td>
So I have the lowest MK pick? Good. <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=546065&amp;board=8&amp;topic=29209811" class="name">badazzbuddy117</a> |
Posted 7/14/2006 11:44:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319851317">message detail</a>
 | #093</td></tr>
<tr class="even">
<td>
wow goo lopen<br>---<br>All hail the "Go Halo" monks! RE 4 rules<br>Name: Poo MK friend code:352255-222249</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/14/2006 11:45:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319851447">message detail</a>
 | #094</td></tr>
<tr class="even">
<td>
Bah, that's what I get for letting the board change my mind...again. Should've stuck with Mega Man.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29209811" class="name">DaruniaTheGoron</a> |
Posted 7/15/2006 2:18:52 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319877394">message detail</a>
 | #095</td></tr>
<tr class="even">
<td>
Damn, the percentage will go down but nice prediction Lopen.<br>---<br>...little Weezing it's gonna stand up against my ****in' Charizard? Just get back on your bike <br>and keep pretending to be cool with your lame ass mohawk ****er. - phoenix1487 <b><i>Sp2k6: 9/11</i></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/15/2006 2:25:57 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319878221">message detail</a>
 | #096</td></tr>
<tr class="even">
<td>
Lopen...vindicated? An unexpected turn of events!<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=721959&amp;board=8&amp;topic=29209811" class="name">Karma Hunter</a> |
Posted 7/15/2006 2:27:03 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319878345">message detail</a>
 | #097</td></tr>
<tr class="even">
<td>
I should have known Lopen's crazy 60% pick would work out for him! Give that man a point! Hell, make it a <i>Stylish</i> one!<br>---<br><b>Commit it to memory.</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29209811" class="name">Lugia2</a> |
Posted 7/15/2006 5:37:16 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319892529">message detail</a>
 | #098</td></tr>
<tr class="even">
<td>
I KNEW there'd be SFF- I just wasn't sure which way it would go...<br><br>Good job, Lopen!<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/15/2006 12:01:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319927706">message detail</a>
 | #099</td></tr>
<tr class="even">
<td>
Final Fantasy.......85.98% 107648<br>Diablo.....................14.02% 17560<br>TOTAL VOTES..................125208<br><br>97.25% of the brackets predicted this match correctly.<br><br>Yeah,
that's just plain scary. Diablo isn't even fodder, yet FF makes it look
bad. Final Fantasy is going to be a force in this Contest, so anyone
who has Zelda winning...bad move.<br><br>Today, Mega Man is easily holding back Mario Kart. Does suck seeing MK getting beaten so bad.<br><br>Soul - 3<br>Moltar - 2<br>HaRRich - 2<br>HM - 2<br>Yoblazer - 1<br>Leon - 1<br>Ulti - 1<br>Mnm - 0<br>Lopen - 0<br><br>Yo gets his first point with the highest FF pick.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Mega Man vs. Mario Kart - Bracket: <b>MM</b> - Vote: <b>MK</b> (11/13)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/15/2006 12:04:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=319928103">message detail</a>
 | #100</td></tr>
<tr class="even">
<td>
+9 yoblazer <br>+8 Moltar <br>+7 Leonhart <br>+6 Soul <br>+5 Ulti <br>+4 Lopen <br>+3 mnm <br>+2 HaRRicH <br>+1 Heroic Mario<br> <br><b>The Rankings</b> (Through Final Fantasy/Diablo)<br>1. Master Moltar (59)<br>2. XxSoulxX (54)<br>3. yoblazer33 (51)<br>4. UltimaterializerX (45)<br>5. Leonhart (43)<br>6. therealmnm (42)<br>7. HaRRicH (40)<br>8. Lopen (37)<br>9. Heroic Mario (33)<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Mega Man vs. Mario Kart - Bracket: <b>MM</b> - Vote: <b>MK</b> (11/13)</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">1</a></li>
<li>      2</li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=2">3</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=3">4</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=4">5</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=5">6</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=6">7</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=7">8</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=8">9</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=9">10</a></li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage2_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29209811&amp;page=1" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage2_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>