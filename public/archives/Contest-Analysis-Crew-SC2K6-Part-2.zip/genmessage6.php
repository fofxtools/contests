<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head>

	


<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">

<title>GameFAQs: Message List</title><link rel="stylesheet" type="text/css" href="genmessage6_files/default.css"><link rel="stylesheet" type="text/css" href="genmessage6_files/nogs.css"><link rel="stylesheet" type="text/css" href="genmessage6_files/bc.css"></head><body linkifytime="441" linkified="6" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage6_files/ge_img_6_light.gif" alt="CNET Networks Entertainment"> <a href="http://www.gamespot.com/">GameSpot</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage6_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D29209811%26page%3D5"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>

	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox">Search for:</label>
		<input id="searchtextbox" name="game" value="Search By Title" onfocus="javascript:if(this.value=='Search By Title'){this.value='';}" onblur="javascript:if(this.value==''){this.value='Search By Title';}" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option>All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1024">PSP</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="1028">PlayStation 3</option>
			<option value="1031">Revolution</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs">Boards</a>
			<a href="http://www.gamefaqs.com/features/help">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PlayStation&nbsp;2</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="http://www.gamefaqs.com/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/revolution/">Revolution</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html?i=1">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">
<div style="text-align: center;">
<a href="http://adlog.com.com/adlog/c/r=10153&amp;s=657778&amp;t=2006.07.30.22.06.13&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;rqid=01c17-gne-ad144C8F19B1584868/http://www.gamespot.com/pc/driving/18wheelsofsteelconvoy/index.html?q=18%20wheels" target="_blank"><img src="genmessage6_files/18wos_leader.gif" alt="Click Here" border="0" height="90" width="728"></a><img src="genmessage6_files/c.gif" height="1" width="1"><br clear="left">&nbsp;<br><noscript><img src='http://gserv.zdnet.com/clear/ns.gif?a000009999999999999+2093' width='1' height='1'></noscript></div><div class="head"><h1>Spring 2006 Contest Analysis Crew - Part 2</h1></div>

<div class="board_nav">
	<div class="body">
	<div class="user">

<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=29209811&amp;page=5">Master Moltar</a> (34) |
		<a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a> | <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>

           | <a href="#8,29209811" id="gamefox-tag-link">Tag Topic</a></div>
<p></p><div class="error">This Topic has been marked <b>closed</b>. No additional messages may be posted.</div>

<div class="pages">

          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">First
          Page</a> |
          <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=4">Previous
          Page</a> |
          Page 6 of 10          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=6">Next
          Page</a>
          | <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=9">Last
          Page</a>
      </div>
      </div></div>

<div class="board">

<table class="message">
<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/21/2006 8:24:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321529026">message detail</a>
 | #251</td></tr>
<tr class="even">
<td>
<b>Mushroom Division:</b> <i>Round 2 - Match 21</i> &#8211; (1)Super Mario Bros. vs. (5)WarCraft <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Super Mario Bros.</b><br>Round 1 &#8211; 92.21% vs. Madden NFL (7.79%)<br><br>Super Mario Bros. absolutely destroys Madden. Over 90% and everything.<br> <br><b>WarCraft</b><br>Round 1 &#8211; 50.44% vs. Grand Theft Auto (49.56%)<br><br>In a close match, WarCraft barely edges into Round 2, with a little help from a certain forum.<br><br>Well,
I certainly wasn&#8217;t expecting this. Super Mario Bros. vs. Warcraft in
Round 2. Could have sworn GTA was going to have the fortune of facing
Mario Bros. in Round 2. Oh well, we are getting the same result anyway.
Anyway, time for a dramatic re-creation of Round 1 events.<br><br>Mario Bros.: lol crush madden<br><br>John Madden: <b>BOOM!</b><br><br>*GTA/Warcraft poll goes up* <b><i>DUEL!</i></b><br><br>GTA: Alright, *****, I&#8217;m going to whoop some ass now. I activate &#8220;Quick Start&#8221;, giving me the early lead in the match.<br><br>GTA fans: See, GTA is going to win easily. Stupid Warcraft fans. lol thinking that rallying would work<br><br>WarCraft: Not so fast, GTA! I summon a Hunter and attack to take the lead. I also lay one card face down.<br><br>*Chaos ensues at Board 8*<br><br>GTA: I&#8217;m coming back, you all can count on me! I attack with Tommy Vercetti&#8217;s Hawaiian shirt!<br><br>WarCraft: I counter that with the &#8220;Overseas Asian Vote&#8221;!<br><br>*WarCraft builds lead little by little, WarCraft supporters begin to act like jerks*<br><br>GTA: No! I&#8217;m still in this!<br><br>WarCraft: Nuh-uh, because now I active my spell card, &#8220;For the Horde!&#8221; It brings me an extra 5,000 rally votes.<br><br>*WarCraft continues to pull ahead, match called over by many*<br><br>WarCraft: And to finish, I&#8217;ll active my trap card, &#8220;Great Blue!&#8221; adding on 10,000 rally votes.<br><br>GTA: Damn you!!!<br><br>*GTA is sent to the Shadow Realm while WarCraft moves on two Round 2.*<br><br>Summary:
I feel that on GameFAQs alone, GTA is the stronger game, but because of
the successful rallying from the WoW forums (which many thought
wouldn&#8217;t happen), WarCraft managed to win. I will, however, say that I
did underestimate WarCraft&#8217;s initial strength. Anyway, let&#8217;s see how
Round 2 goes!<br><br>*Showdown! Super Mario Bros. vs. WarCraft*<br><br>WarCraft: Ok people, rally me to victory!<br><br>Rallyers: **** that noise. *votes Mario, WarCraft is horribly crushed*<br><br>Summary: Rallying won&#8217;t work against <i>freakin&#8217; Mario</i>.<br><br><b>Moltar&#8217;s Bracket Says:</b> Super Mario Bros. will win.<br><br><b>Moltar&#8217;s Prediction is:</b> SMB: 71% - WarCraft: 29%<br> <br><br><br><b>Ulti&#8217;s Analysis</b><br> <br>I
doubt that the winner of this match is in any real question. All that
matters here is whether or not WoW will rally again, which will affect
Warcraft's percentage in the match.<br><br>Then again, this isn't being
held on a Tuesday like Warcraft's last match. There's also the fact
that most of the people in the WoW topics responded to "Vote Warcraft
over Mario!" with things along the lines of "It's freaking MARIO!!".<br><br> I'd give WoW-- er, <i>Warcraft</i>
an honest chance at breaking 40% if this were on a Tuesday. But it's
not, plus Warcraft faithfuls know that Warcraft is a blip on the radar
compared to the influence of the Mario series.<br><br>On a side note,
congrats to Warcraft for beating GTA in the first place. 6 million
people didn't exactly show up to vote, but that match was over for GTA
the second Warcraft proved that the match would be close. Too many
votes for Warcraft to draw from to actually lose.<br><br>I'm half-hoping Warcraft pulls a miracle just to see the chaos, but I know better.<br><br>Prediction: Mario with 63.25%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/21/2006 8:26:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321529350">message detail</a>
 | #252</td></tr>
<tr class="even">
<td>
<b>Soul&#8217;s Analysis</b><br><br><i>SMB defeated Madden with 92.21%<br>Warcraft defeated GTA with 50.44%</i><br><br>Two
great first round matches, for entirely different reasons here. Will
that make it an interesting round 2 match? Highly unlikely, but then
again... Warcraft did beat GTA.<br><br>Let's start with the king. Mario
began this contest by absolutely murdering John Madden. Oh, how much I
wish that was true. Anyways, Madden NFL got its ass whooped in what was
the biggest blowout of the entire contest. Looks like Madden is
despised on this site. That, or Mario is going to destroy everyone in
this contest and their mothers! I wish that was true as well.<br><br>Warcraft's
match was amazing not because of a blowout, but because it was an
unexpected win! Well, it was for most of us anyways. I called this
match right, but then chickened out with a week left. But enough about
that.<br><br>Warcraft defeated GTA with a little help from the WoWers
and TTF (The Tuesday Factor, yo), but it won't be so lucky against
Mario. First off, the servers will not be down when this match takes
place, so WoWers won't be bunched in one place. Therefore, rallying
will be a lot harder and a lot less successful this time around.
Secondly, Mario is no GTA. We know the strength of Mario, while
everyone was taking guesses for GTA off of top tens and the top 100
games contest. What we do know about Mario is that it is far and away
the third most popular series on this site. So, if you are not named
Final Fantasy or Legend of Zelda, you will not defeat Super Mario Bros.<br><br>Warcraft
is going to lose, but it could put up some interesting numbers here. It
all depends on the strength of the rallying last round. If there wasn't
much rallying, then Warcraft will perform better then usual. If
Warcraft's strength came solely from rallying, then it will look like
complete garbage. I'm going to play it safe.<br><br><b>My Prediction: Super Mario Bros. wins with 72.45% of the vote. </b><br> <br> <br><br><b>Yoblazer&#8217;s Analysis</b><br> <br>First off, let me start by saying that parts of me are still soar following the GTA/Warcraft match. <i>Man</i>,
we laughed at you Warcraft supporters so much, and look what happened.
I found it funny how many people casually let the result slide, as if
it weren't a shock or something. It was a shock, and most of the board
got owned. We suck!<br><br>That said, if all that rallying could barely
get Warcraft past Grand Theft Auto, it's going to be in for a world of
hurt against the most famous video game series of all time. I fully
expect this match to not only stamp Mario's series as #3 throughout
GameFAQs, but to also show everyone that the discrepancy between the
Big Three and the next strongest series is absolutely gigantic. Does
everyone remember that one topic on a Starcraft board in which somebody
spammed for Kerrigan votes, and half the replies were hilariously in
support of Vincent? I expect to see the same thing here. You know why?
Because this is Mario, and this is how Mario rolls.<br><br>Super Mario Bros.<br>+ Several games from which to draw popularity<br>+ Most of those games are pretty damn strong in their own right<br>+ Most recognized series in gaming history<br>- Nothing<br><br>Warcraft<br>+ Blizzard rallying. It worked.<br>- It's not going to matter here<br><br>My prediction: Super Mario Bros. defeat Warcraft (79-21)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/21/2006 8:26:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321529483">message detail</a>
 | #253</td></tr>
<tr class="even">
<td>
<b>Leon&#8217;s Analysis</b><br> <br>First of all, hats off to all the
Warcraft supporters out there. I was way off about GTA/Warcraft, so
kudos for the victory. With that out of the way, I&#8217;ll say that this
match is difficult to predict in terms of percentages. The winner is
beyond obvious (even the users at the World of Warcraft forums and
CJayC have admitted that), but exactly how badly will Super Mario
Brothers beat it? <br><br>Both series showed themselves to be
monumental vote drawers, so we could potentially see the final tally
for this match somewhere in the 130,000 range. I wouldn&#8217;t call it all
that likely, but it wouldn&#8217;t surprise me. Just when we thought what the
Legend of Zelda did to Civilization would be hard to top, Super Mario
Brothers not only outdoes it, but shatters the records it had set just
eight days before. Zelda breaks 100,000 votes? No problem! Try 108,000!
Zelda wins by nearly 90,000? Hah! Try winning by nearly 100,000! Those
records should at least stand until the end of this particular contest
because none of the Big Three will have something they can beat up that
badly. <br><br>On the opposite end of the spectrum, Warcraft overcame
an early deficit against Grand Theft Auto and held on for victory in an
all-day slugfest that didn&#8217;t go without its fair share of controversy.
Thirteen vote stuffers were found, and despite what we were expecting,
twelve of them were cheating for Grand Theft Auto, but CJayC made a
topic about it saying that it only amounted to 600 votes, so it would
not have made the difference between victory and defeat even if they
had been counted. Everything seemed to be in Warcraft&#8217;s favor that day.
The match fell on a Tuesday, meaning that the World of Warcraft servers
were down, so rallying on the forums was bound to be more meaningful
than any other day. There was even a &#8220;Blue&#8221; post (the equivalent of a
CJayC post on GameFAQs), meaning that the users there were even more
likely to view the rallying thread. Warcraft&#8217;s attempts appeared to
have paid off, as the match ranked as the fourth highest of all-time. <br><br>The
main thing that determines just how high Super Mario Brothers goes is,
oddly enough, Grand Theft Auto. Many people on the boards had high
aspirations for GTA before the contest began, thinking it had the
potential to be the strongest series behind the Big Three. That
obviously turned out not to be the case, but is Warcraft just that
strong or did Grand Theft Auto tank? Despite losing, it ended up as the
fourth most impressive loser in contest history in terms of individual
votes. Odds are that it would have been victorious without rallying, as
it only ended up losing by 1116 votes. I figured I&#8217;d be able to make a
solid guestimation after Final Fantasy/Diablo, but after that utter
destruction, I really didn&#8217;t know what to do with it. I have no doubt
that Warcraft is ahead of Diablo, but by how much? I&#8217;m undecided but
I&#8217;ll give Warcraft some credit and say it doesn&#8217;t get completely
destroyed like Final Fantasy and the Legend of Zelda have been doing
here. <br><br><i>Leonhart&#8217;s Prediction</i>: <b>Super Mario Brothers with 73.19%</b><br> <br> <br> <br><b>HM&#8217;s Analysis</b><br> <br><b>Super Mario Bros.</b><br><br><i>Previous Matches :</i><br><br>Super Mario Bros &#8211; 92.21% -- 108,723<br><br>Madden NFL &#8211; 7.79% -- 9,186 <br><br><b>Warcraft</b><br><br><i>Previous Matches :</i><br><br>Grand Theft Auto &#8211; 49.56% -- 63,051<br><br>Warcraft &#8211; 50.44% -- 64,167 <br><br><i>Wow</i>.
Both of these matches are ridiculously impressive, which is surprising
given one of them is an expected blowout. This match is undoubtedly a
no-brainer as to who will win &#8211; even CJayC gives Warcraft a snowball&#8217;s
chance at winning &#8211; so it just depends on how big of a blowout Super
Mario Bros. is capable of dishing out, which should be pretty high in
percentage.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/21/2006 8:27:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321529590">message detail</a>
 | #254</td></tr>
<tr class="even">
<td>
Last round, Super Mario Bros. completely thrashed Madden NFL. It was
pretty much to be expected that it would have the blowout of the round,
but the real impressive part of the match is the insane vote totals and
absolutely monstrous individual vote gain for SMB. The Legend of Zelda
set the individual vote record just a few matches ago by barely getting
over 100,000 votes, then SMB comes along and <i>smashes</i>
that by getting 108,000 votes. That is completely unprecedented and
probably will not be surpassed for a long, long time, if ever. That is
truly a sign of strength when you can put up those kinds of numbers by
yourself. Warcraft stands basically no chance against something that
can do that. <br><br>In the other match, Warcraft managed to survive
Grand Theft Auto and actually pull a win, much to the surprise of the
entire Crew. But what was most interesting, and extremely humorous, was
the fact that GTA was caught vote stuffing. It was not Warcraft like
many had suspected. CJayC made a topic and noted that there were about
13 different people vote stuffing and 12 of those were doing it in
favor of Grand Theft Auto. Hilarious stuff. Those 12 people ended up
with a total of 600 votes in favor of GTA, which was still nowhere near
enough to take the lead away from Warcraft. A rather impressive
performance and this could have been a real bracket buster if Warcraft
was anywhere else. <br><br>Super Mario Bros. is the clear and present
winner of this match, and it will not even be close. Super Mario Bros.
is undoubtedly the third strongest series on this site, and it may not
be too far behind LoZ and FF. This is just another rather boring match
for SMB to stroll through before it meets up with its first real
challenge against Final Fantasy in the Final Four. Warcraft can rally
and try to cheat all it likes; in this match it is just completely
outclassed. Even rallying might work <i>against</i> it just because of
how universal Mario is. What might be most enjoyable about this match
is the fact that we get to see a Blizzard smashed quickly &#8211; nothing is
more irritating than Blizzard fanboys. The difference in strength
between another Blizzard entry and a <i>real</i> powerhouse will be present here. Mario is going to be smashing Orcs like they were Koopa Troopas without shells<i>!!</i> <br><br><b>Aitch Emm&#8217;s Bracket :</b> Super Mario Bros.<br><br><b>Aitch Emm&#8217;s Prediction :</b> Super Mario Bros. &#8211; 74% ; Warcraft &#8211; 26%<br><br><b>Aitch Emm&#8217;s Vote :</b> Super Mario Bros.<br> <br> <br> <br><b>Mnm&#8217;s Analysis</b><br> <br>Battle Music: Bowser Boss Music (SM64) <br><br>I
really don't have much to say about this match. It basically will come
down to how much rallying Warcraft can get, and whether or not it will
even <i>hold up</i> against a series as legendary as Super Mario Bros.
I think it will be somewhere in the middle. I really think that Super
Mario Bros. is in a class by itself and is easily much closer to LoZ
and FF than it is to the rest of the pack. So even if Warcraft is legit
and GTA is as strong as I <i>thought</i> it was, SMB would still win
pretty handily. But if what I think is true about the gap between the
big 3 and the rest of the pack, these x-stats are going to look
HORRIBLE. Anyways, Warcraft will have done a good job if it passes 30%.
But with the way FF murdered Diablo, I'm wary of how Warcraft will
stand up to Mario. <br><br>Bracket: Super Mario Bros.<br><br>Vote: Super Mario Bros.<br><br>Prediction: Super Mario Bros. with 76.5%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/21/2006 8:27:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321529734">message detail</a>
 | #255</td></tr>
<tr class="even">
<td>
<b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Super Mario Bros.<br>Earlier this contest:<br>---SMB - 92.21% on Madden NFL<br>---Warcraft - 50.44% on Grand Theft Auto<br>Top 100 List comparison:<br>---SMB3 - #5, SM64 - #13, SMB - #22, SMW - #23, SMW2:YI - #82<br>---WoW - #39, Warcraft 3 - #60<br>Best Game Ever x-stat comparison:<br>---SMB3 - 39.9% (8 Division champion), SMW - 34.24%, SM64 - 21.93% (SFF'd by LoZ:OoT, has since had SM64DS released)<br>---Warcraft - N/A (no rep)<br><br>I'll
keep this one fairly short. Warcarft may have upset GTA, but -- despite
what I said in my GTA/WC analysis -- it's not winning against SMB.
Without rallying, GTA should have beat it soundly...but instead, on the
best day for rallying possible for Warcraft, it barely beats GTA. Had
it won convincingly, sure, I'd be more cautious about this match...but
SMB could beat GTA with 55+%, and GTA would probably beat Warcraft if
it wasn't held on a Tuesday, even with rallying. SMB/WC will be on a
Saturday (which, for what it's worth, probably helped Starcraft against
LoZ:WW.....), and I think even the rallied voters will be more likely
to vote for SMB than they were for GTA, so the rallied effect for
Warcraft should be smaller.<br><br>For kicks though, if there are a lot
of rallied votes for this match as well, this has potential for an even
higher vote-total than GTA/WC.<br><br>Super Mario Bros. wins with 60.12%<br> <br><br><br><b>Lopen&#8217;s Analysis</b><br><br>Hey
Warcraft. You happy to be here? Well I'm happy you're here, that's for
sure. Too bad you're going down right now in a SFF match. "Hark, a
fool!", you say? "Super Mario Brothers/Warcraft Same Fanbase Factor,
preposterous", you say? Well, <i>I</i> say Super Mario Brothers SFFs <i>all</i> series! Yes, Timmy&#8230; <i>all</i>
series! How many people haven't played any games in the Super Mario
Brothers series, eh? I think they did a poll on GameFAQs and "I've
never played a Mario game" got -2%. Yeah, <i>negative</i> percent. Okay, I'm exaggerating, but I'm seriously only off by a few % at most.<br><br>This
is why X-Stats are gonna be so worthless for this thing, I'm not joking
when I say I think that this is gonna be a "SFF match". Look at what
Final Fantasy did to Diablo and tell me I'm not right! Why aren't all
matches blowouts then? Well, if both series are about as popular as one
another, or if one series isn't an absolute beast, I don't think it's
going to happen as much. However, with the big three especially&#8230; Zelda,
Super Mario, and Final Fantasy, I have this feeling we're going to be
seeing much bigger wins than expected. (And Sonic! DMC isn't that weak,
fools!) Oh, and&#8230; blah blah recent series flopping blah blah age blah
blah more releases blah blah classic blah.<br><br>No one really expects Warcraft to <i>win</i>, anyway, I'm just trying to explain my <i>absurdly high prediction</i>, here. Fear The Nostalgia Factor!<br><br><i>Final Fantasy is so screwed</i>.<br><br><b>Lopen's Prediction:</b> Super Mario Brothers with 80.15%<br><br> <br> <br>Comments: Super Mario Bros. wins! I swear!</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/21/2006 8:29:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321530072">message detail</a>
 | #256</td></tr>
<tr class="even">
<td>
I like Ulti's the best -- great positioning.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=863018&amp;board=8&amp;topic=29209811" class="name">Janus5000</a> |
Posted 7/21/2006 8:31:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321530491">message detail</a>
 | #257</td></tr>
<tr class="even">
<td>
Lopen needs to realize that shooting high does not always imply a headshot.<br>---<br>"Those who cast the vote decide nothing. Those who count the vote decide everything."</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3662060&amp;board=8&amp;topic=29209811" class="name">YoAriel33</a> |
Posted 7/21/2006 8:32:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321530736">message detail</a>
 | #258</td></tr>
<tr class="even">
<td>
Dammit, Lopen!<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/21/2006 8:33:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321531016">message detail</a>
 | #259</td></tr>
<tr class="even">
<td>
It's <i>Lopen</i>, people! Lopen will always be Lopen.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Castlevania vs. Kingdom Hearts - Bracket: <b>KH</b> - Vote: <b>KH</b> (20/22)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/21/2006 8:33:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321531089">message detail</a>
 | #260</td></tr>
<tr class="even">
<td>
STOP FOLLOWING ME LEON!<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/21/2006 10:44:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321562405">message detail</a>
 | #261</td></tr>
<tr class="even">
<td>
STOP GETTING ME BOXED IN, SOUL!<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3662060&amp;board=8&amp;topic=29209811" class="name">YoAriel33</a> |
Posted 7/21/2006 11:05:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321567687">message detail</a>
 | #262</td></tr>
<tr class="even">
<td>
God I hate you, Lopen.<br>---<br><i>Watch and you'll see... someday I'll be...<br>part of your WOOOOOOOOORLD!!!</i></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/21/2006 11:08:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321568313">message detail</a>
 | #263</td></tr>
<tr class="even">
<td>
Oh man, I am WWAAYY off-base for this match, heh.<br><br>At least I love the picture, I suppose.....<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2266918&amp;board=8&amp;topic=29209811" class="name">KamikazePotato</a> |
Posted 7/21/2006 11:08:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321568400">message detail</a>
 | #264</td></tr>
<tr class="even">
<td>
Go Lopen!<br><br>---<br>Angsty_Lou: Everything has a sexual connotation if you just look long and hard enough.<br>Theo72: U SED LONG AND HARD LOL</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29209811" class="name">SquallidSnake</a> |
Posted 7/21/2006 11:08:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321568463">message detail</a>
 | #265</td></tr>
<tr class="even">
<td>
Lopen has been extremely hit-or-miss lately.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3147227&amp;board=8&amp;topic=29209811" class="name">MnMZero</a> |
Posted 7/22/2006 12:28:21 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321585979">message detail</a>
 | #266</td></tr>
<tr class="even">
<td>
Meh, I'll never get a point...<br>---<br>*Is therealmnm*<br><b>Proud Supporter of Mega Man X in Best. Series. Ever. Contest</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=463285&amp;board=8&amp;topic=29209811" class="name">UltimaterializerX</a> |
Posted 7/22/2006 2:21:56 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321603498">message detail</a>
 | #267</td></tr>
<tr class="even">
<td>
<i><b>From HaRRicH Posted 7/21/2006 9:29:07 PM #256</b></i><br><i>I like Ulti's the best -- great positioning.</i><br><br>:(<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: Resident Evil 4, KH:COM (Sora), Larussa 92 (NYY), WC3: Frozen Throne</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3478664&amp;board=8&amp;topic=29209811" class="name">SquallidSnake</a> |
Posted 7/22/2006 2:23:33 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321603697">message detail</a>
 | #268</td></tr>
<tr class="even">
<td>
Yeah, he's in a great position to be off by 20%!<br><br>And I can make fun because I'm only off by 10%!<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>Knowing your enemy is the quickest path to victory.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3122769&amp;board=8&amp;topic=29209811" class="name">Jarvis_Clarinet</a> |
Posted 7/22/2006 2:49:03 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321606304">message detail</a>
 | #269</td></tr>
<tr class="even">
<td>
My sig for the remainder of the contest is hereby dedicated to this
year's contest analysis crew. I just hope no one takes it the wrong
way. Keep up the great work, you guys!<br>---<br>HaRRicH: I like Ulti's the best -- great positioning.<br>Leon: Yeah, he's in a great position to be off by 20%! (Dedicated to the 2006 Contest Analysis Crew)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/22/2006 9:53:51 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321635897">message detail</a>
 | #270</td></tr>
<tr class="even">
<td>
Heh, it's all good.  I maintain he did have great positioning though...just really wrong.  Like me.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/22/2006 2:53:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321688361">message detail</a>
 | #271</td></tr>
<tr class="even">
<td>
Castlevania..........48.67% 62435<br>Kingdom Hearts..51.33% 65851<br>TOTAL VOTES................128286<br><br><i>29.9</i> of the brackets predicted this match correctly.<br><br>Well,
Castlevania started strong, but the day vote killed it. KH wins the
match. Look at those totals too, 2nd most of the Contest! Looks like
sometimes the new school can win out against the old school. It might
just be an exception to the rule though. Also, look at the brackets.
Looks like alot of people had Halo winning this four-pack.<br><br>Today, SMB continues its path of dominance by beating WC with ease.<br><br>Soul - 4<br>HaRRich - 3<br>Moltar - 3<br>Lopen - 2<br>Ulti - 2<br>HM - 2<br>Yoblazer - 1<br>Leon - 1<br>Mnm - 0<br><br>Wow..no point. You know, a bracket based on Crew picks would only have 19 points so far. Ouch, good thing I have my own!<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Super Mario Bros. vs. WarCraft - Bracket: <b>SMB</b> - Vote: <b>SMB</b> (22/24)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/22/2006 2:57:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321689141">message detail</a>
 | #272</td></tr>
<tr class="even">
<td>
-1 Moltar<br>-1 Yo<br>-3 Mnm<br>-4 Leon<br>-5 Soul<br>-6 HM<br>-7 Ulti<br>-8 HaRRich<br>-9 Lopen<br><br><b>The Rankings</b> (Through Castlevania/Kingdom Hearts)<br>1. Master Moltar (92)<br>2. XxSoulxX (76)<br>3. UltimaterializerX (75)<br>4. Leonhart (69)<br>5. yoblazer33 (67)<br>6. Lopen (62)<br>7. HaRRicH (56)<br>8. Heroic Mario (51)<br>9. therealmnm (49)<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Super Mario Bros. vs. WarCraft - Bracket: <b>SMB</b> - Vote: <b>SMB</b> (22/24)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=3608784&amp;board=8&amp;topic=29209811" class="name">THEJackSparrow</a> |
Posted 7/22/2006 5:45:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321722467">message detail</a>
 | #273</td></tr>
<tr class="even">
<td>
Hmmm...Looks like I'll gain a little bit of ground on everybody ahead of me, though yo's going to pass me up, too.<br>---<br>"...And then they made me their chief." - Captain Jack Sparrow</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/22/2006 8:23:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321755404">message detail</a>
 | #274</td></tr>
<tr class="even">
<td>
Man, it's almost here...<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/22/2006 8:50:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321761714">message detail</a>
 | #275</td></tr>
<tr class="even">
<td>
Man, for winning MG/FE, I thought I was about to rise from the dead a
lil'...but yesterday and today hurts, bad, and if SSB loses tomorrow
I'm completely done for.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/22/2006 8:56:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321763042">message detail</a>
 | #276</td></tr>
<tr class="even">
<td>
You'd figure for how many points Lopen has gotten in this round alone,
he'd be close to the top. I guess that happens when the times he
doesn't get one end up being the worst overall predictions.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/22/2006 8:56:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321763130">message detail</a>
 | #277</td></tr>
<tr class="even">
<td>
<b>Mushroom Division:</b> <i>Round 2 - Match 22</i> &#8211; (3)Sonic vs. (2)Super Smash Bros. <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Sonic</b><br>Round 1 &#8211; 70.87% vs. Devil May Cry (29.13%)<br><br>Sonic easily takes care of DMC in Round 1.<br> <br><b>Super Smash Bros.</b><br>Round 1 &#8211; 76.37% vs. Dragon Quest (23.63%)<br><br>SSB beats Dragon Quest by a bit more than most expected.<br><br>Ok,
the match of Round 2 IMO. Now that CV/KH has taken place, that might
not be so. But still, this is one match that was gotten tons of debates
on both sides, so I&#8217;m going to try to keep it brief.<br><br>Both series
easily dispatched of their opponents last round. It&#8217;s hard to call a
favorite from their performances though. I would easily take DMC over
DQ, but SSB did better on DQ than Sonic did on DMC, so that doesn&#8217;t
help.<br><br>Anyway, advantages for Sonic. It&#8217;s an old-school series,
and as we&#8217;ve seen with the Big Three, Castlevania and Mega Man, it
helps. A single Castlevania or Mega Man game alone might not defeat
Halo or Mario Kart, but as a series, they were able to. Sonic also has
big old and new school fanbases. Some like the 2D, but had the 3D, and
vice-versa.<br><br>As for Super Smash Bros., it&#8217;s the stronger overall
game, and I&#8217;d take it over any Sonic game individually. As we saw with
Castlevania/Kingdom Hearts, having two strong games and being backed by
a huge company gave it the edge. It had something that Halo didn&#8217;t have
in its match, the Square fanbase, and now SSB has (most of) the
Nintendo fanbase behind it.<br><br>Either way, I see this match being
close. I&#8217;m still giving SSB the edge though. It&#8217;s Sonic&#8217;s old-school
fanbase against SSB&#8217;s new-school one. We could be seeing CV/Halo part 2
where the older, games on many platforms spreading out all over the
years series wins, or CV/KH part 2, where the new, smaller series with
stronger games individually wins. Hopefully we&#8217;re in for a good match
either way. <br><br><b>Moltar&#8217;s Bracket Says:</b> Super Smash Bros. will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Sonic: 48% - Super Smash Bros.: 52%<br> <br><br><br><b>Mnm&#8217;s Analysis</b><br>  <br>Battle Music: Open Your Heart (Sonic Adventure) <br><br>This
match has certainly become more interesting than I thought it would be.
The match of note that made it that was was how Mega Man handled Mario
Kart. Mario Kart couldn't even make it <i>close</i>. Seeing how I
definitely think Mario Kart is more popular than the likes of Super
Mario RPG, I think Mega Man definitely proved its strength in that
matchup. Could it have simply been SFF? Possibly. Mega Man is probably
higher in the tier among fans of both as that match has shown. But I'm
not taking anything away from Mega Man. The question is if Sonic can
follow in Mega Man's footsteps. It has the more daunting task, as SSB
is a different beast altogether than Mario Kart, but based on the gap
in the Mega Man/Mario Kart matchup, Sonic has a lot of room to work
with. <br><br>The thing that bothers me is if Sonic can actually take advantage of a Nintendo franchise.  SC2k4's SMW/Sonic 2 matchup draws <i>huge</i>
flags, as Sonic didn't even make it close, and they were both supposed
to be among the most popular platformers of that era. Of course, Sonic
will have a lot more going for it as a series, but I can't see it
having the edge over SSB in intangibles. SSB is absolutely adored on
this site. I don't think Sonic has done anything to establish itself as
an absolute favorite in this match, which is what I think it would need
to counter SSB. Sonic most likely will make the match close, and even
has a chance to win, but in the end, I think SSB takes it. Kingdom
Hearts has shown against Castlevania that even being a small series, if
you have games that are bigger favorites and also more relevant today,
you still can hold your own. In Halo's case, I think its strength was
just overrated. That isn't the case with Smash Bros. <br><br>Bracket: SSB<br><br>Vote: Sonic<br><br>Prediction: SSB with 54%</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/22/2006 8:57:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321763309">message detail</a>
 | #278</td></tr>
<tr class="even">
<td>
<b>Ulti&#8217;s Analysis</b><br> <br>Before reading this, know that SSBM is my third favorite game of all time. SSB is also in my top ten. Got it? Good.<br><br>Virtually
every small and/or current-gen series has bombed in this contest. Halo
got owned. Diablo got owned. Grand Theft Auto got owned. Devil May Cry
got owned. I wrote this before Kingdom Hearts' match with Castlevania,
so I can't comment on whether or not KH bombed. 73% on a series as cult
as Harvest Moon can't be a good sign, however.<br><br>It's also worth
noting that most of the well-known "old school" series have done VERY
well in this contest. Mario, Zelda, and Final Fantasy have set and
shattered multiple records with their insane vote intake. One could
also note the same of Street Fighter, Mega Man, Castlevania, and Sonic
himself.<br><br>So why wouldn't Sonic impress? Why wouldn't Smash
Brothers bomb? SSB is only two games, and unless my eyes are playing
tricks on me, Halo and Kingdom Hearts haven't done much as two-game
series (Chain of Memories never happened). If SSB wasn't Nintendo, this
match would be far more debated than it currently is. The problem is
that Board 8 has more pathetic, concentrated Nintendo fanboyism than
anywhere else I've ever been on the internet. SSBM being the board's
chosen son certainly helps with how overrated SSB's chances are in this
match.<br><br>Oddly enough, SSB being Nintendo is exactly why SSB is
the favorite in the match. There aren't really any stats to go on here,
and the first person to bring up the Top 100 List gets kicked in the
nuts. That said, Nintendo or not, voters <i>may</i> look at SSB and go
"It's not a series". Circumstantial evidence of this being in the minds
of voters has appeared in the contest already.<br><br>Oh yeah, and name one D128 series outside of Zelda and Final Fantasy that has performed well thusfar in this contest.<br><br>Prediction:
Sonic with 55.55%; I've said from day one that Sonic is a real threat
to shock people in this contest. Board 8 sucking Nintendo off at every
turn is the only reason the match has been dismissed. Then again for
all I know, Smash might blow Sonic out of the water and prove me wrong.
Who knows.<br> <br><br><br><b>Soul&#8217;s Analysis</b><br><br> <i>Sonic defeated Devil May Cry with 70.87%<br>SSB defeated Dragon Quest with 76.37%</i><br><br>Another contest, another make-or-break match that involves none other then Sonic the Hedgehog!<br><br>Yes,
this is my second time picking Sonic to defeat a "stronger" opponent in
these contests. Why am I picking Sonic? For a few major reasons.<br><br>Ok,
we all know that there is a new voting pool on GameFAQs. They prefer
everything Nintendo to everything else. That is quite obvious by now.
What is also obvious is that Mega Man is considered Nintendo on this
site. If you disagree, then come up with a better excuse on why it
always overperforms or underperforms against a Nintendo character!
Hell, this contest shows two results that prove this already: MMX's
horrible beating by LoZ, and MM defeating MK with the utmost of ease.<br><br>What
you guys probably won't believe is that Sonic is also considered
"Nintendo" here. Well, not really "Nintendo", but in that same group of
characters. To avoid confusion, let's just say "Old-School".<br><br>Last
Summer, which characters received boosts? Luigi, Kirby, Bowser, Mario,
and just about every other Nintendo character. But, Mega Man, Knuckles
and Sonic did as well! The new voters have most likely started playing
games in the SNES/Genesis eras, that's why all these characters are a
lot stronger then before. That's why, in my belief anyway, all these
characters would SFF each other in different ways. Don't get me started
on the potential Mario/Sonic match.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/22/2006 8:58:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321763450">message detail</a>
 | #279</td></tr>
<tr class="even">
<td>
People here seem to think that Sonic's jump to 3D hasn't been the best.
I can certainly see why people would think that, but it's not the
majority's opinion. There was a chart that was posted on the board
months ago, that showed the top grossing series in the world, and lo
and behold, Sonic was right up there with the best of them. The fact of
the matter is that Sonic, even though he's not as good as before, is
still very popular right now. His 3D games continously bring in more
and more fans. And considering that Sonic now doesn't have a true home,
he can venture on just about every console and handheld known to man,
and he has. Therefore, he has a huge fanbase. SSB, on the other hand,
is stuck on the Nintendo 64 and GameCube. While both games did very
well, the fact is that the vast majority on this site has a PS and/or
PS2, where no SSB game is found. SSB's fans is limited to Nintendo,
while Sonic has no limitations.<br><br>There are two series alongside Sonic that tells me that Sonic is going to win this match: Castlevania and Mega Man.<br><br>Castlevania
faced off against Halo in the first round and defeated it with 55% of
the vote. Let it be known that I'm writing this before the KH/CV match.
Anyways, Castlevania and Sonic have a lot in common. Both are very old
series with a lot of games under their belt. Both are featured on many
different consoles and handhelds. Both have had mediocre showings in
3D. Both performed really well in the first round. Not only is
Castlevania similar to Sonic, but Halo is similar to SSB as well. Both
series only have two games. Both are exclusive to non-popular consoles
(as opposed to Sony). Both were/are supposed to win their matches. I'm
expecting a similar result here with Sonic on top.<br><br>Mega Man
faced off against Mario Kart in the first round and defeated it with
more then 58% of the vote. Arguably, there was SFF in this match so
Mario Kart could even be stronger. Most people will say that Mario Kart
is the second most popular Mario spinoff, right behind SSB. Mega Man
and Sonic would be about equal, give or take a percentage or two.
Basically, you have to ask yourself this: Is SSB 8% stronger then Mario
Kart? I seriously don't think so.<br><br>Ok, the SSB series is pretty
strong. After all, it did manage to only get 76% on Dragon Quest... Ok,
that's not that bad. Pretty average really. But since we don't know the
strength of DQ, we don't know how strong or weak it could potentially
be. What we do know is that SSBM is the strongest SSB game, and it only
got 50.2% against Starcraft. So far, every game that faced Starcraft
(not including WW) has underperformed in this contest. Halo lost to
Castlevania. Kingdom Hearts could only get 73% on pure fodder. So
basically, what's to say that SSBM is a hell of a lot stronger then
those guys? I mean, if we actually follow the Games contest, it's only
a couple of thousand votes stronger then Halo! Actually, that was
before Halo 2, so really SSBM would be even weaker then that.<br><br>So
basically, Sonic is looking like it's going to win in my eyes. The only
thing going for SSB is that it's Nintendo so it will get the Nintendo
vote (which is BS since Sonic will get a lot of those votes as well)
and that SSBM is <i>so, so strong</i> (which is BS as well). This
contest is showing hint after hint after hint about this match, and I
truly believe that Sonic will win.<br><br><b>My Prediction: Sonic wins with 52.50% of the vote.</b><br> <br><br><br><b>Leon&#8217;s Analysis</b><br> <br>Ahh,
here it is, the match that I&#8217;ve been looking forward to more than any
other. Complete validation or utter humiliation: Which will it be?
We&#8217;re about to find out.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/22/2006 8:58:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321763566">message detail</a>
 | #280</td></tr>
<tr class="even">
<td>
At the beginning, Super Smash Brothers was established as the heavy
favorite to win this match. Let&#8217;s put this into perspective: Twenty
people picked Sonic to beat Super Smash Brothers. Twenty people picked
Super Smash Brothers to upset Super Mario Brothers. I think that speaks
for itself. <br><br>Before
the contest, there was a theory going around that a series would not be
much (if any) stronger than its strongest game. I have no idea where
this mentality came from, but it seemed to be popular among Super Smash
Brothers proponents. After all, Sonic likely doesn&#8217;t have any ONE
strong game. He probably has three or four decently popular games, but
nothing that can match Super Smash Brothers Melee. <br><br>While this
may be true, Super Smash Brothers doesn&#8217;t have to beat any one Sonic
game. It has to beat EVERY Sonic game. As we can see from the way the
contest has played out so far, that&#8217;s an entirely different challenge
altogether. Both Halo games probably outclass any one Castlevania game
(and, excepting Symphony of the Night, by a wide margin), but that
didn&#8217;t give it the win. Grand Theft Auto has two runners-up and one
winner of GameFAQs Game of the Year, but it was upset by Warcraft. Mega
Man hasn&#8217;t had a game released in the Classic series in ten years while
Mario Kart has been a big game on every Nintendo system since the SNES,
but the Blue Bomber beat it handily. <br><br>So what&#8217;s the problem? In
the cases of Halo and Grand Theft Auto, the problem might be the fact
that they are recent series and haven&#8217;t really had an opportunity to
diversify their fanbase. They are also two series that receive a good
deal of anti-voting. However, I think a big problem is the fact that
it&#8217;s very difficult to displace old favorites. Nostalgia is a hard
thing to overcome, and Halo and GTA don&#8217;t have it. In Mario Kart&#8217;s
case, it&#8217;s not quite as easy to explain. It has a lot of fans, but I
suppose there aren&#8217;t a lot that would rank it as a &#8220;favorite&#8221; of
theirs. It&#8217;s more casual fun, I guess. Yet I have to wonder if any one
Mega Man game could stand up to Mario Kart 64 (I&#8217;d probably question it
now, but before, I wouldn&#8217;t have), but the sheer magnitude of the Blue
Bomber&#8217;s series (coupled with loads of nostalgia) probably helped it
over the hump. <br><br>Somebody phrased the idea very well: People
actually ARE voting based on the series, not just their favorite game.
They&#8217;re not weighing the games one at a time, but they are taking the
entire series into consideration. They&#8217;ve already got a preconceived
notion of what they like. It&#8217;s either &#8220;I love Sonic!&#8221; or &#8220;I love Super
Smash Brothers!&#8221; and the &#8220;dead weight&#8221; that the former&#8217;s series carries
probably doesn&#8217;t hurt it. Plus, I think Sonic has more diversity
because the split between the 2-D fanbase and the 3-D fanbase is large
enough to be worth mentioning. I would expect a high overlap between
the fanbase of the original Super Smash Brothers and Super Smash
Brothers Melee. <br><br>Another distinct advantage that Sonic has that
Super Smash Brothers does not is the playing rate. Like Mario, nearly
everybody has played at least one Sonic game in their life (the rate
probably isn&#8217;t quite THAT high, but I&#8217;d expect well over 90%
playability). In an ownership poll for Super Smash Brothers Melee, 20%
said they had never played it before, and an additional 7% said that it
just wasn&#8217;t their kind of game. Granted, this does not take into
account how many played the original Super Smash Brothers, but I think
this is an intangible for Sonic that COULD potentially make a
difference in a close match. I&#8217;m not guaranteeing it by any means. I
just think it&#8217;s worth considering. <br><br>One more thing to consider is the fact that people are voting for this as <i>Series</i>
Contest. There are probably quite a few out there who believe that two
games does not a series make. Heck, even the fans of the Halo boards
were saying as much. Sonic&#8217;s got several intangibles in its corner, but
Super Smash Brothers has the trump card because it&#8217;s not the one that
has to do the catching up.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/22/2006 8:59:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321763732">message detail</a>
 | #281</td></tr>
<tr class="even">
<td>
As the contest has progressed, the Sonic bandwagon has been gaining
members. As the newer series started flopping left and right, more
people began to see the light. When Sonic crushed Devil May Cry with
over 70%, it grew even larger. Super Smash Brothers did just what it
needed to do on Dragon Quest, so it obviously cannot be discounted by
any means. Mega Man beating down Mario Kart without a challenge
strengthened Sonic&#8217;s cause even more. When this match is over, just
remember that I was on it from the very beginning! I won&#8217;t be jumping
off even if it crashes! GO SONIC GO! <br><br><i>Leonhart&#8217;s Prediction</i>: <b>Sonic the Hedgehog with 52.46%</b><br> <br><br><br><b>HM&#8217;s Analysis</b><br> <br><b>Sonic the Hedgehog</b><br><br><i>Previous Matches :</i><br><br>Sonic the Hedgehog &#8211; 70.87% -- 81,627<br><br>Devil May Cry &#8211; 29.13% -- 33,550 <br><br><b>Super Smash Bros.</b><br><br><i>Previous Matches :</i><br><br>Super Smash Bros &#8211; 76.37% -- 90,789<br><br>Dragon Quest &#8211; 23.63% -- 28,092 <br><br>We
finally get to perhaps the most hotly debated match of the entire
contest; at least as far as the Stats topic is concerned. Ever since
the bracket was released, both sides have been at each others throats
trying to prove that the other was right. Interestingly, the major
difference then between the two sides was how people though the voters
would be voting. Those in favor of SSB were thinking that because SSBM
clearly beats any Sonic game that it wouldn&#8217;t have too much trouble
taking it on as a series because the &#8220;series&#8221; part would not play <i>that</i>
big of a role. On the flip side, those in favor of Sonic completely
backed the idea behind the &#8220;series&#8221; deal and how much of a role it
would end up playing. After nearly finished with round 1, and having
seen both series perform, it is extremely safe to say that the &#8220;series&#8221;
part matters &#8230; <br><br>Last round, Sonic <i>totally</i> turned heads
when the Blue Blur&#8217;s franchise went and got a fantastic 70%+ on Devil
May Cry (Poor Lopen!). It was shocking to see a series that most felt
would be decently strong to be turned into an extremely weak looking
entry. The match, more than anything, helped to prove that Sonic <i>wasn&#8217;t</i>
weak at all and that his series was here to compete. We have seen it
time and time again, but Devil May Cry is just one more series with
only a few games, came from this generation, and did not perform well
as a result. SSB, who only has two games and works off of mainly one,
was needed to have a great performance to match this considering how
much weak Dragon Quest, would be than Devil May Cry. <br><br>SSB&#8217;s
performance against Dragon Quest was not really all that impressive. It
seemed to meet expectations more than anything else, I think. It was
pretty good that it managed to hold on to the tripling, but it was
hardly the shocker that Sonic&#8217;s performance put up the day before.
SSB&#8217;s picture contained the entire cast of Nintendo characters against
what looked like the Dragon Quest VIII cast fleeing from them. Perhaps
the most important thing about that whole match is that we&#8217;ve gotten
the massive SSB cast out of the way already, so Sonic does not have to
worry about being overrun in the match picture. SSB&#8217;s match was nothing
really notable either way; if not a little unimpressive given that it
is up against a weak RPG series. The good thing for SSB in this match
was that it drew in a lot total votes and individual votes.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/22/2006 8:59:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321763853">message detail</a>
 | #282</td></tr>
<tr class="even">
<td>
Judging from what we have seen from this contest, Sonic is looking <i>really</i>
good in this match. All of the series that have been long running,
established franchises seem to be performing better than those who were
only recently created and only have a few games to their name. To cite
another match once again, Castlevania/Halo was almost a Sonic/SSB-lite.
Castlevania (Sonic) has a ton of games spanning multiple consoles and
generations whereas Halo (SSB) only has a couple of games that became
really popular this generation. Even in the current match, Mega Man is
absolutely taking down Mario Kart with absolute ease, despite Mario
Kart games as single entities being arguably stronger than any single
Mega Man game. The &#8220;series&#8221; part is really a big part of this contest. <br><br>On
top of that, people really do undercut just how strong and how popular
Sonic games really are. In the Games Contest, we got to see Sonic 2 go
out to Super Mario World in a rather devastating fashion &#8211; it got
absolutely killed. Due to this, Sonic 2 ended up being ranked alongside
games like Street Fighter II, Mortal Kombat, and Skies of Arcadia, even
though it would clearly beat those games. Adding to that, there is
reason enough to suspect that Sonic 2 is not even Sonic&#8217;s most popular
game. In an old favorite&#8217;s poll, Sonic 2 placed second to Sonic and
Knuckles and was very close with Sonic Adventure 2 before its GCN
release. There are really about two games that could end up being
stronger than Sonic 2, which I suspect is already at about 28 &#8211; 30% on
Final Fantasy VII. That essentially gives Sonic three strong games, not
to mention all of the other games that contribute to the series over
the years. <br><br>Another advantage for Sonic is the sheer diversity
that he has going for him. Some may argue that diversity hurts, but
that never made any sense. I cannot imagine someone really liking three
or four Sonic games, but have mixed opinions about the rest voting for
SSB due to the &#8220;misses.&#8221; When you think of a series you like, you
generally think of the <i>great</i> games it has going in its favor.
Anyway, you have a nice diversity among the fanbase as to which Sonic
game is the best, which era of Sonic games are the best, and so on. You
definitely have those who feel the Genesis games are the best while you
have others who feel the Adventure games are the best, and even those
who prefer Sonic Heroes and much more recent Sonic outings. Where you
might have one person not voting for, say, Sonic 2, you would have
these people voting for the Sonic series because they may dislike Sonic
2 and prefer the Adventure games. With SSB, you do not have this
diversity. The series is back primarily by <i>one</i> game &#8211; SSBM. It
is rare that you will find someone saying they love SSB and hate SSBM,
even though one may prefer the other. There is almost no diverse
fanbase brought into the picture and the strength of the series is
being pushed by SSBM. <br><br>What you basically have in this match is
the entirety of the Sonic series against SSBM. I wouldn&#8217;t imagine
anyone arguing that SSB is going to be tipping any scales or helping
out the SSB equation in any notable fashion. After having seen every
long running, established series do some damage on top of SSB lacking
games makes me feel like Sonic will be taking this one. As more matches
occur, the more confident I become in this choice, too. You need more
than one really strong game in order to perform well in a series
contest; this match should prove that more than any other. <br><br><b>Aitch Emm&#8217;s Bracket :</b> Sonic the Hedgehog<br><br><b>Aitch Emm&#8217;s Prediction :</b> Sonic the Hedgehog &#8211; 53% ; Super Smash Bros. &#8211; 47%<br><br><b>Aitch Emm&#8217;s Vote :</b> Sonic the Hedgehog</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/22/2006 9:00:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321764049">message detail</a>
 | #283</td></tr>
<tr class="even">
<td>
<b>Yoblazer&#8217;s Analysis</b><br> <br>Here we have our second of two
highly debated matches for this round. In my opinion, this one is
tougher to judge than Castlevania/Kingdom Hearts because the evidence
isn't really pointing toward one side or the other. For all intents and
purposes, we have a stalemate going in. Let's examine both contestants,
starting with Sonic.<br><br>Sonic's series was one of the starts of
Round 1, overcoming everyone's expectations and beating Devil May Cry
with nearly 71%. After that performance, eyebrows were raised and
expectations were shifted - Sonic suddenly became a contender in Round
2. But just how impressive was that performance? I know that "thinking"
can get pretty taboo during contest season, but the more I think about
it, the less amazing it seems. Like Halo, Kingdom Hearts, and SSB,
Devil May Cry is a very new series with very few games. Unlike those
others, it has zero popular games. The second game stunk and the third
sold poorly. That's easy pickings for something as well-known and
established as Sonic. However, it's now up against a whole 'nother
animal, so it better get ready.<br><br>Super Smash Bros. did a fine job
in taking all the escalating "new series + few games = instant lose"
talk and breaking it over its knee. Talk all the crap you want about
Dragon Quest, but the bottom line is this: other than the Big Three and
Resident Evil (which was up against THE fodder of the tournament), SSB
has been the only series to earn a tripling in the contest. Mega Man X
couldn't do it against Suikoden, and Kingdom Hearts (which just beat
Castlevania, casting another stone to that argument in the process)
couldn't do it against Harvest Moon, but SSB did it against Dragon
Quest. Not bad for a series with only two games. Hopefully, that
performance made people realize that Super Smash Bros. is simply
different from Halo, Kingdom Hearts, Grand Theft Auto, and Devil May
Cry - it's stronger. This is a series that is home to Nintendo's most
popular game since the holy grail of all fanboyism, Ocarina of Time.
This is a series that has the FULL backing of GameFAQs' Nintendo
fanbase, as it has shown time and time again.<br><br>As a final point,
I do believe that much of Sonic's more recent fanbase is comprised of
Nintendo fans who have come to know him through the Gamecube. Needless
to say, I doubt these new fans will be siding with the Blue Blur in
this one.<br><br>Sonic the Hedgehog<br>+ Impressive first round performance<br>+ Many games on different consoles<br>+ As a series, is very well known and respected<br>+ Branched out to more fans over the years<br>- Most of those new fans won't stick with the series in this one<br>- Questions abound if any of Sonic's individual games are that strong<br><br>Super Smash Bros.<br>+ Impressive first round performance<br>+ A beast of a title in SSBM<br>+ SSB, while somewhat forgotten, also has a large fanbase and fantastic sales<br>+ Will have the full backing of the Nintendo faithful (or so I hope, lol)<br>- The only TRUE two-game series in the contest (even Halo has a PC version and a map pack expansion)<br><br>My prediction: Super Smash Bros. def. Sonic the Hedgehog (54-46)<br> <br> <br><br><b>Lopen&#8217;s Analysis</b><br> <br>This
should be Devil May Cry, here! Alright, man, you wanna know why Devil
May Cry lost? Because people are weighting age, and just raw number of
releases heavier into the equation than I'd thought! Haven't I said
this before in a write up this round? Man, if only I knew this stuff
before the contest started, eh? Stupid well of knowledge, it won't let
me drink until it's too late!</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/22/2006 9:01:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321764224">message detail</a>
 | #284</td></tr>
<tr class="even">
<td>
Super Smash Brothers is too small a series. Yeah, it beat that Dragon
Warrior ripoff they call Dragon Quest, but who cares? Sonic's been
around for years, and although he doesn't have any "big gun" that I
thought he'd need, apparently, he <i>doesn't need it</i>. Raw numbers and nostalgia propel Sonic into an easy win here. Oh, you want stats? How about this&#8230; you think SSB beats DMC by <i>more</i>
than ~71%? Because I surely don't. The series are similar&#8230; both new&#8230;
both small amount of games. The way I see it, SSB is like DMC on SSJ3
oh my gawd powerup for seven episodes! (Find which other write up I
used this in for a prize!)<br><br>Thing is, it should've powered up for at <i>least</i>
fifteen episodes. It won't be enough. Hey, comparisons are fun. Another
good comparison here? Mega Man/Mario Kart! Yeah. Really popular
Nintendo side-series with big time launch title and fairly small number
of releases fails to meet the standard set by old school noble nine
character's flagship series! I think I'll go with that one!<br><br><b>Lopen's Prediction:</b> Mega Ma&#8230; er&#8230; Sonic with 58.12% (I'd have gone higher, but I'm a sucker for unoriginal %ages!)<br> <br> <br><br><b>HaRRich&#8217;s Analysis</b><br> <br>Predicted winner:  Super Smash Bros.<br>Earlier this contest:<br>---Sonic - 70.87% on Devil May Cry<br>---SSB - 76.37% on Dragon Quest<br>Top 100 List comparison:<br>---Sonic 2 - #38<br>---SSBM - #6<br>Best Game Ever x-stat comparison:<br>---Sonic 2 - 20.15% (may have been Something Fishy Factor'd by SMW)<br>---SSBM - 37.57% (128 Division champion)<br><br>Like MG/FE, I'm going to repost-then-edit something I said before for this analysis:<br><br>"People
keep relating Sonic/SSB as another battle of new-school VS old-school
(which it is) since CV/Halo and are thinking SSB's automatically on-par
with Halo and Sonic's automatically on-par with CV -- yeah, I said it,
that's not guaranteed. However, there are some key differences here
that people are forgetting or disagreeing with that I want to point out.<br><br>---&gt;
Yes, like Halo, SSB is a two-game pony. However, SSBM is bigger here
than either Halo game, and at least both of its games aren't confined
to the same system, so that should bring less of an overlap than Halo
did.<br>---&gt; Also like Halo, SSB is one of the newer series in the
contest. However, SSB still has two years on Halo as far as its series'
ages go.<br>---&gt; Some people would like to mention hype for Halo 3
helping it out, and so I would like to remind everybody who says such
that SSBB will be featuring Solid Snake, so promptly shut the **** up
if you think Halo 3 hype is bigger here than SSBB hype.<br>---&gt; SSB
is from Nintendo, likely the most loved company on this site. Halo is
from Microsoft, likely the second-most hated company on this site (only
behind EA).<br>---&gt; Yes, Sonic is a vast series. However,
Castlevania is as well, and its biggest game is bigger than Sonic's
biggest game (an unproven fact).<br>---&gt; Also like Castlevania,
Sonic is one of the older series in the contest. However, Castlevania
is older than the Sonic series by four years. CV also has games on
eleven major systems, whereas Sonic has had games on eight major
systems...</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/22/2006 9:02:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321764426">message detail</a>
 | #285</td></tr>
<tr class="even">
<td>
---&gt; ...Castlevania's most popular games seem to be spread out
amongst the systems, too. C:SotN is for the PS, Super Castlevania 4 is
for the SNES, C: Circle of the Moon is for GBA, the original debuted on
the NES, C: Dawn of Sorrow is for the DS...so Castlevania's spread all
over. Sonic, meanwhile, arguably has its three biggest games on the
Genesis <i>and are connectable</i>
(which is the only reason why I think S&amp;K got as popular as it did,
so you could play Sonic 2/3 with Knuckles)...so there's a big overlap
there. SA2B -- likely the best showing from Sonic since he went 3D --
lost to Time Splitters 2 and Eternal Darkness in the Gamecube 2002-GotY
poll, so there's not much room to work with if that poll is a sign of
anything. Even on the Dreamcast, SA2 (not Battle, for what it's worth)
failed to beat Phantasy Star Online <i>or</i> Shenmue 2...on Sega's own system with much weaker competition than the Gamecube's poll.  That leads me to this...<br>---&gt;
...Castlevania in general seems to have more of a following with its
newer games than Sonic does with its newer games. A decent following on
the handhelds that shouldn't be ignored are beating Sonic's handhelds
pretty bad, and its console releases this generation can't hurt,
either, as I understand they have their fans too. Sonic, though SA and
SA2B helps some, should NOT be blown out of proportion -- they've not
been great help.<br><br>Due to Sonic having several well-remembered
titles that would almost-surely outdo Castlevania's other titles not
named C:SotN, I'd still take Sonic &gt; CV in a close one...but I also
still maintain CV would never be given enough credit against Sonic
until the match actually happened. Add to it that anybody who would
take Halo &gt; SSB is crazy now, especially since it's all but official
that Starcraft over-rated its opponents, and Sonic pulling it off is a
toughy. It's definitely not impossible, but it's hardly in its favor."<br><br>Then,
just to compare SSB and Sonic (since I hear they're having a match
against each other), SSBM would beat any Sonic game, and I would almost
bet that no Sonic game could crack 40% on it. I would take SSB over
most Sonic games too, if not all of them...but that one's a bit tougher
to decide. SSB's most definitely running away with the favor if you
were to just go by Sonic's 3D-incarnations, and SSB's got the strength
to go up against the Genesis games as well. Throw 2D and 3D Sonic
together, and it could be interesting, but I'm staying with SSB.
Thinkin' DMC wouldn't decisively beat DQ helps the cause as well (if
Sonic = SSB, DQ gets 40.56% on DMC).....<br><br>Super Smash Bros. wins with 53.12%<br><br> <br> <br>Comments: The Crew favors Sonic in another 5-4 split. Let's see how this plays out...</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/22/2006 9:10:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321766282">message detail</a>
 | #286</td></tr>
<tr class="even">
<td>
<i>Needless to say, I doubt these new fans will be siding with the Blue Blur in this one.</i><br><br>I
don't know why everyone assumes that the Nintendo fanbase will
automatically side with SSB here. I can see a reasoning behind it, but
I don't think you should take it as a given.<br><br>Also, HAHA SOUL! BOXED IN!<br><br>But
now Sonic has to keep it close in victory for me to get a point. Oh
well, at least if he loses, I lose the least points for it.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/22/2006 9:11:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321766447">message detail</a>
 | #287</td></tr>
<tr class="even">
<td>
And with Lopen's extreme hit-or-miss trend in the second round, I'm not entirely sure I want him on my side...<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=152338&amp;board=8&amp;topic=29209811" class="name">Lopen</a> |
Posted 7/22/2006 9:22:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321769026">message detail</a>
 | #288</td></tr>
<tr class="even">
<td>
It's true, Leonhart.  You're <i>so</i> not getting the point in this one.  Either Sonic's gonna do what I say, or SSBM is going to win this one.  Heh heh.. <br><br>It's
interesting, most of us brought up Mega Man/Mario Kart... but does
anyone think that as a series Mario Kart might actually be more popular
than SSBM? I think it's a real possibility, now. The MK games of the
SSBM generations were pretty popular, and it has pretty popular SNES
game to back it up too. I wouldn't think MK wins by much at all if it
did, but I wouldn't count it out there. <br><br>Hmmm... maybe I should've asked this question in the stats topic instead.  <br>---<br>Raiden is still [<i>!!</i>] nominations short! <br><b><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=8&amp;topic=27664244</a></b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/22/2006 9:53:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321777073">message detail</a>
 | #289</td></tr>
<tr class="even">
<td>
Leon...<br><br>STOP FOLLOWING ME! <br><br>Jeez, not even an insane upset pick can keep you away. <br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=476641&amp;board=8&amp;topic=29209811" class="name">DaruniaTheGoron</a> |
Posted 7/22/2006 9:54:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321777193">message detail</a>
 | #290</td></tr>
<tr class="even">
<td>
I think the hype for SSBB will propel it to a small 51-49 victory. Yes,
Sonic is popular, and the newer games are doing less than expected, but
Halo is nowhere <i>close</i>
to SSB's popularity on this site. Infact, Halo 2 may have lost some of
the Halo fans because the fanbase is so split on which game is better.
That's why some people on the Halo 2 board were saying Halo shouldn't
be in this contest.<br>---<br>...little Weezing it's gonna stand up against my ****in' Charizard? Just get back on your bike and keep <br>pretending to be cool with your lame ass mohawk ****er. - phoenix1487 <b><i>Sp2k6: 22/24</i> tied for 778th</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/22/2006 9:54:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321777344">message detail</a>
 | #291</td></tr>
<tr class="even">
<td>
Sonic was MY insane upset pick from the beginning. If anything, YOU followed ME.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/22/2006 9:55:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321777445">message detail</a>
 | #292</td></tr>
<tr class="even">
<td>
<i>I think the hype for SSBB</i><br><br>And that's where you get off track.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=817211&amp;board=8&amp;topic=29209811" class="name">XxSoulxX</a> |
Posted 7/22/2006 9:57:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321777948">message detail</a>
 | #293</td></tr>
<tr class="even">
<td>
<i>I think the hype for SSBB</i><br><br>lol.<br>--- -<br>"ertyu is actually a language. For example, 'dum' is ertyunese for 'godly'." - Topaz Kitsune <br>Not changing signature until HHH pedigrees Candice through a table. 07/07/06</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=254355&amp;board=8&amp;topic=29209811" class="name">Lugia2</a> |
Posted 7/22/2006 10:03:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321779480">message detail</a>
 | #294</td></tr>
<tr class="even">
<td>
Interesting that a few of these analyses (how do you do plural?) were
written before the CV/KH bout. I personally think that match kind of
threw a wrench into the "Old&gt;New" theory.<br><br>Also:Last time you guys went 5-4, the 4 won.<br><br>Oh, and there was SFF.<br><br>And I'm betting it's going to happen again.  Go SSB!  <br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/22/2006 10:04:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321779843">message detail</a>
 | #295</td></tr>
<tr class="even">
<td>
<i>Oh, and there was SFF.</i><br><br>Wait...what?<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=395700&amp;board=8&amp;topic=29209811" class="name">HaRRicH</a> |
Posted 7/22/2006 10:12:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321781578">message detail</a>
 | #296</td></tr>
<tr class="even">
<td>
Now that CV/KH has gone down, I'll say one other thing:<br><br>Thanks
to Starcraft over-rating KH, Halo, and SC as well as willingly taking
DQ over HM if such a match ever occured, not to mention CV being as
expansive as it is and having a stronger top-game than any Sonic
game...I think that SSB being stronger than KH is both more likely and
will be more obvious than Sonic to CV. KH beating CV by 51+% makes me
feel better about this.<br><br><br><br>I do want to say that it's anybody's game though, and I think Leonhart deserves some big props if he is right on this.<br>---<br>Miss my <b>Four-Pack Of Fun</b>?  Go here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007" title="Linkification: http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007">http://boards.gamefaqs.com/gfaqs/gentopic.php?board=585007</a></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=768178&amp;board=8&amp;topic=29209811" class="name">Master Moltar</a> |
Posted 7/22/2006 10:14:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321782003">message detail</a>
 | #297</td></tr>
<tr class="even">
<td>
Yeah, I just wrote mine today. If CV had won, I'd probably would have
predicted Sonic, but yesterday gave me a little bit of faith in SSB.<br>---<br>Moltar Status: Disappointed, I lost my perfect bracket.<br>Super Mario Bros. vs. WarCraft - Bracket: <b>SMB</b> - Vote: <b>SMB</b> (22/24)</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/22/2006 10:14:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321782010">message detail</a>
 | #298</td></tr>
<tr class="even">
<td>
<i>willingly taking DQ over HM if such a match ever occured</i><br><br>I dunno if it'd be that easy of a victory, really...<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2997804&amp;board=8&amp;topic=29209811" class="name">LeonhartForever</a> |
Posted 7/22/2006 10:14:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321782074">message detail</a>
 | #299</td></tr>
<tr class="even">
<td>
But then again, I'd have no problem taking DMC over Harvest Moon.<br>---<br>SC2K6 Nominations: Squall, Roxas, Serge, Seifer, Laguna, <b>The Prince of Persia, Nightmare, Sub-Zero, Captain Falcon, Raiden</b></td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?user=2568612&amp;board=8&amp;topic=29209811" class="name">Draco1214</a> |
Posted 7/22/2006 10:15:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=29209811&amp;message=321782168">message detail</a>
 | #300</td></tr>
<tr class="even">
<td>
The difference between KH and SSB is that KH had a new release 4 months
ago that helped put it over the top. SSB hasn't had any new releases in
years.<br>---<br><b><i>Organization XIII - Number III - Xordac</i></b><br>Currently Playing - Suikoden V, Capcom vs. SNK 2</td>
</tr>

</tbody></table>
</div>


<div class="pagejumper"><ul><li class="first">Jump to Page:
      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=0">1</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=1">2</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=2">3</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=3">4</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=4">5</a></li>
<li>      6</li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=6">7</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=7">8</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=8">9</a></li>
<li>      <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=29209811&amp;page=9">10</a></li>
      </ul></div>
</div>


<div style="padding: 10px 0px 0px; float: left; clear: left;">
<iframe src="genmessage6_files/search.html" id="sponsored_iframe" marginheight="0" marginwidth="0" allowtransparency="true" background-color="transparent" target="_top" longdesc="Sponsored Matches" align="top" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>

	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="preview.php?board=8&amp;topic=29209811&amp;page=5" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="60"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div></div>
	<div id="footer">
		<div id="sitenav">
			<a href="http://dlx.gamespot.com/">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://cheats.gamespot.com/index.html">Cheat Codes</a> |
			<a href="http://forums.gamespot.com/gamespot">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/help/index.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.gamespot.com/misc/advertise.html">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/gamebuyer/index.html">Shop for Games</a> |
			<a href="http://www.gamespot.com/e3/index.html">E3 2006</a>
			</p>
		</div>
		<div id="cnetfooter">
			<p>
				<a href="http://www.bnet.com/?tag=gs.ft.no">BNET</a> |
				<a href="http://www.cnet.com/?tag=gs.ft.no">CNET.com</a> |
				<a href="http://www.cnetchannel.com/main/default.aspx?tag=gs.ft.no">CNET Channel</a> |
				<a href="http://www.download.com/?tag=gs.ft.no">CNET Download.com</a> |
				<a href="http://news.com.com/?tag=gs.ft.no">CNET News.com</a> |
				<a href="http://reviews.cnet.com/?tag=gs.ft.no">CNET Reviews</a> |
				<a href="http://shopper.cnet.com/2001-1_9-0.html?tag=gs.ft.no">CNET Shopper.com</a>
			</p>
			<p>
				<a href="http://www.gamespot.com/?tag=gs.ft.no">GameSpot</a> |
				<a href="http://www.cnetnetworks.com/advertise/properties/international.html?tag=gs.ft.no">International Media</a> |
				<a href="http://www.mp3.com/?tag=gs.ft.no">MP3.com</a> |
				<a href="http://www.mysimon.com/2001-1_8-0.html?tag=gs.ft.no">mySimon</a> |
				<a href="http://www.cnet.com/html/export/partners/index.html?tag=gs.ft.no">Partnerships</a> |
				<a href="http://www.release1-0.com/?tag=gs.ft.no">Release 1.0</a> |
				<a href="http://www.search.com/?tag=gs.ft.no">Search.com</a> |
				<a href="http://techrepublic.com.com/?tag=gs.ft.no">TechRepublic</a> |
				<a href="http://www.tv.com/?tag=gs.ft.no">TV.com</a> |
				<a href="http://www.webshots.com/?tag=gs.ft.no">Webshots</a> |
				<a href="http://www.zdnet.com/?tag=gs.ft.no">ZDNet</a>
			</p>
		</div>
		<div id="networkfooter">
		Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
	</div>
	<div id="legalfooter">
	<div id="copyright">
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
	</div>
	<div id="aboutcnet">
		<a href="http://www.cnet.com/aboutcnet/?tag=gs.ft.no">About CNET Networks</a>
	</div>
	</div>
</div>

<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script src="genmessage6_files/1020.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>