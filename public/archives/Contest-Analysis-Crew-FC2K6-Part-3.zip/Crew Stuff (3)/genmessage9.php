<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage9_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage9_files/nogs.css"></head><body linkifytime="210" linkified="6" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage9_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage9_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31144759%26page%3D8"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage9_files/advertisement.gif" alt="advertisement" height="10" width="120"></div>
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage9_files/a.xhtml" marginwidth="0" marginheight="0" hspace="0" vspace="0" bordercolor="#000000" frameborder="0" height="90" scrolling="no" width="728">
&lt;SCRIPT language='JavaScript1.1'
SRC="http://ad.doubleclick.net/adj/N2790.Gamespot/B2048313.35;abr=!ie;sz=728x90;click0=http://adlog.com.com/adlog/e/r=10153&amp;amp;s=690773&amp;amp;t=2006.10.28.12.56.06&amp;amp;o=1:&amp;amp;h=pi&amp;amp;p=&amp;amp;b=4&amp;amp;l=En_US&amp;amp;site=6&amp;amp;pt=&amp;amp;nd=&amp;amp;pid=&amp;amp;cid=&amp;amp;pp=&amp;amp;e=&amp;amp;rqid=01c17-gne-ad44540F492E4550A&amp;amp;event=58/;ord=2006.10.28.12.56.06?"&gt;
&lt;/SCRIPT&gt;
&lt;NOSCRIPT&gt;
&lt;A
href="http://adlog.com.com/adlog/e/r=10153&amp;amp;s=690773&amp;amp;t=2006.10.28.12.56.06&amp;amp;o=1:&amp;amp;h=pi&amp;amp;p=&amp;amp;b=4&amp;amp;l=En_US&amp;amp;site=6&amp;amp;pt=&amp;amp;nd=&amp;amp;pid=&amp;amp;cid=&amp;amp;pp=&amp;amp;e=&amp;amp;rqid=01c17-gne-ad44540F492E4550A&amp;amp;event=58/http://ad.doubleclick.net/jump/N2790.Gamespot/B2048313.35;abr=!ie4;abr=!ie5;sz=728x90;ord=2006.10.28.12.56.06?"&gt;
&lt;IMG
SRC="http://ad.doubleclick.net/ad/N2790.Gamespot/B2048313.35;abr=!ie4;abr=!ie5;sz=728x90;ord=2006.10.28.12.56.06?"
BORDER=0 WIDTH=728 HEIGHT=90 ALT="Click Here"&gt;&lt;/A&gt;
&lt;/NOSCRIPT&gt;
</iframe>
<img src="genmessage9_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 3
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;page=8">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31144759" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=7">Previous Page</a> |
Page 9 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3151105" class="name">KleenexTissue50</a> |
Posted 10/25/2006 11:37:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343314131">message detail</a>
 | #401</td></tr>
<tr class="even"><td>
<i>guest doesn't count. they make crappy picks!</i><br><br>Not all of us!<br>---<br>CB5 Points: <b>53/56</b>, Current Oracle placement: <b>22/165</b><br>Now playing: Okami
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/26/2006 12:24:10 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343320384">message detail</a>
 | #402</td></tr>
<tr class="even"><td>
[This message was deleted at the request of a moderator or administrator]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=304351" class="name">Mac Arrowny</a> |
Posted 10/26/2006 12:25:50 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343320567">message detail</a>
 | #403</td></tr>
<tr class="even"><td>
<i>Guest for this battle is just downright stupid.</i><br><br>Hah! Not even close to as stupid as those picking Squall &gt; Snake!<br>---<br>99% of people just make up statistics on the spot. If you are part of the 1%, post this in your sig
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/26/2006 12:29:04 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343320978">message detail</a>
 | #404</td></tr>
<tr class="even"><td>Snake support tends to fluctuate immensely though.
Snake could have gotten anywhere from 65% to 50% against Squall based
on how random he is supported. Pretty wide margin for a non SFF match
between a character from the noble nine and a top tier rest of the pack
character.<br><br>Sonic
has always been reasonably consistant vs non noble nine contenders.
Anyone selecting Vincent over Sonic was living an absolute dream.<br>---<br>Despite Karma Hunter's warnings, I doubted what should have been obvious to all. Only the Snake is the true hero! <b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=304351" class="name">Mac Arrowny</a> |
Posted 10/26/2006 12:31:51 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343321283">message detail</a>
 | #405</td></tr>
<tr class="even"><td>
<i>Sonic has always been reasonably consistant vs non noble nine
contenders. Anyone selecting Vincent over Sonic was living an absolute
dream.</i><br><br>Look at Sonic vs. Aeris/Zero and tell me that again.<br>---<br>99% of people just make up statistics on the spot. If you are part of the 1%, post this in your sig
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/26/2006 12:35:25 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343321705">message detail</a>
 | #406</td></tr>
<tr class="even"><td>
MM's performance this year proves Zero has weakened, back when Sonic
faced Zero, Z had quite a bit of momentum going for him. Aeris was very
strong, until she mysteriously vanished after some promising
performances.<br>---<br>Despite Karma Hunter's warnings, I doubted what should have been obvious to all. Only the Snake is the true hero! <b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=304351" class="name">Mac Arrowny</a> |
Posted 10/26/2006 12:38:19 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343322048">message detail</a>
 | #407</td></tr>
<tr class="even"><td>
And? Vincent was almost certainly stronger than Aeris last year, and
has since had DoC and AC, not to mention a potential Square shift with
KH2.<br>---<br>99% of people just make up statistics on the spot. If you are part of the 1%, post this in your sig
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=254355" class="name">Lugia2</a> |
Posted 10/26/2006 5:38:49 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343340764">message detail</a>
 | #408</td></tr>
<tr class="even"><td>
HM didn't pick Vincent?!?  And the guest did!?!?<br><br>Great!
HM sound hollow without his insane picks (Star Ocean&gt;Pokemon!)! And
the Guest prevents the Sonic sweep in the crew that practically
GUARANTEES a Vincent win (see Castlevania&gt;KH last year)!<br><br>Oh well.  Vincent is rather close, anyway.  Come on, Vinny!  Kill my bracket!<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/26/2006 11:53:27 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343370579">message detail</a>
 | #409</td></tr>
<tr class="even"><td>
<i>Aitch Emm&#8217;s Bracket: <b>Sonic the Hedgehog </b></i><br><br>Whoa, hold the phone. What happened to Ganondorf &gt; Male Bracket?<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 5</i>: Darkwing Duck (4-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/26/2006 3:36:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343407192">message detail</a>
 | #410</td></tr>
<tr class="even"><td>
It was all a lie!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sonic vs. Vincent - Bracket: <b>Sonic</b> - Vote: <b>Sonic</b> (50/56)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/26/2006 3:40:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343408103">message detail</a>
 | #411</td></tr>
<tr class="even"><td>
Ryu..........................41.96% 50342<br>Mega Man...............58.04% 69626<br>TOTAL VOTES....................119968<br><br>58.81% of the brackets predicted this match correctly.<br><br>Ryu
recovers from his less-than-stellar performance last year by once again
breaking 40% on a Noble Niner. Well...it's either that, or something is
really wrong with Mega Man this year.<br><br>Today, Vincent is doing very well against Sonic.<br><br>Lopen - 8<br>KH - 8<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>HM - 7<br>Moltar - 7<br>Ulti - 6<br>Yoblazer - 2<br><br>About time Ulti gets another point...<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sonic vs. Vincent - Bracket: <b>Sonic</b> - Vote: <b>Sonic</b> (50/56)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 10/26/2006 3:47:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343409652">message detail</a>
 | #412</td></tr>
<tr class="even"><td>
<i> From: THEJackSparrow </i><br><i><i>Aitch Emm&#8217;s Bracket: <b>Sonic the Hedgehog </b></i><br><br>Whoa, hold the phone. What happened to Ganondorf &amp;gt; Male Bracket?</i><br><br>He only had that because thought TP would be released earlier.<br>---<br>CB06 - Score: <b>52/56 </b>Rank: <b>Tied - 276th </b>Yesterday's Pick:<b> Mega Man</b> <br>Today's Pick: <b>Sonic</b> Tomorrow's Pick: <b>Kirby</b> Losses: <b>Cortana, Ganon, Zero, MC</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/26/2006 3:53:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343410782">message detail</a>
 | #413</td></tr>
<tr class="even"><td>
<i>Whoa, hold the phone. What happened to Ganondorf &gt; Male Bracket?</i><br><br>Whoops. That was my mistake there. =p<br><br>---<br><i>The Master Sword is the most sought-after blade in Hyrule. He who wields it carries with him the hope of the kingdom.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/26/2006 7:27:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343460049">message detail</a>
 | #414</td></tr>
<tr class="even"><td>
Oh please... Vincent &gt; Sonic had far more credence than any silly
Squall &gt; Snake picks. Don't even try to argue against that. Sonic
getting a mere 52% here should be more than enough evidence that
Vincent &gt; Sonic was a very possible upset choice. Did I think it was
happening? No. But it damn well could have, stop acting like a dick.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 10/26/2006 7:29:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343460488">message detail</a>
 | #415</td></tr>
<tr class="even"><td>
Are you Mac Arrowny? o.O<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/26/2006 8:14:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343471231">message detail</a>
 | #416</td></tr>
<tr class="even"><td>
I agree with EC's sentiment, though I still say Solid/Squall was more
plausible pre-contest than Sonic/Vincent as far as the upset goes.
Granted, their performances say otherwise...but Vincent/Squall was real
close last year and they would probably still have a close match this
year (in Vincent's favor still and probably by a little bit more this
time, but they probably both boosted about the same). Then throw in
that Solid has been the weakest NN'er the past two contests and Squall
&gt; Bowser last year was possible...<br><br>...again,
I agree Vincent &gt; Sonic was plausible and the percentages say
otherwise to me, but Solid/Squall still was more up for debate
pre-contest than Sonic/Vincent methinks.<br>---<br><a class="linkification-ext" href="http://wemajor12.myrockinprofile.com/" title="Linkification: http://wemajor12.myrockinprofile.com/">http://wemajor12.myrockinprofile.com/</a><br>Next celebrity I hope to out-rank:  Adam Sandler (#1)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/26/2006 8:16:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343471802">message detail</a>
 | #417</td></tr>
<tr class="even"><td>
Honestly, Vincent &gt; Sonic was the best preseason contest pick to
overthrow the Noble Nine if only because of the very real chance of
Snake overperforming on Squall. <br><br>Which is exactly what happened. No telling how close Squall would've gotten without it though.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 5</i>: Darkwing Duck (4-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/26/2006 8:41:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343478116">message detail</a>
 | #418</td></tr>
<tr class="even"><td>
Wow, for what should be a close match, one side of Kirby/Luigi is already favored by the Crew.<br><br>I don't have Yo's yet, so it could end up as nearly split, or a big majority.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sonic vs. Vincent - Bracket: <b>Sonic</b> - Vote: <b>Sonic</b> (50/56)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/26/2006 8:42:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343478353">message detail</a>
 | #419</td></tr>
<tr class="even"><td>
Well, there are a few major reasons why one side would be favored over
the other. Of course, if it's the other side that's favored, I'll be
surprised.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 5</i>: Darkwing Duck (4-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/26/2006 8:43:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343478514">message detail</a>
 | #420</td></tr>
<tr class="even"><td>
It's hard to debate that happened now, yeah, but for all we knew Squall
could have just been that weak back in 2k2 and KH really did that much.
Also, for Squall growing as strong as he did since 2k2, I would have
throught he could have built up enough favor in their shared fanbase to
prevent much SFF (especially since KH2 is still hot and probably still
GotY).<br><br>Oh, SFF, ye are a tricky ole' bastard.....<br>---<br><a class="linkification-ext" href="http://wemajor12.myrockinprofile.com/" title="Linkification: http://wemajor12.myrockinprofile.com/">http://wemajor12.myrockinprofile.com/</a><br>Next celebrity I hope to out-rank:  Adam Sandler (#1)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/26/2006 8:44:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343478832">message detail</a>
 | #421</td></tr>
<tr class="even"><td>
I honestly didn't think twice about Snake &gt; Squall. I'm not sure
why, it just never entered my head tha twe could see an upset there.
Not enough hype for Squall, I guess. I've been scared ****less about
today's match though since the bracket first came out. Not expecting
Sonic to lose, but just knowing that there was definitely at least a
possibility.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/26/2006 8:45:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343479111">message detail</a>
 | #422</td></tr>
<tr class="even"><td>
<i>It's hard to debate that happened now, yeah, but for all we knew Squall could have just been that weak back in 2k2</i><br><br>*looks at all the characters he's around in the 2002 stats*<br><br>No.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 5</i>: Darkwing Duck (4-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3685859" class="name">PartOfYourWorld</a> |
Posted 10/26/2006 8:46:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343479328">message detail</a>
 | #423</td></tr>
<tr class="even"><td>
Just sent mine in.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/26/2006 8:50:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343480416">message detail</a>
 | #424</td></tr>
<tr class="even"><td>
<b>Blast Division:</b> <i>Round 2 - Match 46</i> &#8211; (3)Kirby vs. (2)Luigi<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Kirby</b><br>Round 1 &#8211; 61.70% vs. The Prince (38.30%)<br><br>I really hope this is The Prince just showing his uber-strength.<br><br><b>Luigi</b><br>Round 1 &#8211; 53.71% vs. Zero (46.29%)<br><br>Zero lost to Luigi?! Ouch, just ouch.<br><br>Before
this match, I said that if Luigi won, I&#8217;d feel much better about Kirby
winning this four-pack than I would if he faced Zero. Well, Luigi won,
and with ease too. Do I feel better though?<br><br>Honestly, no, I
don&#8217;t. If Luigi was going to win, I would have predicted it as close,
not an Ulti-style blowout turned into nearly a 54% win for the Green
Missile. It seems the Luigi of 2005 is back, and Kirby is next in his
sights.<br><br>Now, Kirby beats Zero in 2005 by a little more than
Luigi did now. But still, with Bowser and Tidus doing worse than
expected against their opponents, and Kirby following suit, could it be
proof that the Dream Division was overrated in 2005? OH LAWD, I HOPE
NOT. At least Ryu may say that it was legit and Bowser just
overperformed on him. But, it was awesome seeing Bowser and Kirby so
high. Kirby&#8217;s numbers on Prince aren&#8217;t that hot, so let&#8217;s just hope
he&#8217;s stronger than we thought.<br><br>Yeah, the deck is really stacked
against Kirby here. Kirby-choosers have to hope that either The Prince
was a strong mid-carder (Rikku-2005 level at least, assuming Ryu-2005
is legit), Zero fell from 2005 (as if he didn&#8217;t look bad enough in
2005), and Luigi hasn&#8217;t boosted much more since 2005. Oh, and also that
Kirby himself isn&#8217;t overrated from 2005. There&#8217;s a chance for all of
those, so Kirby isn&#8217;t out of this match yet!<br><br>Bah, I can&#8217;t
believe this is the same Luigi who was outperformed by Jill against
Squall and got spanked against Yoshi. Speaking of Yoshi, if Kirby can
pull the same stunt he did on Bowser (as in, overperform/rSFF him),
then he may have a chance. Of course, Bowser could have just
over-performed on Snake&#8230;but that makes Ryu look way too bad, and as we
saw against Mega Man, it could have been there was just something wrong
with Ryu last year.<br><br>Anyway, as much as it pains me, there is
just a bit more favoring Luigi at this point, so I&#8217;m predicting him as
the winner. I hope I&#8217;m wrong and we get Crew Curse&#8217;d and Kirby beats
the crap out of that Loser Luigi. Screw being unbiased, Kirby
&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;Luigi<br><br><b>Moltar&#8217;s Bracket Says:</b> Luigi will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Kirby: 49% - Luigi: 51%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>"You people almost convinced me to pick Zero. Glad I went with common sense. Oh, and Luigi is beating Kirby too." -red13n<br><br>He
gets no credit for it because everyone is obsessed with his user level,
but red13n is every bit as good at these things as yoblazer is.<br><br>Anyway, yeah, I don't see how Kirby can win this.<br><br>Prediction: Luigi with 54.35%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br> <b>Kirby</b><br><br><i>Previous Matches:</i><br><br>Kirby &#8211; 61.7% -- 75,247<br><br>The Prince of Persia &#8211; 38.3% -- 46,729 <br><br><b>Luigi</b><br><br><i>Previous Matches:</i><br><br>Luigi &#8211; 53.71% -- 69,851<br><br>Zero &#8211; 46.29% -- 60,207 <br><br>Luigi&#8217;s
run in this contest may just be the best one we&#8217;re going to see. After
being counted out by nearly everyone against Zero, he came out strong
and beat the MMX hero with ease. He heads into round 2 against what
appears to be a very disappointing Kirby after failing to impress
against The Prince of Persia. In fact, the entire Dream Division looked
unimpressive as a whole last round, which may be the key to Luigi&#8217;s
victory.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/26/2006 8:51:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343480590">message detail</a>
 | #425</td></tr>
<tr class="even"><td>One of the most important aspects of this match is
SFF, which will likely be the deciding factor one way or another. Some
have suggested that Kirby may have been able to rSFF Bowser after that
close encounter, perhaps making him overrated. If that were the case,
the possibility of Kirby getting rSFF against Luigi seems pretty likely
(Yoshi SFFed Luigi, Bowser didn&#8217;t appear to get rSFFed by Yoshi, etc.).
However, I think the man in green should be able to hold off against
getting SFFed here&#8230;call it a hunch! <br><br>Luigi&#8217;s
performance last round spoke wonders for his strength, I think. Zero
has a long history of doing well in these contests and he&#8217;s undoubtedly
a strong contestant. There is some controversy, though, on the
possibility of Zero dropping. If that is the case, Kirby is looking
good assuming he isn&#8217;t overrated&#8230;and it wasn&#8217;t mostly Luigi
dropping&#8230;gah! I have <i>no</i> idea what to make of this match. All I know is that I&#8217;m in Luigi&#8217;s corner as I was last round. DO NOT DOUBT THE PLUMBER <i>!!</i> <br><br><b>Aitch Emm&#8217;s Bracket:</b> Luigi<br><br><b>Aitch Emm&#8217;s Prediction:</b> Luigi &#8211; 52% ; Kirby &#8211; 48%<br><br><b>Aitch Emm&#8217;s Vote:</b> Luigi<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>It's
a pure SFF match between two well-matched foes, so just pick a side and
hope for the best. Personally, I'm not sure what Kirby did to pull so
close to Bowser last year, but I have my doubts about him ever actually
defeating one of the bigger Mario characters. Aside from that, Luigi
also had the infinitely more impressive first round performance, so I'm
taking him for the win. HEAD MISSILE.<br><br>My prediction: Luigi def. Kirby (53-47)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Wow, Luigi. What are you doing here? This was supposed to be the epic Kirby/<i>Zero</i>
clash! Well, I was really unsure on Kirby/Zero, though I had Kirby.
However, in Kirby/Luigi, I have less concern for Kirby's chances.<br><br>See,
the main reason you'd consider taking Zero over Kirby is because you
think what he did against Bowser last year was a fluke. Or maybe
because you think what Bowser did against Snake was a fluke. And yeah,
that may very well be. People think Kirby did some crazy "reverse
Nintendo SFF" on Bowser, or something, or that Bowser did better
because of the infamous Solid ****.<br><br>But with Luigi? None of that
really applies. Say there was "reverse Nintendo SFF" in Bowser/Kirby.
What's going to save Luigi from Kirby's wrath? Bowser's higher on the
Mario/Nintendo pecking order from everything we've seen so far. Think
Bowser did too well against Snake? Well, doesn't really matter&#8230; the
only match that matters here is Kirby/Bowser from last year. Bowser
&gt; Luigi, Kirby almost beat Bowser, Kirby will beat Luigi.<br><br><i>Suck it up, Kirby!</i> ("It" being that fool Luigi!)<br><br><b>Lopen's Prediction:</b> Kirby with 53.77%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>KIRBY</b><br><br><i>"Haiii!"</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 17th Place [25.54%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 25th Place [25.49%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 22nd Place [26.61%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 13th Place [32.06%]<br><br>Kirby has a ho-hum match against the Prince, though I choose to believe the Prince is surprisingly strong. <i>Aw yeah.</i><br><br><b>LUIGI</b><br><br><i>"I'm-a Luigi! Numba one!"</i><br><br>Summer 2003 Contest<br>Extrapolated Strength --- 30th Place [24.43%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 30th Place [22.96%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 21st Place [28.70%]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/26/2006 8:52:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343480828">message detail</a>
 | #426</td></tr>
<tr class="even"><td>
Redemption. That's the only way I can describe Luigi's match against
Zero last round, and with his victory the 60-40 destruction at the
hands of Squall is all but forgotten. Now he has but one last hurdle to
cross, and that is the ceiling that is the second round for him. Three
second round defeats have dogged Luigi, and now he faces a very
winnable opponent in Kirby. So...let's see how far he's really come.
WOO LUIGI<br><br><i>Notable Releases Since Last Appearance</i><br><br>Kirby: Super Smash Brothers Brawl Trailer (Internet)<br>Luigi: New Super Mario Brothers (DS)<br><br><i>Upcoming Releases</i><br><br>Kirby: Super Smash Brothers Brawl (WII)<br>Luigi: Super Smash Brothers Brawl (WII)<br><br>And
to think, last round all I could think about was how stupid I was for
not having Zero in the Sweet Sixteen. Kirby just about saved me, though
Luigi could ruin me again. Still, I like Kirby's chances here. Ryu is
showing us that it takes real strength to have a good performance on
him, and Bowser did the best on him out of anyone. Snake/Bowser looks
the most legit that it has in a while. Meanwhile, there's still the
matter of Bowser/Kirby, which is odd...but if anyone could rSFF other
Nintendo, it would be Kirby (or Mario, heh). 48% on Bowser is something
I can't see Luigi getting, directly or indirectly. And to reflect that,
I refuse to jump ship with my bracket this time. I'm sticking with
Kirby. Go puffball.<br><br>(also WTF Kirby just dominates that picture)<br><br>Karma Hunter's Vote: Kirby. Because vaccuuming pink stuff &gt; vacuum cleaners<br><br><b>Karma Hunter's Krazy Prediction: Kirby with 52.46%.</b><br><br>Give
Bowser the proportion that Yoshi got on Luigi in 2005, then just give
Kirby the advantage based on 'direct' performances. Uh, simple, right?<br><br><b>Upset Potential: 35%<br><br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br><br>Kirby
might have overperformed on Bowser, but there's no guarantee it was
rSFF. And even if it was, there's no guarantee that Luigi will work
with the same thing. Luigi is a wild card now...and for all I know this
will be child's play for him after Zero. Oh well, not jumping ship this
time, but let's at least reflect the fact that it could happen <i>!!</i><br><br>Upset Prediction: Luigi with 54.38%<br> <br> <br> <br><b>Guest&#8217;s Analysis</b> - <i>transience</i><br><br>this match is completely confusing to me - both characters have reasons to win. let's start with their contest history:<br><br>Kirby:<br><br>the
idea of him being a bigtime underdog to Tidus seems like so long ago.
thanks to Kirby's surprising performance on Bowser, he's now thought of
as a serious threat to anyone but the Noble Nine. a lot of people
thought Bowser was the strongest non-NN character and Kirby got 48% on
him. that's pretty good. they also share a common opponent in Squall -
Luigi got 40% while Kirby got 45.<br><br>Luigi<br><br>Luigi had a very
impressive first round match vs. Zero, taking a commanding lead and
never looking back. Luigi has seemingly gone from a disappointing
midcarder to a character that can beat near-elites with ease. the
Nintendo Boost has benefitted Luigi more than any other character.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=254355" class="name">Lugia2</a> |
Posted 10/26/2006 8:52:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343480843">message detail</a>
 | #427</td></tr>
<tr class="even"><td>Kirby Luigi...How bad is the SFF? We all know that
his is going to turn into a MM/MK anyway, with the winner gaining due
to SFF. <br><br>On
that note, Luigi might pull a Mario by rSFFing the stronger character:
Kirby. But how would we know it was rSFF? This will be fun, anyway.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/26/2006 8:52:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343480871">message detail</a>
 | #428</td></tr>
<tr class="even"><td>
as far as I'm concerned, Luigi is the stronger of the two. Kirby has
two different reasons to be overrated - potential rSFF on Bowser and
Snake getting a sprite picture in his match against Bowser. every
performance from the Dream Division has been average at best this year
- Bowser, Kirby, Tidus and Rikku. the only exception was Ryu's match
with Mega Man yesterday and he did worse than expected vs. Kratos.
expectations aren't always right, but you can't help but notice a
pattern.<br><br>but
if Kirby can rSFF Bowser, why wouldn't he able to do the same thing to
Luigi? after all, Luigi lost to a guy (Yoshi) that did worse on Bowser
than Kirby did. yeah it was two years ago, but the point still stands
that the Mario fanbase goes Bowser &gt; Yoshi &gt; Luigi. Yoshi doesn't
look to be any stronger than Luigi at this point at all either - if
Yoshi SFFed Luigi, why couldn't Kirby?<br><br>in the end, one of two things will happen:<br><br>1.) Luigi will show off his newfound strength and take it to Kirby<br>2.) Kirby will SFF him just like he did to Bowser<br><br>I
think Luigi is more of a "fan favourite" than Bowser is, for whatever
reason. the famous Mario Character poll seems to suggest the same:<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2328" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2328">http://www.gamefaqs.com/poll/index.html?poll=2328</a><br><br>I
don't take too much from this, but Bowser places pretty low for a
character with significant strength. it's possible that he's just a
"leech" and gets all his strength from simply being the bad guy in
Mario, just like Ganondorf does with Zelda. if so, I expect Luigi to
take this one relatively easily. Kirby has a great shot of winning this
match too, but either way I don't expect a close one. the Nintendo
fanbase is going to decide on one of these characters and I think it
will be Luigi.<br><br>transience's prediction: Luigi with 55.76%<br> <br> <br><br>Crew Consensus: 5-2 in favor of Luigi. Ouch, but I hope that dynamic duo of KH and Lopen are right on this one!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/26/2006 8:55:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343481462">message detail</a>
 | #429</td></tr>
<tr class="even"><td>
<i>It's hard to debate that happened now, yeah, but for all we knew
Squall could have just been that weak back in 2k2 and KH really did
that much</i><br><br>Sure... if you're insane and think a cameo can boost people through the goddamn roof!<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 10/26/2006 8:55:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343481533">message detail</a>
 | #430</td></tr>
<tr class="even"><td>
<i><br>He gets no credit for it because everyone is obsessed with his user level,</i><br><br>Or it could be because he's a complete jerk about it. yo at least is an excellent sport.<br>---<br>This was Ed Bellis, servant to the mighty Guru <b>Z1mZum</b>. Congrats, buddy!<br><a class="linkification-ext" href="http://www.thepetitionsite.com/takeaction/754046421" title="Linkification: http://www.thepetitionsite.com/takeaction/754046421">http://www.thepetitionsite.com/takeaction/754046421</a> - For the children.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/26/2006 8:56:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343481871">message detail</a>
 | #431</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Here it is, my first of 2
make-or-break matches. Putting Luigi through to the 3rd round was
pretty risky, considering the board expected Zero to beat him in the
first round. Well, much to many's suprises, but not mine, Luigi beat
Zero, and now he faces Kirby.<br><br>Come on....if Luigi beat Zero,
he'll beat Kirby, right? Zero is almost definitely stronger than Kirby.
But you never know the wacky way that SFF may work. My anti-Kirby bias
may be blinding me here, but I just don't see how the SFF would fall to
Kirby's favor.<br><br>My vote: Luigi<br>My bracket: LUIGI<br>My prediction: Luigi with 57%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/26/2006 8:56:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343481937">message detail</a>
 | #432</td></tr>
<tr class="even"><td>
'tis true - if red didn't have that 52 next to his name, people would
think of him like they think of Valvoras or some of the others.<br>---<br>zizzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/26/2006 8:56:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343481978">message detail</a>
 | #433</td></tr>
<tr class="even"><td>
<i>He gets no credit for it because everyone is obsessed with his user
level, but red13n is every bit as good at these things as yoblazer is.</i><br><br>Yeah,
it couldn't be because he goes out on limbs after the match result is
already secure and he acts like an ass about it. Nope, definitely not.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/26/2006 8:57:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343482020">message detail</a>
 | #434</td></tr>
<tr class="even"><td>
darn you bellis<br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/26/2006 8:58:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343482390">message detail</a>
 | #435</td></tr>
<tr class="even"><td>
...Okay, the other got favored. Kirby has all of the intangibles in his corner, as far as I'm concerned.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 5</i>: Darkwing Duck (4-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/26/2006 9:00:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343482917">message detail</a>
 | #436</td></tr>
<tr class="even"><td>
lol leon trotsky<br><br>I agree though..... I
mean before the contest everyone was saying it was between Zero and
Kirby, and when Zero looks like he's a bust, uhm, wait, uhh.... no no
no no no, Luigi now! I think it's as much of a toss up as you're going
to get personally, but the huge shift from Luigi being the underdog out
of the 3, to the favorite after his match with Zero is a bit surprising.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/26/2006 9:01:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343483199">message detail</a>
 | #437</td></tr>
<tr class="even"><td>
Whoa, the only guy siding with Kirby besides me is <i>Lopen?</i><br><br>...damn you people.<br>---<br><b>*kills self<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 10/26/2006 9:01:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343483264">message detail</a>
 | #438</td></tr>
<tr class="even"><td>
...thinking about it, this match is so terribly confusing. &gt;_&lt;<br>---<br>This was Ed Bellis, servant to the mighty Guru <b>Z1mZum</b>. Congrats, buddy!<br><a class="linkification-ext" href="http://www.thepetitionsite.com/takeaction/754046421" title="Linkification: http://www.thepetitionsite.com/takeaction/754046421">http://www.thepetitionsite.com/takeaction/754046421</a> - For the children.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 10/26/2006 9:02:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343483345">message detail</a>
 | #439</td></tr>
<tr class="even"><td>
You're on your own for this one, teammate!<br>---<br>This was Ed Bellis, servant to the mighty Guru <b>Z1mZum</b>. Congrats, buddy!<br><a class="linkification-ext" href="http://www.thepetitionsite.com/takeaction/754046421" title="Linkification: http://www.thepetitionsite.com/takeaction/754046421">http://www.thepetitionsite.com/takeaction/754046421</a> - For the children.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/26/2006 9:02:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343483374">message detail</a>
 | #440</td></tr>
<tr class="even"><td>
I can't see Zero dropping that much. either Luigi pulled some weird SFF on him or he's legit. plus Yoshi did great.<br>---<br>zizzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/26/2006 9:03:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343483695">message detail</a>
 | #441</td></tr>
<tr class="even"><td>
Sure, Yoshi looked great, but I still think Kirby can take him, honestly.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 5</i>: Darkwing Duck (4-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/26/2006 9:03:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343483709">message detail</a>
 | #442</td></tr>
<tr class="even"><td>
<i><b>Moltar&#8217;s Bracket Says:</b> Luigi will win.<br><br><b>Aitch Emm&#8217;s Bracket:</b> Luigi</i><br><br>I distinctly remember the whole Crew having Zero in their bracket....<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=640243" class="name">Big Bob</a> |
Posted 10/26/2006 9:03:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343483839">message detail</a>
 | #443</td></tr>
<tr class="even"><td>
[This message was deleted at the request of the original poster]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/26/2006 9:04:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343484002">message detail</a>
 | #444</td></tr>
<tr class="even"><td>
Luigi is legit, I have no doubts about that. Kirby's going to have to pull a, well, Kirby here to win. I have a feeling he can.<br>---<br><b>*kills self<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/26/2006 9:05:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343484195">message detail</a>
 | #445</td></tr>
<tr class="even"><td>
yeah, I won't be amazed if he pulls a Kirby. I just hate to count on something like that, ya know?<br>---<br>zizzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/26/2006 9:05:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343484266">message detail</a>
 | #446</td></tr>
<tr class="even"><td>
<i>I agree though..... I mean before the contest everyone was saying it
was between Zero and Kirby, and when Zero looks like he's a bust, uhm,
wait, uhh.... no no no no no, Luigi now! I think it's as much of a toss
up as you're going to get personally, but the huge shift from Luigi
being the underdog out of the 3, to the favorite after his match with
Zero is a bit surprising.</i><br><br>Castlevania syndrome aka let's all hop on the upset train. If only Luigi would have sweeped, then Kirby would have been <i>guaranteed</i> a win. <br><br>Oh,
and I have Kirby in my bracket, but I don't feel as good about it as
you and Leon. I'm hoping Kirby pulls something awesome of though, and
Luigi once again flops to a strong Nintendo character.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sonic vs. Vincent - Bracket: <b>Sonic</b> - Vote: <b>Sonic</b> (50/56)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/26/2006 9:06:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343484410">message detail</a>
 | #447</td></tr>
<tr class="even"><td>
<i>I can't see Zero dropping that much. either Luigi pulled some weird SFF on him or he's legit. plus Yoshi did great.</i><br><br>Eh...
Drop Zero 1.5% and boost Luigi 1% and Kirby should still take it
statistically even if you think he's overrated. Calling for 55%, now
that's insanity! Of course it'll probably be riddled with SFF, and
there's a good chance it could happen, but there's no logical reasoning
I can follow that ends up with Luigi with 55%. And in the same breath,
I don't expect the match to be all that. 53%+ for either person, and I
give both about an equal shot of winning. Nothing would make me happier
than pure Kirby domination though.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/26/2006 9:07:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343484574">message detail</a>
 | #448</td></tr>
<tr class="even"><td>
I mean, we've already seen the Blue Bomber perform less than
spectacularly in the first two rounds, so I'm taking what Luigi did to
Zero with a grain of salt.<br><br>Plus,
I can't get over that match with Bowser. Even if you call it a fluke,
you can't deny the possibility that Kirby flukes again.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 5</i>: Darkwing Duck (4-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/26/2006 9:08:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343484717">message detail</a>
 | #449</td></tr>
<tr class="even"><td>
I'd laugh if Kirby dominated.. Luigi, embarassed yet again. but I
really don't expect that to be the case. like I said, I won't be
amazed, but I have trouble expecting a SFF match to be really really
close. Squall/Vincent is the exception.<br>---<br>zizzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3685859" class="name">PartOfYourWorld</a> |
Posted 10/26/2006 9:08:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343484758">message detail</a>
 | #450</td></tr>
<tr class="even"><td>
Here's a sad little tidbit of information: even if Moltar and I wind up
with the closest picks today, I technically still will not have a
single top crew pick. All three of my points will be earned through
ties (two with Moltar, one with HM).
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=7">8</a></li>
<li>9</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=9">10</a></li>
</ul>
</div>


</div>
<img src="genmessage9_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage9_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31144759&amp;page=8" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage9_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>