<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage6_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage6_files/nogs.css"></head><body linkifytime="141" linkified="8" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage6_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage6_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31144759%26page%3D5"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage6_files/advertisement.gif" alt="advertisement" height="10" width="120"></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage6_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage6_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 3
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;page=5">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31144759" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=4">Previous Page</a> |
Page 6 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=6">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=1502018" class="name">ShatteredElysium</a> |
Posted 10/22/2006 6:48:08 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342486811">message detail</a>
 | #251</td></tr>
<tr class="even"><td>
I fancy doing a guest write-up at some point since I'm conveniently
shacked up at home, unable to walk. Damn you drunken injuries! <br>---<br><b>Contest Score:</b> 45/48 <b>Todays Pick:</b> Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 10/22/2006 6:52:17 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342487010">message detail</a>
 | #252</td></tr>
<tr class="even"><td>
I demand exclusive rights for the guest spots of all of Ashe's matches next contest. &gt;_&gt;<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/22/2006 4:00:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342573659">message detail</a>
 | #253</td></tr>
<tr class="even"><td>
Chun Li..................55.54% 64126<br>Lara Croft .............44.46% 51338<br>TOTAL VOTES..................115464<br><br>33.13% of the brackets predicted this match correctly.<br><br>Chun-Li started off strong, but Lara fought back, and in the end, we got this result. Makes Lara look pretty good...<br><br>Today, Snake is beating Squall with ease.<br><br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Moltar - 7<br>KH - 7<br>Lopen - 7<br>HM - 6<br>Ulti - 5<br>Yoblazer - 2<br><br>HM with another point.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Snake vs. Squall - Bracket: <b>Snake</b> - Vote: <b>Snake</b> (44/48)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2665492" class="name">XIII_rocks</a> |
Posted 10/22/2006 4:01:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342573772">message detail</a>
 | #254</td></tr>
<tr class="even"><td>
lol Lara underestimaters &gt;_&gt;<br>---<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738</a> Sign plz<br><b>AC2K6 Score</b>: 46/48 <b>Today:</b> Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/22/2006 6:36:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342613062">message detail</a>
 | #255</td></tr>
<tr class="even"><td>
Jill Valentine vs. Princess Peach<br>+7 Mo<br>+6 Guest<br>+5 HM<br>+4 KH<br>+3 Ulti<br>+2 Yo<br>-1 Lo<br><br>Zelda vs. Terra Branford<br>+7 Guest<br>+6 HM<br>+5 Yo<br>+4 Ulti<br>+3 Mo<br>+2 KH<br>+1 Lo<br><br>KOS-MOS vs. Aeris Gainsborough<br>+7 Guest<br>+6 Mo<br>+5 Ulti<br>+4 HM<br>+3 Yo<br>+2 Lo<br>+1 KH<br><br>Yuna vs. Joanna Dark<br>+7 Mo<br>+6 KH<br>+5 Yo<br>+4 HM<br>+3 Guest<br>+2 Lo<br>+1 Ulti<br><br>Chun-Li vs. Lara Croft<br>+7 HM<br>+6 Yo<br>+5 Guest<br>+4 Mo<br>+3 KH<br>+2 Ulti<br>+1 Lo<br><br>Solid Snake vs. Squall Leonhart<br>+7 KH<br>+6 Yo<br>+5 Lo<br>+4 Mo<br>+3 HM<br>+2 Ulti<br>-1 Guest<br><br><br><b>The Rankings</b> (Through Tifa vs. The Boss)<br>1. Karma Hunter (180)<br>2. Master Moltar (171)<br>3. Heroic Mario (159)<br>4. UltimaterializerX (143)<br>5. Yoblazer (141)<br>6. Board 8 (136)<br>7. Lopen (97)<br><br>First
off, I apologize profusely for the huge delay. Even with six matches
added to the total scoreboard, there was absolutely no change in
positions. Looks like the removal of only two extra predictors makes
for a much more consistent scoreboard, as people were moving up and
down the rankings on a daily basis during the series contest. Also, it
looks like Master Moltar has made up some ground on Karma Hunter. With
what might be a split match on tap for tonight, this could be Moltar's
chance to strike. <br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=683142" class="name">transience</a> |
Posted 10/22/2006 6:36:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342613215">message detail</a>
 | #256</td></tr>
<tr class="even"><td>
go Lopen!<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/22/2006 6:39:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342613833">message detail</a>
 | #257</td></tr>
<tr class="even"><td>
Board 8 is like Lopen but with strength in numbers and on crack!<br>---<br><a class="linkification-ext" href="http://wemajor12.myrockinprofile.com/" title="Linkification: http://wemajor12.myrockinprofile.com/">http://wemajor12.myrockinprofile.com/</a><br>Next celebrity I hope to out-rank:  Adam Sandler (#1)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/22/2006 6:42:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342614677">message detail</a>
 | #258</td></tr>
<tr class="even"><td>
Who were the other two predictors last time?<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/22/2006 6:47:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342615987">message detail</a>
 | #259</td></tr>
<tr class="even"><td>
<i>Who were the other two predictors last time?</i><br><br>XxSoulxX,
HaRRicH, Leonhart, and therealmnm were also predictors last time (we
had a total of nine). For this contest, our new predictors are Karma
Hunter and, of course, the "Guest" slot.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/22/2006 6:48:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342616353">message detail</a>
 | #260</td></tr>
<tr class="even"><td>
Ah. Might I point out that 1.3~ of the new predictors are made of quality and win?<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/22/2006 6:55:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342618048">message detail</a>
 | #261</td></tr>
<tr class="even"><td>
Soul kind of got shafted, admittedly, considering he won in the last
contest. That said, aside from the occasional Lopen controversy, I
think this year's turned out very nicely.<br>---<br><a class="linkification-ext" href="http://wemajor12.myrockinprofile.com/" title="Linkification: http://wemajor12.myrockinprofile.com/">http://wemajor12.myrockinprofile.com/</a><br>Next celebrity I hope to out-rank:  Adam Sandler (#1)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/22/2006 6:57:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342618594">message detail</a>
 | #262</td></tr>
<tr class="even"><td>
How are the people who end up getting in decided on? Like, how did KH get in and why didn't Soul?<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=46088" class="name">therealmnm</a> |
Posted 10/22/2006 6:58:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342618861">message detail</a>
 | #263</td></tr>
<tr class="even"><td>
Moltar runs the show.<br>---<br>Currently playing: Grand Theft Auto 3, Devil May Cry, Mega Man ZX
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/22/2006 6:59:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342619068">message detail</a>
 | #264</td></tr>
<tr class="even"><td>
Yeah. How does he decide?<br><br>Bah, screw it. *stops with the annoying questions*<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/22/2006 7:08:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342621503">message detail</a>
 | #265</td></tr>
<tr class="even"><td>
Moltar decided by BRIBES!<br><br>Nah, he did
what he felt was best for the Crew this year and wanted to give other
people their chance to make analyses too, since that's a common
complaint that they feel like they can compete like anybody else on the
Crew.<br>---<br><a class="linkification-ext" href="http://wemajor12.myrockinprofile.com/" title="Linkification: http://wemajor12.myrockinprofile.com/">http://wemajor12.myrockinprofile.com/</a><br>Next celebrity I hope to out-rank:  Adam Sandler (#1)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/22/2006 7:26:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342626162">message detail</a>
 | #266</td></tr>
<tr class="even"><td>
I really didn't want Soul to miss out at my expense, but I didn't want
to stiff Moltar either. So, bah. I just have to kick as much ass as
possible to prove myself! Chip on shoulder FTW<br><br>(also it probably saves face for Soul as he would be doing TERRIBLY this year)<br>---<br><b>*kills self<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/22/2006 7:29:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342626801">message detail</a>
 | #267</td></tr>
<tr class="even"><td>
Amen. I would replace Ulti with someone more dedicated if I was Moltar,
but that's just me! Half his write-ups are a word long, and while it's
fitting in plenty of blowout jokes matches, it'd be nice if there was a
little more substance in other matches.<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/22/2006 7:29:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342626860">message detail</a>
 | #268</td></tr>
<tr class="even"><td>
he he he he he he he he he he alyx<br>---<br><a class="linkification-ext" href="http://wemajor12.myrockinprofile.com/" title="Linkification: http://wemajor12.myrockinprofile.com/">http://wemajor12.myrockinprofile.com/</a><br>Next celebrity I hope to out-rank:  Adam Sandler (#1)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/22/2006 7:32:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342627441">message detail</a>
 | #269</td></tr>
<tr class="even"><td>
I'll concur with that -- not that every blow-out's analysis needs to be
like mine from Zelda/Carmen, but you don't see much effort from him on
that anymore. He feels like he's kept around because he's a classic to
the Crew, yet Soul was dropped.....<br>---<br><a class="linkification-ext" href="http://wemajor12.myrockinprofile.com/" title="Linkification: http://wemajor12.myrockinprofile.com/">http://wemajor12.myrockinprofile.com/</a><br>Next celebrity I hope to out-rank:  Adam Sandler (#1)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/22/2006 7:51:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342632479">message detail</a>
 | #270</td></tr>
<tr class="even"><td>
I generally look forward to KH and HM's predictions the most, and
easily find Ulti's predictions to be the least interesting. Moltar,
Lopen and Yo are all average, with Moltar being the most consistent
quality-wise of the three. Guests? We are exactly as we should be, with
writeups as good as Chun-Li/Lara Croft, along with writeups as bad as
Phoenix/Gordon and whatever my first round writeup was. =/<br><br>I have to admit though, I didn't like Squallid's writeup for some reason. :x<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/22/2006 7:53:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342632914">message detail</a>
 | #271</td></tr>
<tr class="even"><td>
My write-ups are the best!<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=152338" class="name">Lopen</a> |
Posted 10/22/2006 7:55:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342633361">message detail</a>
 | #272</td></tr>
<tr class="even"><td>
<i>Yuna vs. Joanna Dark<br>+7 Mo<br>+6 KH<br>+5 Yo<br>+4 HM<br>+3 Guest<br>+2 Lo<br>+1 Ulti</i><br><br>Ulti predicted Magus with 87.xx%.  He got the wrong winner, he should get -1 for that one.  ... what?  I'm completely serious!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=152338" class="name">Lopen</a> |
Posted 10/22/2006 7:56:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342633827">message detail</a>
 | #273</td></tr>
<tr class="even"><td>
Whoa whoa whoa... was I just called <i>average?</i>  Fine, Ashe, you'll get no more of my fanclub benefits!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/22/2006 7:59:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342634598">message detail</a>
 | #274</td></tr>
<tr class="even"><td>
In quality of writeups, yes. In quality of picks? Not a chance.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/22/2006 8:02:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342635353">message detail</a>
 | #275</td></tr>
<tr class="even"><td>
Heh, I would actually support Ulti not gettin' a point for not turning
one in. Not cost him any points, mind you, but you don't see Soul
getting points for not turning in an analysis.<br>---<br><a class="linkification-ext" href="http://wemajor12.myrockinprofile.com/" title="Linkification: http://wemajor12.myrockinprofile.com/">http://wemajor12.myrockinprofile.com/</a><br>Next celebrity I hope to out-rank:  Adam Sandler (#1)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=152338" class="name">Lopen</a> |
Posted 10/22/2006 8:09:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342637133">message detail</a>
 | #276</td></tr>
<tr class="even"><td>
Psh, even a wrong analysis is better than none at all. At least that's
the way I see it. Not that I care, really... I've said in the past that
this topic puts more emphasis on the points than should be anyway. <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/22/2006 8:10:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342637296">message detail</a>
 | #277</td></tr>
<tr class="even"><td>
I agree. My fellow guests, Ulti and Yo are within striking range! Stop making ridiculous picks! =D<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=683142" class="name">transience</a> |
Posted 10/22/2006 8:10:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342637474">message detail</a>
 | #278</td></tr>
<tr class="even"><td>
yeah - why bother being right? it's being daring that counts!<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/22/2006 8:13:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342638159">message detail</a>
 | #279</td></tr>
<tr class="even"><td>
<i>From Lopen</i><br><i>Psh, even a wrong analysis is better than none at all.</i><br><br>That is what I said, which is why I put you above Ulti. o.o<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/22/2006 8:22:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342640546">message detail</a>
 | #280</td></tr>
<tr class="even"><td>
<i>Yeah. How does he decide?</i><br><br>Dartboard!<br><br>Oh fine, I
keep an eye on what other contest-followers say and predict, and look
for the cream of the crop. Of course, plenty of other candidates get
turned down in the process, so sometimes rotation is necessary.<br><br>Oh,
and "dropping" Leon, Soul, mnm and HaRR from the Crew was insanely hard
for me to do. I don't plan on doing anything that drastic again. I just
really wasn't too happy with the huge 9 person Crew, so I decided to
trim it down to 7. I also wanted a Guest spot, so anyone would be able
to be part of the Crew for at least one match (plus, it cuts down on
"omgz plz can i be on da krew?!?!").<br><br> <br> <br>Anyway, speaking of Ulti, his Yoshi/Dante analysis is his longest so far! It's also split 3-3 at the moment. Woo!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Snake vs. Squall - Bracket: <b>Snake</b> - Vote: <b>Snake</b> (44/48)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/22/2006 8:23:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342640980">message detail</a>
 | #281</td></tr>
<tr class="even"><td>
I thought about giving Ulti 0 points for not having a write-up at all, but he would have obviously picked Chun-Li.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/22/2006 8:24:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342641171">message detail</a>
 | #282</td></tr>
<tr class="even"><td>
Split? God dammit Guest, you better have gone with Dante, or I'm ripping off your balls. Do me proud Lopen!<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 10/22/2006 8:24:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342641202">message detail</a>
 | #283</td></tr>
<tr class="even"><td>
Yoshi/Dante was long? ehhhhh...<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), Castlevania: LoI, MMZX, FFL2
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/22/2006 8:24:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342641238">message detail</a>
 | #284</td></tr>
<tr class="even"><td>
Wow, I better start writing mine.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/22/2006 8:27:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342641960">message detail</a>
 | #285</td></tr>
<tr class="even"><td>
Lopen obviously has Dante, and HM has had him from the beginning as
well. Moltar should defer to Yoshi thanks to having him in his bracket
and Yoshi fanboyism, Ulti will likely go with Yoshi for the same
reasons...<br><br>...so that leaves me, Yo, and Guest.<br>---<br><b>*kills self<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/22/2006 8:28:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342642105">message detail</a>
 | #286</td></tr>
<tr class="even"><td>
Split 3-3, and yo didn't send his in?<br><br>Moltar - Yoshi<br>KH - Dante<br>Lopen - Dante<br>HM - Dante<br>Ulti - Yoshi<br>Guest - Yoshi<br><br>m i rite?<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/22/2006 8:28:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342642236">message detail</a>
 | #287</td></tr>
<tr class="even"><td>
darn you kh<br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/22/2006 8:29:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342642494">message detail</a>
 | #288</td></tr>
<tr class="even"><td>
<i>Yoshi/Dante was long? ehhhhh...</i><br><br>Compared to your other ones...<br><br><i>Moltar should defer to Yoshi thanks to having him in his bracket and Yoshi fanboyism</i><br><br>Only right on one of those accounts, buddy<i>!!</i><br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Snake vs. Squall - Bracket: <b>Snake</b> - Vote: <b>Snake</b> (44/48)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/22/2006 8:32:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342643379">message detail</a>
 | #289</td></tr>
<tr class="even"><td>
<i><br>Compared to your other ones...</i><br><br>more like compared to his wang m i rite? lololol<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=254355" class="name">Lugia2</a> |
Posted 10/22/2006 8:35:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342643976">message detail</a>
 | #290</td></tr>
<tr class="even"><td>
"longest" from Ulti, these days, could mean two paragraphs.  Oye.<br><br>Yoshi/Dante...this'll
be fun, like Jill/Peach. Or it could suck, like the majority of the
matches that were supposed to be nice, like the Celes/Big Boss
one...Oye...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=683142" class="name">transience</a> |
Posted 10/22/2006 8:35:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342643977">message detail</a>
 | #291</td></tr>
<tr class="even"><td>
for KH, it depends on if he goes with his bracket or with his recent thoughts on the match. I'd expect the latter, ie Dante.<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/22/2006 8:36:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342644364">message detail</a>
 | #292</td></tr>
<tr class="even"><td>
I'm expecting it to be over in 15 minutes personally. You have no idea
how much I hope there's an absolute slaughter in favor of Dante in
today's match. Dante with 57% would make me hard.<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/22/2006 8:37:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342644637">message detail</a>
 | #293</td></tr>
<tr class="even"><td>
It's like one big guessing game in here!<br><br>---<br><i>The Master Sword is the most sought-after blade in Hyrule. He who wields it carries with him the hope of the kingdom.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/22/2006 8:43:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342646205">message detail</a>
 | #294</td></tr>
<tr class="even"><td>
I figure Yoshi will be ahead after the first five minutes, then Dante takes over from there to win the match in a 54-46 match.<br>---<br><a class="linkification-ext" href="http://wemajor12.myrockinprofile.com/" title="Linkification: http://wemajor12.myrockinprofile.com/">http://wemajor12.myrockinprofile.com/</a><br>Next celebrity I hope to out-rank:  Adam Sandler (#1)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=152338" class="name">Lopen</a> |
Posted 10/22/2006 8:51:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342648350">message detail</a>
 | #295</td></tr>
<tr class="even"><td>
<i>yeah - why bother being right? it's being daring that counts!</i><br><br>Damn straight!  Er...  <br><br>Man, what I'm saying is that if the analysis argues the % well, or is just that awesome, it doesn't matter <i>that</i> much if you're way off.  Psh, you damn kids just can't appreciate quality unless it's <i>backed up by a number</i>.  It's not my fault you have a narrow outlook on things!<br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/22/2006 8:54:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342649009">message detail</a>
 | #296</td></tr>
<tr class="even"><td>
I have to agree with Lopen here...I don't see much of a difference with
taking Kairi to win with 60% (which is what I did) and Jill to win with
60%. I felt my analysis (or lack thereof) was solid enough, but it
still ended up being dead wrong. I don't feel like I should be punished
or penalized, I feel foolish enough.<br>---<br><b>*kills self<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/22/2006 8:57:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342649898">message detail</a>
 | #297</td></tr>
<tr class="even"><td>
It's best just to think of Lopen as someone who is very distant from
the reality of things and rarely -- but sometimes -- gets really lucky
and predicts a match correctly <i>!!</i><br><br><br>(I have not the slightest clue what the hell you guys are arguing about!)<br><br>---<br><i>The Master Sword is the most sought-after blade in Hyrule. He who wields it carries with him the hope of the kingdom.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=683142" class="name">transience</a> |
Posted 10/22/2006 8:57:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342650108">message detail</a>
 | #298</td></tr>
<tr class="even"><td>
well, the idea of analysis is to be right. the number isn't <i>everything</i>, but it does matter somewhat. if you're a mile off every match, it isn't saying much for your predicting skills!<br><br>that said, I'll take a wrong analysis over a correct pick - ie, <i>INDESTRUCTIBLE LOPEN</i> to Ulti's six word "analyses".<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/22/2006 8:59:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342650567">message detail</a>
 | #299</td></tr>
<tr class="even"><td>
<i>well, the idea of analysis is to be right. the number isn't
everything, but it does matter somewhat. if you're a mile off every
match, it isn't saying much for your predicting skills!</i><br><br>...Lopen is in dead-last place in the guru for a reason. You guys knew what you were getting into when you signed him up!<br>---<br><b>*kills self<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=683142" class="name">transience</a> |
Posted 10/22/2006 9:00:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342650810">message detail</a>
 | #300</td></tr>
<tr class="even"><td>
I blame Moltar!<br><br>nah, I love Lopen's analysis. much better than I would do, even if my score doubled his in the end!<br>---<br>xyzzy
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=4">5</a></li>
<li>6</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=9">10</a></li>
</ul>
</div>


</div>
<img src="genmessage6_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage6_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31144759&amp;page=5" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage6_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>