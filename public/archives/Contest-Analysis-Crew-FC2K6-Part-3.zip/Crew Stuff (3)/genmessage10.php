<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage10_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage10_files/nogs.css"></head><body linkifytime="131" linkified="0" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage10_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage10_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31144759%26page%3D9"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage10_files/advertisement.gif" alt="advertisement" height="10" width="120"></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage10_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage10_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 3
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;page=9">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31144759" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=8">Previous Page</a> |
Page 10 of 10
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/26/2006 9:10:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343485278">message detail</a>
 | #451</td></tr>
<tr class="even"><td>
Oh man... if Kirby pulled a Squall I'd probably rip a hole through my jeans with a raging boner.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3685859" class="name">PartOfYourWorld</a> |
Posted 10/26/2006 9:10:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343485304">message detail</a>
 | #452</td></tr>
<tr class="even"><td>
If Kirby manages to win, I daresay anyone would call it a fluke. If you
can give Bowser a good match and beat Luigi, you're pretty high up on
the Nintendo ladder.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=640243" class="name">Big Bob</a> |
Posted 10/26/2006 9:10:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343485328">message detail</a>
 | #453</td></tr>
<tr class="even"><td>
<i>Big Bob's biased and completely nonsensical analysis</i><br><br>That'll be the last time I do this before reading the crew's predictions.<br><br>Anyway, it's simple math here.<br><br>Yoshi &lt;&lt; Bowser (2k3)<br>Luigi &lt;&lt; Yoshi (2k4)<br>Kirby &lt; Bowser (2k5)<br><br>What does that mean?<br><br>Luigi &lt;&lt;&lt; Kirby<br><br>And
Kirby fought a stronger Bowser than Yoshi did! Kirby 60-40'd the Prince
of Persia, who's had three great games on the major consoles this
generation! Kirby also has a part in the Super Smash Bros. Brawl
trailer (something Luigi didn't have), so that should give him a small
boost as well (it seems to have helped Snake so far). Luigi may have
beat Zero, but Zero's already shown weakness.<br><br>Bob's Predicition: <b>Kirby with 55%</b><br>---<br>Gordon
Freeman finally won, but somehow, the universe survived... thus
allowing me to tell said universe about how I was owned by <b>NClark128</b>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/26/2006 9:11:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343485612">message detail</a>
 | #454</td></tr>
<tr class="even"><td>
Well, basically the only way Kirby proves it was legitimate is by beating Luigi, but even then, he could still "fluke" a win. <br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 5</i>: Darkwing Duck (4-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/26/2006 9:13:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343485991">message detail</a>
 | #455</td></tr>
<tr class="even"><td>
Well the idea behind "fluking" the win is more that he has the ability
to overperform on Nintendo characters. Put Kirby and say Luigi up
against a completely random non ninty-guy, and Luigi does better. Do I
believe that? No, but I think that's what they're saying.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/26/2006 9:14:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343486273">message detail</a>
 | #456</td></tr>
<tr class="even"><td>
Either way, the idea that Luigi beats Kirby despite Bowser struggling mightily against him confuses me.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 5</i>: Darkwing Duck (4-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/26/2006 9:14:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343486326">message detail</a>
 | #457</td></tr>
<tr class="even"><td>
It will mean that Kirby is legitimately <i>really</i>
high up on the Nintendo chain, but not too much for his actual contest
strength. We'd get a good read against Sonic regardless, but it'd be
Luigi who could be potentially underrated.<br><br>On the opposite side
of possibilities, Luigi would have the potential to be severely
overrated if he ended up winning and facing Sonic. Though I doubt his
proxy power (Shadow is the cool Sonic, Luigi is the wimpy Mario), the
possibility is always there.<br>---<br><b>*kills self<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/26/2006 9:15:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343486475">message detail</a>
 | #458</td></tr>
<tr class="even"><td>
yoblazer mor lik <b>no</b>blazer mirite?!<br><br>And
really, I'll be dumbfounded if Luigi outperforms Bowser on Kirby. That
was my thought when I had Kirby taking this fourpack if he fought
Luigi. I just couldn't see it. I mean, if anything, Luigi should be <i>easier</i> to overperform on that Bowser.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sonic vs. Vincent - Bracket: <b>Sonic</b> - Vote: <b>Sonic</b> (50/56)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/26/2006 9:15:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343486557">message detail</a>
 | #459</td></tr>
<tr class="even"><td>
Same here... I mean, does anyone really dispute that Bowser &gt; Luigi
on the pecking order? Because if not, I don't see how you could
possibly take Luigi in this match up. You have an insanely small margin
of error to work with there.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/26/2006 9:15:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343486565">message detail</a>
 | #460</td></tr>
<tr class="even"><td>
<i>Shadow is the cool Sonic</i><br><br>Die.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 5</i>: Darkwing Duck (4-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/26/2006 9:15:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343486678">message detail</a>
 | #461</td></tr>
<tr class="even"><td>
Same here goes along with Leon's post. Silly me not quoting.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/26/2006 9:16:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343486805">message detail</a>
 | #462</td></tr>
<tr class="even"><td>
<i>Either way, the idea that Luigi beats Kirby despite Bowser struggling mightily against him confuses me.</i><br><br>It
could suggest that Luigi is simply better with the SFF despite being
weaker. They could be nearly even a la Mario/Samus but Luigi could end
up handing out a similar beatdown.<br>---<br><b>*kills self<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/26/2006 9:17:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343487082">message detail</a>
 | #463</td></tr>
<tr class="even"><td>
I don't know. SFF is difficult to pull when characters are close in
strength. I don't think it makes a difference in who wins or loses.
Whoever is legitimately stronger wins, in my opinion.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 5</i>: Darkwing Duck (4-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/26/2006 9:18:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343487199">message detail</a>
 | #464</td></tr>
<tr class="even"><td>
<i>Die.</i><br><br>I hate Shadow as much as the next guy, but you can't
deny that is his defining character trait. He's Sonic, only dark, has
hover boots and he's vaguely badass and anti-heroic.<br>---<br><b>*kills self<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=788233" class="name">PokemonPatriarch</a> |
Posted 10/26/2006 9:18:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343487218">message detail</a>
 | #465</td></tr>
<tr class="even"><td>
I'm excited about this match, but I see Luigi following suit with pals Yoshi and Peach. <br><br>Ironically, I don't see the strongest Mario character in this contest making the sweet sixteen (Bowser)!!!<br>---<br>Proud fanboy of the Ogre Battle saga!!!<br><b>~~~Allah Approves~~~ </b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/26/2006 9:18:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343487302">message detail</a>
 | #466</td></tr>
<tr class="even"><td>
This match is reminding me of Dante/Yoshi so much. Despite Dante having
every apparent advantage, and all logic and signs pointing to him
winning, Yoshi wins anyway. And now, despite everything pointing to
Kirby, and all logic telling me he should win, my faith in his victory
is extremely shakey.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/26/2006 9:19:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343487615">message detail</a>
 | #467</td></tr>
<tr class="even"><td>
There was always one piece of logic that put Yoshi in that match, and
that was Yoshi/Luigi 2004. Downplay it all you like, but Yoshi &gt;
Luigi was staring us all in the face and I'm not gonna doubt it any
more.<br>---<br><b>*kills self<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/26/2006 9:20:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343487734">message detail</a>
 | #468</td></tr>
<tr class="even"><td>
<i>Ironically, I don't see the strongest Mario character in this contest making the sweet sixteen (Bowser)!!!</i><br><br>None of the other Mario characters had to go up against a Noble Nine member though.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 10/26/2006 9:20:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343487807">message detail</a>
 | #469</td></tr>
<tr class="even"><td>
I just want Luigi to win. I don't care by how much. I just want him to get out of the ****ing second round for once.<br><br>Also, I can't see Kirby winning with more than 52%-53%, but I could definitely see Luigi making Kirby look worse than Zero.<br><br>---<br><i>Do you really need me to bring out the Ovaltine?</i>-Stripey12isback on why hes a war hero.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/26/2006 9:21:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343488197">message detail</a>
 | #470</td></tr>
<tr class="even"><td>
<i>Also, I can't see Kirby winning with more than 52%-53%, but I could definitely see Luigi making Kirby look worse than Zero.</i><br><br>Typically
that's what would give me the clear indication toward Luigi, but I had
that same feeling with Peach against Jill and it ended up being more or
less a tie.<br>---<br><b>*kills self<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/26/2006 9:21:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343488202">message detail</a>
 | #471</td></tr>
<tr class="even"><td>
<i>There was always one piece of logic that put Yoshi in that match,
and that was Yoshi/Luigi 2004. Downplay it all you like, but Yoshi &gt;
Luigi was staring us all in the face and I'm not gonna doubt it any
more.</i><br><br>True, but there was about 18 factors in Dante's favor
compared to Yoshi's one, and in a match where SFF very well could have
taken place, it wasn't exactly rock solid. The signs <i>were</i>
there, or rather the sign, but Dante should have been favored after
Round 1 without question, and I still feel good about my Dante pick
despite it being wrong.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/26/2006 9:22:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343488431">message detail</a>
 | #472</td></tr>
<tr class="even"><td>
lol analysis crew more like contest stats and discussion<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/27/2006 12:19:59 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343522775">message detail</a>
 | #473</td></tr>
<tr class="even"><td>
Moltar and yo get the point with 53%, same as me.  I lost count, I don't know whether that would be my 4th or my 5th point.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=683142" class="name">transience</a> |
Posted 10/27/2006 12:20:51 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343522878">message detail</a>
 | #474</td></tr>
<tr class="even"><td>
guess i uh overshot<br><br>oh well<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/27/2006 12:21:03 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343522901">message detail</a>
 | #475</td></tr>
<tr class="even"><td>
Last I checked, this match wasn't over.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 5</i>: Darkwing Duck (4-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/27/2006 12:22:01 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343523020">message detail</a>
 | #476</td></tr>
<tr class="even"><td>
I was talking about Sonic/Vincent.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/27/2006 12:26:59 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343523614">message detail</a>
 | #477</td></tr>
<tr class="even"><td>
Sonic the Hedgehog vs. Vincent Valentine<br>+7 Mo (tie)<br>+7 Yo (tie)<br>+5 HM<br>+4 KH<br>+3 Lo<br>+2 Ulti<br>-1 Guest<br><br><b>The Rankings</b> (Through Sonic vs. Vincent)<br>1. Master Moltar (188)<br>2. Karma Hunter (185)<br>3. Heroic Mario (177)<br>4. Yoblazer (165)<br>5. UltimaterializerX (161)<br>6. Board 8 (145)<br>7. Lopen (107)<br><br>After
weeks of clawing and scratching his way up the mountain, Master Moltar
has finally made it to the top. But with Karma Hunter hot on his trail
and Heroic Mario closing the gap, how long can he stay there?<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=254355" class="name">Lugia2</a> |
Posted 10/27/2006 5:42:16 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343545616">message detail</a>
 | #478</td></tr>
<tr class="even"><td>
STUPID LUIGI!<br><br>You're not supposed to get
past the second match! Who are you, Gordon Freeman? My bracket is dead!
Stop killing it unless you're going to kill Sonic and drive the whole
board insane!<br><br>And since that last one is almost impossible...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 10/27/2006 5:45:45 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343545839">message detail</a>
 | #479</td></tr>
<tr class="even"><td>
Ulti or Yo better end up getting this point. <i>Maybe</i> HM. The guests need to stay in first! D:<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/27/2006 9:03:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343679590">message detail</a>
 | #480</td></tr>
<tr class="even"><td>
Sonic the Hedgehog.................52.09% 64699<br>Vincent Valentine....................47.91% 59497<br>TOTAL VOTES...................................124196<br><br>52.61% of the brackets predicted this match correctly.<br><br>Wow,
I thought Sonic would have a little more bracket support here, even
though the competition was tough. Anyway, Vincent proves he's not a
one-hit wonder by becoming the closest non-Noble Nine character to beat
Sonic.<br><br>Today, Luigi is all like, "lol kirby".<br><br>Moltar - 8<br>Lopen - 8<br>KH - 8<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>HM - 7<br>Ulti - 6<br>Yoblazer - 3<br><br>Yo and I share a point.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Kirby vs. Luigi - Bracket: <b>Kirby</b> - Vote: <b>Kirby</b> (52/58)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/27/2006 9:04:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343679818">message detail</a>
 | #481</td></tr>
<tr class="even"><td>
D:<br><br>We need our lead back, damnit!<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/27/2006 9:05:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343680091">message detail</a>
 | #482</td></tr>
<tr class="even"><td>
HM has the point this time, so as long as we win this next one, it's all good.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=981127" class="name">Cavalier Lowen</a> |
Posted 10/27/2006 9:11:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343681037">message detail</a>
 | #483</td></tr>
<tr class="even"><td>
Thanks for putting the pressure on me guys.<br><br>*Is guest for Bowser/Crono<br>---<br>Z1mZum owned me in the guru contest (by two points!).  Damn you Z1mZum!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/27/2006 9:12:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343681197">message detail</a>
 | #484</td></tr>
<tr class="even"><td>
As long as you don't have Bowser winning that'll make me happy enough.<br><br>---<br>Cheer Up Emo Kids.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3810656" class="name">TrueHeroComplex</a> |
Posted 10/27/2006 9:13:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343681456">message detail</a>
 | #485</td></tr>
<tr class="even"><td>
What does to take to make it on the Guest List?<br>---<br>A hero is a man who is afraid to run away.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=981127" class="name">Cavalier Lowen</a> |
Posted 10/27/2006 9:13:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343681483">message detail</a>
 | #486</td></tr>
<tr class="even"><td>
lol, I almost pulled the trigger, but not quite.<br>---<br>Z1mZum owned me in the guru contest (by two points!).  Damn you Z1mZum!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/27/2006 9:13:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343681560">message detail</a>
 | #487</td></tr>
<tr class="even"><td>
Oh, and I have a write-up ready in case Portugal forgets for tomorrow. &gt;_&gt;<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/27/2006 9:13:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343681583">message detail</a>
 | #488</td></tr>
<tr class="even"><td>
Penis envy.<br><br>---<br>Cheer Up Emo Kids.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/27/2006 9:14:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343681645">message detail</a>
 | #489</td></tr>
<tr class="even"><td>
<i>From TrueHeroComplex</i><br><i>What does to take to make it on the Guest List?</i><br><br>It takes signing up in the Guest Sign-Up topics.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/27/2006 9:14:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343681721">message detail</a>
 | #490</td></tr>
<tr class="even"><td>
<i>Oh, and I have a write-up ready in case Portugal forgets for tomorrow. &gt;_&gt;</i><br><br>More like when EC owns everybody for a third time in a row m i rite?<br><br>---<br>Cheer Up Emo Kids.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/27/2006 9:19:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343682741">message detail</a>
 | #491</td></tr>
<tr class="even"><td>
let me predict your writeup:<br><br>KHF SUCKS KHF SUCKS KHF SUCKS KHF SUCKS KHF SUCKS KHF SUCKS KHF SUCKS KHF SUCKS KHF SUCKS KHF SUCKS <br><br>Prediction: Sub-Zero with 99% <br>---<br>zizzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/27/2006 9:20:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343682941">message detail</a>
 | #492</td></tr>
<tr class="even"><td>
My write-ups are all more style than substance. They also happen to be incredibly accurate! =D<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/27/2006 9:20:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343683035">message detail</a>
 | #493</td></tr>
<tr class="even"><td>
sounds like your posts, only without the style!<br>---<br>zizzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/27/2006 9:27:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343684501">message detail</a>
 | #494</td></tr>
<tr class="even"><td>
<i>KHF SUCKS KHF SUCKS KHF SUCKS KHF SUCKS KHF SUCKS KHF SUCKS KHF SUCKS KHF SUCKS KHF SUCKS KHF SUCKS </i><br><br>Actually
it's more like KHF SUCKS, SUB-ZERO SUCKS, KHF SUCKS, SUB-ZERO SUCKS,
KHF SUCKS, SUB-ZERO SUCKS, KHF SUCKS, SUB-ZERO SUCKS, KHF SUCKS,
SUB-ZERO SUCKS, KHF SUCKS, SUB-ZERO SUCKS, KHF SUCKS, SUB-ZERO SUCKS,
KHF SUCKS, SUB-ZERO SUCKS. <b>Prince of Persia with 104% of the vote</b><br><br>---<br>Cheer Up Emo Kids.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=927369" class="name">EyEs fr0m Ab0vE</a> |
Posted 10/27/2006 9:33:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343685788">message detail</a>
 | #495</td></tr>
<tr class="even"><td>
5...<br>---<br>"them memory is xbox hard down the framerate"<br>From: Fluxeon | Posted: 4/26/2004 2:48:33 PM |
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/27/2006 9:38:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343687091">message detail</a>
 | #496</td></tr>
<tr class="even"><td>
hay guyz new topik wit corno/bwosr<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Kirby vs. Luigi - Bracket: <b>Kirby</b> - Vote: <b>Kirby</b> (52/58)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/27/2006 9:40:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343687344">message detail</a>
 | #497</td></tr>
<tr class="even"><td>
hey moltar go stuff a chicken in ur butt<br>---<br>Cheer Up Emo Kids.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/27/2006 9:45:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343688560">message detail</a>
 | #498</td></tr>
<tr class="even"><td>
^So much win.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2166215" class="name">DaBoMbDiGiTy15</a> |
Posted 10/27/2006 9:48:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343689088">message detail</a>
 | #499</td></tr>
<tr class="even"><td>
numba<br><br>---<br>Is or...was alat778
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/27/2006 9:48:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343689123">message detail</a>
 | #500</td></tr>
<tr class="even"><td>
Wtf I can't stop laffing. =/<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=8">9</a></li>
<li>10</li>
</ul>
</div>


</div>
<img src="genmessage10_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage10_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31144759&amp;page=9" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage10_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>