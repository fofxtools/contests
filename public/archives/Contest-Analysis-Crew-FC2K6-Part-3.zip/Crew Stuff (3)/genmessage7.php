<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage7_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage7_files/nogs.css"></head><body linkifytime="290" linkified="3" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage7_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage7_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31144759%26page%3D6"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage7_files/advertisement.gif" alt="advertisement" height="10" width="120"></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage7_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage7_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 3
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;page=6">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31144759" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=5">Previous Page</a> |
Page 7 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=7">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/22/2006 9:02:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342651425">message detail</a>
 | #301</td></tr>
<tr class="even"><td>
The funny thing is, I would have eliminated Lopen <i>long</i> ago if I'd stuck to my MM &gt; Samus and Sonic &gt; Crono picks.<br><br>...that is, if I'd actually signed up for the Guru.<br>---<br><b>*kills self<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=152338" class="name">Lopen</a> |
Posted 10/22/2006 9:05:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342652047">message detail</a>
 | #302</td></tr>
<tr class="even"><td>
Psh. I wouldn't be so sure about that, buddy! I've still got Chun Li
over Yuna, Dante over Yoshi, and a weird battle royal to help me!
That's 22 points right there! <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/22/2006 9:06:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342652325">message detail</a>
 | #303</td></tr>
<tr class="even"><td>
I'm sad that I came to Board 8 so late in the game. The Oracle
challenge would have been fun, and I would have many more points in
this contest. =/<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/22/2006 9:07:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342652549">message detail</a>
 | #304</td></tr>
<tr class="even"><td>
I also have Chun-Li over Yuna. I can make up the deficit from Yoshi/Dante and the Royale fairly easily.<br><br>It'd be a blowout if it weren't for that darn Aeris! ha ha aeris<br>---<br><b>*kills self<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/22/2006 9:08:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342652770">message detail</a>
 | #305</td></tr>
<tr class="even"><td>
You <i>both</i> have Chun-Li over Yuna? Damn! I've never seen so much wrong in one place!<br><br>---<br><i>The Master Sword is the most sought-after blade in Hyrule. He who wields it carries with him the hope of the kingdom.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/22/2006 9:09:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342652991">message detail</a>
 | #306</td></tr>
<tr class="even"><td>
You'll see even more now that you know that I don't have Zelda winning the whole thing. =/<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=152338" class="name">Lopen</a> |
Posted 10/22/2006 9:10:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342653293">message detail</a>
 | #307</td></tr>
<tr class="even"><td>
[This message was deleted at the request of the original poster]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=981127" class="name">Cavalier Lowen</a> |
Posted 10/22/2006 9:18:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342655414">message detail</a>
 | #308</td></tr>
<tr class="even"><td>
<i>The funny thing is, I would have eliminated Lopen long ago if I'd stuck to my MM &gt; Samus and Sonic &gt; Crono picks.</i><br><br>Hmm,
I have those. Assuming he has Zero or Kirby, maybe I can eliminate him
if Luigi&gt;Kirby (which I have). Then again, he probably has something
funny in his BR.<br>---<br>Z1mZum owned me in the guru contest (by two points!).  Damn you Z1mZum!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/22/2006 9:46:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342662155">message detail</a>
 | #309</td></tr>
<tr class="even"><td>
<b>Patriot Division:</b> <i>Round 2 - Match 42</i> &#8211; (6)Yoshi vs. (2)Dante<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Yoshi</b><br>Round 1 &#8211; 55.20% vs. Riku (44.80%)<br><br>Seems KH2 helped out Riku a lot, as he was able to put up 45% on Yoshi.<br><br><b>Dante</b><br>Round 1 &#8211; 65.20% vs. Ryu H. (34.80%)<br><br>Dante looking just as strong as he did last year.<br><br>Before
this Contest, I thought this was the single toughest Round 2 match to
predict. In the end, I went with Dante because I saw him as slightly,
and I mean <i>very</i> slightly over Yoshi.<br><br>Now? I feel a bit
different on the match. Yoshi looked bad in Round 1, plain and simple.
As high as I put Yoshi pre-Contest, I don&#8217;t see Riku jumping up from
Frog&#8217;s level to near Yoshi&#8217;s. Oh, and I had Yoshi around Dante&#8217;s level,
which is 32% on Base Link. Now, I don&#8217;t think Riku jumped up over 6%
from his rather small role in KH2 to justify Yoshi being that high.<br><br>Of
course, Yoshi has some nice factors going for him. Of course, he&#8217;s
Nintendo, and more mainstream than Dante. Also, if KH2 did for Riku
what it looks to have done for Kairi and Axel, then Yoshi might have
beaten a beastly Riku. That&#8217;s&#8230;about it though.<br><br>Dante, on the
other hand, looked good on Ryu H. While looking at Zero and Ryu H. this
year, it seems that they&#8217;ve both either dropped from 2005, or were
actually overrated (I find that hard to believe&#8230;). Still, Dante seems
at or around his 2005 numbers, and that should be more than enough to
take Yoshi out without too much trouble. I&#8217;m going to guess this
four-pack ends up in the stats for something like (rounded, and
adjusted, because Snake gon&#8217; kill Dante) 33% for Dante, 31% for Yoshi,
28% for Riku. Hey, I&#8217;ll be happy if the Dino ends up at 30% on BL, and
Riku boosting 3-4% from KH2 sounds a lot more reasonable.<br><br>Oh,
and time for the obligatory Yoshi-fanboy paragraph. Dante is awesome,
but Yoshi is above that. If Yoshi pulls the upset, I&#8217;ll be <i>very</i>
happy. I mean, we&#8217;ve never gotten a good read on Yoshi, and if he turns
out to be stronger than Dante&#8230;wow! And then, the Yoshi &gt; Snake
bandwagon will be in full gear!<br><br><b>Moltar&#8217;s Bracket Says:</b> Dante will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Dante: 53% - Yoshi: 47%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>Dante's
killing of Ryu H paired with Ganon getting clipped made it look like
Yoshi had zero chance to win this, but then Luigi and Peach and Zelda
had to go all berserk afterwards. Just when you think NintendoFAQs is
dying, it shows itself in some funny ways. And with some of the morons
around here that constantly whine about it, you half hope it continues
getting worse.<br><br>Anyway at a glance, it seems Dante has the
advantage here. He's coming off of said Ryu H beating as well as DMC3:
Special Edition. There's also been a ton of DMC4 news out over the past
couple of months, including an EGM cover story. Has anyone seen Yoshi
lately?<br><br>Dante has outperformed Yoshi every year, but one stat jumps out at me:<br><br>Yoshi scored 43.67% against Bowser in an SFF match in 2003.<br><br>Dante 2005 supposedly would score 44.79% on Bowser 2005.<br><br>If
Yoshi was noticeably SFFd in 2003, then he has a good chance of beating
Dante. The problem is that the entire Dream Division from 2005 has
tanked this contest, so Bowser is a bad measuring stick. Dante will
likely win this barring some NintendoFAQs magic, but I'm picking Yoshi
anyway just to keep with what I have in the bracket.<br><br>By the way,
anyone using Riku as a basis for why Yoshi may do bad here needs some
common sense. Have you people SEEN what KH2 has done over the past two
contests?<br><br>Prediction: Yoshi with 50.15%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br><b>Yoshi</b><br><br><i>Previous  Matches:</i><br><br>Yoshi &#8211; 55.2% -- 69,394<br><br>Riku &#8211; 44.8% -- 56,325 <br><br><b>Dante</b><br><br><i>Previous Matches:</i><br><br>Dante &#8211; 65.2% -- 77,894<br><br>Ryu Hayabusa &#8211; 34.8% -- 41,576
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/22/2006 9:47:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342662349">message detail</a>
 | #310</td></tr>
<tr class="even"><td>
It&#8217;s great how we get to the male bracket and kick it off with two <i>really</i> good matches. You almost <i>have</i>
to be rewarded with this after enduring that awful female bracket. This
match is one that has been hotly debated since the beginning of the
contest and one that probably will be debated right up until the
beginning of the match. With reason to doubt Yoshi&#8217;s ranking &#8211;
potentially underrated &#8211; and reason to doubt Dante&#8217;s ranking &#8211;
potential overrated &#8211; this match should definitely be a good one. <br><br>Dante,
by the adjusted 2005 stats, is projected to win this match with
somewhere around 55%. The choice on who wins this should seem <i>very</i>
obvious at first, but there&#8217;s definitely the possibility that Yoshi was
underrated last year when he had that strange match with Mega Man. The
adjustments could have undershot where he really is and considering he
only gained 2% last year during the great Nintendo Boost, there&#8217;s even
more reason to be skeptical. <br><br>However, Dante comes into the
match with a huge win over Hayabusa and with a new game (DMC: Special
Edition) under his belt. The advantages are clearly all in Dante&#8217;s
corner and it would probably be a surprise to quite a few people to see
him lose today. I think Yoshi can definitely upset here with the
possibility of an NSMB boost, Riku gaining more from KH2 than
anticipated, and Dante not being too far off from his 2005 ranking. It
requires quite a bit, but I think the green dinosaur is going to be
able to squeak one out. I&#8217;m probably going to be the only one deviating
from the Dante choice after what appears to be overwhelming evidence
pointing to the Demon Hunter winning, but the same could be said in
Zero/Luigi <i>!!</i> <br><br><b>Believe</b>. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Dante<br><br><b>Aitch Emm&#8217;s Prediction:</b> Yoshi &#8211; 50.5% ; Dante &#8211; 49.5%<br><br><b>Aitch Emm&#8217;s Vote:</b> Yoshi<br> <br> <br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Round
2's most debated match is also the only one where I just can't seem to
make up my damned mind. On the one hand, I know Dante is (rightfully)
the favorite going into the contest; on the other, I have Yoshi in my
bracket, and going against one's own bracket is a decidedly difficult
thing to do, especially in a match as disputed as this.<br><br>When the
contest started, I felt good about having Yoshi for a few reasons. One,
for as good as Dante ended up looking in the 2005 stats, the strongest
opponent he's ever actually beaten is Miles "Freakin' Tails" Prower.
It's not his fault for getting matched up with fodder every year, but
this does he's largely untested outside his match with Vincent. On the
off chance that Vincent overperformed against Crono (Advent Children,
rSFF, whatever), Dante suddenly doesn't look quite as strong. Apart
from Dante possibly being overrated and an unproven winner, I also felt
that Yoshi was stronger than the stats have ever shown him. The poor
dino; he's been in three contests and has gone out in an SFF match
three times. That's just unfair. I figured that Yoshi's probably around
Luigi's strength, if not a bit higher (he did beat him, after all), and
that was good enough for me.<br><br>Then, of course, the two took
center stage. Whereas Dante outperformed Zero by over 2%, Yoshi
performed bellow expectations on Riku. Dante immediately became the
favorite. The Dante supporters suddenly became much louder, bleaching
their hair and shouting mind-numbingly cheesy one liners in unison.
They did, apparently, want to be the ones to fill my dark soul with
annoyance. Well, I guess that's that. Dante wins and proceeds to get
mauled by Snake, making his fourpack look so, so bad in the process.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/22/2006 9:48:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342662575">message detail</a>
 | #311</td></tr>
<tr class="even"><td>
...<br><br>Actually, it really really does.
Several Kingdom Hearts II characters, including Riku, Kairi, Axel, and
Auron, have all obliterated the board's combined expectations. If this
Riku is a good deal stronger than the Axel who broke 30% on Mega Man,
then Yoshi's win looks pretty respectable. In addition, while Dante
outperformed Zero by a little over 2%, Luigi cleaned Zero's clock
outright. It was a result that some of us were expecting, but it was a
margin of victory that hardly anyone saw coming. <i>If</i> Yoshi is
around Luigi's strength (and, to be honest, I have yet to hear a
convincing argument of why he now shouldn't be), this should be one
hell of a match.<br><br>While no one can take away Dante's status as
the favorite going in, no one should claim that Yoshi doesn't have a
realistic shot at the win. Hell, seeing as how <i>all</i> of his
matches have either been against fodder, wrought with SFF, or against
characters who experienced incalculable off-season boosts, it can be
argued that we've never gotten a clear read on Yoshi. And for me,
folks, that's practically a guarantee for something wacky (and maybe a
win).<br><br>My prediction: Yoshi def. Dante (51-49)<br> <br> <br> <br><b>Lopen&#8217;s Analysis</b><br> <br>I
never thought this match was really in question, and I still don't
think it is. Maybe it's just my Dante fanboyism coming into play, but I
didn't overestimate him against Vincent last year! Okay, I did&#8230; I said
he'd win, but I didn't say he'd win <i>easily</i>. Alright, back on
topic here&#8230; looking at what Yoshi and Dante did last round, it'd be
silly to say that Dante isn't looking better coming in.<br><br>Dante made it look like 2005 was legit <i>and then some</i>. What did Yoshi do? He did beat Riku, (more credit than I gave him, I'll admit) but he didn't exactly <i>trounce</i>
him. My theory of Yoshi just doing well because of SFF was proven
mostly wrong, but I still don't think he's everything those X-Stats say
he is. Add into that the fact that Dante has beaten Yoshi every year in
the X-Stats, Squall and Vincent have looked to be everything last year
said they were, and Dante's looking even better to win this match with
ease!<br><br>You know what they say&#8230; you can't make an omelet without
beating a few eggs out of Yoshi first. Watch as Dante illustrates that
principle, tonight! This poll is gettin' crazy!<br><br><b>Lopen's prediction:</b> Dante with 57.35%<br> <br> <br> <br><b>KH&#8217;s Analysis</b><br><br> lol x-stats history<br><br><b>YOSHI</b><br> <br><i>"(Wish I could run faster.)"</i><br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 23rd Place [26.17%]<br> <br>Summer 2004 Contest<br>Extrapolated Strength --- 26th Place [ 25.22%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 27th Place [26.59%]<br><br>Yoshi
underperforms heavily against Riku. The question is, is it an
absolutely massive KH2 boost or is a Yoshi weakness? The fact that we
have to ask the question is not a good sign for Yoshi.<br><br><b>DANTE</b><br> <br><i>"I SHOULD HAVE BEEN THE ONE TO FILL YOUR DARK SOUL WITH <b>LIIIIIIIIIIGGGHHHHTTT</b>"</i><br> <br>Summer 2002 Contest<br>Extrapolated Strength --- 18th Place [25.02%]<br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 21st Place [27.32%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 23rd Place [ 25.49%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 17th Place [29.99%]<br><br>Dante
overperforms notably against Hayabusa. Does this mean that Hayabusa is
weaker than he appears (or SFF is to blame) or that Dante is looking
stronger than ever? The fact that we have to ask the question is a very
good sign for Dante.<br><br><i>Notable Releases Since Last Appearance</i><br><br>Yoshi: N/A<br>Dante: Devil May Cry 3: Special Edition (PS2)<br><br><i>Upcoming Releases</i><br><br>Yoshi: N/A<br>Dante: Devil May Cry 4 (PS3)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/22/2006 9:50:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342662978">message detail</a>
 | #312</td></tr>
<tr class="even"><td>
I don't really want to dwell on this match. Why didn't I take Dante?!
He kicks ass in all sorts of ways, is in some of the best action games
this generation has to offer, has the cornball humor lines that I find
absolutely hilarious, and is generally the better character and the
safer pick. He looks better, has all the intangibles...Yoshi has "lol
Nintendo."<br><br>Don't make me dwell on this too much longer.<br><br>Karma Hunter's Vote: Dante. I'M WORKING AGAINST MYSELF<br><br><b>Karma Hunter's Krazy Prediction: Dante with 53.24%.</b><br> <br>I have no idea why I'm going high, no matter what I do Lopen's going to go higher. =(<br><br><b>Upset Potential: 42.5%<br><br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br> <br>There's
still a reason why I picked Yoshi here in the first place, darn it!
After Luigi whipping up on Zero (enough for him to be projected over
Dante through Hayabusa 2k5, I think), Yoshi <i>should</i> have this
match in the bag. He beat Luigi, directly! He's always looked stronger,
sans that time when he ran smack dab into the KING OF SFF. And
yet...argh!<br><br>Stupid Yoshi. Why couldn't you just lose to Luigi in 2004 and make things make sense?<br><br>Upset Prediction: Yoshi with 51.01%<br> <br><br> <br><b>Guest&#8217;s Analysis</b> - <i>King Morgoth</i><br><br><i>Finally!</i><br>The first day the bracket came out this is <b>the</b> match that had <i>sexy upset</i>
written all over it. Sure there were other good ones, but Yoshi was so
far under Dante in the stats that most people would think there would
be no chance Yoshi wins. Alright, I was wrong, but that one never
changed in my bracket.<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/shared/cb5/cb542.jpg" title="Linkification: http://www.gamefaqs.com/shared/cb5/cb542.jpg">http://www.gamefaqs.com/shared/cb5/cb542.jpg</a><br><br>Yoshi symbolises everything that's good in life. He's friggin' <i>green</i> and he's <i>happy</i>! What? That's not enough to win the match? Let's go with Stats then, Stats!!!<br><br><i>Dante</i><br>His 2k5 value: 32.73%<br>With a constant Ryu H.: 34.12%<br>With constant Terra and Zelda: 24.31% (aka <i>lol xstats</i>)<br><br><i>Yoshi</i><br>His 2k5 value: 29.01%<br>Through his match with Bowser: 31.91%<br>Through his match with Luigi: 34.40%<br>Through his match with Luigi with a constant Zero: 38.07%<br>Through a constant Riku: 26.93%<br><br>As usual, numbers can mean <i>anything</i>,
and it comes to whether or not you'd take Dante over Zero, Yoshi over
Luigi and by how much. And no matter what you think, there'll be
numbers to back your argument.<br><br>So that leaves us with only ONE single solid and valid argument:<br>...<br>He's green...<br>And he's happy...<br>And that's really all he'll need come tomorrow<br><br>Prediction: Yoshi with 52.76%<br> <br> <br> <br>Crew
Consensus: Another highly debated match, another split Crew decision.
Yoshi is the favorite here 4-3. Will the Yosh-man come through, or is
the Crew bracket losing 2 points thanks to the Dark Knight?
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/22/2006 9:52:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342663513">message detail</a>
 | #313</td></tr>
<tr class="even"><td>
Like I said, if you can't see someone winning with more than 51%, it ain't happening! Yoshi's going <i>doooooooooooown.</i><br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/22/2006 9:58:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342665089">message detail</a>
 | #314</td></tr>
<tr class="even"><td>
[This message was deleted at the request of the original poster]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/22/2006 9:59:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342665192">message detail</a>
 | #315</td></tr>
<tr class="even"><td>
KH disappointed. :x<br><br>Yo, might I point out that Axel is a far better character than Riku?<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3052691" class="name">satai_delenn</a> |
Posted 10/22/2006 10:03:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342666098">message detail</a>
 | #316</td></tr>
<tr class="even"><td>...Interesting split. The odd thing is, it seems
like everyone who picked Yoshi to win did so with a feeling of "well,
Dante has all the right reasons to win, but there's GOT to be a reason
that I picked Yoshi." Not to say that those reasons aren't valid, it's
just an interesting observation about the tone of all those Yoshi
pickers' analyses...they all have words like "if" and "maybe" in them.
Hmm.<br>---<br>Beating
FE5 and FE6 hard mode is a true test of manhood in the Japanese
culture. However. This explains why they have a lot of effeminate men.
~Sytha
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/22/2006 10:14:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342668641">message detail</a>
 | #317</td></tr>
<tr class="even"><td>
<i>DpOblivion's Not So Quick Analysis:</i><br><br>Here it is, the match
I've been waiting for! Let me first apologize for not getting my
analysis in earlier. I was busy playing Mario Kart 64. I was being
Yoshi, if you care. Then, we played Mario Party 3. I was Yoshi. Okay,
I'm not some crazy Yoshi fanboy or anything, but since the last
contest, I've really grown to like him from playing Mario Kart: Double
Dash. His egg rules.<br><br>Anyway, there is much evidence to say that
Nintendo is absolutely hot right now. We saw Luigi beat Zero, which,
I'd like to point out once more, I had in my bracket, unlike the entire
Crew. Yoshi also upset Riku in the first round, but that was kind of
expected. Yoshi's opponent this round is a much tougher opponent,
Dante, who's Devil May Cry series is pretty damn popular.<br><br>But
how would you expect someone like Dante, who has basically just
appeared on one system, to beat Yoshi, who's been around since the SNES
days and is a staple in the Mario lineup? I'll tell you how......wait,
no, I can't, because it's not going to happen.<br><br>My vote: Yoshi<br>My bracket: Yoshi<br>My prediction: Yoshi with 53.13%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2104432" class="name">Prometheus321</a> |
Posted 10/22/2006 10:30:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342671847">message detail</a>
 | #318</td></tr>
<tr class="even"><td>
<i>King Morgoth<br><br>So that leaves us with only ONE single solid and valid argument:<br>...<br>He's green...<br>And he's happy...<br>And that's really all he'll need come tomorrow</i><br><br>You sir, are full of win and I salute you.<br>---<br><b>R.I.P Steve Irwin, 2/22/62-9/4/06</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3605206" class="name">wavedash101</a> |
Posted 10/22/2006 11:22:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342682150">message detail</a>
 | #319</td></tr>
<tr class="even"><td>
Wait KH, why the heck didnt you put Yoshi's Island 2 under upcoming releases!!??<br><br>&gt;_________________&gt;<br><br>*loliphuants step on KH*<br>---<br><b>Our shields cannot withstand wavedashing of this magnitude!</b><br>Board 8's Unofficial Master of the Phoenix Down
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=254355" class="name">Lugia2</a> |
Posted 10/23/2006 5:48:25 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342714932">message detail</a>
 | #320</td></tr>
<tr class="even"><td>
...Looks like Lopen gets smacked.  Again.  Nice to see another Jill/Peach match!  Go Yoshi!  Save my completely ruined bracket!<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3793953" class="name">TehMissingLink</a> |
Posted 10/23/2006 1:07:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342755570">message detail</a>
 | #321</td></tr>
<tr class="even"><td>
I'm feeling a Crew Point on this one <i>!!</i><br><br>---<br><b>"Thank You Mario! But our Princess is in another castle!"</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/23/2006 6:47:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342829481">message detail</a>
 | #322</td></tr>
<tr class="even"><td>
Solid Snake....................57.59% 78314<br>Squall Leonhart.............42.41% 57666<br>TOTAL VOTES............................135980<br><br>79.17% of the brackets predicted this match correctly.<br><br>Holy
vote totals! Snake easily walks over Squall. Signs of a stronger Snake,
or is this just more of that funky MGS-FF SFF. We'll find out soon, I
guess!<br><br>Today, Yoshi is beating Dante in a close one.<br><br>KH - 8<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Moltar - 7<br>Lopen - 7<br>HM - 6<br>Ulti - 5<br>Yoblazer - 2<br><br>KH's Snake fanboyism pulls him the point.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Yoshi vs. Dante - Bracket: <b>Dante</b> - Vote: <b>Yoshi</b> (46/50)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 10/23/2006 6:55:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342831398">message detail</a>
 | #323</td></tr>
<tr class="even"><td>
How is the analysis gonna work for the Royale?<br>---<br>CB06 - Score: <b>46/50 </b>Rank: <b>Tied - 647th </b>Yesterday's Pick:<b> Snake</b> <br>Today's Pick: <b>Yoshi</b> Tomorrow's Pick: <b>Sora</b> Losses: <b>Cortana, Ganon, Zero, MC</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 10/23/2006 6:57:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342832111">message detail</a>
 | #324</td></tr>
<tr class="even"><td>
If Dante can stall until midnight, I would've tied HM for today's point.<br><br><b>TuRtLe</b><br>~~~<br>43/48 in the contest. My analysis topic here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/23/2006 8:28:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342856742">message detail</a>
 | #325</td></tr>
<tr class="even"><td>
<b>Destiny Division:</b> <i>Round 2 - Match 43</i> &#8211; (1)Sora vs. (4)Gordon Freeman<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Sora</b><br>Round 1 &#8211; 75.61% vs. Tingle (24.39%)<br><br>Heh, Tingle nearly avoids the tripling against Sora.<br><br><b>Gordon</b><br>Round 1 &#8211; 58.20% vs. Phoenix (41.80%)<br><br>Gordon Freeman wins a match, yeah yeah, omgwtfbbqwutev<br><br>Ok,
you know it&#8217;s bad when Gordon Freeman makes it into Round 2. Sad thing
is, his game outsold Phoenix&#8217;s game by an enormous amount, and yet he
still won with only 58%. Gordon doesn&#8217;t belong in Round 2. In fact, I
don&#8217;t even want to analyze this match. Time to go off on a tangent with
another&#8230;<br><br><b>Real Men, Real Snubs</b> - <i>Donkey Kong</i><br><br>He
hips. He hops. He pops rhymes and he don&#8217;t stop. He&#8217;s Donkey Kong, and
he&#8217;s a real man, and a snub in the 2006 Character Battle.<br><br>*Shot of DK slapping his bongos*<br><br>Donkey
Kong has been a 2002 regular in these Contests, and he always seems to
put on a show. In 2002, the Ape entered the field as a 4-seed, with
hopes to meet his old-rival Mario in Round 3 and have a good show.
However, his performances there were pathetic. 61% against Bub? 51%
against Aya Brea? Who the **** are those people? This is the legend
Donkey Kong we are talking about! Mario then proceeded to beat the
living hell out of him in one of the earliest labeled SFF matches.
Here&#8217;s hoping that 2003 would be better for the King of Swing.<br><br>*Shot of DK being pummeled by Mario*<br><br>Kong
looked a little better in 2003, with a win over Lara, who didn&#8217;t look
too bad in 2002. However, his Round 2 match was against Vercetti, in
one of the most fun to watch matches I&#8217;ve seen. Back and forth the two
went, but the Hawaiian Shirt night vote proved to be too much, and DK
lost. Donkey Kong returned in 2004 to face Vivi, who many thought he
would beat. Yet, the Monkeynatior fell hard against Vivi in one of the
biggest Round 1 upsets of all time. Kawng was looking bad, could he
turn in around in 2005? Going 50-50 with Master Chief and ending at
over 30% on Base Link says yes, he could!<br><br>*Shot of DK valiantly fighting Master Chief*<br><br>But
where is he now? He isn&#8217;t in this Contest, that&#8217;s for sure. Yeah, we
knew DK really wasn&#8217;t that high, and that&#8217;s been confirmed by Master
Chief&#8217;s loss to Sub-Zero, but DK was always one to have an interesting
match. Instead, in his place, we get exciting bouts like 90% of the
female matches! C&#8217;mon DK, we need you back. Make things interesting for
us again..<br><br>*Shot of DK frowning in a lone spotlight*<br><br>Donkey Kong. A real man, and a real snub.<br><br><b>Moltar&#8217;s Bracket Says:</b> Sora will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Sora: 67% - Gordon: 33%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>First we see Gordon win a match, and now we'll probably see someone break 60% on him. NOOOOOOOOOOOOOOOOOOOO.<br><br>I refuse to let the tradition die!1!<br><br>Prediction: Sora with 59.99%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br> <b>Sora</b><br><br><i>Previous Matches:</i><br><br>Sora &#8211; 75.61% -- 93,568<br><br>Tingle &#8211; 24.39% -- 30,176 <br><br><b>Gordon Freeman</b><br><br><i>Previous Matches:</i><br><br>Gordon Freeman &#8211; 58.2% -- 64,324<br><br>Phoenix Wright &#8211; 41.8% -- 46,204 <br><br>HOLY CRAP GORDON FREEMAN WON A MATCH! <br><br>It&#8217;s
great to see Gordon Freeman actually in the second round after, what,
four years? It took him a while, but he finally caught a break. He
didn&#8217;t just scrap by either, he completely <i>rocked</i> his match against Phoenix Wright. Unfortunately for the good Dr. Freeman, he&#8217;s up against a KH2 monster in Sora. What <i>is</i> fortunate about this match is getting to see TINGLE out rank Gordon Freeman &#8211; and it is going to happen.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/23/2006 8:28:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342856906">message detail</a>
 | #326</td></tr>
<tr class="even"><td>
Sora should have absolutely no problem dominating this match from
beginning to end. He looks crazy this year and there&#8217;s no way he
struggles to put up huge numbers here. Freeman&#8217;s 2005 ranking seems
quite suspect after his match with Phoenix Wright, but perhaps we&#8217;ll
get an idea of how far it&#8217;s off here. Again, the most important thing
about this match is TINGLE &gt; FREEMAN <i>!!</i> <br><br><b>Aitch Emm&#8217;s Bracket:</b> Sora<br><br><b>Aitch Emm&#8217;s Prediction:</b> Sora &#8211; 76% ; Gordon Freeman &#8211; 24%<br><br><b>Aitch Emm&#8217;s Vote:</b> Gordon Freeman<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>There
really isn't too much to say about this match, other than it's the
first time in over 14 billion years (the approximate age of the
universe that ended about three weeks ago) that Gordon Freeman is in
the second round. What a cataclysmic accomplishment, Gordy. Fortunately
for him, he won't have to continue winning.<br><br>Obviously, the top
seeded Sora won't be in any danger here, and coming off what looks to
be a very impressive Kingdom Hearts II boost, he'll be stronger than
ever. Of course, the keyblade weilder (and the KH series in general) is
infamous for his inability to really destroy the weak, so that will
help Gordon a bit. All in all, an easy win for Sora, but he still won't
get that tripling he's been after for a few years.<br><br>My prediction: Sora def. Gordon Freeman (67-33)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>In
Round 1, Gordon broke one of his time honored traditions. Now it's
GFRW, which isn't nearly as cool. And in Round 2... he's breaking
another! Why, Gordon, why? All your little quirks&#8230; they're all going
away! Now what are you to us? Just that guy from Half Life. That may
appease Half Life fans, but it isn't winning <i>me</i> over. (not yet, anyway)<br><br>Some
of you might wonder what the other tradition is. The other tradition is
always looking to lose with at least 40%. Yeah, because Gordon
Freeman's got those wacky fanatical fans. But you know what? Those
wacky fanatical fans? They <i>love</i> oversized keys. Oh yeah, it's
true. I've researched this. So, what's going to happen is Sora's going
to take just a little bit of Gordon's diehard 40% and he's going to use
it to break Gordon's last tradition.<br><br>And what's Gordon without his traditions? The novelty is gone! I've got a prediction&#8230; so let's make this one official. <b>BOLD PREDICTION:</b> Gordon Freeman gets his lowest seed yet next character battle, 7 or less!<br><br><b>Lopen's Prediction:</b> Sora with 64.79%.<br> <br> <br> <br><b>KH&#8217;s Analysis</b><br><br> lol x-stats history<br><br><b>SORA</b><br> <br><i>"Maybe my memories are fake. But they're still mine, and I'm gonna be true to them."</i><br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 39th Place [21.17%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 21st Place [26.97% ]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 32nd Place [23.54% ]<br><br>Sora comes off a decently impressive performance against Tingle (*kills self*), and continues his utterly predictable run here.<br><br><b>GORDON FREEMAN</b><br> <br><i>"..."</i><br> <br>Summer 2002 Contest<br>Extrapolated Strength --- 53rd Place [11.31%]<br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 53rd Place [15.35%]<br> <br>Summer 2004 Contest<br>Extrapolated Strength --- 54th Place [13.40%]<br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 40th Place [20.88%]<br><br>Last match never happened.<br><br><i>Notable Releases Since Last Appearance</i><br><br>Sora: Kingdom Hearts 2 (PS2)<br>Gordon Freeman: N/A<br><br><i>Upcoming Releases</i><br><br>Sora: N/A<br>Gordon Freeman: N/A<br> <br>The
one question here is how Gordon will look...he did very well on Leon
Kennedy, who is looking like a total beast right now. But he gave up
42% of the vote to ****ing <i>Phoenix Wright.</i> This is such a crapshoot for me, and I don't know what to say here. Um...
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/23/2006 8:30:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342857286">message detail</a>
 | #327</td></tr>
<tr class="even"><td>
Karma Hunter's Vote: Gordon Freeman. He must win <i>!!</i><br><br><b>Karma Hunter's Krazy Prediction: Sora with 72.58%.</b><br> <br>This
seems crazy, no? I do think Gordon Freeman would lose to Tingle,
actually. Sora is going to look like a beast here, and the only thing
that stops me from going higher is the reality that Sora can't blow out
crap and that GF is potentially nonlinear.<br><br>Upset Potential: 1%<br><br>GORDON FREEMAN IS A LOOSE CANNON NOW WE DON'T KNOW WHAT HE COULD DO!<br> <br><br> <br><b>Guest&#8217;s Analysis</b> - <i>Pats_Dynasty</i><br><br>HOLY CRAP WTF GORDON FREEMAN WON A MATCH?!?!?!<br> <br>Now
that that&#8217;s out of my system, I can get to the topic at hand. Sora,
arguably (and probably) the least deserving one seed of the entire
contest, is matched up against Gordon Freeman, the man who has finally
beaten all odds and won a match. Granted, it was against Phoenix
Wright, but hey, a win&#8217;s a win.<br> <br>Last round, Sora went out and
disappointed, to say the least, putting up only just over 75% on
Tingle. Whether the LoZ fanbase was a part of that remains to be seen,
but I personally thought that it wouldn&#8217;t matter, because the
KHII/Square fanbase would wipe out a good chunk of the Zelda vote, and
give Sora a respectable shot at showing his true strength against
Tingle. Boy was I wrong.<br> <br>Gordon Freeman went and imploded the
universe last round, taking out Phoenix Wright with 58.2%. This doesn&#8217;t
show much other than Phoenix Wright&#8217;s status as ultra-fodder, and I
wonder that now with HL2 and a maybe a good 6 seed he&#8217;d be able to
crack Round Two next year.<br> <br>Alas, it is not meant to be for
Gordon Freeman. Although Sora was exposed against Tingle, he is still
far too strong for Gordon to take out. The match will be interesting
only to see if Gordon holds true to his other quirky trend: He&#8217;ll never
dip below 40%.<br> <br>Pats&#8217; Bracket : Sora<br>Pats&#8217; Vote: GFWATTNW (Wins All The Time Now, WHOOOO)<br>Pats&#8217; Prediction: Sora with <b>59.99%</b><br> <br>Sora looks weak as he is unable to crack 60% on the Freemeister.<br><br> <br> <br>Crew
Consensus: From 42% on Leon, to 58% on Phoenix, to getting destroyed by
Sora? We'll see for Freeman. Huge range on this one.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/23/2006 8:31:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342857536">message detail</a>
 | #328</td></tr>
<tr class="even"><td>
<i>How is the analysis gonna work for the Royale?</i><br><br>No clue yet.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Yoshi vs. Dante - Bracket: <b>Dante</b> - Vote: <b>Yoshi</b> (46/50)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/23/2006 8:39:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342860039">message detail</a>
 | #329</td></tr>
<tr class="even"><td>
I can't wait for Phoenix to make it into next years contest and actually do decently, while Gordon never gets in again.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=254355" class="name">Lugia2</a> |
Posted 10/23/2006 8:49:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342862712">message detail</a>
 | #330</td></tr>
<tr class="even"><td>
Speaking as a guy who doesn't like GF all that much...<br><br>Who loves the Zelda series...<br><br>I JUST CAN'T SEE GORDON LOSING TO TINGLE!<br><br>Dear lord...Anyway, I see GF getting more votes, due to Sora anti-votes, and, well...likeability.<br><br>GF is still screwed though.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=640243" class="name">Big Bob</a> |
Posted 10/23/2006 9:04:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342866966">message detail</a>
 | #331</td></tr>
<tr class="even"><td>
<i>Big Bob's completely biased and nonsensical analysis</i><br><br>All
right, we've got Sora and Gordon Freeman. Sora failed to break 80% on
what is EASILY the most hated character in the Zelda series, and Gordon
finally destroyed the universe once and for all in his defeat of
Phoenix Wright.<br><br>And now, it's time for Gordon to prove his
worth. He beat Phoenix easily, and now he can beat Sora too. After all,
last year he did well on Leon S. Kennedy, and recently Leon put Bowser
to the test in a match that was much closer than expected. Plus,
beating Phoenix Wright is no joke. Phoenix gets more exposure by the
day, his game constantly sells out, and he has a highly anticipated
sequel on the way. Half-Life 2 did wonders for Freeman.<br><br>So what
does Sora have? KHII? Oh sure, just look at Aeris and Squall. THEY sure
overperformed thanks to it. NOT. Sora barely tripled a joke character.
He's just that pathetic.<br><br>Bob's prediction: <b>Gordon Freeman over Sora with 59.99%</b><br><br>Phoenix for life!<br>---<br>Gordon
Freeman finally won, but somehow, the universe survived... thus
allowing me to tell said universe about how I was owned by <b>NClark128</b>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/23/2006 9:25:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342872200">message detail</a>
 | #332</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Haha, way to go, Yoshi! This
better put me on the leaderboard. If I'm not there yet, it's going to
be because of this bastard.....Gordon Freeman, who defied all stupid
logic to beat Phoenix Wright. Well, Sora is no Phoenix Wright; this is
going to be a beat down.<br><br>My vote: Sora<br>My bracket: Sora<br>My prediction: Sora wins with 78%<br><br>Whew,
not too far out there on the prediction, I'm highest of course, but
HM's got 76%. Yup, Tingle &gt; Gordon Freeman. How scary is that?<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=981127" class="name">Cavalier Lowen</a> |
Posted 10/23/2006 9:26:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342872513">message detail</a>
 | #333</td></tr>
<tr class="even"><td>
I'm more worried about Agent 47&gt;Gordon Freeman.<br>---<br>Z1mZum owned me in the guru contest (by two points!).  Damn you Z1mZum!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/23/2006 9:29:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342873226">message detail</a>
 | #334</td></tr>
<tr class="even"><td>
I can't believe HM's the only other person who expects Tingle &gt; Freeman.  Then again, it <i>is</i> HM, who is likely blinded by LoZ bias.  But still, Tingle <i>is</i> from LoZ, no matter how disliked or insignifant he is.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2035700" class="name">Pats_Dynasty</a> |
Posted 10/23/2006 9:54:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342879846">message detail</a>
 | #335</td></tr>
<tr class="even"><td>
Dammit Ulti, I thought I was the only one this crazy.<br>---<br>"Everyone is born right handed, only the best can overcome it." - Super Janitor
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 10/23/2006 10:08:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342883039">message detail</a>
 | #336</td></tr>
<tr class="even"><td>
Change my pick to 59.98%.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), Castlevania: LoI, MMZX, FFL2
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/23/2006 11:08:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342895471">message detail</a>
 | #337</td></tr>
<tr class="even"><td>
#38!<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=152338" class="name">Lopen</a> |
Posted 10/23/2006 11:12:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342896098">message detail</a>
 | #338</td></tr>
<tr class="even"><td>
By the way, I think Freeman would struggle quite a bit with Tingle in a
match. The only reason I had Freeman getting so much is because I think
his voting base is weird. <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/23/2006 11:47:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342901559">message detail</a>
 | #339</td></tr>
<tr class="even"><td>
Yoshi vs. Dante<br>+7 HM<br>+6 Ulti<br>+5 Yo<br>+4 Guest<br>-1 Mo<br>-2 KH <br>-3 Lo<br><br><b>The Rankings</b> (Through Yoshi vs. Dante)<br>1. Karma Hunter (178)<br>2. Master Moltar (170)<br>3. Heroic Mario (166)<br>4. UltimaterializerX (149)<br>5. Yoblazer (146)<br>6. Board 8 (140)<br>7. Lopen (94)<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/24/2006 3:27:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342993883">message detail</a>
 | #340</td></tr>
<tr class="even"><td>
Yoshi.......................50.55% 65497<br>Dante.....................49.45% 64072<br>TOTAL VOTES.................129569 <br><br>31.18% of the brackets predicted this match correctly.<br><br>After
Yoshi's rather poor performance against Riku, I didn't think the Dino
could pull it off, but he did! This match was just as even as I thought
it would be pre-Contest.<br><br>Today, Freeman is doing rather well against Sora.<br><br>KH - 8<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>HM - 7<br>Moltar - 7<br>Lopen - 7<br>Ulti - 5<br>Yoblazer - 2<br><br>HM wins with the low Yoshi pick.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sora vs. Gordon - Bracket: <b>Sora</b> - Vote: <b>Sora</b> (46/52)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=759072" class="name">cyko</a> |
Posted 10/24/2006 6:47:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343042371">message detail</a>
 | #341</td></tr>
<tr class="even"><td>
sorry it took so long, but this week was busier than expected.  i just sent my analysis, Moltar. <br><br>---<br><i>i have officially been <b>Z1mZum'D </b>in the guru contest.</i><br><b>Vincent Valentine to win the Blast Division!!</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/24/2006 9:13:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343080353">message detail</a>
 | #342</td></tr>
<tr class="even"><td>
<b>Destiny Division:</b> <i>Round 2 - Match 44</i> &#8211; (6)Ryu vs. (2)Mega Man<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Ryu</b><br>Round 1 &#8211; 57.11% vs. Kratos (42.89%)<br><br>Kratos puts up a good fight against Ryu.<br><br><b>Mega Man</b><br>Round 1 &#8211; 69.87% vs. Axel (30.13%)<br><br>Axel likewise does very well against Mega Man.<br><br>Well,
these two didn&#8217;t have impressive Round 1 performances. Yeah, we all
knew Kratos was underrated, but after Leon did so well against Bowser,
Ryu is looking <i>very</i> bad. Mega Man also failed to put up 70% on
Axel, who isn&#8217;t even one of the main characters. I mean, if Axel can
break 30%, what about Sora?<br><br>Let&#8217;s not get ahead though, and
focus on this match. Yeah, Mega Man should win it, but we also will
find out about Ryu&#8217;s value. Has he fallen even farther since 2005, or
is he underrated/overrated thanks to Bowser. As for Mega Man, he&#8217;s
going to need to look good here, because ahead he has Crono, Snake, and
even Sora gunning for him.<br><br>I don&#8217;t think Mega Man can be
connected to Zero like some people want to do (since Zero lost to
Luigi, this means Mega Man is weaker too!!), but I also can&#8217;t say MM
impressed me last round. According to last year&#8217;s numbers, Mega Man
wins with 61%. I think he can outperform Bowser, but I also don&#8217;t think
he&#8217;ll land too far from those projected numbers.<br><br><b>Moltar&#8217;s Bracket Says:</b> Mega Man will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Ryu: 38% - Mega Man: 62%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>Ryu
is slowly working his way through the entire Noble Nine, and he may
very well break 40% on all of them. That's his shtick. Sucks that he
had such a predictable path though.<br><br>Prediction: Mega Man with 58.67%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br> <b>Ryu</b><br><br><i>Previous Matches:</i><br><br>Ryu &#8211; 57.11% -- 66,198<br><br>Kratos &#8211; 42.89% -- 49,713 <br><br><b>Mega Man</b><br><br><i>Previous Matches:</i><br><br>Mega Man &#8211; 69.87% -- 81,959<br><br>Axel &#8211; 30.13% -- 35,340 <br><br>Both
of these two characters weren&#8217;t able to meet expectations in the last
round. Mega Man, in particular, shocked a good number of people by not
even getting <i>70%</i> against Axel of all characters. He was
untested certainly, but it didn&#8217;t speak well of him after how many
blowouts he&#8217;s able to get. On the other hand, Ryu wasn&#8217;t able to hit
60% against Kratos, but there was reason enough to suspect that would
be the case after Kratos&#8217;s game sold so well and he could have be
underrated last year. <br><br>I&#8217;m not sure we&#8217;ll be able to take too
much away from this match unless Ryu is able to snatch over 40% of the
vote. Some people have tossed around some silly Capcom SFF, but I
highly doubt we see anything that suspect in this match. It should be a
pretty normal match, but I&#8217;m unsure of what the general expectation is
here. Ryu could possibly be overrated and Mega Man could have
potentially dropped. It should be interesting to see, but the end
result is Mega Man with ease. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Mega Man<br><br><b>Aitch Emm&#8217;s Prediction:</b> Mega Man &#8211; 62% ; Ryu &#8211; 38%<br><br><b>Aitch Emm&#8217;s Vote:</b> Mega Man<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Here
we have a match between two of the video game industry's all-time
legends. Mega Man will attempt to show us that it'll take more than an
awful picture to keep him from kicking ass, and Ryu will be gunning for
his fourth very respectable performance against his fourth different
Noble 9 opponent.<br><br>This match's result is not at all in question,
but the margin of victory certainly is. On the one hand, Ryu has faced
top-notch competition in the past, including Samus, Snake, Sonic, and a
Bowser which probably needed some drug testing. Despite the caliber of
his opponents, Ryu has not once failed to break 40%. He is an
ultra-consistent performer, and it's very difficult to picture him
getting destroyed by all but the most powerful of contest performers
(i.e. Link and Cloud).
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/24/2006 9:14:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343080512">message detail</a>
 | #343</td></tr>
<tr class="even"><td>On the other hand, Mega Man is extremely good at
beating people up. In fact, the only time he has beaten a non-Noble 9
opponent with less than 60% was his 2004 match against Zero, and that
was an SFF match (where spooky **** tends to go down) at a time when
Zero was actually good. Simply put, the Blue Bomber knows how to win
and win big.<br><br>Obviously,
these conflicting opinions make it tough for me to confidently predict
a percentage. While it's very difficult for me to picture Ryu not
hitting 40% for the first time ever (especially with the aid of that
terrible MM picture), it's also difficult to imagine Mega Man failing
to outperform Bowser and not hitting 60%. So, just <i>how</i> does one satisfy both sides of the argument? With a 60/40 prediction, of course! See! Math good!<br><br>My prediction: Mega Man def. Ryu (60-40)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>
So, let's do the rundown here. What we've seen is Mega Man&#8230; is a Mario
character. Given his weird little display against Yoshi, we know they
share the same blood. However, what we've <i>also</i> seen&#8230; is that
Ryu too, is a Mario Bros. character. "What?", you say? It's all true&#8230;
remember Ryu got 45% on Sonic in 2004. In 2005 he barely scraped up 40%
against <i>Bowser</i>. Now we all know that Sonic would beat Bowser handily! So what does this mean? That's right, Super Mario Bros. series SFF!<br><br>Still doubting? How about the new Mario Party 9? I've got the scoop on this one:<br><br><a class="linkification-ext" href="http://i24.photobucket.com/albums/c38/NeoX-Death/MarPart9.jpg" title="Linkification: http://i24.photobucket.com/albums/c38/NeoX-Death/MarPart9.jpg">http://i24.photobucket.com/albums/c38/NeoX-Death/MarPart9.jpg</a><br><br>As
we can see from how well Ryu's doing, he's clearly not just making some
random cameo appearance. 2 Shines? Beating Mario and Peach at their own
game? Oh yeah, believe it. Ryu's been doing this for years, and it
shows. Mega Man, on the other hand isn't doing so well&#8230; but he's in the
game, at least! Even if he's a recent addition, he's a Mario character
too!<br><br>Okay&#8230; that wasn't <i>all</i> just for my amusement. I
really think we could see some weird results here. I'm not sure where
the "Super Mario Brothers SFF" goes in this one, though. However, I
want to say Mega Man. It seems like that should be the case. Of course,
Ryu's higher on the pecking order than Yoshi, so it won't be <i>too</i> bad. But rest assured, Ryu is better than this match result will make him look!<br><br><b>Lopen's prediction:</b> Mega Man with 63.18%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br> lol x-stats history<br><br><b>MEGA MAN</b><br><br><i>"You can't beat me with fake power!"</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 3rd Place [42.91%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 4th Place [38.60%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 6th Place [35.99%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 7th Place [35.55%]<br><br>Mega
Man has a tough fight (well, for a fodder blowout) with Axel last
round, though Axel's strength has yet to be determined. He's certainly
looking to impress here, that's for sure.<br><br><b>RYU</b><br> <br><i>"Seek an opponent who is your equal. Only then can you improve."</i><br> <br>Summer 2002 Contest<br>Extrapolated Strength --- 10th Place [34.62%]<br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 18th Place [29.70%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 16th Place [29.84%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 25th Place [27.47%]<br> <br>Ryu
comes off a good win against a surprisingly tough Kratos...and he keeps
up his streak of winning a match every year (now being the weakest
character to do so). His road ends here, of course. It's so odd how
he's only made the Sweet Sixteen twice in his long contest career. o.O
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/24/2006 9:15:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343080755">message detail</a>
 | #344</td></tr>
<tr class="even"><td>
<i>Notable Releases Since Last Appearance</i><br><br>Mega Man: N/A<br>Ryu: N/A<br><br><i>Upcoming Releases</i><br><br>Mega Man: N/A<br>Ryu: N/A<br><br>This
is a fitting match. Both characters are Capcom, both get by nowadays
with nothing but the occasional low-budget rehash, and as such both
character's popularities seem resistant to change. Mega Man seems to
have more longevitity here though, and I'm feeling a dominant match on
his part, match picture be damned. Nothing else to say, though I'm
hoping Ryu can perhaps redeem himself here. I'm just not counting on it.<br><br>Karma Hunter's Vote: Mega Man. Metal Blades &gt; Hadoken (which MM has anyway so nyah)<br><br><b>Karma Hunter's Krazy Prediction: Mega Man with 65.48%.</b><br><br>Pure
stats here. Putting Ryu at where his match with Kratos suggests, using
Sora 2k4 to adjust Kratos. Then use a constant MM and there ya go.<br><br>Upset Potential: 0%<br><br>Ryu's peak has come and gone here, and only a true revival of the SF series will ever bring him back. <br><br> <br> <br><b>Guest&#8217;s Analysis</b> - <i>cyko</i><br><br>so,
for a good portion of my work day today, i tried to come up with
something clever or witty to say about this match. i really did. you
know - something about how this analysis sucks and is now about trains
or Guitar Hero 2 (which comes out in 2 weeks!! you better buy it!!
&lt;/shameless plug&gt;) or something like that. but i've got nothing.
see? this match is so boring that even the analysis is boring. the
outcome of this match has been sealed since the moment the bracket was
released. *yawn*<br><br>i suppose there is still the matter of ho much
Mega Man wins by. was Ryu and the Dream Division actually overrated
last year? or has Kratos improved in popularity? has Mega Man lost some
of his popularity? or is Axel surprisingly strong? will there be some
kind of Capcom SFF? old-school SFF? cheesy anime SFF? "i like both of
these guys" SFF? OSFTSTDNGCMCTFIMVC SFF?!?!<br><br>meh.<br><b><i><br>cyko's vote - Mega Man<br>cyko's bracket - Mega Man<br>cyko's prediction - Mega Man with 64.59%</i></b><br> <br> <br> <br>Crew
Consensus: Mega Man with the win. Some are betting on Ryu doing better
than the stats indicate, but the majority has Mega Man redeeming
himself here.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/24/2006 9:19:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343081918">message detail</a>
 | #345</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis</i><br><br>Welcome to my analysis,
I'm-on-the-leaderboard version! After 2 debatable matches to open the
2nd round of the male bracket, we have 2 consecutive snore-fests. By
the way, a lot of people hate the pic because of the version of Mega
Man used; but I personally think the pic is one of the best CJay has
ever done. It looks very artistic, and with a much better background
than a damned brick wall. See, with these boring matches, I get going
on these stupid tangents.......<br><br>My vote: Umm......*flips a coin* Ryu<br>My bracket: Mega Man<br>My prediction: Mega Man with 59%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/24/2006 9:20:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343082169">message detail</a>
 | #346</td></tr>
<tr class="even"><td>
I see MM with 63% here... though I could definitely see MM doing better.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/24/2006 9:21:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343082393">message detail</a>
 | #347</td></tr>
<tr class="even"><td>
Axel isn't surprisingly strong. Anybody who has played KH2, and to a
lesser extent, CoM should have expected that result against Mega Man.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=640243" class="name">Big Bob</a> |
Posted 10/24/2006 9:24:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343083241">message detail</a>
 | #348</td></tr>
<tr class="even"><td>
<i>Big Bob's completely biased and nonsensical analysis</i><br><br>Let
me say this right now: Ryu is a HACK. He fell last year, and he's going
to fall even more this year. He let Kratos break 40% on him. Kratos is
a newb. He's been in two contests and lost two matches. He may have a
sequel coming out, but it's going to be on an obsolete system by the
time it's out. And Ryu hasn't had anything in forever. Mega Man,
however, keeps pumping out games and stretching across systems. He beat
Axel, and let's face it: Axel is tough. Riku did well on Yoshi, and
Sora is beating a pumped-up Gordon Freeman. For Mega Man to get 70% on
him is amazing. And unlike Ryu, Axel isn't a has-been.<br><br>Bob's prediction: <b>Mega Man with 80%</b>.<br>---<br>Gordon
Freeman finally won, but somehow, the universe survived... thus
allowing me to tell said universe about how I was owned by <b>NClark128</b>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/24/2006 9:28:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343084141">message detail</a>
 | #349</td></tr>
<tr class="even"><td>
I'm feeling Big Bob's prediction right now. I really am, y'know?<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/24/2006 9:31:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343084804">message detail</a>
 | #350</td></tr>
<tr class="even"><td>
I <i>pray</i> that's a joke analysis.<br>---<br>"that'll do, pig."
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=5">6</a></li>
<li>7</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=9">10</a></li>
</ul>
</div>


</div>
<img src="genmessage7_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage7_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31144759&amp;page=6" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage7_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>