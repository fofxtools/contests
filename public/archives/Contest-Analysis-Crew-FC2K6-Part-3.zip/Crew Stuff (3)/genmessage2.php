<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage2_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage2_files/nogs.css"></head><body linkifytime="200" linkified="3" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage2_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage2_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31144759%26page%3D1"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage2_files/advertisement.gif" alt="advertisement" height="10" width="120"></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage2_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage2_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 3
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;page=1">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31144759" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">First Page</a> |
Page 2 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=2">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/16/2006 2:40:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341284713">message detail</a>
 | #051</td></tr>
<tr class="even"><td>
<i>From PortugalTheMann Posted 10/16/2006 9:43:44 AM</i><br><i>I'll totally do Zelda/Terra , if I can steal it from Ashe.<br><br>Anyway,
I'm surprised no one on the crew went over 70%, I wasn't expecting it
myself, but I thought people would still be skeptical of The Boss'
strength. Looks like Celes is one weak piece!</i><br><br>I would prefer if you would take Auron/Subby, but it is up to you. My fault for getting greedy, eh? ;o<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2621370" class="name">LinkLegend27</a> |
Posted 10/16/2006 2:46:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341286030">message detail</a>
 | #052</td></tr>
<tr class="even"><td>
Tag.<br>---<br>CB5:26 out of 29.<br>BSE:78 out of 80.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/16/2006 4:11:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341304895">message detail</a>
 | #053</td></tr>
<tr class="even"><td>
<i>Just emailed by guest writeup. Lemme know if you got it!</i><br><br>Got it!<br><br><i>I'll totally do Zelda/Terra , if I can steal it from Ashe.</i><br><br>Hmm, well, since Zelda/Terra was the first choice, Ashe can keep it. Auron/Sub-Zero is still up though.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Tifa vs. The Boss - Bracket: <b>Tifa</b> - Vote: <b>The Boss</b> (32/36)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/16/2006 4:14:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341305584">message detail</a>
 | #054</td></tr>
<tr class="even"><td>
Rikku................58.28% 75494<br>Kairi..................41.72% 54043<br>TOTAL VOTES...............129537<br><br>58.22% of the brackets predicted this match correctly.<br><br>Eww,
Kairi being strong. That's just wrong. This match also received a ton
of votes, and it seems Kairi being from KH not only killed the last
perfect, but also alot of other brackets.<br><br>Today, Tifa is nearly tripling The Boss.<br><br>Lopen - 7<br>KH - 6<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience) - 6<br>Ulti - 5<br>HM - 5<br>Moltar - 5<br>Yoblazer - 2<br><br>Ulti finally gets another point.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Tifa vs. The Boss - Bracket: <b>Tifa</b> - Vote: <b>The Boss</b> (32/36)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3657433" class="name">LusterSoldier</a> |
Posted 10/16/2006 4:50:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341314124">message detail</a>
 | #055</td></tr>
<tr class="even"><td>
I sent my analysis to Moltar.  When my analysis gets posted, I would like the beginning of my analysis to say "<b>Guest&#8217;s Analysis</b> - <i>Luster Soldier</i>" (minus the quotes of course) because Luster Soldier was the username of my old account.<br>---<br><b>Luster Soldier&gt;</b> - Popular at school. <b>~Shield Bearer~ | ~Data Analyst~</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3602792" class="name">Garsha_III</a> |
Posted 10/16/2006 7:51:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341361336">message detail</a>
 | #056</td></tr>
<tr class="even"><td>
Does anyone have the archive for the last two topics?<br>---<br><b>The Beatles &gt;&gt;&gt;&gt; Lolicon.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/16/2006 8:39:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341374271">message detail</a>
 | #057</td></tr>
<tr class="even"><td>
Heh, I had it like that anyway, Luster.<br><br><i>Does anyone have the archive for the last two topics?</i><br><br>I've sent them to creative, so whenever he puts them up on his site.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Tifa vs. The Boss - Bracket: <b>Tifa</b> - Vote: <b>The Boss</b> (32/36)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/16/2006 8:39:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341374428">message detail</a>
 | #058</td></tr>
<tr class="even"><td>
<b>Limit Division:</b> <i>Round 2 - Match 36</i> &#8211; (3)Jill Valentine vs. (2)Princess Peach<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Jill</b><br>Round 1 &#8211; 62.03% vs. Sheena (37.97%)<br><br>Sheena may have made the end result look a lot better for her, but Jill still wins it.<br><br><b>Peach</b><br>Round 1 &#8211; 83.10% vs. Daisy (16.90%)<br><br>Peach basically faces her clone, and manages 83% on her.<br><br>Ahh,
this match. It&#8217;s pretty weird to talk about personally, as I had Jill
up until the final hour of the bracket period. I then switched to
Peach. It seemed like the safe pick, right?<br><br>Well, after Round
1&#8230;I don&#8217;t know. Neither impressed me much last round. Jill started off
well against Sheena, but Sheena sliced into the percentage and ended up
looking good. Peach, on the other hand, practically had a free &#8220;Kick
ass&#8221; card, yet couldn&#8217;t even manage 85% on a freakin&#8217; clone of hers. I
mean, does Daisy even have a fanbase of 18,000+? Anyway&#8230;now we arrive
here.<br><br>There was lots of talk pre-Contest about Peach. It was
tough as nails to predict where she would land. She could end up
anywhere from low fodder (lol wario) to decent midcarder (y helo thar
dk). It all depended on if she would get the backing of the Mario
fanbase, which wasn&#8217;t guaranteed (lol wario again). They supported her
over Daisy, but Jill is in a whole &#8216;nother league. While she seems to
be getting weaker over the years, she&#8217;s still a semi-decent midcarder.
If Sheena = Lloyd indirectly, then Jill is about at her 2004 number.
Can I see Peach going toe-to-toe with Hayabusa?<br><br>Pre-Contest, I said no. Now, I say&#8230;no still. Yeah, I still don&#8217;t have high hopes for Peach.<br><br>&#8220;But
Moltar!,&#8221; You scream, &#8220;Then why did you pick Peach to beat Jill.&#8221;
Honestly, Peach just feels like the safe pick here. Jill probably
wouldn&#8217;t go 50-50 with Hayabusa anymore, and if Sheena is under Lloyd,
then Jill has gotten even weaker. All Peach needs to do is be at
low-midcarder level (22-23%) on Base Link and she wins the match. Peach
will probably get the Nintendo and the &#8220;I know her, she&#8217;s a freakin&#8217;
Mario character!&#8221; backing, and RE characters not named Leon haven&#8217;t
been looking so hot. Jill has a very good chance, but I&#8217;m going with
Peach for the win.<br><br><b>Moltar&#8217;s Bracket Says:</b> Peach will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Jill: 47% - Peach: 53%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>Anyone
notice how all the hype for this match completely died after Claire's
loss to Kairi and Jill's percentage bleed against Sheena? It's as if
the hype for this match never even happened, though there's good reason
for hype here to exist. Peach only performed well because she was
facing an exact clone of her in the first round, and no one gives a
crap about Daisy.<br><br>As for why this match is hyped, uh... everyone
else and their walls of text can deal with that. I'm sticking with
fanboyism alone here!1!<br><br>Prediction: Peach with 54.45%<br> <br> <br> <br><b>HM&#8217;s Analysis</b><br> <br><b>Jill Valentine</b><br><br><i>Previous Matches:</i><br><br>Jill Valentine &#8211; 62.03% -- 70,699<br><br>Sheena Fujibayashi &#8211; 37.97% -- 43,275 <br><br><b>Princess Peach</b><br><br><i>Previous Matches:</i><br><br>Princess Peach &#8211; 83.1% -- 90,611<br><br>Princess Daisy &#8211; 16.9% -- 18,423 <br><br>This
is another one of those special debated match-ups of the female
bracket. The other we had was Claire/Kairi &#8211; and that turned out to be
pretty good &#8211; but this match is definitely more important from a point
perspective and features two <i>popular</i> females going at it.
Personally, my initial reaction was always to go with Peach here and I
slowly gained more confidence in the pick as time went on.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/16/2006 8:40:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341374588">message detail</a>
 | #059</td></tr>
<tr class="even"><td>A lot of people think that Peach has no fans or
that no one really cares about her because she doesn&#8217;t do much &#8211; but
you could say that about <i>tons</i>
of characters. That doesn&#8217;t stop people from liking those characters
for whatever reason. It helps that Peach is perhaps the most well-known
female, and one of the most well-known characters, in this entire
bracket. <br><br>Peach&#8217;s competition, while not weak, isn&#8217;t exactly a <i>beast</i> herself. She allowed <i>Sheena Fujibayashi</i>
to nearly bring her under 40%, and she lost the day vote hard in the
process. Resident Evil certainly hasn&#8217;t appeared to have lost a step
here, but the only <i>real</i> impressive RE character as of late has
been Leon Kennedy thanks to Resident Evil 4. Jill should gain no such
benefit considering she has absolutely no role, or even a mention, in
the game. <br><br>Aside from Peach&#8217;s iconic history in the Mario
series as a damsel-in-distress, she has recently gotten her own game on
the hottest system in gaming right now &#8211; the Nintendo DS. Super
Princess Peach was given some pretty good scores and it sold about
253,000 copies in America (for those keeping up, that&#8217;s 47,000 less
than Dirge of Cerberus). I think Peach should be able to benefit some
from that, even if only slightly. She at least can claim that she is
more than a damsel-in-distress with a main game, even if she has played
the DID role for most of her history. <br><br>Peach coming the revered
Super Mario Bros. series should get her plenty of votes, too. Mario
characters have looked pretty damn impressive in the past couple of
years, even against characters with big games and plenty of reason to
increase. I think the Mario series as a whole is on a rise and it
doesn&#8217;t look to be stopping anytime soon. I don&#8217;t think this match is
going to be <i>too</i> close &#8211; a Luigi/Zero affair &#8211; but it shouldn&#8217;t
be a blowout either. I predict Peach gets the lead out of the gate and
never looks back. <br><br>It would be <i>great</i> if Peach could just
dominate Jill tonight and give me some reason to jump on board the
PEACH &gt; TIFA bandwagon! Well, maybe that bandwagon isn&#8217;t even
established yet&#8230;BUT I WILL BE THERE SHOULD PEACH DO THE UNTHINKABLE.
PEACH &gt; TIFA FOR LIFE. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Princess Peach<br><br><b>Aitch Emm&#8217;s Prediction:</b> Princess Peach &#8211; 54% ; Jill Valentine &#8211; 46%<br><br><b>Aitch Emm&#8217;s Vote:</b> Princess Peach<br> <br> <br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Well,
here it is - the hottest match of the entire ****ing bracket. It's a
shame that both of these lovely ladies can't move on, but they, them's
the breaks. Let's get on with the match, shall we?<br><br>This is
easily the most debated female match of Round 2, and one of only two
with the potential to be any good. However, this is potential that I'm
not buying, as I think Peach will take this match relatively easily.
For me, there's never been any reason to assume Jill being far-and-away
stronger than Claire Redfield. Both star in two RE games that have been
whored out to every console known to man, and while Jill is the first
RE diva, Claire has the more popular games under her belt. If I were to
take an educated guess, I'd say that Jill's ceiling would be around
Kairi's level (enough to go toe-to-toe with Kairi and possibly eek out
a win). Now, do I think Princess Peach can beat Kairi? Yes. Easily.<br><br>Keeping
with my very risky and potentially stupid "Jill is approximately equal
to Kairi" theory, it must be noted that Kairi was able to score almost
42% against Rikku. Do I think Peach can beat Rikku? No, not quite, but
I do think she'd get very close. I have the craziest urge to go high in
this match, but I'm getting warning signs from both sides. One is
saying "Jill isn't weak, you idiot." and the other is saying "You're
overestimating Peach, bozo." Since these voices are starting to scare
me, I think it best to take Peach in a relatively easy (but not
dominant) win.<br><br>My prediction: Princess Peach def. Jill Valentine (56-44)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/16/2006 8:41:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341374823">message detail</a>
 | #060</td></tr>
<tr class="even"><td>
<b>Lopen&#8217;s Analysis</b><br> <br> Another match where I only have one right. Maybe to save my credibility I should stop bringing this up&#8230; <i>nah!</i>
Anyway, I had Sheena here, in hopes that Jill would've dropped some
more, and that Sheena was higher than Lloyd. Sheena beating Jill was
the big speed bump I foresaw in my plan. Peach? Peach is fodder, folks!
I had no internal debate about Sheena &gt; Peach. And yeah, call me
stubborn, but I <i>still</i> think Sheena could beat Peach.<br><br>People
aren't drones. They aren't just gonna vote Peach because she's a Mario
character. Check out the favorite Mario character poll: Peach got 2% or
so. Guess who the only character was that was even <i>close</i> to that area was. Yeap, Wa-friggin-Luigi. It's easy to accept Wa-friggin-Luigi as fodder, right? <i>Right?</i><br><br>Of
course I can't base my whole argument on a "favorite Mario character"
poll&#8230; but that's concrete evidence that supports what I've seen in
life. Sure, we all <i>know</i> Peach. But do we <i>like</i> Peach? I'd
say most of us are ambivalent when it comes to Peach. Will that get her
votes? Sure, it gets Pac-Man votes. Will it get her big <i>wins</i>, though? Absolutely not.<br><br><b>Lopen's Prediction:</b> Jill Valentine with 63.12%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br>Jill Valentine<br><br>Summer 2002 Contest<br>Extrapolated Strength --- 16th Place [27.37%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 28th Place [24.56%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 37th Place [20.64%]<br><br>After
winning her first match since making the Sweet Sixteen in 2002, Jill is
primed for an attempt to do it again. Unfortunately, she has nothing
here to make her look like the definite favorite. Jill basically met
expectations in her last match, but not much more...if anything, some
considered it disappointing. Of course, Peach's insane range may just
hand her the win anyway...<br><br>Princess Peach<br> <br>lol N/A<br><br>In
the biggest example of rSFF we've ever had, Peach squeaks out a victory
against Daisy and now gets a chance to prove herself against, y'know, a
<i>real</i> opponent. Peach may have exceeded some people's
expectations and failed to meet those of others, but in a completely
worthless match like that it's probably better if we pretend she's
never been in a contest before. Yup...<br><br><i>Notable Releases Since Last Appearance</i><br><br>Jill Valentine: N/A<br>Princess Peach: Super Mario Bros. 2 (NES), Super Mario RPG (SNES), Super Princess Peach (DS)<br><br><i>Upcoming Releases</i><br><br>Jill Valentine: Resident Evil: Umbrella Chronicles (WII)<br>Princess Peach: N/A<br><br>The
most debated match of the (female) second round is here...and I'm
really thinking it's going to be anticlimactic. I'm finding it harder
and harder to see Jill winning here, and that really saddens me.<br><br>For one, while the idea of a <i>second</i>
Nintendo boost is more or less ludicrous, there has been little to
suggest that Nintendo has actually *lost* a step since its big boost in
2005. Peach, being a Mario character, can only benefit from this boost.
So while Jill beating Luigi could be argued way back in 2003, there's a
chance that Jill would be losing to <i>Wario</i> today. Though I'm not sold on her being stronger, Peach isn't going to be too far off from Wario.<br><br>Peach also has the monster of SSBM on her side. While I believe Jill 2k4 is underrated, the fact that <i>Captain Falcon</i> and <i>Ness</i>
would be projected to have close matches with her cannot be ignored.
Peach absolutely manhandles either. The fact that Peach's match with
what was essentially <i>herself</i> nearly garnered as many votes as Jill/Sheena is not something to overlook here.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/16/2006 8:42:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341375047">message detail</a>
 | #061</td></tr>
<tr class="even"><td>
Yes, Leon impressed against Bowser. What does this mean? It means that
if Jill was the main character of RE4 we could have seen her make a run
at Tifa. darn you capcom<br><br>I
expect Peach to take this handily, and this is a low percentage for me.
I'm asking Jill to prove me wrong, but I asked the same of The Boss,
too.<br><br>I don't make a habit of being wrong.<br><br>Karma Hunter's Vote: Jill Valentine. FOR DAISY<br><br><b>Karma Hunter's Krazy Prediction: Princess Peach with 54.23%.</b><br> <br>Yeah...easy win, but no blowout for the embodiment of female stereotypes in gaming...<br><br><b>Upset Potential: 35%<br><br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br><br>Hope
springs eternal, however...let's say, for argument's sake, that Jill
2k4 is underrated and that Jill 2k3 is her value today. Jill easily
beats any version of Donkey Kong that isn't overrated by MC 2k5, and
that's Peach's absolute ceiling IMO. Even better for Jill is that she's
behind Squall 2k3, who is potentially underrated by Link/Samus SFF. The
optimal Jill Valentine is a value that Peach isn't touching, and never
will touch. If Jill can retain a fraction of that magic that she had in
her prime...well, she very well could prove me wrong.<br><br>So here's hoping!<br><br>Upset Prediction: Jill Valentine with 52.08%.<br> <br> <br> <br><b>Guest&#8217;s Analysis</b> - <i>Luster Soldier</i><br><br><b>Previous matches</b><br><br>Jill Valentine/Sheena Fujibayashi<br><br>Jill Valentine - 62.03%<br>Sheena Fujibayashi - 37.97%<br><br>Princess Peach/Princess Daisy<br><br>Princess Peach - 83.10%<br>Princess Daisy - 16.90%<br><br><b>x-stats history (based off Base Link)</b><br><br>Jill Valentine<br><br>Summer 2002 Contest - 27.37%<br>Summer 2003 Contest - 25.38%<br>Summer 2004 Contest - 22.13%<br><br>Princess Peach<br><br>No previous contest history.<br><br>In
the first match, Jill Valentine managed to defeat Sheena Fujibayashi
fairly easily without too much trouble at all. While Jill has been
slowing falling in the x-stats over the years, her first 60%+ victory
shows she hasn't completely fallen off the map just yet.<br><br>Princess
Peach managed to dispose of Princess Daisy with the help of SFF. Even
without SFF, Peach could probably get at least 70% against Daisy.<br><br>I
don't know why this match is even up for debate. Even though Jill
performed better this year, it doesn't really pose a threat to Peach.
Even though we don't have a value for Peach in the x-stats yet, the
only thing to work off of is her match with Daisy. Jill was able to
pull off 40% against Squall back in 2003. Since Peach cannot possibly
be stronger than Squall, it follows that Peach will most likely not win
with over 60%.<br><br>Looking at an earlier match, Samus/Ada, many
people were expecting Ada to do fairly decently against Samus because
of her absolute destruction of Jade. Instead, Ada got sent to the trash
and Samus made Ada look like nothing at all. I have a feeling this sort
of situation could happen here but Peach will end up winning the match.
This match will make Peach look weaker than she appears to be.<br><br><b>Luster Soldier's prediction:</b> Princess Peach with 53.77%<br><br> <br> <br>Crew Consensus: While it's likely to be close, the Crew says Peach will squeak out the victory.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/16/2006 8:45:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341376012">message detail</a>
 | #062</td></tr>
<tr class="even"><td>
Man, I really don't get Lopen sometimes.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=977109" class="name">NewLib</a> |
Posted 10/16/2006 8:46:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341376338">message detail</a>
 | #063</td></tr>
<tr class="even"><td>
Lopen seems to live under the motto, "If your going to risk it, risk it big."<br>---<br>--NL--<br>Z1mZum made me look like Toadette.  And made me nominate her.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2568612" class="name">Draco1214</a> |
Posted 10/16/2006 8:46:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341376347">message detail</a>
 | #064</td></tr>
<tr class="even"><td>
His percentage is too high, but he has a point in his argument. I mean, how many Nintendo fans really care about Peach?<br>---<br>Character Battle V Score - <i>33/36 points</i><br>Current Prediction - <b>Tifa Lockhart</b> vs. The Boss
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/16/2006 8:46:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341376424">message detail</a>
 | #065</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Oh boy.....this match is
giving me more of a headache now than I ever expected it to. When I
made this pick, and even still when the contest started, I thought
Peach had this match won without question. But now, I'm having doubts
and worries, as there have been many people coming forward and talking
about how strong Jill is, and how weak Peach should be.<br><br>But my
bracket has been all about saying "Screw the stats, stick to the basic
principles." My bracket is looking pretty good with this theory (hell
yeah, Luigi &gt; Zero). And the principle here is, Mario character vs.
Resident Evil character. It seems pretty crazy to believe that Resident
Evil would beat Mario.<br><br>My vote: Princess Peach<br>My bracket: Princess Peach<br>My prediction: Princess Peach with 55%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/16/2006 8:48:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341376801">message detail</a>
 | #066</td></tr>
<tr class="even"><td>
That argument was shot once I realized how many Sony fans care for Kairi.<br><br>And
I don't think Nintendo fans are that different when it comes to useless
characters who get alot of screentime in a strong franchise.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Tifa vs. The Boss - Bracket: <b>Tifa</b> - Vote: <b>The Boss</b> (32/36)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=1389806" class="name">Heroic Citan</a> |
Posted 10/16/2006 8:48:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341376810">message detail</a>
 | #067</td></tr>
<tr class="even"><td>
How can you seriously think Sheena would beat Jill. Did you not see how
weak ToS characters were? Taking Sheena over Jill isn't risky, it's
stupid =\<br> <br>---<br><b>Nominate Citan for Summer 2007!</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3657433" class="name">LusterSoldier</a> |
Posted 10/16/2006 8:53:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341378301">message detail</a>
 | #068</td></tr>
<tr class="even"><td>
Ugh, so many predictions that are close to mine. To get a fairly good
amount of points for the Guest, Peach must fall below 54%.<br>---<br><b>Luster Soldier</b> - Popular at school. <b>~Shield Bearer~ | ~Data Analyst~</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2568612" class="name">Draco1214</a> |
Posted 10/16/2006 8:54:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341378526">message detail</a>
 | #069</td></tr>
<tr class="even"><td>
It'd be funny if Lopen gets the point because he is the only one with Jill winning.<br>---<br>Character Battle V Score - <i>33/36 points</i><br>Current Prediction - <b>Tifa Lockhart</b> vs. The Boss
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 10/16/2006 8:54:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341378687">message detail</a>
 | #070</td></tr>
<tr class="even"><td>
How is Peach over Daisy rSFF? Isn't rSFF where the typically weaker
character wins because of the shared fanbase, everyone likes that
character?<br><br>Also, while Lopen can pick whichever character he likes, he really should have gone <i>much</i> lower. Come on, even us guests aren't <i>that</i> insane.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/16/2006 8:58:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341379611">message detail</a>
 | #071</td></tr>
<tr class="even"><td>
<i>It'd be funny if Lopen gets the point because he is the only one with Jill winning.</i><br><br>I thought about that...heh.<br><br><i>How is Peach over Daisy rSFF? </i><br><br>Because <i>everyone</i> knows Daisy could really break 90% on Base Link! She just got a bad draw!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Tifa vs. The Boss - Bracket: <b>Tifa</b> - Vote: <b>The Boss</b> (32/36)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 10/16/2006 8:59:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341380089">message detail</a>
 | #072</td></tr>
<tr class="even"><td>
<i>This is easily the most debated female match of Round 2, and one of only two with the potential to be any good.</i><br><br>Chunners/Lara?<br><br>I can't see that being close, although Lara might impress.<br><br><b>TuRtLe</b><br>~~~<br>I used my brain and statistics to make my bracket. Karma Hunter used MGS fanboyism. KH won. <b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=254355" class="name">Lugia2</a> |
Posted 10/16/2006 9:04:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341381728">message detail</a>
 | #073</td></tr>
<tr class="even"><td>
Lopen? If Jill manages to win by one vote, you still win. This seems to
show the main flaw in both Moltar's and Yohblazer's systems...<br><br>Dear
lord, Peach isn't that much like Amy, is she? More like Kairi, except a
little less than useless. She was invaluable in SMRPG. Kairi? She did
not deserve to get into this contest, let alone go to the second round.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3657433" class="name">LusterSoldier</a> |
Posted 10/16/2006 9:06:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341382009">message detail</a>
 | #074</td></tr>
<tr class="even"><td>
<i>Isn't rSFF where the typically weaker character wins because of the shared fanbase, everyone likes that character?</i><br><br>In
a match involving rSFF, the weaker character generally doesn't win.
rSFF results in less of a blowout than what would be expected. Mega
Man/Zero is the best example of this.<br>---<br><b>Luster Soldier</b> - Popular at school. <b>~Shield Bearer~ | ~Data Analyst~</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/16/2006 9:15:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341384400">message detail</a>
 | #075</td></tr>
<tr class="even"><td>
Yeah, I'll take Auron/Subby then, though I'll probably be horribly off, as I have no clue where to spot Auron or Subs.<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/16/2006 9:18:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341385306">message detail</a>
 | #076</td></tr>
<tr class="even"><td>
I'm sorry. =/<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/16/2006 9:23:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341386667">message detail</a>
 | #077</td></tr>
<tr class="even"><td>
<i>If Jill manages to win by one vote, you still win. This seems to show the main flaw in both Moltar's and Yohblazer's systems...</i><br><br>I
do believe that picking the right winner is ultimately more important
than pin-pointing the margin of victory, but a situation like this may
end up changing my mind.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/16/2006 9:28:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341387835">message detail</a>
 | #078</td></tr>
<tr class="even"><td>
-1 points to everyone who gets it wrong, as usual, but when giving
points to those who have won, make it so that the people who got it
wrong still make a difference on the actual score the person/people who
got it correct get, mayhaps? D:<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/16/2006 9:32:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341389044">message detail</a>
 | #079</td></tr>
<tr class="even"><td>
I don't understand...<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/16/2006 9:32:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341389075">message detail</a>
 | #080</td></tr>
<tr class="even"><td>
I agree with yo here. If I say Peach with 56, Peach wins with 50.5% and
someone predicted Jill with 51, I think taking Peach wiht 56 is the
better move. Predicting the winner &gt;&gt;&gt; getting % right,
however in a case as extreme as Lopen, it would be horrible.<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3802849" class="name">King Bowser</a> |
Posted 10/16/2006 9:34:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341389680">message detail</a>
 | #081</td></tr>
<tr class="even"><td>
...Okay, that prediction by Lopen isn't even funny. That's just...awful.<br><br>---<br><b>"Thank You Mario! But our Princess is in another castle!"</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/16/2006 9:35:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341390069">message detail</a>
 | #082</td></tr>
<tr class="even"><td>
Lopen, I no longer love you. You're willing to take Sheena &gt; Jill &gt; Peach with <i>63%</i>. But you won't take Dante &gt; Snake? Some fan you are <i>!!</i><br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/16/2006 9:36:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341390370">message detail</a>
 | #083</td></tr>
<tr class="even"><td>
Basically, Jill wins with 50.01%, right?<br><br>Moltar is closest, so he would get 7 points.<br>Guest is second, so he would get 6 points.<br>HM is third, so he would get 5 points.<br>KH is fourth, so he would get 4 points.<br>Ulti is third, so he would get 3 points.<br>You are second, so you would get 2 points.<br>Lopen is last, so he would get 1 point.<br><br>Just change the people who got it wrong to -1, and there you go.<br><br>Moltar, Guest, HM, KH, Ulti, and you all get -1, and Lopen gets 1 point.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/16/2006 9:39:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341391008">message detail</a>
 | #084</td></tr>
<tr class="even"><td>
<i>I agree with yo here. If I say Peach with 56, Peach wins with 50.5%
and someone predicted Jill with 51, I think taking Peach wiht 56 is the
better move. Predicting the winner &gt;&gt;&gt; getting % right,
however in a case as extreme as Lopen, it would be horrible.</i><br><br>It would. Look at it this way: even if <i>Jill</i>
were to win with 53.5%, Lopen's prediction would STILL be the farthest
away in terms of actual percentage. A part of me wants to tell him to
stop making such predictions for the sheer novelty of being wacky;
there's no way even he believes Jill has a shot at that kind of win.
I'm probably just bitter after a month of terrible performances, but
seeing the same person lead one ranking system and be dead last in the
other is just ridiculous.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/16/2006 9:41:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341391582">message detail</a>
 | #085</td></tr>
<tr class="even"><td>
I'll let you touch my butt if it'll make you feel better, then we can spoon and watch The Little Mermaid: Special Edition.<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/16/2006 9:44:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341392591">message detail</a>
 | #086</td></tr>
<tr class="even"><td>
<b>UNDER THE SEA!</b><br>---<br><a class="linkification-ext" href="http://wemajor12.myrockinprofile.com/" title="Linkification: http://wemajor12.myrockinprofile.com/">http://wemajor12.myrockinprofile.com/</a><br>Next celebrity I hope to out-rank:  Alyssa Milano (#44)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/16/2006 9:48:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341393647">message detail</a>
 | #087</td></tr>
<tr class="even"><td>
We can even do lines of coke off HaRR's mom's ass!<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/16/2006 9:50:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341394036">message detail</a>
 | #088</td></tr>
<tr class="even"><td>
Not if she downs the stash first!<br>---<br><a class="linkification-ext" href="http://wemajor12.myrockinprofile.com/" title="Linkification: http://wemajor12.myrockinprofile.com/">http://wemajor12.myrockinprofile.com/</a><br>Next celebrity I hope to out-rank:  Alyssa Milano (#44)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/16/2006 9:50:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341394160">message detail</a>
 | #089</td></tr>
<tr class="even"><td>
Well I'm not taking her to the hospital this time!<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/16/2006 9:51:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341394443">message detail</a>
 | #090</td></tr>
<tr class="even"><td>
Does that work at all, Yo?<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/16/2006 9:52:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341394710">message detail</a>
 | #091</td></tr>
<tr class="even"><td>
As long as you'll put her in the back of the van and drive off, that'll be good enough for me.<br>---<br><a class="linkification-ext" href="http://wemajor12.myrockinprofile.com/" title="Linkification: http://wemajor12.myrockinprofile.com/">http://wemajor12.myrockinprofile.com/</a><br>Next celebrity I hope to out-rank:  Alyssa Milano (#44)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/16/2006 9:54:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341395084">message detail</a>
 | #092</td></tr>
<tr class="even"><td>
Yep, I see where you're coming from. I'll consider it, but it does make things a bit more complex than I originally had in mind.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/16/2006 9:55:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341395342">message detail</a>
 | #093</td></tr>
<tr class="even"><td>
No spooning? ;_;<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 10/16/2006 10:47:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341407304">message detail</a>
 | #094</td></tr>
<tr class="even"><td>
As crazy as Lopen's prediction is, it doesn't matter if Jill wins.<br>---<br>CB06 - Score: <b>32/36 </b>Rank: <b>Tied - 1527th </b>Yesterday's Pick:<b> Rikku</b> <br>Today's Pick: <b>Tifa</b> Tomorrow's Pick: <b>Peach</b> Losses: <b>Cortana, Ganon, Zero, MC</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/16/2006 10:48:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341407611">message detail</a>
 | #095</td></tr>
<tr class="even"><td>
Yeah, but he should still go for an actual prediction. =/<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=152338" class="name">Lopen</a> |
Posted 10/16/2006 11:29:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341416032">message detail</a>
 | #096</td></tr>
<tr class="even"><td>
Haha... wow.  Is the little percentage game <i>that</i> important to you people?  <br><br>I believed that Peach really <i>was</i>
that weak. Jill gets around that on people in the 16-17% range using
"lol X-Stats", and I thought she'd be weaker than Wario. Obviously, I
was wrong.. but I wasn't making a huge % just for the sake of making a
huge %. <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/17/2006 1:58:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341494169">message detail</a>
 | #097</td></tr>
<tr class="even"><td>
And yet Hit or Miss Lopen still looks to hit!<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 4</i>: #21 Doctor Zoidberg (3-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=964696" class="name">TheRye</a> |
Posted 10/17/2006 2:26:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341500289">message detail</a>
 | #098</td></tr>
<tr class="even"><td>
tag<br>---<br>Congrats to <b> Z1mZum </b> and his Guru ownage<br>&#8220;TheRye is like Jesus, if Jesus ever played video games.&#8221; -Inviso
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/17/2006 4:19:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341527035">message detail</a>
 | #099</td></tr>
<tr class="even"><td>
Tifa Lockhart.................74.55% 90595<br>The Boss.......................25.45% 30934<br>TOTAL VOTES............................121529<br><br>78.98% of the brackets predicted this match correctly.<br><br>Ouch, The Boss ends up looking worse than Terra would have against Tifa. Could this be more of that funky FF7/MGS SFF? Dunno...<br><br>Today, Jill is winning the match currently, but Peach is looking to comeback soon.<br><br>KH - 7<br>Lopen - 7<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience) - 6<br>Ulti - 5<br>HM - 5<br>Moltar - 5<br>Yoblazer - 2<br><br>We all underestimated Tifa, but KH had the highest pick.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Jill vs. Peach - Bracket: <b>Peach</b> - Vote: <b>Jill</b> (34/38)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/17/2006 7:20:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341576275">message detail</a>
 | #100</td></tr>
<tr class="even"><td>
Up my prediction by 1% if you could, Moltar <i>!!</i><br><br>---<br><i>"Looking good, Princess, especially from this angle!</i>"
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">1</a></li>
<li>2</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=9">10</a></li>
</ul>
</div>


</div>
<img src="genmessage2_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage2_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31144759&amp;page=1" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage2_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>