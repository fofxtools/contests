<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage5_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage5_files/nogs.css"></head><body>
<div id="container">
	<div id="gne_nav">
		<img src="genmessage5_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage5_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31144759%26page%3D4"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage5_files/advertisement.gif" alt="advertisement" height="10" width="120"></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage5_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage5_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 3
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;page=4">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31144759" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=3">Previous Page</a> |
Page 5 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=5">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/21/2006 2:02:43 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342263916">message detail</a>
 | #201</td></tr>
<tr class="even"><td>
<i>Hopefully Leonhart shows SOME brains and puts Snake on a 50.01% win just to give the Guests some hope</i><br><br>Sounds to me like YOU'VE already conceded!<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=683142" class="name">transience</a> |
Posted 10/21/2006 2:02:44 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342263917">message detail</a>
 | #202</td></tr>
<tr class="even"><td>
Snake looks perfectly fine there. I don't understand why people are
saying Squall has this match suddenly. we've seen pictures that are
miles worse.<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/21/2006 2:02:54 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342263933">message detail</a>
 | #203</td></tr>
<tr class="even"><td>
And I might actually be motivated to work on Metal Gear Squallid if Squall wins!<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/21/2006 2:02:55 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342263935">message detail</a>
 | #204</td></tr>
<tr class="even"><td>
...But while on the subject of bad pictures...<br><br>LINK LOST TO CLOUD IN 2003 BECAUSE OF THE WIND WAKER PIC.<br><br><br>(I know how much you love that.)<br><br>---<br><i>The Master Sword is the most sought-after blade in Hyrule. He who wields it carries with him the hope of the kingdom.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/21/2006 2:03:40 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342264001">message detail</a>
 | #205</td></tr>
<tr class="even"><td>
There's nothing wrong with the Old Snake picture in and of itself. We
just don't know how well-liked the image of Snake it has created is.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/21/2006 2:07:16 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342264339">message detail</a>
 | #206</td></tr>
<tr class="even"><td>
<i>Hopefully Leonhart shows SOME brains and puts Snake on a 50.01% win just to give the Guests some hope<br><br>Sounds to me like YOU'VE already conceded!</i><br><br>Nah,
I just want to see every last analysis be wrong and for me to be the
lone person with the nuts to put it all on teh man. Reality is Squall
wins 50.51%.<br>---<br>~*~ Board 8's Champion MILF Hunter ~*~
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/21/2006 2:08:35 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342264459">message detail</a>
 | #207</td></tr>
<tr class="even"><td>
Ha, you think the resident Squall fan is going to be caught unaware?<br><br>Not so fast, my friend! *breaks pencil*<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/21/2006 2:09:56 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342264568">message detail</a>
 | #208</td></tr>
<tr class="even"><td>
It's a well known fact that Snake is winning with 53% <i>!!</i><br><br>---<br><i>The Master Sword is the most sought-after blade in Hyrule. He who wields it carries with him the hope of the kingdom.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/21/2006 2:10:19 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342264601">message detail</a>
 | #209</td></tr>
<tr class="even"><td>
<i>There's nothing wrong with the Old Snake picture in and of itself.
We just don't know how well-liked the image of Snake it has created is.</i><br><br>Indeed. From a purely aesthetic standpoint, you can make a strong case for this being the best picture Snake's ever had.<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/21/2006 2:10:24 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342264607">message detail</a>
 | #210</td></tr>
<tr class="even"><td>
It's a well-known fact that Heroic Mario is a well-known fibber!<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 10/21/2006 2:28:27 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342266014">message detail</a>
 | #211</td></tr>
<tr class="even"><td>
Wow, another point for the guests maybe? Lara is expected to knock off
a bit with the day vote, right? If so, damn.... who would have though
the guests would catch so much momentum after getting like 1 point in
the first half?<br>---<br>CB06 - Score: <b>40/44 </b>Rank: <b>Tied - 1085th </b>Yesterday's Pick:<b> Yuna</b> <br>Today's Pick: <b>Chun Li</b> Tomorrow's Pick: <b>Snake</b> Losses: <b>Cortana, Ganon, Zero, MC</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/21/2006 2:30:39 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342266173">message detail</a>
 | #212</td></tr>
<tr class="even"><td>
The guests are going streaking then!<br><br>But
while we're sort of on the subject of match pictures, I've always
wanted CJayC to use this picture, but he never has. It's not a
particularly difficult one to find either.<br><br>http://images.quizilla.com/D/DY/DYS/DysfunctionalGumbo/1134349891_icssquall2.jpg<br><br>...Don't know if it would have the same effect without the background, but I think it's one of Squall's better pictures.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/21/2006 8:17:09 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342283240">message detail</a>
 | #213</td></tr>
<tr class="even"><td>
Solid's pic is not that bad at all, and I would definitely lean towards
Yoshi/Dante being far more unfair in Yoshi's favor, than Snake/Squall
is, hell, I don't even know if you can say Squall has the clear pic
advantage, they both look good, the MGS4 trailor that a bunch of people
wanted to say would boost snake, is now going to harm him because the
picture? Eh, no.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/21/2006 2:14:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342334937">message detail</a>
 | #214</td></tr>
<tr class="even"><td>
The point is mine, gentlemen <i>!!</i><br><br>---<br><i>The Master Sword is the most sought-after blade in Hyrule. He who wields it carries with him the hope of the kingdom.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/21/2006 3:06:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342344816">message detail</a>
 | #215</td></tr>
<tr class="even"><td>
The point tomorrow will be mine!<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2665492" class="name">XIII_rocks</a> |
Posted 10/21/2006 3:21:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342347633">message detail</a>
 | #216</td></tr>
<tr class="even"><td>
The respect I lost for HM when he gambled away the best account name on
B8 has just been regained - the only person to show faith in Lara?
Score.<br>---<br>http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738 Sign plz<br><b>AC2K6 Score</b>: 44/46 <b>Today:</b> Chun (euw)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/21/2006 3:24:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342348197">message detail</a>
 | #217</td></tr>
<tr class="even"><td>
Yuna.....................78.05% 89711<br>Joanna Dark.........21.95% 25229<br>TOTAL VOTES..................114940<br><br>70.10% of the brackets predicted this match correctly.<br><br>Wow,
Yuna almost did as well against Joanna as Mario did...Yuna for winner?
Nah, just some fodder fluctuation is all. That means its an
overperformance!<br><br>Today, Chun-Li has 55% against Lara, in a match that started out with over 60% for Chunners.<br><br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Moltar - 7<br>KH - 7<br>Lopen - 7<br>Ulti - 5<br>HM - 5<br>Yoblazer - 2<br><br>It's great being off by more than 10 points, yet still being closest.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Chun-Li vs. Lara - Bracket: <b>Chun-Li</b> - Vote: <b>Chun-Li</b> (42/46)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/21/2006 9:32:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342422337">message detail</a>
 | #218</td></tr>
<tr class="even"><td>
Wow, talk about spot-on for my Chun-Li prediction. *gloats* The only
question now is how close it will end up, it just keeps inching
closer....<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/21/2006 9:58:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342427768">message detail</a>
 | #219</td></tr>
<tr class="even"><td>
<b>Patriot Division:</b> <i>Round 2 - Match 41</i> &#8211; (1)Solid Snake vs. (4)Squall Leonhart<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Snake</b><br>Round 1 &#8211; 82.15% vs. Soma (17.85%)<br><br>Snake has no troubles making Soma look like fodder.<br><br><b>Squall</b><br>Round 1 &#8211; 72.02% vs. Tidus (27.98%)<br><br>Ouch, this SFF-beatdown went a lot worse than most expected.<br><br>WOO
Male-half Round 2! It&#8217;s looking to be very interesting too, with
Squall, Vincent and Bowser all looking to challenge the Noble Nine. How
close will they get to them, and can any of the manage to pull off the
huge upset? Who knows&#8230;but we can guess, right?<br><br>First up is Solid
Snake vs. Squall. To be honest, Squall looked much more impressive in
Round 1. Yeah, SFF did help him out, but still, how much of that could
be SFF? Squall was also in KH2, so he should be stronger than last
year, and 2005 Squall would get 47.55% on Snake. Could KH2 push him
over the edge?<br><br>It could, but I don&#8217;t think it will. In fact, I&#8217;m
expecting Squall to do slightly worse than expected. Remember, the two
faced off in 2002 (points shotgun in the face of whoever says lol
2002), and Snake embarrassed Squall badly. Now, I&#8217;m not calling for
anything like that here, but Snake MAY, and I repeat MAY, slightly
overperform on Squall thanks to&#8230;weird PlayStation SFF? I don&#8217;t know.
Either way, overperformance or not, I still think Snake is a tad out of
Squall&#8217;s reach.<br><br>Also, we&#8217;ve seen a ton of Noble Nine breakers go
up against Snake, and Snake has overcome them all. Squall is just going
to be another victim!<br><br><b>Moltar&#8217;s Bracket Says:</b> Snake will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Snake: 54% - Squall: 46%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>FINALLY. Jill/Peach aside, we get back to the superior half of this bracket.<br><br>Oh
and rant time. Why does everyone on the board like Solid Snake's
character but not Squall's? They're the same damn thing. The only real
fault Squall has is having a stupid taste in women, though he redeemed
himself by being a fine piece of ass in Kingdom Hearts. Not so much in
KH2, though the scene where Aeris wins a staredown against him is
priceless.<br><br>As for the actual match, Squall has a lot of reasons
to do well here. KH2, mainly. 45% isn't out of the question, but people
calling for him to win are probably a little off. Bracket voting alone
should save Snake from any upset bids, but I still think Squall is
going to do damn well for himself here. The Snake &gt; MM upset train
might stop in the second round of this contest.<br><br>Prediction: Snake with 52.89%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br> <b>Solid Snake</b><br><br><i>Previous Matches:</i><br><br>Solid Snake &#8211; 82.15% -- 86,697<br><br>Soma Cruz &#8211; 17.85% -- 19,487 <br><br><b>Squall Leonhart</b><br><br><i>Previous Matches:</i><br><br>Squall Leonhart &#8211; 72.02% -- 82,091<br><br>Tidus &#8211; 27.98% -- 31,893 <br><br>Ah, yes, the first of many potential Noble Nine breaker matches. This is perhaps the most <i>likely</i>
one to happen of them all right next to Sonic/Vincent. Both Squall and
Snake both came out looking very impressive last round with two big
blowouts. These two were <i>also</i> very close to each other last year, enough that it would be reasonable to take the upset.  <br><br>Last
year, this match was projected to be a 52/48 match in favor of Snake.
And while that is certainly enough where year-to-year variation can
change the result, Squall actually had something big in his favor with
Kingdom Hearts II. That alone has the power to potentially give him
enough to squeak out a win. <i>But</i>, Solid Snake came out of E3 <i>very</i> strong with an amazing new Metal Gear Solid 4 trailer <i>and</i>
the absolutely huge announcement of Snake appearing in Super Smash
Bros. Brawl. They may be just hype, but that&#8217;s the best hype you can
have next to Twilight Princess.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/21/2006 9:58:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342427886">message detail</a>
 | #220</td></tr>
<tr class="even"><td>
It will be <i>very</i> interesting to see how
this one plays out. Both of these characters look be close together and
both have reasons to potentially increase. We <i>have</i> seen this
match before in 2002 where Snake absolutely wrecked Squall &#8211; some even
speculate that there could have been SFF &#8211; and I don&#8217;t think the result
is going to change too much. Snake will definitely not get nearly as
high, but he should win this one without much of a problem. <br><br>The Noble Nine will live another day &#8211; and considering it&#8217;s Snake winning, we can all be thankful. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Solid Snake<br><br><b>Aitch Emm&#8217;s Prediction:</b> Solid Snake &#8211; 53% ; Squall Leonhart &#8211; 47%<br><br><b>Aitch Emm&#8217;s Vote:</b> Solid &#8220;Old&#8221; Snake.<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Maybe
it's just because I haven't taken the time to really look into things,
but I'm not sure whether the few people calling for the upset here are
serious or not. Could Squall Leonhart have gained enough strength in
the past four years to reverse (well, not reverse, but overturn) a
65/35 loss?<br><br>Contrary to what some people may say, I think that
Squall has always been relatively strong. He beat Luigi with 60% in
2003, beat Kirby with 55% in 2004, and was almost Vincent's equal in
2005. In actuality, 2002 was his only disappointing year. Was that
because he didn't have Kingdom Hearts under his belt? Partially, yes,
but it was mainly because he was up against one of the few opponents
best suited to kick his teeth in.<br><br>Face it, there's no logical reason for Squall to benefit <i>that much more</i>
from Kingdom Hearts than any other character from any other boost. One
game won't take any character from chump to Noble 9 breaker, although
it can help get him up there. Look what Snake did against Sora last
year. Do you think something similar happened to Squall four years ago,
or do you think that it was a legitimate result and he's shot up like a
rocket since then? Personally, I believe the former, and I believe
Snake will overperform once again.<br><br>Will Squall do better this
time around? For the sake of all that is good and holy, his fans better
hope so. Will he actually challenge Snake or come anywhere near as
close to beating him as Bowser did last year? Don't count on it.<br><br>My prediction: Solid Snake def. Squall Leonhart (57-43)<br> <br> <br> <br><b>Lopen&#8217;s Analysis</b><br> <br>
We saw this match back in 2002. It's going down exactly the same today,
baby! Snake shall strike down Squall with great vengeance! Okay, not <i>exactly</i>
the same. I can't say that Squall's not going to make this at least a
little closer from Kingdom Hearts 1 and 2. (and Chain of Memories, we
mustn't forget that!) <i>However</i>, Squall is still going to be made out to look like a fool. Why, you ask?<br><br>Snake'll
probably find that echidna burger that's still in Squall's stomach. The
cravings will drive him insane&#8230; he hasn't had one in a couple of years.
They give him everlasting youth. MGS4? Yeap, lack of echidna burgers
taking their toll. So anyway, Snake'll go into a mad frenzy, and then
he'll have no choice but to devour him in an echidna-like fashion.<br><br>Blah blah MGS/FF8 interaction make %s go crazy blah blah. There, <i>analysis&#8230; happy</i>?<br><br><b>Lopen's prediction:</b> Solid Snake with 59.54%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>SOLID SNAKE</b><br> <br><i>"A strong man doesn't need to read the future. He makes his own."</i><br> <br>Summer 2002 Contest<br>Extrapolated Strength --- 9th Place [35.23%]<br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 8th Place [34.74%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 12th Place [30.82%]<br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 9th Place [33.88%]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/21/2006 9:59:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342427990">message detail</a>
 | #221</td></tr>
<tr class="even"><td>
Snake is looking pretty hot after dispatching handily of Soma Cruz, a
character many thought could break the contest prior to that match. In
fact, he dispatched of him *so* handily that people actually started
throwing around Konami SFF to explain the performance. Because, y'know
Soma being that weak (or Snake being that strong <i>?!</i>) is impossible and all.<br><br>Anywho,
Snake gets his first real challenge here, and it's a doozy. If he wants
to show any prospects of getting past Mega Man in their third showdown,
he'll have to make this win over Squall convincing...assuming he wins
at all. WOO SNAKE<br><br><b>SQUALL LEONHART</b><br> <br><i>"I'm more complex than you think."</i><br> <br>Summer 2002 Contest<br>Extrapolated Strength --- 20th Place [24.36%]<br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 16th Place [30.7% ]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 17th Place [29.58%]<br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 12th Place [32.22% ]<br> <br>As
good as Snake looked off of that Soma thrashing, the obliteration that
Squall laid down on Tidus simply outdid it on almost every level.
Square SFF is typically not the most severe SFF out there, and Squall
has never been given enough credit in these things, but the
"...whatever" he made out of Tidus was just shy of what Link 2k5 was
expected to do.<br><br>So, uh, Squall for 2k6 Champ? Not quite...<br><br><i>Notable Releases Since Last Appearance</i><br><br>Solid Snake: Metal Gear Solid 3: Subsistence (PS2), Super Smash Brothers Brawl Trailer (Internet)<br>Squall Leonhart: Kingdom Hearts II (PS2)<br><br><i>Upcoming Releases</i><br><br>Solid Snake: Metal Gear Solid 4: Guns of the Patriots (PS3), Super Smash Brothers Brawl (WII)<br>Squall Leonhart: N/A<br> <br>Hey,
look, it's the male bracket! My Lord and Savior, I worship the ground
that you are predicted upon. Yes, it's back, and with it, characters of
actual strength and matches that will garner actual debate. The first
of which is this match...one that has had a LOT of discussion recently,
though virtually no one has actually taken in their brackets.<br><br>The reason? This:<br><br><b>http://www.gamefaqs.com/poll/index.html?poll=955</b><br><br>This
is actually a REMATCH of a match we saw way back in 2002, and a match
that Squall got his ass flat out dominated in. For all the laughing
about 2002 Stats that this board has done, they certainly do shy away
from previous results when push come to shove. Come on, who here really
takes Ryu over Dante in a rematch? Honestly?<br><br>But since then,
Squall has had plenty of reason to catch up. Kingdom Hearts was
absolutely huge for him, and he went from being a 15-seeded no hoper to
2003's breakout star. For three years now he has made it to the Sweet
Sixteen and nearly made the Elite Eight last year.<br><br>You'd think
that, bias aside, Squall &gt; Snake would be a perfectly logical upset
pick for me. After all, I have Cloud &gt; Link thanks mostly to Kingdom
Hearts 2 (AC will help, but it's not the deal breaker), and Link 2k5
beats Cloud 2k5 with almost exactly as much as Snake 2k5 beats Squall
2k5.<br><br>The difference is that there seems to be a really Fishy
relationship between Metal Gear and Final Fantasy...FFVII, at the
least. FFVII made MGS look weaker than <i>MGS2</i>, Sephiroth made
Liquid look like he'd lose to Frog in a blowout, Tifa made The Boss
look weaker than Terra...if indeed there is a 'hierarchy' that MGS fits
into with FF games, it has been postulated that Snake/Squall was
'technically' SFF. And while Squall has had KH since then, there's also
this match:<br><br><b>http://www.gamefaqs.com/poll/index.html?poll=2116</b><br><br>Which
had Snake overperforming on Sora (y'know, the lead of KH). While there
was a big picture advantage there, something was definitely fishy in
those results. If MGS has the edge on both FF8 and KH, it makes
Squall's prospects look that much bleaker.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/21/2006 10:00:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342428162">message detail</a>
 | #222</td></tr>
<tr class="even"><td>
Ultimately, I don't think Snake will falter here because of three reasons.<br><br>1.) He's the 1 seed, the massive bracket favorite, if it comes down to the wire he will have better ralliers and cheaters<br>2.)
This wouldn't exactly be the first time that we've seen someone look
like they could take elite competition after annihilating Tidus<br>3.) Because he's beating Mega Man, sillies<br><br>Karma Hunter's Vote: <b>VOTE SNAKE</b><br><br><b>Karma Hunter's Krazy Prediction: Solid Snake with 57.49%.</b><br> <br>Going to lose Crew Points constantly for overestimating Snake, don't really care, etc...<br><br>Truthfully...do
I take Squall over all non-Nobles this year? Yeah, probably. Then why
am I making this kind of a prediction? Hoping for an overperformance?<br><br>Actually, I'm hoping for just the opposite.<br><br><b>Upset Potential: 0%<br><br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br><br>Am
I so naive as to believe that Cloud's KH boost would be nullified if he
went up against Snake? Not a chance of that happening -- Snake would be
doing his best just to avoid being overperformed on, and if he pulled
that off there's no way he'd be stealing that KH vibe (and thus be
overperforming himself). Neither FF8 nor KH is enough to slay the beast
alone, but combined they just may have what it takes.<br><br>The Devil
Division has almost certainly proven itself to be legit. Vincent and
Dante's impressive wins make Squall look that much better, and with KH2
he only has reason to look more impressive. The picture is in his favor
(duh it's Snake), if weekends favor Square characters it favors
him...if he truly is more popular here, he can win this even in the
face of all of Snake's advantages, and break the Noble Nine against the
very character he lost in the first round to in his inaugural match.<br><br>Uh...so why do I have the upset potential at 0%?<br><br>Because SNAKE IS INVINCIBLE you ****ers.<br> <br>Upset Prediction: Solid Snake with 13.37%<br><br>If you're gonna go out, do it in style!<br> <br> <br> <br><b>Guest&#8217;s Analysis</b> - <i>LeonhartForever</i><br><br>Okay, the time for the ultimate internal struggle between the Squallid and the Snake has finally arrived. Hit the music! <br><br>*&#8220;Blue Fields&#8221; begins playing in the background* <br><br>There we go&#8230;Wait, that&#8217;s not right! You know which track I&#8217;m talking about! <br><br>&#8220;I&#8217;m stiiiiiilllll in a dream, <b>SNAAAAAAAAAAAAAAAAKE EAAAAAAATERRRRRRRRR!!!!</b>&#8221; <br><br>That&#8217;s&#8230;a
little better, as it does conjure up memories of Snake&#8217;s most dangerous
foe, The Ladder. But then again, that&#8217;s a different Snake. Come on now,
time to get serious! <br><br>*&#8220;Liberi Fatali&#8221; plays on continuous loop* <br><br>Now <i>that</i>
is what I&#8217;m looking for, the perfect music to set the stage for this
climactic showdown. Friends, this is the last chance to break through
that pretentious group of supposedly unbeatables known as the Noble
Nine. Trust me on this. Vincent is not beating Sonic, and neither
Bowser nor Auron is going to beat Crono. Come next year, the
aristocracy of the Character Battle will rise to an even higher level
of affluence, out of reach from the rest of the world for the
foreseeable future. In other words, this isn&#8217;t just your average,
run-of-the-mill contest poll. It&#8217;s a <i>revolution</i> for justice!  <br><br>And
yet, despite the vast importance and potential repercussions of this
match, it is being overlooked by nearly all of Board 8. Not a single
person took the upset in the Board Odds Project, and few people
considered it to a serious extent. Why, you ask? It&#8217;s very simple. As a
teacher, you always want to move from the known to the unknown, and so,
my students, we will begin with the most basic element of this match: <br><br>http://www.gamefaqs.com/poll/index.html?poll=955
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/21/2006 10:00:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342428255">message detail</a>
 | #223</td></tr>
<tr class="even"><td>
As you can see here, Solid Snake easily disposed of Squall Leonhart in
their only previous meeting. This is the primary reason why this match
goes so undebated by the majority of Board 8. If this was the only
piece of evidence you had to go by, it&#8217;s only natural that you would
choose Snake to win this match, hands down. But what makes this match
different from their first meeting? <b>ONLY EVERYTHING!</b> <br><br>First
of all, that match was in 2002. Take a look at everything else in this
contest relative to the 2002 Extrapolated Rankings. Very little of it
holds up compared to now. So many characters who looked decent in that
contest would be fodder now, and some fodder would be even <i>worse</i> now than before. You just cannot take it into heavy consideration when predicting the outcome of this match. <br><br>Even
so, that&#8217;s still a lot of ground for Squall to make up. Why should we
think he can do it? Well, he showed us in 2003 that he possessed a good
deal of strength, defeating Jill Valentine and Luigi with absolute ease
before getting 41.80% on Samus Aran in defeat. That&#8217;s a good 7.23%
better than he had done on Solid Snake in 2002. So this means that
Snake would beat Samus handily, right? As true as that SHOULD be, that
is not the case in this situation. He hasn&#8217;t been able to defeat any
Noble Nine characters, much less Samus Aran, who is in the upper half
of the group. It means that we&#8217;re dealing with a significantly improved
Squall. <br><br>What caused this drastic rise in strength in the span
of one year? There are a couple of possibilities, but the most
widespread explanation is simply this: Kingdom Hearts. Not only was it
Squall&#8217;s first appearance in four years, it was on a new console
generation to a potentially different demographic. The fact that he had
the largest role of the Final Fantasy cameos only helps, and even some
who hated Squall in Final Fantasy VIII admit that he&#8217;s actually
likeable in Kingdom Hearts. Perhaps he changed a few minds with that
one. <br><br>However, another possibility that could rear its ugly
head in this match and potentially cost Squall his chance at the upset
is something that I was one of the first around these parts to propose.
I believe that Solid Snake may have actually overperformed against
Squall in 2002, meaning he was not as weak (relatively anyway) as he
appeared to be. This is what could spell doom for Squall if this is the
case, regardless of how close to Snake he is indirectly. <br><br>But
why would you believe such a thing would even happen, other than just
being a freaky, random overperformance? Well, we have enough examples
outside of this to believe that Final Fantasy/Metal Gear &#8220;SFF&#8221; occurs.
In the Games Contest, there was Final Fantasy VII vs. Metal Gear Solid,
in which the original MGS looked noticeably weaker than Metal Gear
Solid 2 (which should have immediately raised eyebrows everywhere, but
for some reason did not). Then, in the Villains Contest, there was
Sephiroth/Liquid Snake, in which Liquid winds up well below Frog 2005,
no matter how you look at it. Considering the big leap in strength that
Solid Snake made in 2005, that should not be so. And while this is not
necessarily FF/MGS, it&#8217;s still worth mentioning, Solid Snake vs. Sora
isn&#8217;t a match you can blame solely on the stacked picture. Aeris vs.
Sora in 2003 already told us that Final Fantasy has a heavy overlap
with Kingdom Hearts (as if we needed match to tell us that), so it
stands to reason that the same thing could have happened here. Maybe
they were all just big coincidences. Who knows? But you can&#8217;t rule out
the possibility.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/21/2006 10:01:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342428423">message detail</a>
 | #224</td></tr>
<tr class="even"><td>Now what makes me think that it won&#8217;t happen this
time? In my opinion, SFF isn&#8217;t very severe (or even present at all)
when the two characters are very close in strength, as I believe these
two are. Mario/Samus last year was the exception, not the rule, folks.
Most of the time, you end up with something like Yoshi/Luigi with no
noticeable SFF. Of course, I&#8217;m not saying that Solid Snake cannot do it
again here. I&#8217;ll put it this way. If he does overperform again, I won&#8217;t
be shocked, but I&#8217;m not expecting it. <br><br><br>Okay,
now that we&#8217;ve established the idea that Squall is going to do better
against Solid Snake than he did in 2002, the question then becomes: How
much better? Glad you asked! I&#8217;m about to tell you! <br><br>Let&#8217;s go
back to 2003 for a moment, shall we? While Squall&#8217;s path ended when he
lost to Samus, that isn&#8217;t the end of his story. After that match, Samus
went on to lose to Link in a performance that most didn&#8217;t think
anything of at the time. It went about as expected without much
appearance of SFF&#8230;or so it seems! Keep in mind that Samus had Metroid
Prime between SC2K2 and SC2K3, her first game in several years. For all
intents and purposes, one would expect a rather large increase, right?
Well, if Link didn&#8217;t SFF her, then it appears that she did not have
one. <br><br>Enter SC2K4, where Samus Aran is destroying everything in
her path en route to an extremely respectable 40.99% on Cloud Strife.
Wait, this is the same Cloud who beat Link in 2003, right? Then why did
Samus do 3% better against him? It seems rather obvious that she was
stronger, but why would it take an extra year after Metroid Prime for
such a boost to take effect? That doesn&#8217;t make any sense! Is it
entirely possible that Samus was this strong in 2003? I say yes! I&#8217;ll
allow for another modest increase in 2004, but for the most part, there
is little noticeable difference between Samus 2003 and Samus 2004. <br><br>This
becomes more interesting when you see that Sonic the Hedgehog only
managed 42.49% on Samus in 2004, .69% better than Squall had done the
year before. Based on Sonic 2004, this would actually put Squall <i>very</i>
close to his 2005 value. Coincidence? Perhaps, but then again&#8230;Perhaps
not! As I said before, I will allow for a second Samus increase in
2004, but I wouldn&#8217;t give her too much. Am I saying that Squall could
have beaten Sonic in 2004? Maybe not necessarily win, but I think he
would have done very respectably. <br><br>Unfortunately, concerning
Squall himself in 2004, we can draw very little conclusive data, due to
him getting horribly SFF&#8217;d by Cloud Strife. I&#8217;ll admit that putting
Squall at his 2005 value in 2004 creates something strange with
Bomberman, but other than that, I don&#8217;t really see a problem. Maybe it
was an anomaly. Who knows? Either way, it doesn&#8217;t really matter now.
Everything else looks fine. It makes the huge boosts Kirby and Luigi
got in 2005 look a little less extreme and thus, more reasonable. <br><br>SC2K5 was when Squall finally proved that he was a legitimate near-elite contender (or at least it <i>should</i>
have been). He proved that he actually was capable of destroying fodder
by nearly tripling Geno, and then he beat Snake&#8217;s annual whipping boy,
Knuckles the Echidna, after he pulled the largest upset in contest
history over Magus. However, he narrowly lost to Final Fantasy VII fan
favorite Vincent in one of the closest matches of the contest, just
barely missing a berth in the Elite Eight. That&#8217;s another thing that
makes me think that Snake won&#8217;t overperform. If any two RPG games would
have heavy fanbase overlap, it&#8217;d be Final Fantasy VII and Final Fantasy
VIII. We are well aware of FFVII&#8217;s power around here, and yet Vincent
was unable to pull any sort of SFF on Squall. In any event, I digress.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/21/2006 10:02:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342428657">message detail</a>
 | #225</td></tr>
<tr class="even"><td>Once again, one thing that may work against Squall
Leonhart&#8217;s upset chances is the fact that he was only able to get
53.80% against Knuckles the Echidna, and Solid Snake, even in 2004 when
he didn&#8217;t even look like he belonged in the Noble Nine anymore, managed
to get 59.54% on him. In 2005, Sonic the Hedgehog looked much stronger
than he ever had before, so it stands to reason that Knuckles could
have gotten a hefty boost of his own. Could he have broken 45% on Snake
last year? Maybe (Oh, watching the entire board calling for Snake&#8217;s
head after that would have been priceless!). However, I have considered
the possibility that Knuckles is overrated (Note: This does not mean
that I think the Devil Division is overrated, just Knuckles himself,
for whatever the reason. Call it the Link/Magus or Frog/Snake Syndrome,
if you wish), and in that case, it wouldn&#8217;t really matter. Either way,
I doubt it would be to a great extent, because I couldn&#8217;t fathom Snake
getting 60% on Magus. He may be overrated, but he&#8217;s still strong. <br><br>Now
let&#8217;s look at Vincent. After defeating Squall, he did very well for
himself, grabbing nearly 45% against Crono. However, many thought he
did a little <i>too</i> well and called for the Devil Division being
overrated. There&#8217;s not much indication of that being the case in 2006
so far, so I believe it was a legitimate performance, as I thought all
along. Vincent getting 52.59% on Ganondorf should be enough proof of
that. Sure, call Dirge of Cerberus boost all you want, but the point
remains that he was at least nearly as strong as he looked in 2005.
Besides, Squall has plenty of reason of his own to boost with the
release of Kingdom Hearts II in the last six months. I personally think
it would be enough to boost him even over Vincent now, especially
looking at what we&#8217;ve seen from Kingdom Hearts II characters so far. Of
course, we can&#8217;t tell anything from Squall based on his first round
performance since it was an SFF slaughter of Tidus. Plus, if people
sincerely believe that Vincent is a legitimate threat to beat Sonic the
Hedgehog, you have to think that Squall has the potential to beat Solid
Snake since he is not quite as strong as the Blue Blur. I&#8217;m not going
to disregard Snake&#8217;s potential to be stronger this year though, since
he has been the focus of the two biggest gaming announcements of the
year. <br><br>Regardless of what happens in this match, I expect it to
be a good one. Just remember! If Squall beats Snake, it doesn&#8217;t stop
here! Mega Man, you&#8217;re next! <br><br><b>Leonhart&#8217;s Prediction</b>: <i>Squall Leonhart with 50.44%</i><br> <br> <br> <br>Crew
Consensus: Everyone except Leon with his crazy wall has Snake winning
this match. Ranges from close, (lower 50's) to...not close (upper 50s)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 10/21/2006 10:03:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342428856">message detail</a>
 | #226</td></tr>
<tr class="even"><td>
Holy zombie jesus Leon. I was half expecting that wall to randomly end with Snake winning.<br><br>And Moltar, when are you having signups for round 3 guest analyses?<br><br><b>TuRtLe</b><br>~~~<br>43/48 in the contest. My analysis topic here:<br>http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/21/2006 10:04:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342429040">message detail</a>
 | #227</td></tr>
<tr class="even"><td>
I...don't have the highest Snake prediction?<br><br>DAMN IT LOPEN<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/21/2006 10:04:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342429092">message detail</a>
 | #228</td></tr>
<tr class="even"><td>
I guess I could put up the female half for Round 3 tommorrow.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Chun-Li vs. Lara - Bracket: <b>Chun-Li</b> - Vote: <b>Chun-Li</b> (42/46)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/21/2006 10:06:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342429555">message detail</a>
 | #229</td></tr>
<tr class="even"><td>
<i>This wouldn't exactly be the first time that we've seen someone look
like they could take elite competition after annihilating Tidus</i><br><br>...Still beat Snake that year though.<br><br>Hit or miss Lopen MISSES again!<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/21/2006 10:07:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342429694">message detail</a>
 | #230</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>All this Squall over Snake
talk is really making me sick.......but then again, I completely see
where it's coming from. Squall is the main character from FF8, and had
a relatively prominent cameo in Kingdom Hearts. That is a dangerous
description for an opponent to see. <br><br>But Solid Snake is no
ordinary opponent. Metal Gear Solid is highly popular, and he has a lot
of hype right now with MGS4 and SSBB. If this match were to happen next
year, there is no doubt Snake would win, but right now, hype might not
mean much.<br><br>Solid Snake is a Noble Nine character, and you just
aren't given that title without merit. But on the NN heirarchy, he is
8th or 9th. And Squall is one of the Top 3 outside of the NN, so you
can't count him out just because he's not in the NN. But being in the
NN is good enough for me to say that Snake wins.<br><br>And this was
certainly no quick analysis....these have become increasingly longer, I
need to shut up quicker, the whole point of the "Quick Analysis" was
that I was just gonna get to the point and shut up quick.<br><br>My vote: Solid Snake<br>My bracket: Solid Snake<br>My prediction: Solid Snake with 52.55%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/21/2006 10:08:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342429951">message detail</a>
 | #231</td></tr>
<tr class="even"><td>
<i>All this Squall over Snake talk is really making me sick</i><br><br>Then I can only imagine what my wall of text did to you!<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/21/2006 10:09:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342430147">message detail</a>
 | #232</td></tr>
<tr class="even"><td>
<i>...Still beat Snake that year though.</i><br><br>I believe you have evaded my point quite adeptly, sir! I commend thee.<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 10/21/2006 10:09:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342430276">message detail</a>
 | #233</td></tr>
<tr class="even"><td>
<i>From Master Moltar Posted 10/21/2006 11:04:24 PM</i><br><i>I guess I could put up the female half for Round 3 tommorrow.</i><br><br>Can
you do it now, since I'm working tomorrow and have a linear algebra
midterm on Monday, and I've missed every other signup so far &gt;_&gt;<br><br><b>TuRtLe</b><br>~~~<br>43/48 in the contest. My analysis topic here:<br>http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/21/2006 10:21:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342432901">message detail</a>
 | #234</td></tr>
<tr class="even"><td>
Your wall of text just made my jaw drop when I saw it.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=668794" class="name">Mumei</a> |
Posted 10/21/2006 10:31:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342435040">message detail</a>
 | #235</td></tr>
<tr class="even"><td>
http://www.gamefaqs.com/poll/index.html?poll=743<br><br>This would be for Karma Hunter.<br><br>---<br><i>"I
believe that words uttered in passion contain a greater living truth
than do those words which express thoughts rationally conceived"</i><b>- Sensei, "Kokoro"</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/21/2006 10:32:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342435190">message detail</a>
 | #236</td></tr>
<tr class="even"><td>
Leonhart delivers.<br><br>---<br><i>The Master Sword is the most sought-after blade in Hyrule. He who wields it carries with him the hope of the kingdom.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/21/2006 10:32:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342435223">message detail</a>
 | #237</td></tr>
<tr class="even"><td>
That might be the best poll I've ever seen.<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/21/2006 10:32:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342435348">message detail</a>
 | #238</td></tr>
<tr class="even"><td>
And I always deliver on time. I'm like the post office, only efficient!<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3623587" class="name">Gaddswell</a> |
Posted 10/21/2006 10:33:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342435418">message detail</a>
 | #239</td></tr>
<tr class="even"><td>
Holy ****! That analysis took 3 whole posts Leon! Took so long to read!<br>---<br>By the time we localize the programs, kids don&#8217;t even know they&#8217;re from Japan any more. - 4Kids CEO Al Kahn
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/21/2006 10:47:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342438301">message detail</a>
 | #240</td></tr>
<tr class="even"><td>
If this pace keeps up, I'm gonna hit my Chun-Li prediction dead on....come on!<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/21/2006 10:53:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342439513">message detail</a>
 | #241</td></tr>
<tr class="even"><td>
Damn it, I figured we were due for an update where the percentage didn't increase....<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 10/21/2006 10:54:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342439669">message detail</a>
 | #242</td></tr>
<tr class="even"><td>
*looks at Karma's prediction*<br><br>WOO UNFINISHED FFP LET'S DO THIS<br>---<br>This was Ed Bellis.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/21/2006 11:00:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342440966">message detail</a>
 | #243</td></tr>
<tr class="even"><td>
DAMN IT!!  55.54%, one-hundreth of a percentage off!<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=683142" class="name">transience</a> |
Posted 10/22/2006 12:04:41 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342453488">message detail</a>
 | #244</td></tr>
<tr class="even"><td>
<i>Hit or miss Lopen MISSES again!</i><br><br>absolutely!<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/22/2006 12:06:27 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342453812">message detail</a>
 | #245</td></tr>
<tr class="even"><td>
On the one hand, Snake's terrible day vote should help me snag this one with ease. On the other...GO LOPEN.<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 10/22/2006 12:29:28 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342457669">message detail</a>
 | #246</td></tr>
<tr class="even"><td>
Oh man, I feel bad for you DP. So damn close to the percentage nailing.<br>---<br>CB06 - Score: <b>44/48 </b>Rank: <b>Tied - 696th </b>Yesterday's Pick:<b> Chun Li</b> <br>Today's Pick: <b>Snake</b> Tomorrow's Pick: <b>Yoshi</b> Losses: <b>Cortana, Ganon, Zero, MC</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3191556" class="name">LegendarySnake</a> |
Posted 10/22/2006 1:49:35 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342468931">message detail</a>
 | #247</td></tr>
<tr class="even"><td>
Psh, Snake will be down past Lopen's percentage before his infamous day vote hits. He misses again! I wasn't wrong to say so!<br>---<br>Deluded boy. Nobility is forever.<br>The Snake has triumped over the Squallid.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=254355" class="name">Lugia2</a> |
Posted 10/22/2006 5:34:50 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342484459">message detail</a>
 | #248</td></tr>
<tr class="even"><td>
Great.  We're now back to nigh-impossible upset picks.  Thanks Guests!  You're going to make us look bad!<br><br>At least we can rely on HM to pick Vincent&gt;Sonic, only to prove that Gannon is still better.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=304351" class="name">Mac Arrowny</a> |
Posted 10/22/2006 6:34:39 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342486237">message detail</a>
 | #249</td></tr>
<tr class="even"><td>
<i>Great. We're now back to nigh-impossible upset picks. Thanks Guests! You're going to make us look bad!<br><br>At least we can rely on HM to pick Vincent&gt;Sonic, only to prove that Gannon is still better.</i><br><br>Actually,
I'm doing the Guest writeup for Vincent vs. Sonic, so we can probably
expect the guests to continue their tradition of ridiculous upset picks.<br>---<br>99% of people just make up statistics on the spot. If you are part of the 1%, post this in your sig
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=1502018" class="name">ShatteredElysium</a> |
Posted 10/22/2006 6:44:11 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342486612">message detail</a>
 | #250</td></tr>
<tr class="even"><td>
[This message was deleted at the request of the original poster]
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=3">4</a></li>
<li>5</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=9">10</a></li>
</ul>
</div>


</div>
<img src="genmessage5_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage5_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31144759&amp;page=4" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage5_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>