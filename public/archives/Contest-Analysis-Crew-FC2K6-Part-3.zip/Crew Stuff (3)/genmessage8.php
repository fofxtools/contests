<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage8_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage8_files/nogs.css"></head><body linkifytime="221" linkified="1" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage8_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage8_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31144759%26page%3D7"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage8_files/advertisement.gif" alt="advertisement" height="10" width="120"></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage8_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage8_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 3
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;page=7">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31144759" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=6">Previous Page</a> |
Page 8 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=8">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 10/24/2006 9:39:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343086849">message detail</a>
 | #351</td></tr>
<tr class="even"><td>
Lol, Axel higher than Ryu.<br>---<br>CB06 - Score: <b>48/52 </b>Rank: <b>Tied - 305th </b>Yesterday's Pick:<b> Yoshi</b> <br>Today's Pick: <b>Sora</b> Tomorrow's Pick: <b>Mega Man</b> Losses: <b>Cortana, Ganon, Zero, MC</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/24/2006 9:45:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343088418">message detail</a>
 | #352</td></tr>
<tr class="even"><td>
Axel is stronger than Sora. Got it memorized?<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=640243" class="name">Big Bob</a> |
Posted 10/24/2006 9:49:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343089360">message detail</a>
 | #353</td></tr>
<tr class="even"><td>
Notice the "completely biased and nonsensical".<br>---<br>Gordon
Freeman finally won, but somehow, the universe survived... thus
allowing me to tell said universe about how I was owned by <b>NClark128</b>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/24/2006 9:51:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343089798">message detail</a>
 | #354</td></tr>
<tr class="even"><td>
And yet it makes the most sense out of any of the picks in this topic! =O<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/24/2006 9:55:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343090722">message detail</a>
 | #355</td></tr>
<tr class="even"><td>
Should probably put these somewhere that won't purge.<br><br>Round 3 Guests<br><br>Samus vs. Rikku - ShatteredElysium<br>Tifa vs. Peach - Vlado<br>Zelda vs. Aeris - BlAcK TuRtLe<br>Yuna vs. Chun-Li - Lugia2<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sora vs. Gordon - Bracket: <b>Sora</b> - Vote: <b>Sora</b> (46/52)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/24/2006 10:14:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343094810">message detail</a>
 | #356</td></tr>
<tr class="even"><td>
Vlado - "Tifa with 87%"<br>---<br><a class="linkification-ext" href="http://wemajor12.myrockinprofile.com/" title="Linkification: http://wemajor12.myrockinprofile.com/">http://wemajor12.myrockinprofile.com/</a><br>Next celebrity I hope to out-rank:  Adam Sandler (#1)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/25/2006 12:04:06 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343115379">message detail</a>
 | #357</td></tr>
<tr class="even"><td>
Sora vs. Gordon Freeman<br>+7 Lo<br>+6 Mo (tie)<br>+6 Yo (tie)<br>+4 Guest<br>+3 Ulti<br>+2 KH<br>+1 HM<br><br><b>The Rankings</b> (Through Sora vs. Gordon)<br>1. Karma Hunter (180)<br>2. Master Moltar (176)<br>3. Heroic Mario (167)<br>4. UltimaterializerX (152)<br>4. Yoblazer (152)<br>6. Board 8 (144)<br>7. Lopen (101)<br><br>Karma
Hunter's vice-like grip over the top spot has been severely weakened.
Master Moltar now trails our leader by a mere four points. Moltar, who
led the scoreboard through most of the Series Contest before losing it
on the final day, has his eyes on the prize and his mind on <b>redemption</b>.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=304351" class="name">Mac Arrowny</a> |
Posted 10/25/2006 12:30:47 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343118858">message detail</a>
 | #358</td></tr>
<tr class="even"><td>
Moltar: analysis sent.<br>---<br>99% of people just make up statistics on the spot. If you are part of the 1%, post this in your sig
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/25/2006 12:33:42 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343119218">message detail</a>
 | #359</td></tr>
<tr class="even"><td>
Agh, I've just been sucking it up like crazy lately. I must be like Mega Man, and I've stolen yo's jobbing powers!<br>---<br><b>*kills self<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=625761" class="name">LordLockeRA</a> |
Posted 10/25/2006 1:49:30 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343126677">message detail</a>
 | #360</td></tr>
<tr class="even"><td>
At least you're not Lopen.  His clown car broke down about eight matches ago and can't seem to get back on track.<br>---<br>Meeh.  Whatever.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=254355" class="name">Lugia2</a> |
Posted 10/25/2006 5:53:20 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343139391">message detail</a>
 | #361</td></tr>
<tr class="even"><td>
Nice to see the Guest slot not did, since I'll be writing for that later.<br><br>MM...is really falling.  If Vincent somehow verifies HM, then MM is <i>so screwed.</i><br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=254355" class="name">Lugia2</a> |
Posted 10/25/2006 5:54:04 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343139434">message detail</a>
 | #362</td></tr>
<tr class="even"><td>
I meant  "didn't do badly."  That teaches me to check before I post...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/25/2006 6:33:56 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343140725">message detail</a>
 | #363</td></tr>
<tr class="even"><td>
LOL people thinking Ryu wouldn't break 40%<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 5</i>: Darkwing Duck (4-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/25/2006 6:35:12 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343140805">message detail</a>
 | #364</td></tr>
<tr class="even"><td>
LOL people thinking Ryu has a chance in hell at the day/after school vote.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/25/2006 6:36:36 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343140879">message detail</a>
 | #365</td></tr>
<tr class="even"><td>
The morning vote is Ryu's bad time, and he's not losing that much percentage against Mega Man. He's no Kratos.<br><br>*looks at Axel*<br><br>Yeah, he looked just as bad or worse than Ryu last round with the day vote.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 5</i>: Darkwing Duck (4-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3052691" class="name">satai_delenn</a> |
Posted 10/25/2006 9:56:52 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343156550">message detail</a>
 | #366</td></tr>
<tr class="even"><td>
Hmm. Mega Man's current performance doesn't look good for the rest of my bracket... &gt;_&gt;<br>---<br>Beating
FE5 and FE6 hard mode is a true test of manhood in the Japanese
culture. However. This explains why they have a lot of effeminate men.
~Sytha
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 10/25/2006 11:05:56 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343164272">message detail</a>
 | #367</td></tr>
<tr class="even"><td>
<i>Yuna vs. Chun-Li - Lugia2</i><br><br>=(<br>---<br>This was Ed Bellis.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3733356" class="name">Heroic_Servbot</a> |
Posted 10/25/2006 11:07:29 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343164445">message detail</a>
 | #368</td></tr>
<tr class="even"><td>
Well guests are screwed on the Tifa match....<br>---<br><b>wavedash</b><br><i>Ozzie's in a pickle!</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=1502018" class="name">ShatteredElysium</a> |
Posted 10/25/2006 11:15:09 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343165253">message detail</a>
 | #369</td></tr>
<tr class="even"><td>Samus - Rikku is Monday right? I'll probably do
some number crunching, analysis and lol x-stats Thursday, get drunk
Thursday night, disregard everything I've done and send you my random
prediction and write-up on Friday evening.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/25/2006 3:35:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343204540">message detail</a>
 | #370</td></tr>
<tr class="even"><td>
Sora..............................63.93% 77994<br>Gordon Freeman.......36.07% 43996<br>TOTAL VOTES........................121990<br><br>73.01% of the brackets predicted this match correctly.<br><br>For
the first time, Freeman loses by over 60% of the vote, but still, many
expected more out of Sora. I mean, he's the main character in one of
the biggest games of the year, yet he doesn't look to have moved much
since last year. Maybe Mega Man will shed some light on this...<br><br>Speaking of MM, he's not looking too hot against Ryu. Mr. Consistency has returned!<br><br>Lopen - 8<br>KH - 8<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>HM - 7<br>Moltar - 7<br>Ulti - 5<br>Yoblazer - 2<br><br>Lopen didn't have a hit or miss pick, but he was the closest.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Ryu vs. Mega Man - Bracket: <b>MM</b> - Vote: <b>MM</b> (48/54)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/25/2006 3:39:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343205276">message detail</a>
 | #371</td></tr>
<tr class="even"><td>
I find it hilarious that the difference between 1st and 6th is closer than the difference between 6th and 7th. Silly Lopen.<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/25/2006 3:45:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343206714">message detail</a>
 | #372</td></tr>
<tr class="even"><td>
Silence, all of you.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/25/2006 3:46:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343206972">message detail</a>
 | #373</td></tr>
<tr class="even"><td>
Oh... that too! I was actually talking about the consistency rankings.
Sorry my furry little Arab friend who could break me in two!<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/25/2006 5:23:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343229329">message detail</a>
 | #374</td></tr>
<tr class="even"><td>
^o^<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/25/2006 6:21:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343243121">message detail</a>
 | #375</td></tr>
<tr class="even"><td>
Ryu vs. Mega Man<br>+7 Ulti<br>+6 Yo<br>+5 HM (tie)<br>+5 Mo (tie)<br>+3 Lo<br>+2 Guest<br>+1 KH<br><br><b>The Rankings</b> (Through Ryu vs. Mega Man)<br>1. Karma Hunter (181)<br>1. Master Moltar (181)<br>3. Heroic Mario (172)<br>4. UltimaterializerX (159)<br>5. Yoblazer (158)<br>6. Board 8 (146)<br>7. Lopen (104)<br><br>After
weeks of dominating the scoreboard, Karma Hunter has been caught.
Standing on even ground and staring eye-to-eye with the now co-leader
is Crew founder, Master Moltar. This tie at the top couldn't have come
at a better time, as we're getting ready for two consecutive matches
where a risk could really pay off. Will they play it safe or make a
stab at a big lead? For my sake, I hope they both go with Ganondorf
over Sonic.<br><br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/25/2006 6:23:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343243587">message detail</a>
 | #376</td></tr>
<tr class="even"><td>
Vincent will break the noble nine. I can't wait for HM to be the only one to get this match right.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3793953" class="name">TehMissingLink</a> |
Posted 10/25/2006 7:25:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343258641">message detail</a>
 | #377</td></tr>
<tr class="even"><td>
I'll send you my analysis for the next match shortly, Moltar!<br><br>---<br><i>The Master Sword is the most sought-after blade in Hyrule. He who wields it carries with him the hope of the kingdom.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=254355" class="name">Lugia2</a> |
Posted 10/25/2006 9:01:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343282319">message detail</a>
 | #378</td></tr>
<tr class="even"><td>
Next?  But that is-<br><br><i>Gann-</i> <br>er, wait.  <br><i>Vincent v Sonic</i><br><br>This will be interesting.  Or HM is nuts.  Ah well.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/25/2006 9:04:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343283051">message detail</a>
 | #379</td></tr>
<tr class="even"><td>
<b>Blast Division:</b> <i>Round 2 - Match 45</i> &#8211; (1)Sonic the Hedgehog vs. (5)Vincent Valentine<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Sonic</b><br>Round 1 &#8211; 80.75% vs. CATS (19.25%)<br><br>Sonic does slightly better on CATS than I expected.<br><br><b>Vincent</b><br>Round 1 &#8211; 52.59% vs. Ganondorf (47.41%)<br><br>In the most debated match of Round 1, Vincent wins by a small margin.<br><br>Noble
Nine Breaker #2 steps up to the plate against Sonic. He said he
dedicates this match to the people who bought and loved Dirge of
Ceberus (all 3 of you) and Final Fantasy Advent Children (all 400
million of you).<br><br>There&#8217;s been a lot of crazy upsets called in
this Contest, but the most plausible in my opinion is Vincent over
Sonic. Do I think it will happen? There&#8217;s a small chance, but I didn&#8217;t
take Ganondorf over Sonic (Ganon should&#8217;ve won!!)<br><br>Now this
match, according to last year&#8217;s stats, goes to Sonic with 53.71%. Now,
in order to make Ganondorf look very good (because in the end, that&#8217;s
all that really matters), we&#8217;ll say 2005 Ganondorf = 2005 Vincent, and
Vincent boosted from Advent Children and DoC to score the victory. That
does make him a serious threat to Sonic, but only if he really is that
high up.<br><br>Now, this match won&#8217;t be a blowout, as it takes a lot
to go 55-45 with Crono. Sonic is a step below that, but if Sonic does
in fact put up Crono-like numbers on a potentially stronger Vincent,
Crono better watch out. I&#8217;ll go with a middle of the road pick for
Sonic.<br><br><b>Moltar&#8217;s Bracket Says:</b> Sonic will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Sonic: 53% - Vincent: 47%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>Can
we please stop with the Vincent &gt; Sonic bandwagon? I know everyone
is desperate to see the Noble Nine break, but this is just ridiculous.
Ganon was an overrated fraud, and the Ganon/Tidus/Magus trio of 2003
have now all been exposed. Ganon not so much given that Zelda is always
on the way up, but still. Vincent beating a warped Ganon isn't saying a
whole lot. I seriously think 47% is the ABSOLUTE best Vincent can hope
for. <br><br>Prediction: Sonic with 55.55%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br><b>Sonic the Hedgehog</b><br><br><i>Previous Matches:</i><br><br>Sonic the Hedgehog &#8211; 80.75% -- 87,757<br><br>CATS &#8211; 19.25% -- 20,925 <br><br><b>Vincent Valentine</b><br><br><i>Previous Matches:</i><br><br>Vincent Valentine &#8211; 52.59% -- 67,321<br><br>Ganondorf &#8211; 47.41% -- 60,685 <br><br>Well this is quite unfortunate that I have to analyze Sonic v. <i>Vincent</i>
because I was convinced that Ganondorf was going to be here. Alas, I
must go on. Sonic had a good showing against CATS last year by getting
a whopping 80% on him and Vincent came out with a nice victory over
Ganon despite the possibility of him being overrated and Ganon being
underrated. <br><br>There hasn&#8217;t been too much debate on this match,
but it is definitely one that many people are keeping their eye on.
Vincent certainly has the <i>potential</i> to be the first character
to ever upset a Noble Nine character. Within the past year, he&#8217;s had
the benefit of Dirge of Cerberus (which has sold 300,000 copies as of
October 1st) and the release of Advent Children (which has exceeded 1.5
million in America). It&#8217;s unclear on how much those have helped him,
but one would have to imagine that he&#8217;ll at least get a nice boost from
it.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/25/2006 9:05:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343283274">message detail</a>
 | #380</td></tr>
<tr class="even"><td>Right now, this match is projected to go to Sonic
with 53.79%. It certainly doesn&#8217;t really sound like a match that would
have seen much upset potential in 2005, but with Vincent&#8217;s newly
acquired items, he could possibly make up the difference and end up
being that one character to do the unthinkable. Personally, I&#8217;m
actually <i>not</i>
expecting Vincent to pull out a victory here. Perhaps it&#8217;s just hard to
imagine Vincent doing it without something like, say, Twilight Princess
in his corner. I do think, though, that he&#8217;s going to get very close.
Make no mistake &#8211; Vincent could very well upset here and shock
everyone, but I&#8217;m just not seeing it happen this year. <br><br>I&#8217;m
rooting for Vincent all the way in this match because it makes Ganon
look better (and I like him more than Sonic), so if he pulls out a win,
more power to him. But I&#8217;ll take the conservative route for a change! <br><br><b>Aitch Emm&#8217;s Bracket:</b> Sonic the Hedgehog<br><br><b>Aitch Emm&#8217;s Prediction:</b> Sonic the Hedgehog &#8211; 51% ; Vincent Valentine &#8211; 49%<br><br><b>Aitch Emm&#8217;s Vote:</b> Vincent Valentine <br> <br> <br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>It's
6:25 Pacific and the picture isn't up yet (I told myself I'd wait for
it before writing this), so I better get started. Unless I need a few
lessons on Character Battle history, this is the second most hyped
"Noble 9 breaker" match, right after Snake/Bowser. Does it earn its
place? I guess so, but let's delve just a smidgen further as to why.<br><br>For almost two months, Ganondorf/Vincent was <i>the</i>
most debated match of the contest. It was a battle between
Nintendo/Square forces that each had a terrific 2005, and most agreed
that it was a waste to put such a match in Round 1. Fortunately for us,
the winner would go on to face Sonic, one of the Noble 9's weak links,
and that made for a few very bold upset picks. Once the match actually
started (or a couple of hours afterwards, I should say), the Ganondorf
supporters were made to look like fools, as Vincent won <i>easily</i>.
How easily? 52.59% easily. Sure, it isn't the beatdown of the century,
but such an easy win really contrasted the big-fight atmosphere before
the match, and it absolutely humiliated the Zelda villain.<br><br>Now, let me get one thing straight: I don't think Ganondorf has declined, and I don't think he's anything more than possibly a <i>teeny bit</i>
overrated from last year. The fact that Zelda looking like arguably the
most impressive performer in the entire field disproves the first
point, and Ganon's convincing win against Auron and ability to break
40% on Samus last year disproves the second. I think Ganondorf is very
strong, yet Vincent still beat him with ease. What does that mean? It
means that Vincent boosted. After Dante choked against Yoshi, there's
no way I'd believe he'd ever give Ganondorf the kind of fight he's
expected to through Vincent's 2005 performance, and this means that
Vincent is simply stronger now than he was last year.<br><br>Now,
that's some very scary strength, and it's Top 10 potential for sure,
but is it enough to beat Sonic? Personally, I don't think so. Vincent
may be the third strongest FFVII character, but there's no way I'm
taking <i>any</i> side character to beat a legend of Sonic's caliber
after Tifa failed to crack 44% last year. You need more than impressive
victories or wins over Ganondorf to beat Sonic (remember all the talk
of Magus&gt;Sonic? LOL!!!!). You need something... something special.
Call it oomph. Call it pizzazz. Call it moxy. Whatever you call it,
just realize that this goofy looking weirdo doesn't have it. Sonic will
beat Vincent, and I'm willing to bet the final result won't warrant the
hype this match has been getting.<br><br>My prediction: Sonic the Hedgehog def. Vincent Valentine (53-47)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/25/2006 9:06:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343283397">message detail</a>
 | #381</td></tr>
<tr class="even"><td>
<b>KH&#8217;s Analysis</b><br><br> lol x-stats history<br><br> <br><br><b>SONIC THE HEDGEHOG</b><br><br> <br><br><i>"Talk about a low-budget flight! No food or movies...I'm outta here! I like running better!"</i><br><br> <br><br>Summer 2002 Contest<br>Extrapolated Strength --- 5th place [41.05%]<br><br> <br><br>Summer 2003 Contest<br>Extrapolated Strength --- 10th place [34.92%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 8th place [33.56%]<br><br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 8th Place [35.28%]<br><br>Sonic
whips up on Hybrid CATS last round in impressive fashion, so much as to
cause people to downplay the performance (no WAY is Sonic that strong,
Hybrid must be nearly on par with Eggplant CATS!). In any case, he'll
have a better chance to prove his strength here, in a match against
what is potentially the toughest of all non-Nobles.<br><br><b>VINCENT VALENTINE</b><br> <br><i>"I don't care what you are doing, so much as the idiotic way as you are doing it."</i><br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 11th Place [32.60%]<br><br>Vincent
beats Ganondorf in a relatively close but comfortable match last round,
defying Zelda's invincibility for the first time in what seems what
forever. Was it his strength or the -dorf's weakness? We get some
answers to that today.<br><br><i>Notable Releases Since Last Appearance</i><br><br>Sonic the Hedgehog: N/A<br>Vincent Valentine: Advent Children (Film), Dirge of Cerberus (PS2)<br><br><i>Upcoming Releases</i><br><br>Sonic the Hedgehog: Sonic the Hedgehog (PS3, X360), Sonic and the Secret Rings (WII)<br>Vincent Valentine: N/A<br>While
this is a good match on paper, I have doubts that Vincent will even
make a match out of it. This is just a stepping stone to Sonic/Crono in
my mind, and Sonic will be trying to look as good as ever.<br><br>If he struggles at all, he may as well concede the match. 52% or so on Ganondorf isn't <i>that</i> good.<br><br>Karma Hunter's Vote: Sonic the Hedgehog. Though I would have voted Vincent if HM hadn't closed his account prematurely!<br><br><b>Karma Hunter's Krazy Prediction: Sonic the Hedgehog with 54.28%</b><br> <br>A
little over a percent under Crono's performance, but on a debatably
stronger Vincent. Just to make the upcoming Sonic/Crono confrontation
as ambiguous as possible.<br><br><b>Upset Potential: 32%<br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br><br>It's
not like people haven't been talking up Ganondorf &gt; Sonic since the
man's first year in the contests. In retrospect it was totally bonkers,
but G-dorf has grown quite nicely in these things...not enough to
outstrip Sonic, but he's close enough. If there is a Nintendo/Zelda
boost, it probably isn't enough for him to catch up -- but it's
certainly enough for someone who lays on 52%+ or so to do it!<br><br>This
means Vincent boosted much more from AC/DoC than I anticipated. I don't
see it, but it could happen. In which case, a constant or declining
Sonic (setting Hybrid CATS = Eggplant CATS means Sonic fell! perfect
logic right hurr) gives Vincent a big chance at the upset.<br><br>A lot of stretches, but Vincent's close enough to merit the debate.<br><br>Upset Prediction: Vincent Valentine with 50.27%
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/25/2006 9:07:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343283592">message detail</a>
 | #382</td></tr>
<tr class="even"><td>
<b>Guest&#8217;s Analysis</b> - <i>Mac Arrowny</i><br><br>I'd like to start
off by just mentioning the previous matches of both of these
characters. Sonic impressed by getting 80.75% on Hybrid CATS, only 1.7%
worse than what he's expected to get on CATS 2k3, and 5.7% better than
what he's expected to get on CATS 2k5. Vincent, on the other hand, got
52.59% against Ganon, which is .14% less than he was expected to get in
the 2k5 stats. However, this doesn't look as bad for Vinny V as it
first seems. Tingle scored an impressive percentage on KH2 Sora (very
impressive after Yoshi vs. Dante, less so after Sora vs. Gordon), Zelda
has arguably been the most impressive character we've seen so far, and
LoZ won the series contest. Does this imply an LoZ boost? Possibly yes,
possibly no. I've always been a firm believer in 2k5 Ganon being
underrated regardless, so VV definitely doesn't suffer from his
performance on Ganon. Meanwhile, CATS's 2k5 performance was based on
Master Chief, who now seems to have been woefully overrated in 2k5, and
whose antivotes may have allowed CATS to overperform. CATS through
MC2k3 would be expected to do about 3.5% worse on Sonic than he did
last round, which leads me to believe that Sonic's performance is not
indicative of a boost.<br> <br>Sonic doesn't have much reason to boost
(Sonic Rush doesn't count, Super Princess Peach just surpassed it in
sales), but Vincent has plenty of reasons to do so. One of the
arguments about Vincent not getting a very large boost from Dirge of
Cerberus is that it's such an awful game that there's no way Vincent
would gain much from it. While at first glance this seems to make
sense, it is in fact entirely irrelevant. We've seen plenty of
characters receive games in recent years that have been well received
and poorly received, and yet their boosts have been of an entirely
different nature, size-wise. So far as I have been able to tell, the
deciding factor in most of these cases has been how likable/cool/badass
the <i>character</i> is in the new game, not the quality of the game
itself. Devil May Cry 2 and Xenosaga 2 were received similarly, and yet
Dante received a boost, while KOS-MOS seemingly dropped. Why? Because
people <i>liked</i> Dante in DMC2, while they disliked KOS in XS2.<br> <br>What
does this have to do with DoC? I've heard many people talk about how
much the gameplay sucks, the plot sucks, the controls suck, etc...but I
have <i>never</i> heard anyone complain about Vincent's role in the
game. In fact, many people who've played the game have said that
Vincent's more badass then ever, and that can't be a bad thing. If
anything hampers DoC, it will be the game's poor sales, which were at
330,000 by the end of September. I expect them to reach at least
380,000 by the end of October, which is, surprise surprise, very close
to the sales for DMC3 before SC2k5. Now, I'm not expecting him to boost
5% on BL just from DoC, but he's less than 3% away from Sonic to start
with. Could DoC boost him 3%?<br> <br>Possibly, but unlikely. That's
almost as much as DMC2 boosted Dante. Vincent has an advantage in being
the main character whereas he was previously a secret character, but
DoC was far less popular and well-received. A 2.5% seems legit for
DoC.That's not enough to beat Sonic, but thankfully, Vincent also has
Advent Children. As of June, AC has managed to sell 1.3 million copies
in America alone, and has no doubt added to that amount since. This is
an absolutely amazing number for a DVD.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/25/2006 9:08:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343283817">message detail</a>
 | #383</td></tr>
<tr class="even"><td>In most cases, movies don't help out characters
too much. RE:A didn't seem to do much for Jill, and Tomb Raider didn't
seem to do much for Lara Croft after the opening weekend, though the
Silent Hill movie is one of the few explanations for Silent Hill's
oddly strong VC performance. What's the difference between AC and these
others? Advent Children was seen mostly by <i>gamers</i>,
while those other movies were made for the general public. Vincent is
one of the coolest characters in the movie, and the one I'd expect do
boost most after Cloud and Tifa (Sephiroth is debatable...). Despite AC
being more important than any of those other movies, the boost he'll
get from the movie is not large. Maybe a couple percent.<br> <br>Still,
all of this combined is enough for Vincent to beat Sonic, and the
beating could be even worse than the aforementioned information
suggests. KH2 factor could bring about a sitewide Square shift. Square
characters have looked pretty good this contest, when not being SFF'd.
Sonic's boost in 2k5 could've been temporary, as there's really not
much reason for Sonic to look better than ever before. Of course, he
could also continue his trend of boosting since 2k3, which would be
utterly baffling, but possible.<br> <br>This match definitely has the
potential to go either way, but I think Vincent can pull out the win.
It'll be sad to see the inferior character out of Vincent and Ganondorf
making it out of the division, but at least we'll get to see Sonic go
down, and finally have an end to the Noble Nine.<br> <br><b>Mac's Prediction</b>: Vincent with 52.60%<br> <br> <br> <br>Crew
Consensus: Sonic wins in a close one, but he shouldn't be in any real
danger. The Blur from anywhere in the low-to-mid 50's.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/25/2006 9:08:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343284010">message detail</a>
 | #384</td></tr>
<tr class="even"><td>
No Lopen?<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/25/2006 9:09:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343284233">message detail</a>
 | #385</td></tr>
<tr class="even"><td>
<b>Lopen&#8217;s Analysis</b><br> <br> Ah&#8230; remember when people were saying
Ganondorf was going to beat Sonic here? I'm kinda confused that Vincent
didn't get any hype to win this. Do I think he'll win? Well, no&#8230; but&#8230;
he clearly deserved the hype more than Ganondorf, right? I give Vincent
an off-shot to win this, but beyond that, there isn't really that much
to talk about here. You either think Vincent got a good little boost
from last year and can take Sonic, or you don't. It's pretty clear last
year he wouldn't have had a chance. <br><br>Way I see it, Sonic's got
a number he should aim for: 55.38%. The magical Crono number! If he
makes that, he's looking good to sweep that Crono fool clear off the
bracket in a couple of rounds. If not? Well, I still give him a chance,
you can't really trust these things through extrapolation anyway.
Vincent could've boosted, whatever. But anyway, I'm telling you that's
what the people are gonna be looking for. And Sonic might be the one to
deliver on it. What he did to CATS, he looks like he's a contender to
do it, for sure. Not that I'm one to call contest winners through
fodder, of course.<br><br>Might be the one to do it? I lied. This match won't answer <i>anything</i> about Crono/Sonic&#8230; ha ha ha ha!<br><br><b>Lopen's prediction:</b> Sonic with 55.38%
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/25/2006 9:10:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343284358">message detail</a>
 | #386</td></tr>
<tr class="even"><td>
Jeeze Moltar, you're losing your step.<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/25/2006 9:11:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343284624">message detail</a>
 | #387</td></tr>
<tr class="even"><td>
I don't see how anyone would think Sonic is breaking 55% here, unless
of course you think Sonic boosted for no random reason. Sure it's
possible, but I doubt it. He's not doing as good on Vincent as he did
on Tifa.<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/25/2006 9:11:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343284695">message detail</a>
 | #388</td></tr>
<tr class="even"><td>
Quiet you!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Ryu vs. Mega Man - Bracket: <b>MM</b> - Vote: <b>MM</b> (48/54)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 10/25/2006 9:22:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343287097">message detail</a>
 | #389</td></tr>
<tr class="even"><td>
Vincent with 52%? No way. 51% at most.<br>---<br>CB06 - Score: <b>50/54 </b>Rank: <b>Tied - 294th </b>Yesterday's Pick:<b> Sora</b> <br>Today's Pick: <b>Mega Man</b> Tomorrow's Pick: <b>Sonic</b> Losses: <b>Cortana, Ganon, Zero, MC</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/25/2006 9:32:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343289625">message detail</a>
 | #390</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>If Vincent wins this match, I am damning every single one of you to hell.  Every single one of you.  To hell.<br><br>Right
when the bracket came out, I feared this match. But damn it, this isn't
going to be the match where the Noble Nine breaks! It's not going to be
Sonic, not here, not now!<br><br>To hell.  Remember that.<br><br>My vote: Sonic<br>My bracket: Sonic<br>My prediction: Sonic with 53%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/25/2006 9:34:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343290066">message detail</a>
 | #391</td></tr>
<tr class="even"><td>
Does it matter? I don't think Yo is using the system I suggested. Guest
could have predicted Vincent with 100% of the vote and it wouldn't have
meant anything. =/<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/25/2006 9:37:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343290629">message detail</a>
 | #392</td></tr>
<tr class="even"><td>
Actually, using lol-ec stats Vincent &gt; Sonic with 50.02% of the
vote, but using common sense, Sonic &gt; Vincent with 51%. Still, I'd
love to see Vincent win!<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=304351" class="name">Mac Arrowny</a> |
Posted 10/25/2006 10:05:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343297211">message detail</a>
 | #393</td></tr>
<tr class="even"><td>
<i>Crew Consensus: Sonic wins in a close one, but he shouldn't be in
any real danger. The Blur from anywhere in the low-to-mid 50's.</i><br><br>Hey! I made a prediction too, you know!<br><br><i>Vincent with 52%? No way. 51% at most.</i><br><br>Heh, just look at what Vincent got on Ganon.<br><br>Also, why no posting these writeups in the stat topic?<br>---<br>99% of people just make up statistics on the spot. If you are part of the 1%, post this in your sig
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=304351" class="name">Mac Arrowny</a> |
Posted 10/25/2006 10:05:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343297288">message detail</a>
 | #394</td></tr>
<tr class="even"><td>
Oh, never mind.<br>---<br>99% of people just make up statistics on the spot. If you are part of the 1%, post this in your sig
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=640243" class="name">Big Bob</a> |
Posted 10/25/2006 10:08:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343297935">message detail</a>
 | #395</td></tr>
<tr class="even"><td>
<i>Big Bob's completely biased and nonsensical analysis</i><br><br>Alright,
folks! It's time for another legend to smack-lay in a downward
direction on another wimp! Sonic the Hedgehog has been around for 15
years now. He's the one that almost usurped Mario off the throne!
That's what I call strength? And he's fighting some optional party
member in an RPG. Sonic is so going to win this one. He got 80% on CATS
in the first round. Vincent got 50 something on Ganondorf. The same
Ganondorf who failed to outperform CATS in 2k4. That's weak. And what
about the people Vincent beat last year? He didn't get 80% on Kerrigan,
fodder of the worst kind. He didn't beat Dante too impressively, and
Dante just got beat by a Dinosaur that was destroyed by Mega Man last
year. And Squall got 60-40'd by Snake AFTER Kingdom Hearts II came out.
Vincent's new game is unpopular, and Sonic's new game for the Wii looks
like it will be among the best on the system.<br><br>Bob's Prediction: <b>Sonic with 70%</b><br>---<br>Gordon
Freeman finally won, but somehow, the universe survived... thus
allowing me to tell said universe about how I was owned by <b>NClark128</b>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/25/2006 10:09:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343298131">message detail</a>
 | #396</td></tr>
<tr class="even"><td>
Well, one person's prediction does not a consensus make!<br><br><i>Especially</i> if it's the Guest!&lt;/random guest hating&gt;<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Ryu vs. Mega Man - Bracket: <b>MM</b> - Vote: <b>MM</b> (48/54)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/25/2006 10:10:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343298393">message detail</a>
 | #397</td></tr>
<tr class="even"><td>
guest doesn't count. they make crappy picks!<br>---<br>zizzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/25/2006 10:12:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343298652">message detail</a>
 | #398</td></tr>
<tr class="even"><td>
Hating because of how badly we are <i>destroying</i> you in your own system? =O<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/25/2006 11:24:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343312257">message detail</a>
 | #399</td></tr>
<tr class="even"><td>
Whew.....looks like disaster is being averted.<br><br>*high-fives my new leaderboard buddy, tranny*<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 10/25/2006 11:36:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=343313999">message detail</a>
 | #400</td></tr>
<tr class="even"><td>
<i> From: Mac Arrowny </i><br><i><i>Crew Consensus: Sonic wins in a
close one, but he shouldn't be in any real danger. The Blur from
anywhere in the low-to-mid 50's.</i><br><br>Hey! I made a prediction too, you know!<br><br><i>Vincent with 52%? No way. 51% at most.</i><br><br>Heh, just look at what Vincent got on Ganon.<br><br>Also, why no posting these writeups in the stat topic?</i><br><br>Lol Vincent 45%.<br>---<br>CB06 - Score: <b>52/56 </b>Rank: <b>Tied - 276th </b>Yesterday's Pick:<b> Mega Man</b> <br>Today's Pick: <b>Sonic</b> Tomorrow's Pick: <b>Kirby</b> Losses: <b>Cortana, Ganon, Zero, MC</b>
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=6">7</a></li>
<li>8</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=9">10</a></li>
</ul>
</div>


</div>
<img src="genmessage8_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage8_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31144759&amp;page=7" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage8_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>