<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage4_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage4_files/nogs.css"></head><body linkifytime="201" linkified="3" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage4_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage4_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31144759%26page%3D3"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage4_files/advertisement.gif" alt="advertisement" height="10" width="120"></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage4_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage4_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 3
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;page=3">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31144759" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=2">Previous Page</a> |
Page 4 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=4">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/19/2006 9:03:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342025671">message detail</a>
 | #151</td></tr>
<tr class="even"><td>
Wash your hands, turn the page.<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/19/2006 10:06:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342039633">message detail</a>
 | #152</td></tr>
<tr class="even"><td>
<b>Aeon Division:</b> <i>Round 2 - Match 39</i> &#8211; (1)Yuna vs. (4)Joanna Dark<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Yuna </b><br>Round 1 &#8211; 79.30% vs. Roll (20.70%)<br><br>Yuna does very well against Roll&#8230;almost too well&#8230;<br><br><b>Joanna</b><br>Round 1 &#8211; 60.23% vs. Cortana (39.77%)<br><br>Joanna isn&#8217;t afraid of no Halo character!<br><br>Yeesh, another boring Round 2 match in the female half. Oh well, Round 3 should turn up to be a bit more interesting.<br><br>For
now though, Joanna&#8217;s Contest time looks to end here. Yuna is already
projected to beat her easily, but that performance on Roll was pretty
impressive. Yuna may actually be trying to make herself look like a
threat to take down Chun-Li with ease.<br><br>What am I guessing though? Yuna will put up an average performance.<br><br><b>Moltar&#8217;s Bracket Says:</b> Yuna will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Yuna: 68% - Joanna: 32%<br> <br> <br><br><b>Ulti&#8217;s Analysis That&#8217;s Not Written by Moltar Because He Hasn&#8217;t Gotten it Yet and Needs Something Here</b><br><br>joanna is the hott, perfect dark rulez bang bang zip zop zoobity bop<br> <br>Prediction: Magus with 87.55% <br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br> <b>Yuna</b><br><br><i>Previous Matches:</i><br><br>Yuna &#8211; 79.3% -- 97,716<br><br>Roll &#8211; 20.7% -- 25,501 <br><br><b>Joanna Dark</b><br><br><i>Previous Matches:</i><br><br>Joanna Dark &#8211; 60.23% -- 60,488<br><br>Cortana &#8211; 39.77% -- 39,944 <br><br>After
the awesome overperformance from Zelda and the underperformance from
Aeris, we&#8217;re back to the boring old female matches that we have become
accustomed to. Last round, Yuna came out with a very nice performance
by nearly quadrupling Roll and Joanna Dark put Cortana into her place
as bottom of the barrel fodder. <br><br>I&#8217;m not sure what to make of
this match simply because it could range from 60% - 70%, I think. Yuna
was likely underrated last year, Joanna could have been underrated and
then boosted from PDZ or she could have not been underrated and not
boosted and all sorts of various possibilities. There&#8217;s not much to
really go over with this match because of how easy it is. The most we
may get from this division is to see how Chun-Li will compare against
Yuna heading into the division finals (YUNA &gt; CHUN-LI). <br><br><b>Aitch Emm&#8217;s Bracket:</b> Yuna<br><br><b>Aitch Emm&#8217;s Prediction:</b> Yuna &#8211; 66.5% ; Joanna Dark &#8211; 33.5%<br><br><b>Aitch Emm&#8217;s Vote:</b> Yuna<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br> <br>This
is, without a shadow of a doubt, the worst match of Round 2. What we
will essentially have to endure is a character who does not deserve to
win two matches beating up on a character who did not deserve one
match. Yuna will beat up on Joanna and, based on the extent of said
beating-up, people will make predictions and set expectations regarding
her upcoming match with Chun-Li or Lara Croft. And... that's really all
I'm able to muster today. Sorry, but I don't really know or care about
either of these ladies, and the match result is obvious.<br><br>My prediction: Yuna def. Joanna Dark (67-33)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>
Don't let Roll fool you. Yuna's not suddenly some female bracket taking
beast. No no&#8230; Roll's just fodder of the worst sort. Joanna Dark will
take her off her little high horse that she summoned. (Oh ho I bet it
was Ixion!) Joanna will do her best to "disturb the summoner"&#8230; "touch
the summoner"&#8230; "hurt the summoner"? What's the line? <i>I don't know!</i><br><br>Oh wait&#8230; it's&#8230; <i>"Stay away from the summoner!"</i>
That's right! So Joanna Dark will do her best to&#8230; "approach the
summoner"? Alright. Yeah. She'll try to approach her&#8230; in votes&#8230; but
she'll fail&#8230; miserably.<br><br><b>Lopen's prediction:</b> Yuna with 64.12%
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/19/2006 10:07:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342039876">message detail</a>
 | #153</td></tr>
<tr class="even"><td>
<b>KH&#8217;s Analysis</b><br><br> lol x-stats history<br> <br>Yuna<br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 34th Place [23.66%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 31st Place [23.92%]<br><br>Yuna
is looking good in her prospects to take this very boring division down
after an absolute clobbering of Roll. Getting your ass beat down like
that against <i>Yuna?</i> Roll's either one of the most worthless
things we've ever seen, or -- actually, yeah, Roll = Worthless
basically summarizes last round's match.<br><br>Joanna Dark<br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 59th Place [15.12%]<br> <br>Joanna
had a good expected thrashing of Cortana herself, though nothing that
would give her inklings at this upset. Yuna just has too much going in
her favor, Joanna's just trying to make herself respectable here.<br><br><i>Notable Releases Since Last Appearance</i><br><br>Yuna: Kingdom Hearts II (PS2)<br>Joanna Dark: Perfect Dark Zero (XB360)<br><br><i>Upcoming Releases</i> <br><br>Yuna: N/A<br>Joanna Dark: N/A<br> <br>This match sums up everything I hate about the female bracket.<br><br>Karma Hunter's Vote: Joanna Dark. May be the last time we see her in a contest at this rate...<br><br><b>Karma Hunter's Krazy Prediction: Yuna with 67.5%.</b><br> <br>Yuna
has reason to be underrated and perhaps stronger this year, but Joanna
has reason to be SFFed in her last appearance...with the severity of
Nintendo SFF and PDZ, I'll go lower than what the stats say.<br><br>Upset Potential: 0%<br><br>lol steve illumina<br> <br><br> <br><b>Guest&#8217;s Analysis</b> - <i>Minipoooot</i><br><br>Let&#8217;s look at the previous matches in this contest with Yuna and Joanna.<br><br>Yuna: 79.3% - Roll: 20.7%<br>Joanna: 60.23%- Cortana: 39.77%<br><br>Though
Roll had never been in a previous contest, it was expected that she
would end up as fodder for Yuna. Cortana, also never having been in a
contest, was expected to perform somewhat decently against Joanna, but
ended up getting rolled over by Ms. Dark. Obviously, Yuna is the heavy
favorite coming into this match. According to lol x-stats, 2005 Yuna
will win against 2005 Joanna with 68.39%. However, with the release of
Perfect Dark Zero after last year&#8217;s contest, I believe that Joanna&#8217;s
percentage should rise a little.<br><br>My prediction:<br>Yuna- 64.5%<br>Joanna 35.5%<br> <br> <br> <br>Crew Consensus: In a match that will be boring, Yuna will win with 60.xx%.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=304351" class="name">Mac Arrowny</a> |
Posted 10/19/2006 10:26:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342044166">message detail</a>
 | #154</td></tr>
<tr class="even"><td>
<i>Crew Consensus: In a match that will be boring, Yuna will win with 60.xx%.</i><br><br>I wish! Sadly, it's more like 6x.xx%...<br>---<br>99% of people just make up statistics on the spot. If you are part of the 1%, post this in your sig
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=152338" class="name">Lopen</a> |
Posted 10/19/2006 11:17:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342054833">message detail</a>
 | #155</td></tr>
<tr class="even"><td>
Note to self... take all <b>BOLD PREDICTIONS</b> to heart, not just your own.  <br><br>On a mostly unrelated note, that was Ulti's best write-up in a while!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 10/19/2006 11:28:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342056742">message detail</a>
 | #156</td></tr>
<tr class="even"><td>
Moltar's got this easy, so the guests hang on to top spot!<br>---<br>CB06 - Score: <b>40/44 </b>Rank: <b>Tied - 1127th </b>Yesterday's Pick:<b> Aeris</b> <br>Today's Pick: <b>Yuna</b> Tomorrow's Pick: <b>Chun Li</b> Losses: <b>Cortana, Ganon, Zero, MC</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/19/2006 11:44:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342059320">message detail</a>
 | #157</td></tr>
<tr class="even"><td>
Damn it, Mets made me miss it again....well, no more of that, I
suppose. And I haven't checked out the poll yet, so I'm free to make a
percentage prediction, not that it wouldn't be completely off anyway.<br><br><i>DpOblivion's Quick Analysis:</i><br><br>Good
for Joanna, I'm glad she got out of the first round. Too bad for her
she's gotta go up against a 1 seed and a Final Fantasy female in Round
2. Will Yuna do better or worse than Aeris though? Aeris is obviously
more popular, while KOS-MOS is coming off a hot new game, and Joanna,
while not all that popular, is still a Nintendo character and wouldn't
suffer from the slight SFF for being a fellow RPG character. Not that
the percentage really matters, either way, Yuna wins and loss in this
contest are pretty set in stone, no real debate in any of her past,
present, or future matches in this contest.<br><br>My vote: Joanna<br>My bracket: Yuna<br>My prediction: Yuna with 59%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/19/2006 11:44:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342059451">message detail</a>
 | #158</td></tr>
<tr class="even"><td>
Wow.....looks like I went the wrong way with that one.....<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 10/20/2006 12:46:11 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342067971">message detail</a>
 | #159</td></tr>
<tr class="even"><td>
Oops.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), Castlevania: LoI, MMZX
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 10/20/2006 12:52:25 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342068688">message detail</a>
 | #160</td></tr>
<tr class="even"><td>
<i>Don't let Roll fool you. Yuna's not suddenly some female bracket
taking beast. No no&#8230; Roll's just fodder of the worst sort. Joanna Dark
will take her off her little high horse that she summoned. (Oh ho I bet
it was Ixion!) Joanna will do her best to "disturb the summoner"&#8230;
"touch the summoner"&#8230; "hurt the summoner"? What's the line? I don't
know!</i><br><br>lol cortana<br>lol joanna<br>lol female bracket<br><br><b>TuRtLe</b><br>~~~<br>35/40 in the contest. My analysis topic here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=152338" class="name">Lopen</a> |
Posted 10/20/2006 2:08:52 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342075905">message detail</a>
 | #161</td></tr>
<tr class="even"><td>
I stand by my statement... sans the Joanna "high-horse" segment!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=254355" class="name">Lugia2</a> |
Posted 10/20/2006 5:53:16 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342087455">message detail</a>
 | #162</td></tr>
<tr class="even"><td>
Holy...how did you guys mess up this badly?  Usually it's just the Crew, DP, or Board 8...but all at the same time?<br><br>No, wait...this happened w/ Magus/Knuckles and Sub/MC matches too...though it's still a little odd.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/20/2006 5:58:06 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342087675">message detail</a>
 | #163</td></tr>
<tr class="even"><td>
Who said Yuna well over 70%? I'M PRETTY SURE I DID. Samus underrated, confirmed!<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/20/2006 6:12:17 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342087857">message detail</a>
 | #164</td></tr>
<tr class="even"><td>
<i>From Lugia2 Posted 10/20/2006 6:53:16 AM</i><br><i>Holy...how did you guys mess up this badly?  Usually it's just the Crew, DP, or Board 8...but all at the same time?<br><br>No, wait...this happened w/ Magus/Knuckles and Sub/MC matches too...though it's still a little odd.</i><br><br>It's a simple explanation, really. I was not the guest.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/20/2006 6:33:08 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342088378">message detail</a>
 | #165</td></tr>
<tr class="even"><td>
Agree'd. I totally would have took Yuna with 72%, been off by 8, and
still won! *Ignores the fact that I would have completely blown the
last coupel days*<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/20/2006 6:36:11 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342088539">message detail</a>
 | #166</td></tr>
<tr class="even"><td>
Yuna!!!!<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/20/2006 6:36:40 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342088557">message detail</a>
 | #167</td></tr>
<tr class="even"><td>
Vincent &gt; Sonic confirmed!<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/20/2006 6:38:18 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342088641">message detail</a>
 | #168</td></tr>
<tr class="even"><td>
I would have failed on Aeris, but I have a pretty good feeling that I might have done decently with Zelda. ;o<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/20/2006 6:39:12 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342088700">message detail</a>
 | #169</td></tr>
<tr class="even"><td>
Yuna &gt; Zelda baby!<br><br>Zelda 75.53%  80,168<br>Joanna Dark 24.47%  25,977<br>TOTAL VOTES 106,145<br><br>And that's without PD0 <i>!!</i><br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/20/2006 6:42:35 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342088846">message detail</a>
 | #170</td></tr>
<tr class="even"><td>
Ah, but you forget about the <b>MASSIVE N64 rSFF!!!</b><br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/20/2006 6:59:35 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342089726">message detail</a>
 | #171</td></tr>
<tr class="even"><td>
...but Zelda and Mario were both on the 64!<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/20/2006 7:02:51 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342089892">message detail</a>
 | #172</td></tr>
<tr class="even"><td>
Yeah, but that was a case of SFF, not rSFF.<br><br>And don't you dare bring up the gun-user rSFF in this match. D:<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/20/2006 3:05:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342145857">message detail</a>
 | #173</td></tr>
<tr class="even"><td>
KOS-MOS.........................38.35% 43543<br>Aeris Gainsborough......61.65% 70006<br>TOTAL VOTES............................113549<br><br>71.68% of the brackets predicted this match correctly.<br><br>KOS-MOS
actually does very well for herself, and gets 38% on Aeris. Now, these
results are similiar to how a 2003 Aeris vs. 2004 KOS-MOS would have
gone. Does this mean Aeris isn't any stronger, KOS-MOS was underrated,
or Aeris's boost for KH2 was cancelled out by KOS-MOS is XS3?<br><br>Today, *takes off glasses* My God, Yuna...<br><br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>KH - 7<br>Lopen - 7<br>Moltar - 6<br>Ulti - 5<br>HM - 5<br>Yoblazer - 2<br><br>A sad day indeed.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Yuna vs. Joanna - Bracket: <b>Yuna</b> - Vote: <b>Joanna</b> (40/44)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=254355" class="name">Lugia2</a> |
Posted 10/20/2006 3:13:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342147592">message detail</a>
 | #174</td></tr>
<tr class="even"><td>
The Guest.  Is winning.<br><br>Quick!  Set off a bomb in hell, cause Hell is freezing over!<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/20/2006 3:21:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342149051">message detail</a>
 | #175</td></tr>
<tr class="even"><td>
Guests are in first, Lopen is tied for second, and Yo is in a distant last place.<br><br>It's like this is the Soviet Russia Crew.<br>---<br><a class="linkification-ext" href="http://wemajor12.myrockinprofile.com/" title="Linkification: http://wemajor12.myrockinprofile.com/">http://wemajor12.myrockinprofile.com/</a><br>Next celebrity I hope to out-rank:  Weird Al Yankovic (#8)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 10/20/2006 3:22:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342149200">message detail</a>
 | #176</td></tr>
<tr class="even"><td>
WHAT THE CRUNK ANALYSIS CREW<br>---<br>This was Ed Bellis, servant to the mighty Guru <b>Z1mZum</b>. Congrats, buddy!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/20/2006 3:22:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342149364">message detail</a>
 | #177</td></tr>
<tr class="even"><td>
Eh? It's not their fault. Us guests are just so spectacular.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/20/2006 4:32:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342163333">message detail</a>
 | #178</td></tr>
<tr class="even"><td>
Keep in mind the guests had 1 point up until Vincent/Ganon..... then we caught fire.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=152338" class="name">Lopen</a> |
Posted 10/20/2006 7:09:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342194428">message detail</a>
 | #179</td></tr>
<tr class="even"><td>
In accordance with my advice...<br><br>Up my Chunners% by 7, Moltar.  <br><br>Of course <i>this</i> time it'll end up screwing me, I bet!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/20/2006 9:39:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342223516">message detail</a>
 | #180</td></tr>
<tr class="even"><td>
<b>Aeon Division:</b> <i>Round 2 - Match 40</i> &#8211; (3)Chun-Li vs. (2)Lara Croft<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Chun-Li </b><br>Round 1 &#8211; 68.74% vs. Kasumi (31.26%)<br><br>Ouch, destruction.<br><br><b>Lara</b><br>Round 1 &#8211; 77.55% vs. Alyx (22.45%)<br><br>Ouch, destruction x2.<br><br>With
both females looking good in Round 1, we might have a match on our
hands here. Right? RIGHT?!? OH YEAH, IT&#8217;S GOING TO BE INTENSE!<br><br>Bleh,
who am I kidding, I can&#8217;t get excited for this. I mean, look at the
next two matches. Snake/Squall and Yoshi/Dante. Now THOSE I can get
excited over. For now though, we just get this.<br><br>This match is
only projected to be close if Lara has climbed back to her 2003
value&#8230;yeah, I don&#8217;t think so. A new game with good sales and reviews
will help her up from her pitiful 2004 performance, but not to
Chun-Li&#8217;s level, or even her 2003 level. If Lara can pull 40% on
Chunners, it&#8217;s a moral victory.<br><br><b>Moltar&#8217;s Bracket Says:</b> Chun-Li will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Chun-Li: 61% - Lara: 39%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br> *looks at Samus/Ada*<br><br>Yeah,
blowing away joke fodder doesn't mean that you won't suck ass later on.
I don't get how people are hyping Lara. No one gave a crap about
Legends.<br><br>Prediction: Chun-Li with 65.45%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br> <b>Chun-Li</b><br><br><i>Previous Matches:</i><br><br>Chun-Li &#8211; 68.74% -- 71,106<br><br>Kasumi &#8211; 31.26% -- 32,611 <br><br><b>Lara Croft</b><br><br><i>Previous Matches:</i><br><br>Lara Croft &#8211; 77.55% -- 75,464<br><br>Alyx Vance &#8211; 22.45% -- 21,850 <br><br>This
match is pretty much a foregone conclusion. Some people like to
entertain the idea of Lara Croft winning here, but after Chun-Li&#8217;s
dominate performance on Kasumi, it&#8217;s safe to say that any talk of that
should have been ceased then. Lara <i>does</i> have a chance to make it respectable, but Chun-Li isn&#8217;t going to lose this match. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Chun-Li<br><br><b>Aitch Emm&#8217;s Prediction:</b> Chun-Li &#8211; 55% ; Lara Croft &#8211; 45%<br><br><b>Aitch Emm&#8217;s Vote:</b> Chun-Li<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>The
round's last female match is kinda good, but not really. After Lara's
phenomenal performance against Alyx Vance, some people are wondering if
today's match will have a disputed winner. Personally, I'm not sold.
Alyx is the weakest of the weak, so of course a stronger, infinitely
more recognizable character like Lara will run all over her. To the
GameFAQs visitors, I believe that Chun-Li is nearly as recognizable as
Lara, but the Street Fighter pioneer is much more liked. To me, that's
really all there is to it. Chun-Li wins it with ease.<br><br>My prediction: Chun-Li def. Lara Croft (57-43)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>
Lara Croft got about 80% on her opponent last round. That was pretty
hilarious. Not that it really meant anything. Well, it made me laugh,
that means something.<br><br>This match will be where we get the answer
to the question that's on all of our minds: "Did Lara's new release of
Tomb Raider: Some Game <i>really</i> help her?" Me? I don't think so. I expect Lara to slightly outdo Kasumi here, and that's about it.<br><br>Oh,
oh&#8230; that's not about it. What else can we get from this? We should
watch out for what Chun Li gets on Lara Croft. Basically, will she do
better or worse than Yuna did against Joanna Dark? I'm thinking if she
does around equal or better, you've got to see Chun Li as the favorite
next round. As washed up as Lara Croft is, I'd have take her to beat
Joanna Dark without thinking too hard about it. Now, if Chun Li does
worse, or a lot worse&#8230; Yuna's looking good. But even then, you've
always got to consider Tomb Raider: Some Game. That's an X-Factor on
Lara, no doubt!<br><br><b>Lopen's prediction:</b> Chun Li with 71.12%
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/20/2006 9:39:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342223599">message detail</a>
 | #181</td></tr>
<tr class="even"><td>
<b>KH&#8217;s Analysis</b><br><br> lol x-stats history<br> <br>Chun-Li<br> <br>Summer 2005 Contest<br>Extrapolated Strength --- 34th Place [22.84%]<br><br>Chun-Li looks on par with 2002 Cloud last round with that beating of Kasumi. Yay 2k2 Stats!<br><br>Lara Croft<br> <br>Summer 2002 Contest<br>Extrapolated Strength --- 27th Place [21.80%]<br> <br>Summer 2003 Contest<br>Extrapolated Strength --- 37th Place [ 22.11% ]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 53rd Place [13.91% ]<br><br>Lara
gets the biggest blowout of her career last round, over the likes of
such foes as Chop Chop Master Onion and Ryo Hazuki. Does this mean that
she's any stronger, or that Alyx Vance is one of the most pathetic
chumps in the history of the contest?<br><br>...do you really need an answer to that?<br><br><i>Notable Releases Since Last Appearance</i><br><br>Chun-Li: N/A<br>Lara Croft: Tomb Raider: Legend (Multi)<br><br><i>Upcoming Releases</i><br><br>Chun-Li: N/A<br>Lara Croft: N/A<br> <br>This
match has become *almost* semi-debatable lately! I blame the female
bracket. Anywho, if Chun-Li is overrated significantly from the Dream
Division and Lara is back to her old 'glory', I guess you can make a
case for her. But I don't see the Street Fighter fanbase faltering her
to the lack of Tomb Raider fanbase. That's all I need.<br><br>Karma Hunter's Vote: The Strongest Woman in the World! (aka Chun-Li)<br><br><b>Karma Hunter's Krazy Prediction: Chun-Li with 63.74%.</b><br> <br>I'm too lazy to even change my prediction from Chun-Li/Kasumi.<br><br>Upset Potential: 10%<br> <br>Lara
looks pretty hot in that picture and Chun-Li could be overrated. Lara
could overperform, but winning would be a BIG stretch.<br> <br>Upset Prediction: Lara Croft with 53.4%%<br> <br><br> <br><b>Guest&#8217;s Analysis</b> - <i>Who Cares?</i><br><br>Aside
from being disappointed that Chunny wasn&#8217;t setup to face Peach, the
first thing that came to mind when I saw the Chun-Li/Lara setup when
the bracket was released was &#8220;Trap match for casuals.&#8221; You may or may
not seen them, but every once in a while you&#8217;d have topics like &#8220;Yuna
or Lara&#8221; or &#8220;Chun-Li &gt; Lara. Bad pick?&#8221; made by casuals &amp;
contest noobs gracing the board.<br><br>Not that there&#8217;s anything wrong
with that, hell that&#8217;s the very people who are being targeting for this
match. Just look that the prediction percentage for Kratos/Ryu for
goodness sake. In this respect, Ceej <i>did</i> setup a nice little
match here, its just that those of us who&#8217;ve been around these contests
long enough know we&#8217;re in for yet another match with an obvious winner.
And that winner is Chun-Li.<br><br>The Queen of Fighting Games is
coming fresh off a sound beating of the DoA star Kasumi, potentially
tacking on some genre-SFF for good measure. Unfortunately because she
was facing someone that was four years removed from the contest, we
have no idea what that performance really means for her. And now once
again Thunder Thighs is forced to play the role of measuring stick to
her opponent. This time she&#8217;s dealing with a character that not only
missed last year&#8217;s contest, but suffered a 9% drop in the X-stats since
her last appearance. Needless to say, it wouldn&#8217;t be fair to use either
of Chunny&#8217;s performances as a gauge for how well she&#8217;ll do in her big
match against Yuna next round.<br><br>On the other side, yeah, Lara
doesn&#8217;t have much of a shot here. Don&#8217;t let her beatdown of Alyx Vance
think that she suddenly has a chance. She&#8217;s not exactly known for
blowing out fodder. She let Chop-Chop Master Onion score 30% on her and
let Ryo Hazuki score 40%. (Yes I know it&#8217;s from 2k2 where a lot of
weird things happened, but even this is inexcusable by that contest&#8217;s
standards) The fact that Alyx couldn&#8217;t avoid a tripling &amp; the two
ladies combined for the worst vote totals of this contest just goes to
show how much suck Alyx is made of. I mean she&#8217;s an NPC that comes from
the same game as Gordon Freeman for cryin&#8217; out loud! Just how strong
could she really be?
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/20/2006 9:40:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342223840">message detail</a>
 | #182</td></tr>
<tr class="even"><td>But wait; didn&#8217;t she have a new multi-platform
game out called Tomb Raider Legend you say? If anything Legend may have
put Lara back on the map and breathed some life back into her series,
but you can forget about her helping her iconic status. (Which is
something a lot of casual brackets will be banking on) She&#8217;s fallen
from that pedestal long ago, and really as far as these contests go,
that&#8217;s something that&#8217;s never helped her much to begin with. Fact is,
GameFAQs as a whole has never really cared for Tomb Raider, and for
Legend to push her up from horrible fodder in 2k4, where she couldn&#8217;t
break 20% on Samus, to a solid midcarder with the likes Chun, Yuna,
&amp; Rikku two years later is pretty much ludicrous. For that to
happen, Legend needed to be a huge as Resident Evil 4 in terms of
praise and acclaim, and that game was no RE4. Even in her best year
(2k3), she was practically equal to KOS-MOS. And by the way, Chun is
projected to get over 57% on the Xenosaga star based on last year&#8217;s
stats.<br><br>With
that said, I&#8217;m not sure if what happened to her in 2k4 was a large
fluke or not, but I&#8217;d expect Lara to get a nice boost from Legend, and
I wouldn&#8217;t be surprised to see her get all the way back to a
respectable KOS-MOS-ish level of strength. The higher seeding will most
certainly help as well, &amp; Chun is likely to a bit overrated as
shown by Bowser&#8217;s poor showing against Leon, (and well...just about
every other character in the Dream Division not having the greatest of
showings) but that&#8217;s about it. Even if the Lara hate has suddenly
disappeared, as some of her supporters had been suggesting after her
Round 1 win, it won&#8217;t be enough. Street Fighter has always had a
respectable presence on this site, and that fanbase likes Chun too much
to let her drop this match.<br><br>So when all is set and done, Lara
just has too much going against her to &#8216;shock the world&#8217; come tomorrow.
Chun-Li will advance and expect to see a lot of casual brackets get
busted here, much like how they were destroyed when Ryu beat Kratos.<br><br><b>PREDICTION: Chun-Li with 59.41%</b><br> <br> <br> <br>Crew
Consensus: Chun-Li pulls out the win. The range is pretty large, but
it's because we're unsure about how much Lara has changed from 2004.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 10/20/2006 9:51:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342226061">message detail</a>
 | #183</td></tr>
<tr class="even"><td>
72.63<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/20/2006 9:58:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342227373">message detail</a>
 | #184</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>This is the first time Lara
Croft has seen the 2nd round since the inaugural contest back in 2002.
In it, she only managed to put up 59% on the cult character Ryo
Hazuki....ouch. Here, she faces Chun-Li, who is from a series that is
far from cult, Street Fighter. Now, Lara's had a successful new game,
and even a movie starring Angelina Jolie as her since then....but
that's not going to be enough to save her here. Here's to Chun-Li
scoring the upset, and those damn -1 casuals not seeing it coming.<br><br>My vote: Lara Croft<br>My bracket: Chun-Li<br>My prediction: Chun-Li with 55.55%<br><br>(Whew, not the lowest prediction! I swear I didn't look at HM's and just boost it.....)<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/20/2006 10:01:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342227994">message detail</a>
 | #185</td></tr>
<tr class="even"><td>
Oh my God, I totally want Tomb Raider: Some Game, it sounds awesome.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/21/2006 12:50:48 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342256311">message detail</a>
 | #186</td></tr>
<tr class="even"><td>
Expect another point for the guests on October 22nd!<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/21/2006 12:53:35 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342256656">message detail</a>
 | #187</td></tr>
<tr class="even"><td>
Hopefully Leonhart shows SOME brains and puts Snake on a 50.01% win
just to give the Guests some hope while keeping his own dreams of
Squall winning within reach. If he puts Squall at anything above
49.99%, use DP's prediction as the guest analysis &gt;_&gt;;<br>---<br>~*~ Board 8's Champion MILF Hunter ~*~
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/21/2006 12:56:07 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342256966">message detail</a>
 | #188</td></tr>
<tr class="even"><td>
Oh please, what is the fun of going with the flow like that? Risk big, win big!<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/21/2006 12:56:08 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342256969">message detail</a>
 | #189</td></tr>
<tr class="even"><td>
Nah, Leonhart likes Solid Snake alot too. I'm sure he'll make it close
-- and rightfully so -- but I'm confident he'll take Solid.<br>---<br><a class="linkification-ext" href="http://wemajor12.myrockinprofile.com/" title="Linkification: http://wemajor12.myrockinprofile.com/">http://wemajor12.myrockinprofile.com/</a><br>Next celebrity I hope to out-rank:  Weird Al Yankovic (#8)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/21/2006 1:15:58 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342259355">message detail</a>
 | #190</td></tr>
<tr class="even"><td>
Considering he doesn't <i>really</i> have much to lose on that match, I'd be pretty surprised if he didn't take Squall in a close one at least. He <i>does</i> like him more and he wouldn't want to be wrong if Squall actuall does win (he won't). =p<br><br>---<br><i>The Master Sword is the most sought-after blade in Hyrule. He who wields it carries with him the hope of the kingdom.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/21/2006 1:18:13 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342259598">message detail</a>
 | #191</td></tr>
<tr class="even"><td>
Wait and see, my former HM. The Squallid within is more powerful than you think.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/21/2006 1:31:04 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342260950">message detail</a>
 | #192</td></tr>
<tr class="even"><td>
But how would you feel if you didn't choose your favorite character when he broke the Noble Nine <i>!!</i><br><br>---<br><i>The Master Sword is the most sought-after blade in Hyrule. He who wields it carries with him the hope of the kingdom.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/21/2006 1:34:39 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342261307">message detail</a>
 | #193</td></tr>
<tr class="even"><td>
Exactly. It will be an arduous, uphill battle, featuring a wall of text from me, as nothing less would do.<br><br>As
a result, the winner of said match will have several walls of text
written about them by me in the form of a character
analysis/tribute/something else along those lines.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/21/2006 1:36:52 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342261534">message detail</a>
 | #194</td></tr>
<tr class="even"><td>
The problem is the pic.<br><br>While Snake's pic
is indeed pretty bad, he has won on worse, and Squall's pic is the
worst pic I can ever recall him having. Squall looks far more brunette
than normal and loses any edge he would have gained from Snake's pic.<br>---<br>~*~ Board 8's Champion MILF Hunter ~*~
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/21/2006 1:38:48 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342261715">message detail</a>
 | #195</td></tr>
<tr class="even"><td>
...Squall had that exact same picture against Geno, and his gunblade is
extremely prominent. Honestly, that's one of my more favored pictures
of him. I dislike the one he got against Knuckles last year, and the
one he got against Vincent wasn't the best either.<br><br>...And
the picture he got against Bomberman is by far the worst he has
received. At least his polygon against Samus had his famous face shot
from the FFVIII demo in the background.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/21/2006 1:59:01 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342263582">message detail</a>
 | #196</td></tr>
<tr class="even"><td>
Yeah, Squall definitely has the edge in that picture...but I dare you
to find me a single picture of Snake that he wouldn't have had the edge
against. The only 'X-Factor' here is to see if Old Snake will adversely
affect Snake, and while I suppose it's a possibility there's a reason
why the MGS4 trailers are the absolute hottest game trailers on the net
right now. I don't think it'll do much, if anything at all.<br><br>Though
if Squall actually wins or even makes it interesting expect Snake
fanboys to come out of the woodwork blaming the picture for the
performance. <br><br>(including me, I'm not gonna lie here &lt;_&lt;)<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 10/21/2006 2:00:49 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342263748">message detail</a>
 | #197</td></tr>
<tr class="even"><td>
How is your sig space feeling Karma? I'm all ready to set up shop.......<br>---<br>~*~ Board 8's Champion MILF Hunter ~*~
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/21/2006 2:00:50 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342263750">message detail</a>
 | #198</td></tr>
<tr class="even"><td>
I really don't care what it takes for Squall to win, as long as he
wins. Blame it on the picture all you want. Nothing will take that away
from me.<br><br>...And watching the board react will be beyond priceless.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/21/2006 2:01:15 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342263791">message detail</a>
 | #199</td></tr>
<tr class="even"><td>
People will always blame the picture for Snake underperforming regardless of how good or bad it is. &lt;&lt;<br><br>---<br><i>The Master Sword is the most sought-after blade in Hyrule. He who wields it carries with him the hope of the kingdom.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/21/2006 2:02:03 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342263866">message detail</a>
 | #200</td></tr>
<tr class="even"><td>
Snake would have totally got 70% on Sora without that damn biased picture. Stupid Sora pity-votes!!!<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=2">3</a></li>
<li>4</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=9">10</a></li>
</ul>
</div>


</div>
<img src="genmessage4_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage4_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31144759&amp;page=3" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage4_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>