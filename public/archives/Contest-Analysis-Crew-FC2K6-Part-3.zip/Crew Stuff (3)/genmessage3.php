<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage3_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage3_files/nogs.css"></head><body linkifytime="210" linkified="3" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage3_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage3_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31144759%26page%3D2"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage3_files/advertisement.gif" alt="advertisement" height="10" width="120"></div>
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage3_files/a.xhtml" marginwidth="0" marginheight="0" hspace="0" vspace="0" bordercolor="#000000" frameborder="0" height="90" scrolling="no" width="728">
&lt;SCRIPT language='JavaScript1.1'
SRC="http://ad.doubleclick.net/adj/N3671.CNETENT/B2026705.27;abr=!ie;sz=728x90;click0=http://adlog.com.com/adlog/e/r=10153&amp;amp;s=688352&amp;amp;t=2006.10.28.12.55.04&amp;amp;o=1:&amp;amp;h=pi&amp;amp;p=&amp;amp;b=4&amp;amp;l=En_US&amp;amp;site=6&amp;amp;pt=&amp;amp;nd=&amp;amp;pid=&amp;amp;cid=&amp;amp;pp=&amp;amp;e=&amp;amp;rqid=00c17-gne-ad14540F467E3CF7A&amp;amp;event=58/;ord=2006.10.28.12.55.04?"&gt;
&lt;/SCRIPT&gt;
&lt;NOSCRIPT&gt;
&lt;A
href="http://adlog.com.com/adlog/e/r=10153&amp;amp;s=688352&amp;amp;t=2006.10.28.12.55.04&amp;amp;o=1:&amp;amp;h=pi&amp;amp;p=&amp;amp;b=4&amp;amp;l=En_US&amp;amp;site=6&amp;amp;pt=&amp;amp;nd=&amp;amp;pid=&amp;amp;cid=&amp;amp;pp=&amp;amp;e=&amp;amp;rqid=00c17-gne-ad14540F467E3CF7A&amp;amp;event=58/http://ad.doubleclick.net/jump/N3671.CNETENT/B2026705.27;abr=!ie4;abr=!ie5;sz=728x90;ord=2006.10.28.12.55.04?"&gt;
&lt;IMG
SRC="http://ad.doubleclick.net/ad/N3671.CNETENT/B2026705.27;abr=!ie4;abr=!ie5;sz=728x90;ord=2006.10.28.12.55.04?"
BORDER=0 WIDTH=728 HEIGHT=90 ALT="Click Here"&gt;&lt;/A&gt;
&lt;/NOSCRIPT&gt;
</iframe><img src="genmessage3_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 3
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;page=2">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31144759" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=1">Previous Page</a> |
Page 3 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=3">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/17/2006 7:29:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341578559">message detail</a>
 | #101</td></tr>
<tr class="even"><td>
*secretly ups his own prediction by one in response*<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/17/2006 8:17:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341592513">message detail</a>
 | #102</td></tr>
<tr class="even"><td>It would be nice if you could eliminate the
underscores and the word "The" from my name when you post mine. I do
have the account, it just has a limited amount of posts. =/<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/17/2006 8:32:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341597037">message detail</a>
 | #103</td></tr>
<tr class="even"><td>
<b>Triforce Division:</b> <i>Round 2 - Match 37</i> &#8211; (1)Zelda vs. (4)Terra Branford<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Zelda</b><br>Round 1 &#8211; 86.08% vs. Carmen (13.92%)<br><br>86% and over 100K votes on Carmen. Watch out everyone!<br><br><b>Terra</b><br>Round 1 &#8211; 58.69% vs. Kerrigan (41.31%)<br><br>In a match nearly perfectly predicted by the X-Stats, Terra beats Kerrigan.<br><br>From
one impressive Zelda victory, to hopefully another. Since it seems that
Terra and Kerrigan haven&#8217;t changed from last year, let&#8217;s see what the
good ol&#8217; Stats say on this!<br><br><i>Zelda (2005c) VS Terra (2005c)<br><br>Zelda has a strength of 33.71.<br>Terra has a strength of 18.65.<br><br>Zelda wins with 72.34% of the vote! <br>A win of 47,037 with 105,286 total votes cast.</i><br><br>72% for Zelda isn&#8217;t bad. I&#8217;ll go a little higher though, given Zelda&#8217;s impressive performance on Carmen.<br><br><b>Moltar&#8217;s Bracket Says:</b> Zelda will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Zelda: 74% - Terra: 26%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>Terra won a match and I completely forgot she was even in this contest. God the female half sucks.<br><br>*plugs in 2005 stats and gives Zelda extra 2% for no real reason*<br><br>Prediction: Zelda with 74.34%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br> <b>Zelda</b><br><br><i>Previous Matches:</i><br><br>Zelda &#8211; 86.08% -- 102,509<br><br>Carmen Sandiego &#8211; 13.92% -- 16,578 <br><br><b>Terra Branford</b><br><br><i>Previous Matches:</i><br><br>Terra Branford &#8211; 58.69% -- 58,141<br><br>Sarah Kerrigan &#8211; 41.31% -- 40,922 <br><br>In
the last round, the lovely Princess of Hyrule sets some records with
her performance, being the first character to ever break 100,000
individual votes and getting the largest blowout of the entire contest.
She comes into this round looking <i>exceptionally</i> strong with the
annihilation of Carmen. Terra, on the other hand, looked about how she
was expected to against Kerrigan. The Final Fantasy VI heroine is in
for a beat down of a lifetime this round. <br><br>This match is pretty much a no-brainer as far as result and percentage are concerned. Given that Terra is definitely not <i>stronger</i> than last year, Zelda is at least guaranteed to get about 72% or so in this match; however, I think she&#8217;ll get <i>more</i>
thanks to a slight increase, along with this feeling that Zelda is just
going to perform much better in the female half than she might normally
in a usual bracket. <br><br>Zelda has been <i>the</i> most impressive
character for Nintendo this contest, which is somewhat surprising but
also rather expected given where she comes from and her competition.
Nothing would give me greater pleasure than to see Zelda rock the
female half of the bracket and end up in the finals &#8211; rSFF SAMUS HERE
WE COME! <br><br>It&#8217;s one match at a time, though, and Zelda just
needs to continue her domination of Final Fantasy characters en route
to a showdown with Samus. That&#8217;s right &#8211; Aeris is just another Final
Fantasy casualty against the mighty Legend of Zelda. I&#8217;m really anxious
to see Zelda post-Twilight Princess, especially since she might have a <i>big</i> role for once! <i>Zelda4Life!</i> <br><br><b>Aitch Emm&#8217;s Bracket:</b> Zelda<br><br><b>Aitch Emm&#8217;s Prediction:</b> Zelda &#8211; 76.5% ; Terra Branford &#8211; 23.5%<br><br><b>Aitch Emm&#8217;s Vote:</b> Zelda!<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>She
controls the crowd, you know she holds it down, when it drops you know
it's jiggy when you hear the sound, from town to town until she's
world-renowned, she'll rock Hyrule all year around.<br><br>My prediction: Zelda break dances all over Terra's uglyass face (75-25)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br> <i>Another</i>
match where I only have one of the two right, (this doesn't get old!) I
was expecting Terra to get stopped by Kerrigan. Yes, I'd seen the last
contest&#8230; but I figured because they were both fodder anything could
happen. Okay, I was wrong.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/17/2006 8:33:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341597244">message detail</a>
 | #104</td></tr>
<tr class="even"><td>What does that have to do with this match? The
hell if I know. This one should be easy&#8230; I think the most interesting
thing we'll see here is "how does Zelda compare to Dante". Dante got
71.50% on Terra last year. Will Zelda do better or worse? Me? Well, if
you know me&#8230; obviously, I'm thinking "worse".<br><br>Why? Because <b>DANTE IS INVINCIBLE!</b> (the hell with you, Master Chief!)<br><br><b>Lopen's Prediction:</b> Zelda with 68.50%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br> lol x-stats history<br><br>Zelda<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 19th Place [30.29%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 14th Place [30.89%]<br><br>Zelda
sought, found, and beat the crap out of Carmen Sandiego last round
(;_;), and is looking to follow that up with another fodder crushing
today. All just an appetizer for the inevitable Zelda/Aeris clash, of
course <i>!!</i><br><br>Terra<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 50th Place [17.10%]<br><br>Terra
does what's expected of her against Kerrigan despite all the
hullaballoo concerning the match picture. FF6 gets another win under
its belt (amazingly), but that all comes to an end here. Goodbye,
Terra. Don't let the door smack you on the ass on the way out.<br><br><i>Notable Releases Since Last Appearance</i><br><br>Zelda: N/A<br>Terra: N/A<br><br><i>Upcoming Releases</i><br><br>Zelda: The Legend of Zelda: Twilight Princess (WII)<br>Terra: N/A<br><br>...yeah,
I'm following Jill/Peach a little too closely right now to give this
any sort of real analysis. But come on, it's freaking <i>Zelda/Terra.</i><br><br>Typically
you'd expect Square to look its best when it goes out to Nintendo...but
this is FF6 we're talking about here. If this goes over a tripling I
won't bat an eye.<br><br>Karma Hunter's Vote: Terra.<br><br><b>Karma Hunter's Krazy Prediction: Zelda with 74.86%.</b><br> <br>Do
I doubt the Devil Division? No. Do I think Zelda is any stronger this
year? No. But I'm getting the feeling that the name "Zelda" is an
absolute fodder killer. Expect her to look like she can take down Snake
here, but falter as soon as she runs into real competition.<br><br>Upset Potential: 0%<br><br>lol FF6<br> <br> <br> <br> <br><b>Guest&#8217;s Analysis</b> - <i>Lady Ashe</i><br><br>Oh,
cool. It is time for another Square vs. Nintendo match. We have
characters from the two most powerful series, The Legend of Zelda, and
Final Fantasy, going head to head to see who gets to advance to round
three. On one side of the mat we have Princess Zelda, the heavy
favorite for this match. On the other side, we have Terra, one of the
two lead characters from the best game of all time. Who will win in
this epic conflict? Methinks you should read on and find out.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/17/2006 8:34:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341597465">message detail</a>
 | #105</td></tr>
<tr class="even"><td>Let's take a look at Zelda, shall we? She is
looking hot after a record shattering win against Carmen Sandiego, and
is looking to move on to face Aeris next round. There isn't really much
to say here, other than the fact that Zelda is from <i>the</i>
most popular series on GameFAQs. As if that was not enough, said series
has what is looking to be its best game ever coming out soon enough, as
well as her role as a commonly played character in Super Smash Brothers
Melee. But let's not forget that her opponent should not be any slouch,
either. It's time to see what is going on over with everybody's
favorite greenhead, Terra!<br><br>Back in round one, Terra faced off
against the horribly deformed looking Sarah Kerrigan, and defeated her
without much difficulty. It is generally accepted that her path for
this contest ends here, but she is still aiming to put up a good fight
before she goes. What does Terra have going for her to help her in this
endeavor? Well, she is from <i>the</i> best game of all time. Sadly
however, many GameFAQs users have never played a Final Fantasy game
before Final Fantasy 7, and so this isn't incredibly likely to count
for too much. After all, the best character from the best game ever
lost to <i>Diablo</i> of all peo- demons. Terra does have Final
Fantasy 6 coming to the DS, but it is most likely way too far off to
have any significant impact on the way this match will turn out.<br><br>Well,
we have taken a brief look at both of the characters, now what does it
all mean? To be honest, I would like to base my entire argument for
this match on the fact that Zelda got 100 000 freaking votes, but the
possibility of Carmen being uber-fodder is just too great to ignore. Oh
well, in that case I suppose that it would be best to take a look at
the good old x-stats.<br><br>Terra (2005c) VS Zelda (2005c)<br><br>Terra has a strength of 18.65.<br><br>Zelda has a strength of 33.71.<br><br>Zelda wins with 72.34% of the vote!<br><br>A win of 47,037 with 105,286 total votes cast.<br><br>Taking
Twilight Princess Hype and a possible drop for Terra into account, 75
or 76 is looking about right. But there is still one more point that I
would like to bring up, and it is something that I doubt will be
brought up by any of the Crew members. Zelda will benefit from Same Fan
Factor. The newer Final Fantasy games don't share the same fanbase as
The Legend of Zelda does, but the kind of people that have played Final
Fantasy 6 and the other older Final Fantasy games have almost
definitely played Zelda games as well. This will take away a fair
amount of votes that Terra would have otherwise received, and make
Zelda look even more impressive. While I would like for Terra to give
off a somewhat respectable performance, I just can't see it happening
for her.<br><br>My prediction? Zelda with 78.86%<br> <br> <br> <br>Crew Consensus: Hmm, this one is pretty much agreed upon. Mid 70's for Zelda it seems!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/17/2006 8:40:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341599210">message detail</a>
 | #106</td></tr>
<tr class="even"><td>
DS? More like GBA, mirite? *feels really stupid*<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=254355" class="name">Lugia2</a> |
Posted 10/17/2006 8:45:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341600780">message detail</a>
 | #107</td></tr>
<tr class="even"><td>
Wow. Everyone just used the X-stats and, in the exception of Lopen (who
would've been way off EVEN IF HE WON THIS MATCH BY 53%) pushed it up.
This was...odd.<br><br>But
hey! We might have the match of the round right here! Didn't think we'd
find an awesome match in the female bracket (I found Kairi/Claire just
odd, but this is cool)!<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/17/2006 9:11:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341607995">message detail</a>
 | #108</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Zelda should win this match
with ease, but the bigger question is by how much? The most imporant
match of the female bracket may very well be Aeris vs. Zelda next
round, which will be Final Fantasy VII vs. Legend of Zelda. Always a
big match there. This match here is sort of a preview, with Final
Fantasy VI vs. Legend of Zelda.<br><br>Now I have Aeris over Zelda as
my big upset, so my prediction here might be more hope than anything.
Obviously Aeris should do a lot better than Terra, but would it be that
much of a difference? It's still the same basic fanbase we are talking
about here.<br><br>My vote: Zelda<br>My bracket: Zelda<br>My prediction: Zelda with 71%<br><br>(Yay, not the lowest! Kind of surprising....)<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/17/2006 9:14:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341608676">message detail</a>
 | #109</td></tr>
<tr class="even"><td>
Zelda will double Samus. Good on you for joining the bandwagon, HM.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/17/2006 11:13:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341637901">message detail</a>
 | #110</td></tr>
<tr class="even"><td>
I'm .03% off at the moment. Let's keep this up! =D<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=625761" class="name">LordLockeRA</a> |
Posted 10/18/2006 11:13:05 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341698411">message detail</a>
 | #111</td></tr>
<tr class="even"><td>
Ouch.  Looks like Zelda jacked Mega Man's buster cannon, for it seems she's en route to stealing his title of Fodder Smiter.<br>---<br>Meeh.  Whatever.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3151105" class="name">KleenexTissue50</a> |
Posted 10/18/2006 1:22:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341715759">message detail</a>
 | #112</td></tr>
<tr class="even"><td>
The hell's the e-mail I'm supposed to send this thing to?<br><br>&gt;_&gt;<br>---<br>CB5 Points: <b>37/40</b>, Current Oracle placement: <b>38/163</b><br>Now playing: Okami
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/18/2006 3:54:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341744393">message detail</a>
 | #113</td></tr>
<tr class="even"><td>
It looks like that crazy high Zelda pick isn't so crazy any more!<br><br><i>From KleenexTissue50 Posted 10/18/2006 2:22:04 PM</i><br><i>The hell's the e-mail I'm supposed to send this thing to?</i><br><br><i>From Master Moltar Posted 10/15/2006 9:36:17 PM</i><br><i><a class="linkification-ext" href="mailto:MasterMoltar@gmail.com" title="Linkification: mailto:MasterMoltar@gmail.com">MasterMoltar@gmail.com</a><br><br>I should probably put that in the first post...</i><br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/18/2006 5:04:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341760048">message detail</a>
 | #114</td></tr>
<tr class="even"><td>
Jill Valentine..................49.99% 59239<br>Princess Peach............50.01% 59266<br>TOTAL VOTES..........................118505<br><br>62.85% of the brackets predicted this match correctly.<br><br>Peach
is winning, oh wait Jill caught up and took the lead. Oh no, here comes
the after school vote, Peach ahead again. Uh oh, but Jill's coming back
again, it's down to the wire, will Jill make it? Nope, another loss by
27 votes. That's a decent summary of yesterday.<br><br>Today, Zelda is crushing Terra.<br><br>KH - 7<br>Lopen - 7<br>Moltar - 6<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience) - 6<br>Ulti - 5<br>HM - 5<br>Yoblazer - 2<br><br>Lowest Peach pick was from me.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/18/2006 8:47:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341817087">message detail</a>
 | #115</td></tr>
<tr class="even"><td>
<b>Triforce Division:</b> <i>Round 2 - Match 38</i> &#8211; (3)KOS-MOS vs. (2)Aeris Gainsborough<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>KOS-MOS</b><br>Round 1 &#8211; 65.43% vs. Amy (34.57%)<br><br>KOS-MOS easily beats Amy with 65%.<br><br><b>Aeris</b><br>Round 1 &#8211; 69.78% vs. Marle (30.22%)<br><br>Marle holds up a bit better than I expected against Aeris.<br><br>Not
much to say about this match, except it should hopefully clear up some
of the Zelda/Aeris arguments. KOS-MOS isn&#8217;t really a match for Aeris.
We should be able to get a good read on the blue-haired girl though,
because that 2005 number just isn't right to me.<br><br>It doesn&#8217;t seem
as if Aeris has lost a step since 2003 either. Only 70% on Marle may
look unimpressive, but you have to remember she&#8217;s a Chrono Trigger
character, and CT characters, no matter who, always get the CT backing.
This match is predicted to end up over a doubling, but I&#8217;ll give
KOS-MOS a little extra, because she&#8217;s cute.<br><br>Oh, and this analysis is dedicated to KOS-MOS&#8217;s Round 2 match pic, which is the best thing the female bracket has given us yet.<br><br><b>Moltar&#8217;s Bracket Says:</b> Aeris will win.<br><br><b>Moltar&#8217;s Prediction is:</b> KOS-MOS: 34% - Aeris: 66%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br><br>(Nobody knows... the trouble I've seen...) -Phoenix Wright<br><br>How are my crewmates writing anything for these female matches? &gt;_&gt;<br><br>Prediction: Aeris with 66.65%<br> <br> <br> <br><b>HM&#8217;s Analysis</b><br> <br> <b>KOS-MOS</b><br><br><i>Previous Matches:</i><br><br>KOS-MOS &#8211; 65.43% -- 67,068<br><br>Amy Rose &#8211; 34.57% -- 35,441 <br><br><b>Aeris Gainsborough</b><br><br><i>Previous Matches:</i><br><br>Aeris Gainsborough &#8211; 69.78% -- 80,305<br><br>Marle &#8211; 30.22% -- 34,779 <br><br>Last round, Aeris didn&#8217;t look <i>too</i>
hot against Marle. It is tough to make any conclusions from the match,
but it was certainly underperforming by the expectations set for her.
Luckily, we&#8217;ll get some idea of where Aeris is looking with this match.
KOS-MOS has been in these contests since 2003 and we have a good enough
read on her to judge Aeris, assuming nothing wacky happens. <br><br>This match won&#8217;t be too interesting to see outside of the percentages. Personally, I&#8217;m hoping that Aeris <i>really</i>
underperforms here so that we can get that Zelda bandwagon growing
larger and larger. It&#8217;s a shame, but this begins another series of
boring female match-ups until we hit the awesome male half. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Aeris Gainsborough<br><br><b>Aitch Emm&#8217;s Prediction:</b> Aeris Gainsborough &#8211; 67% ; KOS-MOS &#8211; 33%<br><br><b>Aitch Emm&#8217;s Vote:</b> Aeris Gainsborough<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>While
Aeris didn't look particularly great against the (admittedly unknown
and untested) Marle last round, most of her Final Fantasy and Kingdom
Hearts buddies are doing just swimmingly. At this point in the contest,
Square has definitely done a good job in keeping up with Nintendo, and
most might even argue that they've proven to be the more impressive
force. Since Aeris is Square and had a role in KHII, she'll obviously
receive some of these nice boostees. Based on the fantastic
performances of her ilk, I still have confidence in Aeris's potential
to be tough competition for Zelda (even though that's not necessarily
what I want).<br><br>KOS-MOS, on the other hand, is completely dead to me. Seriously, <i>Amy Rose</i>?
AMY ROSE?! What the hell is an Amy Rose and why couldn't you double
it?! Your left boob should be able to 70/30 Amy Rose, gawdammit. Luigi
scored exactly 66% on KOS-MOS last year. I expect a refreshed Aeris to
outdo that. Prove me right, flower girl.<br><br>My prediction: Aeris def. KOS-MOS (68-32)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Another match where I only have on&#8230; oh wait, I got <i>both</i> of these two. Oh yeah! I'm so good I amaze myself sometimes.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/18/2006 8:48:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341817246">message detail</a>
 | #116</td></tr>
<tr class="even"><td>
This match? Well, I don't know. I asked KOS-MOS herself about her
chances and she was all like "probability of victory is 0.04%". To
which I replied, "really? I was thinking 0.0397%!". Oh, yeah, she got
all indignant because I underestimated her, but she was impressed that
my margin of error was so low for a "crude human approximation". Now it
was <i>my</i> turn to get indignant. <i>Crude</i>&#8230; ha!<br><br>Okay, there was a point to all this&#8230; KOS-MOS doesn't have a chance here. I know it. She knows it. The crew knows it. We <i>all</i>
know it! The number to look out for, here? 67%. Will Aeris outdo that?
Will she look better than Luigi did? I'm thinking she will, but not by
much. Hopefully, when all is said and done, KOS-MOS will look better
than Marle in the X-Stats! Yes, yes&#8230; it'd be beautiful! *listens to
boos as a result of continued unnecessary cheap shots*<br><br>Oh, fine, you're gonna boo? Well how bout this?  KOS-MOS is gonna lose by less than Marle did&#8230; <i>and</i>&#8230;
after the match, for good measure, she's gonna make Marle a consolation
sandwich. A consolation sandwich that has a 99.68% chance to actually
make Marle feel worse&#8230; <i>yeahh!!!</i><br><br><b>Lopen's Prediction:</b> Aeris with 68.24%<br> <br><br> <br><b>KH&#8217;s Analysis</b><br><br> lol x-stats history<br><br>KOS-MOS<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 36th Place [22.22%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 31st Place [22.60%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 45th Place [19.52%]<br><br>KOS-MOS
laid the lingering doubts that Luigi gave her to rest last round,
absolutely destroying Amy Rose beyond any shadow of a doubt. Yeah,
default votes didn't help Amy out too much here. Unfortunately, now
she's up against a more well-known AND stronger character.<br><br>Aeris Gainsborough<br><br>Summer 2002 Contest<br>Extrapolated Strength --- 12th Place [30.62%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 15th Place [32.81%]<br><br>Aeris
didn't impress *too* much last round, though I'd attribute that more to
CT's strength and the match picture than anything. Or maybe she's lost
a step since 2003? Wouldn't be too shocking, but this match will help
us draw some more conclusions (or, like other matches, prove to be
completely useless).<br><br><i>Notable Releases Since Last Appearance</i><br><br>Aeris Gainsborough: Kingdom Hearts II (PS2)<br>KOS-MOS: Xenosaga III (PS2)<br><br><i>Upcoming Releases</i><br><br>Aeris Gainsborough: N/A<br>KOS-MOS: N/A<br><br>Aeris
doesn't have much of an upper bound to look out for, but I won't feel
very good at all about her over Zelda if she dips below a doubling
(i.e. what Luigi got). KOS-MOS should be stronger than she was last
year, but I don't think she'll be as strong as she was in 2003 and
Aeris has all the intangibles.<br><br>Well, except the match picture. WTF is that thing<br><br>Karma Hunter's Vote: Aeris. It might change once I get a copy of Xenosaga THAT WON'T ****ING FREEZE DURING CUTSCENES<br><br><b>Karma Hunter's Krazy Prediction: Aeris Gainsborough with 70.84%.</b><br> <br>Though
it may just be tranny's insanity channeling through me, I'm going
higher than I'm comfortable in spite of the match picture. Xenosaga is
the spiritual successor to Xenogears, and it's pretty much accepted
that FFVII gave that a SFF beatdown back in the Games Contest. If
there's any significant carryover, it should default to FFVII.<br><br>Or this will make me look crazier than Lopen! HA HA<br><br>Upset Potential: 0%<br><br>I don't believe in TJF *that* much!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/18/2006 8:49:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341817553">message detail</a>
 | #117</td></tr>
<tr class="even"><td>
<b>Guest&#8217;s Analysis</b> - <i>KleenexTissue50</i><br><br>This match
could end up one of two ways. Aeris completely slaughters KOS-MOS,
further proving the fact that FF7 &gt; most in the contests, or KOS-MOS
does surprisingly well, and Aeris looks real bad going into her match
with Zelda. Aeris will win this one for sure, but by how much is what&#8217;s
in question here. Let&#8217;s look at the previous matches of these two,
shall we?<br><br>KOS-MOS - 65.43% - 67068<br>Amy Rose - 34.57%  - 35441<br><br>Aeris Gainsborough 69.78%  - 80305<br>Marle 30.22% - 34779<br><br>Now,
granted this doesn&#8217;t really tell us very much, as there&#8217;s almost no way
to judge the strength of Marle or Amy. The lol x-stats say that 2003
Aeris beats 2005 KOS-MOS by about as much as KOS-MOS beat Amy this
year. 2004&#8217;s KOS-MOS proves to be stronger by about 2%. All things
accounted for, Aeris <i>should</i> get around 64%. However, Xenosaga 3
was released nary 2 months ago. Not only that, but it was very well
received (far better than the abysmal Episode 2, which may explain
KOS-MOS&#8217;s slight drop last year). It&#8217;s fairly safe to say that we&#8217;re
looking at a stronger KOS-MOS than last year. And Aeris&#8217; performance
against Marle wasn&#8217;t exactly spectacular. Not bad, but not quite what
it should be.<br><br>So where the hell am I going with this? I have no
idea. I just thought it&#8217;d be fun to throw some x-stats around and sound
like I know what I&#8217;m talking about. Summary: KOS-MOS will be stronger
than expected and Aeris won&#8217;t do quite as well as she should.<br><br><b>Prediction: Aeris with 60.89%<br>Bracket: Aeris<br>Vote: KOS-MOS</b><br> <br> <br> <br>Crew
Consensus: Another match where the Crew is pretty tight on, while the
Guest is far from the pack. KOS-MOS in the mid-high 60's.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/18/2006 8:50:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341817822">message detail</a>
 | #118</td></tr>
<tr class="even"><td>
Oh, and Yo's pick is now 69%. He e-mailed it to me while I was posting the write-ups.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Zelda vs. Terra - Bracket: <b>Zelda</b> - Vote: <b>Zeldal</b> (36/40)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/18/2006 8:50:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341817835">message detail</a>
 | #119</td></tr>
<tr class="even"><td>
Will my e-mail count?<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/18/2006 8:50:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341817982">message detail</a>
 | #120</td></tr>
<tr class="even"><td>
Well, that answers that.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3151105" class="name">KleenexTissue50</a> |
Posted 10/18/2006 8:51:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341818105">message detail</a>
 | #121</td></tr>
<tr class="even"><td>
Oh man, I'm such a crazy guy.<br>---<br>CB5 Points: <b>37/40</b>, Current Oracle placement: <b>38/163</b><br>Now playing: Okami
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/18/2006 8:51:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341818332">message detail</a>
 | #122</td></tr>
<tr class="even"><td>
I'm still higher, yo <i>!!</i><br><br>*ignores that this may make my fall all the more brutal*<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/18/2006 8:54:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341819084">message detail</a>
 | #123</td></tr>
<tr class="even"><td>
At this point, I think it's illegal for me to get the closest prediction.<br>---<br><i>The Little Mermaid</i> 2-Disc Platinum Edition DVD<br>Coming <b>October 3, 2006</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/18/2006 8:56:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341819628">message detail</a>
 | #124</td></tr>
<tr class="even"><td>
Go Guests!<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=254355" class="name">Lugia2</a> |
Posted 10/18/2006 8:59:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341820351">message detail</a>
 | #125</td></tr>
<tr class="even"><td>Check me on this. Who's the favorite in
Zelda/Aeris? I'm pretty sure I've got the LoZ girl. BSE and all that,
though Gannon doesn't make it look so hot...<br><br><br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/18/2006 8:59:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341820535">message detail</a>
 | #126</td></tr>
<tr class="even"><td>
Uh, after today? I'm not sure if anyone's saying Aeris is the favorite...<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/18/2006 9:00:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341820562">message detail</a>
 | #127</td></tr>
<tr class="even"><td>
I have Aerith, but I am really starting to regret that pick. =/<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=152338" class="name">Lopen</a> |
Posted 10/18/2006 11:03:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341849299">message detail</a>
 | #128</td></tr>
<tr class="even"><td>
You know what sucks?  I was going to drop my prediction like 6% after Leonhart's goading today in the <b>BOLD PREDICTION</b>, but I forgot to.<br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3151105" class="name">KleenexTissue50</a> |
Posted 10/18/2006 11:04:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341849512">message detail</a>
 | #129</td></tr>
<tr class="even"><td>
Who's crazy now <i>!!</i><br>---<br>CB5 Points: <b>39/42</b>, Current Oracle placement: <b>37/163</b><br>Now playing: Okami
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/18/2006 11:09:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341850504">message detail</a>
 | #130</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Sorry, I was too busy watching the METS WIN! to get this in on time.<br><br>Anyway,
Zelda blew her competition away, so now Aeris needs to blow her
competition away as well. KOS-MOS is from the weaker Xenosaga, but a
brand new game may help boost her. But when you're against the main
female from Final Fantasy VII, nothing is going to help you out too
much.<br><br>My vote: KOS-MOS (for you, Notre Game!)<br>My bracket: Aeris<br>My prediction: too late<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 10/18/2006 11:11:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341850896">message detail</a>
 | #131</td></tr>
<tr class="even"><td>
I would consider Tifa to be more of the main female from FFVII. =/<br><br>Oh, and it is quite clear that guests are far superior to actual crew members. =o<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 10/18/2006 11:12:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341851051">message detail</a>
 | #132</td></tr>
<tr class="even"><td>
Oh SNAP, Guests are in first if this holds!<br>---<br>CB06 - Score: <b>38/42 </b>Rank: <b>Tied - 1179th </b>Yesterday's Pick:<b> Zelda</b> <br>Today's Pick: <b>Aeris</b> Tomorrow's Pick: <b>Yuna</b> Losses: <b>Cortana, Ganon, Zero, MC</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=254355" class="name">Lugia2</a> |
Posted 10/19/2006 5:53:20 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341883903">message detail</a>
 | #133</td></tr>
<tr class="even"><td>
I guess the guests have redeemed themselves now for some of their crappy picks...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3052691" class="name">satai_delenn</a> |
Posted 10/19/2006 10:07:33 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341900259">message detail</a>
 | #134</td></tr>
<tr class="even"><td>
*praises Lopen's unnecessary cheap shots*<br><br>...what?<br><br>So...does Aeris get anti-voted? I know a lot of people dislike her (even while she's very popular), but enough to anti-vote her?<br>---<br>Beating
FE5 and FE6 hard mode is a true test of manhood in the Japanese
culture. However. This explains why they have a lot of effeminate men.
~Sytha
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 10/19/2006 10:12:12 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341900764">message detail</a>
 | #135</td></tr>
<tr class="even"><td>
I anti-voted her.<br><br>Although that's probably because she's my least favourite character in her game.<br><br><br><b>TuRtLe</b><br>~~~<br>"Like Darth Maul, the bastard child of Michael Flatley and Hellboy"- trancer1
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2665492" class="name">XIII_rocks</a> |
Posted 10/19/2006 10:16:11 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341901181">message detail</a>
 | #136</td></tr>
<tr class="even"><td>
<i>I guess the guests have redeemed themselves now for some of their crappy picks...</i><br><br>*cough* Y halo thar 3rd place. &gt;_&gt;<br>---<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738</a> Sign plz<br><b>AC2K6 Score</b>: 40/42 <b>Today:</b> Aeris
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/19/2006 1:50:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341927921">message detail</a>
 | #137</td></tr>
<tr class="even"><td>
<i>*cough* Y halo thar 3rd place. &gt;_&gt;</i><br><br>? Guests are tied for 1st right now, and if this match stays under 63.43 they go in by themselves.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2665492" class="name">XIII_rocks</a> |
Posted 10/19/2006 3:49:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341950946">message detail</a>
 | #138</td></tr>
<tr class="even"><td>I was talking about my personal performance, to
seperate myself from the apparently "crappy" picks. &gt;_&gt; But yeah,
go guests! LOL CREW OWNED &lt;_&lt;<br>---<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738" title="Linkification: http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738">http://boards.gamefaqs.com/gfaqs9/genmessage.php?board=7&amp;topic=22242738</a> Sign plz<br><b>AC2K6 Score</b>: 40/42 <b>Today:</b> Aeris
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=1009378" class="name">The Real Truth</a> |
Posted 10/19/2006 3:53:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341951785">message detail</a>
 | #139</td></tr>
<tr class="even"><td>
Aeris still stands a chance against Zelda, though this match doesn't really help.<br><br>Xenosaga
3 was supposed to actually be a good game and KOS-MOS has massive boobs
in the picture. Luigi got what? 66%? against KOS-MOS last year. The
match is in favor of Zelda and my bracket is already screwed anyway,
but I still say Aeris has a shot.<br>---<br><b>Nominate Barret Wallace for SC2k7, you know you want to</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 10/19/2006 3:55:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341952219">message detail</a>
 | #140</td></tr>
<tr class="even"><td>
Zelda certainly deserves the status of favorite, but I don't think you
can make any guarantees off of an obvious overperformance against
Terra. Really, she earns status more because Aeris has been
underwhelming.<br><br>Really though, this lines up fairly well with Aeris 2003 vs. KOS-MOS 2004.<br>---<br><b>Squall Leonhart's Road to the Character Battle V Championship</b>:<br><i>Round 2</i>: (1) Solid Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/19/2006 4:27:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341959379">message detail</a>
 | #141</td></tr>
<tr class="even"><td>
Zelda......................79.45% 92826<br>Terra Branford........20.55% 24005<br>TOTAL VOTES.....................116831<br><br>92.76% of the brackets predicted this match correctly.<br><br>More
Zelda domination in Round 2. Zelda almost does as well as Samus did on
her opponent, in the match and bracket support! Good signs for this
Princess. I smell an overperformance though, woo Zelda boost and
Terra/Kerrigan drop.<br><br>Today, KOS-MOS is doing well against Aeris.<br><br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe) - 7<br>KH - 7<br>Lopen - 7<br>Moltar - 6<br>Ulti - 5<br>HM - 5<br>Yoblazer - 2<br><br>With the high pick, the Guest spot gets another point.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>KOS-MOS vs. Aeris - Bracket: <b>Aeris</b> - Vote: <b>KOS-MOS</b> (38/42)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3605206" class="name">wavedash101</a> |
Posted 10/19/2006 4:30:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341960027">message detail</a>
 | #142</td></tr>
<tr class="even"><td>
Woo go B8!!!!<br>---<br><b>Our shields cannot withstand wavedashing of this magnitude!</b><br>Board 8's Unofficial Master of the Phoenix Down
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 10/19/2006 7:09:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341998144">message detail</a>
 | #143</td></tr>
<tr class="even"><td>
I wonder if the guest will nail the percentage... 1 percent off in 4 hours is about right.<br>---<br>CB06 - Score: <b>38/42 </b>Rank: <b>Tied - 1179th </b>Yesterday's Pick:<b> Zelda</b> <br>Today's Pick: <b>Aeris</b> Tomorrow's Pick: <b>Yuna</b> Losses: <b>Cortana, Ganon, Zero, MC</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/19/2006 7:12:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341998835">message detail</a>
 | #144</td></tr>
<tr class="even"><td>
Just three more days, gentlemen. Three more days.<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/19/2006 7:13:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341999047">message detail</a>
 | #145</td></tr>
<tr class="even"><td>
Until I have to watch 2 of my 4 favorite characters face off? And one get blown up? Horrible I know...<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/19/2006 7:14:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341999253">message detail</a>
 | #146</td></tr>
<tr class="even"><td>
Two of your four? Ha, I got you beat by one! <br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/19/2006 7:14:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=341999365">message detail</a>
 | #147</td></tr>
<tr class="even"><td>
I actually meant of 3...<br><br>Snake &gt; Prince &gt; Squall. &gt;_&gt;<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3478664" class="name">SquallidSnake</a> |
Posted 10/19/2006 7:17:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342000143">message detail</a>
 | #148</td></tr>
<tr class="even"><td>
Squall &gt; *censors out this name so as not to get cursed out by EC* &gt; Snake<br>---<br>Some stories can't be told by words. Some legends are meant to die.<br>October 22 - Internal war rages between the Squallid and the Snake
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=3786232" class="name">EvenMyROgetsB7</a> |
Posted 10/19/2006 7:18:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342000406">message detail</a>
 | #149</td></tr>
<tr class="even"><td>
Tidus sucks nuts.<br><br>&gt;_&gt;<br><br>---<br>I'm so hardcore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31144759&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/19/2006 9:03:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31144759&amp;message=342025528">message detail</a>
 | #150</td></tr>
<tr class="even"><td>
Next page.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=1">2</a></li>
<li>3</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31144759&amp;page=9">10</a></li>
</ul>
</div>


</div>
<img src="genmessage3_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage3_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31144759&amp;page=2" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage3_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>