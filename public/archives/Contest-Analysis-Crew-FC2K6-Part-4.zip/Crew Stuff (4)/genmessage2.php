<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage2_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage2_files/nogs.css"></head><body linkifytime="200" linkified="5" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage2_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage2_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31382187%26page%3D1"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div class="ad" style="text-align: center;">
<div style="text-align: center;"><img src="genmessage2_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div>
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage2_files/a.xhtml" marginwidth="0" marginheight="0" hspace="0" vspace="0" bordercolor="#000000" frameborder="0" height="90" scrolling="no" width="728">
&lt;SCRIPT language='JavaScript1.1'
SRC="http://ad.doubleclick.net/adj/N3340.CNET/B2067766.29;abr=!ie;sz=728x90;click0=http://adlog.com.com/adlog/e/r=10153&amp;s=700192&amp;t=2006.11.13.16.13.08&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;e=&amp;rqid=00c17-gne-ad3455078112F6E4A3&amp;event=58/;ord=2006.11.13.16.13.08?"&gt;
&lt;/SCRIPT&gt;
&lt;NOSCRIPT&gt;
&lt;A
href="http://adlog.com.com/adlog/e/r=10153&amp;s=700192&amp;t=2006.11.13.16.13.08&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;e=&amp;rqid=00c17-gne-ad3455078112F6E4A3&amp;event=58/http://ad.doubleclick.net/jump/N3340.CNET/B2067766.29;abr=!ie4;abr=!ie5;sz=728x90;ord=2006.11.13.16.13.08?"&gt;
&lt;IMG
SRC="http://ad.doubleclick.net/ad/N3340.CNET/B2067766.29;abr=!ie4;abr=!ie5;sz=728x90;ord=2006.11.13.16.13.08?"
BORDER=0 WIDTH=728 HEIGHT=90 ALT="Click Here"&gt;&lt;/A&gt;
&lt;/NOSCRIPT&gt;
</iframe>
<img src="genmessage2_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 4
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;page=1">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31382187" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">First Page</a> |
Page 2 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=2">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/28/2006 9:50:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343893128">message detail</a>
 | #051</td></tr>
<tr class="even"><td>
I'll take it... I have a pretty good range to work with!<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/28/2006 9:51:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343893330">message detail</a>
 | #052</td></tr>
<tr class="even"><td>
Holy crap, people, I thought <i>I</i> was going to be high. <br><br>---<br>"Let's face it: the princess Zelda has always been a symbol of sexual desire."
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/28/2006 9:52:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343893455">message detail</a>
 | #053</td></tr>
<tr class="even"><td>
I wish I were high... :(<br><br>darn you friends<br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 10/28/2006 9:54:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343893890">message detail</a>
 | #054</td></tr>
<tr class="even"><td>
59.97-62.47<br><br>COME ON BABY<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/28/2006 9:59:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343895043">message detail</a>
 | #055</td></tr>
<tr class="even"><td>
Oh god. My oracle pick is closest to Lopen. =/<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=640243" class="name">Big Bob</a> |
Posted 10/28/2006 10:13:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343897858">message detail</a>
 | #056</td></tr>
<tr class="even"><td>
<i>Big Bob's completely biased and nonsensical analysis</i><br><br>Alright, I'm a little pissed at Mega Man X7 for not letting me do ANYTHING, but here it goes.<br><br>Auron
was strong BEFORE KHII, and now that Kairi and Riku have been revealed
to have strength (plus Sora against a strong Gordon Freeman), it's time
for Auron to show his stuff. Sub-Zero beat Master Chief, but now he has
everything working against him. No anti-votes, no picture advantage,
and no bracket support. He will lose all his strength to the dead guy.<br><br>...Erm, wait.  They're both dead.  Nevermind.<br><br>Bob's Prediction: <b>Auron with 80%</b><br>---<br>Gordon
Freeman finally won, but somehow, the universe survived... thus
allowing me to tell said universe about how I was owned by <b>NClark128</b>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 10/29/2006 12:53:46 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343927520">message detail</a>
 | #057</td></tr>
<tr class="even"><td>
All I care about is Subby doing better than Scorpion. **** Scorpion.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), Castlevania: LoI, MMZX
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=1502018" class="name">ShatteredElysium</a> |
Posted 10/29/2006 2:41:00 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343944107">message detail</a>
 | #058</td></tr>
<tr class="even"><td>
Sent my analysis in Moltar.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/29/2006 2:45:16 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343944376">message detail</a>
 | #059</td></tr>
<tr class="even"><td>
Maybe it's all the alcohol I've had tonight, but I lauged out loud at the Pat Riley comment, EC.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 10/29/2006 3:15:56 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343946167">message detail</a>
 | #060</td></tr>
<tr class="even"><td>
[This message was deleted at the request of the original poster]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 10/29/2006 3:16:24 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343946197">message detail</a>
 | #061</td></tr>
<tr class="even"><td>
Holy crap, .01% off Crono's percentage, KH. Good job!<br>---<br>CB06 - Score: <b>56/62 </b>Rank: <b>Tied - 546th </b>Yesterday's Pick:<b> Crono</b> <br>Today's Pick: <b>Auron</b> Tomorrow's Pick: <b>Samus</b> Losses: <b>Cortana, Ganon, Zero, MC, Kirby</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=254355" class="name">Lugia2</a> |
Posted 10/29/2006 5:30:36 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343953301">message detail</a>
 | #062</td></tr>
<tr class="even"><td>
<i>EvenMyROgetsB7<br>Posted: 10/28/2006 12:43:57 PM ATTN: Lugia2, I
would totally kill to do the Yuna/Chun-Li write-up, if you want to
switch with me for Auron/Subby, I would love you forever, or if there's
anything else I could do to make you change your mind. Having sex with
animals is an option.</i><br><br>Sorry EC.  I was gone yesterday, so I wasn't able to make much of a decision.  If I was around, I would have made the switch.<br><br>But
now...well...You see, I've wanted to do an analysis for a long time
now, and if I lose Yuna/Chunners write-up (you don't have one anymore),
I doubt I'll get an analysis this contest. Sorry.<br><br>...On that subject, I need Moltar's e-mail.  Moltar, if you don't mind, could I have it please?<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=683142" class="name">transience</a> |
Posted 10/29/2006 5:35:51 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343953533">message detail</a>
 | #063</td></tr>
<tr class="even"><td>
<a class="linkification-ext" href="mailto:mastermoltar@gmail.com" title="Linkification: mailto:mastermoltar@gmail.com">mastermoltar@gmail.com</a><br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/29/2006 6:18:15 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343955112">message detail</a>
 | #064</td></tr>
<tr class="even"><td>
<i>From DaruniaTheGoron</i><br><i>Holy crap, .01% off Crono's percentage, KH. Good job!</i><br><br>I was .02% =/<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=683142" class="name">transience</a> |
Posted 10/29/2006 6:22:43 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343955242">message detail</a>
 | #065</td></tr>
<tr class="even"><td>
and these are some pretty high predictions today.. it's like everyone
wanted to make a bold prediction and went high. well except Lopen, but
Sub-Zero beat his dear Master Chief so that's understandable.<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/29/2006 8:51:34 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343967276">message detail</a>
 | #066</td></tr>
<tr class="even"><td>
I didn't think mine was high at all... I put Sub at 25% on BL, and
boosted up Auron a little more than 2%, thanks to Samus being
underrated! I just hope the % stays in my range for the rest of the
match.<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=683142" class="name">transience</a> |
Posted 10/29/2006 8:54:01 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343967581">message detail</a>
 | #067</td></tr>
<tr class="even"><td>
nah, yours was what I would think consensus to be, 60-62%. 64-65 by the majority was just surprising.<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/29/2006 8:56:09 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343967838">message detail</a>
 | #068</td></tr>
<tr class="even"><td>
Well to be fair... I actually came out with 61.9% for my prediction,
but boosted it up barely above 62 just to be safe if anyone went with
62 even. &gt;_&gt;<br><br>So I had more faith in Auron doing better here than worse, even though it looks like it's gonna be slightly worse.<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=683142" class="name">transience</a> |
Posted 10/29/2006 8:57:48 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343968037">message detail</a>
 | #069</td></tr>
<tr class="even"><td>
it's still an easy point for you - I'm not giving you credit anymore ('cept for Leon), I'm blaming your competition!<br><br>OH WHAT NOW ANALYSTS<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 10/29/2006 9:29:26 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343971850">message detail</a>
 | #070</td></tr>
<tr class="even"><td>
Sub-Zero's not dead, BB. You're probably thinking of Scorpion.<br>---<br>This was Ed Bellis, servant to the mighty Guru <b>Z1mZum</b>. Congrats, buddy!<br><a class="linkification-ext" href="http://www.thepetitionsite.com/takeaction/754046421" title="Linkification: http://www.thepetitionsite.com/takeaction/754046421">http://www.thepetitionsite.com/takeaction/754046421</a> - For the children.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/29/2006 9:30:51 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343972036">message detail</a>
 | #071</td></tr>
<tr class="even"><td>
3/3 if this baby holds up! I demand a spot on the crew for the next character battle!<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 10/29/2006 11:16:50 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=343989124">message detail</a>
 | #072</td></tr>
<tr class="even"><td>
God dammit.... stop dropping Auron!<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=152338" class="name">Lopen</a> |
Posted 10/29/2006 3:16:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344041653">message detail</a>
 | #073</td></tr>
<tr class="even"><td>
<i>it's still an easy point for you - I'm not giving you credit anymore ('cept for Leon), I'm blaming your competition!</i><br><br><i>Not so fast,</i> tranny!<br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/29/2006 3:17:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344041964">message detail</a>
 | #074</td></tr>
<tr class="even"><td>
I like how you say that just as Auron is looking to increase his %!<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/29/2006 3:59:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344051500">message detail</a>
 | #075</td></tr>
<tr class="even"><td>
The point currently belongs to Lopen. Auron needs to hit or exceed 59.97% for it to be otherwise.<br>---<br><i>I don't know when, I don't know how, but I know something starting right now... <br>Watch and you'll see, someday I'll be... <b>part of your world!</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/29/2006 4:41:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344061037">message detail</a>
 | #076</td></tr>
<tr class="even"><td>
grr... If I had stuck to my actual prediction of 61.9 I'd be looking
better now, not great, but better. This is what I get for changing my
prediction for what I believe other predictions might be.<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/29/2006 4:44:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344061728">message detail</a>
 | #077</td></tr>
<tr class="even"><td>
You'd be screwed if mine counted.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 10/29/2006 4:45:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344061894">message detail</a>
 | #078</td></tr>
<tr class="even"><td>
Y'know, I was just browsing through the first Analysis Crew topic on
Ngamer's site. I find it remarkable that thing went the entire contest
without hitting 500. Most non-stats people didn't seem to care less -
and that was probably one of the most interesting contests, too! The
writeups seemed different, too, and the Crew (Moltar, Ulti, Dp) had a
real nice dynamic. I was just surprised to find that it really didn't
take off all too well at first.<br>---<br>This was Ed Bellis, servant to the mighty Guru <b>Z1mZum</b>. Congrats, buddy!<br><a class="linkification-ext" href="http://www.thepetitionsite.com/takeaction/754046421" title="Linkification: http://www.thepetitionsite.com/takeaction/754046421">http://www.thepetitionsite.com/takeaction/754046421</a> - For the children.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/29/2006 4:54:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344064153">message detail</a>
 | #079</td></tr>
<tr class="even"><td>
Ahh yes, good times.  I'm gonna have to go to that site and reminisce as well.  Hey look, it's my printable bracket!<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/29/2006 4:57:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344064767">message detail</a>
 | #080</td></tr>
<tr class="even"><td>
Whoa, we had V9 skin back then? It feels like we didn't have it for that long....damn, time flies.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=683142" class="name">transience</a> |
Posted 10/29/2006 4:59:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344065334">message detail</a>
 | #081</td></tr>
<tr class="even"><td>
got introduced during Spring 2004, yeah?<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/29/2006 5:08:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344067506">message detail</a>
 | #082</td></tr>
<tr class="even"><td>
ATTN: AURON JEEZE YOU BETTER NOT GIVE THIS TO LOPEN OR I'LL GRRR DARN YOU.<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 10/29/2006 5:10:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344067913">message detail</a>
 | #083</td></tr>
<tr class="even"><td>
Yeah, Spring '04. Forsaken was one of the original Crew too, but I think he dropped out after a few matches.<br>---<br>This was Ed Bellis, servant to the mighty Guru <b>Z1mZum</b>. Congrats, buddy!<br><a class="linkification-ext" href="http://www.thepetitionsite.com/takeaction/754046421" title="Linkification: http://www.thepetitionsite.com/takeaction/754046421">http://www.thepetitionsite.com/takeaction/754046421</a> - For the children.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/29/2006 5:13:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344068642">message detail</a>
 | #084</td></tr>
<tr class="even"><td>
<i>Dp&#8217;s Analysis<br><br>It&#8217;s always tough predicting the 8 vs. 9 match
up. Sometimes it might just be easier to flip a coin to predict the
winner. This is one of those toss-ups. Like Metal Gear, Metroid was
another game that didn&#8217;t hit it big until it&#8217;s later games. It also
wasn&#8217;t as good of a game and it&#8217;s later versions. But Metroid may be
able to pick up some votes because of its later games.<br><br>Pac-Man
was a simple game. Move a yellow dot along the screen grabbing tiny
white dots while avoiding the ghosts. But back in its day, simple was
good enough. And man, this game was addictive. Many quarters were
wasted for some excitement at the arcade. The people loved it, and it
paved the way for gaming.<br><br>This is a tough match to predict here. I see Pac-Man as the better game here, but if Metroid can get enough<br>supporters
of the entire series itself, then Metroid could have a chance. But I
think too many people who are just fans of the later part of the series
will realize that this is Pac-Man, a great game of it&#8217;s time, and
Metroid wasn&#8217;t. Metroid fans will back Super Metroid and Metroid Prime,
but I think they&#8217;ll let Pac-Man shine for once, like it should. I see
Pac-Man pulling the &#8220;upset&#8221; here.<br><br>Dp's Prediction: Pac-Man over Metroid 54%-46%</i><br><br>Can I go back in time and slap myself, please?<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=152338" class="name">Lopen</a> |
Posted 10/29/2006 5:13:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344068708">message detail</a>
 | #085</td></tr>
<tr class="even"><td>
<b>Hooohahahahaha!</b>  <i>Outstanding!</i>  Your 3-0 shall be denied, EC, oh yes!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/29/2006 5:15:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344069129">message detail</a>
 | #086</td></tr>
<tr class="even"><td>
I could've sworn MWIS was an original member, too, and dropped out like Forsaken.  I guess he dropped out before it started?<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3201793" class="name">Ed Bellis</a> |
Posted 10/29/2006 5:16:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344069456">message detail</a>
 | #087</td></tr>
<tr class="even"><td>
Dunno about that one... you were actually there. I'm just watching from the future! =P<br>---<br>This was Ed Bellis, servant to the mighty Guru <b>Z1mZum</b>. Congrats, buddy!<br><a class="linkification-ext" href="http://www.thepetitionsite.com/takeaction/754046421" title="Linkification: http://www.thepetitionsite.com/takeaction/754046421">http://www.thepetitionsite.com/takeaction/754046421</a> - For the children.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/29/2006 5:28:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344072283">message detail</a>
 | #088</td></tr>
<tr class="even"><td>
<i>DpObliVion&#8217;s prediction is: Donkey Kong over Duck Hunt 62%-38%</i><br><br>Hmm, I guess I was pretty wild and terrible at predicting percentages back then, too.  Definitely not my strength....<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/29/2006 6:01:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344080388">message detail</a>
 | #089</td></tr>
<tr class="even"><td>
Whoa, I totally forgot all this time......Ulti had his famous StarCraft &gt; Halo analysis posted on my birthday. Cool.<br><br>Speaking of Ulti, it's fun to see your obsessive use of ` instead of ' from back then.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/29/2006 6:14:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344083630">message detail</a>
 | #090</td></tr>
<tr class="even"><td>
I need it to go up .2 in the remaining 4.75 hours. It could happen dammit! ;_;<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/29/2006 6:33:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344088358">message detail</a>
 | #091</td></tr>
<tr class="even"><td>
Crono.......................57.44% 68821<br>Bowser.....................42.56% 50986<br>TOTAL VOTES....................119807<br><br>63.73% of the brackets predicted this match correctly.<br><br>Oh
man, Bowser looked horrible at first, but a stellar morning vote
allowed him to end up looking much more respectable. I mean, it does
show that he was overrated in 2005, but not by that much. Also,
Crono-supporters with him winning look pretty good right about now.<br><br>Today, Auron is winning the match, but Sub is doing respectably.<br><br>KH - 9<br>HM - 8<br>Moltar - 8<br>Lopen - 8<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Ulti - 6<br>Yoblazer - 3<br><br>KH only .01% off...<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Auron vs. Sub-Zero- Bracket: <b>Auron</b> - Vote: <b>Auron</b> (54/62)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/29/2006 7:14:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344098822">message detail</a>
 | #092</td></tr>
<tr class="even"><td>
<i>Remember: Mass Characters &gt; Mass Carriers.</i><br><br>Haha, that
was a great tagline by me. Just got through the old topic, so this will
be my last post about it. That was fun, damn, I had some pretty big
write-ups for that. And what the hell, we go through the whole thing
and then Ulti forgets to do his write-up for the Final Match.<br><br>Moltar: 20<br>DpObliVion: 13<br>UltimaterializerX: 29<br>Forsaken: 1<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/29/2006 8:37:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344121315">message detail</a>
 | #093</td></tr>
<tr class="even"><td>
<b>Spazer Division:</b> <i>Round 3 - Match 49</i> &#8211; (1)Samus vs. (3)Rikku <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Samus</b><br>Round 1 &#8211; 81.85% vs. Nidoran F (18.15%)<br>Round 2 &#8211; 79.78% vs. Ada (20.22%)<br><br>Ouch, Samus makes Ada look almost as bad as Nidoran F.<br><br><b>Rikku</b><br>Round 1 &#8211; 75.00% vs. Lenneth (25.00%)<br>Round 2 &#8211; 58.28% vs. Kairi (41.72%)<br><br>Well&#8230;Kairi did a lot better than I expected&#8230;Hmmph.<br><br>Samus&#8217;s third opponent on her &#8220;Path to Victory&#8221; in the female bracket is her toughest yet&#8230;<br><br>What?
I&#8217;m not lying! Sure, Rikku is nowhere near Samus&#8217;s league. I mean, she
did get 45% on Ryu, but this was obviously the weaker Ryu that appeared
in 2005. Hmm&#8230;let&#8217;s see how this match would have gone in 2005, and work
from there.<br><br>*5 hours later*<br><br>Alright, after slaving over
those x-stats, I&#8217;ve finally come to the conclusion that Samus would win
with 68.16%! Now, what have they had since then&#8230;Rikku had a small role
in KH2, but Samus has her amazing female bracket winner support. Then
again, I wouldn&#8217;t put Rikku below Frog, so this could be another match
where the result is pretty close to the X-Stats prediction. Oh, and let
me make one more quick calculation&#8230;<br><br>*5 more hours later*<br><br>Ooh, seems like Kairi would end up nearly getting tripled by Samus. Now THAT&#8217;S something I want to see!<br><br>&#8230;wait, there&#8217;s a calculator that does all these calculations for you? Curse you, technology!<br><br><b>Moltar&#8217;s Bracket Says:</b> Samus will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Samus: 69% - Rikku: 31%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br> <br>I really see no reason for this match not to follow last year's stats. BOOOOOOOOOO to the return of the female bracket.<br><br>Prediction: Samus with 68.16%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br><b>Samus Aran</b><br><br><i>Previous Matches:</i><br><br>Samus Aran &#8211; 81.85% -- 95,533<br><br>Nidoran F &#8211; 18.15% -- 21,180 <br><br>Samus Aran &#8211; 79.78% -- 98,352<br><br>Ada Wong &#8211; 20.22% -- 24,923 <br><br><b>Rikku</b><br><br><i>Previous Matches:</i><br><br>Rikku &#8211; 75% -- 83,124<br><br>Lenneth Valkyrie &#8211; 25% -- 27,704 <br><br>Rikku &#8211; 58.28% -- 75,494<br><br>Kairi &#8211; 41.72% -- 54,043 <br><br>Samus
came out very strong last round by demolishing Ada Wong. Most of us had
expected that the match wouldn&#8217;t be close, but Samus beating Ada nearly
as bad as Nidoran F surely reassured a lot of people who chose Samus to
win it all. Rikku put up a rather disappointing performance against
Kairi by not even managing to break 60%. Of course, it&#8217;s tough to say
just how weak of a performance it looked given that Kairi was untested.
<br><br>This match should tell us <i>something</i> about other
matches&#8230;but I&#8217;m not entirely sure what. Samus is expected to get about
68% in this match and if she somehow manages to fail to meet that &#8211; or
worse, a doubling &#8211; the upset alarms may be sounding for her match
against Zelda (WOO), but I&#8217;m not banking on it. <br><br>But, after the
disappointing showing from the Dream Division so far, or at least in
everyone&#8217;s case except Mega Man, this match help to continue shedding
more light on what happened there. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Samus Aran<br><br><b>Aitch Emm&#8217;s Prediction:</b> Samus Aran &#8211; 70.5% ; Rikku &#8211; 29.5%<br><br><b>Aitch Emm&#8217;s Vote:</b> Samus Aran <br> <br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>I
watched Samus hit 80% on Ada Wong. Then I watched Rikku barely hit 58%
against Kairi. Now I'm wondering how in the heck Rikku is going to
avoid coming out of this in an ambulance. The sad truth (for her and
her fans) is this: she won't.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/29/2006 8:37:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344121534">message detail</a>
 | #094</td></tr>
<tr class="even"><td>
Statistically, Rikku would need to beat Ada Wong with 66.2% of the vote to even hit <i>30%</i>
against Samus. Doesn't seem like such an attainable goal to me,
especially when you take her very poor performance against Kairi into
account. Historically, Samus has been very unlucky as of late. Her last
three matches prior to the 80% clinic on Ada were against a big name <b>Nintendo</b> villain, a <b>Nintendo</b> icon, and a <b>Nintendo</b>
joke entry. We all know Samus does her worst when up against other
Nintendo characters, and I believe many of us have been unfairly
underestimating her because of these recent matches without considering
who she was against and why she didn't perform up to snuff. Well, Rikku
sure isn't Nintendo, and it's about time Samus once again reminded all
of us just who the hell she was.<br><br>I completely expect Samus to
finish around the 70% mark in this match. In fact, if Rikku performs
well enough to escape the doubling, I'll burn my copy of The Little
Mermaid.<br><br>My prediction: Samus Aran def. Rikku (71-29)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Well, when the contest came out, I thought Samus lost a step. Nidoran F? Not 90%? <i>Nonsense!</i>
But then in round 2, she clobbers Ada Wong and makes me think she
hasn't lost a step at all. So hey, what does that mean? That means
Rikku doesn't have a chance, that means Samus is gonna have it nice and
easy? How easy?<br><br><b>Rikku:</b> Hey, Samie, let's dance!<br><br><b>Samus:</b> &#8230;<br><br><b>Rikku:</b> C'mon, pleeeeaaassseee? *puppy dog look*<br><br>*Samus blows Rikku's head off with a Super Missile*<br><br>Cold
hearted bounty hunting at its finest. Oh, don't worry. Tidus will cast
Life 2 on Rikku! We don't do casualties in this contest, that would be
uncivilized!<br><br><b>Lopen's prediction:</b> Samus with 66.65%<br><br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br>Samus Aran<br><br>Summer 2002 Contest<br>Extrapolated Strength --- 4th Place [41.07%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 7th Place [36.72%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 4th Place [39.50%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 5th Place [38.21%]<br><br>Back
to the female half. You can tell how excited I am for this, seeing as
how the thing that makes me happiest is no particular match, but that
the sprite round isn't going to be in Round 4 this year. Oh, um, Samus
wins.<br><br>Rikku<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 30th Place [24.33%]<br><br>Rikku struggles against Kairi. Not exactly good when your next round opponent is...Samus? Oh, dear...<br><br><i>Notable Releases Since Last Appearance</i><br><br>Samus Aran: Metroid Prime: Hunters (DS), Metroid Prime Pinball (DS), Super Smash Brothers Brawl Trailer (lol internet) <br>Rikku: Kingdom Hearts II (PS2)<br><br><i>Upcoming Releases</i><br><br>Samus Aran: Metroid Prime 3: Corruption (WII), Super Smash Brothers Brawl (WII)<br>Rikku: N/A<br><br>Another
match where the percentage is all that matters. In any case, Samus has
looked incredibly dominating and the Dream Division has faltered at
almost every chance it's had. The only saving grace for Rikku is that
she was behind Ryu, who impressed like crazy against Mega Man. But I'm
starting to think that was Mega Man's fault, hence, Rikku gets
destroyed. Betcha didn't see that one coming!<br><br>Karma Hunter's Vote: Rikku. blah blah personality &gt; Samus blah blah<br><br><b>Karma Hunter's Krazy Prediction: Samus Aran with 71.46% .</b><br><br>Frog &gt; Rikku? Yeah, ouch.<br><br>Upset Potential: 0%<br><br>Rikku isn't affiliated with Nintendo in the slightest! She has no chance here!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/29/2006 8:38:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344121759">message detail</a>
 | #095</td></tr>
<tr class="even"><td>
<b>Guest&#8217;s Analysis</b> - <i>ShatteredElysium</i><br><br>Samus Aran <br>Previous Matches <br>1st Round: (8) Nidoran F  - 81.85% (95533) <br>2nd Round: (4) Ada Wong - 79.78% (98352) <br> <br>Rikku <br>Previous Matches <br>1st Round: (6) Lenneth Valkyrie - 75% (83124) <br>2nd Round: (2) Kairi &#8211; 58.28% (75494) <br> <br>Similar Past Opponents <br>Ryu (Street Fighter) <br>Samus 2002 - 57.85% (39293) <br>Rikku 2005 &#8211; 44.28% (47054) <br> <br>Lol X-Stats <br>Samus 68.16% (65,749) <br>Rikku 31.82% (30,717) <br> <br> <br>So
in the first match of round three, we have statistically the strongest
female character to ever grace these contests squaring off against one
of the many Final Fantasy characters that gain entry into this contest.
<br> <br>I don&#8217;t think that Rikku was given a fair chance to prove
herself in the contest last year, coming up against Ryu in round one. I
personally felt that she was one of a few Final Fantasy characters that
had the potential to upset a few brackets. This year she has proven to
be a mid-carder with wins over Lenneth and Kairi. Whilst neither are
exactly monsters, she has struggled with neither. This is her first
real test and it couldn&#8217;t get much sterner than this. <br> <br>We have
to look at facts here. Rikku has beaten two contest debutants whilst
Samus is a noble nine members and as such has never lost to a character
outside of the noble nine. In fact, only three character outside the
noble nine have managed to break 40% on Samus and they are Ryu (2002),
Squall (2003) and Ganondorf (2005). There is no question over who is
going to win this match because Samus is clearly going to run away with
it. The question is by how much. <br> <br>The only opponent they have
shared is Ryu but I really don&#8217;t like using 2002 statistics. X-stats
say that Samus is going to win with 68.16% if both characters have
remained constant. I personally think they&#8217;ve both received small
boosts but neither has come up against opposition where it could be
accurately measured. Ganondorf only just managed to scrape in with a
post 40% score last year and Rikku is nowhere near Ganon&#8217;s strength so
she isn&#8217;t getting near that 40 barrier. I think 68% is slightly too
high though and we&#8217;re looking more around the 65% mark. I&#8217;m going for a
victory that would be Samus&#8217;s most resounding third round victory but
not by much. <br> <br>Samus 66.2% <br>Rikku 33.8%<br><br> <br> <br>Crew Consensus: Samus has a bit of a range to work with, but it's unanimous that Rikku has no chance here.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=640243" class="name">Big Bob</a> |
Posted 10/29/2006 8:41:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344122538">message detail</a>
 | #096</td></tr>
<tr class="even"><td>
<b><i>Big Bob's completely biased and nonsensical analysis</i></b><br><br>Doing
these analysises (did I spell that right?) aren't fun when the match is
going to go exactly the way you want it to anyway. I like Samus and I
like Rikku, but I want to see Samus blow the hell out of something. But
not too badly.<br><br>Bob's Prediction: <b>Samus with 70%</b><br>---<br>Gordon
Freeman finally won, but somehow, the universe survived... thus
allowing me to tell said universe about how I was owned by <b>NClark128</b>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=683142" class="name">transience</a> |
Posted 10/29/2006 8:44:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344123240">message detail</a>
 | #097</td></tr>
<tr class="even"><td>
high predictions for Samus.. or maybe people are down on Rikku?<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 10/29/2006 8:45:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344123697">message detail</a>
 | #098</td></tr>
<tr class="even"><td>
Combination of both, I'd wager. People went low for Ada last time
because of how Leon impressed (and her destruction of Jade), but she
ended up getting totally trashed. <br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/29/2006 8:48:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344124453">message detail</a>
 | #099</td></tr>
<tr class="even"><td>
Eh, she was projected to get 68.16% on Rikku last year. So they aren't really <i>that</i> high.<br><br>---<br>"Let's face it: the princess Zelda has always been a symbol of sexual desire."
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/29/2006 8:50:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344124934">message detail</a>
 | #100</td></tr>
<tr class="even"><td>
Plus the "Rikku was overrated" evidence is piling up, unless Kairi
really is that strong (and looking at Axel, I wouldn't be too
surprised)...<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Auron vs. Sub-Zero- Bracket: <b>Auron</b> - Vote: <b>Auron</b> (54/62)
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">1</a></li>
<li>2</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=9">10</a></li>
</ul>
</div>


</div>
<img src="genmessage2_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage2_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31382187&amp;page=1" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage2_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>