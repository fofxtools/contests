<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage9_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage9_files/nogs.css"></head><body linkifytime="170" linkified="2" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage9_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage9_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31382187%26page%3D8"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div class="ad" style="text-align: center;">
<div style="text-align: center;"><img src="genmessage9_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage9_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage9_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 4
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;page=8">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31382187" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=7">Previous Page</a> |
Page 9 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=254355" class="name">Lugia2</a> |
Posted 11/10/2006 5:18:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346710728">message detail</a>
 | #401</td></tr>
<tr class="even"><td>
<i>*Rips up X-stats*<br><br>What, the stats that had Crono projected to win with 51.72% against Sonic? Yeah, they totally failed us here.</i><br><br>Your
attempt at sarcasm merely confirms what I meant. That kind of change
means thousands in votes. Besides, that wasn't the ONLY thing
invalidated this contest...Just ask guys like Magus, Megs, Samus (well,
if you don't believe the suit theory), Tifa, Bowser (who, due to these
new stats, may end up destroying Megs for some reason), Leon...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=152338" class="name">Lopen</a> |
Posted 11/10/2006 5:21:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346711421">message detail</a>
 | #402</td></tr>
<tr class="even"><td>
Still, an X-Stat jitter of barely more than 1% is nothing, don't
exaggerate it. Stuff like that happens every year, and it doesn't make
the X-Stats much less reliable. You can't use them in close matches,
that much should be obvious. <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 11/10/2006 8:09:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346747763">message detail</a>
 | #403</td></tr>
<tr class="even"><td>
Haha! Another good pick<i>!!</i><br><br>And I'm waiting until I see the picture(s) before sending my analysis, Moltar! <br><br>But if it gets too late, I'll just go ahead and type it up real quick and send it.<br><br>---<br>"My ambition is to create the coolest Link that's ever existed." -- Keisuke Nishimori, Twilight Princess
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 11/10/2006 8:10:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346747902">message detail</a>
 | #404</td></tr>
<tr class="even"><td>
So...any word about who gets Snake/Sonic?<br>---<br>"A strong man doesn't need to read the future. He makes his own." - Solid Snake<br>"I'll show you what true speed really is!" - Sonic
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=1129736" class="name">Sonic 2 Shouldve Won</a> |
Posted 11/10/2006 8:24:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346751202">message detail</a>
 | #405</td></tr>
<tr class="even"><td>
HELL YES!! I WAS WRONG! I've never been so happy to be wrong before.<br><br>I
kinda feel ashamed of myself though. I mean, the one official analysis
I do, and I pass up the opportunity to call the Sonic &gt; Crono upset.
Oh well, who cares.....SONIC WINS!<br><br>---<br>Spring 2004 Contest - Sonic the Hedgehog 2 should've beat Super Mario World<br><b>*DpOblivion*</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 11/10/2006 8:45:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346756004">message detail</a>
 | #406</td></tr>
<tr class="even"><td>
Don't think I'm not writing one up for the Guest molty... I'm still waiting on the pic/s.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/10/2006 9:39:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346768910">message detail</a>
 | #407</td></tr>
<tr class="even"><td>
Ok, because I was getting kinda worried when I realized i only had 4 in. Wonder if KH is waiting as well.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sonic vs. Crono - Bracket: <b>Crono</b> - Vote: <b>Sonic</b> (104/120)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 11/10/2006 9:40:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346769048">message detail</a>
 | #408</td></tr>
<tr class="even"><td>
im writing it now.. if she gets a ZSS pic I'll just do a short add on.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 11/10/2006 10:04:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346774626">message detail</a>
 | #409</td></tr>
<tr class="even"><td>
Okay... it's been sent.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 11/10/2006 10:12:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346776378">message detail</a>
 | #410</td></tr>
<tr class="even"><td>
Sent.<br><br>---<br>"My ambition is to create the coolest Link that's ever existed." -- Keisuke Nishimori, Twilight Princess
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/10/2006 10:39:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346782510">message detail</a>
 | #411</td></tr>
<tr class="even"><td>
<b>Final Four:</b> <i> Match 61</i> &#8211; (1)Samus vs. (1)Zelda <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Samus</b> - <i>Zero Suit? How about we see Zero Clothing Samus!</i><br>Round 1 &#8211; 81.85% vs. Nidoran F (18.15%)<br>Round 2 &#8211; 79.78% vs. Ada (20.22%)<br>Round 3 &#8211; 69.00% vs. Rikku (31.00%)<br>Round 4 &#8211; 50.49% vs. Tifa (49.51%)<br><br>Uh&#8230;yeah, blame ZSS<br><br><b>Zelda</b> - <i>Needs to call upon the power of &#8220;The Link&#8221; to overcome this hurdle!</i><br>Round 1 &#8211; 86.08% vs. Carmen (13.92%)<br>Round 2 &#8211; 79.45% vs. Terra (20.55%)<br>Round 3 &#8211; 56.87% vs. Aeris (43.13%)<br>Round 4 &#8211; 57.02% vs. Yuna (42.98%)<br><br>Zelda doesn&#8217;t look too dominant last round either<br><br>Gosh
diddly darn you Zero Sero Suit Samus. You turned what never looked to
be a debatable match into one. I mean, up until Round 4, everything had
been fine and normal in the world. Samus had looked like her old self,
and Zelda looked stronger as well. I mean, she was definitely looking
like she would do better than the stats projected.<br><br>Then Round 4
hits us, and in comes Zero Suit Samus versus KH2 Tifa. Now, many
thought Samus would be relatively fine with ZSS, but once we actually
saw Tifa <i>leading</i> against Samus, then yeah, something was up.
Now of course, people were stupid and called Tifa either at 40% on BL
or Samus at Tifa&#8217;s 33% on BL level. That&#8217;s <b>WROOOOOOOONG!!!</b><br><br>Samus
obviously underperformed against Tifa because some causals just didn&#8217;t
recognize her in Zero Suit form. Now, the real question is by how much?
I mean, Tifa has had AC, KH2, maybe even FFXII-influx for her, but how
much of the overperformance can we blame on that and the picture?<br><br>Hopefully,
Zelda will answer that, and hopefully we&#8217;ll see Samus return to full
form this match! Zelda has looked great so far in every match up to
Yuna, but still, Yuna&#8217;s looked like a beast this year, so who knows. I
mean, she almost equals Aeris now! Anyway, I think Samus still has a
really good shot, but I do think Zelda has boosted, so she&#8217;ll do better
than projected. People may shoot very low because of what happened last
round, but I still think Samus will do pretty decent for herself here.<br><br><b>Moltar&#8217;s Bracket Says:</b> Samus will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Samus: 56% - Zelda: 44%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br> <br>We're
in the final eight and still have eeeeeeeasy matches on the female
side. All this is is a "guess the winner's percent!" type of match.<br><br>Prediction: Samus with 59.47%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br><b>Samus Aran</b><br><br><i>Previous Matches:</i><br><br>Samus Aran &#8211; 81.85% -- 95,533<br><br>Nidoran F &#8211; 18.15% -- 21,180 <br><br>Samus Aran &#8211; 79.78% -- 98,352<br><br>Ada Wong &#8211; 20.22% -- 24,923 <br><br>Samus Aran &#8211; 69% -- 85,439<br><br>Rikku &#8211; 31% -- 38,387 <br><br>Samus Aran &#8211; 50.49% -- 72,773<br><br>Tifa Lockhart &#8211; 49.51% -- 71,355 <br><br><b>Zelda</b><br><br><i>Previous Matches:</i><br><br>Zelda &#8211; 86.08% -- 102,509<br><br>Carmen Sandiego &#8211; 13.92% -- 16,578 <br><br>Zelda &#8211; 79.45% -- 92,826<br><br>Terra Branford &#8211; 20.55% -- 24,005 <br><br>Zelda &#8211; 56.87% -- 71,597<br><br>Aeris Gainsborough &#8211; 43.13% -- 54,300 <br><br>Zelda &#8211; 57.02% -- 77,105<br><br>Yuna &#8211; 42.98% -- 58,112
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/10/2006 10:40:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346782592">message detail</a>
 | #412</td></tr>
<tr class="even"><td>
Zelda finally gets to have a showdown with Samus &#8220;I Cannot SFF
Anything&#8221; Aran! For the Princess of Hyrule, this has been an absolute
breeze despite having some legitimate competition. Aeris, the one she
was expected to lose to, got absolutely rocked from beginning to end.
Yuna also got destroyed despite any potential FFXII factor that might
have helped her out. Zelda seems to be doing everything right this
contest and is really proving herself with some big wins &#8211; a long way
from the days of just beating Lara Croft or Vivi before losing in round
2 &#8211; and she&#8217;s looking to possibly make contest history against a fellow
Nintendo character here. <br><br>Samus
has been up, down, and all around in this contest. She came out looking
awful against Nidoran F &#8211; barely managing 80% -- then comes out look
pretty solid by destroying Ada Wong nearly as bad as Nidoran F. She
simply met expectations, if not underperformed a bit by stats, against
Rikku and finally shocked <i>everyone</i> by barely squeaking by Tifa.
Her most recent match, against actual competition, certainly isn&#8217;t
doing her any favors. There are a number of factors that could have
potentially played into that match, but it doesn&#8217;t look <i>great</i> for Ms. Aran no matter how you slice it. <br><br>This
is a match I have felt would be pretty close from the very beginning. I
figured that Twilight Princess would have been out by the time this
match rolled around pre-contest, but it ends up coming a week after
this match. However, the positive thing with this is that it&#8217;s so close
that full attention has been put on TP again. The media are getting
their final copies, screenshots are released daily, and impressions are
insanely positive &#8211; Zelda even had a new screenshot released of her! I
think it all plays into her favor, along with the advantage of coming
from Nintendo&#8217;s top series, The Legend of Zelda. <br><br>Zelda has
looked absolutely dominative for this entire contest whereas Samus has
looked like she usually does, if not a bit weaker. I think it&#8217;s really
hard to deny here that Zelda <i>has</i> increased, and any little bit
indirectly will help. I think the ability for Zelda to rSFF Samus here
is pretty big considering she comes into the match with all the
recognition, the focus (TP in one week; MP3 delayed into 2007), and
already being very strong. I&#8217;m not saying that since Samus got SFFed
hard by Mario that she is susceptible to SFF by <i>anyone</i>, but Zelda is hardly some bottom feeder; she&#8217;s a definite near-elite.  <br><br>(Stupid CJayC isn&#8217;t going to put up the pictures before this goes out!) <br><br>I
think this match is going to end up being really close, despite some
people thinking it&#8217;ll be taken by Samus with ease (LOL EC 60%+). Zelda
has everything necessary in her corner to at least break 45% here and
easily out do Ganondorf&#8217;s percentage last year. Samus seems rather
vulnerable, Zelda looks fantastic, and Twilight Princess is a mere week
away with tons of media coming out about it constantly. Finally add in
potential rSFF going Zelda&#8217;s way and we may just indeed see the fall of
the Noble Nine here! GO ZELDA <i>!!</i> <br><br><b>Aitch Emm&#8217;s Bracket:</b> Samus Aran<br><br><b>Aitch Emm&#8217;s Prediction:</b> Samus Aran &#8211;  52.5% ; Zelda &#8211; 47.5%<br><br><b>Aitch Emm&#8217;s Vote:</b> Zelda<br><br> <br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br><br>With
that blasted blue idiot wrecking everything as we speak, the Wii just
days away, and me wondering how I'm actually going to play that Wii
between two jobs and the looming semester finals, I'd be stupid <i>not</i> to make this pick!<br><br>My prediction: Zelda def. Samus (53-47)<br><br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>I'm
really stabbing in the dark on my %age guesstimate with this match. On
the one hand, we could get a match similar to we got last round in
this:
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/10/2006 10:41:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346782706">message detail</a>
 | #413</td></tr>
<tr class="even"><td>
<a class="linkification-ext" href="http://i24.photobucket.com/albums/c38/NeoX-Death/ZvSamus.jpg" title="Linkification: http://i24.photobucket.com/albums/c38/NeoX-Death/ZvSamus.jpg">http://i24.photobucket.com/albums/c38/NeoX-Death/ZvSamus.jpg</a><br><br>On the other we could get one like this:<br><br><a class="linkification-ext" href="http://i24.photobucket.com/albums/c38/NeoX-Death/SvZelda.jpg" title="Linkification: http://i24.photobucket.com/albums/c38/NeoX-Death/SvZelda.jpg">http://i24.photobucket.com/albums/c38/NeoX-Death/SvZelda.jpg</a><br><br>And
this makes the difference between Samus with 51% and Samus with 60%,
right there. Okay, I admit those two pictures were over the top (but of
course!), but the point is Malibu Suit Samus was the reason she looked
so bad against Tifa. And I'd <i>totally</i> have called for it if I bothered to look at match pictures.<br><br>Now,
given that these pictures are going to be user submitted, I'm thinking
Samus is likely to be her power suit, just like we would rather her be.
And it's also going to be a cycle of pictures, I'd assume, so even if
there is one vile Zero Suit picture in there, it shouldn't be a problem.<br><br>But,
notice I didn't say "the difference between Samus with 49% and Samus
with 60%" even with the Zero Suit, I think Samus would still squeak a
win out. She 60-40ed Ganondorf last year, and although Zelda's looking
perhaps a <i>tad</i> better (even that's debatable considering Yuna)
than Ganondorf was last year, that's still quite a little % to
overturn. I don't think she's got it in her. And also, Zelda vs. Tifa
would be a pretty tough match for me to call, anyway. Zelda easily?
Nah. Zelda wouldn't beat Tifa by much (if at all), I wouldn't think.<br><br>I
think Zelda kinda depends on the Zero Suit to have any chance, and I
don't think she'll be getting it right now. Samus is just too much
without it, here.<br><br><b>Lopen's Prediction:</b> Samus with 56.66%<br><br><br> <br><b>KH&#8217;s Analysis</b><br> <br>lol wate he mess up? Time for Moltar to step in! <i>Samus is so screwed</i>, but I&#8217;ll pick her just because it probably was all because of the picture. darn you samus<br> <br>Prediction: Solid &#8220;I&#8217;m your shadow&#8221; Snake with 54.30%<br><br><br> <br><b>Guest&#8217;s Analysis</b> - <i>Explicit Content</i><br><br>Alright...
I'm going to try to keep this short and sweet, because anyone reading
this already knows my feelings on this match, and if you don't, you're
probably braindead, or BT. That's assuming you can differentiate the
two.<br><br>First off, we have Samus, the queen of gaming as we know
it! Once upon a time many believed she was the only person capable of
giving Mr. Sephiroth a match, other than Clink of course. In 2005 she
was the sexy upset over the FF7 villain in the ToC. She came storming
right out of the gate putting up 88% on Yuri, making Snake look like a
low mid-carder, and beating down Ganon harder than Seph had a few
months prior. The Samus cloud was riding sky-high, and the upset train
was a rollin' --- then came that slut Mario. That dirty, caniving,
two-faced whore put an end to Samus' beautiful run, with his disgusting
"rSFF" oh what a trickster you are Mario, what a trickster you are.
Now, after this amazing run, looking like she really can rival Seph,
people would be giving her, her props right? <b>WRONG, *****</b>. People start talking about crazy things like Crono beating her. Crono! Board 8, how I pity thee.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/10/2006 10:41:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346782856">message detail</a>
 | #414</td></tr>
<tr class="even"><td>
Now lets fast forward this baby to this year, if Samus is underrated in
the stats, then surely so must the people in her path be, like Yuna,
Ganon and Auron, oh what interesting characters! Let's start it off
with the estrogen filled portion of the bracket. Yuna comes roaring
out, completely decimating Roll, making a should be stronger Joanna
look worse than HM's face, tearing Chunners a new one, and
overperforming very nicely on Zelda.<br><br>Underrated character 1/1.<br><br>"Fluke!
Crazy! Preposterous!" you say, well I'm glad you're such a skeptic,
you're making my job more fun! Ganon. Ganon goes out first round to
Vincent with 48%, "what's so impressive about that?" you say, that's
what last years stats project! Well my friends, Vincent has had DoC
since the last contest, the first game he's ever starred in, along with
Advent Children, the highly viewed FF7 movie, who goes on to perform
slightly better than the stats predict. Aww EC, looks like your case
ends here... how unfortunate. <b>NOT SO FAST STARFOX!</b> Sonic is currently kicking Crono's ass, oh hey look, Ganon is disgustingly underrated last year, <b>SHOCK AND AWE LADIES AND GENTS, SHOCK AND AWE</b>.<br><br>Underrated character 2/2.<br><br>"Psshaw! I don't believe it, two is just a coincidence, there's nothing you can prove, they just boosted!" Ah my friends, this <i>might</i>
be the case if it weren't for my good buddy Auron. Now that man, that
man can have be my babies daddy. Me? Oh well... that's for another
time. Auron starts off 2K6 making Alucard look as weak as ever, <b>WHAT NO! SUBBY CAN'T BE THAT STRONG!</b>
darn you auron... ---- or darn you not! Just when you were
disappointing me, you go and bring me a fresh bouquet of flowers and
chocolate, aww you're so sweet. You go on to make Crono look like ass
making it look like you would thrash the very same Ganon who gave you a
solid beating the previous year. Auron, you so sweet!<br><br>Underrated character 3/3.<br><br>You
can't deny it, 3 characters, with only one thing in common, all
overperform severely the year after Samus apparently is weaker than
Mario indirectly. Hmm... yep, they just all boosted that makes sense,
right? RIGHT?!<br><br>Now we have Zelda, but who really cares about her
anyway? She's the princess you save, yeah, she goes all Sheik action on
you in OoT, but to this day I still see people asking why Zelda turns
into Sheik in SSB. The voters aren't the most intelligent folk. Ganon
however, is the king of Villains, the man who Link must overcome to
save the world from darkness time after time. The man cannot be
stopped. And you expect a frilly dilly ho like Zelda to outperform the
king of evil on Samus? Sassafrass!<br><br><b>EC's Prediction That Is So Right It Hurts:</b> Samus with 61%<br><br>.<br>.<br>.<br>.<br>.<br>.<br><i>Hold The Phone!!</i><br><br>Should Ceej decide to be a skank and use ZSS pic:<br><br><b>EC's Prediction That Is So Right It Hurts:</b> Samus with 51%<br> <br> <br><br>Crew Consensus: Uh..Samus wins in the 50% range.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/10/2006 10:41:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346782910">message detail</a>
 | #415</td></tr>
<tr class="even"><td>
Laff.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=640243" class="name">Big Bob</a> |
Posted 11/10/2006 10:46:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346783751">message detail</a>
 | #416</td></tr>
<tr class="even"><td>
<b><i>Big Bob's completely biased and nonsensical analysis</i></b><br><br>I
don't care about this match. Sonic has made the final four, beaten a
fellow NN-er, and broke the record for the biggest comeback!<br><br><b>Bob's Prediction: Samus with I don't care, because I'm partying</b><br>---<br>Gordon
Freeman finally won, but somehow, the universe survived... thus
allowing me to tell said universe about how I was owned by <b>NClark128</b>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 11/10/2006 10:56:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346785777">message detail</a>
 | #417</td></tr>
<tr class="even"><td>
I'd like to change my pick to Zelda with 55.55%. I don't think Zelda
would have had any problems beating Tifa, and if there's any SFF AT ALL
in tomorrow's match, Samus will get Ulti-destroyed.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), Castlevania: LoI, MMZX
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 11/10/2006 10:59:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346786426">message detail</a>
 | #418</td></tr>
<tr class="even"><td>
KH picked Snake to win tomorrow? He's ballzier than I thought &lt;_&lt;<br><br><b>TuRtLe</b><br>~~~<br>Pretty much out of the contest<br>lol x-stats
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 11/10/2006 11:04:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346787563">message detail</a>
 | #419</td></tr>
<tr class="even"><td>
Well that a stupid last second change on my part =op<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), Castlevania: LoI, MMZX
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/10/2006 11:05:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346787618">message detail</a>
 | #420</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Sorry for being late, I was
too busy playing Sonic the Hedgehog 2 in celebration of SONIC'S VICTORY
OVER CRONO!!!!! (Swear I didn't check out the poll yet though)<br><br>Oh
yeah, Samus vs. Zelda now. Wow....all the times I kept saying, "The
Noble Nine is not falling this contest," I was really referring to the
male half, because I never thought we'd be in the position to think of
Samus being the one knocked off. But sure enough, after struggling
mightily against Tifa, we worry about her against Princess Zelda, who
has been dominant all contest long. Is there really an upset in the
making?<br><br>Well, the thing is, these are two prominent Nintendo
characters, so obviously we will see SFF here. Samus has obviously
shown to be stronger, but could Zelda, from the more popular series,
rSFF Samus like Mario did? Well, Zelda isn't the main character like
Mario is, but still the name of the series.<br><br>With all the
Twilight Princess hype going on now, I really would not be surprised if
Zelda wins this match. And you know what? Screw it, this contest has
been so unbelievablely crazy, I'm gonna call for the upset. Oh, and
this was definitely no quick analysis, sorry.<br><br>My vote: Zelda<br>My bracket: Samus<br>My prediction: Zelda with 53%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/10/2006 11:06:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346787940">message detail</a>
 | #421</td></tr>
<tr class="even"><td>
Hey, my alt is on the leaderboard!<br>---<br>Moltar Status: 17th on the leaderboard! Go my alt!<br>Samus vs. Zelda - Bracket: <b>Samus</b> - Vote: <b>Samus</b> (104/128)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/10/2006 11:07:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346788094">message detail</a>
 | #422</td></tr>
<tr class="even"><td>
Damn, I knew I should've went with my real gut pick.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=254355" class="name">Lugia2</a> |
Posted 11/11/2006 5:56:49 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346829800">message detail</a>
 | #423</td></tr>
<tr class="even"><td>
...I can't believe people thought Zelda would do it. This is Samus
we're talking about, not 2002 Solid Snake or something like that.<br><br>Still, I'm more worried about the next round than anything else...Though I still doubt Sonic can defeat Samus...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/11/2006 7:10:19 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346833080">message detail</a>
 | #424</td></tr>
<tr class="even"><td>
<i>From Lugia2</i><br><i>...I can't believe people thought Zelda would
do it. This is Samus we're talking about, not 2002 Solid Snake or
something like that.<br><br>Still, I'm more worried about the next round than anything else...Though I still doubt Sonic can defeat Samus...</i><br><br>Then it's a good thing that Snake can, and will!<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/11/2006 7:13:45 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346833311">message detail</a>
 | #425</td></tr>
<tr class="even"><td>
Sorry about not getting my prediction in yesterday, Moltar. My internet
crapped out for whatever reason and I'm still trying to pick up the
pieces.<br><br>I got TOMORROW'S match covered, though!!!<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/11/2006 9:17:27 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346843776">message detail</a>
 | #426</td></tr>
<tr class="even"><td>
Heh, I was having major internet problems too. Good thing it was
working from 9:30 to 11:30 (and it was out the rest of the night).<br><br>And what Guest does Snake/Sonic?<br>---<br>Moltar Status: 17th on the leaderboard! Go my alt!<br>Samus vs. Zelda - Bracket: <b>Samus</b> - Vote: <b>Samus</b> (104/128)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/11/2006 9:27:07 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346844842">message detail</a>
 | #427</td></tr>
<tr class="even"><td>
I'll take it, then. Screw the finals. &gt;_&gt;<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/11/2006 11:15:50 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346860735">message detail</a>
 | #428</td></tr>
<tr class="even"><td>
So, do I get it then? o.O<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/11/2006 4:36:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346925966">message detail</a>
 | #429</td></tr>
<tr class="even"><td>
Sure<br>---<br>Moltar Status: 17th on the leaderboard! Go my alt!<br>Samus vs. Zelda - Bracket: <b>Samus</b> - Vote: <b>Samus</b> (104/128)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 11/11/2006 4:42:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346927235">message detail</a>
 | #430</td></tr>
<tr class="even"><td>
<i>THEJackSparrow | Posted 11/6/2006 6:09:27 PM | message detail  <br>If
the Male Bracket final is Snake vs. Sonic, I want it. I know I've
already done two, but I've been hoping and calling for that match all
contest!</i><br>---<br>"A strong man doesn't need to read the future. He makes his own." - Solid Snake<br>"I'll show you what true speed really is!" - Sonic
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 11/11/2006 8:20:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346974910">message detail</a>
 | #431</td></tr>
<tr class="even"><td>
You can have the write-up, Lady Ashe. Moltar said I could have the finals instead.<br>---<br>"A strong man doesn't need to read the future. He makes his own." - Solid Snake<br>"I'll show you what true speed really is!" - Sonic
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 11/11/2006 8:25:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346976233">message detail</a>
 | #432</td></tr>
<tr class="even"><td>
By the way, Moltar, "Ulti" just sent in his Snake/Sonic Analysis...<br>---<br>"A strong man doesn't need to read the future. He makes his own." - Solid Snake<br>"I'll show you what true speed really is!" - Sonic
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/11/2006 8:25:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346976243">message detail</a>
 | #433</td></tr>
<tr class="even"><td>
You people have too many different accounts. At least mine have basically the same name. =/<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/11/2006 8:25:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346976304">message detail</a>
 | #434</td></tr>
<tr class="even"><td>
Gah, I need <i>something.</i> Pictures, Crew Writeups, anything! GRRRAAAAHHHH <br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=395700" class="name">HaRRicH</a> |
Posted 11/11/2006 8:27:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346976644">message detail</a>
 | #435</td></tr>
<tr class="even"><td>
<i>By the way, Moltar, Ulti just sent in his Snake/Sonic "Analysis"...</i><br><br>Heh.<br>---<br>Diddy did it.  Diddy did it.<br>DAMMIT!  What didn't Diddy do?!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 11/11/2006 8:28:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346976792">message detail</a>
 | #436</td></tr>
<tr class="even"><td>
No, I put the quotation marks in the proper place. You'll see.<br>---<br>"A strong man doesn't need to read the future. He makes his own." - Solid Snake<br>"I'll show you what true speed really is!" - Sonic
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/11/2006 8:28:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346976850">message detail</a>
 | #437</td></tr>
<tr class="even"><td>
ohmygosh I want to see Ulti's writeup for this match so bad<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=395700" class="name">HaRRicH</a> |
Posted 11/11/2006 8:28:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346976973">message detail</a>
 | #438</td></tr>
<tr class="even"><td>
I trust you did.<br>---<br>Diddy did it.  Diddy did it.<br>DAMMIT!  What didn't Diddy do?!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=981127" class="name">Cavalier Lowen</a> |
Posted 11/11/2006 8:28:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346977009">message detail</a>
 | #439</td></tr>
<tr class="even"><td>
You guys doing writeups for the BR too?<br>---<br>Z1mZum owned me in the guru contest (by two points!).  Damn you Z1mZum!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 11/11/2006 8:30:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346977300">message detail</a>
 | #440</td></tr>
<tr class="even"><td>
Hmmm...I wonder. Will the Battle Royale be like predicting the
percentage for the winner or the loser (since it's the loser that gets
booted)?<br>---<br>"A strong man doesn't need to read the future. He makes his own." - Solid Snake<br>"I'll show you what true speed really is!" - Sonic
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/11/2006 8:30:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346977337">message detail</a>
 | #441</td></tr>
<tr class="even"><td>
They should be. At least for Link/Cloud. &gt;=/<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/11/2006 8:31:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346977499">message detail</a>
 | #442</td></tr>
<tr class="even"><td>
I would assume it would be for the percentage of the loser (and who the
loser is), since that's the only thing that matters. Up until the final
day, of course.<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 11/11/2006 8:32:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346977724">message detail</a>
 | #443</td></tr>
<tr class="even"><td>
<i>You guys doing writeups for the BR too?</i><br><br>Yeah. I don't think Moltar has specified exactly how we're doing that one though.<br><br>---<br>"My ambition is to create the coolest Link that's ever existed." -- Keisuke Nishimori, Twilight Princess
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/11/2006 8:33:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346978102">message detail</a>
 | #444</td></tr>
<tr class="even"><td>
I might be interested in Day 2 or 3 of that, but it's doubtful that I'll get it because I'm going today. =/<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=152338" class="name">Lopen</a> |
Posted 11/11/2006 8:35:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346978518">message detail</a>
 | #445</td></tr>
<tr class="even"><td>
Predicting the lowest makes the most sense.<br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=395700" class="name">HaRRicH</a> |
Posted 11/11/2006 8:42:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346980225">message detail</a>
 | #446</td></tr>
<tr class="even"><td>
Just an idea for the BR...what if, like the BR, the person who does the
worst in the BR at the end of each day is done with predictions for the
rest of it? MM, KH, HM, yo, Ulti, Lopen, and the guest of the day would
get to predict the first day of the BR...and each day, as one character
goes down, so does a predictor, until only two people get to predict
the final match (as if Link/Cloud needs 7 different write-ups, really).
It would make it a bit more competitive with the predictors as well,
and could be a good chance for somebody to make a come-from-behind
lead-jump in the points (both MM's and yo's).<br><br>Not
that the classic format wouldn't work, but for a funny style of contest
matches and a number of predicters that fit this idea perfectly, hey,
worth a thought at least.<br><br><br><br><br><br><br><br><br>Oh, and in the event of a tie, I think Paper Rock Scissors is mandatory.<br>---<br>Diddy did it.  Diddy did it.<br>DAMMIT!  What didn't Diddy do?!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/11/2006 8:55:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346983172">message detail</a>
 | #447</td></tr>
<tr class="even"><td>
KH is going Cloud, so this match needs more writeups than most of the female bracket matches. &gt;_&gt;<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=395700" class="name">HaRRicH</a> |
Posted 11/11/2006 8:56:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346983514">message detail</a>
 | #448</td></tr>
<tr class="even"><td>
Oh, then KH could stand to lose early so he doesn't lose any points off of yo's system then!<br>---<br>Diddy did it.  Diddy did it.<br>DAMMIT!  What didn't Diddy do?!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 11/11/2006 8:58:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346983930">message detail</a>
 | #449</td></tr>
<tr class="even"><td>
The idea of not being able to do a write-up for Link after enduring that female bracket would be quite saddening!<br><br>---<br>"My ambition is to create the coolest Link that's ever existed." -- Keisuke Nishimori, Twilight Princess
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/11/2006 9:05:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346985664">message detail</a>
 | #450</td></tr>
<tr class="even"><td>
Interesting idea. That would add a twist. But I would rather still see
everyone's analysis. Or at least, you can make a game of it to see who
would win, that'd be cool, as long as all the predictions still go up.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=7">8</a></li>
<li>9</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=9">10</a></li>
</ul>
</div>


</div>
<img src="genmessage9_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage9_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31382187&amp;page=8" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage9_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>