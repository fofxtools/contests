<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage5_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage5_files/nogs.css"></head><body linkifytime="290" linkified="1" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage5_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage5_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31382187%26page%3D4"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div class="ad" style="text-align: center;">
<div style="text-align: center;"><img src="genmessage5_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div>
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage5_files/2006.htm" marginheight="0" marginwidth="0" topmargin="0" leftmargin="0" allowtransparency="true" frameborder="0" height="90" scrolling="no" width="728">
&lt;script language="JavaScript" type="text/javascript"&gt;
document.write('&lt;a
href="http://adlog.com.com/adlog/e/r=10153&amp;s=698137&amp;t=2006.11.13.16.13.46&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;e=&amp;rqid=00c17-gne-ad64551C992282A692&amp;event=58/http://clk.atdmt.com/ATA/go/gmsptbrg0010000048ata/direct;wi.728;hi.90/01/2006.11.13.16.13.46"
target="_blank"&gt;&lt;img
src="http://view.atdmt.com/ATA/view/gmsptbrg0010000048ata/direct;wi.728;hi.90/01/2006.11.13.16.13.46"/&gt;&lt;/a&gt;');
&lt;/script&gt;&lt;noscript&gt;&lt;a
href="http://adlog.com.com/adlog/e/r=10153&amp;s=698137&amp;t=2006.11.13.16.13.46&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;e=&amp;rqid=00c17-gne-ad64551C992282A692&amp;event=58/http://clk.atdmt.com/ATA/go/gmsptbrg0010000048ata/direct;wi.728;hi.90/01/2006.11.13.16.13.46"
target="_blank"&gt;&lt;img border="0"
src="http://view.atdmt.com/ATA/view/gmsptbrg0010000048ata/direct;wi.728;hi.90/01/2006.11.13.16.13.46"
/&gt;&lt;/a&gt;&lt;/noscript&gt;</iframe><img src="genmessage5_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 4
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;page=4">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31382187" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=3">Previous Page</a> |
Page 5 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=5">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 11/3/2006 6:10:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345119681">message detail</a>
 | #201</td></tr>
<tr class="even"><td>
Writeup has been written! Now what's Moltar's E-mail!<br><br>---<br><i>Do you really need me to bring out the Ovaltine?</i>-Stripey12isback on why hes a war hero.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 11/3/2006 6:30:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345124051">message detail</a>
 | #202</td></tr>
<tr class="even"><td>
Yeah.<br><br>---<br><i>Do you really need me to bring out the Ovaltine?</i>-Stripey12isback on why hes a war hero.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/3/2006 6:32:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345124411">message detail</a>
 | #203</td></tr>
<tr class="even"><td>
<a class="linkification-ext" href="mailto:mastermoltar@gmail.com" title="Linkification: mailto:mastermoltar@gmail.com">mastermoltar@gmail.com</a><br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 11/3/2006 6:34:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345124753">message detail</a>
 | #204</td></tr>
<tr class="even"><td>
Sent. Also noticed, right after clicking send, that I titled it Mega Man/Zora writeup. Oh well.<br><br>---<br><i>Do you really need me to bring out the Ovaltine?</i>-Stripey12isback on why hes a war hero.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=981127" class="name">Cavalier Lowen</a> |
Posted 11/3/2006 6:37:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345125404">message detail</a>
 | #205</td></tr>
<tr class="even"><td>
Nah, a Zora would totally own everyone in the contest.  <br><br>Actually it would be funny if Ceej gave Link a Zora Link picture in one of the ToC matches or something.<br>---<br>Z1mZum owned me in the guru contest (by two points!).  Damn you Z1mZum!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 11/3/2006 6:42:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345126505">message detail</a>
 | #206</td></tr>
<tr class="even"><td>
True. Although I wish I would've typo'd even more than that, as Zoro is way better than both a Zora and Sora.<br><br>---<br><i>Do you really need me to bring out the Ovaltine?</i>-Stripey12isback on why hes a war hero.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/3/2006 7:18:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345134489">message detail</a>
 | #207</td></tr>
<tr class="even"><td>
Once again, another Snake match's Crew point seems to gravitate toward
my prediction. And I've intentionally gone higher than what I expect
Snake to get by at least 2 percent every time!<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/3/2006 8:25:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345148415">message detail</a>
 | #208</td></tr>
<tr class="even"><td>
Yuna......................60.84% 71634<br>Chun Li..................39.16% 46106<br>TOTAL VOTES..................117740<br><br>41.25% of the brackets predicted this match correctly.<br><br>Ouch,
Yuna 60-40's Chun-Li, which is pretty impressive. She's definitely
looking stronger this year. The bracket support is iffy though, as I
think a good number of the casuals had Lara winning this division.<br><br>Moltar - 10<br>Lopen - 9<br>KH - 9<br>HM - 8<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Ulti - 7<br>Yoblazer - 5<br><br>Yo and I both get points for our high Yuna picks.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Snake vs. Yoshi - Bracket: <b>Snake</b> - Vote: <b>Yoshi</b> (72/80)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/3/2006 10:00:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345168339">message detail</a>
 | #209</td></tr>
<tr class="even"><td>
<b>Destiny Division:</b> <i>Round 3 - Match 54</i> &#8211; (1)Sora vs. (2)Mega Man <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Sora</b><br>Round 1 &#8211; 75.61% vs. Tingle (24.39%)<br>Round 2 &#8211; 63.93% vs. Gordon (36.07%)<br><br>Sora does&#8230;okay on Gordon I guess.<br><br><b>Mega Man</b><br>Round 1 &#8211; 69.87% vs. Axel (30.13%)<br>Round 2 &#8211; 58.04% vs. Mega Man (41.96%)<br><br>Has the Ryu of 2002-2004 that we know and love returned?<br><br>Usually
once you get to Round 3, questions are answered and things are cleared
up. That&#8217;s not the case here though, but I guess it was <i>destiny</i> that this happened!<br><br>Speaking of <i>destiny</i>, we have a match that was <i>destined</i>
to happen from the beginning, Sora vs. Mega Man. Sora hasn&#8217;t looked
like a KH2-boosted killing machine though. Failing to triple Sora,
failing to double Gordon, this looks like pre-KH2 Sora! However, Mega
Man hasn&#8217;t looked like his usual self either. He didn&#8217;t break 70% on
Axel, and then raised one of the biggest unanswered questions we have
had so far in this Contest. If everyone else in the 2005 Dream Division
has looked overrated thus far (Bowser, Kirby, Chun-Li, and Tidus), then
what the heck is up with Ryu looking <i>stronger</i>?<br><br>Yeah, one
could say Bowser overperformance, but Ryu did only get 55% on Rikku. So
I don&#8217;t know what to make of him. Either way, if Ryu was overrated
along with the rest of his division, that puts Mega Man under Bowser,
and that just doesn&#8217;t make any sense.<br><br>In short, Mega Man is
going to need to redeem himself here. So far, Sora hasn&#8217;t looked like
he&#8217;s done any huge boosting, and this may be Mega Man&#8217;s opportunity to
capitalize. With Snake looking like a beast, Mega Man is going to need
some good numbers on Sora in order to look good going into the match. I
also think another good thing to watch for is if Sora beats Ryu&#8217;s
performance on Mega Man. If he does better by a great amount, then I
think it&#8217;s time to officially say Mega Man has dropped and jump on the
Snake bandwagon.<br><br><b>Moltar&#8217;s Bracket Says:</b> Mega Man will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Sora: 42% - Mega Man: 58%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br> <br>Honestly,
I think all of the "lol MM is gon' bomb" stuff is premature. Wait until
this match to decide that; to make a long story short, if Sora goes
nuts and breaks 40% on Mega Man with ease, then there will be mild
cause for concern if you have Mega &gt; Snake. But until then, it
really doesn't matter. Mega looked TERRIBLE after his match with Leon
Kennedy last year, and he beat Sonic before giving Crono a match
anyway. Besides, Snake's MO is to always go nuts during the early
rounds, then bomb later. We'll see what happens.<br><br>Oh and Snake/Sora was SFF. Don't go insane if Mega can't score 65% here.<br><br>Prediction: Mega Man with 59.13%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br><b>Sora</b><br><br><i>Previous Matches:</i><br><br>Sora &#8211; 75.61% -- 93,568<br><br>Tingle &#8211; 24.39% -- 30,176 <br><br>Sora &#8211; 63.93% -- 77,994<br><br>Gordon Freeman &#8211; 36.07% -- 43,996 <br><br><b>Mega Man</b><br><br><i>Previous Matches:</i><br><br>Mega Man &#8211; 69.87% -- 81,959<br><br>Axel &#8211; 30.13% -- 35,340 <br><br>Mega Man &#8211; 58.04% -- 69,626<br><br>Ryu &#8211; 41.96% -- 50,342 <br><br>This
is Mega Man&#8217;s chance to redeem himself after what has been labeled as
two straight unimpressive performances. He failed to break 70% on KH2&#8217;s
Axel and then proceeded to heavily undershoot expectations against
Street Fighter&#8217;s Ryu. Sora, on the other hand, hasn&#8217;t exactly come out
looking like a beast, but it hasn&#8217;t necessarily been looking bad
either.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/3/2006 10:01:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345168574">message detail</a>
 | #210</td></tr>
<tr class="even"><td>It&#8217;s going to be tough to take anything away from
this match considering that Sora could be practically anywhere at this
point, but I think we all have our limits on what would constitute an
underperformance by Mega Man here. I suppose you could simply ask
yourself whether or not Sora is capable of beating someone like Ryu.
Many think he can solidify his position as a near-elite with this
performance&#8230;but I&#8217;m really doubting it. I think this match goes about
the same way Mega Man/Ryu did, which would certainly help Mega Man out
a bit heading into his big match with Snake. <br><br>I
expect Mega Man to take this one pretty easily, but if he has troubles
here, I think that may be the final nail in the coffin for him. Three
straight unimpressive performances certainly didn&#8217;t do Aeris any
favors. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Mega Man<br><br><b>Aitch Emm&#8217;s Prediction:</b> Mega Man &#8211; 57% ; Sora &#8211; 43%<br><br><b>Aitch Emm&#8217;s Vote:</b> Sora <br> <br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Last
year, Mega Man began his fourth Character Battle with two dull,
uninspired performances, and the people wondered what was going on. He
then shocked us all in Round 3. This year, Mega Man has begun his fifth
Character Battle with two dull, uninspired performances, and the people
are wondering what is going on. Will he shock everyone in Round 3 yet
again? I'm not so sure, but I definitely don't think we'll be seeing
his third "bleh" performance in a row.<br><br>Throughout the past few
weeks, the possibility of Sora creeping into the mid-40's in this match
has grown among board regulars, while Mega Man's chances of eclipsing
60% have all but diminished. After all, isn't that the way it should
be? Mega Man couldn't even break 70% on Axel, and his performance
against Ryu was pathetic, especially when compared to what Bowser did
last year. I'm not arguing that Sora <i>shouldn't</i> be looked upon to do well for himself in this match, but I am arguing that he <i>won't</i>.<br><br>I mean, seriously, Sora? <i>Sora?</i>
Did you see what happened last year? SORA? The day Sora hits the
mid-40's on a Noble 9er is the day GameFAQs can go to hell. Yeah,
that's about it. I can't articulate it very well, but... Sora? Jesus
****ing Christ.<br><br>My prediction: Mega Man def. Sora (61-39)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Does
Sora outdo Ryu? A few years ago we're like&#8230; "aw hell naw". But now?
Many are calling for him to do just that. Well, I know Sora's become a
lot more popular in his years around here, but does he have enough to
one-up Ryu?<br><br>People think Ryu has dropped, I don't think that's
the case. I think Ryu's as good as he's ever been and he just fluked
out last year against Bowser. People are calling for Mega Man's head on
a platter because he failed to meet expectations on Ryu. But heck, we
ignore last year and that's about what Mega Man should've been <i>expected</i>
to do. Oh, and there's Axel&#8230; but hell, I figured Axel would be pretty
popular too. I'm pretty sure I won that point, and you know why? If you
recall, it was <i>all Axel</i>, baby!<br><br>I don't think Ryu's lost a step, I don't think Mega Man's lost a step, and I don't think Sora's gained enough steps to win this.<br><br><b>Lopen's Prediction:</b> Mega Man with 59.85%<br> <br><br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>SORA</b><br><br><i>"A
scattered memory like a far-off dream. A far-off dream like a scattered
memory. I want to line the pieces up. Yours and mine."</i><br><br>Summer 2003 Contest<br>Extrapolated Strength --- 39th Place [21.17%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 21st Place [26.97% ]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 32nd Place [23.54% ]<br><br>Sora neither impresses nor disappoints against GF, and now finishes his dull, <i>dull</i> run here. Worst. Placement. Of a Wildcard Character. Ever.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/3/2006 10:01:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345168670">message detail</a>
 | #211</td></tr>
<tr class="even"><td>
<b>MEGA MAN</b><br><br><i>"Why must I fight you? We are not enemies!"</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 3rd Place [42.91%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 4th Place [38.60%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 6th Place [35.99%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 7th Place [35.55%]<br><br>Mega
Man disappoints against Ryu last round, making that two strikes against
him. He needs to hit this one out of the park to make people stop
doubting for his inevitable third clash with Solid Snake.<br><br><i>Notable Releases Since Last Appearance</i><br><br>Sora: Kingdom Hearts 2 (PS2)<br>Mega Man: N/A<br><br><i>Upcoming Releases</i><br><br>Sora: N/A<br>Mega Man: N/A<br><br>And
now for a predictable match that will only really serve to show whether
MM can handle Snake one more time. As of right now Snake is impressing
immensely against Yoshi, and in the sprite round no less. Unless Ceej
pulls a 2004 with the match picture Snake is looking to have all the
momentum here, and Mega's going to need one hell of an immovable force
to meet the unstoppable object.<br><br>On Sora's part, this is his one
chance to show what he's gained from KH2...to see whether Gordon is
non-linear or whether it just didn't help him out that much (or
alternatively that Snake/Sora was legit, in which case WTF happened
with Kratos).<br><br>Mega Man's been in this position before, just last
year even, and I expect him to hit another home run to give his
supporters the faith here. That doesn't mean Snake won't have a chance
-- Mega Man/Sonic was the closest match of 2005 after all -- but his
situation probably won't seem <i>quite</i> as dire after this match.<br><br>Karma Hunter's Vote: Mega Man. I'm still not *too* big on Sora -- Riku's where it's at!<br><br><b>Karma Hunter's Krazy Prediction: Mega Man with 57.04%.</b><br><br>This
is probably MM's last chance to prove himself before the actual
match...I won't disrespect Sora's strength so much as to give him lower
than Ryu (I wouldn't take Ryu over Sora now, not by a longshot). But if
he does this well on a KH2 boosted Sora or better he'll have a strong
argument for reestablishing himself as the favorite in his upcoming
match against Snake -- I'd probably take Sora over Yoshi after what I
saw Riku do to him, though it may be by the slimmest of margins.<br><br>And
if Ryu ends up outperforming Sora, I'll just chalk it up to an
overperformance on Ryu's end. No way Kratos boosted *that* much more
than Sora.<br><br>Upset Potential: 0.5%<br><br>Assuming a 2004 Sora boosting the same margin as 2005 Riku appears to<br>have gone to 2006, Sora could conceivably win this against a boosted<br>MM. But it's a mere fleeting thought.<br><br>Upset Prediction: Sora with 50.68%<br><br> <br><b>Guest&#8217;s Analysis</b> - <i>KamikazePotato</i><br> <br>Another
3rd Round match that serves no purpose except to set up a 4th round
match. Unless Luigi pulls a miracle, this could be one of the most
boring 3rd rounds we&#8217;ve ever had. Anyway, one of the aforementioned
set-up matches is Mega Man vs. Sora. Anyone with a brain looked past
Sora&#8217;s 1 seed and took Mega Man in the match-up, but the actual outcome
is not what people will be talking about during this match. All eyes
are on Mega Man to prove himself.<br> <br>Since 2005 Sora involves the
Snake/Sora match, which ended up screwing with the stats a bit, most
people just use Sora&#8217;s 2004 value. 2005 Mega Man vs. 2004 Sora has Mega
Man winning with 62.71 percent. Give Sora a couple more percent to
account for Kingdom Hearts II, and you&#8217;ve got the outcome. Right?
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/3/2006 10:02:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345168882">message detail</a>
 | #212</td></tr>
<tr class="even"><td>Who would have ever thought that Mega Man would
drop so suddenly? After 4 years of being consistent, he let&#8217;s Axel get
30% on him, then can&#8217;t outdo Bowser on Ryu. Axel was untested, but Ryu
wasn&#8217;t looking good at all. Last year he let Bowser get 60% on him in a
match where he was the statistical favorite, then he only outdid
Alucard by 2% on Kratos. Despite the signs of weakness, Mr. Consistency
still managed to get 41.96% on Mega Man, and if Mega Man hadn&#8217;t
recovered with the day vote he would&#8217;ve gotten even higher. Now no one
is saying that Bowser would beat Mega Man or anything, but against a
Snake that is impressing every round, any signs of weakness could lead
to defeat.<br> <br>However,
there are extenuating circumstances. Kratos was also hurt in the stats
by the Snake/Sora match. Ryu dropping suddenly is also very fishy; even
if it is a joke, he&#8217;s called Mr. Consistency for a reason. Mega Man
also had a new game out for the DS at the start of the contest, to
boot. Two staple characters of the contest dropping for no reason
whatsoever? It really doesn&#8217;t happen.<br> <br>There&#8217;s also Sora&#8217;s
strength, or lack thereof, to consider. Apparently Kingdom Hearts II
didn&#8217;t do that much for him. He didn&#8217;t really impress against Gordon
Freeman, only getting a couple more percent against GF than projected.
That may seem good, but Kingdom Hearts II and Sora&#8217;s 1 seed really made
you think he&#8217;d do better against Gordon Freeman. This may be just
people over-expecting Sora, but still.<br> <br>I think Mega Man is
going to impress in this match. Sora hasn&#8217;t boosted much, and Ryu is
stronger than he appeared. The Mega Man&gt;Snake bandwagon will start
again!<br> <br>Oh, and it looks like my prediction is exactly what it
should be if I had just done that thing in the second paragraph. But
all this writing makes it look smarter! Or something.<br> <br>Bracket: Mega Man<br>Vote: Mega Man<br>Prediction: Mega Man with 58.74%<br> <br> <br> <br>Crew
Consensus: Mega Man with the 1-seed upset everyone saw coming. Lots of
high 50's picks for the MM, hoping that he can redeem himself.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 11/3/2006 10:02:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345168926">message detail</a>
 | #213</td></tr>
<tr class="even"><td>
Sora failing to triple Sora? Mega Man wins with 25646346% of the vote!<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/3/2006 10:07:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345170043">message detail</a>
 | #214</td></tr>
<tr class="even"><td>
Wow, we all went high. Guess Mega Man's been consistent enough throughout his contest career to warrant it.<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 11/3/2006 10:09:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345170358">message detail</a>
 | #215</td></tr>
<tr class="even"><td>
Ugh. And here I was thinking I would a high pick.<br><br>---<br><i>Do you really need me to bring out the Ovaltine?</i>-Stripey12isback on why hes a war hero.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 11/3/2006 10:09:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345170448">message detail</a>
 | #216</td></tr>
<tr class="even"><td>
Also, Sora winning this against a boosted Mega Man? Wha?<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/3/2006 10:14:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345171300">message detail</a>
 | #217</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Mega Man beat Ryu with 58%.
You should think Sora would do better. But Axel barely got 30% on Mega
Man. So I have no idea where to call this....but that really doesn't
matter, because Mega Man will easily win, and that's all that really
matters.<br><br>My vote: Ehh....I'll give it to Sora<br>My bracket: Mega Man<br>My prediction: Mega Man with 57%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/4/2006 1:01:42 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345198018">message detail</a>
 | #218</td></tr>
<tr class="even"><td>
A 'weakened' Mega Man, that should have said. Meh.<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=254355" class="name">Lugia2</a> |
Posted 11/4/2006 5:37:10 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345217238">message detail</a>
 | #219</td></tr>
<tr class="even"><td>
About 57% now...You guys were pretty close with this.<br><br>Still
doesn't say much about next round. I'd care more for my bracket, but my
bracket is already too dead for Snake to cause damage.<br><br>So, who thinks 57% is a sign of weakness?<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=683142" class="name">transience</a> |
Posted 11/4/2006 5:39:57 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345217395">message detail</a>
 | #220</td></tr>
<tr class="even"><td>
57? this'll be at 55 by noonish.<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 11/4/2006 8:04:34 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345225222">message detail</a>
 | #221</td></tr>
<tr class="even"><td>
Wow... I'm shocked by all the high numbers. After Riku's performance, you'd think people would give Sora some respect.<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 11/4/2006 1:23:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345273692">message detail</a>
 | #222</td></tr>
<tr class="even"><td>
Same here, I took Sora in the betting contest expecting him to easily cover the 42.5% spread, and he has.<br>---<br>CB06 - Score: <b>78/84 </b>Rank: <b>Tied - 256th </b>Yesterday's Pick:<b> Snake</b> <br>Today's Pick: <b>Mega Man</b> Tomorrow's Pick: <b>Sonic</b> Losses: <b>Cortana, Ganon, Zero, MC, Kirby</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/4/2006 7:57:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345355748">message detail</a>
 | #223</td></tr>
<tr class="even"><td>
Solid Snake................57.16% 69085<br>Yoshi.........................42.84% 51781<br>TOTAL VOTES......................120866<br><br>68.14% of the brackets predicted this match correctly.<br><br>Snake is able to survive, even though his horrible sprite tried to hold him back. Snake just keeps looking better and better.<br><br>Today, Sora is doing almost too well against Mega Man<br><br>KH - 10<br>Moltar - 10<br>Lopen - 9<br>HM - 8<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Ulti - 7<br>Yoblazer - 5<br><br>That Snake fanboy named KH gets the point.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sora vs Mega Man - Bracket: <b>MM</b> - Vote: <b>Sora</b> (76/84)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/4/2006 7:58:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345355957">message detail</a>
 | #224</td></tr>
<tr class="even"><td>
Oh, and anyone who hasn't done a write-up yet want to do one of the Elite 8 matches? Samus/Tifa, Zelda/Yuna or Snake/MM?<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sora vs Mega Man - Bracket: <b>MM</b> - Vote: <b>Sora</b> (76/84)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 11/4/2006 8:00:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345356477">message detail</a>
 | #225</td></tr>
<tr class="even"><td>
Snake/MM, please.<br><br>...<br><br>*hides my last writeup*<br><br>---<br><i>Do you really need me to bring out the Ovaltine?</i>-Stripey12isback on why hes a war hero.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/4/2006 8:02:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345356898">message detail</a>
 | #226</td></tr>
<tr class="even"><td>
Is there a reason other than the fact that it's not set in stone you didn't include Sonic/Crono?<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/4/2006 8:02:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345356942">message detail</a>
 | #227</td></tr>
<tr class="even"><td>
Nah, I'll save up so that I can get Zelda/Samus.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2273363" class="name">shadow8021</a> |
Posted 11/4/2006 8:47:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345367589">message detail</a>
 | #228</td></tr>
<tr class="even"><td>
I can do Sonic/Crono! Please?<br>---<br>Character Battle Score: 80/84    Guru Place: 7th<br>Today's Pick: Mega Man
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/4/2006 9:01:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345371033">message detail</a>
 | #229</td></tr>
<tr class="even"><td>
No.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/4/2006 9:37:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345379762">message detail</a>
 | #230</td></tr>
<tr class="even"><td>
<i>Is there a reason other than the fact that it's not set in stone you didn't include Sonic/Crono?</i><br><br>No, that's the only reason.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sora vs Mega Man - Bracket: <b>MM</b> - Vote: <b>Sora</b> (76/84)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/4/2006 9:39:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345380223">message detail</a>
 | #231</td></tr>
<tr class="even"><td>
<b>Blast Division:</b> <i>Round 3 - Match 55</i> &#8211; (1)Sonic vs. (2)Luigi <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Sonic</b><br>Round 1 &#8211; 80.75% vs. CATS (19.25%)<br>Round 2 &#8211; 52.09% vs. Vincent (47.91%)<br><br>Vincent does very well against Sonic.<br><br><b>Luigi</b><br>Round 1 &#8211; 53.71% vs. Zero (46.29%)<br>Round 2 &#8211; 52.31% vs. Kirby (47.69%)<br><br>Luigi beats Kirby by more than Bowser did&#8230;wow.<br><br>Woo
answers! Yeah, Vincent is as strong, if not stronger, than 2005
indicated, as he puts up better than projected numbers against Sonic.
Who cares about Vincent though, this puts Ganondorf very high as well!
Woo, Ganondorf!<br><br>Also, Luigi just further confirmed that the
Dream Division was overrated with his win against Kirby. Man, when did
this Green Plumber get so strong. If anything, he&#8217;s showing that he&#8217;s
either at his 2005 level, or slightly above it. Scary.<br><br>So now we
reach this match here, and there isn&#8217;t really much to say on it. Prior
to this, Sonic would already nearly crack 60% on Luigi, and I don&#8217;t see
Luigi as challenging Sonic at all. If anything, Mario/Shadow points to
something weird happening, like an overperformance, but I won&#8217;t bank on
it.<br><br><b>Moltar&#8217;s Bracket Says:</b> Sonic will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Sonic: 59% - Luigi: 41%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br> <br>Whatever gave all that power to Mario last year is clearly at work again for Luigi. BUT!!<br><br>Let's
not go nuts and assume Luigi is going to give Sonic a match here. Even
with doing well on Tifa last year, Luigi is barely projected to break
40%. Might he do a little better? Maybe, but calling for an upset is a
bit nuts.<br><br>Prediction: Sonic with 58.58%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br><b>Sonic the Hedgehog</b><br><br><i>Previous Matches:</i><br><br>Sonic the Hedgehog &#8211; 80.75% -- 87,757<br><br>CATS &#8211; 19.25% -- 20,925 <br><br>Sonic the Hedgehog &#8211; 52.09% -- 64,699<br><br>Vincent Valentine &#8211; 47.91% -- 59,497 <br><br><b>Luigi</b><br><br><i>Previous Matches:</i><br><br>Luigi &#8211; 53.71% -- 69,851<br><br>Zero &#8211; 46.29% -- 60,207 <br><br>Luigi &#8211; 52.31% -- 55,812<br><br>Kirby &#8211; 47.69% -- 50,890 <br><br>Luigi <i>finally</i>
makes to round 3 and gets to face off against a Noble Nine character!
The Eternal Understudy has shined like no other in this contest by
taking a four-pack that he wasn&#8217;t given too much of a shot in, winning
convincingly at that! Sonic has looked pretty impressive himself by
taking care of CATS with no trouble (Surprise!) and managing to pull
out a close win against Mr. Valentine. Some might say it was
disappointing, but I think it just solidifies Vincent&#8217;s position as a
huge threat in these contests. <br><br>Some people have compared this
match to Mario/Shadow and thinking there may be some proxy votes here
to potentially make this match closer, but I&#8217;m not really one to
believe any of that. I <i>do</i> think that Luigi is going to be very
impressive here by out doing what the hedgehog did to Tifa last year,
who also happened to beat Luigi, but Sonic ever being threatened, or
even matching what Vincent did, is just hopeless optimism for the
plumber. <br><br>Unless Sonic just rocks this match, he probably won&#8217;t
be considered too impressive heading into the match with Crono, but I
think he&#8217;ll stand a great chance there regardless of what happens in
this one. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Ganondorf<br><br><b>Aitch Emm&#8217;s Prediction:</b> Sonic the Hedgehog &#8211; 55% ; Luigi &#8211; 45%<br><br><b>Aitch Emm&#8217;s Vote:</b> Luigi<br> <br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Despite
what last year's stats predict (a Sonic victory with over 59%), I can't
help but think that Luigi will do very well for himself here. He was
the #3 pick in his fourpack, yet he defied the odds in beating two
characters that were once thought to be in a whole other ballpark. It
is entirely possible that a combination of power and SFF did both Zero
and Kirby in, and that speaks volumes for the plumber.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/4/2006 9:40:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345380427">message detail</a>
 | #232</td></tr>
<tr class="even"><td>Call me crazy, but there's a tiny Italian voice
telling me that Luigi may draw a tiny bit of SFF against Sonic, and he
may also benefit from appearing as a Mario proxy of sorts (everyone
remembers Mario/Shadow 2003, right?). If these theories actually prove
to be correct, Luigi will almost certainly outperform Bowser's
percentage against Crono, thus putting Sonic in a boatload of trouble
next round.<br><br>My prediction: Sonic the Hedgehog def. Luigi (55-45)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Oh&#8230; what a&#8230; match&#8230;<br><br><b>KYAAASSSHHHHH!!!</b> DIE LUIGI DIE!<br><br>&#8230;
sorry. Anyway, this match is just another "% caller" for me. Doesn't
seem like it should be debatable. Tifa beat Luigi and Sonic beat Tifa
really easy last year, no sweat. So, easy win for Sonic, right? Even
assuming Luigi got a nice little popularity boost, it'd have to be <i>really</i> nice. <i>However</i>, there's something funny that might happen in this. Hopefully not <i>everybody</i> brings this up&#8230; I'll try and keep it brief.<br><br>2003, Mario faced Shadow the Hedgehog. And Shadow? Shadow went all wacky and got like 45% on him. Way more than he <i>should've</i>
got. Basically, the stat heads out there were all like "Shadow was a
Sonic proxy in that one, so he did better than he should've!".<br><br>Okay,
now does that theory hold any water? Eh, seems to make sense to me,
actually. But, does that mean Luigi does better than expected on Sonic
or worse? One might say "Shadow was the weaker guy, and Luigi is the
weaker guy, Luigi should do better". Another might say "Shadow was the
Sonic the Hedgehog guy, and Sonic is the Sonic the Hedgehog guy, Sonic
should do better"! And of course, there's option 3, the theory doesn't
hold any water and Luigi will do just as expected to.<br><br>What do I think? Eh, I'll take a gamble on the "Sonic should do better" side. Is good? Is good.<br><br><b>Lopen's prediction:</b> Sonic with 58.50%<br><br><br> <br><b>KH&#8217;s Analysis</b><br><br>...I
happen to be dressed in the full garb of V from "V For Vendetta", and I
can barely see out of this damn mask. Crazy party. Yeah, this is my
first true Ulti-style half-asssed writeup, out of necessity. Uh Sonic
wins<br><br><b>Sonic the Hedgehog with 56.32%</b><br> <br><br> <br><b>Guest&#8217;s Analysis</b> - <i>BigBob</i><br><br>Before
I get into analyzing, I'd like to say that it's about time Sonic beat a
Nintendo character. Samus Aran's been holding him back since the
beginning of time, and now he's finally a lock to win against his rival
company. The only time Sega has beat Nintendo before was when Shadow
beat Wario in 2003.<br><br>Everyone remember that one? Remember how
Shadow kicked Wario's ass when he was the underdog, then proceeded to
put 45% on Mario? He was not the same strength the following year, so
maybe you can count that as an overperformance. And frankly, I think
it's gonna happen again. Luigi has the same fanbase as Mario, and if
Mario can let a second-rate Sonic character get 45% on him, will Luigi
be able to stop Sonic from making a complete fool of him? I think not.<br><br>Bob's Prediction: Sonic with 63%.<br> <br> <br>Crew Consensus: The Guest is rolling pretty high, but everyone else says mid to high 50's for the Blue Blur.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=640243" class="name">Big Bob</a> |
Posted 11/4/2006 9:44:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345381273">message detail</a>
 | #233</td></tr>
<tr class="even"><td>
I'm the only one that went above 60?  Wasn't expecting that...<br>---<br>Gordon
Freeman finally won, but somehow, the universe survived... thus
allowing me to tell said universe about how I was owned by <b>NClark128</b>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/4/2006 9:49:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345382406">message detail</a>
 | #234</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>It's been fun rooting for
Luigi the last couple matches. But those times are over, because he's
up against my boy Sonic. After beating Vincent, Sonic is looking ahead
to facing Crono, as Luigi should be no problem at this point.<br><br>Hey
Luigi, thanks for getting me to the leaderboard. Sorry I ruined it with
the accidental Peach pick and the stupid Aeris pick. You did good
though. It's Sonic time now though.<br><br>My vote: Sonic<br>My bracket: Sonic over Luigi<br>My prediction: 56%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/4/2006 9:50:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345382696">message detail</a>
 | #235</td></tr>
<tr class="even"><td>
OK then.....I'm calling Sonic/Crono in advance. It's happening, and I'm
taking it. The urge to officially have a say in the Crew is too great,
and I need to satisfy it with a Sonic match.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=395700" class="name">HaRRicH</a> |
Posted 11/4/2006 10:54:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345396587">message detail</a>
 | #236</td></tr>
<tr class="even"><td>
Damn, Solid/Mega was the only other match this contest I wanted.<br>---<br>Diddy did it.  Diddy did it.<br>DAMMIT!  What didn't Diddy do?!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/5/2006 1:29:30 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345424622">message detail</a>
 | #237</td></tr>
<tr class="even"><td>
I only ask for one match all contest, and it's gotta be Sonic......so I
better get it. I deserve priority since A) I haven't done a guest
analysis yet and B) I'm an original Crew member.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=254355" class="name">Lugia2</a> |
Posted 11/5/2006 9:25:46 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345459661">message detail</a>
 | #238</td></tr>
<tr class="even"><td>
Sonic is at or above 60%. This felt like a Female match-wipeout...Oh
well. Won't be too surprised if this happens again w/Solid Snake and
MM. SS v MM...Hmm...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/5/2006 1:20:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345501148">message detail</a>
 | #239</td></tr>
<tr class="even"><td>
Ok, I'll let HaRR do Snake/MM, since I can't remember him doing any
other one recently. DP also can do Sonic/Crono if it happens.<br><br>That leaves Samus/Tifa and Zelda/Yuna<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sonic vs. Luigi - Bracket: <b>Sonic</b> - Vote: <b>Sonic</b> (80/88)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/5/2006 4:43:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345550609">message detail</a>
 | #240</td></tr>
<tr class="even"><td>
Sora..............................45.72% 61167<br>Mega Man....................54.28% 72630<br>TOTAL VOTES........................133797<br><br>38.87% of the brackets predicted this match correctly.<br><br>Ah
yes, it wouldn't be a contest without horrible bracket support for Mega
Man. Speaking of MM, he didn't look so good against Sora here. Sora
gets 46% on MM, so either he's boosted up to Ganondorf and Vincent's
level, or MM has fallen.<br><br>Today, Sonic is doing a tad better than expected against Luigi.<br><br>KH - 10<br>Moltar - 10<br>HM - 9<br>Lopen - 9<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Ulti - 7<br>Yoblazer - 5<br><br>HM had the lowest MM pick...<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sonic vs. Luigi - Bracket: <b>Sonic</b> - Vote: <b>Sonic</b> (80/88)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 11/5/2006 6:54:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345583418">message detail</a>
 | #241</td></tr>
<tr class="even"><td>
I will fight you to the death for Samus/Zelda Ashe.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 11/5/2006 6:59:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345584692">message detail</a>
 | #242</td></tr>
<tr class="even"><td>
No, you won't. I'm being generous enough as it is in that I'm letting you take Zelda/Crono.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=395700" class="name">HaRRicH</a> |
Posted 11/5/2006 7:30:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345592512">message detail</a>
 | #243</td></tr>
<tr class="even"><td>
...EC needs Samus/Zelda though, mainly because he's not going to **** Board 8 over with his prediction.<br>---<br>Diddy did it.  Diddy did it.<br>DAMMIT!  What didn't Diddy do?!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3124464" class="name">nintendogirl1</a> |
Posted 11/5/2006 7:41:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345595504">message detail</a>
 | #244</td></tr>
<tr class="even"><td>
DUN DUN DUN!<br><br>*Appearance of random lurker*<br><br>I'll do Samus/Tifa!<br>---<br>Why not?
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3124464" class="name">nintendogirl1</a> |
Posted 11/5/2006 9:10:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345620695">message detail</a>
 | #245</td></tr>
<tr class="even"><td>
And written and typed nice and early in case I couldn't get on the computer again before it needs to be in.<br>---<br>Caution is good.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3124464" class="name">nintendogirl1</a> |
Posted 11/5/2006 9:11:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345620843">message detail</a>
 | #246</td></tr>
<tr class="even"><td>
That should be written and sent.<br>---<br>Damned lack of thought.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/5/2006 9:19:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345623542">message detail</a>
 | #247</td></tr>
<tr class="even"><td>
<i>From HaRRicH</i><br><i>...EC needs Samus/Zelda though, mainly because he's not going to **** Board 8 over with his prediction.</i><br><br>Because I ****ed Board 8 over with my other Zelda prediction.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/5/2006 9:31:23 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345626889">message detail</a>
 | #248</td></tr>
<tr class="even"><td>
<b>Time Division:</b> <i>Round 3 - Match 56</i> &#8211; (1)Crono vs. (3)Auron <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Crono</b><br>Round 1 &#8211; 74.16% vs. Capt. Falcon (25.84%)<br>Round 2 &#8211; 57.44% vs. Bowser (42.56%)<br><br>Crono does better than expected against Bowser<br><br><b>Auron</b><br>Round 1 &#8211; 64.40% vs. Alucard (35.60%)<br>Round 2 &#8211; 59.63% vs. Sub-Zero (40.37%)<br><br>Looks like Sub-Zero wasn&#8217;t as weak as some thought.<br><br>Ouch,
with Crono exposing Bowser, that was certainly the final nail
concerning his status. He was overrated. Crono also hasn&#8217;t seemed to
have lost a step last year.<br><br>How about Auron? Well, he looked
good against Alucard, and not so much so against Sub-Zero. It seems
that for having one of the biggest cameos in KH2, he hasn&#8217;t changed
much from last year. Not to mention, this makes Alucard look pretty
bad. Wonder what happened to him? <br><br>Anyway, this is a good match
to see where Auron lies. We haven&#8217;t gotten a good read on him in
forever. Yeah, even though both characters are Square, I don&#8217;t expect
anything fishy in this match. Not much more to say here, really&#8230;<br><br><b>Moltar&#8217;s Bracket Says:</b> Crono will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Crono: 58% - Auron: 42%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br> <br>Crono/Kefka,
Crono/Magus, Crono/Vincent, and now Crono/Auron. 4th year in a row
where Crono faces a Square character in an easy to call match that
won't tell us a damn thing. Unless Auron does well, because then we'll
just assume a constant Crono and a massive boost from the other side
like we did with Vince &lt;_&lt;<br><br>And don't laugh, because that
paid off in the Ganon match. Anyway, uh... Auron has been behind SFF
all three contests prior, so stats mean little here. Auron will
probably do a mite better than 40%.<br><br>Prediction: Crono with 59.85%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br><b>Crono</b><br><br><i>Previous Matches:</i><br><br>Crono &#8211; 74.16% -- 84,090<br><br>Captain Falcon &#8211; 25.84% -- 20,306 <br><br>Crono &#8211; 57.44% -- 68,821<br><br>Bowser &#8211; 42.56% -- 50,986 <br><br><b>Auron</b><br><br><i>Previous Matches:</i><br><br>Auron &#8211; 64.4% -- 74,808<br><br>Alucard &#8211; 35.6% -- 41,357 <br><br>Auron &#8211; 59.63% -- 80,252<br><br>Sub-Zero &#8211; 40.37% -- 54,325 <br><br>Crono did away with any idea that he was going to get upset <i>this</i>
contest by any non-Noble Nine character after taking care of Bowser
without much trouble. Auron put up some rather disappointing numbers
against Sub-Zero, at least as far as I&#8217;m concerned because I <i>so</i> wanted the doubling! <br><br>Looking at the stats, this match might seem pretty uninteresting with Crono taking it easily with 60%+. <i>However,</i> Auron is a bit underrated in the stats <i>and</i>
it doesn&#8217;t take into account his new Kingdom Hearts II boost. Although
the possibility for SFF remains here, I doubt we&#8217;re going to see much
simply because of the two generation gap between them. <br><br>Auron
should be pretty impressive here, but I don&#8217;t think there&#8217;s much of a
chance at him pulling off any kind of crazy upset. He&#8217;s been looking
pretty good in this contest, but not <i>that</i> good. For now, it
looks like the Noble Nine held strong this year despite having some
damn fine competition. Auron will take a respectable loss here. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Crono<br><br><b>Aitch Emm&#8217;s Prediction:</b> Crono &#8211; 56% ; Auron &#8211; 44%<br><br><b>Aitch Emm&#8217;s Vote:</b> Auron<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Crono wins, I suppose. By how much, NO ONE KNOWS. Hahahaha Sorry.<br><br>My prediction: Crono def. Auron (59-41)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>This
match doesn't seem too interesting either. I guess we'll finally get a
read on how much Auron boosted from Kingdom Hearts 2, though. I'm not
thinking there's a big boost, myself, but anyway... it's time for more
percentage calling.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/5/2006 9:31:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345627015">message detail</a>
 | #249</td></tr>
<tr class="even"><td>Now, people will think because Master Chief got
38% on Crono last year that Auron will do better than that? Well, I'm
not so sure he does. Auron's strength advantage is nil in a match vs. a
noble niner because <i>Master Chief is a freak</i>. Therefore last year Auron probably about matches what Master Chief did against Crono, that's what I'm saying.<br><br>Then
there's this "KH2 boost" thing and yearly fluctuation, and I'm just
thinking Auron's getting somewhere between 35% and 45% on Crono. Yeah,
I can't lose.<br><br><b>Lopen's prediction:</b> Crono with between 55 and 65%.<br><br>&#8230; what? Not good enough for you? You want more precision? Well, I need to warm up first. Let's analyze just a bit more!<br><i>*Marle
annoyingly walks down an annoying street, annoyingly skipping, and she
annoyingly approaches Auron, who looks visibly annoyed*</i><br><b>Marle:</b> Hi, wha&#8230;<br><b>Auron:</b> FAREWELL!<br><i>*Auron blows Marle away with Shooting Star*</i><br><br>Ahh&#8230; excellent.<br><br><b>Lopen's prediction:</b> Crono with 58.14%<br><br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>CRONO</b><br><br><i>"..."</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 7th Place [37.43%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 6th Place [38.14%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 5th Place [37.18%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 6th Place [36.54%]<br><br>Crono does a number on Bowser last round, making him either look<br>decently overrated or implying a bit of a Crono boost. Since I have<br>him taking the main bracket, you know what this means <i>!!</i> WOO<br>CRONO<br><br><b>AURON</b><br><br><i>"Now!
This is it! Now is the time to choose! Die and be free of pain or live
and fight your sorrow! Now is the time to shape your stories! Your fate
is in your hands!"</i><br><br>Summer 2003 Contest<br>Extrapolated Strength --- 20th Place [27.80%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 20th Place [27.38%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 22nd Place [28.30%]<br><br>Auron
seems to have a tougher than expected fight against Sub-Zero, and with
no excuses that MC's linearity would have given. Though he still did
significantly better than the stats say, I suppose! WOO AURON<br><br><i>Notable Releases Since Last Appearance</i><br><br>Crono: N/A<br>Auron: Kingdom Hearts II (PS2)<br><br><i>Upcoming Releases</i><br><br>Crono: N/A<br>Auron: N/A<br><br>Just
another stepping stone to the Sonic/Crono clash, of course. Sonic is
doing pretty well against Luigi today, so Crono needs to put on a show
and show, once again, that he is a consistent beast here. Honestly,
does <i>anyone</i> expect any weakness out of Crono by now?<br><br>Karma Hunter's Vote: Auron. <i>Farewell.</i><br><br><b>Karma Hunter's Krazy Prediction: Crono with 57.65%.</b><br><br>Coupled with my wishful thinking of a Crono boost and a nice gain for Auron from KH2, this is what we get here. Sah-weet!<br><br>Upset Potential: 5%<br><br>Y'know,
in terms of straight stats Auron is projected to give Crono a really
tough fight. KH2 and possible rSFF could allow him to pull it off!<br><br>lol master chief<br><br>Upset Prediction: Auron with 50.28%<br><br><br> <br><b>Guest&#8217;s Analysis</b> - <i>Luis_Sera89</i><br><br><b>Crono</b><br><br>Round 1: Beat Captain Falcon with 74.16%<br>Round 2 : Beat Bowser with 57.44%<br><br>Crono
looked as consistent as ever in his opening two matches this contest,
beating Falcon of F-Zero and SSB fame with similar numbers that would
be expected against Ness, then never looking in any danger against one
of the success stories of 2k5 Bowser, in a match that a certain
bandwagon of users were predicting to be close.<br><br><b>Auron</b><br><br>Round 1: Beat Alucard with 64.40%<br>Round 2: Beat Sub Zero with 59.63%
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/5/2006 9:32:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345627330">message detail</a>
 | #250</td></tr>
<tr class="even"><td>
Auron started impressively, blowing away Alucard in an utterly
dominating display, indicating that the katana wielding badass may just
be one of the biggest beneficiaries of KH2F, as well as continuing his
run of victories in the low to mid 60&#8217;s range in first round matches.
However in his surprise second round match up against Mortal Kombat&#8217;s
Sub Zero, it seemed he dropped a ball in a contest that people were
thinking would be even more crushing. Sub Zero as strong as a 2k5 Frog
assuming a constant Auron, as well as performing almost 5% better than
Alucard? Either Subbie a lot stronger than we gave him credit for,
Auron&#8217;s old timer pic really hurt him or he just plain aint gonna be
troubling the near elites quite yet.<br><br>This
match isn&#8217;t about whether Crono&#8217;s Elite Eight appearance is under
threat, but rather how Auron places in the group of characters
including Bowser, Tifa and Dante. Interestingly, Crono&#8217;s last match
against Bowser should provide a good indication of just where he places
in said group, and if he indeed cracks 42.66% he&#8217;s doing very well for
himself indeed.<br><br>Crono exceeded X stat expectations against
Bowser based off of last years standings, but of course that was a
trail blazing Bowser hot off of going 50/50 against Solid **** and
looking the favourite for the Holy Grail of 10th strongest character.
It turned out to be all about just how overrated he would be, ending up
as a respectable 1.5%ish, saving face for the Koopa King. Most
importantly, Crono&#8217;s long awaited drop seems to have skipped a year
once again, and he seems to be on his way to the main bracket finals
for the second year in succession for a hotly anticipated match up
against Samus Aran.<br><br>One thing I know I am taking into
consideration is how much SFF, if any at all we will be witnessing.
Crono has faced Square&#8217;s Kefka, Magus, Zidane and Vincent in the past.
Of those, one is from his own game, one was untested and one was from
FFVII. Only Kefka seemed to perform below expectations, although it was
by a fairly significant 7/8%. So what of Auron? As of 2006, FFX has
never seemed to hold up well against stronger Square games, Auron
himself suffering the wrath of Cloud and Sephiroth in 2k3 and 2k4
respectively.<br><br>Based on last years X-stats:<br><br>Crono (2005c) VS Auron (2005c)<br><br>Crono has a strength of 39.87.<br>Auron has a strength of 30.88.<br><br>Crono wins with 61.27% of the vote!<br>A win of 21,366 with 94,756 total votes cast.<br><br>Adding
in a 1.5/2% KH2 boost for Auron, and accounting for the potential
double SFF from being behind both Samus/Ganon and Mario/Samus, that
will go someway to negate any SFF Crono may get on him, and so I don&#8217;t
expect Crono to be 60/40ing Auron.<br><br>It&#8217;s all down to Auron to
prove just how much he&#8217;s gained on the rest of the pack this year, and
for Crono to silence the Sonic/Mega Man/Snake crowds.<br><br><b>Luis&#8217; prediction: Crono with 58.79%</b><br> <br> <br> <br>Crew Consensus: Crono wins in the mid-to-high 50's...just like nearly every other round 3 match.
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=3">4</a></li>
<li>5</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=9">10</a></li>
</ul>
</div>


</div>
<img src="genmessage5_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage5_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31382187&amp;page=4" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage5_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>