<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage10_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage10_files/nogs.css"></head><body linkifytime="321" linkified="3" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage10_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage10_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31382187%26page%3D9"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div class="ad" style="text-align: center;">
<div style="text-align: center;"><img src="genmessage10_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage10_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage10_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 4
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;page=9">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31382187" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=8">Previous Page</a> |
Page 10 of 10
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/11/2006 9:41:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346994628">message detail</a>
 | #451</td></tr>
<tr class="even"><td>
<i>I would assume it would be for the percentage of the loser (and who
the loser is), since that's the only thing that matters. Up until the
final day, of course.</i><br><br>Sounds good to me! Not too big on the elimination.<br><br>Also,
HaRR, would you like to write for the Finals? I know I said Leon could
do it before, but he did a number on Ulti's Snake/Sonic write-up, and
it'd be cool to see another former Crew member who was unfairly booted
get to write for a huge match up.<br><br>Oh, and no Guest write-ups for the BR.<br>---<br>Moltar Status: 17th on the leaderboard! Go my alt!<br>Samus vs. Zelda - Bracket: <b>Samus</b> - Vote: <b>Samus</b> (104/128)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=981127" class="name">Cavalier Lowen</a> |
Posted 11/11/2006 9:43:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346995005">message detail</a>
 | #452</td></tr>
<tr class="even"><td>
<i>Oh, and no Guest write-ups for the BR.</i><br><br>BOO<br>---<br>Z1mZum owned me in the guru contest (by two points!).  Damn you Z1mZum!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/11/2006 9:44:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346995268">message detail</a>
 | #453</td></tr>
<tr class="even"><td>
Moltar, I'll send it in shortly. :x<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/11/2006 10:23:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347004708">message detail</a>
 | #454</td></tr>
<tr class="even"><td>
Sorry about taking so long. Sent and stuff.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/11/2006 10:23:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347004797">message detail</a>
 | #455</td></tr>
<tr class="even"><td>
i need writeups <i>now</i><br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/11/2006 10:25:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347005156">message detail</a>
 | #456</td></tr>
<tr class="even"><td>
<b>Final Four:</b> <i> Match 62</i> &#8211; (1)Solid Snake vs. (1)Sonic<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Snake</b> - <i>The injection of badass in the Final Four</i><br>Round 1 &#8211; 82.15% vs. Soma (17.85%)<br>Round 2 &#8211; 57.59% vs. Squall (42.51%)<br>Round 3 &#8211; 57.16% vs. Yoshi (42.84%)<br>Round 4 &#8211; 55.33% vs. Mega Man (44.67%)<br><br>Snake just walks all over Mega Man<br><br><b>Sonic</b> - <i>The injection of iconic figure who ruined brackets in the Final Four</i><br>Round 1 &#8211; 80.75% vs. CATS (19.25%)<br>Round 2 &#8211; 52.09% vs. Vincent (47.91%)<br>Round 3 &#8211; 60.19% vs. Luigi (39.81%)<br>Round 4 &#8211; 50.77% vs. Crono (49.23%)<br><br>Sonic comes back and takes the victory from Crono<br><br>Well,
it&#8217;s rare when it&#8217;s so late in the bracket, and no one can predict
what&#8217;s going to happen next. A lot of the board members picked Mega Man
and Crono to win their matches, but instead, we have the two underdogs
of the Noble Nine, Snake vs. Sonic right here. What a ride&#8230;.or should I
say, <b>LET&#8217;S ROCK!</b><br><br>Now, Snake has just looked dominant up
until this point. I don&#8217;t think I need to go over his first three
victories again, but let&#8217;s look at his match against Mega Man. That&#8217;s
55% on the guy who beat him with 56% only 2 years ago. Mega has fallen
ladies and gentlemen. The real question is by how much, and also how
much did Snake boost? It was a combination of the two that gave Solid
the victory. For fun, let&#8217;s try and predict Mega and his opponents
place in the stats to see how much Snake has boosted (oh and I&#8217;m
rounding, yay rounding!).<br><br>If Mega has fallen to 36% on BL, that
puts Snake at nearly 40%, Sora at 33.48% (right under the Top 15), Ryu
at 30.25% (slightly above his 2005 value), and Axel at 21.60% (which
puts him around where Kairi may fall). None of those seem too
farfetched to me, but there&#8217;s a problem. Crono is at 39.87% on BL, and
Sonic beat Crono&#8230;<br><br>So if Crono flucuated a little down, and Sonic
flucuated a little up, that puts Snake and Sonic (along with Samus)
very close to each other. I&#8217;m telling you, this is an extremely
exciting end to the bracket we have awaiting us. Now, I&#8217;m going to say
Snake is the slight favorite going into this match. He has bracket
support, along with everything else mentioned before. Sonic has his
status and all, and that should make this very close. I mean, if Crono
would have won, I probably would have given Crono the nod, but I&#8217;m
going Snake &gt; Sonic. Eh, it just feels right.<br><br><b>Moltar&#8217;s Bracket Says:</b> Crono (bleh) will win, but the alt bracket has Snake.<br><br><b>Moltar&#8217;s Prediction is:</b> Snake: 51% - Sonic: 49%<br> <br> <br><br><b>Ulti&#8217;s Analysis?</b><br> <br>Yeah, this is totally UltimaterializerX and not Leonhart posing as him because he&#8217;s not able to get his prediction in on time! <br><br>Before
the contest, these two were viewed as the weak links of the Noble Nine.
After all, they were the only two that had never beaten a fellow Noble
Niner, but this year, they&#8217;ve overcome the hurdles that had hindered
them before and turned the inequality signs around. Very few people on
Board 8 gave either of these two a shot at being here, much less BOTH
of them, but lo and behold, here they are fighting for a spot in the
finals against Samus Aran. <br><br>First of all, let&#8217;s take a look at
Solid Snake. He&#8217;s perhaps been the most consistently impressive
character this year. He has yet to allow anybody to break 45% on him.
Not even Mega Man could do it. Every time it looked like there was an
opportunity that he might falter, Snake not only met expectations, he
far surpassed them.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/11/2006 10:26:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347005265">message detail</a>
 | #457</td></tr>
<tr class="even"><td>In the first round, people were expecting Soma
Cruz to be close to the fodder line. Solid Snake shut those people up
really quickly by beating him worse than Samus beat Nidoran F (Snake
&gt; Samus, yo! Come on, who&#8217;d seriously take Nidoran F to beat Soma
Cruz?). Then, with potential Noble Nine breaker Squall Leonhart
stepping up to the plate, Snake makes easy work of him, seemingly
pulling an overperformance similar to what happened in 2002. After all,
there&#8217;s no way Snake could be THAT strong, right? That would make him a
threat to Samus! <br><br>Even
when Snake&#8217;s worst enemy, the sprite round, reared its ugly head (or
Snake reared his ugly sprite, whichever), he still managed to breeze
past Yoshi with over 57%. At this point, people are starting to wonder
if he can overcome his two-time nemesis, Mega Man, especially after the
Blue Bomber throws out a dud against Sora. After all, he had lost with
over 57% just two years ago. That wouldn&#8217;t be easy to turn around,
right? <br><br>Apparently, it was pretty easy. Solid Snake not only beat Mega Man, he embarrassed him, holding him to <i>seven</i>
five-minute update wins the entire match, none of them during what was
supposed to be his horrible day vote. Assuming a constant Mega Man (LOL
Black Turtle), Snake looks as strong as Mario here. Every performance
has made him look like a potential threat to take it all, but will he? <br><br>That&#8217;s
where Sonic the Hedgehog steps in. At least Solid Snake has casuals
believing he could win the contest. Sonic didn&#8217;t even have that much.
In a pre-contest poll, a measly 11% thought he could win the male
bracket. He did worse than <i>Sora</i>, for cryin&#8217; out loud! Even
though he was projected to have a close match with Crono, people just
couldn&#8217;t get past his stigma as somebody who couldn&#8217;t win a big match
when it counted. After all, he had blown two ideal chances to beat
Samus in 2002 and Mega Man just one year ago. <br><br>First up for
Sonic was contest legend CATS. He easily quadrupled him, but nobody
really thought too much of it. It seemed pretty much like he was
expected to do, especially considering he wasn&#8217;t facing true Face-CATS,
but CATS has this funny thing about facing contest winners! <br><br>After
that came the showdown against Vincent Valentine that few expected
Sonic to lose, but most figured he would probably struggle. Before we
go any further, I have to admit that Sonic/Vincent is probably one of
my favorite match pictures ever. It&#8217;s just awesome. I don&#8217;t know what
was going through CJayC&#8217;s mind when he decided to use generic Microsoft
Powerpoint backgrounds for round 2, but this particular occasion, it
worked. <br><br>Anyway, Sonic went even with Vincent during the night
hours before managing to pull away with his famous day vote and seal
the victory. All in all, he barely broke 52% while Crono broke 55% with
ease last year. Even though Vincent had Dirge of Cerberus between the
two contests, it sucked, so it obviously couldn&#8217;t have done anything
for him, right? Basically, Sonic&#8217;s fate had already been sealed. <br><br>Up
next on the slate was the star of the contest up to this point, Luigi.
After Mario/Shadow 2003, people were wondering if the little brother of
Sonic&#8217;s eternal rival could work a little magic of his own. The Blue
Blur responded to that with a resounding &#8220;NO!&#8221; and beat the green
plumber with over 60%. Despite how impressive Luigi had looked and how
he had seemingly improved since 2005, Sonic managed to beat him by even
MORE than the stats had projected. After Crono did worse against Auron
(who lost to Ganondorf, who lost to Vincent. FOLLOW THE CHAIN!) than he
did against Vincent, people were conceding that he <i>might</i> have a close match with Sonic, but only a few were actually willing to say he would outright win.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/11/2006 10:26:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347005459">message detail</a>
 | #458</td></tr>
<tr class="even"><td>
When the day of the match finally came, Crono jumped out to a big lead
using the powerful Chrono Trigger night vote, and despite all of the
trends, the stats topic was already talking about Snake&#8217;s chances
against the silent hero. The rest of the board was talking about how
Sonic had choked yet again and how he should be kicked out of the Noble
Nine. BUT NOT SO FAST, MY FRIENDS! <br><br>&lt;/Corso&gt; <br><br>Yours truly made a special <b>BOLD PREDICTION</b> the day before this match. <br><br><i> Sir Crono | Posted 11/9/2006 3:15:57 PM | message detail <br><br>BOLD PREDICTION: Sonic makes a big day vote comeback over Crono tomorrow for the win!</i> <br><br>And
with Sonic down 2207 votes to Crono, the comeback began. For the early
morning hours and the early afternoon, Sonic made some decent slices.
As he got closer, we waited to see if something wonky (Whoa! Microsoft
Word spellchecker recognizes this word?!) would happen with the after
school vote to save Crono. As it turned out, Sonic turned the heat up
even higher, as he started getting 55% updates with regularity. When he
took the lead, he didn&#8217;t even bother looking back to see if Crono was
coming. In the end, Sonic had completed the largest successful comeback
in contest history to score his first win over a Noble Niner and his
first ever Final Four appearance. And what a way to do it! That should
go a long way to erase the stigma he had developed over the years. <br><br>Anyway,
as a fervent support of Sonic in the contests, that win felt good, so I
had to devote some time to it. As far as the match at hand is
concerned, it&#8217;s very difficult to say who has the advantage. I posted a
long list of &#8220;What if?&#8221; scenarios to try to determine who the favorite
should be. For the sake of space (as this write-up is already going to
be lengthy), I&#8217;ll just link to it: <br><br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/detail.php?board=585007&amp;topic=31562699&amp;message=346900472" title="Linkification: http://boards.gamefaqs.com/gfaqs/detail.php?board=585007&amp;topic=31562699&amp;message=346900472">http://boards.gamefaqs.com/gfaqs/detail.php?board=585007&amp;topic=31562699&amp;message=346900472</a> <br><br>As
you can see, there really is nothing decisive favoring one character
over the other. If this match isn&#8217;t close, I&#8217;ll be shocked. In terms of
straight up performances this contest, I&#8217;d have to give the edge to
Solid Snake, though if they had swapped places in the bracket, we might
be saying the same thing about Sonic. After all, he did have to face
the strongest non-Noble Niner in round two, who&#8217;s essentially a lock to
be ranked higher than Mega Man in the stats at this point. Plus, he
will EASILY have the bracket votes in his favor, for whatever that&#8217;s
worth. This late in the contest, I do wonder how many will bother still
sticking to their brackets, but if this match is as close as it&#8217;s
looking to be, it might make a difference. <br><br>In terms of overall
intangibles, the advantage probably goes to Sonic. After all, the Blue
Blur is a legend, and we have a better idea of where he stands
relatively since Crono isn&#8217;t looking to have changed much. With Snake,
it&#8217;s hard to say because none of his matches are too conclusive.
Regardless, the match against Mega Man is probably the single most
impressive performance this contest. However, looking at all of those
potential scenarios I posted in the link, I like the ones that favor
Sonic winning moreso than I do the ones that favor Solid Snake winning.
Either way, random variation could just take a crap on all of that
anyway, so it doesn&#8217;t matter much, really. <br><br>In terms of
favorites, I prefer Solid Snake, but for some reason, I always find
myself rooting for Sonic the Hedgehog in these contests. Regardless of
who wins, I&#8217;ll be happy, and I&#8217;ll be even happier if they can beat
Samus! However, if fate holds to form, my Sonic Bracket Curse
(predicting Sonic to go one match farther than he actually does, as I
have him winning the entire male bracket but losing to Samus) will pull
through here and Snake will win.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/11/2006 10:27:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347005544">message detail</a>
 | #459</td></tr>
<tr class="even"><td>I wrote all of this not to give you a prediction!
The percentage here is in fact Ulti&#8217;s, as he texted me on my cell phone
and told me to give the following prediction for Snake/Sonic. I just
decided to be greedy and take advantage of the opportunity to do a
write-up for this match since I can&#8217;t do the official &#8220;Guest Analysis&#8221;
for this match. <br><br><b>Ulti&#8217;s Prediction</b>: Sonic the Hedgehog with 50.96% <br><br>(But if Leonhart had an official prediction for this match, it&#8217;d be <b>Solid Snake with 50.00004%</b>. Closest match EVER? YOU BET!)<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br><b>Solid Snake</b><br><br><i>Previous Matches:</i><br><br>Solid Snake &#8211; 82.15% -- 86,697<br><br>Soma Cruz &#8211; 17.85% -- 19,487 <br><br>Solid Snake &#8211; 57.59% -- 78,314<br><br>Squall Leonhart &#8211; 42.41% -- 57,666 <br><br>Solid Snake &#8211; 57.16% -- 69,085<br><br>Yoshi &#8211; 42.84% -- 51,781 <br><br>Solid Snake &#8211; 55.33% -- 70,163<br><br>Mega Man &#8211; 44.67% -- 56,648 <br><br><b>Sonic the Hedgehog</b><br><br><i>Previous Matches:</i><br><br>Sonic the Hedgehog &#8211; 80.75% -- 87,757<br><br>CATS &#8211; 19.25% -- 20,925 <br><br>Sonic the Hedgehog &#8211; 52.09% -- 64,699<br><br>Vincent Valentine &#8211; 47.91% -- 59,497 <br><br>Sonic the Hedgehog &#8211; 60.19% -- 79,761<br><br>Luigi &#8211; 39.81% -- 52,760 <br><br>Sonic the Hedgehog &#8211; 50.77% -- 64,027<br><br>Crono &#8211; 49.23% -- 62,087 <br><br>Now <i>this</i>
is pretty damn unexpected. I&#8217;m not sure most of us figured that both
Snake and Sonic would be here in the Male Bracket Finals after having
beaten Mega Man and Crono, respectively. These two getting here also
means that every Noble Nine character has beaten another fellow Noble
Nine character before! It&#8217;s especially good to see that Sonic got over
the hump of being known as a &#8220;choker&#8221; against the Noble Nine after his
very impressive swing of about 4,000 votes total. <br><br>This match,
to me, is just about as dead even as you can possibly get. Snake has
been dominating throughout this contest beating opponent after opponent
with little trouble. Sonic has taken down some impressive people this
contest himself &#8211; Vincent, Luigi, and Crono. I&#8217;m not sure where the
advantage lies &#8211; perhaps in the brackets which favor Snake &#8211; but I do
know that whoever wins shouldn&#8217;t do it by very much at all. <br><br>Snake
and Sonic have always seemed to bring up the rear of the Noble Nine; in
2003, it was Sonic, but in 2004, it was Snake. It was Snake again in
2005. Since their performances to me are <i>so</i> split, I&#8217;m going to
give Sonic the edge here simply because he&#8217;s consistently ranked higher
than Snake with the exception of one year. Sure, this Snake looks quite
different from any previous one we&#8217;ve seen &#8211; but Sonic looks like his
strongest yet as well. <br><br>This match should be a worthy
conclusion to the male bracket and set up for a fantastic final against
Samus. Man, this contest has been just <i>awesome</i> all around.  <br><br><b>Aitch Emm&#8217;s Bracket:</b> GANONDORF BELIEVE<br><br><b>Aitch Emm&#8217;s Prediction:</b> Solid Snake &#8211; 49.5% ; Sonic the Hedgehog &#8211; 50.5%<br><br><b>Aitch Emm&#8217;s Vote:</b> &#8230;Sonic for Ganon!<br><br> <br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br><br>You
know, I've realized something over the past couple of days. Even with
mass shake-ups, great matches, and one of my favorite characters ever
battling it out for the male title, when my bracket is broken, I just
don't care nearly as much. I've barely checked the Stats Topic or the
match updates all day, and it leads me to wonder what in the Sam Hills
the other guys in there are talking about. Probably this match! Yep,
that must be it. This is a fantastic final four match, and I'm sure
I'll receive a nerdy jolt of energy as soon as I F5 and see the picture
change.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/11/2006 10:27:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347005677">message detail</a>
 | #460</td></tr>
<tr class="even"><td>The first thing that strikes me about this match
is the irony of the whole thing. For years, we have basically regarded
it as law that Sonic the Hedgehog and Solid Snake were the two weakest
Noble 9 members. They were, of course, the group's lone two members who
were winless against the rest of the Noble 9. How awesome is it, then,
that both of them had to beat out other N9 members just to get here?
Fantastic, truly is. So, they're both here, and they've both overcome
some huge hurdles, but it sure ain't over yet. One of these two will go
on to face Samus Aran in the contest finals, while the other will have
to spend a year thinking of the glory he let slip through his fingers.
Who will move on? Whose cuisine reigns supreme?<br><br>It's
almost impossible to say who, if either, have the upper hand. For
starters, both of looked damn good. In addition, most of their matches
are riddled with questions. How far did Mega Man drop? How high did
Vincent boost? Was there SFF in Snake/Squall? Was there SFF in
Sonic/Luigi? How did Snake's sprite affect him? The list goes on and
on. Good arguments can be made for both characters, and the guy who
flips a coin has as good a chance calling this correctly as the guy who
spends hours in thought.<br><br>So, who am I taking? I think anyone who
knows me knows the answer. While Sonic has had a great tournament thus
far, Snake has been the star. He's had four matches and has
overperformed four times. He disposed of fodder the way you're <i>supposed</i>
to dispose of fodder. He surprised many versus Squall. He brushed off
an asstastic sprite and kicked the crap out of Yoshi. And then, to top
it all off, he avenged two prior losses and absolutely humiliated Mega
Man. Before stepping onto center stage every time, he has turned
around, looked at the board, and said "Colonel, what do you mean??"
which, roughly translated, means "I'm going to win this ****."<br><br>Don't forget to scan that cardboard box, Ms. Aran.<br><br>My prediction: Solid Snake def. Sonic the Hedgehog (52-48)<br><br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Well,
I know you've all heard it before&#8230; Mega Man hasn't lost a step! And he
hasn't! I refuse to believe it. With the exception of Solid Snake's
match, Mega Man didn't disappoint me this year! Nope! So why then, is
Snake here?<br><br>Massive Snake boost.<br><br>Trust me, man. It's a
boost, it's massive. It's possibly because of his NEWCOMER status,
possibly because of something else. Probably both! Snake has been on a
roll this year: ain't no one gonna stop him. If Mega Man can't
GRACEFULLY beat Snake, no one can. I stand by that.<br><br>Seriously though. Look at the matches. Has Mega Man really looked <i>that</i>
much worse than Sonic or Crono this year? 54% on Sora isn't looking as
good as 54% on Auron, that's true. But how true? Could Sora be near
elite at this point? Well, I don't think it's out of the question. I
point you again to Riku/Yoshi&#8230; Riku did well against Yoshi. Sora should
be stronger than Riku. Yoshi's a near elite and did fairly well against
Snake.<br><br>But then again, both of em are extrapolated through
Snake. So I don't know what I'm trying to prove with that. Maybe Snake
pulled something fishy on Mega Man? I don't know if I'd go that far.<br><br><br>Maybe
I'm still in denial about Mega Man dropping that far. Maybe I'm wrong
and Sonic will make this a match? I'll believe it (or disbelieve it <i>even more</i>)
after this match. I honestly hope I'm wrong here, an anti-climatic male
bracket final would be a real bummer. I feel funny pulling for Sonic
here, since I at least <i>claim</i> to like Snake more&#8230; but I would
really rather him win this! But anyway, that's not important to my
analysis, right? Right. I don't drive my analyses on hope&#8230; Snake should
win this without too big a struggle&#8230; I stand by that!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/11/2006 10:28:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347005767">message detail</a>
 | #461</td></tr>
<tr class="even"><td>
So uh&#8230; Sonic&#8230; you'd better win in a close one, or you better lose hard to make Mega Man look good. Okay?<br><br>And just for good luck: <a class="linkification-ext" href="http://i24.photobucket.com/albums/c38/NeoX-Death/CFvMarle.jpg" title="Linkification: http://i24.photobucket.com/albums/c38/NeoX-Death/CFvMarle.jpg">http://i24.photobucket.com/albums/c38/NeoX-Death/CFvMarle.jpg</a>. Kill that enemy of everlasting peace, Sonic!<br><br>&#8230; that analysis felt so random... and indecisive, too! <i>I'm sorry!</i><br><br><b>Lopen's Prediction:</b> Solid Snake with 53.99%<br><br><br> <br><b>KH&#8217;s Analysis</b><br> <br>lol x-stats history<br><br><b>SOLID SNAKE</b><br><br><i>"A name means nothing on the battlefield."</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 9th Place [35.23%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 8th Place [34.74%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 12th Place [30.82%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 9th Place [33.88%]<br><br>And
continuing his string of incredible performances, Snake does what NO
ONE thought he could do. Screw not letting a non-Noble Niner crack 45%
on him, he doesn't let MEGA MAN crack 45% on his ass.<br><br>One vicious beatdown en route to getting over the hump later, and Snake's two matches away from winning the contest. <i>From winning the contest.</i><br><br>Don't stop now!<br><br><b>SONIC THE HEDGEHOG</b><br><br><i>"What can I say? I die hard."</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 5th place [41.05%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 10th place [34.92%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 8th place [33.56%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 8th Place [35.28%]<br><br>And
Sonic puts the demons of his past to rest likewise, getting over the
hump and destroying my bracket by defeating the man who once went
toe-to-toe with Mario, Crono! And with such great victories on both
ends, this match is one hell of an unpredictable sucker. May the best
character win.<br><br>(i.e. Solid Snake)<br><br><i>Notable Releases Since Last Appearance</i><br><br>Solid Snake: Metal Gear Solid 2: Subsistence (PS2), Super Smash Brothers Brawl Trailer (Internet)<br>Sonic the Hedgehog: Sonic Rush (DS)<br><br><i>Upcoming Releases</i><br><br>Solid Snake: Metal Gear Solid 4: Guns of the Patriots (PS3), Super Smash Brothers Brawl (WII)<br>Sonic the Hedgehog: Sonic the Hedgehog (PS3, X360), Sonic and the Secret Rings (WII)<br><br>How
funny. Last year, my #1 (Snake) and #2 (Mario) character faced off in
the Final Four. I was immensely pleased with that match, as Snake did
very well on Mario and put those who had been calling for his head that
year in their place.<br><br>This year, my #1 (Snake) and #3 (Sonic)
character are facing off in the Final Four. Except this time, the only
way that I'll be truly pleased is if Snake pulls the win here -- and
he's got a damn good shot at it.<br><br>In fact, unlike in the Mega Man
match, I'm calling him the favorite here. Despite the fact that Mega
Man had been underwhelming prior to being blasted away by Snake, it's
still <i>Mega Man.</i> When I gave my prediction last time I did it
being fully aware that such numbers would make him the favorite to take
the main bracket in my eyes (hence the tagline). Snake outdid them
significantly. Mega Man could simply suck EVEN MORE, but I'm not buying
it.<br><br>Other than that, it's the same pluses for Snake that he's
had so far. He's looked extremely impressive in every match -- the only
one that can really be construed against him is Yoshi, and really, I've
seen Snake in the sprite round enough to actually consider that
performance impressive. And, again...not letting MM crack 45% is no
joke.<br><br>Sonic can win this, but I feel good calling Snake the favorite. He deserves it, and hopefully he doesn't stop his run now.<br><br>Karma Hunter's Vote: <b>VOTE SNAKE</b><br><br><b>Karma Hunter's Krazy Prediction: Solid Snake with 53.35%.</b><br><br>Let's see if this prediction works this time around!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/11/2006 10:28:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347005880">message detail</a>
 | #462</td></tr>
<tr class="even"><td>
<b>Upset Potential: 0%<br><br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br><br>But
unlike Mega Man, Sonic's been impressive in his own right this year. A
big win over CATS, a convincing margin over the toughened Vincent,
blowing away Luigi and edging out Crono. This is a stronger Sonic --
and while he doesn't look as improved as the toughened Snake, he
doesn't need to be seeing as how he already had the head start to begin
with.<br><br>Really, we can only rely on stats so much here. Sonic
making Snake look worse than Vincent wouldn't surprise me (though it
would certainly sadden me), and Snake could whip him just as easily.
This is what the contest was like back in 2002, and it's fantastic &#8211;
just grab on to something, hold on, and root for your favorites right
down to the wire!<br><br>The match we've been calling for since the Noble Nine's invention is here -- and here like no one expected!!!<br><br>Upset Prediction: Sonic the Hedgehog with 50.32%<br><br><br> <br><b>Guest&#8217;s Analysis</b> - <i>Lady Ashe</i><br><br>It
is time... The male competitors have fought amongst themselves in a
great struggle to determine who is the greatest of them all, and it is
down to two. Solid Snake is the first of these two masterful men. He is
the fan favourite to win the contest, but few of those higher ups saw
his ascension to the top tier of male competitors coming. The other of
these titans is Sonic the Hedgehog. He shocked everybody by defeating
the insider favourite to win the whole thing this year. Snake's match
was rather anti-climatic, while Sonic's match had the largest vote
swing ever in these contests. Will this one be a nail-biter or will it
be another solid victory? Let's take a more in depth look at the
competitors!<br><br>Solid Snake has been looking pretty dominant this
contest, and aims to keep that up on his way to the Battle Royale. In
the first two rounds he performed much better than expected against
Soma Cruz and Squall Leonhart, and in the third round he did the same
despite having one of his famous Solid **** pictures. Those matches
aren't as important at this point, though. What <i>is</i> important is
his match last round against Mega Man. Snake absolutely destroyed Mega
Man, with a difference in percentage of nearly 11%. That's just
ridiculous. It's not even funny. If the previous matches in this
contest are anything to go by, Snake looks set to take this one with
ease.<br><br>However, this year's previous matches aren't all that
there is to work with here. It is pretty obvious that Snake has boosted
here, although the extent of this is yet to be determined. In addition
to this, Snake should receive another boost from FFXII. It is pretty
commonly accepted by now that Snake has some sort of SFF with Final
Fantasy characters, and FF characters are all getting a nice boost from
their newly released game. This can be seen by looking at Tifa/Samus
and Yuna/Zelda, so if the trend of MGS/FF SFF keeps up Snake should be
getting a fair amount of extra votes in this match against Sonic.<br><br>On
the other hand, Sonic hasn't been looking too shabby himself. In the
first round he put up a great performance on CATS, who is sometimes
viewed as the best value for predicting the winner of the contest. He
seemed to have lost his step a bit in the second round against Vincent,
but Vincent starred in a new game and was in a popular movie since the
last contest, making Sonic's performance look better than some had
originally thought. His third round performance wasn't anything
noteworthy on either end, but his fourth round match against Crono was
one that barely anybody saw coming. He managed to defeat one of the two
primary competitors for the main bracket, dominating from the moment
the morning hit and never letting up. Snake may have looked fabulous in
the previous rounds, but Sonic has certainly been no slouch himself.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/11/2006 10:29:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347006087">message detail</a>
 | #463</td></tr>
<tr class="even"><td>What does Sonic have going for him heading into
this match? He seems to have received a rather large boost to be able
to defeat a character that smashed Auron fresh off of Kingdom Hearts 2.
This certainly isn't as significant as the boost that Snake received
from SSBB hype and FFXII combined, but it doesn't have to be when one
considers the fact that Sonic was ahead of Snake in the x-stats last
year. Sonic looks to be at a disadvantage here, but it isn't a major
one and so more analysis needs to be done to determine a winner!<br><br>What
does all of this mean? Well, both of these characters have had
admirable performances up to this point, with Snake looking slightly
more impressive. They have both boosted, although Snake has most likely
boosted to a higher degree. Toss in the fact that Sonic was stronger
than Snake last year, and it looks like we're going to have a nice
50/50 split. Making the reasonable assumption that Mega Man and Zero
dropped at the same rate doesn't help this predicament at all, as that
also results in a 50/50 split. However, I am forced to make a call and
based on Snake's impressing with the day vote yesterday, I'm going to
have to go with him. It's close though, and I wouldn't be at all
surprised if Sonic managed to pull out the win.<br><br>My prediction? Snake with 51.42%.<br> <br> <br> <br>Crew
Consensus: Whew, if you managed to slug through that, good for you! For
the lazy, the Crew favors Snake 5-2 in this close, exciting match.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/11/2006 10:30:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347006203">message detail</a>
 | #464</td></tr>
<tr class="even"><td>
Man, that guest writer is a lock for the point!<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/11/2006 10:30:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347006302">message detail</a>
 | #465</td></tr>
<tr class="even"><td>
Ulti going against Snake? Against <i>Sonic?</i> Hell hath frozen over, indeedy.<br><br>Plus, that writeup was way too lengthy and gracious toward Sonic to pass for his. &lt;&lt;<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/11/2006 10:34:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347007124">message detail</a>
 | #466</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>LETS GO SONIC *clap clap clapclapclap*<br><br>I'll
be damned if Sonic beats Crono, but then loses to Solid Snake. Nope, no
way, not gonna happen. Sure, Snake kicked more ass last round, but Mega
Man is certainly weaker than Crono. The only problem is that Snake has
a better chance against Samus than Sonic does, I think. Oh well, I'll
gladly settle for male bracket champ.<br><br>My vote: Sonic<br>My bracket: Crono<br>My prediction: Sonic with 50.40%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=395700" class="name">HaRRicH</a> |
Posted 11/11/2006 11:39:09 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347022359">message detail</a>
 | #467</td></tr>
<tr class="even"><td>
Thank you MM, but on such short notice I believe I'll pass and let somebody else take it.  Again, thanks though.<br>---<br>Diddy did it.  Diddy did it.<br>DAMMIT!  What didn't Diddy do?!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 11/12/2006 12:42:54 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347034483">message detail</a>
 | #468</td></tr>
<tr class="even"><td>
I'll take the finals if theyre open &gt;_&gt;;<br>---<br>Despite Karma Hunter's warnings, I doubted what should have been obvious to all. Only the Snake is the true hero! <b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/12/2006 12:43:56 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347034643">message detail</a>
 | #469</td></tr>
<tr class="even"><td>
Wait, Lopen went higher than me? DAMN IT.<br><br>I move to retroactively move my percentage higher plz. Out of <i>principle.</i><br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=981127" class="name">Cavalier Lowen</a> |
Posted 11/12/2006 12:47:50 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347035220">message detail</a>
 | #470</td></tr>
<tr class="even"><td>
I'll take the final if it's cool with everyone...<br>---<br>Z1mZum owned me in the guru contest (by two points!).  Damn you Z1mZum!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=254355" class="name">Lugia2</a> |
Posted 11/12/2006 6:27:14 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347062652">message detail</a>
 | #471</td></tr>
<tr class="even"><td>
"Close"<br><br>Snake is at 58%.<br><br>Well, the
Noble Nine is getting arranged. Hey, who thinks Karma Hunter is going
to end up as the winner, through sheer MGS fanboyism alone?<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/12/2006 6:30:00 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347062773">message detail</a>
 | #472</td></tr>
<tr class="even"><td>
It's worked so far!<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/12/2006 7:37:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347212229">message detail</a>
 | #473</td></tr>
<tr class="even"><td>
Sonic the Hedgehog......50.77% 64027<br>Crono...........................49.23% 62087<br>TOTAL VOTES......................126114<br><br>13.31% of the brackets predicted this match correctly.<br><br>Wow,
Crono had a comfortable lead going into the morning, but then Sonic
completely dismanteled him during the day and built up a lead of his
own. He then went on to win, and had very low bracket support.<br><br>Samus Aran.......................55.27% 72890<br>Zelda.................................44.73% 58985<br>TOTAL VOTES.............................131875<br><br>41.16% of the brackets predicted this match correctly.<br><br>Was Zelda stronger this year? Has Samus lost a step? Who knows, but Samus 55-45's Zelda in this match.<br><br>Today, Snake is beating the crap out of Sonic...woah.<br><br>Moltar - 12<br>KH - 12<br>HM - 11<br>Lopen - 10<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Ulti - 7<br>Yoblazer - 5<br><br>One point for HM, one point for me.<br>---<br>Moltar Status: 17th on the leaderboard! Go my alt!<br>Snake vs. Sonic - Bracket: <b>N/A</b> - Vote: <b>Snake</b> (120/144)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3191556" class="name">LegendarySnake</a> |
Posted 11/12/2006 7:47:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347214912">message detail</a>
 | #474</td></tr>
<tr class="even"><td>
<b>Solid Snake with 55.70%+</b> tomorrow! Book it!<br>---<br><b>Solid Snake's Road to the Character Battle V Championship</b><br><i>Final Four</i>: Sonic the Hedgehog
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/12/2006 9:55:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347249536">message detail</a>
 | #475</td></tr>
<tr class="even"><td>
<b>Finals:</b> <i> Match 63</i> &#8211; (1)Samus vs. (1)Solid Snake <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Samus</b> - <i>Misses the tough male competiton.</i><br>Round 1 &#8211; 81.85% vs. Nidoran F (18.15%)<br>Round 2 &#8211; 79.78% vs. Ada (20.22%)<br>Round 3 &#8211; 69.00% vs. Rikku (31.00%)<br>Round 4 &#8211; 50.49% vs. Tifa (49.51%)<br>Round 5 &#8211; 55.27% vs. Zelda (44.73%)<br><br>Samus somewhat redeems herself against Zelda.<br><br><b>Zelda</b> - <i>RARGH, SNAKE SMASH THROUGH MALE BRACKET!</i><br>Round 1 &#8211; 82.15% vs. Soma (17.85%)<br>Round 2 &#8211; 57.59% vs. Squall (42.51%)<br>Round 3 &#8211; 57.16% vs. Yoshi (42.84%)<br>Round 4 &#8211; 55.33% vs. Mega Man (44.67%)<br>Round 5 &#8211; 55.00% vs. Sonic (45.00%)<br><br>&#8230;.****in&#8217; beast Snake<br><br><i>Road to the Finals</i><br><br>Samus:
I can&#8217;t believe CjayC did this. He put me, ME, THE Samus Aran with a
bunch of these weak females. I mean, my first opponent is a Pokemon?
Who over the age of 12 still plays that?<br><br>Nidoran F: Approximately 54 million! *Blasted to bits by Samus*<br><br>Samus: Yawn, next is&#8230;Ada Wong? Who?<br><br>Ada: RE4 yo. I&#8217;m the ***** in the red dress!<br><br>Samus: And now you&#8217;re&#8230;the..dead person&#8230;in the red dress&#8230;AHAHAHA SAMOAN BULLDOZER *blasts Ada* Now we have&#8230;Rikku?<br><br>Rikku: Yeah! Woo! Peace and love!<br><br>Samus: Such a shame, she&#8217;s pretty. *blasts her to death* Now it&#8217;s&#8230;.oh no.<br><br>Tifa: Oh yes, it&#8217;s me Samus.<br><br>Samus: You, you&#8217;re the one who!-<br><br>Tifa: The past was the past Samus, I served my time in jail, and all your emotional distress of the moment is gone now.<br><br>Samus: *shudders*<br><br>Tifa: How about we go one more round, eh?<br><br>Samus: &#8230;*blasts* Next! Hey, it&#8217;s my good buddy Zelda.<br><br>Zelda: Hey! *kidnapped by awesome new badass TP Ganondorf omg did u c the pics? secks plz*<br><br>Samus: Aww&#8230;<br><br>*Meanwhile, in Manly Man City*<br><br>Citizens: OH GOD HE&#8217;S OUT OF CONTROL SOMEONE STOP SNAKE!<br><br>Soma: I&#8217;ll do it! By the power of-*crushed by Snake*<br><br>Snake: RAARGHRAWR!<br><br>Squall: &#8230;whatever, this is stupid. *jobs to Snake*<br><br>Yoshi: *licks*<br><br>Snake: Teehee *underperforms*<br><br>Mega Man: Your time is up Snake, I&#8217;m putting an end to this!<br><br>Snake: RARGH, MEGA MAN BEAT SNAKE 2 TIMES, NOW MEGA MAN DIE<br><br>Mega Man: *forced to divide by zero* Oh ***-*implodes*<br><br>Sonic: Ha, there&#8217;s no way he&#8217;ll make me look that bad!<br><br>Snake: RARGH, SNAKE HATE BLUE<br><br>Sonic: *defeated by Snake&#8217;s Aura of Badass*<br><br>And
now it has come to this, Snake vs. Samus in the finals!&#8230;Yeah, thanks
for being a crazed, steroid-taking monster Snake. At this point, I&#8217;ll
be shocked if he loses after scoring 55% on Mega Man and a Sonic who
beat Crono, while Samus scored 55% on Zelda&#8230;who&#8217;s a bit below them.<br><br>Hey, I wouldn&#8217;t complain though, go Samus!  <br><br><b>Moltar&#8217;s Bracket Says:</b> Samus will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Samus: 48% - Snake: 52%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br> <br>Hopefully he posts it later! For now though&#8230;bwhahaha<br> <br>Prediction: Raiden with 73.14%<br><br> <br> <br><b>HM&#8217;s Analysis</b><br> <br><b>Samus Aran</b><br><br><i>Previous Matches:</i><br><br>Samus Aran &#8211; 81.85% -- 95,533<br><br>Nidoran F &#8211; 18.15% -- 21,180 <br><br>Samus Aran &#8211; 79.78% -- 98,352<br><br>Ada Wong &#8211; 20.22% -- 24,923 <br><br>Samus Aran &#8211; 69% -- 85,439<br><br>Rikku &#8211; 31% -- 38,387 <br><br>Samus Aran &#8211; 50.49% -- 72,773<br><br>Tifa Lockhart &#8211; 49.51% -- 71,355 <br><br>Samus Aran &#8211; 55.27% -- 72,890<br><br>Zelda &#8211; 44.73% -- 58,985 <br><br><b>Solid Snake</b><br><br><i>Previous Matches:</i><br><br>Solid Snake &#8211; 82.15% -- 86,697<br><br>Soma Cruz &#8211; 17.85% -- 19,487 <br><br>Solid Snake &#8211; 57.59% -- 78,314<br><br>Squall Leonhart &#8211; 42.41% -- 57,666 <br><br>Solid Snake &#8211; 57.16% -- 69,085<br><br>Yoshi &#8211; 42.84% -- 51,781 <br><br>Solid Snake &#8211; 55.33% -- 70,163<br><br>Mega Man &#8211; 44.67% -- 56,648
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/12/2006 9:56:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347249663">message detail</a>
 | #476</td></tr>
<tr class="even"><td>
Solid Snake &#8211; 54.93% -- 72,261 (as of 10:15 PM EST)<br><br>Sonic the Hedgehog &#8211; 45.07% -- 59,296 (as of 10:15 PM EST) <br><br>Well&#8230;holy
crap, Snake. It always seemed like a pretty solid bet that Snake would
be at least a little stronger this year thanks to the MGS4 and SSBB
trailers&#8230;but not <i>this</i> strong. It seems crazy to say it, but you have to figure that Snake is the <i>favorite</i> heading into this match. In fact, it just feels like Snake <i>can&#8217;t</i> lose this one.  <br><br>Samus
is definitely the strongest competition he&#8217;ll be facing in this contest
though. We&#8217;ve seen her look rather weak against Tifa, but put up solid
numbers against Zelda, who was the star of that match no doubt. She
definitely has a shot in this match, but with the way Snake is
performing, she might not be able to squeak out a victory here. <br><br>&#8230;This
analysis is awful, I know. I&#8217;m just pretty dumbfounded at how strong
Snake is looking this year. Never in my wildest dreams would I have
thought that Snake would be here in the finals and the favorite against
<i>Samus Aran</i>. Sure, she got beat pretty hard last year against Mario, but good grief.  <br><br>There
is one possibility here for Samus &#8211; one I think will tell the tale for
the trailer boost theory &#8211; and that is if Snake really did benefit this
much from the SSBB trailer, he should be susceptible to SFF. Given that
he&#8217;s not a Nintendo character normally and that he&#8217;s not really &#8220;in&#8221;
with the Nintendo fanbase, Samus may be able to pull some SFF, or rSFF
if you like, and win the match. It&#8217;ll be interesting to see. <br><br>This seems like a sorry analysis for the finals, but Snake just seems too dominant here. Plus, I&#8217;m preparing a <i>monster</i> for Link&#8217;s final match against Cloud. That&#8217;s sure to be a beauty &#8211; LINK DOMINATION BABY BRING IT ON! <br><br>(Plus I&#8217;m writing this really late.) <br><br><b>Aitch Emm&#8217;s Bracket:</b> Samus Aran<br><br><b>Aitch Emm&#8217;s Prediction:</b> Samus Aran &#8211; 49.8% ; Solid Snake &#8211; 50.2%<br><br><b>Aitch Emm&#8217;s Vote:</b> SAMUS ARAN FOR ZELDA &gt; MEGA MAN BELIEVE<br><br> <br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br><br>Well,
we've finally arrived! After two months of watching, waiting, arguing,
and running through the gamut of nerd emotions, we've reached the final
match, and what a final match it is! It's a match between the
overwhelming favorite female character versus one of the four favorite
males, but if we delve a smidgen deeper, this match is so, so much more.<br><br>When
the tournament began, Samus was about as big a board favorite to take
the female crown as Sephiroth was to take the villains crown last year.
No one, and I mean <i>no one</i>, thought she wouldn't be here. No one
expected her to break a sweat, either, and boy were we wrong on that
regard. I'm sure most people remember the impressive Bowser/Ganondorf
performances against Sephiroth in the Villains Contest, so just take
those, multiply them tenfold, throw in two pairs of breasts, and you
have Tifa's performance against Samus. It was amazing, and Samus went
from champ to chump faster than you could say "Zero Suit picture? Man,
I smell an overperformance!" She rebounded slightly with a 55% win
against Zelda, but not before letting the princess of Hyrule score
nearly five more percentage points than Ganondorf. Simply put, she's
going into this as the underdog.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/12/2006 9:56:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347249876">message detail</a>
 | #477</td></tr>
<tr class="even"><td>Her opponent, Solid Snake, was one of the top four
male contenders at the start of the tournament. Of course, amongst the
Board 8 community, he was a very, very distant fourth, and practically
no one gave him a realistic shot to beat Mega Man, let alone reach the
finals. Well, reach the finals he did, and he did it in spectacular
fashion. Snake has had five matches, and he has managed to destroy
expectations and overperform in each of them. He trashed a Castlevania
main character nearly as badly as he did away with that skeleton guy
last year, surprised everyone against Squall, destroyed the "Solid
****" legend against Yoshi, and has snapped the necks of two Noble 9ers
as if they were pant-pissing Russian guards. You know the only other
characters I can think of who have overperformed as consistently and
impressively as Snake has this year? Cloud in 2003, Link in 2004, Mario
in 2005, and that's... about it. Yep, performing the way Snake has this
year usually means you're primed to take the title home, and that's
exactly what he's looking to do.<br><br>However,
I don't think it will be as effortless as his last two matches. The
quickly emerging theory regarding Snake's massive boost is that he's
riding a wave of acceptance and hype from Nintendo fans. After all, how
in the hell can he go from beating Bowser with less than 51% to
destroying Mega Man <i>and</i> Sonic with 55%. Now, I'm not ready to
go campaigning for this theory or anything, but I do think it makes
sense and is the most logical reason to why the Solid One is suddenly a
god of Character Battles. As we all know, Samus is a big-name Nintendo
character, and as such, stands a chance to siphon some of this newfound
support from Snake. It's certainly not a guarantee, especially given
Samus's track record with such things, but it's certainly possible, and
I wouldn't be too surprised if she actually pulled off the win because
of it. In addition to that, I think she's simply stronger than Mega
Man, Sonic, and Crono, and should provide us with a better show for the
finals.<br><br>In conclusion, Snake should take this, but I wouldn't
bat an eyelash if Samus were to make this a damn good match, and I
think she has a realistic shot to win.<br><br>My prediction: Solid Snake def. Samus Aran (52-48)<br><br><b>Fun Fact</b>:
Should Snake win this match, he will have beaten three different Noble
9 characters, more than Samus, Mega Man, and Sonic, and tied with Crono
and Sephiroth. Not bad for one contest's work, eh? =P<br><br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Well, didn't I tell you people that Mega Man hadn't lost a step? The simple answer is Solid Snake is going <i>nuts</i>
this contest. Can Samus stand up against his fury? Nope, not a chance.
I don't think Samus is a cut above Mega Man, Sonic and Crono, despite
what the 2004 stats say. Yes, she beat Sonic 57-43 back then, but those
days are over. Samus getting only 40% against Mario, SFF or not, tells
me that she's not a cut above.<br><br>This year she hardly looks like
she's in her 2004 groove either. Unimpressive performances at the first
sight of real competition. Even against Tifa, if she emerged from the
Malibu or not, she wouldn't have crushed her.<br><br>So basically,
that's what we've got. I don't think Samus is a step above Crono,
Sonic, or Mega Man. Snake clearly is this year. Snake wins. I'd hate to
give such a brief write-up for this match, but that's all it really
boils down to for me.<br><br><b>Lopen's Prediction:</b> Solid Snake with 55.13%<br><br><br> <br><b>KH&#8217;s Analysis</b><br> <br>lol x-stats history<br><br>Samus Aran<br><br>Summer 2002 Contest<br>Extrapolated Strength --- 4th Place [41.07%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 7th Place [36.72%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 4th Place [39.50%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 5th Place [38.21%]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/12/2006 9:57:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347250021">message detail</a>
 | #478</td></tr>
<tr class="even"><td>
Samus redeems the Tifa debacle by doing decently on Zelda. Before
today, you could have even said she had reclaimed her rightful favorite
status, however...<br><br><b>SOLID SNAKE</b><br><br><i>"There are no heroes or heroines. If you lose, you're worm food."<br>"There's no right part in murder, not ever."<br>"Sounds like a spy movie."<br>"Change sides? I don't recall saying I was on yours."<br>"Building the future and keeping the past alive are one and the same thing."</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 9th Place [35.23%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 8th Place [34.74%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 12th Place [30.82%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 9th Place [33.88%]<br><br>At the time of this writing, Snake is looking like he will not let Sonic the Hedgehog -- <i>the Sonic who beat CRONO</i> -- break 45% on him. If you don't think this man is the favorite to win the contest right now, I don't know what to tell you.<br><br>This is it, Snake.<br><br><i>Win.</i><br><br><i>Notable Releases Since Last Appearance</i><br><br>Samus Aran: Metroid Prime: Hunters (DS), Metroid Prime Pinball (DS), Super Smash Brothers Brawl Trailer (lol internet)<br>Solid Snake: Metal Gear Solid 3: Subsistence (PS2), Super Smash Brothers Brawl Trailer (Internet)<br><br><i>Upcoming Releases</i><br><br>Samus Aran: Metroid Prime 3: Corruption (WII), Super Smash Brothers Brawl (WII) <br>Solid Snake: Metal Gear Solid 4: Guns of the Patriots (PS3), Super Smash Brothers Brawl (WII)<br><br>The
final that even *I* had a hard time see happening is here, and Snake
being the established favorite over the once-invulnerable Samus is
amazing to see here.<br><br>Let me keep this brief. Samus basically
went 55-45 with Zelda. Snake is expected to do better against Mega Man,
Sonic, and Crono. Even if Samus is actually UNDERRATED, I could see
Snake beating her without a problem.<br><br>Tifa match aside, who the hell do you think I'm siding with???<br><br>Karma Hunter's Vote: <b>VOTE SNAKE</b><br><br><b>Karma Hunter's Krazy Prediction: Solid Snake with 55.35%.</b><br><br>NO ONE ABOVE 45% ON SNAKE<br><br><b>Upset Potential: 0%<br><br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br><br>Though
as much as I hate to say it, Samus has a chance here. Snake seems to be
getting his support from the SSBB crowd, and if Samus can somehow put a
stop to that she can win this thing -- except that sort of presumes
that Samus is stronger without SSB, which is kind of a stretch...eh...<br><br>I
guess Yoshi is the best argument here, but I refuse to believe the
sprite round did nothing. Samus can still win, but it would shock me at
the core to this point. It would take a miracle for Snake to not snag
that #5 slot now. What a contest.<br><br>...no, Samus doesn't get an Upset Prediction.<br><br>...<br><br>SNAKE IS INVINCIBLE<br><br><br> <br><b>Guest&#8217;s Analysis</b> - <i>SilverNightmareX7</i><br><br>So we are down to the final conventional match of the 2006 Tournament.<br> <br>In
one corner, we have Samus. But who gives a flying **** about her? She
was expected from the very begining to make the finals and hasnt looked
all that elite, albeit that terrible (yet strangely erotic) picture of
Samus in Zero Suit form. Throughout this tournament, Samus has done a
little below expectations upon walking into the finals thanks to a
rather pathetic female bracket.<br> <br>The other corner is the one
that matters. The one that seats the soon-to-be champion. The one that
seats a character whom, in SC2k5 may very well have lost to characters
such as Squall and Vincent. One whom, this year, blew a very
respectable looking Squall out of the water. One who made
UltiMegaManFanboyX admit Mega Man has no place in the Noble Nine. One
who has yet to break a sweat in any given match this tournament.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/12/2006 9:58:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347250278">message detail</a>
 | #479</td></tr>
<tr class="even"><td>We call this man Solid Snake, and he is the reason
my sig is currently owned by Karma Hunter. He is the reason resident
Board 8 troll Sir Chris is no more. And this year, he is the destined
champion. He may even be making people nervous about placing the male
champion as their #5/#6 finisher. The days of being the Noble Nine's
resident underachiever are over.<br> <br>This year, Solid Snake goes against many, many a bracket, and defeats Samus in the finals with a winning percentage of 51.47%<br> <br>And because there will be no guest analysis of the battle royale:<br> <br>6. Samus, 5. Mario, 4. Snake, 3. Cloud, 2. Sephiroth, 1. Link.<br> <br>Logic:
Mario's absence from the main bracket gives him less support than
Snake; Sephiroth outlasts Cloud because of the three left, he is the
villain. Link will take away more votes from Cloud than he will
Sephiroth.<br> <br> <br> <br>Crew Consensus: Oh man, Snake for the sweep in the Finals? Guess that shows how much we fear his dominance.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 11/12/2006 10:00:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347250859">message detail</a>
 | #480</td></tr>
<tr class="even"><td>
Damn, I am shocked to see I was one of the low % people. Sad to see KH overshoot.<br>---<br>Despite Karma Hunter's warnings, I doubted what should have been obvious to all. Only the Snake is the true hero! <b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/12/2006 10:01:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347251070">message detail</a>
 | #481</td></tr>
<tr class="even"><td>
Thank God I went higher than Lopen this time.<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=640243" class="name">Big Bob</a> |
Posted 11/12/2006 10:04:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347251629">message detail</a>
 | #482</td></tr>
<tr class="even"><td>
<b><i>Big Bob's competely biased and nonsensical analysis</i></b><br><br>Snake
beat Mega Man, and beat Sonic (who beat Crono)? Samus struggled against
Tifa and got the same percentage on Zelda as Snake got on Sonic? She's
****ed.<br><br><b>Bob's Prediction: Snake with 55%</b><br><br>That's right, make her look worse than Sonic!<br>---<br>Gordon
Freeman finally won, but somehow, the universe survived... thus
allowing me to tell said universe about how I was owned by <b>NClark128</b>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 11/12/2006 10:04:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347251758">message detail</a>
 | #483</td></tr>
<tr class="even"><td>
Woah, no one took Samus? I thought with the rSFF threat at least one would.<br>---<br>CB06 - Score: <b>122/144 </b>Rank: <b>Tied - 1275th </b>Yesterday's Pick:<b> Samus Aran</b> Today's Pick: <b>Crono ;_;</b> <br>Tomorrow's Pick: <b>Samus</b> Losses: <b>Cortana, Ganondorf, Zero, Master Chief, Kirby, Mega Man, Crono</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3662060" class="name">YoAriel33</a> |
Posted 11/12/2006 10:08:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347252514">message detail</a>
 | #484</td></tr>
<tr class="even"><td>
I was thinking about it, but Snake's looked much better AAAAAAAAAAND I like him more, so that about sealed that deal. &gt;_&gt;<br>---<br><i>I don't know when, I don't know how, but I know something starting right now... <br>Watch and you'll see, someday I'll be... <b>part of your world!</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=981127" class="name">Cavalier Lowen</a> |
Posted 11/12/2006 10:08:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347252566">message detail</a>
 | #485</td></tr>
<tr class="even"><td>
<a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499508&amp;page=2" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499508&amp;page=2">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30499508&amp;page=2</a><br><br>Bleh, I took the upset...hopefully Ceej doesn't use ZSS...<br>---<br>Z1mZum owned me in the guru contest (by two points!).  Damn you Z1mZum!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/12/2006 10:09:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347252838">message detail</a>
 | #486</td></tr>
<tr class="even"><td>
Every time you take Samus or vote for her against Snake, a kitten spontaneously combusts.<br><br>Even if you don't like kittens, keep in mind that I might send you a litter or two if Snake loses. &lt;&lt;<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=840451" class="name">SilverNightmareX7</a> |
Posted 11/12/2006 10:11:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347253263">message detail</a>
 | #487</td></tr>
<tr class="even"><td>
Snake has just been too dominant. Its is destiny. Snake dominated what was considered to be entirely Crono's bracket.<br><br>Samus
on the other hand, has suffered much like Sephiroth did in the villains
contest. Mediocre brackets make elite characters less elite.
Unfortunately for Samus, she doesnt have 7 months to recover from the
suckage of the mediocre bracket like Sephiroth did.<br>---<br>Despite Karma Hunter's warnings, I doubted what should have been obvious to all. Only the Snake is the true hero! <b>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/12/2006 10:12:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347253541">message detail</a>
 | #488</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>I'll be damned if Sonic loses to Snake so Snake can just lose to Samus. Ah, screw it....Samus has Nintendo behind her.<br><br>My vote: Snake<br>My bracket: Samus<br>My prediction: Samus with 54%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/12/2006 10:13:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347253784">message detail</a>
 | #489</td></tr>
<tr class="even"><td>
I don't even think Dp changes his predictions based on what's actually happening in the contests. =/<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 11/12/2006 10:14:20 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347254074">message detail</a>
 | #490</td></tr>
<tr class="even"><td>
<i>Every time you take Samus or vote for her against Snake, a kitten spontaneously combusts.<br><br>Even if you don't like kittens, keep in mind that I might send you a litter or two if Snake loses. &lt;&lt;</i><br><br>I hate Kittens... and if you sent me Kittens it would just be more for me to kill. <br><br><i>Kittens are so screwed.</i><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 11/12/2006 10:14:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347254122">message detail</a>
 | #491</td></tr>
<tr class="even"><td>
Thank God indeed. If I had seen anyone go for Samus, I would have lost all faith in the crew.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/12/2006 10:15:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347254328">message detail</a>
 | #492</td></tr>
<tr class="even"><td>
<i>I hate Kittens... and if you sent me Kittens it would just be more for me to kill.</i><br><br>Too bad you didn't get the subtle implication!<br><br>Wait, it wasn't subtle at all. Stop being so dense EC<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 11/12/2006 10:16:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347254530">message detail</a>
 | #493</td></tr>
<tr class="even"><td>
My pick: Samus with 51.56%.<br><br>I'm basing
this off of a constant Zelda and going guesswork on the percentages. If
Snake's boost has truly come from the SSBB announcement, then Samus
being a Nintendo character should put a dent into Snake's strength. I
hope to hell I'm wrong, though.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), Castlevania: LoI, MMZX
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3605461" class="name">chaosarcher07</a> |
Posted 11/12/2006 10:16:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347254632">message detail</a>
 | #494</td></tr>
<tr class="even"><td>
Lopen's got this one.<br>---<br>My FC2K6 Bracket: 58?/68?<br>Next match prediction: Tifa
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 11/12/2006 10:16:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347254699">message detail</a>
 | #495</td></tr>
<tr class="even"><td>
um whats a dense george<br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 11/12/2006 10:17:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347254781">message detail</a>
 | #496</td></tr>
<tr class="even"><td>
Yay Ulti ^_^<br>---<br>CB06 - Score: <b>122/144 </b>Rank: <b>Tied - 1275th </b>Yesterday's Pick:<b> Samus Aran</b> Today's Pick: <b>Crono ;_;</b> <br>Tomorrow's Pick: <b>Samus</b> Losses: <b>Cortana, Ganondorf, Zero, Master Chief, Kirby, Mega Man, Crono</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 11/12/2006 10:21:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347255634">message detail</a>
 | #497</td></tr>
<tr class="even"><td>
<i> From: SilverNightmareX7 </i><br><i>Snake has just been too dominant. Its is destiny. Snake dominated what was considered to be entirely Crono's bracket.<br><br>Samus
on the other hand, has suffered much like Sephiroth did in the villains
contest. Mediocre brackets make elite characters less elite.
Unfortunately for Samus, she doesnt have 7 months to recover from the
suckage of the mediocre bracket like Sephiroth did.</i><br><br>Why does
she need "recovery time"? She's going against a male, maybe she'll
bounce back. Besides that, she still put up awesome numbers on everyone
besides Tifa (who could have easily boosted due to various factors +
underperformance from Samus because of ZSS pic). And I say Zelda
boosted as well which makes Samus look good. Zelda flat out <i>dominated</i> her matches. She emberrassed Aeris.<br>---<br>CB06 - Score: <b>122/144 </b>Rank: <b>Tied - 1275th </b>Yesterday's Pick:<b> Samus Aran</b> Today's Pick: <b>Crono ;_;</b> <br>Tomorrow's Pick: <b>Samus</b> Losses: <b>Cortana, Ganondorf, Zero, Master Chief, Kirby, Mega Man, Crono</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 11/12/2006 11:53:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347274892">message detail</a>
 | #498</td></tr>
<tr class="even"><td>
So what's the deal with the Battle Royale again?<br><br>---<br>"My ambition is to create the coolest Link that's ever existed." -- Keisuke Nishimori, Twilight Princess
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 11/13/2006 12:00:47 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347276190">message detail</a>
 | #499</td></tr>
<tr class="even"><td>
This match makes me wonder WTF happened with Tifa.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), Castlevania: LoI, MMZX
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=463285" class="name">UltimaterializerX</a> |
Posted 11/13/2006 12:01:16 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=347276281">message detail</a>
 | #500</td></tr>
<tr class="even"><td>
BR writeup coming tomorrow.<br><br>~*ST*~<br>---<br><b>Winner of the Spring 2004 "Best. Game. Ever." Contest</b><br>Now Playing: <b>Disgaea 2</b>, KH:COM (Sora), Castlevania: LoI, MMZX
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=8">9</a></li>
<li>10</li>
</ul>
</div>


</div>
<img src="genmessage10_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage10_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31382187&amp;page=9" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage10_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>