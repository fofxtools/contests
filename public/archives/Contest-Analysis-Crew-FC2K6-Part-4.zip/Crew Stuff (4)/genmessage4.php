<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage4_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage4_files/nogs.css"></head><body linkifytime="261" linkified="4" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage4_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage4_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31382187%26page%3D3"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div class="ad" style="text-align: center;">
<div style="text-align: center;"><img src="genmessage4_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage4_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage4_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 4
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;page=3">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31382187" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=2">Previous Page</a> |
Page 4 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=4">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 10/31/2006 9:05:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344542602">message detail</a>
 | #151</td></tr>
<tr class="even"><td>
It&#8217;s time! Up next is the most important match of the entire contest,
Zelda vs. Aerith! Zelda is the lovable princess from the aptly named
video game series, The Legend of Zelda. Over in the other corner of the
arena is Aerith, some *spoilers* dead chick from Final Fantasy VII.
These game names are really quite fitting, as you would have to be
living in some sort of fantasy world in order to believe that this
match will be anything but a legendary blowout in favour of our beloved
princess. If Aerith fans actually existed, they most certainly would
find themselves quite disappointed in the abysmal showing she will give
in what will turn out to be her final GameFAQs Character Battle. But
enough about how big of a blowout this match will be, let&#8217;s take a look
at why exactly it will be such a blowout.<br><br>First
off we have the clear favourite to win this match (and the whole
contest), Zelda. In the first round of this contest, Zelda destroyed
Carmen Sandiego with nearly 90% of the vote, a feat that she is aiming
to repeat here on Aerith. Now, Carmen is one of the most recognizable
characters in gaming, and I can see her easily breaking the fodder
level at 20% on Base Link, so we&#8217;re clearly dealing with a Zelda far
more powerful than we saw back in 2005. In round two, Zelda defeated a
character from the undisputed best game of all time with relative ease.
If Zelda can do so well against someone from the undisputed best game
of all time, what is to stop her from dominating someone from the
absolute <i>worst</i> game ever, Final Fantasy VII? Absolutely
nothing, that&#8217;s what. If Zelda&#8217;s spectacular performance in the first
two rounds is any judge, it shouldn&#8217;t take any thought at all to
predict the outcome of this match. <br><br>On the other hand, Aerith
had a pathetic first two rounds, letting Marle and KOS-MOS put up a
good showing against her when she should have been able to RPG SFF them
to the moon. There isn&#8217;t really anything more to say about it. They are
both uber-fodder and Aerith disappointed against them to an incredible
degree. Once again, if her earlier performances can be trusted, I would
have to think twice before putting her over even Tanner.<br><br>Even
ignoring the previous rounds, Zelda still has a huge advantage in she
has undeniably received a massive boost from Twilight Princess Hype. In
addition to this, Final Fantasy XII has just been released. This will
increase the number of people coming to GameFAQs and voting while they
are here. Aerith is easily one of the most hated characters of all
time, and so Zelda should get a nice bonus from all of the Aerith
anti-votes.<br><br>Due to the various factors listed above, I am
confident in Zelda&#8217;s ability to get 99.99% of the vote against Aerith.
However, I left one important factor out: The jp. The jp will vote for
Aerith to oppose the hivemind, and his excessive gravitation pull will
pull a large amount of Zelda votes towards Aerith, causing her to
overperform to a ridiculous degree. As much as I know that this should
be the greatest blowout ever, I can&#8217;t possibly ignore this crucial
factor, which leads me to my calculated guess for this match.<br><br>My prediction? Zelda with 54.64%<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 10/31/2006 10:06:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344556300">message detail</a>
 | #152</td></tr>
<tr class="even"><td>
Well, apparently I got the guest writeup for Sora/MM.<br><br>---<br><i>Do you really need me to bring out the Ovaltine?</i>-Stripey12isback on why hes a war hero.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=625761" class="name">LordLockeRA</a> |
Posted 11/1/2006 4:08:37 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344594365">message detail</a>
 | #153</td></tr>
<tr class="even"><td>
Zelda detonates fodder just to struggle with someone with a face and a personality people actually know and possably care about.<br><br>Go
figure. Then again, I think Aeris is looking weaker then she should
thanks to an underrated KOS-MOS, considering she got thumped last year
by what may be a horribly-misread Luigi.<br><br>Speaking of Luigi... I
don't know WHAT to say about him anymore, because apparently he and
Bowser were hitting the same stash of shrooms as Luigi is currently
wiping his hands clean of the BLOOD of a fourpack he had no business
breaking through and looking at Sonic with an uneasy glint. Luigi,
ninebreaker?<br><br>... probably not, but at this point, I'd give him more of a shot then I'd have given Vincent.<br><br>---<br>Meeh.  Whatever.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=254355" class="name">Lugia2</a> |
Posted 11/1/2006 5:54:44 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344599098">message detail</a>
 | #154</td></tr>
<tr class="even"><td>
...Lord? You do realize that "not underperforming or overperforming"
doesn't mean "with someone with a face and a personality people
actually know and possably care about", right?<br><br>If the match gets between 2000 votes, THEN I'll worry.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 11/1/2006 8:09:38 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344606158">message detail</a>
 | #155</td></tr>
<tr class="even"><td>
Hmmm, if Aeris can impress until the after-school vote, and bring
things down a little bit with the second night vote, I might have a
good shot at this point <i>!!</i><br><br><b>TuRtLe</b><br>~~~<br>55/62 in the contest. My analysis topic here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 11/1/2006 8:11:09 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344606258">message detail</a>
 | #156</td></tr>
<tr class="even"><td>
And how is Zelda struggling here? Were this match to take place in
2003, Aeris would probably have the results reversed now. Zelda is
kicking ass!<br><br><b>TuRtLe</b><br>~~~<br>55/62 in the contest. My analysis topic here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3662060" class="name">YoAriel33</a> |
Posted 11/1/2006 9:13:51 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344611507">message detail</a>
 | #157</td></tr>
<tr class="even"><td>
Tifa Lockheart vs. Princess Peach<br>+7 Yo<br>+6 HM<br>+5 KH<br>+4 Ulti<br>+3 Mo<br>+2 Guest<br>+1 Lo<br><br><b>The Rankings</b> (Through Tifa vs. Peach)<br>1. Master Moltar (211)<br>2. Heroic Mario (201)<br>3. Karma Hunter (200)<br>4. Yoblazer (190)<br>5. UltimaterializerX (181)<br>6. Board 8 (158)<br>7. Lopen (122)<br><br>---<br><i>I don't know when, I don't know how, but I know something starting right now... <br>Watch and you'll see, someday I'll be... <b>part of your world!</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/1/2006 3:41:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344668989">message detail</a>
 | #158</td></tr>
<tr class="even"><td>
Tifa Lockhart.....................66.05% 79830<br>Princess Peach ...............33.95% 41033<br>TOTAL VOTES...........................120863<br><br>61.21% of the brackets predicted this match correctly.<br><br>Peach may have started well, but Tifa took off from there. Tifa ends with just under a doubling on the Princess.<br><br>Today, Zelda is beating Aeris pretty bad, especially for a match that was deemed close.<br><br>Moltar - 9<br>Lopen - 9<br>KH - 9<br>HM - 8<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Ulti - 6<br>Yoblazer - 4<br><br>Yo finally gets a point of his own!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Zelda vs. Aeris - Bracket: <b>Zelda</b> - Vote: <b>Zelda</b> (64/72)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/1/2006 9:03:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344750961">message detail</a>
 | #159</td></tr>
<tr class="even"><td>
So Lugia2 hasn't sent me Yuna/Chun-Li, and I think it's late enough for anyone to take care of it.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Zelda vs. Aeris - Bracket: <b>Zelda</b> - Vote: <b>Zelda</b> (64/72)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/1/2006 9:05:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344751380">message detail</a>
 | #160</td></tr>
<tr class="even"><td>
[This message was deleted at the request of the original poster]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 11/1/2006 9:07:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344751916">message detail</a>
 | #161</td></tr>
<tr class="even"><td>
Alright, working on it now.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=254355" class="name">Lugia2</a> |
Posted 11/1/2006 9:11:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344753084">message detail</a>
 | #162</td></tr>
<tr class="even"><td>
<i>WHAT?</i><br><br>Grr...I thought I emailed it. I guess I'm banned or
something- my e-mail isn't gmail or anything like that. I'll post it
here. Oye... Anyway, this is from the original message.<br><br>"Here's the thing!  Sorry if it's a little short.<br><br>Yuna<br><br>She's
been doing well this contest. She wiped out two competitors while above
70% of the vote. She was in FFX, and in...FFXII...but she's still loved
by FF freaks and normal gamers a like.<br><br>Chun-Li<br><br>Chunners...doesn't look so hot.  She hasn't reached that 70% destroying mark.  So...uh...<br><br>Well, doesn't seem hard to pick.  BUT WAIT!  What about the X-Stat Calculator?<br><br>...shows up 52% for Yuna in 2005.  That was the only contest they shared.  Anything before 2004 is probably invalid<br><br>Course, Yuna is behind the weird Gannon/Samus thing...But Samus got destroyed Mario by SFF...<br><br>Chun-Li,
on the other hand, is completely safe as far as SFF. She got chomped by
Bowser, who got Weirded out by Kirby (what happened? I dunno), and,
well, the rest isn't SFF.<br><br>So, it isn't that clear.  Chunners has only a couple of points to maneuver.  She could still win this...<br><br>...If she were from FF or Nintendo.<br><br>Let's
be frank. I somehow have Thunder thighs winning this match in my (now
dead) bracket. But Yuna might have a FFXII boost ("Might" because
people say Aeris has one. O-K...). She is from the FF part of
SquareTendo. Her game is pretty well remembered.<br><br>And
Chun-Li?..nah. Her game is legendary, but games/=characters, and her
game isn't being overexposed like Pokemon is, and the SF releases don't
seem to be that huge anymore. She also hasn't impressed that much,
except for those who had Lara here.<br><br>I've got Chunners in my bracket.  That was a mistake.<br><br>My vote: Chunners.  I don't see why to vote for the sl-summoner from FFX-2<br><br>My Bracket: Chun-Li <br><br>My Prediction: Yuna with 51%<br><br>Low?  Well, I have to take in account whatever was happening elsewhere... "<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 11/1/2006 9:23:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344756181">message detail</a>
 | #163</td></tr>
<tr class="even"><td>
51%<br><br>*shudders*<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/1/2006 9:41:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344760688">message detail</a>
 | #164</td></tr>
<tr class="even"><td>
<b>Aeon Division:</b> <i>Round 3 - Match 52</i> &#8211; (1)Yuna vs. (3)Chun-Li <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Yuna </b><br>Round 1 &#8211; 79.30% vs. Roll (20.70%)<br>Round 2 &#8211; 78.05% vs. Joanna (21.95%)<br><br>Yuna&#8217;s looking like Zelda-lite here. Another impressive performance from her.<br><br><b>Chun-Li</b><br>Round 1 &#8211; 68.74% vs. Kasumi (31.26%)<br>Round 2 &#8211; 55.54% vs. Lara (44.46%)<br><br>So&#8230;I guess Lara isn&#8217;t as weak now as she was in 2004!<br><br>While
this match isn&#8217;t as hyped up as Zelda/Aeris, it still deserves to get
some talk over it. I mean, last year, these two weren&#8217;t far away from
each other. Yuna got what, 39% on Ganondorf, and Chun-Li got 34% on
Bowser. But that was a Bowser on some obvious roids. They&#8217;re close,
darn it!<br><br>Well, they were, until Yuna decided to spit in the face
of her 2005 value and lay a nice pile of sweet-smelling flowers over
it. Ok, yeah, Roll is garbage, but then to fave Joanna, who Mario got
81% on, and get 78% on that? Can&#8217;t say we saw that coming! The fodder
in the female bracket was worse than we thought! <br><br>Chun-Li
looked like a contender in Round 1, putting up amazing numbers on
Kasumi&#8230;well, amazing if this was 2002, but still! However, her Round 2
match was a lot less impressive. Lara has never looked good here,
except kinda in 2002 and maybe 2003. However, Lara looked a bit <i>too</i>
good against Chun-Li. Yeah, I know Lara wasn&#8217;t herself in 2004, and she
has had Legend since then, but to bring her pretty much up to her 2003
value? Yeah&#8230;no.<br><br>So let&#8217;s see&#8230;looking at all the characters
Bowser faced, he really messed them up. Chun-Li may be overrated, and
Yuna is looking beastly for being behind potential double-SFF last
year. I&#8217;m going to say Yuna with the easy win.<br><br><b>Moltar&#8217;s Bracket Says:</b> Yuna will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Yuna: 57% - Chun-Li: 43%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br> <br>Like
the last match, this was mildly debatable until the last round
happened, when Bowser underperformed. Now the upset almost seems
impossible for ol' Chunners, though she still may do well.<br><br>Prediction: Yuna with 53.53%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br> <b>Yuna</b><br><br><i>Previous Matches:</i><br><br>Yuna &#8211; 79.3% -- 97,716<br><br>Roll &#8211; 20.7% -- 25,501 <br><br>Yuna &#8211; 78.05% -- 89,711<br><br>Joanna Dark &#8211; 21.95% -- 25,229 <br><br><b>Chun-Li</b><br><br><i>Previous Matches:</i><br><br>Chun-Li &#8211; 68.74% -- 71,106<br><br>Kasumi &#8211; 31.26% -- 32,611 <br><br>Chun-Li &#8211; 55.54% -- 64,126<br><br>Lara Croft &#8211; 44.46% -- 51,338 <br><br>After Chun-Li&#8217;s rather unimpressive performance against Lara Croft, this once <i>potentially</i>
close match has sort of sunk into the &#8220;Oh crap, another boring female
match&#8221; mix that the female bracket has. Yuna came out looking extremely
impressive against Joanna Dark, blowing her out nearly as bad as she
had done to <i>Roll</i> one round prior.  <br><br>The most interesting
thing about this match will be to see where Yuna and Chun-Li stand.
There are some question marks surrounding their placement last year,
with one being underrated and the other being overrated, but we should
get some idea of that here. Fortunately, after Zelda&#8217;s domination in
yesterday&#8217;s match, we&#8217;ll actually get to see Yuna perform against <i>another</i> Zelda character to compare! Woo!  <br><br>&#8230;Yeah.
This should be another pretty dull match, unless Yuna really surprises
or disappoints. The winner shouldn&#8217;t be in question. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Yuna<br><br><b>Aitch Emm&#8217;s Prediction:</b> Yuna &#8211; 55% ; Chun-Li &#8211; 45%<br><br><b>Aitch Emm&#8217;s Vote:</b> Yuna
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/1/2006 9:42:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344760859">message detail</a>
 | #165</td></tr>
<tr class="even"><td>
<b>Yoblazer&#8217;s Analysis</b><br> <br>It can be argued that Yuna is
unproven after two rounds of beating up on pitiful fodder. The same
could have been argued against Zelda, and look what she's doing now
(Jesus Christ). Fodder or no fodder, Yuna has looked terrific, and
there's no way I'm taking someone who barely managed 55% against Lara
Croft to beat a Final Fantasy midcarder. Sorry, Chun-Li. You have my
vote, but you don't have this match.<br><br>My prediction: Yuna def. Chun-Li (57-43) <br><br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>One could say that Yuna's got a huge edge going into this thing. Getting only ~2% less on Joanna Dark than <i>freaking Mario</i>
did isn't something to scoff at. Now I'd say Joanna and Roll are both
fodder, and it's more looking bad for them than good for Yuna. However,
that's not all Yuna has&#8230; I'd say the main reason people are condemning
Chun Li at this point would be what she did in round 2.<br><br>Now, in
round 2, Chun Li did pretty poorly against Lara Croft by most of our
standards. But Lara Croft is very much an x-factor. I know you've heard
me bring it up time and time again, but Tomb Raider: Some Game could
have brought her back into the limelight at least somewhat. 2003
levels? <i>Maybe</i>. Maybe even higher&#8230; I mean heck, she could've
just had something weird happen against Samus. Lara Croft may have
never been mega fodder in the first place. People say "no one cares
about Lara Croft anymore". But honestly, did anyone care about her in
2002 and 2003 either? Both years were also far beyond her prime, and
she wasn't mega fodder then, was she?<br><br>And let's not forget Chun Li's <i>first</i> round. ~70% on Kasumi might very well be the most impressive victory amongst the two to me. Heck, using <i>2002</i>
X-Stats Kasumi was expected to even make that match somewhat close.
Okay, 2002 stats suck, so we'll ignore them.. but I'd say Kasumi's not
a <i>totally</i> incompetent opponent, she's probably about on the level of say.. Jin Kasama.<br><br>However,
the biggest selling point for Chun Li for me right now is Ryu. Ryu did
much better on Mega Man than he was expected to. Now I always believed
that Some Fishy Factor may have occurred in Ryu/Bowser, and this match
helps to validate that a bit. Now, if you'll recall, our only read on
Chun Li from last year was a beating from Bowser. A Bowser that can
potentially pull Fishy things out of his hat when he faces Ryu. You
think Chun Li's immune if Ryu isn't? <i>Hell</i> naw. Chun Li's got every reason to be better than she looks in 2005 here.<br><br>So with all that considered, I think Chun Li is looking good to <i>take</i> this match. No fanboyish rants from me here though... believe it or not, I like Yuna more! <br><br><b>Lopen's prediction:</b> Chun Li with 51.99%<br><br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br>Yuna<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 34th Place [23.66%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 31st Place [23.92%]<br><br>Yuna decimated Joanna almost as badly as Mario last round. And with no SFF to blame? Wow.<br><br>Chun-Li<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 34th Place [22.84%]<br><br>Chun-Li beats Lara Croft last round...in perhaps the most unimpressive way possible. Wow.<br><br><i>Notable Releases Since Last Appearance</i><br><br>Yuna: Kingdom Hearts II (PS2)<br>Chun-Li: N/A<br><br><i>Upcoming Releases</i><br><br>Yuna: N/A<br>Chun-Li: N/A
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/1/2006 9:43:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344761136">message detail</a>
 | #166</td></tr>
<tr class="even"><td>
And now for the other match in which I somehow picked the character
that I didn't think was going to win. However, unlike last match (which
didn't exactly pay off ;_;), I'm jumping ship. Chun-Li winning this at
this point is a real stretch for me. She's weaker in the stats. She was
in the Dream Division. Yuna was behind a possibly underrated Ganon.
Yuna has looked like a beast (albeit against fodder, but so did Zelda),
Chun-Li barely beat Lara Croft. The only thing Chunners really has on
her side is the match picture, and we've already seen today that won't
change a blowout.<br><br>Karma Hunter's Vote: Chun-LI, out of nostalgia. This is a bit of a tough vote.<br><br><b>Karma Hunter's Krazy Prediction: Yuna with 56.32%.</b><br><br>So, yeah. Another win for my bracket (<i>somehow</i>), a loss for the excuse I call logic.<br><br><b>Upset Potential: 29%<br><br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br><br>Ryu
is the one thing that makes Chun-Li look good. Assuming a constant Mega
Man and a Bowser that overperformed on Chun-Li to the same extent he
did on Ryu, she has a real shot at this. Rikku sort of tells us
otherwise, but we have no idea if we're dealing with a stronger Samus
or not (plus she might be underrated in 2k5). She can win, but unlike
last time I'm not banking on the upset.<br><br>Upset Prediction: Chun-Li with 53.4%%<br><br><br> <br><b>Guest&#8217;s Analysis</b> - <i>Lugia2</i><br><br>It&#8217;s posted above silly! Apparently, he&#8217;s too <i>good</i> for us, so yeah! Scroll up and read it if you want.<br> <br> <br> <br>Crew Consensus: Other that Lopen, everyone else has Yuna winning here. It could range from pretty close to Ulti-style blowout.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 11/1/2006 9:45:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344761656">message detail</a>
 | #167</td></tr>
<tr class="even"><td>
Bleh. This next match is completely insignificant when compared to the
beautiful scene that we are viewing right now. It is between the
leading lady of Final Fantasy X and Final Fantasy X-2, Yuna, and the
woman with the thunder thighs, Chun-Li. This match is just as
predictable as Zelda &gt; Aerith, except it lacks the importance for
future rounds (Zelda &gt; Samus, anyone). Yuna will win this match
easily, but let&#8217;s take a look at just how easily.<br><br>First
off we&#8217;ll examine the star of Final Fantasy X/X-2, Yuna. In the first
round of this tournament, she decided to take a page out of Zelda&#8217;s
book and completely destroyed Roll, getting nearly 100,000 votes. Her
second round performance was also similar to Zelda&#8217;s showing, with a
second blowout against tested fodder. Yuna&#8217;s performance against Joanna
is nearly as well as the one given from Mario, of all characters. Now,
I&#8217;m not saying that Yuna is able to break the noble nine, but she
certainly seems strong enough to beat <i>Chun-Li.</i><br><br>Sure,
Yuna may be looking like a goddess right now, but what has Chun-Li been
up to so far? Well, not much. In round one she completely failed to
break 70% on Kasumi, a character that I&#8217;m willing to bet a fair amount
of people have never even heard of. In round two, she bombed even
harder, barely managing to pass 55% on an extremely weak Lara Croft.
Lara isn&#8217;t the icon she once was, and I&#8217;m certain that she generates a
fair number of anti-votes. Chunner&#8217;s performance so far has been less
than spectacular, and she will need to step up her game a fair amount
to have a chance of even making this match a close one.<br><br>This
match is basically a more extreme version of Zelda vs. Aerith, with a
Final Fantasy character going up against someone that casual gamers
won&#8217;t have even heard of. Yuna seems to have randomly boosted like
Zelda, and I&#8217;m expecting a result similar to that of today&#8217;s match.
Zelda is around 57% at the time of writing, so I&#8217;ll take that and bump
it up a bit over 1% for Yuna.<br><br>My prediction? Yuna with 58.34%<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/1/2006 9:49:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344762396">message detail</a>
 | #168</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Time for me to get a point
again, whooo! Well anyway, Chun-Li had a nice run, but now she faces
Final Fantasy, which means she's doomed. Yuna's got this one in the
bag, and after seeing Tifa get 66% on Princess Peach, this could be
ugly.<br><br>My vote: Chun-Li<br>My bracket: Yuna, though I probably accidentally picked Chun-Li<br>My prediction: Yuna with 64%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 11/1/2006 9:51:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344763064">message detail</a>
 | #169</td></tr>
<tr class="even"><td>
By the way, I demand the right to poke Lugia in the eye for seeing this
topic when my prediction turns out to be the closest one.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/1/2006 11:00:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344777844">message detail</a>
 | #170</td></tr>
<tr class="even"><td>
Nice point for Ulti.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 11/2/2006 12:02:17 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344787447">message detail</a>
 | #171</td></tr>
<tr class="even"><td>
darn u ulti!<br><br><b>TuRtLe</b><br>~~~<br>55/62 in the contest. My analysis topic here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=254355" class="name">Lugia2</a> |
Posted 11/2/2006 5:59:50 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344812397">message detail</a>
 | #172</td></tr>
<tr class="even"><td>
...Considering my talk about Bowser and Gannon, you'd think I wouldn't be SO stupid as to look to close to the X-Stat Calc.<br><br>I
DID e-mail it. I didn't realize that it didn't go through until last
night. Don't understand how it failed to get in though...<br><br>At least I won't be last.  Yay Lopen!<br><br>Oh, and Ashe?  I think poking might not be sufficient.  &gt;_&gt;<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 11/2/2006 6:35:54 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344813267">message detail</a>
 | #173</td></tr>
<tr class="even"><td>
Oh, no. A poke will be just fine. It will just be a very hard poke, and it may use a knife instead of a finger. -_-<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2792167" class="name">Luis_Sera89</a> |
Posted 11/2/2006 1:24:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344854238">message detail</a>
 | #174</td></tr>
<tr class="even"><td>
I've finished my analysis of Crono/Auron. Could I just double check what Moltar's e-mail is?<br>---<br>Terrible demon. Ouch...
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/2/2006 3:07:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344872523">message detail</a>
 | #175</td></tr>
<tr class="even"><td>
<a class="linkification-ext" href="mailto:mastermoltar@gmail.com" title="Linkification: mailto:mastermoltar@gmail.com">mastermoltar@gmail.com</a><br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Yuna vs. Chun-Li - Bracket: <b>Yuna</b> - Vote: <b>Yuna</b> (68/76)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/2/2006 3:48:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344881736">message detail</a>
 | #176</td></tr>
<tr class="even"><td>
Zelda..................................56.87% 71597<br>Aeris Gainsborough.............43.13% 54300<br>TOTAL VOTES..............................125897<br><br>65.58% of the brackets predicted this match correctly.<br><br>Zelda
once again looks impressive while Aeris disappoints. In a match that
was projected to be close, Zelda wins by a good margin. Has Aeris
dropped, or Zelda boosted? I think it's a combination of the two.<br><br>Today, Yuna is doing very well against Chun-Li.<br><br>Moltar - 9<br>Lopen - 9<br>KH - 9<br>HM - 8<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Ulti - 7<br>Yoblazer - 4<br><br>Ulti takes the point in a close one.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Yuna vs. Chun-Li - Bracket: <b>Yuna</b> - Vote: <b>Yuna</b> (68/76)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 11/2/2006 4:02:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344884828">message detail</a>
 | #177</td></tr>
<tr class="even"><td>
Snake/Yoshi Analysis sent.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 6</i>: Han Solo (5-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 11/2/2006 6:40:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344923475">message detail</a>
 | #178</td></tr>
<tr class="even"><td>
You better not have gone stupid biased Leon, the guest spot desperately needs a point!<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3251974" class="name">trannyscience</a> |
Posted 11/2/2006 6:41:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344923631">message detail</a>
 | #179</td></tr>
<tr class="even"><td>
it's Leon!<br>---<br>zizzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 11/2/2006 6:41:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344923750">message detail</a>
 | #180</td></tr>
<tr class="even"><td>
Good point. :(<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 11/2/2006 6:43:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344924152">message detail</a>
 | #181</td></tr>
<tr class="even"><td>
Let's just say...Snake &gt; Mega Man confirmed! SFF in Mega Man/Yoshi? PSHAW!<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 6</i>: Han Solo (5-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 11/2/2006 8:22:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344949393">message detail</a>
 | #182</td></tr>
<tr class="even"><td>
-_-<br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/2/2006 8:28:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344951096">message detail</a>
 | #183</td></tr>
<tr class="even"><td>
Round 3 male half peeps are...<br><br>Snake vs. Yoshi - Leonhart4eva<br>Sora vs. Mega Man - KamikazePotato<br>Sonic vs. Luigi - Big Bob <br>Crono vs. Auron - Luis_Sera89<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Yuna vs. Chun-Li - Bracket: <b>Yuna</b> - Vote: <b>Yuna</b> (68/76)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 11/2/2006 8:29:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344951276">message detail</a>
 | #184</td></tr>
<tr class="even"><td>
If I don't get Samus/Zelda there will be hell to pay Moltar.<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 11/2/2006 8:29:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344951501">message detail</a>
 | #185</td></tr>
<tr class="even"><td>
I think guest should get the point today because Lugia's prediction
wasn't in the right spot. Mine went right after KH's, so it is clearly
the true guest prediction. =o<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 11/2/2006 8:30:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344951648">message detail</a>
 | #186</td></tr>
<tr class="even"><td>
<i>From PortugalTheMann</i><br><i>If I don't get Samus/Zelda there will be hell to pay Moltar.</i><br><br>Better get ready to pay up then, Moltar! Zelda/Samus is mine!<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 11/2/2006 8:32:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344952066">message detail</a>
 | #187</td></tr>
<tr class="even"><td>
You think Zelda is going to win, that should automatically disqualify you. &gt;_&gt;<br><br>I'm filled with the truth of Samus' bloody beating of Zelda!<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/2/2006 10:07:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344975617">message detail</a>
 | #188</td></tr>
<tr class="even"><td>
Ummm.......Snake/Yoshi?<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/2/2006 10:14:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344977131">message detail</a>
 | #189</td></tr>
<tr class="even"><td>
<i>From PortugalTheMann</i><br><i>I'm filled with the truth of Samus' bloody beating <b>at the hands</b> of Zelda!</i><br><br>You forgot a few words, but it has been fixed now!<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/2/2006 10:45:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344982943">message detail</a>
 | #190</td></tr>
<tr class="even"><td>
&lt;_&lt;<br><br><i>DpOblivion's Quick Analysis:</i><br><br>And
so we start a string of 5 straight matches featuring Noble 9 characters
facing non-Noble 9 characters. Yawn. If Vincent couldn't beat Sonic,
none of these should be even considered. But hey, good job for Yoshi
even getting to this point!<br><br>My vote: Yoshi<br>My bracket: Snake over Yoshi<br>My prediction: Snake with 59%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3623587" class="name">Gaddswell</a> |
Posted 11/2/2006 10:49:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344983692">message detail</a>
 | #191</td></tr>
<tr class="even"><td>
O_O<br><br>Analysis' not posted yet?<br>---<br>By the time we localize the programs, kids don&#8217;t even know they&#8217;re from Japan any more. - 4Kids CEO Al Kahn
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/2/2006 10:49:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344983696">message detail</a>
 | #192</td></tr>
<tr class="even"><td>
<b>Patriot Division:</b> <i>Round 3 - Match 53</i> &#8211; (1)Solid Snake vs. (3)Yoshi <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Snake</b><br>Round 1 &#8211; 82.15% vs. Soma (17.85%)<br>Round 2 &#8211; 57.59% vs. Squall (42.51%)<br><br>Snake does almost too well on Squall&#8230;some people even are calling for that crazy MGS/FF SFF thing.<br><br><b>Yoshi</b><br>Round 1 &#8211; 55.20% vs. Riku (44.80%)<br>Round 2 &#8211; 50.55% vs. Dante (49.45%)<br><br>I guess only 55% on Riku can put you above Dante.<br><br>Yep,
I just have to except it now. Riku has become a near-elite. I mean, I
seriously thought that performance spelled doom for Yoshi, but KH2 has
boosted Riku up from mid-carder to near-elite. That&#8217;s <i>crazy</i>,
but that win Yoshi pulled over Dante proves it. See, the Devil Divison
has been looking good this Contest, save Terra and Kerrigan, but they
suck anyway. Vincent looked legit, and may have even boosted more.
Squall&#8230;actually looks overrated, unless you believe that what Snake
scored on Squall last round was legit. Then again, a lot of factors
could lead to Snake overperforming by 5%. Most likely a Snake boost,
but Squall has also had his KH2 performance, and that should have
boosted him too.<br><br>Squall could have overperformed on Vincent last
year&#8230;but still, I&#8217;d rather just call something fishy here, as MGS vs.
FF matches always look fishy. Dante also looked legit it Round 1, and
looking at Luigi, and with the thought that Yoshi &gt; Luigi, Yoshi
might have been always above Dante, so his 2005 value looks about right
(though it may still put both Riku and Yoshi too high up&#8230;).<br><br>Ok,
stats rambling aside (hey, it&#8217;s good to finally get answers!), now we
have Snake/Yoshi. As we saw with Frog in 2005, and now Bowser in 2006,
characters who face Sprite Snake tend to overperform. Now Bowser
overperformed to a much smaller extent than Frog did (but come on, CT
sprite Frog versus a barely visible Solid ****? I&#8217;m not surprised.), so
I&#8217;m not expecting Yoshi to go wild. Also, with Snake&#8217;s regular picture
in the background, that should help Solid as well. <br><br>Ok, so
Snake wins, now it&#8217;s time to figure out the percentage. Using Luigi
2005 (because I can!), Snake gets around 42% on him. Now I just have to
factor in a slight Yoshi overperformance&#8230;and success! Man, I hope Yoshi
breaks 45% here, that&#8217;d be awesome! Also, I guess we should be happy
Dante didn&#8217;t have to face Snake, because if Squall was any indication,
Dante would have been <i>rocked!!</i> <br><br><b>Moltar&#8217;s Bracket Says:</b> Snake will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Snake: 55% - Yoshi: 45%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br> <br>Snake is yet again in the sprite round against a cute green animal. You know what this means...<br><br>Prediction: Snake with 53.19%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br><b>Solid Snake</b><br><br><i>Previous Matches:</i><br><br>Solid Snake &#8211; 82.15% -- 86,697<br><br>Soma Cruz &#8211; 17.85% -- 19,487 <br><br>Solid Snake &#8211; 57.59% -- 78,314<br><br>Squall Leonhart &#8211; 42.41% -- 57,666 <br><br><b>Yoshi</b><br><br><i>Previous  Matches:</i><br><br>Yoshi &#8211; 55.2% -- 69,394<br><br>Riku &#8211; 44.8% -- 56,325 <br><br>Yoshi &#8211; 50.55% -- 65,497<br><br>Dante &#8211; 49.45% -- 64,027 <br><br>Now <i>this</i>
certainly is an interesting match-up. Snake seems to have a thing for
going up against Mario characters in recent years. Last year, he took
out Bowser and Mario and now he&#8217;s set for a confrontation with Yoshi,
who is coming off of a very impressive win against Dante. Snake, too,
is coming off of a good win on Squall, who many thought had a chance to
break the Noble Nine before the match.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/2/2006 10:50:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344983864">message detail</a>
 | #193</td></tr>
<tr class="even"><td>As nice as it is to kick off the male bracket once
again, this match isn&#8217;t going to be one that will be very interesting,
I don&#8217;t think. Snake should pretty much dominate right out of the gate
and never look back. Some think there&#8217;s a chance for Yoshi to
overperform here thanks to the ugly Snake sprite (everyone wanted Ghost
Babel, remember <i>!!</i>),
but I think Snake&#8217;s artwork in the background will help him out
considerably. It looked to help in 2003 against Ryu at least! <br><br>So yeah, this match should go pretty easily in Snake&#8217;s favor. <br><br><b>Aitch Emm&#8217;s Bracket:</b> Solid Snake<br><br><b>Aitch Emm&#8217;s Prediction:</b> Solid Snake &#8211; 56% ; Yoshi &#8211; 44%<br><br><b>Aitch Emm&#8217;s Vote:</b> Solid Snake<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Ah,
the men are finally back action, and who better to kick things off than
the manliest man of them all? Box hiding, chain smoking, tranq
shooting, Codec instructions not understanding (Colonel... <i>what do you mean?</i>), ass kicking Solid Snake is here, and this time, he ain't fearin' no puny ass sprite picture.<br><br>That's
right, folks. It may look as terrible as usual, but Snake could care
less, and he'll prove that with an awesome performance against Yoshi
tonight. He's destroyed fodder in Round 1 and surpassed almost
everyone's expectations on Squall in Round 2, so I don't think the
lovable green dino, Yoshi, is going to put a damper on Snake's
fantastic run so far in the contest.<br><br>As an aside, I'd like to thank CJayC for getting the sprite round over and done with this early, as now Snake will <i>probably</i> get a decent picture against Mega Man (please, though, none of that 2004 putridocity).<br><br>My prediction: Solid Snake def. Yoshi (58-42)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Bout
time we whack some of these damned Nintendo sideshow characters! Oh
yes&#8230; I can feel the hatred for Nintendo welling up within me. How dare
you slay my two favorite characters, you miserable Mario vermin! DRONES
THAT VOTE FOR MARIO CHARACTERS MUST BE ERADICATED!<br><br>&#8230; oh&#8230; I'm sorry. Whatever has happened to me? &#8230; *ahem*<br><br>Well,
it isn't Solid ****, it's purple. How badly will this sprite hurt
Snake? We've all seen Snake get put in trouble because of it before.
Frog and Bowser come to mind. Although against Ryu in 2003 he seemed to
hold up against the sprite pretty well. I blame it on Ryu's sprite not
being much better, and it being the best sprite he's had. Seriously,
SF1? Ryu deserved to make the match with Snake 51-49 too!<br><br>Anyway,
that's really the main debatable factor in this matchup. Snake would've
taken Yoshi pretty easily without it, and he may even take Yoshi easily
<i>with</i> it. I don't Snake will lose, despite this close % I'm
calling for. Yoshi's fairly strong, but even with the sprite handicap I
don't think he's got enough. And even with the picture disadvantage,
maybe that scruffy thing on Snake's side in the background can help him
out a bit.<br><br><b>Lopen's prediction:</b> Solid Snake with 51.04%<br><br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br><b>SOLID SNAKE</b><br><br><i>"You want eternal rest? I've got it right here."</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 9th Place [35.23%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 8th Place [34.74%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 12th Place [30.82%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 9th Place [33.88%]<br><br>Snake turns a possible upset bid by Squall into an absolute crushing. Thanks, MGS/FF SFF!<br><br><b>YOSHI</b><br><br><i>"Now, let's go play, together. Together under the clearest of blue skies."</i><br><br>Summer 2003 Contest<br>Extrapolated Strength --- 23rd Place [26.17%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 26th Place [ 25.22%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 27th Place [26.59%]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/2/2006 10:51:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344983983">message detail</a>
 | #194</td></tr>
<tr class="even"><td>
Yoshi shocks my current expecations and confirms my pre-contest ones by
dispatching of Dante in a close one. Whatever works, I guess!<br><br><i>Notable Releases Since Last Appearance</i><br><br>Solid Snake: Metal Gear Solid 3: Subsistence (PS2), Super Smash Brothers Brawl Trailer (Internet)<br>Yoshi: N/A<br><br><i>Upcoming Releases</i><br><br>Solid Snake: Metal Gear Solid 4: Guns of the Patriots (PS3), Super Smash Brothers Brawl (WII)<br>Yoshi: N/A<br><br>Sprites? Sprites?! SPPPPPPPPPRRRRRRRRRRRRIIIIIIIIIIITTTTTTTTTESSSSSS!!!!<br><br>Yes,
it's the sprite round, and once again Solid Snake takes his position as
a temporary laughingstock as he reminds us that, yes, he had games back
then too.<br><br>In any other case this is an easy match to call
obviously, but Bowser and Frog say this could be very interesting
indeed. We'll get to that in a second.<br><br>However, I really don't think this will be all that interesting, if only due to the background picture.<br><br>Oh, and my percentage for Snake? Yeah, that's counting in a Yoshi overperformance.<br><br>Karma Hunter's Vote: <b>VOTE SNAKE</b><br><br><b>Karma Hunter's Krazy Prediction: Solid Snake with 57.04%.</b><br><br>Once again overestimating Snake blah blah don't care blah blah <i>Mega Man is so screwed</i> blah blah<br><br><b>Upset Potential: 0%<br><br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br><br>While <i>I</i>
like the Ghost Babel sprite, I've come to terms that I'm in the
minority with that opinion (this probably stems from the fact that I'm
the only person who's ever played that game). With this being arguably
his worst picture yet (though the background kinda disputes that), and
assuming Yoshi = Bowser with the only thing separating them being SFF,
Yoshi has a very real shot here. He just has to hope Snake hasn't
boosted.<br><br>Oh, and that Snake isn't INVINCIBLE.<br><br>Upset Prediction: Yoshi with 140.85%<br><br><br> <br><b>Guest&#8217;s Analysis</b> - <i>LeonhartForever</i><br><br>All
right, here&#8217;s Solid Snake&#8217;s final chance to prove he deserves the
status of &#8220;Favorite&#8221; against Mega Man. With the Blue Bomber&#8217;s oddly
unimpressive numbers in contrast to Snake&#8217;s dominant performances, he&#8217;s
lookin&#8217; good so far heading into part 3 of the thus far one-sided
rivalry. Can he pull a Crono and turn things around to get a win? <br><br>It&#8217;s
rather interesting to see that Solid Snake and Mega Man both face the
other&#8217;s Sweet Sixteen opponents from last year. In most cases, you&#8217;d
expect that to be a perfect gauge of their upcoming match, but&#8230;<i>Not so fast, my friend!!</i> <br><br>&lt;/Corso&gt; <br><br>Both
of them had strange overperformances against their opponents last year,
with Snake nearly matching what Samus did against Sora, and Mega Man
pulling in 68% on Yoshi. Suffice it to say that Snake is not getting
that much against the green dino (though it&#8217;d be awesome if he did<i>!!</i>), so he&#8217;ll have to prove his worth some other way. <br><br>Of
course, also working against Solid Snake in this match is his worst foe
of all: The Sprite Round! This time, he is represented as a little
blue&#8230;splotch of pixels against Yoshi. I used to think that Ghost Babel
would actually have decent sprites for Snake, but it turns out I was
wrong. Somebody needs to inform Hideo Kojima about the Character
Battles so he can work on a Metal Gear game for Game Boy Advance,
pronto! <br><br>Fortunately for Snake, CJayC did him a favor by
sticking a giant mugshot in the background of the pictures this round,
and behind him is the unmistakable Metal Gear Solid 2 Melting Snake
picture. That should help him out in terms of lessening the negative
effects the picture might have.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/2/2006 10:51:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344984099">message detail</a>
 | #195</td></tr>
<tr class="even"><td>As you remember, Solid Snake was on the verge of
collapsing the Noble Nine last year when he got stuck with a sprite
against Bowser in the Elite Eight. This could be a cause for concern,
especially after Crono exposed the Koopa King last round. But Bowser&#8217;s
always been stronger than Yoshi, right? Before the contest (heck, and
even as late as just a week ago), this appeared to be the case, but one
can&#8217;t help but wonder now. While Yoshi struggled to keep Riku below 45%
in his first round match, Bowser did the same against Leon Kennedy. Who
you would take in a match between Riku and Leon Kennedy should probably
give you an idea of where the two are in relation to another. <br><br>Going
into round 2, it didn&#8217;t even look like Yoshi would make it this far.
Dante was the favorite, and for good reason. He had just flatout looked
better in nearly every contest appearance, but the stars were aligned
just right as the day of that match was apparently the 3 year
anniversary of the first posting of LUEshi, as well as some other stuff
that&#8217;s best not mentioned at this point. Either way, the important
thing is that he won against a guy who got 46% on Vincent last year,
who nearly managed 48% on Sonic this year. It was a very impressive win
for Yoshi, and after Crono owned Bowser, it brought into question just
how close those two were. <br><br>Of course, we have to factor Luigi into the equation as well. <br><br>Wait, Luigi? What does he have to do with anything?  <br><br>Glad
you asked! Well, you see, Luigi beat Zero far more easily than even the
minority of Board 8 brackets that picked him expected, and then he went
and outdid Bowser&#8217;s performance against Kirby. Sure, that might mean
that the pink puffball&#8217;s performance last year was a fluke or
something, but it makes you think. Could Yoshi and Luigi have caught up
to Bowser? But this is SFF, right? Stuff like that shouldn&#8217;t happen! <br><br>Actually,
Solid Snake might have something to say about that. I personally
believe both of his matches against Squall Leonhart have been &#8220;SFF&#8221;
matches (for lack of a better term), but yet there was an 7-8%
differential in those performances. In other words, Squall gained a lot
of ground on him in those four years. What&#8217;s to say that Yoshi and
Luigi couldn&#8217;t have done the same? Sure, being from the same franchise
might affect that, but the possibility remains. <br><br>Now, why even
mention this? Considering the fact that Bowser had a shot at beating
Snake last year, if Yoshi is on equal footing with him this year, the
slight possibility is out there of the dino coming close in his own
right. Of course, Snake&#8217;s face shot in the background should neutralize
that to an extent. Plus, we might be dealing with an even stronger
Snake than last year. After all, he was essentially the star of this
year&#8217;s E3, with a Metal Gear Solid 4 trailer being release and then
shocking everybody by Nintendo revealing his inclusion in Super Smash
Brothers Brawl. Plus, he did have an actual release in Metal Gear Solid
3: Subsistence for those who disagree with the notion of a mere trailer
(or &#8220;trailor&#8221; as EC would say) doing anything of note. <br><br>In any
event, if Solid Snake wants to look like he can defeat Mega Man next
round, he can&#8217;t have any of those struggles he had against Bowser last
year. He&#8217;s got to win comfortably and hope for the Blue Bomber to
struggle against Sora. Expect Snake to start off with a high percentage
despite the Nintendo Power Hour and then watch him drop with the day
vote, as usual. Hopefully, he can do what Crono did to Bowser and soar
over 60% with that strong night vote of his! <br><br><b>Leonhart&#8217;s Prediction</b>: Solid Snake with 54.38%<br><br> <br> <br>Crew Consensus: Thank you Internet connection for crapping out for nearly 3 hours! Oh, and uh...Snake wins.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=395700" class="name">HaRRicH</a> |
Posted 11/2/2006 10:54:25 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344984530">message detail</a>
 | #196</td></tr>
<tr class="even"><td>
Methinks it's yo's point to lose.<br>---<br>Diddy did it.  Diddy did it.<br>DAMMIT!  What didn't Diddy do?!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3662060" class="name">YoAriel33</a> |
Posted 11/3/2006 12:50:55 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345001726">message detail</a>
 | #197</td></tr>
<tr class="even"><td>
Zelda vs. Aeris Gainsborough<br>+7 Ulti<br>+6 Guest<br>+5 HM<br>+4 Mo (tie)<br>+4 Yo (tie)<br>+2 Lo<br>-1 KH<br><br>Yuna vs. Chun-Li<br>+7 Mo (tie)<br>+7 Yo (tie)<br>+5 KH<br>+4 HM<br>+3 Ulti<br>+2 Guest<br>-1 Lo<br><br><b>The Rankings</b> (Through Yuna vs. Chun-Li)<br>1. Master Moltar (222)<br>2. Heroic Mario (210)<br>3. Karma Hunter (204)<br>4. Yoblazer (201)<br>5. UltimaterializerX (191)<br>6. Board 8 (166)<br>7. Lopen (123)<br><br>---<br><i>I don't know when, I don't know how, but I know something starting right now... <br>Watch and you'll see, someday I'll be... <b>part of your world!</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 11/3/2006 7:31:14 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345025751">message detail</a>
 | #198</td></tr>
<tr class="even"><td>
Bah, I knew I should've shot higher!<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 6</i>: Han Solo (5-0)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/3/2006 11:48:38 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345049936">message detail</a>
 | #199</td></tr>
<tr class="even"><td>
Yeah, too much overrating of Yoshi. Snake beat Squall by 57.59%, surely one should expect Squall to do better than Yoshi.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 11/3/2006 12:07:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345052365">message detail</a>
 | #200</td></tr>
<tr class="even"><td>
Well, if I thought Snake/Squall was entirely legitimate, I would have picked Snake to go higher, and I almost did.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 6</i>: Han Solo (5-0)
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=2">3</a></li>
<li>4</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=9">10</a></li>
</ul>
</div>


</div>
<img src="genmessage4_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage4_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31382187&amp;page=3" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage4_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>