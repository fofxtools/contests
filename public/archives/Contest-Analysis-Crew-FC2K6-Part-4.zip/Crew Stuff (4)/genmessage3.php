<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage3_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage3_files/nogs.css"></head><body linkifytime="270" linkified="3" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage3_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage3_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31382187%26page%3D2"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div style="text-align: center;">
<div style="text-align: center;"><img src="genmessage3_files/advertisement.gif" alt="advertisement" height="10" width="120"></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage3_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage3_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 4
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;page=2">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31382187" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=1">Previous Page</a> |
Page 3 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=3">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/29/2006 8:56:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344126646">message detail</a>
 | #101</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>This is a 3rd round match?
Come on. Rikku doesn't deserve 3 matches. You know what? This is Quick
Analysis....and this is over. There, nice and quick.<br><br>My vote: Hmm, someone I don't give a damn about, or someone I hate....Rikku<br>My bracket: Samus<br>My prediction: Samus with 72%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=683142" class="name">transience</a> |
Posted 10/29/2006 9:00:12 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344127530">message detail</a>
 | #102</td></tr>
<tr class="even"><td>
yeah, but Rikku was in KH2, no? even a small role, I'd expect that to be worth something.<br><br>also, if you think Bowser/Ryu was an anomaly, 45% is pretty decent.<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/29/2006 9:02:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344128038">message detail</a>
 | #103</td></tr>
<tr class="even"><td>
Rikku's role in KH2 is one of the biggest non-factors I can possibly think of. She had <i>one</i> very brief appearance as a <i>fairy</i>...thing. It won't do anything. <br><br>---<br>"Let's face it: the princess Zelda has always been a symbol of sexual desire."
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/29/2006 9:04:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344128567">message detail</a>
 | #104</td></tr>
<tr class="even"><td>
Yeah, she has like, 2 or 3 scenes, and I totally missed one of them
until I had to backtrack and see it later. I wouldn't expect too much
from that.<br><br><i>if you think Bowser/Ryu was an anomaly</i><br><br>*raises hand* Though, I'm not even sure what to think of Ryu 2005 or 2006 anymore.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Auron vs. Sub-Zero- Bracket: <b>Auron</b> - Vote: <b>Auron</b> (54/62)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=1832249" class="name">AmazingKirby</a> |
Posted 10/29/2006 9:05:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344128903">message detail</a>
 | #105</td></tr>
<tr class="even"><td>
One appearance? Try, like, 4.<br>---<br>caps
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/29/2006 9:06:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344129117">message detail</a>
 | #106</td></tr>
<tr class="even"><td>
And there's always the possibility of Samus being underrated or
boosting a tiny bit for no apparent reason or just beating out the
projections by a few points. I'd sooner expect Samus to exceed
projections here than undershoot them. If she can't manage a doubling,
for example, it'd be terribly disappointing.<br><br>---<br>"Let's face it: the princess Zelda has always been a symbol of sexual desire."
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=683142" class="name">transience</a> |
Posted 10/29/2006 9:07:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344129295">message detail</a>
 | #107</td></tr>
<tr class="even"><td>
escaping a doubling wouldn't surprise me <i>that</i> much - if Samus exceeds 70% here I'll be really impressed.<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 10/29/2006 9:07:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344129370">message detail</a>
 | #108</td></tr>
<tr class="even"><td>
<i>One appearance? Try, like, 4.</i><br><br>Okay. <i>Four</i> completely forgettable, completely stupid scenes that are going to do absolutely <i>nothing</i>
to her popularity. And don't even try to say it would because that
would just be so ridiculously biased...even for you. &lt;&lt;<br><br>---<br>"Let's face it: the princess Zelda has always been a symbol of sexual desire."
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=1832249" class="name">AmazingKirby</a> |
Posted 10/29/2006 9:09:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344129860">message detail</a>
 | #109</td></tr>
<tr class="even"><td>
Hey, <i>I</i> remembered them!<br>---<br>caps
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/29/2006 10:50:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344152297">message detail</a>
 | #110</td></tr>
<tr class="even"><td>
I expect the stats to be pretty dead on... If Samus is underrated than so is Rikku. Oh, and darn you lopen.<br><br>Oh well... 20/21 possible points on the guest spot isn't so bad.<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/29/2006 10:54:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344152909">message detail</a>
 | #111</td></tr>
<tr class="even"><td>
Oh wow... silly me. I thought Samus was going against <i>Yuna</i> today. Hmmm... well I'm smoking something, and it must be good! Alright, Samus totally thrashes faces.<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/29/2006 11:06:18 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344155220">message detail</a>
 | #112</td></tr>
<tr class="even"><td>
Ugh, only 35.87% get the match right, but I don't move up on the
leaderboard. Looks like I won't be beating my record for highest spot
(#13).<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=1502018" class="name">ShatteredElysium</a> |
Posted 10/30/2006 2:25:16 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344178716">message detail</a>
 | #113</td></tr>
<tr class="even"><td>
Looks like I may have under shot my prediction in this match. I really
though the boost Samus received in the adjusted X-stats was too high
last year hence why I went under the x-stats rating. Silly me for
doubting lol x-stats. Hopefully Rikku will eat in to the percentage
marginally so I don't come last.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 10/30/2006 12:48:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344226272">message detail</a>
 | #114</td></tr>
<tr class="even"><td>
You thought she was overrated? It's a good thing she's underrated!<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=605982" class="name">smasherx</a> |
Posted 10/30/2006 12:53:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344226945">message detail</a>
 | #115</td></tr>
<tr class="even"><td>
If the rest of my bracket is perfect, can I join the analysis crew next year?<br>---<br><b>#1</b><br>Upcoming: Samus, Tifa, Zelda, Yuna
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=640243" class="name">Big Bob</a> |
Posted 10/30/2006 12:59:57 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344227785">message detail</a>
 | #116</td></tr>
<tr class="even"><td>
Random thought: I would take Rikku to beat Yuna.<br>---<br>Gordon
Freeman finally won, but somehow, the universe survived... thus
allowing me to tell said universe about how I was owned by <b>NClark128</b>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 10/30/2006 1:01:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344227969">message detail</a>
 | #117</td></tr>
<tr class="even"><td>
<i>Four completely forgettable, completely stupid scenes that are going
to do absolutely nothing to her popularity. And don't even try to say
it would because that would just be so ridiculously biased...even for
you. &lt;&lt;</i><br><br>I dunno. I thought the Gullwings stealing Yuffie's ice cream was pretty hardcore.<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 5</i>: W, 35-15 vs. Darkwing Duck
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/30/2006 3:37:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344256264">message detail</a>
 | #118</td></tr>
<tr class="even"><td>
Auron............................59.63% 80252<br>Sub-Zero........................40.37% 54325<br>TOTAL VOTES.........................134577<br><br>35.87% of the brackets predicted this match correctly.<br><br>Good
ol' bracket hurting Master Chief. Only 36% had Auron winning his
four-pack, which is pretty sad. Anyway, Sub-Zero looks very good here,
even breaking 40% against Auron. I'm impressed.<br><br>Today, Samus is doing slightly better than projected against Rikku.<br><br>Lopen - 9<br>KH - 9<br>HM - 8<br>Moltar - 8<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Ulti - 6<br>Yoblazer - 3<br><br>Hit for Lopen, as going low pays off.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Samus vs. Rikku - Bracket: <b>Samus</b> - Vote: <b>Samus</b> (56/64)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/30/2006 8:49:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344337850">message detail</a>
 | #119</td></tr>
<tr class="even"><td>
Ulti is second to last? What the hell's going on?<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 10/30/2006 8:50:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344338221">message detail</a>
 | #120</td></tr>
<tr class="even"><td>
I agree, Dp. It's a disgrace that he is above Yo.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3605461" class="name">chaosarcher07</a> |
Posted 10/30/2006 9:04:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344342220">message detail</a>
 | #121</td></tr>
<tr class="even"><td>
Lopen is DESTROYING THE CREW<br>---<br>My FC2K6 Bracket: 54/64<br>Next match prediction: Samus
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/30/2006 9:20:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344346441">message detail</a>
 | #122</td></tr>
<tr class="even"><td>
<b>Limit Division:</b> <i>Round 3 - Match 50</i> &#8211; (1)Tifa Lockhart vs. (2)Princess Peach <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Tifa</b><br>Round 1 &#8211; 76.18% vs. Ivy (23.82%)<br>Round 2 &#8211; 74.55% vs. The Boss (25.45%)<br><br>Ouch, The Boss doesn&#8217;t look so hot against Tifa.<br><br><b>Peach</b><br>Round 1 &#8211; 83.10% vs. Daisy (16.90%)<br>Round 2 &#8211; 50.01% vs. Jill (49.99%)<br><br>Jill still can&#8217;t break that 27 vote barrier against her opponent&#8230;<br><br>Hmm,
in a match that was moderately exciting compared to the male bracket,
Peach just barely makes it into Round 2. However, she was facing a Jill
who was not at her 2004 strength. (Peach = Ryu H? Get out of my face).
So where does this put both Ms. Valentine and the Princess? Low
midcarders, which is what most expected them to be. This means they&#8217;re
nowhere near Tifa&#8217;s level, so Tifa wins with blow-out ease.<br><br>Heck,
low-midcards like Peach don&#8217;t belong in the Sweet Sixteen.
Low-midcarders lose at the latest Round 2. In fact, let&#8217;s look at
another low-midcarder who was snubbed thanks to the female bracket, and
like Jill, he knows how to put on a good match.<br><br><b>Real Men, Real Snubs</b> - <i>Kefka</i><br><br>A
clown. An angel. A piece of lettuce. All these words could be used to
describe this character. His name is Kefka, and he&#8217;s a real man, and a
snub in the 5th Character Battle.<br><br>*Shot of Kefka destroying the world*<br><br>Kefka
entered the Contest scene in 2003, and people had high expectations for
him. People thought Final Fantasy 6 characters would be as strong as
the characters from other Final Fantasy games. Well, they were soon
proven otherwise, because out of the gate, Kefka struggled with
Pac-Man&#8230;hohoho! In a back and forth battle, the clown nearly beat
Pac-Man. His next match then showed him getting destroyed by Crono with
over 78% of the vote. Lol ff6, huh?<br><br>*Shot of Kefka running from Crono*<br><br>Oh,
but he was back in 2004 to ruin more brackets! His Round 1 match was
against Knuckles, and Kefka was the favorite to win. However, for
anyone who thought longer than 3 seconds on this match saw that
Knuckles had this all but locked up. I mean, you don&#8217;t go from
struggling with Pac-Man to beating Knuckles. And that&#8217;s what Kefka
did&#8230;he lost, and with that put a dent in many brackets. Oh Kefka&#8230;and
even in 2005, &#8220;Franz&#8221; Kefka was even a bigger bracket favorite than
casual favorite Tommy Vercetti! In a match that will be remembered for
it&#8217;s barriers and craziness, Kefka suffered another crushing blow.<br><br>*Shot of Vercetti breaking through Kefka&#8217;s barriers*<br><br>But
where is he now? Not in this Contest. Sure, he&#8217;s weak, just like all
the other FF6 characters, so why should he come back? Simple, with him
around, more people pick him to win in matches he&#8217;ll certainly lose.
That makes the smart people who don&#8217;t pick him look better! Also, in
his three years, he&#8217;s put on an interesting match each time, and that&#8217;s
more than the female bracket has given us.<br><br>*Shot of Kefka frowning in a lone spotlight*<br><br>Kefka. A real man, and a real snub. (And a loser too!)<br><br><b>Moltar&#8217;s Bracket Says:</b> Tifa will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Tifa: 68% - Peach: 32%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br> <br>Peach
had a nice run this contest, including last round's classic. But not
even I, Peach's biggest fanboy am dumb enough to think that she has a
chance here. Hell, it'll be a moral victory if she so much as breaks
30%.<br><br>Prediction: Tifa with 67.67%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br> <b>Tifa Lockhart</b><br><br><i>Previous Matches:</i><br><br>Tifa Lockhart &#8211; 76.18% -- 96,118<br><br>Ivy Valentine &#8211; 23.82% -- 30,046 <br><br>Tifa Lockhart &#8211; 74.55% -- 90,595<br><br>The Boss &#8211; 25.45% -- 30,934 <br><br><b>Princess Peach</b><br><br><i>Previous Matches:</i><br><br>Princess Peach &#8211; 83.1% -- 90,611<br><br>Princess Daisy &#8211; 16.9% -- 18,423 <br><br>Princess Peach &#8211; 50.01% -- 59,239<br><br>Jill Valentine &#8211; 49.99% -- 59,266
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/30/2006 9:21:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344346718">message detail</a>
 | #123</td></tr>
<tr class="even"><td>
It&#8217;s <i>very</i> nice seeing Peach sitting nice
in round 3 after just escaping a loss to Jill Valentine. Partially
because I prefer Peach and partially because Nintendo/Square encounters
are always good to see. Tifa had a pretty solid performance last round
as well by disposing of The Boss without much of a problem. <br><br>What
will be interesting about today&#8217;s match is to see just how much
strength Peach actually has. We&#8217;ve seen her just brutally destroy Daisy
and squeak out a close against Jill Valentine. There may be something
to the whole &#8220;Peach gets votes until she&#8217;s up against someone people
care about.&#8221; Sure, people may care about Jill, but that isn&#8217;t the test
like this is. It&#8217;ll be interesting to see how well Peach holds up. <br><br>Tifa
isn&#8217;t in any sort of danger here one way or another. She can
underperform all she wants and it won&#8217;t make much difference
considering her opponent is Samus. An overperformance might be in the
cards, but I doubt it will make much difference unless it&#8217;s just a
brutal beat down, which I don&#8217;t anticipate happening. <br><br>This is
just another unfortunate no-brainer in the female bracket &#8211; and with
two characters I don&#8217;t particularly care too much about &#8211; so on to
Zelda&#8217;s demolition of Aeris <i>!!</i> <br><br><b>Aitch Emm&#8217;s Bracket:</b> Tifa Lockhart<br><br><b>Aitch Emm&#8217;s Prediction:</b> Tifa Lockhart &#8211; 67% ; Princess Peach &#8211; 33%<br><br><b>Aitch Emm&#8217;s Vote:</b> Princess Peach<br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br>  <br>Tifa
will obviously win the match, but I think (the now legendary...sorry
Jill) Princess Peach will draw enough Nintendo support to avoid the
doubling. And that's... really all I gots to say about that.<br><br>My prediction: Tifa Lockheart def. Princess Peach (66-34)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Well, I guess Peach <i>wasn't</i>
mega fodder after all. Damn, I hate being wrong about outrageous calls.
In any case, mega fodder or not, Peach doesn't have a realistic chance.
Tifa beat the more popular Luigi last year. It wasn't a <i>commanding</i> victory, but it was a victory nonetheless.<br><br>Now
the question for the silly %age guessing game is this: How much more
popular is Luigi than Peach? Or heck, you know what the real question
is? Is Jill Valentine more or less popular than 2 years ago? I know
that's what the other analysts are gonna be thinking, regardless of
whether they admit it. Tifa gets 67.04% on 2k4 Jill Valentine, expect
plenty of scores in that neighborhood. Yeap.<br><br><br>Now I'm
conflicted, here. Intuition tells me that Jill dropped and also that
Peach isn't that popular. (I didn't say fodder again!) <i>Bias</i> tells me that "Sheena couldn't <i>possibly</i> be that weak! Jill must've rose to 2k2 levels <i>!!</i>".<br><br>But
bias also enjoys seeing Peach, Daisy, and Jill as weak as possible!
Sorry, Sheena, you're gonna have to take one for the team! Wait wait&#8230; I
thought of something. Something to justify a high %! I remember what I
said: "Peach will be like Nintendo's Pac-Man, she'll be able to defeat
fodder easily (and apparently some mid-carders) but she'll utterly
collapse against good competition!". Peach&#8230; meet good competition! <i>Yeahhh!</i><br><br><b>Lopen's Prediction:</b> Tifa with 71.49%<br><br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br>Tifa Lockheart<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 16th Place [30.77%]<br><br>Tifa puts another feather in the cap of the FF/MGS SFF argument. Schweet.<br><br>Princess Peach<br><br>lol N/A<br><br>Peach hands Jill her second 27 vote loss of her contest career. Poor Jill...<br><br><i>Notable Releases Since Last Appearance</i><br><br>Tifa Lockheart: Kingdom Hearts 2 (PS2)<br>Princess Peach: Super Mario Bros. 2 (NES), Super Mario RPG (SNES),<br>Super Princess Peach (DS)<br><br><i>Upcoming Releases</i><br><br>Tifa Lockheart: N/A<br>Princess Peach: N/A
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/30/2006 9:21:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344346963">message detail</a>
 | #124</td></tr>
<tr class="even"><td>
I'm going out to get FFXII as we speak, so you get another Ulti-style
writeup. Only one that's biased against Peach! DIE JOKE FODDER DIE<br><br>Karma Hunter's Vote: ...no.<br><br><b>Karma Hunter's Krazy Prediction: Tifa Lockheart with 67.55% .</b><br><br>More
or less what the stats say -- Peach should be stronger than Jill 2k4,
but we should also have a stronger Tifa here. Hence, this.<br><br>Upset Potential: 0%<br><br>HAHAHAHAHAHAHAHAHAHA<br><br><br> <br><b>Guest&#8217;s Analysis</b> - <i>Vlado</i><br><br>And
so, we have another match with a clear outcome. Unfortunately, it seems
Tifa won't have what's at least close battle this contest (a.k.a. she's
not gonna face Zelda, the only opponent who could've given her a close
match in the female half). Samus is still too strong, it seems Tifa
wouldn't be able to threaten her, but I still believe she'll give her a
very close one, at least. Tifa is much stronger than last year, and
she'll prove it.<br><br>So now, let's look at her opponent. Peach is
someone who definitely didn't deserve to make it so far. Vote stuffing
aside, if bracket voting weren't a factor, Jill would have beaten her
with relative ease. Well, the two are close enough to consider their
strength equal, of course. This contest has, however, proven that Peach
is not even remotely close to Yoshi and Luigi, who defeated much
stronger opponent with much greater margin.<br><br>"lol xstats" say
Tifa would get around 64-65% on Ryu Hayabusa last year. Well, as we've
seen, Ryu = Jill = Peach. However, Tifa this year is much stronger than
she was a year ago. It's a given she'll score better on Samus than she
did on Sonic last year. Advent Children and Dirge of Cerberus, as well
as the upcoming release of Final Fantasy XII (in just a couple of
hours, this will definitely affect today's match), are important
factors that should boost her a few percent. The Boss, Tifa's last
opponent, is definitely weaker than Peach and Jill, however, the margin
can't be very big. Whether there was some SFF in that match, however,
as we've seen in pretty much every FFVII/Metal Gear battle, is anyone's
guess.<br><br>So, Tifa is the absolute favourite here, anything below a
doubling will be a surprise. In fact, if Tifa fails to double Peach,
you might as well write her off completely for her match against Samus.
Not even a supposed FFXII boost for FF characters can help her much
unless she's already very strong. So yeah... Tomorrow's match is a test
for Tifa's true strength and her ability to threaten Samus. Without
doubt, she's Samus' strongest opponent in the female half and, should
Samus beat her, the female champ will be clear. To those who like to
suggest impossible scenarios, no, Zelda can't beat Samus, in fact,
she'd just get SFF'd like Ganon was last year, and definitely lose by
more than Tifa would, even if their strength is somewhat close.<br><br>As
for Peach, avoiding a doubling would be an achievement for her. I hope
it doesn't happen, I'd rather have my hopes get crushed in a week than
now. At the end, Peach was the Nintendo character who got the closest
to losing to a non-Noble Nine opponent, which exposes her as by far
Nintendo's weakest representative at this point. Let me reiterate, if
bracket voting didn't exist, Jill would have won that match by at least
1000 votes.<br><br>So, Tifa has nothing to worry about. Much like in
the previous two battles, the only thing she has to fight against is
herself, and the percentage numbers. Should she double Peach, she's
definitely in good shape to challenge Samus, once FFXII hype has really
picked up and there are much more FF fans on the site than usual. I
expect Tifa to achieve that doubling, and then some. I hope I don't get
disappointed so early.<br><br>Prediction: <b>Tifa with 70.63%</b>.<br> <br> <br> <br>Crew Consensus: Tifa with the easy win over Peach. Mid-high 60's to low 70's...kinda the same range Samus had.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3605461" class="name">chaosarcher07</a> |
Posted 10/30/2006 9:26:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344348199">message detail</a>
 | #125</td></tr>
<tr class="even"><td>
Vlado doesn't have the highest pick?<br>---<br>My FC2K6 Bracket: 58?/68?<br>Next match prediction: Zelda
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=152338" class="name">Lopen</a> |
Posted 10/30/2006 9:27:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344348543">message detail</a>
 | #126</td></tr>
<tr class="even"><td>
Hahaha... <i>told ya!</i>  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/30/2006 9:28:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344348766">message detail</a>
 | #127</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>I can't even think about
these blowout matches, not with Aeris/Zelda looming around the corner.
Peach beat Jill by 27 votes, so there's no chance in hell of her
beating Final Fantasy's babe, Tifa.<br><br>My vote: Princess Peach<br>My bracket: Tifa<br>My prediction: Tifa with 69%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=395700" class="name">HaRRicH</a> |
Posted 10/30/2006 9:28:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344348823">message detail</a>
 | #128</td></tr>
<tr class="even"><td>
I'm surprised, too.  I'm not sure if I should support Vlado or insult Lopen for this!<br>---<br><a class="linkification-ext" href="http://wemajor12.myrockinprofile.com/" title="Linkification: http://wemajor12.myrockinprofile.com/">http://wemajor12.myrockinprofile.com/</a><br>Next celebrity I hope to out-rank:  Adam Sandler (#1)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=640243" class="name">Big Bob</a> |
Posted 10/30/2006 9:29:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344348955">message detail</a>
 | #129</td></tr>
<tr class="even"><td>
<b><i>Big Bob's completely biased and nonsensical analysis</i></b><br><br>You
may think Tifa has this match in the bag, but I gotta tell you
something: Peach beat JILL. Do I have to remind you that in 2k3, Jill
outdid Luigi's percentage on Squall? The same Squall that was behind
Link/Samus SFF? Jill's still strong, especially with the Resident Evil
boost. And now it's time for Peach to show her stuff. Tifa beat Luigi
last year, but it wasn't too impressive. And did anyone who wasn't a
FFVII fan before really like Tifa now that Advent Children came out?<br><br>Also,
keep in mind how much Luigi has boosted. If Peach is stronger than
Luigi, and Luigi boosted since NSMB, Peach is likely to boost as well.
She easily had a larger part in that game than Luigi or Bowser.<br><br>Bob's Prediction: <b>Peach with 60%</b><br>---<br>Gordon
Freeman finally won, but somehow, the universe survived... thus
allowing me to tell said universe about how I was owned by <b>NClark128</b>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/30/2006 9:33:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344350115">message detail</a>
 | #130</td></tr>
<tr class="even"><td>
Hmm, I actually like Yo's pick the best at the moment. I have a bad feeling Peach will do well tommorrow.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Samus vs. Rikku - Bracket: <b>Samus</b> - Vote: <b>Samus</b> (56/64)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=152338" class="name">Lopen</a> |
Posted 10/30/2006 9:34:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344350180">message detail</a>
 | #131</td></tr>
<tr class="even"><td>
Insult me while you can, HaRRicH... Vlado and I are the only two in <i>contention</i> for this point!  Soon we shall behold the power of The Pac-Man Factor in all its glory!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=981127" class="name">Cavalier Lowen</a> |
Posted 10/30/2006 9:34:31 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344350220">message detail</a>
 | #132</td></tr>
<tr class="even"><td>
<i>I have a good feeling Peach will do well tommorrow.</i><br><br>Fix'd<br>---<br>Z1mZum owned me in the guru contest (by two points!).  Damn you Z1mZum!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/30/2006 9:36:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344350767">message detail</a>
 | #133</td></tr>
<tr class="even"><td>
The better Peach does, the better she looks, and that's <i>no good!!</i><br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Samus vs. Rikku - Bracket: <b>Samus</b> - Vote: <b>Samus</b> (56/64)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3251974" class="name">trannyscience</a> |
Posted 10/30/2006 9:37:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344350874">message detail</a>
 | #134</td></tr>
<tr class="even"><td>
I like Lopen's analysis. one of my favourite analyses of the contest so far!<br>---<br>zizzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/30/2006 10:51:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344368100">message detail</a>
 | #135</td></tr>
<tr class="even"><td>
Moltar's pretty dead-on for today's prediction.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/30/2006 11:04:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344370442">message detail</a>
 | #136</td></tr>
<tr class="even"><td>
Moltar&#8217;s Prediction is: Samus: 69% - Rikku: 31%<br><br>Samus Aran  69%   85439<br>Rikku  31%  38387<br><br>Hooray Moltar!<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 10/30/2006 11:06:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344370868">message detail</a>
 | #137</td></tr>
<tr class="even"><td>
Nice freaking job Moltar. Although it was kinda lucky 'cause you never go into even tenths of a percentage, heh.<br>---<br>CB06 - Score: <b>62/68 </b>Rank: <b>Tied - 424th </b>Yesterday's Pick:<b> Samus</b> <br>Today's Pick: <b>Tifa</b> Tomorrow's Pick: <b>Zelda</b> Losses: <b>Cortana, Ganon, Zero, MC, Kirby</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3662060" class="name">YoAriel33</a> |
Posted 10/30/2006 11:39:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344376076">message detail</a>
 | #138</td></tr>
<tr class="even"><td>
Crono vs. Bowser<br>+7 KH<br>+6 Lo<br>+5 Ulti<br>+4 Mo<br>+3 Yo<br>+2 HM<br>+1 Guest<br><br>Auron vs. Sub-Zero<br>+7 Lo<br>+6 Guest<br>+5 Yo<br>+4 HM (tie)<br>+4 Mo (tie)<br>+2 KH<br>+1 Ulti<br><br>Samus Aran vs. Rikku<br>+7 Mo<br>+6 Ulti<br>+5 HM<br>+4 Yo<br>+3 Lo<br>+2 KH<br>+1 Guest<br><br><b>The Rankings</b> (Through Samus vs. Rikku)<br>1. Master Moltar (208)<br>2. Heroic Mario (195)<br>2. Karma Hunter (195)<br>4. Yoblazer (183)<br>5. UltimaterializerX (177)<br>6. Board 8 (156)<br>7. Lopen (121)<br><br>And
Heroic Mario once again pulls into a tie with Karma Hunter. With his
lower Tifa prediction, HM is heavily favored to have sole possession of
second place by tomorrow. Not bad for a guy who picked Ganondorf to win
four matches. &gt;_&gt;<br>---<br><i>I don't know when, I don't know how, but I know something starting right now... <br>Watch and you'll see, someday I'll be... <b>part of your world!</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=625761" class="name">LordLockeRA</a> |
Posted 10/31/2006 1:35:53 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344389322">message detail</a>
 | #139</td></tr>
<tr class="even"><td>
Did Vlado just say SAMUS was going to SFF another Nintendo character?<br><br>In other news, the sky is falling.<br>---<br>Meeh.  Whatever.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=683142" class="name">transience</a> |
Posted 10/31/2006 1:59:17 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344390848">message detail</a>
 | #140</td></tr>
<tr class="even"><td>
WOO GUEST<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=254355" class="name">Lugia2</a> |
Posted 10/31/2006 5:45:57 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344402411">message detail</a>
 | #141</td></tr>
<tr class="even"><td>
Lopen, when you're wrong, you're wrong.  You only seem to get points when you're with the majority.<br><br>Besides
him and Vlado, it's really surprising how close you all were. Just
within a couple of points! Even Karma Hunter didn't go insane...And he
called Peach fodder, in spite of having Peach behind by just one more
point. Interesting...<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/31/2006 4:02:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344474632">message detail</a>
 | #142</td></tr>
<tr class="even"><td>
Samus Aran.....................69% 85439<br>Rikku...............................31% 38387<br>TOTAL VOTES......................123826<br><br>83.95% of the brackets predicted this match correctly.<br><br>This
match ends up pretty close to the projected result. Seems Rikku was
more or less legit in 2005, and Samus hasn't lost a step either.<br><br>Today, Peach is doing just fine against Tifa.<br><br>Moltar - 9<br>Lopen - 9<br>KH - 9<br>HM - 8<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Ulti - 6<br>Yoblazer - 3<br><br>It's like I looked into the future for my perfect pick!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Tifa vs. Peach - Bracket: <b>Tifa</b> - Vote: <b>Tifa</b> (60/68)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=152338" class="name">Lopen</a> |
Posted 10/31/2006 6:26:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344505638">message detail</a>
 | #143</td></tr>
<tr class="even"><td>
<i>You only seem to get points when you're with the majority.</i><br><br>I'll have you know most of my points come from being far from the majority!  Or... at least a good half!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 10/31/2006 7:40:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344522636">message detail</a>
 | #144</td></tr>
<tr class="even"><td>
<i>DpOblivion's Extremely Quick Analysis:</i><br><br>I don't even give a **** anymore. Zelda wins.<br><br>My vote: Zelda<br>My bracket: Aeris<br>My prediction: Zelda with 58.18%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/31/2006 8:39:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344536799">message detail</a>
 | #145</td></tr>
<tr class="even"><td>
<b>Triforce Division:</b> <i>Round 3 - Match 51</i> &#8211; (1)Princess Zelda vs. (2)Aeris Gainsborough <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Zelda</b><br>Round 1 &#8211; 86.08% vs. Carmen (13.92%)<br>Round 2 &#8211; 79.45% vs. Terra (20.55%)<br><br>Zelda puts up some scary numbers on Terra.<br><br><b>Aeris</b><br>Round 1 &#8211; 69.78% vs. Marle (30.22%)<br>Round 2 &#8211; 61.65% vs. KOS-MOS (38.35%)<br><br>Aeris does decently on KOS-MOS.<br><br>Hey, a match in the female bracket that&#8217;s actually important! Time to pay attention to this one! Zelda or Aeris? <i>Let&#8217;s rock!</i><br><br>Before
the Contest, this match didn&#8217;t get much talk. Many people went with
Zelda, reasoning being either TP or 46% on the strongest Snake yet, and
called it a match. There have been some Aeris supporters, who may have
had arguments before the Contest with KH2 and AC and stuffs, but now?<br><br>Eh&#8230;let&#8217;s
just say Aeris hasn&#8217;t looked too hot. 70% on some CT character is
alright, I guess, and what she got on KOS-MOS doesn&#8217;t really look good
no matter how you spin it&#8230;but does this mean that Aeris didn&#8217;t benefit
much, or even at all from KH2? Hard to say. <br><br>Zelda, on the
other hand, has been very impressive as usual. Yeah, her opponents were
total fodder, but the numbers are still impressive. I mean, I didn&#8217;t
think Zelda was in much trouble here before the Contest, and I don&#8217;t
feel any worse now.<br><br>&#8230;Yeah, that&#8217;s the best Round 3 has to offer
us. LoZ vs. FF7&#8230;and it won&#8217;t even be all that good. Stupid matches that
are close but not close enough to be interesting. FFXII may help keep
Aeris in the game, but I&#8217;m expecting Zelda to be looking better than
ever.<br><br><b>Moltar&#8217;s Bracket Says:</b> Zelda will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Zelda: 54% - Aeris: 46%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br> <br>This
WAS debatable match until last round happened. Zelda goes berserk on
Terra, while Aeris struggles to break 60% on a cult RPG icon in
KOS-MOS. Xenosaga 3 didn't move KOS-MOS anywhere, and any fan of the
game will tell you that. Aeris just bombed, plain and simple. What was
a debatable match has the potential to start a Zelda &gt; Samus
bandwagon.<br><br>Honestly, Aeris might be thankful just to break 45%,
and I seriously wouldn't be shocked to see Zelda break 60 here. Vincent
&gt; Tifa &gt; Aeris comfirmed!<br><br>Prediction: Zelda with 57.46%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br> <b>Zelda</b><br><br><i>Previous Matches:</i><br><br>Zelda &#8211; 86.08% -- 102,509<br><br>Carmen Sandiego &#8211; 13.92% -- 16,578 <br><br>Zelda &#8211; 79.45% -- 92,826<br><br>Terra Branford &#8211; 20.55% -- 24,005 <br> <br><br><b>Aeris Gainsborough</b><br><br><i>Previous Matches:</i><br><br>Aeris Gainsborough &#8211; 69.78% -- 80,305<br><br>Marle &#8211; 30.22% -- 34,779 <br><br>Aeris Gainsborough &#8211; 61.65% -- 70,006<br><br>KOS-MOS &#8211; 38.35% -- 43,543 <br><br><i>The</i>
match of the female bracket is finally here! &#8230;But it&#8217;s not going to be
nearly as exciting as some people were thinking pre-contest! Since the
start of the contest, Zelda has come out looking absolutely <i>dominative</i>
against both of her opponents. She scored the highest blowout in round
1 and also is still the only character to ever get 100,000 individual
votes. She came out strong in round 2, too, with about a 7%
overperformance on Square&#8217;s own Terra Branford. Needless to say, she&#8217;s
looked good enough to take the <i>entire</i> bracket, but we just give the crown to Hyrule&#8217;s lovely princess just yet!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/31/2006 8:40:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344536984">message detail</a>
 | #146</td></tr>
<tr class="even"><td>
Zelda&#8217;s competition, however, has not looked good at all. Aeris came
out with what was considered an underperformance by failing to break
70% on Marle. She <i>then</i> went on to undershoot <i>all</i> of her 2003 projections on <i>all</i> of KOS-MOS&#8217;s values, from 2003 &#8211; 2005. It&#8217;s pretty clear to me that Aeris&#8217;s best case scenario is to be <i>equal</i>
to her old value, much less increase. In all likelihood, and this
wouldn&#8217;t be surprising, Aeris might end up back at her old 2002 value.
The fact that she gained a minor 2% in the year that Square was at
their absolute <i>finest</i> -- AKA, &#8220;Square shift&#8221; &#8211; it should speak well about her now. <br><br>There&#8217;s also the fact that Aeris has not made another appearance in the bracket in <i>three</i>
years. Even after CJayC dropped the company cap, she still was not able
to make it. The fact that it took her until there was a guaranteed spot
for 32 females speaks wonders, I think. Aeris 2k3 just isn&#8217;t the Aeris
now. And this isn&#8217;t relying on Aeris weakness to win because Zelda was <i>already</i> expected to beat her with about 51% in 2005 (and I expect Zelda to have boosted a bit), when using Aeris 2k3.  <br><br>I
expect this match to go in favor of Zelda with absolute ease. I don&#8217;t
think we&#8217;re going to see her struggle here. I have a feeling that Zelda
will put up some pretty dominant numbers to go along with her other
performances. Can she beat Samus? We can hope! But as for now, she can
just assume her role as the &#8220;Square Killer&#8221; for this contest (Terra,
Aeris, <i>and</i> Yuna)! <br><br>Oh, and by the time this is posted
and you&#8217;re reading, as well as by the time the match starts, there
should be a brand-new Twilight Princess trailer out, along with
detailed impressions from the final version from tons of media outlets.
Why does do, aside from the obvious? It certainly helps that Zelda is
finally shown in-game casting a badass spell <i>!!</i> <br><br><b>Aitch Emm&#8217;s Bracket:</b> Zelda<br><br><b>Aitch Emm&#8217;s Prediction:</b> Zelda &#8211; 55% ; Aeris Gainsborough &#8211; 45%<br><br><b>Aitch Emm&#8217;s Vote:</b> Zelda!<br><br><br> <br><b>Yoblazer&#8217;s Analysis</b><br> <br>Unless
Chun-Li brings in her A+++ game out of nowhere, this is probably the
only third round match with any potential. Such a shame, huh?<br><br>Going
by both their first two matches, there's no question who's heading into
this match as the favorite. While Aeris has failed to impress on two
separate occasions, Zelda has been one of, if not <i>the</i> most
impressive entrants in either half of the bracket. She had one of the
most legendary performances in Character Battle history against Carmen
Sandiego, becoming the first character to ever break 100,000 individual
votes, and the first non-Noble 9 character to win with over 85% of the
vote.<br><br>Of course, obliterating fodder and beating legitimately
strong characters are far from one in the same. Even though Aeris has
not matched Zelda's level of utter dominance, she's still a character
with a very impressive two-year contest history under her belt. She has
broken 43% against Solid Snake, 47% against Sonic the Hedgehog, and
doubled Sora via some wicked SFF. Don't get me wrong - I still expect
Zelda to win this match without much trouble, but I would be surprised
if Aeris weren't to put up a respectable performance, and I'd be
completely shocked if Zelda approached 60% like I've been seeing some
people toss around.<br><br>My prediction: Zelda def. Aeris Gainsborough (54-46)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/31/2006 8:41:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344537170">message detail</a>
 | #147</td></tr>
<tr class="even"><td>
<b>Lopen&#8217;s Analysis</b><br> <br>When the bracket was first released, I thought this match deserved <i>way</i>
more debate than it received. Well, I can't deny Zelda's looking more
the favorite coming into this match. But her little fodder smashing
tricks aren't what are convincing me in this one. In fact, the main
reason I think Zelda's looking to be the favorite is more because of <i>Aeris</i>. Aeris just hasn't been doing too well. I expected more on Marle, and although I made a <b>BOLD PREDICTION</b>
that Aeris would do worse than Ryu against KOS-MOS (unfortunately not
here!), you can't say that's a good thing for Aeris's chances!<br><br>But
killing fodder is just killing fodder. Zelda getting 83% on Carmen
Sandiego and 79% on Terra isn't impressing me much. Fishy stuff just
happens sometimes, look at that crazy stuff Samus pulled in 2004. 80%
on Lara Croft and Sam Fisher? "She's beatin' Cloud!", they said! Tifa
did it last year against Vyse too, it didn't matter It's in the
victories against opponents that are worth their salt that you find
true knowledge!<br><br>Even if Zelda gets 60% on Aeris, I'm not sounding the Zelda/Samus upset alarms, though I'm sure most everybody else will be. <i>If</i> it happens, I'm blaming Aeris. <i>But&#8230;</i> I don't think it <i>will</i> happen. This match is still debatable if you ask me. Even with the 61% on KOS-MOS,<br><br><b>Lopen's Prediction:</b> Zelda with 52.01%.<br><br><br> <br><b>KH&#8217;s Analysis</b><br><br>lol x-stats history<br><br>Zelda<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 19th Place [30.29%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 14th Place [30.89%]<br><br>Zelda
beats Terra worse than Mario's expected to, after the Devil Division
all but validated itself and Terra/Kerrigan went exactly to
expectations. <i>Ouch.</i><br><br>Aeris Gainsborough<br><br>Summer 2002 Contest<br>Extrapolated Strength --- 12th Place [30.62%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 15th Place [32.81%]<br><br>Instead
of overperforming like I half-anticipated, Aeris underperforms
immensely against KOS-MOS, and that's not something you can afford to
do when your opponent looks like Mario. Double OUCH.<br><br><i>Notable Releases Since Last Appearance</i><br><br>Zelda: N/A<br>Aeris Gainsborough: Kingdom Hearts II (PS2)<br><br><i>Upcoming Releases</i><br><br>Zelda: The Legend of Zelda: Twilight Princess (WII)<br>Aeris Gainsborough: Final Fantasy XII (<i>aw yeah</i>)<br><br>Hey,
funny story guys. I just checked my bracket last night out of boredom,
and apparently I have Zelda winning this match (and Yuna winning her
match, and Zero winning his fourpack making my stressing out over Kirby
winning pseudo-ironic). Now, aside from the fact that I'm not
particularly sure when I changed my bracket in a drunken stupor or
whether I even still have Cloud &gt; Link, this actually makes me a ton
more relieved, and it's easy to see why. Zelda is just simply flat-out
stronger than Aeris here today, and I'm 99% sure of it. Hey, them's the
breaks, but between being freaking <i>Zelda</i> and just being that much more impressive, to call her anything but the favorite would be an insult.<br><br>Karma
Hunter's Vote: Aeris. Because even though somehow this hurts my
bracket, I can't bring myself to vote for Zelda. Well, maybe against
Ganondorf...no, not even then.<br><br>Upset Prediction: Zelda with 53.47%<br><br>Yup.<br><br><b>Upset Potential: 40%<br><br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br><br><i>However,</i>
apparently my conscious hasn't caught up to my subconscious, because
I'm still putting my chips in with Aeris (well, my Crew/Oracle chips at
least). If Zelda and Aeris are near-equals I see Aeris taking this
match without too much of a problem, and we all know the reason why I
think this&#8212;Final Fantasy XII.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/31/2006 8:41:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344537314">message detail</a>
 | #148</td></tr>
<tr class="even"><td>There are some that say FFXII will have a
negligble or minimal effect. To be frank, these people are fooling
themselves. If Aeris doesn't win this match, she will be overrated in
the stats. Period. I don't care if she ends up with 49% or 45% or 40%,
she would have gotten less if FFXII hadn't come out on the day of her
match.<br><br>FFXII will definitely bring an influx of people here for the FAQs, and the people that it brings <i>will</i> favor Aeris. The fact that she is not in the game is irrelevant. These are people coming on to GameFAQs looking for FAQs for a <i>Final Fantasy game.</i>
Do you think there is perhaps a slight chance that these people will
prefer Aeris more than the people here for Zelda FAQs or Mortal Kombat
FAQs? I for one, don't see how you can deny it. If the voting were
confined just to the people that came here for FFXII FAQs, it would
definitely be more in Aeris' favor compared to the general GameFAQs
population. This is common sense, here, and for chrissakes we've seen
it once before.<br><br>Now, does that mean that the group will prefer
Aeris unanimously? Hell no, that's just as absurd as to say it would
have no effect at all, and if it did I'd be calling Aeris a mortal lock
despite everything that we've seen right here. There's no guarantee
that it will outright prefer Aeris -- that is to say, if Zelda wins
56-44, the FFXII influx favors Zelda 51-49. It favors Aeris more than
the overall population, but still prefers Zelda.<br><br>This much seems
to be obvious. But at the end of the day Aeris has to be close enough
for it to make a difference, and I really think that she is despite
everything we've seen this year. I'm getting a really big Snake/Bowser
vibe from this match, where after Snake looked unbeatably dominating
and Bowser looked terribly unimpressive they had one of the closest
matches in contest history. I don't think Zelda is at Mario level, and
honestly I don't think she's much stronger than her 2k5 self, if at
all. Ganondorf didn't give me reason to fear, at least. And while Aeris
underperformed, I have a hard time seeing her just getting blown out.
She's still Final Fantasy VII, and I'm not used to seeing weakness come
out of that game.<br><br>Yeah, Bowser had a picture advantage. But
y'know what, Aeris' pic advantage over Zelda today ain't too shabby
either. And hopefully FFXII can bring in enough outside support to push
her over the edge.<br><br>Or not, seeing as how that would apparently
kill my bracket. And it doesn't exactly fill me with confidence when I
realize this is probably the longest writeup I've done (Ulti's
Halo/Starcraft is the <i>exception</i>, not the rule). But you get what I mean!<br><br><b>Karma Hunter's Krazy Prediction: Aeris with 50.57%</b><br><br><br> <br><b>Guest&#8217;s Analysis</b> - <i>BlAcK TuRtLe</i><br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2535" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2535">http://www.gamefaqs.com/poll/index.html?poll=2535</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=2536" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=2536">http://www.gamefaqs.com/poll/index.html?poll=2536</a><br><br>Last
round, Zelda impresses greatly by beating the crap out of Terra worse
than Vincent was projected to while Aeris disappointed against KOS-MOS
by performing worse than Luigi did last year.<br><br>This is pretty
much the only match left on the female side which has had any real
debate behind it, since Zelda and Tifa were extremely close in last
year's stats. People are assuming that Aeris is roughly at the same
strength as Tifa, despite her 2 year absence in 2k4 and 2k5 and Tifa
getting a 1 seed to Aeris' 2-seed.<br><br>So far in this contest, all
signs have been pointing to a Zelda win. Zelda has been looking
extremely impressive with her record setting blowout of Carmen Sandiego
and absolute destruction of Terra. It's safe to say that this year,
Zelda is geared up and ready for action.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 10/31/2006 8:42:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344537576">message detail</a>
 | #149</td></tr>
<tr class="even"><td>Aeris on the other hand is coming off a "meh"
performance against Marle and her absolute ball-drop against KOS-MOS.
Aeris failed to match Luigi's performance on 2k5 KOS-MOS by 5%. The
same Luigi that went on to lose comfortably to Tifa. I think it's safe
to say that Aeris is considerably weaker than her well-endowed
cast-mate, so it seems as though Zelda has this match pretty much in
the bag. How much in the bag is the real question.<br><br>Last
year's x-stats have Tifa and Zelda pretty much equal. Since KOS-MOS
performed 5% better on Aeris than she did Luigi, it would be safe to
assume that Aeris is probably around Luigi's 2k5 level after you factor
in the fact that KOS-MOS had a new game about 3 weeks before her match
against Aeris.<br><br>Running Zelda against Luigi last year gives us:<br><br><i>Zelda (2005c) VS Luigi (2005c)<br><br>Zelda has a strength of 33.71.<br>Luigi has a strength of 31.32.<br><br>Zelda wins with 53.54% of the vote!<br>A win of 7,248 with 102,228 total votes cast.</i><br><br>Plug
in the fact that Zelda seems stronger this year, along with the fact
that Luigi did considerably better and Zelda winning with 55% is a good
place to start. Factor in any increase from TP coming out in 3 weeks
cancelling out any boost Aeris gets from FF12 traffic and you get my
prediction of:<br><br><b>TuRtLe's Prediction:</b> Zelda with 56.23%<br><b>TuRtLe's Bracket:</b> Zelda<br><b>TuRtLe's Vote:</b> Zelda <br><br> <br> <br>Crew Consensus: Zelda wins, but KH is hoping for the Aeris upset. Zelda pickers range from the low to mid-high 50's.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=254355" class="name">Lugia2</a> |
Posted 10/31/2006 9:04:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=344542455">message detail</a>
 | #150</td></tr>
<tr class="even"><td>
Well, looks like Aeris di-<br><br>*Gets killed by moderators*<br><br>But who didn't know that beforehand?  Oye.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=1">2</a></li>
<li>3</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=9">10</a></li>
</ul>
</div>


</div>
<img src="genmessage3_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage3_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31382187&amp;page=2" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage3_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>