<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage8_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage8_files/nogs.css"></head><body linkifytime="200" linkified="1" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage8_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage8_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31382187%26page%3D7"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div class="ad" style="text-align: center;">
<div style="text-align: center;"><img src="genmessage8_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div>
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage8_files/a.xhtml" marginwidth="0" marginheight="0" hspace="0" vspace="0" bordercolor="#000000" frameborder="0" height="90" scrolling="no" width="728">
&lt;SCRIPT language='JavaScript1.1'
SRC="http://ad.doubleclick.net/adj/N2790.Gamespot/B2087377.9;abr=!ie;sz=728x90;click0=http://adlog.com.com/adlog/e/r=10153&amp;s=699674&amp;t=2006.11.13.16.14.20&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;e=&amp;rqid=00c17-gne-ad54551BB82280DB8A&amp;event=58/;ord=2006.11.13.16.14.20?"&gt;
&lt;/SCRIPT&gt;
&lt;NOSCRIPT&gt;
&lt;A
href="http://adlog.com.com/adlog/e/r=10153&amp;s=699674&amp;t=2006.11.13.16.14.20&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;e=&amp;rqid=00c17-gne-ad54551BB82280DB8A&amp;event=58/http://ad.doubleclick.net/jump/N2790.Gamespot/B2087377.9;abr=!ie4;abr=!ie5;sz=728x90;ord=2006.11.13.16.14.20?"&gt;
&lt;IMG
SRC="http://ad.doubleclick.net/ad/N2790.Gamespot/B2087377.9;abr=!ie4;abr=!ie5;sz=728x90;ord=2006.11.13.16.14.20?"
BORDER=0 WIDTH=728 HEIGHT=90 ALT="Click Here"&gt;&lt;/A&gt;
&lt;/NOSCRIPT&gt;
</iframe><img src="genmessage8_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 4
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;page=7">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31382187" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=6">Previous Page</a> |
Page 8 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=8">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=304351" class="name">Mac Arrowny</a> |
Posted 11/9/2006 3:27:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346463129">message detail</a>
 | #351</td></tr>
<tr class="even"><td>
<i>Mega Man would yank their old school support out from under then like a rug. A foul rug! </i><br><br>Just like he did to Ryu?<br><br>And Dante not being the main character in DMC4 probably means that he's not going to be doing any NN-breaking anytime soon.<br>---<br>"Luckily, I brought my smart sword. It won't hurt anyone 'friendly'. In fact, it makes them talk!" - Princess Zelda
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 11/9/2006 3:28:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346463270">message detail</a>
 | #352</td></tr>
<tr class="even"><td>
Yeah, that's why MGS3 hurt Snake, right!<br>---<br>"A strong man doesn't need to read the future. He makes his own." - Solid Snake<br>"I'll show you what true speed really is!" - Sonic
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 11/9/2006 3:31:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346463956">message detail</a>
 | #353</td></tr>
<tr class="even"><td>
Ouch. Poor MM.<br><br>But please people, MM losing to Squall or Vincent? Yeah just like Magus beat Sonic.<br><br>---<br><i>Do you really need me to bring out the Ovaltine?</i>-Stripey12isback on why hes a war hero.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 11/9/2006 3:33:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346464341">message detail</a>
 | #354</td></tr>
<tr class="even"><td>
<i>But please people, MM losing to Squall or Vincent? Yeah just like Magus beat Sonic.</i><br><br>Yeah,
because we have every reason to believe that Vincent is a fraud like
Magus was. He's never proven to be near elite in every match he's been
in.<br>---<br>"A strong man doesn't need to read the future. He makes his own." - Solid Snake<br>"I'll show you what true speed really is!" - Sonic
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=152338" class="name">Lopen</a> |
Posted 11/9/2006 3:33:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346464464">message detail</a>
 | #355</td></tr>
<tr class="even"><td>
Thing is, Magus was based off of getting 34% on Link, not 48% on Sonic.  Magus would never pull anything like that.  <br><br>And
Mega Man can't old school SFF Ryu. It's obvious why. They're two
degrees of separation away! Ryu/Nintendo has bad results, Mega
Man/Nintendo has bad results... but Mega Man/Ryu? <i>Nahhh</i>.<br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/9/2006 3:34:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346464638">message detail</a>
 | #356</td></tr>
<tr class="even"><td>
Magus not being able to beat Sonic had more to do with him being
overrated than with Sonic. But a better indicator is Snake -- if it
hadn't been for MGS3, he would have very likely lost to Zelda or Bowser
in 2k5. <br><br>I don't see any MGS3 coming along to help out MM. And the NN is not unbreakable. I suspect he will rebound, but if he doesn't...<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 11/9/2006 3:35:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346464910">message detail</a>
 | #357</td></tr>
<tr class="even"><td>
Sonic didn't have anything to help him rebound from his 2003
performance, but he obviously has. Every NN has a bad year that they
rebound from.<br><br>---<br><i>Do you really need me to bring out the Ovaltine?</i>-Stripey12isback on why hes a war hero.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 11/9/2006 3:36:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346465143">message detail</a>
 | #358</td></tr>
<tr class="even"><td>
Except the difference is that Vincent can still come very close to
beating Mega Man even if he rebounds. He got nearly 48% on perhaps the
strongest Sonic we've ever had.<br>---<br>"A strong man doesn't need to read the future. He makes his own." - Solid Snake<br>"I'll show you what true speed really is!" - Sonic
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 11/9/2006 3:39:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346465637">message detail</a>
 | #359</td></tr>
<tr class="even"><td>
Well, judging by the way NN characters rebound, Mega Man next year will
be back to his normal strength, and the year after that he wins the
bracket. I doubt Vincent could win in either year.<br><br>---<br><i>Do you really need me to bring out the Ovaltine?</i>-Stripey12isback on why hes a war hero.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=152338" class="name">Lopen</a> |
Posted 11/9/2006 3:44:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346466957">message detail</a>
 | #360</td></tr>
<tr class="even"><td>
Haha... silly pattern matching.  <br><br>Not to say it's even really a pattern.  Mario rebounded <i>and</i> took the bracket the year after he was in a slump.  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=304351" class="name">Mac Arrowny</a> |
Posted 11/9/2006 3:52:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346468813">message detail</a>
 | #361</td></tr>
<tr class="even"><td>
<i>Yeah, that's why MGS3 hurt Snake, right!</i><br><br>Funny, you didn't even say <i>Solid</i> Snake there. Most people consider NS and SS to be pretty much identical, judging from the strengths of BB and SS in 2k5.<br><br>Dante actually <i>is</i> in DMC4, but he looks to have a slightly smaller role than Snake did in MGS2.<br><br><i>Sonic
didn't have anything to help him rebound from his 2003 performance, but
he obviously has. Every NN has a bad year that they rebound from.</i><br><br>Well, Sonic Heroes was his second-biggest game ever, so that might have made a small difference...<br><br><i>Not to say it's even really a pattern. Mario rebounded and took the bracket the year after he was in a slump. </i><br><br>I
still say that Crono overperformed in that match. Everyone was rooting
for Mario to lose that year, just like what we saw in the VC.<br>---<br>"Luckily, I brought my smart sword. It won't hurt anyone 'friendly'. In fact, it makes them talk!" - Princess Zelda
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 11/9/2006 3:56:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346469762">message detail</a>
 | #362</td></tr>
<tr class="even"><td>
If the 2004 bracket weren't riddled with SFF, we'd have a good idea based on Mario's performances if he had a bad year or not.<br>---<br>"A strong man doesn't need to read the future. He makes his own." - Solid Snake<br>"I'll show you what true speed really is!" - Sonic
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/9/2006 5:48:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346497196">message detail</a>
 | #363</td></tr>
<tr class="even"><td>
Zelda...............57.02% 77105<br>Yuna...............42.98% 58112<br>TOTAL VOTES...........135217<br><br>52.79% of the brackets predicted this match correctly.<br><br>More good vote totals, and another good performance by Yuna. She almost does as well as Aeris does against Zelda. <br><br>Today, Snake is owning Mega Man's face!<br><br>KH - 11<br>Moltar - 11<br>Lopen - 10<br>HM - 10<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Ulti - 7<br>Yoblazer - 5<br><br>Lopen gets the point with his Zelda pick.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Snake vs. Mega Man - Bracket: <b>MM</b> - Vote: <b>Snake</b> (104/112)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=623712" class="name">RPGGamer0</a> |
Posted 11/9/2006 5:56:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346499043">message detail</a>
 | #364</td></tr>
<tr class="even"><td>
Does anyone know what the points of the "other" point distribution way are?  Those were always interesting...<br><br>---<br><b>Do
not kill. Do not rape. Do not steal. These are principles which every
man of every faith can embrace. These are codes of behavior, and those
of you that ignore them will pay the dearest cost.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/9/2006 8:27:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346536989">message detail</a>
 | #365</td></tr>
<tr class="even"><td>
Yo is quite behind on those, isn't he...<br><br>Anyway,
Sonic/Crono is looking to be much more debated by the Crew than
Snake/MM. Coule we possibly be seeing a split? Who knows?!<br><br>&lt;/hype building post&gt;<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Snake vs. Mega Man - Bracket: <b>MM</b> - Vote: <b>Snake</b> (104/112)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3685859" class="name">PartOfYourWorld</a> |
Posted 11/9/2006 8:28:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346537386">message detail</a>
 | #366</td></tr>
<tr class="even"><td>
Sorry for the massive delay; I deserve to be lambasted by every Crew
member and person following this topic. Been extremely busy lately, but
I'll have a full update on the standings later tonight.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/9/2006 8:29:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346537732">message detail</a>
 | #367</td></tr>
<tr class="even"><td>
I would've done them if I...ya know...hadn't completely forgotten about them &gt;.&gt;<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Snake vs. Mega Man - Bracket: <b>MM</b> - Vote: <b>Snake</b> (104/112)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/9/2006 8:43:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346540999">message detail</a>
 | #368</td></tr>
<tr class="even"><td>
Ooh, I'm looking forward to seeing the Crew's split.  I already know where 1 vote is going, at least.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=254355" class="name">Lugia2</a> |
Posted 11/9/2006 8:49:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346542454">message detail</a>
 | #369</td></tr>
<tr class="even"><td>
Sonic/Crono?  Could Crono have fallen even farther after the near-death of the Chrono Trigger bandwagon last year?<br><br>Last
year was horrible. Frog got smashed in by Samus after going toe-to-toe
with Snake, Magus lost to Knuckles, and MASTER CHIEF of all people does
very well on him- not to mention Vincent's 45%. And that's when you
forget the plumber...Heck, we didn't even HAVE the Chrono series in the
BSE contest!<br><br>Still, Sonic does look strong...but didn't Vincent do better on Sonic than Crono?  I still think Crono is safe...<br><br>We'll see tomorrow.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3251974" class="name">trannyscience</a> |
Posted 11/9/2006 8:51:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346543095">message detail</a>
 | #370</td></tr>
<tr class="even"><td>
crew? lessee...<br><br>....4-3, Crono.<br>---<br>zizzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2273363" class="name">shadow8021</a> |
Posted 11/9/2006 8:52:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346543182">message detail</a>
 | #371</td></tr>
<tr class="even"><td>
"but didn't Vincent do better on Sonic than Crono?"<br><br>But didn't Vincent get a boost from FF:AC and DoC?<br>---<br>Character Battle Score: 108/112    Guru Place: 6th<br>Today's Pick: Mega Man
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2273363" class="name">shadow8021</a> |
Posted 11/9/2006 8:52:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346543289">message detail</a>
 | #372</td></tr>
<tr class="even"><td>
Not to mention SFF<br>---<br>Character Battle Score: 108/112    Guru Place: 6th<br>Today's Pick: Mega Man
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/9/2006 9:05:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346546549">message detail</a>
 | #373</td></tr>
<tr class="even"><td>
<b>Blast in Time Division:</b> <i>Round 4 - Match 60</i> &#8211; (1)Sonic vs. (1)Crono<br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Sonic</b> - <i>Thinks he&#8217;s cool, but can&#8217;t hold a candle to Shadow and Knuckles.</i><br>Round 1 &#8211; 80.75% vs. CATS (19.25%)<br>Round 2 &#8211; 52.09% vs. Vincent (47.91%)<br>Round 3 &#8211; 60.19% vs. Luigi (39.81%)<br><br>Sonic easily 60-40s Luigi<br><br><b>Crono</b> - <i>Silly Crono, Dragonball is for dirty weeaboo otaku! lol japan</i><br>Round 1 &#8211; 74.16% vs. Capt. Falcon (25.84%)<br>Round 2 &#8211; 57.44% vs. Bowser (42.56%)<br>Round 3 &#8211; 54.50% vs. Auron (45.40%)<br><br>Auron does very well against Crono<br><br>It&#8217;s time for Part 2 of <b>ROUND 4, MALE HALF ELITE EIGHT EXTRAVAGANZA EVENT SPECIAL 2006 LIVE</b><i>!!</i> sponsored by Mama EC&#8217;s Smooth Butter, no one churns it out like mama EC do.<br><br>Ok,
this match wasn&#8217;t too debated beforehand. I mean, a few people thought
Sonic could take out Crono because Sonic would boost up a few percent
from some games or Crono would (lol) drop, I don&#8217;t remember. Anyway,
this match has gotten much more attention lately. And unlike Snake/MM,
it isn&#8217;t looking one-sided going in.<br><br>In Round 1, both characters
performed to expectations. Sonic was expected to more or less quad
CATS, and Crono was more or less expected to triple Falcon. That&#8217;s all
fine and dandy. Round 2 comes along, and now it gets interesting. Sonic
does slightly worse than projected against Vincent. However, Vincent
has had his own game since then, along with everything else FF that
came along and may have boosted him. Can&#8217;t really blame Sonic there,
right? Crono, on the other hand, does better than projected against
Bowser. Sure, he was overrated from Snake, but hey. At the end of the
round, Sonic is looking more or less the same, while Crono remains a
mystery still. I mean, if you adjust Bowser down a little, he falls
into the Zelda range, which isn&#8217;t too unrealistic&#8230;right?<br><br>Round 3
is when the match goes up into the air. Sonic does better than
projected on a supposedly stronger Luigi&#8230;yeah, that&#8217;s a curveball. I
mean, Luigi beats Zero and Kirby, yet Sonic still does better than he&#8217;s
projected to by a percent. What does Crono do right after?
Underperforms heavily against Auron. Ahh, just what we needed to call
the match close.<br><br>Now, Auron was underrated last year, but not by
this much. He&#8217;s obviously boosted, or Crono and Bowser both look like
crap. I&#8217;m not buying the latter, and I guess it isn&#8217;t that farfetched
that Auron is stronger than we thought. I mean, he did arguably have
the biggest FF cameo in KH2&#8230;I&#8217;m just unsure that brings him up to
nearly Bowser 2005 value.<br><br>So where do we go from here? Sonic has
looked good so far, while Crono&#8217;s last match makes him look iffy. Well,
unlike Snake/MM, I&#8217;m not jumping ship here. I said pre-Contest that
while I would take Sonic over MM, I&#8217;d still take Crono over Sonic. I
don&#8217;t see Sonic making up that gap by just random variation alone. I
don&#8217;t think Crono has fallen, maybe fluctuated a little, but I think
he&#8217;s still slightly above a little stronger Sonic. Crono has looked
fine up until his last match, and you can&#8217;t even hold that against him.
Sonic, on the other hand, was put into contention in this match because
of the last round. Was it just a fluke, or a sign of things to come?
This one should be good. Crono&#8217;s got the night, but his day vote has
gotten pitiful. He&#8217;ll need a good lead going into the day, because
Sonic will be in full swing once the kids come home.<br><br><b>Moltar&#8217;s Bracket Says:</b> Sonic will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Sonic: 49% - Crono: 51%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br> <br>Honestly, I don't see how this will be any different from Crono v Mega Man last year.<br><br>Prediction: Crono with 51.72%
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/9/2006 9:06:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346546687">message detail</a>
 | #374</td></tr>
<tr class="even"><td>
<b>HM&#8217;s Analysis</b><br><br><b>Sonic the Hedgehog</b><br><br><i>Previous Matches:</i><br><br>Sonic the Hedgehog &#8211; 80.75% -- 87,757<br><br>CATS &#8211; 19.25% -- 20,925 <br><br>Sonic the Hedgehog &#8211; 52.09% -- 64,699<br><br>Vincent Valentine &#8211; 47.91% -- 59,497 <br><br>Sonic the Hedgehog &#8211; 60.19% -- 79,761<br><br>Luigi &#8211; 39.81% -- 52,760 <br><br><b>Crono</b><br><br><i>Previous Matches:</i><br><br>Crono &#8211; 74.16% -- 84,090<br><br>Captain Falcon &#8211; 25.84% -- 20,306 <br><br>Crono &#8211; 57.44% -- 68,821<br><br>Bowser &#8211; 42.56% -- 50,986 <br><br>Crono &#8211; 54.5% -- 68,115<br><br>Auron &#8211; 45.5% -- 56,865 <br><br>Man, the final week of this contest is shaping up to be <i>very</i>
awesome. After Snake&#8217;s domination over Mega Man &#8211; and that&#8217;s what it
was given that Mega Man won so very few updates &#8211; the only Noble Nine
character who has not beat another fellow Noble Nine character is
Sonic. But that changes today, folks! <br><br>This match is really
tough to analyze simply because both of these guys have looked really
good coming into this match. I wouldn&#8217;t be surprised with the winner
regardless of who it was. I think Sonic comes into this match with a
slight edge, though, primarily due to the beating he gave Luigi.
Managing to pull in over 60% on what looked like a stronger Luigi was
impressive stuff. However, Crono managed to put Bowser in his place one
round before. <br><br>Whoever wins should do so with only about 51% of
the vote, I think, but I&#8217;m going to go with Sonic here. It&#8217;s just more
of a gut pick than anything else. There&#8217;s not really much justification
here since I&#8217;m so torn on this one. But a Sonic victory makes Ganon
look better so we&#8217;ll have to go with that <i>!!</i> GO BLUE BLUR! <br><br><b>Aitch Emm&#8217;s Bracket:</b> Ganondorf<br><br><b>Aitch Emm&#8217;s Prediction:</b> Sonic the Hedgehog &#8211; 50.9% ; Crono &#8211; 49.1%<br><br><b>Aitch Emm&#8217;s Vote:</b> Sonic the Hedgehog (Prefer Crono, but have to get Ganon higher!!)  <br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br><br>Samus
nearly shocked the contest world against Tifa, Yuna put up as good a
fight as Aeris did against Zelda, and Snake is avenging two defeats to
Mega Man in dominant fashion. You know, these Elite 8 matches have been
pretty damn good so far. At worst, they've been very unpredictable; at
best, awesome, and I think this finale could potentially even raise the
standard.<br><br>While there are people clamoring for Sonic based on
his first three performances, I think he's done merely alright. Not
bad, but not amazing. His 60% on Luigi was very impressive, I'll give
him that, but it was also a match that surely had some SFF
implications, and such matches usually prove to be a shakey indicator
of strength. His other two matches haven't really impressed me. Eighty
percent against CATS is definitely better than what Master Ass managed
to pull last year, but it's still a feat that Ryu accomplished years
ago. Nothing special. Also, his Vincent win was the least impressive
(percentage wise) of his entire contest career. While Sonic advocates
are defending the performance by claiming a very significant Vincent
boost, I'm one to think that a Noble 9 victory over an outsider with
less than 53% is never what you would call "impressive."<br><br>Likewise,
Crono hasn't had a bad contest by any means, but he has yet to wow me.
Sure, the win against Bowser pissed me off in that King Koopa
completely dropped the ball, but most people knew he was at least
somewhat overrated, and Crono exposed that. His win against Auron,
seemed a little on the blah side for my tastes. Even so, I'd still take
54.5% on an Auron that destroyed Alucard over 52% on Vincent. Call me
crazy, sure. It can definitely go either way, but I'll stick with Crono
on this one.<br><br>My prediction: Crono def. Sonic (51-49)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/9/2006 9:07:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346546861">message detail</a>
 | #375</td></tr>
<tr class="even"><td>
<b>Lopen&#8217;s Analysis</b><br> <br>Sonic vs. Crono was always a toss-up
match in my book. People had Crono as the "commanding favorite", but
let's face it, what'd Crono get on Mega Man last year after Mega Man
scraped by Sonic? 51.5% or something? That's nothing that can't be
overturned by just random chance, I'd say.<br><br>And this year,
judging from what we've seen, Sonic's looking primed and ready to do
the aforementioned overturning. Round 1 doesn't really matter, so lets
compare round 3s: In round 2 Sonic took Vincent out with some trouble&#8230;
heck, he got less than Crono did last year. But that was a more
dangerous Vincent, one could say. Advent Children and that Devil May
Cry wannabe game, whatever. Crono did about what might've been expected
against Bowser.<br><br>But fast forward to round 3, Sonic <i>smacked</i>
Luigi, who seemed to be taking Mario's supply of performance enhancing
mushrooms this year. Meanwhile Crono didn't do so hot against Auron.
But that Auron's probably been taking some of that performance
enhancing <b>DARKNESS</b>, so it doesn't matter as much as people think to me. (Sub-Zero beat Master Chief, he ain't not no sucka!)<br><br>So
now as a result of round 3 there's a Crono doom-saying committee,
standing right next to the Mega Man doom-saying committee. Sonic vs.
Snake is what these committees want to see. Well, I don't think Crono's
lost a step <i>either</i>. But you know what, maybe I'm not the one
who should answer this. Let's ask Marle! (I had Captain Falcon do it&#8230; I
couldn't bear to sit through an interview with her)<br><b>Captain Falcon:</b> Has Crono lost a step this year?<br>*Marle begins spinning slowly in place*<br><b>Marle:</b> I'm a chaos emerald I'm a chaos emerald!<br><b>Captain Falcon:</b> Are you mocking me? I didn't even say "show me your moves!" for once!<br><b>Marle:</b> Teeheeheehee! *continues to spin*<br><b>Sonic:</b> Those moves are <i>no good</i>! *wags finger*<br><br>At this point, Captain Falcon snapped: <a class="linkification-ext" href="http://i24.photobucket.com/albums/c38/NeoX-Death/CFvMarle.jpg" title="Linkification: http://i24.photobucket.com/albums/c38/NeoX-Death/CFvMarle.jpg">http://i24.photobucket.com/albums/c38/NeoX-Death/CFvMarle.jpg</a><br><br>Oh man&#8230; did you <i>see</i> how <i>distorted</i> Marle got from that hit? <i>Holy crap!</i> Captain Falcon is truly a <i>god of combat!</i><br><br>In
any case, lost a step or not (my new favorite phrase it seems!), Crono
doesn't even need to have lost one to lose this. Although Sonic's been
looking better coming in, this match is still just a gamble on yearly
fluctuation being in Sonic's or Crono's favor in my eyes. This match
should be close either way.<br><br><b>Lopen's prediction:</b> Sonic with 50.46%<br><br><br> <br><b>KH&#8217;s Analysis</b><br> <br>lol x-stats history<br><br><b>SONIC THE HEDGEHOG</b><br><br><i>"Good gravy, Snake is killing Mega Man."</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 5th place [41.05%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 10th place [34.92%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 8th place [33.56%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 8th Place [35.28%]<br><br>Snake is beating Mega Man!<br><br><b>CRONO</b><br><br><i>"F'ing A, I know. 56%??? I'm so screwed."</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 7th Place [37.43%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 6th Place [38.14%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 5th Place [37.18%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 6th Place [36.54%]<br><br>The greatest day in GameFAQs history is here!<br><br><i>Notable Releases Since Last Appearance</i><br><br>Sonic the Hedgehog: Sonic Rush (DS)<br>Crono: N/A<br><br><i>Upcoming Releases</i><br><br>Sonic the Hedgehog: Sonic the Hedgehog (PS3, X360), Sonic and the Secret Rings (WII)<br>Crono: N/A<br><br>And
this is the second of the most anticipated Noble Nine clashes that we
have on our schedule for this fine contest. Though it could never
measure up to the awesomeness of today, it's still a goody.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/9/2006 9:07:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346546994">message detail</a>
 | #376</td></tr>
<tr class="even"><td>
In terms of preference, I really, <i>really</i>
want Sonic to win. But, unfortunately, Crono's just looked more
impressive to me. I consider Squall, Auron, and Vincent all more or
less on the same tier of strength, and Crono beat Auron worse than
Sonic beat Vincent. I'd take Vincent in a direct match, but not by
*that* much. Add in that Sonic is officially now the NN's biggest
choker until proven otherwise (well, ignoring today's match &lt;_&lt;),
that Crono never seems to ****ing lose any strength (grr), and that he
already had the advantage to begin with...Sonic can certainly do this,
but I don't like his chances. He killed Luigi, but I've never really
respected the man's strength -- and Zero dropped comparative to MM
makes that make a lot more sense.<br><br>And...that's all I've really got to say about this. I'm all burned out from today's match. Congrats, Snake.<br><br>Karma Hunter's Vote: Sonic the Hedgehog!<br><br><b>Karma Hunter's Krazy Prediction: Crono with 51.15%.</b><br><br>This
is very possibly Crono's toughest fight in the whole bracket despite my
unconcerned nature toward the match. This is by no means a bye for him.<br><br><b>Upset Potential: 45%<br><br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br><br>Sonic
has been on the rise lately, while Crono stayed constant at best in
2005. He has had hype for upcoming games, he's got a fair amount of
buzz surrounding him just concerning the possibility of him being in
SSBB, he should benefit from a more casual voterbase that higher votals
imply (though 2003 and the fact that said votals may be influenced by
FFXII sort of dispute that). He's looked decently impressive all
around, and I'd be tempted to call him the favorite if Crono had really
faltered at all. This is a tossup, and while he doesn't have the
backing of my pick he certainly has my hopes, and my vote.<br><br>Kick his ass, Blue Blur.<br><br>Upset Prediction: Sonic the Hedgehog with 51.68%<br><br> <br><br><b>Guest&#8217;s Analysis</b> - <i>DpObliVion</i><br><br>Well,
it&#8217;s time for my glorious return to the Crew. And the time is right, as
this match includes the great Sonic the Hedgehog. I couldn&#8217;t pass up
this opportunity. Unfortunately though, his opponent is the mighty
Crono.<br><br>Yesterday, I was honestly all ready to concede defeat to
Crono. After all, in 2005, we saw Mega Man beat Sonic, followed by
Crono beating Mega Man. Crono has definitely showed far more success in
the contests than Sonic, so Sonic is certainly the underdog. But today
makes you forget about all the history. Snake is beating Mega Man, and
easily too, with 55.7% of the vote at the time I write this. Last year,
Mega Man only beat Sonic by 742 votes, and it has been pretty widely
assumed that Snake and Sonic are on pretty much the same level at the
bottom of the Noble Nine. Both Snake and Sonic are getting hype for
upcoming next-gen games, while Mega Man has been sitting still. I would
have no doubt in Sonic winning a rematch this year.<br><br>But this is
not Sonic vs. Mega Man; this is Sonic vs. Crono. After Mega Man beat
Sonic, Crono then beat Mega Man with 51.35%. Again, not extremely
convincing, and like Mega Man, Crono has had nothing to boost him since
last year like Sonic has had. Everyone is waiting to see Chrono Trigger
show up on the Wii&#8217;s Virtual Console list, but so far, no luck (I do
see Sonic the Hedgehog there though, just to throw that out there).<br><br>Prior
to the start of the contest, it was pretty much guaranteed that Crono
would take the male bracket, or at least guaranteed to beat Sonic to
lead to a rematch against Mega Man where he would be the favorite. Now
that Snake has beaten Mega Man though, nothing is guaranteed anymore.
Hell, we may even see the Noble Nine taken down the day after, with
Samus struggling and Zelda dominating. Sonic certainly cannot be
counted out in this match anymore.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/9/2006 9:08:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346547234">message detail</a>
 | #377</td></tr>
<tr class="even"><td>If you know me, you know that I&#8217;m about as big of
a Sonic fanboy as there is. But unlike in the past (Sonic 2 Shouldve
Won?), I have not been letting by fanboyism blind me into expecting
Sonic to win matches that he shouldn&#8217;t. Such matches would include this
one. You cannot take away the fact that Crono&#8217;s game, Chrono Trigger,
was runner-up to Final Fantasy VII in the Best Game Ever contest. Even
after being surprised by Mega Man flopping, I would be even more
surprised to see Crono flop as well. Surprise, surprise, but I really
am expecting Sonic to lose this match, even though I should be leading
the growing charge of people saying that Sonic will pull off the upset.
This is one case though where I would be absolutely ecstatic to be
proven wrong about.<br><br>GO SONIC!<br><br><b>DpOblivion&#8217;s Bracket says:</b> Crono<br><br><b>DpOblivion&#8217;s Prediction is:</b> Crono with 51.13%<br><br> <br> <br>Crew
Consensus: In another debated match, the Crew seems to heavily favor
Crono. In a 5-2 decision, we have him winning the match.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3251974" class="name">trannyscience</a> |
Posted 11/9/2006 9:08:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346547243">message detail</a>
 | #378</td></tr>
<tr class="even"><td>
Moltar more like wtftar with that prediction<br>---<br>zizzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/9/2006 9:09:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346547284">message detail</a>
 | #379</td></tr>
<tr class="even"><td>
Rofl Lopen.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/9/2006 9:09:07 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346547288">message detail</a>
 | #380</td></tr>
<tr class="even"><td>
Rofl Lopen.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 11/9/2006 9:10:15 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346547570">message detail</a>
 | #381</td></tr>
<tr class="even"><td>
My momma's butter is hot and sticky.<br><br>P.S. <b>GIVE ME SAMUS/ZELDA YOU FREAK GRAAAAAAH</b><br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/9/2006 9:11:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346547810">message detail</a>
 | #382</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Oh wait, why am I doing
this, I'm today's Guest Analys....er......yeah....I couldn't break the
habit, I guess. LETS GO SONIC *clap clap clapclapclap* LETS GO SONIC
*clap clap clapclapclap* LETS GO SONIC *clap clap clapclapclap*<br><br>He's got a chance......but even I'm not expecting victory.  Crono's just too strong.<br><br>My vote: SONIC<br>My bracket: Crono<br>My prediction: Crono with 51.13%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/9/2006 9:11:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346547905">message detail</a>
 | #383</td></tr>
<tr class="even"><td>
Oh crap, that's 2 days in a row I messed up my bracket pick.<br><br>Oh well, at least <i>one</i> of my brackets does have both Snake and Sonic advancing!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Snake vs. Mega Man - Bracket: <b>MM</b> - Vote: <b>Snake</b> (104/112)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/9/2006 9:12:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346548166">message detail</a>
 | #384</td></tr>
<tr class="even"><td>
Wow......so Crono has to fall between 51.07% and 51.14% for me to get the point. Ouch.<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/9/2006 9:12:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346548293">message detail</a>
 | #385</td></tr>
<tr class="even"><td>
Wait, HM was the odd one out?<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/9/2006 9:13:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346548374">message detail</a>
 | #386</td></tr>
<tr class="even"><td>
What, Lopen doesn't even count anymore?<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/9/2006 9:16:56 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346549258">message detail</a>
 | #387</td></tr>
<tr class="even"><td>
HM <i>and</i> Lopen? But that means... Dp picked Crono..?<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/9/2006 9:17:50 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346549470">message detail</a>
 | #388</td></tr>
<tr class="even"><td>
&lt;_&lt;<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=152338" class="name">Lopen</a> |
Posted 11/9/2006 10:09:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346561557">message detail</a>
 | #389</td></tr>
<tr class="even"><td>
Ashe was clearly rofling at my hilarious picture.  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3662060" class="name">YoAriel33</a> |
Posted 11/10/2006 12:04:48 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346583145">message detail</a>
 | #390</td></tr>
<tr class="even"><td>
Solid Snake vs. Yoshi<br>+7 KH<br>+6 Yo<br>+5 HM<br>+4 Mo<br>+3 Guest<br>+2 Ulti<br>+1 Lo<br><br>Sora vs. Mega Man<br>+7 HM<br>+6 KH<br>+5 Mo<br>+4 Guest<br>+3 Ulti<br>+2 Lo<br>+1 Yo<br><br>Sonic the Hedgehog vs. Luigi<br>+7 Mo<br>+6 Ulti<br>+5 Lo<br>+4 Guest<br>+3 KH<br>+2 HM (Tie)<br>+2 Yo (tie) <br><br>Crono vs. Auron<br>+7 HM<br>+6 KH<br>+5 Mo<br>+4 Lo<br>+3 Guest<br>+2 Yo<br>+1 Ulti<br><br>Samus Aran vs. Tifa Lockheart<br>+7 KH<br>+6 Yo<br>+5 Lo<br>+4 Mo<br>+3 Ulti<br>+2 Guest<br>+1 HM<br><br>Zelda vs. Yuna<br>+7 Lo<br>+6 Mo<br>+5 Yo<br>+4 Guest<br>+3 KH<br>+2 HM<br>+1 Ulti<br><br>Solid Snake vs. Mega Man<br>+7 KH<br>+6 HM<br>+5 Guest<br>+4 Yo<br>+3 Ulti<br>+2 Mo<br>-1 Lo<br><br><br><b>The Rankings</b> (Through Solid Snake vs. Mega Man)<br>1. Master Moltar (255)<br>2. Karma Hunter (243)<br>3. Heroic Mario (240)<br>4. Yoblazer (227)<br>5. UltimaterializerX (200)<br>6. Board 8 (191)<br>7. Lopen (146)<br><br>Sorry about that.<br>---<br><i>I don't know when, I don't know how, but I know something starting right now... <br>Watch and you'll see, someday I'll be... <b>part of your world!</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=795464" class="name">Tatl</a> |
Posted 11/10/2006 10:00:30 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346629286">message detail</a>
 | #391</td></tr>
<tr class="even"><td>
Tag<br>---<br>Izzyzy "The Closet King" is my current GameFAQs idol.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=468956" class="name">goku z</a> |
Posted 11/10/2006 11:17:04 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346639864">message detail</a>
 | #392</td></tr>
<tr class="even"><td>
Taking semifinal write-ups, yet?<br>---<br><i>Dirty old men &gt; Squall ||</i> <b>Check out Contact, the GotY 2006!</b><br>Every time red13n mods a fad, a nerd gets his zits.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=1640900" class="name">MasterMoltar</a> |
Posted 11/10/2006 12:07:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346647763">message detail</a>
 | #393</td></tr>
<tr class="even"><td>
Well, EC already called Samus/Zelda, and we'll see tommorow about the male half finals.<br>---<br>Back from the shadows...
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 11/10/2006 12:09:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346648117">message detail</a>
 | #394</td></tr>
<tr class="even"><td>
I expected you to make a topic for Samus/Zelda. =/<br><br>*attempts to call the finals* &gt;_&gt;<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 11/10/2006 2:39:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346675171">message detail</a>
 | #395</td></tr>
<tr class="even"><td>
I'm waiting on my write-up to see the pic/pics... If ZSS appears, I will make ceej pay!<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/10/2006 2:40:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346675400">message detail</a>
 | #396</td></tr>
<tr class="even"><td>
Actually, I only want the guest writeup for the finals if Snake is in them. Pwetty pwease, Moltar? :x<br><br>&gt;_&gt;<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=254355" class="name">Lugia2</a> |
Posted 11/10/2006 3:40:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346688626">message detail</a>
 | #397</td></tr>
<tr class="even"><td>
*Rips up X-stats*<br><br>Well, this is insane.<br><br>I
still believe Samus will get on top. She defeated Sonic 57-43 in 2004,
and that is a VERY large margin to fall. I STILL think the suit is the
problem- I mean, we all saw what happened to Snake whenever he got his
sprite. And since Crono seems to have dropped badly...<br><br>So, unless Zelda destroys the Noble Nine, I think Samus still has this.<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/10/2006 3:42:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346688976">message detail</a>
 | #398</td></tr>
<tr class="even"><td>
<i>From Lugia2</i><br><i>*Rips up X-stats*<br><br>Well, this is insane.<br><br>I
still believe Samus will get on top. She defeated Sonic 57-43 in 2004,
and that is a VERY large margin to fall. I STILL think the suit is the
problem- I mean, we all saw what happened to Snake whenever he got his
sprite. And since Crono seems to have dropped badly...<br><br>So, unless Zelda destroys the Noble Nine, I think Samus still has this.</i><br><br>If
I get around to writing my Zelda/Samus match, you might end up thinking
otherwise, regardless of whether or not Zelda wins. :x<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2997804" class="name">LeonhartForever</a> |
Posted 11/10/2006 3:43:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346689223">message detail</a>
 | #399</td></tr>
<tr class="even"><td>
<i>*Rips up X-stats*</i><br><br>What, the stats that had Crono projected to win with 51.72% against Sonic? Yeah, they totally failed us here.<br>---<br>"A strong man doesn't need to read the future. He makes his own." - Solid Snake<br>"I'll show you what true speed really is!" - Sonic
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/10/2006 5:05:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346707791">message detail</a>
 | #400</td></tr>
<tr class="even"><td>
Solid Snake............55.33% 70163<br>Mega Man..............44.67% 56648<br>TOTAL VOTES..................126811<br><br>48.34% of the brackets predicted this match correctly.<br><br>....DAYUM! That's all I got to say. Snake's boosted, MM's fallen. Just...wow.<br><br>Today, Sonic is pulling away from Crono at the moment.<br><br>KH - 12<br>Moltar - 11<br>Lopen - 10<br>HM - 10<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Ulti - 7<br>Yoblazer - 5<br><br>Another point for KH.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Sonic vs. Crono - Bracket: <b>Crono</b> - Vote: <b>Sonic</b> (104/120)
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=5">6</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=6">7</a></li>
<li>8</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=9">10</a></li>
</ul>
</div>


</div>
<img src="genmessage8_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage8_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31382187&amp;page=7" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage8_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>