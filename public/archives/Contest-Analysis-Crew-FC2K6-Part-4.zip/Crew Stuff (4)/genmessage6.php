<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage6_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage6_files/nogs.css"></head><body linkifytime="220" linkified="1" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage6_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage6_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31382187%26page%3D5"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div class="ad" style="text-align: center;">
<div style="text-align: center;"><img src="genmessage6_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div><iframe marginheight="0" marginwidth="0" allowtransparency="true" src="genmessage6_files/getntag.htm" frameborder="0" height="90" scrolling="no" width="728">
</iframe><img src="genmessage6_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 4
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;page=5">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31382187" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=4">Previous Page</a> |
Page 6 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=6">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/5/2006 9:34:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345627843">message detail</a>
 | #251</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Remember, remember, the
fifth of November.....Sonic with 60% on Luigi, sweet! Lookin good.
Unfortunately, Crono's performance today probably won't help to much in
predicting next round's match, as he could SFF Auron.<br><br>My vote: Crono I suppose<br>My bracket: Crono over Auron<br>My prediction: Crono with 62%<br><br>---<br><i>Remember, remember, the fifth of November, the gunpowder treason and plot,<br>I see of no reason why gunpowder treason should ever be forgot.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/5/2006 9:39:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345629132">message detail</a>
 | #252</td></tr>
<tr class="even"><td>
What the hell does that November 5th crap have to do with this match?<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3605206" class="name">wavedash101</a> |
Posted 11/5/2006 9:39:47 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345629265">message detail</a>
 | #253</td></tr>
<tr class="even"><td>
Old timer picture?<br><br>I thought he had the KH2 picture for the Subby match?<br>---<br><b>Our shields cannot withstand wavedashing of this magnitude!</b><br>Board 8's Unofficial Master of the Phoenix Down
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/5/2006 9:42:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345630117">message detail</a>
 | #254</td></tr>
<tr class="even"><td>
Nothing, it's just fun.<br><br>---<br><i>Remember, remember, the fifth of November, the gunpowder treason and plot,<br>I see of no reason why gunpowder treason should ever be forgot.</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=640243" class="name">Big Bob</a> |
Posted 11/5/2006 9:45:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345630915">message detail</a>
 | #255</td></tr>
<tr class="even"><td>
<b><i>Big Bob's completely biased and nonsensical analysis</i></b><br><br>Crono
may have shown Bowser up, but Bowser was overrated. By a LOT. He's
weaker than Luigi, who Auron's consistently been stronger than. Auron's
also had Kingdom Hearts II since then. Sub-Zero's the mascot of Mortal
Kombat AND has had new games accounting for his strength, and Auron
beat the hell out of Alucard when everyone expected it to be closer.
Keep in mind the recent release of Final Fantasy XII to remind people
why they like those games so much, and you've got a victory for Auron.<br><br>Bob's Prediction: <b>Auron with 60%</b><br>---<br>Gordon
Freeman finally won, but somehow, the universe survived... thus
allowing me to tell said universe about how I was owned by <b>NClark128</b>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=395700" class="name">HaRRicH</a> |
Posted 11/5/2006 9:56:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345633867">message detail</a>
 | #256</td></tr>
<tr class="even"><td>
Ashe, I dunno what other Zelda match you predicted or how well you did
it, but the whole Zelda &gt; Samus thing is enough for me to say it's
going to keep Board 8 from getting a POSITIVE number of points.<br>---<br>Diddy did it.  Diddy did it.<br>DAMMIT!  What didn't Diddy do?!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/5/2006 9:59:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345634670">message detail</a>
 | #257</td></tr>
<tr class="even"><td>
Um, I got the point for the Guests.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=395700" class="name">HaRRicH</a> |
Posted 11/5/2006 10:18:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345639528">message detail</a>
 | #258</td></tr>
<tr class="even"><td>
Right, fine, and EC's got two (and 2nd his third time), and he's got Samus &gt; Zelda.  History goes in his favor there as well.<br>---<br>Diddy did it.  Diddy did it.<br>DAMMIT!  What didn't Diddy do?!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/5/2006 10:21:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345640346">message detail</a>
 | #259</td></tr>
<tr class="even"><td>
Ah, but I'm clearly better when it comes to predicting Zelda matches!
Besides, he has had more guest spots than me, so I get priority
anyways. ;o<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=395700" class="name">HaRRicH</a> |
Posted 11/5/2006 10:24:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345641116">message detail</a>
 | #260</td></tr>
<tr class="even"><td>
I'll give you the priority point...but when I was on the Crew last
year, I got the point for both matches Fire Emblem was in. Rest assured
when I say I am no Fire Emblem expert, heh.<br>---<br>Diddy did it.  Diddy did it.<br>DAMMIT!  What didn't Diddy do?!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=395700" class="name">HaRRicH</a> |
Posted 11/5/2006 10:27:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345641714">message detail</a>
 | #261</td></tr>
<tr class="even"><td>
Er...last contest, not last year.<br>---<br>Diddy did it.  Diddy did it.<br>DAMMIT!  What didn't Diddy do?!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/5/2006 10:34:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345643312">message detail</a>
 | #262</td></tr>
<tr class="even"><td>
Did you see my Zelda/Aerith writeup? I undershot Zelda by a lot. Don't assume I'm going to do anything <i>too</i> insane, if I get it.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 11/5/2006 11:15:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345652391">message detail</a>
 | #263</td></tr>
<tr class="even"><td>
I'll take Yuna/Zelda if no one who hasn't done a writeup wants it.<br>---<br>CB06 - Score: <b>86/92 </b>Rank: <b>Tied - 224th </b>Yesterday's Pick:<b> Sonic the Hedgehog</b> <br>Today's Pick: <b>Crono</b> Tomorrow's Pick: <b>Samus</b> Losses: <b>Cortana, Ganon, Zero, MC, Kirby</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 11/6/2006 2:45:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345747208">message detail</a>
 | #264</td></tr>
<tr class="even"><td>
I'm liking my chances on this point!<br><br>---<br>"Let's face it: the princess Zelda has always been a symbol of sexual desire."
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 11/6/2006 3:30:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345757438">message detail</a>
 | #265</td></tr>
<tr class="even"><td>
I'm liking your face!<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 11/6/2006 3:31:37 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345757692">message detail</a>
 | #266</td></tr>
<tr class="even"><td>
Who doesn't? This is one beautiful face I have!<br><br>---<br>"Let's face it: the princess Zelda has always been a symbol of sexual desire."
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=468956" class="name">goku z</a> |
Posted 11/6/2006 3:33:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345758119">message detail</a>
 | #267</td></tr>
<tr class="even"><td>
When are sign-ups for next round taking place? I'd like to do Snake/Mega Man, and haven't done a write-up yet.<br>---<br><i>Dirty old men &gt; Squall ||</i> <b>Check out Contact, the GotY 2006!</b><br>Every time red13n mods a fad, a nerd gets his zits.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 11/6/2006 3:37:11 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345759097">message detail</a>
 | #268</td></tr>
<tr class="even"><td>
It's no wonder your mother is so damn fine.<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=1243369" class="name">chocoboslayer</a> |
Posted 11/6/2006 3:59:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345764939">message detail</a>
 | #269</td></tr>
<tr class="even"><td>
Hey...any way I can do a guest write-up for next round? <br><br>If so, any way I can get Zelda/Yuna?<br>---<br>*dances Yuna-style through this topic*<br>Contest Score: 84/94! Next Pick: Samus Aran vs. <b>Tifa Lockhart</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/6/2006 5:00:45 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345781103">message detail</a>
 | #270</td></tr>
<tr class="even"><td>
Sonic the Hedgehog..................60.19% 79761<br>Luigi..........................................39.81% 52760<br>TOTAL VOTES ...................................132521<br><br>40.02% of the brackets predicted this match correctly.<br><br>Well,
this is interesting. Sonic did better than he was supposed to against
Luigi. That means either Sonic's boosted (meaning Vincent and Ganon
look even better) or Luigi isn't even at his 2005 level (meaning Kirby
and Zero got beat by a <i>weaker</i> Luigi). Hmm...nice vote totals too.<br><br>Today, Auron is doing very well against Crono.<br><br>Moltar - 11<br>KH - 10<br>HM - 9<br>Lopen - 9<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Ulti - 7<br>Yoblazer - 5<br><br>Point goes to me for my Sonic pick, woo.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Crono vs. Auron - Bracket: <b>Crono</b> - Vote: <b>Auron</b> (84/92)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/6/2006 5:03:17 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345781751">message detail</a>
 | #271</td></tr>
<tr class="even"><td>
I already have the Guest write-ups for Samus/Tifa and Zelda/Yuna, HaRR is doing Snake/MM and DP is doing Crono/Sonic.<br><br>We'll get to Round 5 later...<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Crono vs. Auron - Bracket: <b>Crono</b> - Vote: <b>Auron</b> (84/92)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3052691" class="name">satai_delenn</a> |
Posted 11/6/2006 5:08:26 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345783186">message detail</a>
 | #272</td></tr>
<tr class="even"><td>
Hehe. I always love the unashamed Marle hate in Lopen's analyses.<br>---<br>Beating
FE5 and FE6 hard mode is a true test of manhood in the Japanese
culture. However. This explains why they have a lot of effeminate men.
~Sytha
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 11/6/2006 5:09:27 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345783434">message detail</a>
 | #273</td></tr>
<tr class="even"><td>If the Male Bracket final is Snake vs. Sonic, I
want it. I know I've already done two, but I've been hoping and calling
for that match all contest!<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 6</i>: Han Solo - W, 28-26
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3251974" class="name">trannyscience</a> |
Posted 11/6/2006 6:29:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345805528">message detail</a>
 | #274</td></tr>
<tr class="even"><td>
dang, I wanted Sonic/Crono!<br><br>*calls final!*<br>---<br>zizzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/6/2006 6:32:21 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345806393">message detail</a>
 | #275</td></tr>
<tr class="even"><td>
<i>From trannyscience</i><br><i>dang, I wanted Sonic/Crono!<br><br>*calls final!*</i><br><br>I already offered Zelda/Snake to EC in exchange for Zelda/Samus. Sorry. D:<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 11/6/2006 7:16:22 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345819195">message detail</a>
 | #276</td></tr>
<tr class="even"><td>
I'll take any available match if I can<br><br><b>TuRtLe</b><br>~~~<br>81/88 in the contest. My analysis topic here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=981127" class="name">Cavalier Lowen</a> |
Posted 11/6/2006 7:20:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345820480">message detail</a>
 | #277</td></tr>
<tr class="even"><td>
I must have a MM/Sonic analysis if it happens.<br>---<br>Z1mZum owned me in the guru contest (by two points!).  Damn you Z1mZum!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 11/6/2006 9:55:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345865633">message detail</a>
 | #278</td></tr>
<tr class="even"><td>
Wow, these writeups are awesome today. I love how Lopen perfectly
supports his Tifa &gt; Samus pick. He has made a believer out of me!<br><br>&lt;/Impatience&gt;<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/6/2006 9:56:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345865776">message detail</a>
 | #279</td></tr>
<tr class="even"><td>
<b>Limit of the Spazer Division:</b> <i>Round 4 - Match 57</i> &#8211; (1)Samus vs. (1)Tifa <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Samus</b> - <i>The Best of the Best in the female half, and the whole bracket!</i><br>Round 1 &#8211; 81.85% vs. Nidoran F (18.15%)<br>Round 2 &#8211; 79.78% vs. Ada (20.22%)<br>Round 3 &#8211; 69.00% vs. Rikku (31.00%)<br><br>More Samus domination in Round 3<br><br><b>Tifa</b> - <i>The Breast of the Best in the female half, WOO Tifa Breast joke #53324!</i><br>Round 1 &#8211; 76.18% vs. Ivy (23.82%)<br>Round 2 &#8211; 74.55% vs. The Boss (25.45%)<br>Round 3 &#8211; 66.05% vs. Peach (33.95%)<br><br>Tifa nearly doubles the Princess.<br><br>Samus has taken down all that have stepped in her path so far, but now she faces her toughest opponent yet. Hey Samus, <i>Breasts have arrived!</i><br><br>Now,
Tifa has looked pretty good so far. Good numbers against Ivy and The
Boss, decent stuff against Peach. That&#8217;s all good and stuff&#8230;but you
need a bit more than that to face Samus. I mean, Tifa got 43% on Sonic
last year, and Samus has beaten Sonic twice in the past. Tifa doesn&#8217;t
even look to be much stronger than her last year self. Maybe it was
just her opponents though&#8230;<br><br>Samus on the other hand is looking to
be at or above her 2005 value, and that&#8217;s more than enough to win this
match easily. Samus beats Tifa 60-40 using last year&#8217;s stats, and I
honestly don&#8217;t see it being to far away from that result. Tifa fans
should feel good if she breaks 40%, because 45% is waaay too much to
ask for.<br><br>Oh, and it&#8217;s the debut of Zero Suit Samus! Time to see her kick some ass and take some names!<br><br><b>Moltar&#8217;s Bracket Says:</b> Samus will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Samus: 59% - Tifa: 41%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br> <br>We're
in the final eight and still have eeeeeeeasy matches on the female
side. All this is is a "guess the winner's percent!" type of match.<br><br>Prediction: Samus with 59.47%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br><b>Samus Aran</b><br><br><i>Previous Matches:</i><br><br>Samus Aran &#8211; 81.85% -- 95,533<br><br>Nidoran F &#8211; 18.15% -- 21,180 <br><br>Samus Aran &#8211; 79.78% -- 98,352<br><br>Ada Wong &#8211; 20.22% -- 24,923 <br><br>Samus Aran &#8211; 69% -- 85,439<br><br>Rikku &#8211; 31% -- 38,387 <br><br><b>Tifa Lockhart</b><br><br><i>Previous Matches:</i><br><br>Tifa Lockhart &#8211; 76.18% -- 96,118<br><br>Ivy Valentine &#8211; 23.82% -- 30,046 <br><br>Tifa Lockhart &#8211; 74.55% -- 90,595<br><br>The Boss &#8211; 25.45% -- 30,934 <br><br>Tifa Lockhart &#8211; 66.05% -- 79,830<br><br>Princess Peach &#8211; 33.95% -- 41,033 <br><br>Starting the female bracket <i>now</i>
isn&#8217;t so bad when you&#8217;re starting it off with something like
Samus/Tifa! Although the result of this match is a foregone conclusion,
it&#8217;ll be nice to actually see two strong Nintendo and Square characters
going at it. This one should help us get an idea of where Tifa stands
after KH2 and where characters like Peach and Jill end up placing.
Samus had a pretty &#8220;by the stats&#8221; match against Rikku last year, out
doing them by less than a percent, whereas Tifa put up a pretty
impressive doubling on Princess Peach despite starting out pretty
badly. <br><br>I think there is a slight possibility that Samus may
undershoot her expectations and projections in this match. I doubt the
picture, which is Zero Suit Samus from SSBB, will hurt her that much,
but it just seems like the female bracket would have some over and
underperformances similar the Villain Contest for whatever reason. It
probably won&#8217;t be anything major, but Tifa may put up surprising
numbers or she may just get rocked hard.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/6/2006 9:56:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345865940">message detail</a>
 | #280</td></tr>
<tr class="even"><td>It&#8217;s nice to see that we&#8217;re starting to get into
some of the more interesting matches. We pretty much only have the
strong characters left in the contest at this point, which is
particularly good for the female half! The most exciting match &#8211; ZELDA
&gt; SAMUS &#8211; has yet to come though! <br><br><b>Aitch Emm&#8217;s Bracket:</b> Samus Aran<br><br><b>Aitch Emm&#8217;s Prediction:</b> Samus Aran &#8211; 60% ; Tifa Lockhart &#8211; 40%<br><br><b>Aitch Emm&#8217;s Vote:</b> Samus Aran <br><br> <br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br><br>Before
getting to gourge ourselves on the two terrific men's matches, we'll
have to sit through two boring, predictable matches on the female side.
Despite these matches not being very good for the Elite 8, let's look
on the bright side: they're about ten times better than what we've had
to deal with so far from the female bracket.<br><br>Both Samus and Tifa
have more or less done exactly what was expected of them. It can be
argued that Tifa underperformed against Princess Peach, but it's
difficult to argue that point when Peach is completely new to the
contest scene. Either way, we all knew both of these characters would
be here, and we knew what the ending result would be.<br><br>Truth be
told, the most interesting aspect of this match is probably the fact
that it's the first time Samus has been pictured without her Power
Suit. Will she underperform? Overperform? Will it make no difference?
Unless the percentages are completely out of whack, it will be hard to
tell, but the Metroid heroine should have no trouble in winning.
Personally, I think Samus is going to look good here, but I'm not sure
why either of the FFVII ladies haven't looked more impressive,
especially when given the fact that every male character who starred in
KHII has looked extremely impressive thus far. It strikes me as very
strange, and almost gives me a forboding feeling that Tifa will have
the match of her life. Regardless, my Nintendo fanboyism has once again
gotten the better of me, so I'm going with Samus for the easy win. See
you in Brawl, sexy mama.<br><br>My prediction: Samus Aran def. Tifa Lockheart (58-42) <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>This
match kinda bores me. None too interesting. I'd like to say Tifa has an
upset chance here, but she really doesn't. We saw Sonic smash her into
the dirt last year, we know Samus is at <i>least</i> on the level of
Sonic. Kind of a no-brainer. Not even the results of this year give it
any support. Tifa got less on Peach than Samus got on Rikku&#8230; and come
on, who here takes Peach over Rikku. Anybody, anybody? I guess Tifa
smashing the Boss with 75% or so was pretty impressive, but we know
about that FF7/MGS stuff that goes on.<br><br>Anyway, Samus has shown to typically be stronger than Sonic, Sonic got ~57% on Tifa last year, I expect Samus to get a tad more.<br><br><b>Lopen's prediction:</b> Samus with 58.12%<br><br><br> <br><b>KH&#8217;s Analysis</b><br> <br>lol x-stats history<br><br>Samus Aran<br><br>Summer 2002 Contest<br>Extrapolated Strength --- 4th Place [41.07%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 7th Place [36.72%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 4th Place [39.50%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 5th Place [38.21%]<br><br>Samus does about as expected on Rikku. Not much to say about it, just like every other female match!<br><br>Tifa Lockheart<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 16th Place [30.77%]<br><br>Tifa doubles up on Peach, not too much to say either way about it. Just like every other female match!<br><br>Rikku struggles against Kairi. Not exactly good when your next round opponent is...Samus? Oh, dear...
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/6/2006 9:57:30 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345866163">message detail</a>
 | #281</td></tr>
<tr class="even"><td>
<i>Notable Releases Since Last Appearance</i><br><br>Samus Aran: Metroid Prime: Hunters (DS), Metroid Prime Pinball (DS), Super Smash Brothers Brawl Trailer (lol internet)<br>Tifa: Kingdom Hearts II (PS2)<br><br><i>Upcoming Releases</i><br><br>Samus Aran: Metroid Prime 3: Corruption (WII), Super Smash Brothers Brawl (WII)<br>Tifa: N/A<br><br>Well,
this match is only really important because it's the debut of Zero Suit
Samus, and will help to quell speculation concerning whether or not it
will help or hurt Samus. I really don't think it'll matter either way,
maybe a lil' to hurt, but it's not like Tifa had a chance here anyway.
Her big goal is to do as well as possible to show that she has a chance
at challenging Zelda (though the point is perhaps moot since such a
match would be after TP).<br><br>Karma Hunter's Vote: Tifa. blah blah personality &gt; Samus blah blah<br><br><b>Karma Hunter's Krazy Prediction: Samus Aran with 57.46% .</b><br><br>Tifa should clear 40% pretty easily here, I should hope. Everything else is fair game.<br><br>Upset Potential: 0%<br><br>Tifa isn't affiliated with Nintendo in the slightest! She has no chance here!<br><br><br> <br><b>Guest&#8217;s Analysis</b> - <i>nintendogirl</i><br><br>Hey
it&#8217;s me, the user you&#8217;ve never seen or even heard of before! I&#8217;m
stepping in as the guest today because I think that even I can predict
this one without looking like too much of an idiot. Before this year, I
lurked during contest time but never really paid any interest to the
subtleties of the contest. Swings and SFF and surprisingly, I had no
concept of the Noble Nine.<br><br>So now, with all that knowledge and a little hoping I reckon I can quite happily say that Samus is going to win.<br><br>&lt;_&lt;<br><br>Okay,
so you knew that bit. Samus is Noble Nine and there is I don&#8217;t think
anyone in the main bracket that can hit over 47% on her. She is a
fully-suited Nintendo mascot with missiles blaring while Tifa is the
big boobed girl from FF7. Yeah, she had a cameo in KHII, but to be
honest, it will mean absolutely nothing next to Samus.<br><br>Incidentally
apparently even most of the casuals know that with Samus being the
character with the highest bracket support in the second and third
rounds and the second highest in the first round.<br><br>So, in
summary, Samus will breeze through this match as she heads all the way
to the Battle Royale with a comfortable margin against whoever meets
her in the final.<br><br>Ngirl&#8217;s prediction: Samus with 59.83%<br> <br> <br> <br>Crew Consensus: Easy Samus win says the Crew. Samus in the (surprise surprise!) mid to high 50's.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/6/2006 9:59:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345866643">message detail</a>
 | #282</td></tr>
<tr class="even"><td>
...I thought I took out that line from Samus/Rikku! BAH<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 11/6/2006 10:03:04 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345867634">message detail</a>
 | #283</td></tr>
<tr class="even"><td>
I don't want to read about you. I want to read about the match. &gt;_&gt;<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=640243" class="name">Big Bob</a> |
Posted 11/6/2006 10:08:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345869163">message detail</a>
 | #284</td></tr>
<tr class="even"><td>
<b><i>Big Bob's completely biased and nonsensical analysis</i></b><br><br>Tifa
has obviously boosted from Kingdom Hearts II. Samus has her ZSS pic,
which could possibly hurt or help her. Samus is gonna win easily, but I
fully expect this match to set off some alarms. Board 8 will be in a
riot after this match happens.<br><br><b>Bob's Prediction: Samus with...um...hold on.</b><br><br><i>(goes to check  what Sonic got on Tifa last year)</i><br><br><b>...56.39%</b><br>---<br>Gordon
Freeman finally won, but somehow, the universe survived... thus
allowing me to tell said universe about how I was owned by <b>NClark128</b>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=788233" class="name">PokemonPatriarch</a> |
Posted 11/6/2006 10:16:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345871333">message detail</a>
 | #285</td></tr>
<tr class="even"><td>
What's truly ironic is that Samus has just as much if not <i>more</i> of TJF for once...and against TIFA!<br>---<br>Proud fanboy of the Ogre Battle saga!!!<br><b>~~~Allah Approves~~~ </b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=152338" class="name">Lopen</a> |
Posted 11/6/2006 10:23:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345872902">message detail</a>
 | #286</td></tr>
<tr class="even"><td>
Tifa &gt; Samus?  That's not my flavor of upset... you don't know me, Ashe!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/6/2006 10:23:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345873028">message detail</a>
 | #287</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Divisional Finals are down,
we now move to the SemiFinals! No Belarus here, but whatever, that's
beside the point. The point is, we have Samus vs. Tifa, a great Noble
Nine / Nintendo character vs. a strong Final Fantasy character. Should
be an interesting match, but nothing more than a mere speedbump for
Samus. Yup, the Noble Nine remains in tact after this year, folks.
Hopefully noone's too disappointed about that fact.<br><br>My vote: Samus (even though I hate her)<br>My bracket: Samus over TIFA! I SWEAR TO ****ING GOD I HATE TIFA!!<br>My prediction: Samus with 57%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/6/2006 10:25:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345873528">message detail</a>
 | #288</td></tr>
<tr class="even"><td>
Ivy &gt; Tifa in TJF, no TJF in Tifa/The Boss, sprite against Peach and Samus &gt; Tifa in TJF.<br><br>This just hasn't been Tifa's contest TJF-wise.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Samus vs. Tifa - Bracket: <b>Samus</b> - Vote: <b>Samus</b> (88/96)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=254355" class="name">Lugia2</a> |
Posted 11/7/2006 6:32:42 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345921178">message detail</a>
 | #289</td></tr>
<tr class="even"><td>
[This message was deleted at the request of a moderator or administrator]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3800578" class="name">Lady Ashe</a> |
Posted 11/7/2006 6:55:49 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345922490">message detail</a>
 | #290</td></tr>
<tr class="even"><td>
<i>From Lopen</i><br><i>Tifa &gt; Samus?  That's not my flavor of upset... you don't know me, Ashe!  </i><br><br>Hah! Well it's pretty clear now that it should be!<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 11/7/2006 9:19:03 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345935566">message detail</a>
 | #291</td></tr>
<tr class="even"><td>
<i>Karma Hunter's Krazy Prediction: Samus Aran with 57.46% .<br><br>Tifa should clear 40% pretty easily here, I should hope. Everything else is fair game.<br><br>Upset Potential: 0%<br><br>Tifa isn't affiliated with Nintendo in the slightest! She has no chance here!</i><br><br>LOL KH<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 7</i>: Bahamut (2-4)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3216520" class="name">TheSwizzle</a> |
Posted 11/7/2006 10:39:21 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345946370">message detail</a>
 | #292</td></tr>
<tr class="even"><td>
If only Vlado were here the guests would've <i>won</i>...  DARN IT.<br>---<br><i>"If at first you don't succeed, find out if the loser gets anything."</i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=152338" class="name">Lopen</a> |
Posted 11/7/2006 1:08:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345971124">message detail</a>
 | #293</td></tr>
<tr class="even"><td>
You know... if I knew they were using Malibu Suit Samus, I'd have made this match a <i>lot</i> closer.  I really should've looked at the pic.  <br><br>Believe it or not.  <br><br>(Not <i>this</i> close, mind you.)<br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3605206" class="name">wavedash101</a> |
Posted 11/7/2006 1:09:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345971263">message detail</a>
 | #294</td></tr>
<tr class="even"><td>
PIC FACTOR = APPROVED<br>---<br><b>Our shields cannot withstand wavedashing of this magnitude!</b><br>Board 8's Unofficial Master of the Phoenix Down
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3605206" class="name">wavedash101</a> |
Posted 11/7/2006 1:10:43 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345971433">message detail</a>
 | #295</td></tr>
<tr class="even"><td>
lol KH!<br><br>---<br><b>Our shields cannot withstand wavedashing of this magnitude!</b><br>Board 8's Unofficial Master of the Phoenix Down
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=460011" class="name">FourthDeus</a> |
Posted 11/7/2006 1:11:54 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345971630">message detail</a>
 | #296</td></tr>
<tr class="even"><td>
<i>Upset Potential: 0%<br><br>Tifa isn't affiliated with Nintendo in the slightest! She has no chance here!<br></i><br><br>lol ZS Samus (aka Samus Fans are Morons Factor) + FFXII Factor<br>---<br>5/18/05<br>Never forget.  Never forgive.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/7/2006 1:39:51 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=345976677">message detail</a>
 | #297</td></tr>
<tr class="even"><td>
I knew you were all going too high, but......wow.....<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/7/2006 3:46:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346005445">message detail</a>
 | #298</td></tr>
<tr class="even"><td>
Crono..................54.5% 68115<br>Auron..................45.5% 56865<br>TOTAL VOTES ............124980<br><br>46.04% of the brackets predicted this match correctly.<br><br>Pretty
good prediction percent for Crono, considering it's well...Crono.
Still, Auron made him sweat today, as he pulls 45.5% on the Noble
Niner. We knew Auron was underrated last year, but it seems Auron is
even stronger this year, and that Sub-Zero is pretty darn strong.<br><br>Today, I guess the casuals don't recognize ZSS is all. because Samus is barely beating Tifa!<br><br>Moltar - 11<br>HM - 10<br>KH - 10<br>Lopen - 9<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Ulti - 7<br>Yoblazer - 5<br><br>HM is on a tear as he gets another point.<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Samus vs. Tifa - Bracket: <b>Samus</b> - Vote: <b>Samus</b> (88/96)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/7/2006 9:27:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346099210">message detail</a>
 | #299</td></tr>
<tr class="even"><td>
<b>Triforce/Aeon Division:</b> <i>Round 4 - Match 58</i> &#8211; (1)Princess Zelda vs. (1)Yuna <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Zelda</b> - <i>This Twilight Princess looking to win another match.</i><br>Round 1 &#8211; 86.08% vs. Carmen (13.92%)<br>Round 2 &#8211; 79.45% vs. Terra (20.55%)<br>Round 3 &#8211; 56.87% vs. Aeris (43.13%)<br><br>Zelda beats Aeris Ulti-Style! How embarrassing.<br><br><b>Yuna</b> - <i>Our annual &#8220;Their division must have been real crappy if they could make it to Round 4&#8221; contestant this year!</i><br>Round 1 &#8211; 79.30% vs. Roll (20.70%)<br>Round 2 &#8211; 78.05% vs. Joanna (21.95%)<br>Round 3 &#8211; 60.84% vs. Chun-Li (39.16%)<br><br>Yuna laughs at Chun-Li&#8217;s attempt to challenge her.<br><br>The
female half is almost over, and we still have predictible as crap
matches, great. Oh well, at least the payoff of Snake/MM and
Sonic/Crono should be worth it.<br><br>This match isn&#8217;t that bad. I
mean, both these characters have impressed a lot of us round after
round. Round 1, both blowout their opponents by much more than
expected. Round 2, both again destroy their opponents, who had also
been in the last Contest, by enough to make them look like Noble Nine
people. Round 3, in debated matches, Zelda easily takes care of Aeris,
and Yuna easily takes care of Chun-Li.<br><br>Now, if last year never
happened, there may be some talk on this match. But, last year
happened, so oh well Yuna. Yeah, if you don&#8217;t remember Yuna got
thrashed by Ganondorf last year in a 61-39 affair. Now, Zelda is at
Ganon&#8217;s level&#8230;so you put 2 and 2 together. At least Yuna had a good run
though&#8230;and I&#8217;ll give her a couple percent extra for her efforts this
Contest.<br><br><b>Moltar&#8217;s Bracket Says:</b> Zelda will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Zelda: 59% - Yuna: 41%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br> <br>We're
in the final eight and still have eeeeeeeasy matches on the female
side. All this is is a "guess the winner's percent!" type of match.<br><br>lolcwutididthur?<br><br>Prediction: Zelda with 65.00%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br> <br><b>Zelda</b><br><br><i>Previous Matches:</i><br><br>Zelda &#8211; 86.08% -- 102,509<br><br>Carmen Sandiego &#8211; 13.92% -- 16,578 <br><br>Zelda &#8211; 79.45% -- 92,826<br><br>Terra Branford &#8211; 20.55% -- 24,005 <br><br>Zelda &#8211; 56.87% -- 71,597<br><br>Aeris Gainsborough &#8211; 43.13% -- 54,300 <br><br><b>Yuna</b><br><br><i>Previous Matches:</i><br><br>Yuna &#8211; 79.3% -- 97,716<br><br>Roll &#8211; 20.7% -- 25,501 <br><br>Yuna &#8211; 78.05% -- 89,711<br><br>Joanna Dark &#8211; 21.95% -- 25,229 <br><br>Yuna &#8211; 60.84% -- 71,634<br><br>Chun-Li &#8211; 39.16% -- 46,106 <br><br>Zelda comes into this match looking absolutely <i>dominative</i>
in every possible way. She has exceeded both expectations and stats in
every single one of her matches. Her latest match gave FFVII its worst
loss in contest history, beating out Link&#8217;s beat down of Sephiroth in
2002. That kind of strength is very nice to see from Zelda. Yuna, too,
comes into this match looking much stronger than usual. She&#8217;s exceeded
expectations and made Chun-Li look like nothing with an easy victory
over here. <br><br>With all that said, even with both of them having
impressed, Zelda comes into this match with much more impressive wins
and over stronger characters. She took care of Aeris nearly as well as
Yuna took care of Chun-Li; that about takes care of any questions
surrounding the winner of this one. What will be really interesting to
see in this match is if Zelda can match, or get close, to what Ganon
put up on Yuna last year. Of course, Yuna looking stronger this year
may have Zelda having trouble matching the percentage, but it will be
great if she&#8217;s able to.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/7/2006 9:27:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346099453">message detail</a>
 | #300</td></tr>
<tr class="even"><td>Zelda&#8217;s path, for the most part, seems pretty set
regardless of this match. She has a showdown with Samus next round for
the female bracket winner and I think she has a shot there, even if
it&#8217;s not a great one. If Zelda can match, or even exceed, Ganon&#8217;s
percentage last year, I think she&#8217;ll be looking <i>really</i>
good. I doubt she wins without Twilight Princess out, but considering
the new screenshots and trailer that have her in them &#8211; she looks <i>fantastic</i>, I might add &#8211; she may put on a show here and in the next round. <br><br>She&#8217;s been the highlight of the contest for me and it&#8217;ll be good to see that continue here <i>!!</i> <br><br><b>Aitch Emm&#8217;s Bracket:</b> Zelda<br><br><b>Aitch Emm&#8217;s Prediction:</b> Zelda &#8211; 62% ; Yuna &#8211; 38%<br><br><b>Aitch Emm&#8217;s Vote:</b> Zelda<br><br> <br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br><br>This
match has me a lot more conflicted right now than it did about 22 hours
ago. On the one hand, Tifa is having one of the great performances in
contest history against Samus Aran as we speak. Could Final Fantasy XII
be having a profound effect? Could KHII have boosted its female
characters more than we previously thought? Add to this the fact that
Yuna has already looked amazing herself, and the concept of another FF
overperformance is looming its ominous head.<br><br>However, there's
also no denying the fact that Zelda scored 57% against Aeris. Think
about it... fifty-seven ****ing percent on a character who many once
thought could challenge or even defeat Tifa. I get the feeling that a
lot of people will go low here in the face of Tifa's miraculous job,
but there's no way I give this to Zelda with less than 57%. Absolutely
no way. Hell, up until yesterday, I was ready to put her a good
percentage point or so ahead of Ganon's percentage last year (which
means I would have picked Zelda with about 62-63%). Sadly, I'm too
chicken for that bold of a prediction now, but I still have a feeling
Zelda will lay the smack down.<br><br>Now, if you gentlemen will excuse me, the polls close in less than an hour, and I feel like voting for some reason. America FTW.<br><br>My prediction: Zelda def. Yuna (60-40)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br>Yuna
doing better than Aeris&#8230; it defies all logic we've had from previous
years. And yet, I think it could happen here. Yuna has just looked
better than Aeris this year. Come on, beating KOS-MOS with 61.65% or
beating Chun Li with 60.84%? Which is better? I know I'd take Chun Li
to beat KOS-MOS without sweating it too much. Heck, she almost looked
as good as <i>freaking Mario</i> against Joanna Dark.<br><br>So that's what this match boils down to: previous expectations vs. current expectations. I'm taking current. I can't explain <i>why</i>
Yuna's suddenly become a bracket steamrolling machine (okay, small
brackets!). Maybe she's been hitting the megaelixir this year. Who
knows? All I know is based on <i>this</i> year, not 2003 or 2004 or 2005... Yuna's looking better.<br><br>Does she have a chance? Would be nice&#8230; but no, I'm not going <i>that</i> far!<br><br><b>Lopen's prediction:</b> Zelda with 55.85%<br><br><br> <br><b>KH&#8217;s Analysis</b><br> <br>lol x-stats history<br><br>Zelda<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 19th Place [30.29%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 14th Place [30.89%]<br><br>Zelda
whipped up on Aeris last round beyond almost anyone's expectations,
solidifying her place in the Final Four. And with the way that freaking
<i>Samus</i> is performing on the other FF7 girl...Zelda for the Finals??? o_O<br><br>Yuna<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 34th Place [23.66%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 31st Place [23.92%]<br><br>Yuna
destroys Chun-Li last round, making it her third straight
overperformance in a row. If it weren't for the uber-Zelda that we've
been seeing, people would be calling for the upset here, believe you
me.
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=4">5</a></li>
<li>6</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=6">7</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=9">10</a></li>
</ul>
</div>


</div>
<img src="genmessage6_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage6_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31382187&amp;page=5" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage6_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>