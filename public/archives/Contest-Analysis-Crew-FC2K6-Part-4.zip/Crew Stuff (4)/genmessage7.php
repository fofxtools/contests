<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html><head><title>GameFAQs - GameFAQs Contests Message Board</title>

	



<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="GameFAQs Contests Message Board, GameFAQs Contests Forum, GameFAQs Contests Discussion, GameFAQs Contests User Discussion, GameFAQs Contests Player Discussion, GameFAQs Contests Players, Talk About GameFAQs Contests, Discuss GameFAQs Contests, GameFAQs Contests User Topics">
<meta name="description" content="GameFAQs Contests Forum - GameFAQs is the best place for GameFAQs Contests message boards where you can get in heated GameFAQs Contests discussions with other hard core gamers.">
<link href="genmessage7_files/default.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="genmessage7_files/nogs.css"></head><body linkifytime="270" linkified="6" linkifying="false">
<div id="container">
	<div id="gne_nav">
		<img src="genmessage7_files/ge_img_6_light.gif" alt="CNET Networks Entertainment">
		<a href="http://www.gamespot.com/">GameSpot</a>: <a href="http://www.gamespot.com/ps3/index.html">PS3</a> - <a href="http://www.gamespot.com/wii/index.html">Wii</a> | <a href="http://www.gamefaqs.com/">GameFAQs</a> | <a href="http://www.metacritic.com/">Metacritic</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a href="http://www.tv.com/">TV.com</a>
	</div>

	<div id="header">
		<div id="logo">
			<a href="http://www.gamefaqs.com/"><img src="genmessage7_files/v9_clear.gif" alt="GameFAQs"></a>
		</div>
		<div id="loginbox">
	<div class="msg">
		Welcome, KirbyKhan
	</div>
	<div class="nav">
	<a href="http://www.gamefaqs.com/user/logout.html?r=boards.gamefaqs.com%2Fgfaqs%2Fgenmessage.php%3Fboard%3D8%26topic%3D31382187%26page%3D6"><b>Logout</b></a>
	<a href="http://www.gamefaqs.com/user/manage.html" class="last"><b>Manage account</b></a>
	</div>
</div>
	</div>
	<div id="searchbox">
		<form id="search" method="get" action="http://www.gamefaqs.com/search/index.html">
		<label for="searchtextbox"><a href="http://www.gamefaqs.com/search/index.html">Search:</a></label>
		<input id="searchtextbox" name="game" value="" class="text" type="text">
		<select id="searchplatform" name="platform">
			<option value="0" selected="selected">All Platforms</option>
			<option>--------</option>
			<option value="1026">DS</option>
			<option value="12">Game Boy Advance</option>
			<option value="11">GameCube</option>
			<option value="5">PC</option>
			<option value="7">PlayStation 2</option>
			<option value="1028">PlayStation 3</option>
			<option value="1024">PSP</option>
			<option value="1031">Wii</option>
			<option value="13">Xbox</option>
			<option value="1029">Xbox 360</option>
			<option>--------</option>
			<option value="26">Arcade</option>
			<option value="1">Dreamcast</option>
			<option value="2">Game Boy</option>
			<option value="9">Game Boy Color</option>
			<option value="10">Genesis</option>
			<option value="1006">N-Gage</option>
			<option value="18">Neo-Geo</option>
			<option value="19">NES</option>
			<option value="4">Nintendo 64</option>
			<option value="6">PlayStation</option>
			<option value="8">Saturn</option>
			<option value="21">SNES</option>
			<option>All Platforms</option>
		</select>
		<div class="btn"><a href="#" onclick="document.getElementById('search').submit();"><b>go</b></a></div>
		</form>
	</div>
	<div id="quicknav">
		<p>
			<a href="http://www.gamefaqs.com/">Home</a>
			<a href="http://www.gamefaqs.com/new/index.html">What's New</a>
			<a href="http://www.gamefaqs.com/contribute/">Contribute</a>
			<a href="http://www.gamefaqs.com/features/">Features</a>
			<a href="http://boards.gamefaqs.com/gfaqs/index.php">Boards</a>
			<a href="http://www.gamefaqs.com/features/help/">Help</a>
		</p>
	</div>
	<div id="platformlist">
		<div class="nav">
			<b>Platforms:</b>
			<a href="http://www.gamefaqs.com/portable/ds/">DS</a> |
			<a href="http://www.gamefaqs.com/portable/gbadvance/">GBA</a> |
			<a href="http://www.gamefaqs.com/console/gamecube/">GameCube</a> |
			<a href="http://www.gamefaqs.com/computer/doswin/">PC</a> |
			<a href="http://www.gamefaqs.com/console/ps2/">PS2</a> |
			<a href="http://www.gamefaqs.com/console/ps3/">PS3</a> |
			<a href="http://www.gamefaqs.com/portable/psp/">PSP</a> |
			<a href="http://www.gamefaqs.com/console/wii/">Wii</a> |
			<a href="http://www.gamefaqs.com/console/xbox/">Xbox</a> |
			<a href="http://www.gamefaqs.com/console/xbox360/">Xbox 360</a> |
			<a href="http://www.gamefaqs.com/systems.html">All&nbsp;Systems</a>
		</div>
		<div class="jumper">
			<form id="sys" action="/search/jump.php" method="get">
				<select id="jumpmenu" name="sys" onchange="location=options[selectedIndex].value;">
				<option value="/systems.html" selected="selected">Platform Jumper</option>
				<option value="http://www.gamefaqs.com/coinop/arcade/">Arcade</option>
				<option value="http://www.gamefaqs.com/console/dreamcast/">Dreamcast</option>
				<option value="http://www.gamefaqs.com/portable/ds/">DS</option>
				<option value="http://www.gamefaqs.com/portable/gameboy/">Game Boy</option>
				<option value="http://www.gamefaqs.com/portable/gbadvance/">Game Boy Advance</option>
				<option value="http://www.gamefaqs.com/portable/gbcolor/">Game Boy Color</option>
				<option value="http://www.gamefaqs.com/console/gamecube/">GameCube</option>
				<option value="http://www.gamefaqs.com/console/genesis/">Genesis</option>
				<option value="http://www.gamefaqs.com/portable/ngage/">N-Gage</option>
				<option value="http://www.gamefaqs.com/console/neogeo/">Neo-Geo</option>
				<option value="http://www.gamefaqs.com/console/nes/">NES</option>
				<option value="http://www.gamefaqs.com/console/n64/">Nintendo 64</option>
				<option value="http://www.gamefaqs.com/computer/doswin/">PC</option>
				<option value="http://www.gamefaqs.com/console/psx/">PlayStation</option>
				<option value="http://www.gamefaqs.com/console/ps2/">PlayStation 2</option>
				<option value="http://www.gamefaqs.com/console/ps3/">PlayStation 3</option>
				<option value="http://www.gamefaqs.com/portable/psp/">PSP</option>
				<option value="http://www.gamefaqs.com/console/saturn/">Saturn</option>
				<option value="http://www.gamefaqs.com/console/snes/">SNES</option>
				<option value="http://www.gamefaqs.com/console/wii/">Wii</option>
				<option value="http://www.gamefaqs.com/console/xbox/">Xbox</option>
				<option value="http://www.gamefaqs.com/console/xbox360/">Xbox 360</option>
				<option value="http://www.gamefaqs.com/systems.html">-Full List-</option>
				</select>
				<noscript>
				<div id="jumpbuttons">
				<div class="btn"><a href="javascript:void(0);" onclick="document.getElementById('sys').submit();"><b>go</b></a></div>
				</div>
				</noscript>
			</form>
		</div>
	</div>

	<div id="content">

	<div class="head"><h1>GameFAQs Contests</h1></div><div id="board_wrap">

<div class="ad" style="text-align: center;">
<div style="text-align: center;"><img src="genmessage7_files/advertisement.gif" alt="advertisement" height="10" width="120"><br></div>
<script language="JavaScript">
<!--

function SymError()
{
  return true;
}

window.onerror = SymError;

var SymRealWinOpen = window.open;

function SymWinOpen(url, name, attributes)
{
  return (new Object());
}

window.open = SymWinOpen;

//-->
</script>

<iframe src="genmessage7_files/a.xhtml" marginwidth="0" marginheight="0" hspace="0" vspace="0" bordercolor="#000000" frameborder="0" height="90" scrolling="no" width="728">
&lt;SCRIPT language='JavaScript1.1'
SRC="http://ad.doubleclick.net/adj/N3340.CNET/B2067766.29;abr=!ie;sz=728x90;click0=http://adlog.com.com/adlog/e/r=10153&amp;s=700192&amp;t=2006.11.13.16.14.08&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;e=&amp;rqid=00c17-gne-ad64551C992282B08B&amp;event=58/;ord=2006.11.13.16.14.08?"&gt;
&lt;/SCRIPT&gt;
&lt;NOSCRIPT&gt;
&lt;A
href="http://adlog.com.com/adlog/e/r=10153&amp;s=700192&amp;t=2006.11.13.16.14.08&amp;o=1:&amp;h=pi&amp;p=&amp;b=4&amp;l=En_US&amp;site=6&amp;pt=&amp;nd=&amp;pid=&amp;cid=&amp;pp=&amp;e=&amp;rqid=00c17-gne-ad64551C992282B08B&amp;event=58/http://ad.doubleclick.net/jump/N3340.CNET/B2067766.29;abr=!ie4;abr=!ie5;sz=728x90;ord=2006.11.13.16.14.08?"&gt;
&lt;IMG
SRC="http://ad.doubleclick.net/ad/N3340.CNET/B2067766.29;abr=!ie4;abr=!ie5;sz=728x90;ord=2006.11.13.16.14.08?"
BORDER=0 WIDTH=728 HEIGHT=90 ALT="Click Here"&gt;&lt;/A&gt;
&lt;/NOSCRIPT&gt;
</iframe>
<img src="genmessage7_files/dotclear.gif" alt="" style="position: absolute; top: 0px; left: 0px;" height="0" width="0">
</div>
<div class="head"><h1>
	Fall 2006 Contest Analysis Crew - Part 4
	</h1></div>
<div class="board_nav">
	<div class="body">
<div class="user">
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;page=6">Master Moltar (34)</a>
| <a href="http://boards.gamefaqs.com/gfaqs/index.php">Board List</a>
	| <a href="http://boards.gamefaqs.com/gfaqs/gentopic.php?board=8">Topic List</a>
		| Topic Closed
					 | <a href="#8,31382187" id="gamefox-tag-link">Tag Topic</a></div><div class="pages">
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">First Page</a> |
<a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=5">Previous Page</a> |
Page 7 of 10
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=7">Next Page</a>
| <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=9">Last Page</a>
</div>
	</div>
</div>

<div class="board">
<table class="message">



<tbody><tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/7/2006 9:28:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346099719">message detail</a>
 | #301</td></tr>
<tr class="even"><td>
<i>Notable Releases Since Last Appearance</i><br><br>Zelda: N/A<br>Yuna: Kingdom Hearts II (PS2)<br><br><i>Upcoming Releases</i><br><br>Zelda: The Legend of Zelda: Twilight Princess (WII)<br>Yuna: N/A<br><br>Zelda should have this one...by a lot...but seriously, WTF Samus.<br><br>Karma Hunter's Vote: Yuna.<br><br>Prediction: Zelda with 61.47%<br><br>This <i>feels</i> like it should be a more impressive Yuna, so I'm going low here. Well, for me anyway.<br><br><b>Upset Potential: 30%<br><br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br><br>...yeah,
I don't really have a reason for this, especially a potential this
high. But I didn't have one for Tifa doing what she's doing to Samus
today. Um...if Yuna wins, I called it? &lt;_&lt;<br><br>Upset Prediction: Yuna with 53.54%<br><br> <br><b>Guest&#8217;s Analysis</b> - <i>chocoboslayer</i><br><br>If
I gave a damn about lol x-stats and contest history and all that stuff,
I would write it in here. Guess what....I don't. So, let's move on.<br><br>Both
of these two beat the holy hell out of their first two opponents,
showed dominance against a more difficult third round opponent, and now
they get to fight....TO THE DEATH!!<br>(Ok...maybe not to the death....but you get the point.)<br><br>This
match is simple. While I may have guessed wrong about the winner of
this match, the loser has been obvious from the moment the bracket was
released. All good things must come to an end, and Yuna's run in this
contest is no exception. It's my personal belief (or fanboy desire,
your pick) that Yuna will do better here than Aeris did last round.<br><br>...what?<br><br>Choco's Bracket: Aeris (lol)<br>Choco's Vote: Yuna<br>Choco's Prediction: Zelda def. Yuna, 53%-47%<br><br> <br>Crew Consensus: Wow, predictions all over the place for Zelda. Yeah she wins, but from anywhere in the low 50's to mid 60's.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 11/7/2006 9:28:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346099802">message detail</a>
 | #302</td></tr>
<tr class="even"><td>
HM isn't the high man? That's just stupid  crazy.<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786689" class="name">HoorayProxies</a> |
Posted 11/7/2006 9:29:39 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346099991">message detail</a>
 | #303</td></tr>
<tr class="even"><td>
Oh, and hit or miss Lopen is totally taking the point on this one. And he's not even one of the extremes!<br><br>---<br>Hooray Beer, Hooray Proxies!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/7/2006 9:30:49 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346100359">message detail</a>
 | #304</td></tr>
<tr class="even"><td>
[This message was deleted at the request of the original poster]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/7/2006 9:31:33 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346100577">message detail</a>
 | #305</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>What an odd result today.
Thankfully, Zelda's opponent is from FFX; Yuna won't be too impressive
like Tifa is today. How well will she do though? Could we see some
serious Zelda &gt; Samus discussions coming?<br><br>My vote: Zelda<br>My bracket: Let's not talk about this....<br>My prediction: Zelda with 54.76%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=640243" class="name">Big Bob</a> |
Posted 11/7/2006 10:03:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346109946">message detail</a>
 | #306</td></tr>
<tr class="even"><td>
<b><i>Big Bob's completely biased and nonsensical analysis</i></b><br><br>Congrats, a character I hate made it to round four simply because her division was weak as hell.  Knock 'er dead, Zelda.<br><br><b>Bob's Prediction: Zelda with 100%</b><br>Hey, I'M not voting for Yuna.<br>---<br>Gordon
Freeman finally won, but somehow, the universe survived... thus
allowing me to tell said universe about how I was owned by <b>NClark128</b>.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/7/2006 10:57:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346123693">message detail</a>
 | #307</td></tr>
<tr class="even"><td>
Holy ****crap! Tifa is making Samus look like fodder out there! As long
as Zelda doesn&#8217;t completely bomb against Lady Yuna, Zelda &gt; Samus is
all but a lock! But she isn&#8217;t quite there yet. Will Zelda disappoint
against Yuna? I suggest you read on and find out! Both of these lovely
ladies have been tearing their part of the bracket to shreds so I
highly doubt they need any introduction at this point, but I&#8217;ll give
them one anyways because I&#8217;m good like that. Here we have everybody&#8217;s
second favourite princess (Ashe is still first <i>!!</i>)
up against the lovable summoner, Yuna! Both have been bafflingly
brilliant up to this point, but Zelda seems to be a strong favourite
heading in. Let&#8217;s take a look at what each of the pair have going for
them, shall we?<br><br>Zelda, Zelda, Zelda... What will we do with you? You have been an absolute <i>beast</i>
up to this point, and it doesn&#8217;t look like you&#8217;ll be slowing down any
time soon. In the first two rounds you blew out fodder, but that
doesn&#8217;t mean very much now that we have hit the elite eight. However,
in the third round you surpassed expectations a third time by getting
an absolutely amazing 56.87% on Aerith, one of the top female video
game characters of all time. Aerith and Yuna come from the same series,
and can you really see Yuna beating Aerith? I know that I certainly
can&#8217;t. Twilight Princess is coming ever closer and we have seen Zelda
in a trailer casting one badass spell, so if anybody had any doubt in
their mind about which character they were going to vote for, it has
been completely expelled.<br><br>On the other hand, Yuna has been
looking pretty powerful herself. She blew away fodder almost as well as
Zelda did in the first two rounds, and put up some pretty strong
numbers against Chun-Li. Final Fantasy XII has come out and enough
people have played it by this point that it could potentially give her
a fair boost. In addition to this, Yuna made an appearance in Kingdom
Hearts II, and everybody knows just how much that helped Auron. Put
those two factors together and we have a potentially close match, right?<br><br>Wrong.
The Final Fantasy XII factor is a pile of garbage made up by Samus
fanboys in an attempt to justify her abysmal performance today. Even if
we assume that the FFXII factor does exist, Zelda has already proved
herself to be immune to it from her match against Aerith, while Yuna
failed to take advantage of it against Chun-Li. As much as I love Yuna,
she doesn&#8217;t have a ghost of a chance. I might even go so far as to say
that the voters are going to &#8220;Stay away from the summoner&#8221;!<br><br>My prediction? Zelda with 99.99%. <i>Everyone left in the contest is so screwed !!</i><br><br><b><i>Not so fast, Zelda! You&#8217;ve activated Yuna&#8217;s trap card, a costly mistake !!</i></b><br><br>While
most signs indicate to Zelda making Yuna look worse than Carmen
Sandiego, there is one very important factor that I haven&#8217;t yet
mentioned, and it is the picture factor. If people can make up garbage
about Samus underperforming due to her picture, I can do the same thing
when it comes to Zelda and this garbage: <a class="linkification-ext" href="http://www.gamefaqs.com/shared/cb5/cb558.jpg" title="Linkification: http://www.gamefaqs.com/shared/cb5/cb558.jpg">http://www.gamefaqs.com/shared/cb5/cb558.jpg</a><br><br>Zelda will still win, but Yuna will manage to impress due to that absolutely pathetic picture that Ceej gave the princess.<br><br>My revised prediction? Zelda with 62.34%.<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/8/2006 4:36:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346252297">message detail</a>
 | #308</td></tr>
<tr class="even"><td>
Samus Aran..........50.49% 72773<br>Tifa Lockhart.........49.51% 71355<br>TOTAL VOTES................144128<br><br>46.04% of the brackets predicted this match correctly.<br><br>Oh
man, closest match between a non-Noble Niner and a Noble Niner ever.
Good thing we can just blame Samus's horrible performance on her
unrecognizable (to the casuals) Zero Suit Pic! I mean, Samus isn't
weak...or in trouble next round...right? Crazy high vote totals too.<br><br>Today, Yuna is doing pretty well against Zelda.<br><br>KH - 11<br>Moltar - 11<br>HM - 10<br>Lopen - 9<br>Guest (Wigs, SilverNightmareX7, EC (2), TheRye, transience, Lady Ashe, Kleenex) - 8<br>Ulti - 7<br>Yoblazer - 5<br><br>KH with the lowest Samus pick.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2266918" class="name">KamikazePotato</a> |
Posted 11/8/2006 7:31:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346298828">message detail</a>
 | #309</td></tr>
<tr class="even"><td>
Wait, am I doing the Snake/MM writeup? I forget.<br><br>---<br><i>Do you really need me to bring out the Ovaltine?</i>-Stripey12isback on why hes a war hero.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/8/2006 7:33:48 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346299563">message detail</a>
 | #310</td></tr>
<tr class="even"><td>
No, HaRR already did it.<br><br>I wonder who the favorite will be for the match...<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Zelda vs. Yuna - Bracket: <b>Zelda</b> - Vote: <b>Zelda</b> (96/104)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3214175" class="name">cdw01</a> |
Posted 11/8/2006 7:41:02 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346301542">message detail</a>
 | #311</td></tr>
<tr class="even"><td>
"46.04% of the brackets predicted this match correctly."<br><br>That was the prediction percentage from the Crono match. <br>63.86% of the brackets predicted Samus to win the match.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 11/8/2006 8:52:38 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346321955">message detail</a>
 | #312</td></tr>
<tr class="even"><td>
Snake will be the favorite I think among the analysis crew... but that won't stop them from being wrong!<br><br>---<br>mmm feel the vibration baby
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 11/8/2006 8:53:41 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346322213">message detail</a>
 | #313</td></tr>
<tr class="even"><td>
I say 5-2 pick Mega Man!<br>---<br>CB06 - Score: <b>98/104 </b>Rank: <b>Tied - 213th </b>Yesterday's Pick:<b> Samus</b> <br>Today's Pick: <b>Zelda</b> Tomorrow's Pick: <b>Mega Man</b> Losses: <b>Cortana, Ganon, Zero, MC, Kirby</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786721" class="name">GyratingGrandma</a> |
Posted 11/8/2006 8:54:32 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346322439">message detail</a>
 | #314</td></tr>
<tr class="even"><td>
[This message was deleted at the request of the original poster]
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/8/2006 8:56:29 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346322985">message detail</a>
 | #315</td></tr>
<tr class="even"><td>
<i>"46.04% of the brackets predicted this match correctly."</i><br><br>Yeah yeah, that'd be pretty sad. 63.86% for Zero Suit!<br>---<br>Moltar Status: Feeling good and hot-blooded.<br>Zelda vs. Yuna - Bracket: <b>Zelda</b> - Vote: <b>Zelda</b> (96/104)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/8/2006 9:11:03 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346326701">message detail</a>
 | #316</td></tr>
<tr class="even"><td>
<b>Destiny of the Patriot Division:</b> <i>Round 4 - Match 59</i> &#8211; (1)Solid Snake vs. (2)Mega Man <br><br><b>Moltar&#8217;s Analysis</b><br><br><b>Snake</b> - <i>Even as an old man, he can still kick your ass.</i><br>Round 1 &#8211; 82.15% vs. Soma (17.85%)<br>Round 2 &#8211; 57.59% vs. Squall (42.51%)<br>Round 3 &#8211; 57.16% vs. Yoshi (42.84%)<br><br>Sprite Snake does not falter against Yoshi.<br><br><b>Mega Man</b> - <i>Even Mega Man: Cheap Capcom Cash-In Adventure 54 can&#8217;t save him now!</i><br>Round 1 &#8211; 69.87% vs. Axel (30.13%)<br>Round 2 &#8211; 58.04% vs. Ryu (41.96%)<br>Round 3 &#8211; 54.28% vs. Sora (45.72%)<br><br>And MM disappoints yet again!<br><br>It&#8217;s time for Part 1 of <b>ROUND 4, MALE HALF ELITE EIGHT, EXTRAVAGANZA EVENT SPECIAL 2006 LIVE</b><i>!!</i> sponsored by the Devil May Cry, filling dark souls with <i>liiiiiight</i> since 1968.<br><br>Now,
back in 2003 and 2004, Mega Man and Snake faced each other. Both times,
Mega Man laughed in the face of Snake and won with ease both times.
That&#8217;s a great reason for Mega Man to win again. Results never change,
and the voters are robots, the x-stats prove this!<br><br>Oh
wait&#8230;Mario/Crono kinda disproves that&#8230;fine, I&#8217;ll actually go on. Ok, so
there was this little poll before the Contest, and Snake was the
favorite to win the Contest, but those mean nothing. I mean, Mega Man
wasn&#8217;t even listed! <br><br>So anyway, we get to Round 1, and Snake
makes Soma look like 100% Grade A fodder of the worst kind. It&#8217;s a good
start, I&#8217;ll admit. But how about Mega Man. I mean, did you see what he
did against Axel?! He underpeformed like no other could! Well, we don&#8217;t
know how strong Axel was, and both Riku and Kairi ended up pretty high,
so it isn&#8217;t too crazy to see Axel up there as well. Still, MM not
breaking 70% did seem really funky. Surely he&#8217;d turn it around in Round
2!<br><br>Well, before that, let&#8217;s throw in that Snake got 57.5%
against Squall. Yeah, there might have been some of that funky FF/MGS
stuff, but that&#8217;s still pretty good. But Mega Man, he&#8217;s always been
stronger, so of course he&#8217;ll look great in Round 2 against Ryu? Right?!
Wrong! He performs worse against Ryu than Bowser did, and Bowser looked
bad this Contest. Still, it&#8217;s not all that bad. I mean, before Bowser,
both Snake and Sonic only got 57% on Ryu, and Mega Man had his almighty
58%! Surely, he&#8217;s looking fine for Snake still!<br><br>Round 3 comes
along, and Snake continues to impress with his horrible sprite and gets
57% on Yoshi. Oh, but Mega Man won&#8217;t let his troopers down, because
surely he&#8217;ll obliterate Sora. Well, he didn&#8217;t obliterate him, but he
did do something. Bomb? Surely! He only pulled 54% against Sora. But
Sora had KH2, and you can&#8217;t trust Tingle and Gordon Freeman! Mega Man
is still in this!<br><br>Ok, all joking aside, Snake has looked great
going into this match, while Mega Man has looked like crap. Snake is
looking stronger than he was in 2005, and Mega Man looks weaker. Mega
Man 2005 would get 52% on 2005 Snake, so there isn&#8217;t much room for MM
to fall and Snake to rise before the results are changed. <br><br>MM
still has a chance though. If Axel really is that strong (23% on BL),
Ryu returned to his normal self, and Sora did boost that much from KH2,
then MM still has a chance. Really, there&#8217;s a decent chance of all that
coming together. However, there&#8217;s a better chance that Mega Man has
fallen. It helps things come together a lot easier. Besides, what good
releases has MM had lately? Yeah, it&#8217;s kind of weird to see him fall
off the map after so long, but it&#8217;s not like he&#8217;ll be losing to Vincent
and Ganondorf and Zelda now. However, he may very well be at the bottom
of the Noble Nine now.<br><br>Snake, on the other hand, has a very
bright future. With the highly anticipated MGS4 and SSBB on the way,
Snake seems to only be going up. Snake also has the brackets, and even
though that didn&#8217;t help him in the previous two matches because the gap
was so large to overcome, it&#8217;s likely to help him a lot more here.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/8/2006 9:11:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346326918">message detail</a>
 | #317</td></tr>
<tr class="even"><td>This match is by no means a lock for either
character. In fact, I&#8217;d call it a toss-up at this point. MM could be
considered the slight favorite because of his previous two wins over
Snake, and Snake could be called the favorite because he has flat out
looked better so far. I&#8217;m going with Solid here for the win, even
though I have Mega in my bracket. Hey, I went with Luigi when he looked
better, and right now, I&#8217;m feeling Snake will come through.<br><br><b>Moltar&#8217;s Bracket Says:</b> Snake will win.<br><br><b>Moltar&#8217;s Prediction is:</b> Snake: 51% - Mega Man: 49%<br> <br> <br><br><b>Ulti&#8217;s Analysis</b><br> <br>And
here it is. This match right here may very well be the first real
shakeup in the Noble Nine since Link/Cloud 2003. The difference this
time around is that the writing is clearly on the wall, whereas Cloud
hit everyone out of nowhere. Snake has performed out of his mind all
contest, while Mega Man has disappointed in seemingly every match. This
paired with Mega Man's <i>ass</i> prediction percentages makes me
believe that the full backing of the casual vote is behind Snake in
this match. Yes Snake has been on the ass end of two beatings at the
hands of Mega, but something about Snake is different this year.<br><br>Personally,
I think it was SSBB's first trailer. Check any Nintendo poll since and
view the dominance. If Snake is truly drawing from the Nintendo fanbase
this contest (which is seriously the one company in which hype
translates into contest strength), then he may be able to win this
match VERY easily. Mega has an uphill climb here. He can win, but he'll
need to perform a hell of a lot better than he's been doing this
contest in order to actually pull it off.<br><br>Think of it in a stats
way if you must. 2005 Mega Man scores 45.79% on 2004 Samus. In that
same 2004 contest, Sora scored 34.15% on Samus. If you slap a 50.00
value on 2004 Samus and extrapolate, 2005 Mega Man would allegedly
score 62.71% on 2004 Sora.<br><br>Mega Man just scored a measly 54.28%
on Sora. Can Kingdom Hearts 2 and a 1 seed really be the only reasons
we attribute to Sora doing 8.5% better than what he was supposed to get
two years ago? Something is off with Mega Man this year, and it's about
to get exposed unless Mega magically pulls his head out of his ass and
wins this. And before anyone forgets, Snake beat the living piss out of
Sora last year to the tune of a 65-35 pasting that would have been
worse without a minor KH day vote boost to help Sora save some face.
Metal Gear Solid just scored 58% on Kingdom Hearts in the series
contest, which happened AFTER Kingdom Hearts 2.<br><br>Snake is on
track to win this, and at this point it'll be an upset in my mind if
Mega Man wins. I don't usually go against my bracket in the Crew
writeups (especially not when I'm still way up in the scores), but I
see no advantage for Mega Man here.<br><br>Prediction: Snake with 51.83%<br> <br><br> <br><b>HM&#8217;s Analysis</b><br><br> <b>Solid Snake</b><br><br><i>Previous Matches:</i><br><br>Solid Snake &#8211; 82.15% -- 86,697<br><br>Soma Cruz &#8211; 17.85% -- 19,487 <br><br>Solid Snake &#8211; 57.59% -- 78,314<br><br>Squall Leonhart &#8211; 42.41% -- 57,666 <br><br>Solid Snake &#8211; 57.16% -- 69,085<br><br>Yoshi &#8211; 42.84% -- 51,781 <br><br><b>Mega Man</b><br><br><i>Previous Matches:</i><br><br>Mega Man &#8211; 69.87% -- 81,959<br><br>Axel &#8211; 30.13% -- 35,340 <br><br>Mega Man &#8211; 58.04% -- 69,626<br><br>Ryu &#8211; 41.96% -- 50,342 <br><br>Mega Man &#8211; 54.28% -- 72,630<br><br>Sora &#8211; 45.72% -- 61,167 <br><br>Solid
Snake and Mega Man face off yet again &#8211; it&#8217;s almost like Mario/Crono
III where the one who lost twice finally gets over the hump (wink,
wink!) &#8211; and this is looking like the most balanced encounter the two
have had. These two have been at the exact opposite ends of the
strength spectrum this contest; Mega Man has disappointed time and time
again by undershooting both statistical projections and overall
expectations. He couldn&#8217;t even manage 55% against <i>Sora</i> for crying out loud!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/8/2006 9:12:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346327076">message detail</a>
 | #318</td></tr>
<tr class="even"><td>
Snake, on the other hand, has pretty much dominated this year. He came
out looking beastly against Soma, who is untested to be fair, and then
makes Squall look like nothing and even puts up fantastic numbers
against a Yoshi that came off of beating Dante &#8211; and he did with his <i>sprite</i>
picture! Needless to say, Snake comes into this match looking to take
it with absolute ease&#8230;but it almost feels wrong to give it to him after
the last two encounters. <br><br>For whatever reason, Snake looks a
lot stronger this year. That may be because of his opponents not being
as strong as originally thought (Devil Division overrated<i>!!</i>) or
he just boosted like crazy this year. In either case, he looks good
against a Mega Man who is looking to be the weakest he&#8217;s ever been. <br><br>In
many ways, this reminds me of Mario/Crono III. Mario (Mega Man) beat
Crono (Solid Snake) in the previous two encounters, but once that third
time rolled around Crono was able to get over the hump. I&#8217;m thinking
we&#8217;re going to be seeing something similar to that here. It would be
amazing if Snake beat down Mega Man on par with how he beat Squall and
Yoshi &#8211; PLOT TWIST <i>!!</i> <br><br><b>Aitch Emm&#8217;s Bracket:</b> Mega Man<br><br><b>Aitch Emm&#8217;s Prediction:</b> Solid Snake &#8211; 53% ; Mega Man &#8211; 47%<br><br><b>Aitch Emm&#8217;s Vote:</b> SOLID SNAKE <b>!</b><br> <br><br> <br><b>Yoblazer&#8217;s Analysis</b><br><br>Frustrated, degraded, down before you're done<br>Rejection, depression, can't get what you want<br>You ask me how I make my way<br>You ask me everywhere and why<br>You hang on every word I say<br>But the truth sounds like a lie<br><br><i>Live to win, 'till you die, 'till the light dies in your eyes<br>Live to win, take it all, just keep fighting till you fall</i><br><br>Obsessive, compulsive, suffocate your mind<br>Confusion, delusions, kill your dreams in time<br>You ask me how I took the pain<br>Crawled up from my lowest low<br>Step by step and day by day<br>'Till there's one last breath to go<br><br><i>Live to win, 'till you die, 'till the light dies in your eyes<br>Live to win, take it all, just keep fighting till you fall</i><br><br>Day by day, kickin' all the way, I'm not cavin' in<br>Let another round begin, live to win<br>Yeah, live, yeah, win<br><br><i>Live to win, 'till you die, 'till the light dies in your eyes<br>Live to win, take it all, just keep fighting 'till you fall</i><br><br>Day by day, kickin' all the way, I'm not cavin' in<br>Let another round begin, live to win<br>Live to win<br>Live to win<br><i>YEAH<br>LIVE<br>YEAH</i><br><b>WIN</b><br><br>My prediction: Solid Snake def. Mega Man (52-48)<br> <br><br> <br><b>Lopen&#8217;s Analysis</b><br> <br><i>"He will kindly allow his opponent to leave the field with fewer points, but their dignity intact."</i> - Satai Delenn<br><br>That's what Mega Man's all about this year... making his opponents look good! Let's just face facts here, Mega Man's <i>got</i>
to be tired of brutally slaughtering Snake. He's done it twice now, and
this time he's changing things up. This time&#8230; Mega Man's not looking to
be&#8230; IN&#8230; well let's not even say it, it seems to be bad luck. No no...
this year... Mega Man is <b>GRACEFUL!</b> He'll exhibit in his win,
letting Snake look as good as possible. Now, I know you gots to know&#8230;
why haven't I abandoned him for Snake like the rest of the crew almost
certainly has?<br><br>You may think this is a double standard&#8230; in the
last one I said "Yuna has just looked better than Aeris this year, and
we've got to use this year! Screw the past!". Now, by what most people
are thinking, <i>Snake</i> has looked better this year. The Mega Man doomsayers are out in full force. <i>But</i>, there's a difference. Whereas Yuna doing so well totally blindsided me, I somewhat <i>expected</i> Mega Man to get what he got in each round.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/8/2006 9:12:58 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346327214">message detail</a>
 | #319</td></tr>
<tr class="even"><td>
I actually called him only getting 70% on Axel. I would've called
(believe it or not!) him only getting ~57% on Ryu had I not expected
SFF in the match (Mega Man-&gt;Yoshi and Bowser-&gt;Ryu relations
through Mario... man, it makes sense!). Something strange happened in
Ryu/Bowser, there's no doubt in my mind. And I've been calling for Sora
to impress on him since the contest began as well! (Check the <b>BOLD PREDICTION</b> topic if you don't believe me!)<br><br>Now, admittedly, I didn't expect Sora to bring him down to <i>54%</i>,
but it's not outside of my acceptable range. You think Snake getting
more on Yoshi is more impressive&#8230; but could Sora beat Yoshi? Seems like
he should be able to without sweating too much&#8230; after all, Riku got 45%
on him.<br><br>And&#8230; despite me expecting these happenings, I've had
Mega Man taking the bracket from day one. Has he lost a step? No, not
one step. He's faced one guy who was underrated through Bowser, and two
guys on Kingdom Crack. I'd say Mega Man's gonna be in for his toughest
Snake fight yet (mostly because of Snake boosting&#8230; let me say it again&#8230;
Mega Man hasn't lost a step!), but I still think he will win this one.<br><br><b>Lopen's prediction:</b> Mega Man with 51.85%<br><br> <br><b>KH&#8217;s Analysis</b><br> <br>lol x-stats history<br><br><b>SOLID SNAKE</b><br><br><i>"I'll die after I kill you."</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 9th Place [35.23%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 8th Place [34.74%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 12th Place [30.82%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 9th Place [33.88%]<br><br>Snake outperforms my expectations for the third time by crushing Yoshi...<i>in the sprite round.</i> And looking at the rest of the field's latest performances...the main bracket is yours for the taking, Snake. Just step up.<br><br><b>MEGA MAN</b><br><br><i>"What power...! I've got to go after him!"</i><br><br>Summer 2002 Contest<br>Extrapolated Strength --- 3rd Place [42.91%]<br><br>Summer 2003 Contest<br>Extrapolated Strength --- 4th Place [38.60%]<br><br>Summer 2004 Contest<br>Extrapolated Strength --- 6th Place [35.99%]<br><br>Summer 2005 Contest<br>Extrapolated Strength --- 7th Place [35.55%]<br><br>Mega
Man takes his third strike of underperforming against Sora.
Underperforming in one round is forgivable, but all three? Mega Man
will be doing very, <i>very</i> good to stay constant this year.<br><br>Then again, that *is* the Blue Bomber's M.O.<br><br><i>Notable Releases Since Last Appearance</i><br><br>Solid Snake: Metal Gear Solid 3: Subsistence (PS2), Super Smash Brothers Brawl Trailer (Internet)<br>Mega Man: N/A<br><br><i>Upcoming Releases</i><br><br>Solid Snake: Metal Gear Solid 4: Guns of the Patriots (PS3), Super Smash Brothers Brawl (WII)<br>Mega Man: N/A<br><br>This
is it, baby. The match of the contest -- nay, the match of ALL
CONTESTS. The third installation of this so-far one-sided rivalry is
here -- <b><i>Solid Snake versus Mega Man!!!</i></b><br><br>My boy,
the main man, greatest character of all time Solid Snake has been
impressing like crazy for three straight matches running up to his <i>fifth</i>
straight Elite Eight appearance. He dominated Soma Cruz, making the
character who many thought could be above the fodder line -- or even
comparable to Alucard -- look weaker than <i>unadjusted Laharl</i>
based on a constant Snake. He smashed an extremely impressive looking
post-KH2 Squall in a match that many expected Squall to win, and
whipped up on Yoshi in the sprite round to cap it all off, showing none
of the weakness that Bowser took advantage of in the sprite round last
year.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/8/2006 9:13:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346327390">message detail</a>
 | #320</td></tr>
<tr class="even"><td>Meanwhile, SUPER FIGHTING ROBOT (who would totally
beat Samus in a direct match) Mega Man has been less than stellar for
three rounds running. He let KH2's Axel break 30% on him. I may be the
man's number one fan on the board (<b>Commit it to memory.</b>), but It's ****ing <i>Axel</i>.
MM then proceeded to do worse on Ryu than Bowser did last year (the
same Bowser that lost to Snake in the sprite round), a Ryu that barely
did 2% better against Kratos than Alucard did. And finally, the Blue
Bomber capped off his bombing with an extremely disappointing match
against a so-far unimpressive Sora, letting the kid do less than a
percent worse than Solid Snake did in his best showing against MM.<br><br>To
put that all in perspective, before this contest Mega Man had never
dropped below 60% against a non-Noble Nine opponent other than Zero.
Not Zelda, not Tidus, not Leon Kennedy -- no one. This year he has done
it twice, has let one of said opponents break 45% on him, and Zero? The
guy got whipped by <i>Luigi</i>, a Luigi that Sonic just got done breaking 60% on. This has looked like a very, very bad year for Mega Man and co. so far.<br><br>So
you may wonder why I, Snake fanboy extraordinaire, still have Mega Man
as the favorite in this match. Well, for one, it's not like it's
without precedent:<br><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1364" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1364">http://www.gamefaqs.com/poll/index.html?poll=1364</a><br><a class="linkification-ext" href="http://www.gamefaqs.com/poll/index.html?poll=1775" title="Linkification: http://www.gamefaqs.com/poll/index.html?poll=1775">http://www.gamefaqs.com/poll/index.html?poll=1775</a><br><br>And
with the second poll further from the first in every way, Snake has a
hell of a climb to make for himself. Now, is this the same Snake or the
same Mega Man that we've seen in past years? Hell, no. But even looking
at this year, there are very compelling reasons for Mega Man to be
favored here.<br><br>Try the comparison between Sora and Riku, for
instance. Sora 2k4 gets 58.3% on Riku 2k5. If that proportion holds,
measuring Snake 2k6 through Riku and Mega Man 2k6 through Sora gives
Mega Man a 50.33% victory.<br><br>...okay, not the most reassuring of
measurements. But let's also take into account that Sora had the
biggest role in KH2 by far, while Riku's was absolutely pitiful. Even
though Sora is stronger, I'd still expect him to gain more. Let's not
forget that the proportion may have been even greater to begin with if
Samus is overrated in last year's stats (and the Tifa match certainly
isn't reassuring me that she's not). And if FFXII's release helped Sora
at all (Auron, Tifa, and Yuna are all meeting or exceeding
expectations) that makes Mega Man look even better. It's a slight, but
definite advantage to the Blue Bomber there.<br><br>Despite his
"disappointment" against Ryu, Mega Man still did the second best that
anyone has done on him -- Bowser may have outperformed him, but he also
outperformed Samus Aran and, yes, Solid Snake. Using the strongest Ryu
available Mega Man still underperformed, but it's not by that much
(like a lil' over a half percent) and he's still projected to beat
Snake comfortably using that.<br><br>Yeah, Mega Man is projected to do
significantly worse on Gordon Freeman than Snake is on Ryu Hayabusa.
But we've all suspected GF of being non-linear ever since he broke 40%
on Leon Kennedy (and every other opponent up to Sora) yet struggled
with <i>Phoenix Wright</i>.<br><br>And speaking of non-linearity
(which it seems a lot of characters are getting in on the fun with
these days) what's to say MM isn't non-linear? Or hell, most of the
Noble Nine? Picture be damned, Snake got 50.5% on Bowser and turned it
into 43% on Mario. Mega Man may give up nearly 46% of the vote to Sora,
but there's still 4% of voters that don't necessarily have to cave to
Snake, even if Snake performs stronger indirectly. It's like mnm says
-- it takes a LOT to displace the favorites, and Mega Man is a freaking
icon. Snake looks fantastic, I feel great about his chances...but he
has yet to prove himself. And that gives MM the favorite nod here.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/8/2006 9:14:10 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346327567">message detail</a>
 | #321</td></tr>
<tr class="even"><td>
Karma Hunter's Vote: <b>VOTE SNAKE</b><br><br>Favorite Prediction: Mega Man with 52.35%<br><br><b>Upset Potential: 100%<br><br>UPSET ALERT UPSET ALERT UPSET ALERT</b><br><br>...ew, okay, enough making Mega Man look good. I have not yet BEGUN to analyze!!!<br><br>Seriously,
now, let's admit it. If Snake had let Soma Cruz break 30% on him,
barely beat Squall and let Yoshi get 46-47% on him, there'd be little
to no hype for this match. Especially if Mega Man had performed to
expectations on his other opponents. We'd be looking to see how well
Snake could do, yes -- but not win.<br><br>Snake has been more impressive than Mega Man this year, plain and simple. And there are a LOT of comparisons that favor him.<br><br>Squall
is a BIG one. Now, of course Snake/Squall was SFF -- Squall's not
losing to Yoshi, especially after KH2 -- but it begs the question of
how much Squall gets on Snake indirectly. 45%? 46%? 47%? I can assure
you of this -- unless Squall is nearly even with Snake indirectly,
Snake looks golden going into this, because Mega Man let <i>Sora</i>
nearly break 46% on him. Sora is *not* stronger than Squall, directly
or indirectly. The worst post-KH Squall gets 54.4% on the best Sora
indirectly (which is more than MM got). The best Squall gets 58.86% on
the best Sora indirectly, and the worst Sora is just flat-out
embarrassing. Would this mean Squall could beat Mega Man? No -- but I'd
give him a shot.<br><br>FFXII helped Sora, you say? Well, it's nice
that Sora and Kratos were in the same fourpack from last year, because
that's a little hard to believe when you see that Sora gets almost
exactly as much on Kratos in 2k6 as he's projected to in 2k5 (and both
were behind Snake/Sora, so that doesn't matter). That doesn't mean
anything on its own, but FFXII helping out Sora to any significant
extent means that without it, Kratos boosted significantly more than
Sora this year. <i>Based on his game continuing to sell well.</i> Sora
has had the biggest game on this site up to right now, and he's
infinitely cooler and more likable in it. I can't accept that Kratos
boosted more than Sora -- let alone THAT much more than Sora.<br><br>And let's say FFXII is bringing a big influx to the site right now. Aside from Link being <i>so screwed</i>
against Cloud, that could also be a bit of a help for Snake, however
small. After all, the man's basically proven himself to have SFF with
PS FFs and KH. If FFXII snake-bit Mega Man once, he could very well get
Snake-bit again.<br><br>(okay, I may be a bit optimistic with that argument but whatever)<br><br>Snake
impressing against Yoshi came and went with little fanfare, which was
surprising considering how well he did, and how he did it with yet
ANOTHER stacked sprite picture. While perhaps not as bad as his latest
installations, sprite Snake has yielded bad results for Snake more than
once, and people definitely expected Yoshi to do well on Snake due to
it. He ended up getting clobbered, and extrapolating through Dante 2k5
makes Snake look great (while using Hayabusa 2k5 makes the man look
absolutely <i>fantastic</i>). And that's all considering Yoshi could very well have overperformed. With a good picture for Snake tonight (okay, now that <i>is</i> a stretch) he could take this match with absolute ease.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/8/2006 9:14:46 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346327722">message detail</a>
 | #322</td></tr>
<tr class="even"><td>
"But Kay Aitch! There was a background picture there! Snake had a face
picture in the background in 2003 against Ryu and he didn't
overperform!" Or so it <i>seems,</i>
my imaginary friend. Ryu being overrated all this time is a very real
possibility, even if it's only to an extent. Dante certainly didn't
look better in 2004 than he did in 2003 -- sure, you can blame it on
Viewtiful Dante, but Tails doesn't fill me with any confidence either.
And I've all but accepted Ryu being overrated in 2004 by a good amount.
Characters just don't normally go from getting 45% on Sonic to 41% on
Bowser, and KOS-MOS's dropoff was very notable as well. And KOS
certainly doesn't look too much better this year, despite her great
picture advantage against Aeris and having XSIII come out recently.
Bowser overperforming on Ryu just seems ridiculous, as for every
intangible he has Mega Man had more. And he ended up failing miserably.<br><br>It's
no lock, of course. Snake supporters have had to stress this to
insecure (=P) MM supporters for weeks now. I have stressed for a long
time that until MGS4 and SSBB, the Noble Nine breaking is far more
likely than the 'Elite Eight'. Which, succinctly, is the Noble Nine
minus Solid Snake. He's always been the odd man out -- the Playstation
Konami character amidst a gaggle of Nintendo elites, Square elites, and
gaming icons. He's always been very strong, but never competitive with
the upper tiers, and is continually overestimated by the casuals. Who
do you think the #1 pick to take the main bracket is, chumps?<br><br>But
what makes him overestimated in the first place? It doesn't hurt that
Snake is the coolest of the cool. It doesn't hurt that he may have THE
most rabid fanbase here, bar none. What DOES hurt him is that the MGS
series don't have the same universal appeal that the other top tier
games have. He has the character, just not the exposure. Oh, and he
lacks a sword.<br><br>But this is all looking to change with SSBB. Getting the support of a fanbase that can come in fourth in the <i>Series Contest</i> X-Stats against <i>Super Mario Bros.</i>
is no ****ing joke. He's already gained some fans simply by being
announced for the damn thing. He stole the show at E3 with it and MGS4.
The damn new SSBB gameplay video where he ****ing kicks ass probably
gained him a few fans.<br><br>After SSBB, Snake/Mega Man will be a
foregone conclusion for Snake. Even if MM ends up being in the damn
thing. But for now, he has to go up on more or less his own power one
last time. And really? I think he can do it even if Mega Man hasn't
dropped a bit. Rely on your strength, not an opponent's weakness.<br><br>And Snake is invincible, ****ers. <b>BOOK IT.</b><br><br><b>Karma Hunter's Krazy Prediction: Solid Snake with 53.64%.</b><br><br><i>Watch out, main bracket!</i><br><br><br> <br><b>Guest&#8217;s Analysis</b> - <i>HaRRich</i><br><br>The future VS The past.<br><br>Casual bracket-makers VS Contest regulars.<br><br>Konami's icon VS Capcom's icon.<br><br>Socom VS Blaster.<br><br>Bandanna VS Helmet.<br><br><b>Who wins?!</b><br><br>Does hype ever mean anything in the contests?<br><br>Do minor releases ever mean anything for icons?<br><br>Does the influx of a new system ruin our previous year's stats?<br><br>Did the sprite round make Solid Snake look worse than he should have against Yoshi?<br><br>Did KH2 make Mega Man look worse than he should have against Sora?<br><br><b>Where are the answers?!</b><br><br>...I got your back on this one guys.<br><br>Future,
regulars, Capcom's, Socom, Bandanna, from time to time, rarely, more
than we realize (and expect next year to be chaos), barely, surely.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 11/8/2006 9:14:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346327739">message detail</a>
 | #323</td></tr>
<tr class="even"><td>
Crew favours Snake?<br><br>Mega Man = lock to win<br><br><b>TuRtLe</b><br>~~~<br>81/88 in the contest. My analysis topic here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=768178" class="name">Master Moltar</a> |
Posted 11/8/2006 9:16:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346328065">message detail</a>
 | #324</td></tr>
<tr class="even"><td>To get more serious with it now, I'll try to keep
this fairly simple for the most part...but Solid Snake has been on an
absolute rampage thus far this contest while Mega Man's shown weakness
at so many different angles. Before the contest even started, it was
noted that Solid Snake had a 1-seed while Mega Man had a 2-seed and
Zero had a 7-seed, which caught some eyes but generally not many people
looked into it any further than just "laff, seeding"...not to mention
The Boss got four seeds higher than Roll and did nearly 5% better
against Tifa than Roll did against Yuna, but at least that one was
expected. Right before the contest started, we saw in a poll that Solid
Snake is the most favored character to win the male's side of the
bracket...now, granted, Mega Man's never had much bracket support
(especially against Solid) yet has still pulled out big-time wins
against him twice before ( 14.53% in 2k3 and 31.34% in 2k4 for Mega
Man's bracket support to get to the Final Four, both of which featured
Mega/Solid in the Elite Eight), but it can only help Solid Snake.<br><br>In
the first round, Solid beat Soma Cruz worse than Samus beat Nidoran F
while Mega allowed Axel to crack 30%. In the second round, Solid made a
post-KH2 Squall look like Luigi (who Squall has 60-40'd before...and
Squall just got done making Tidus look nearly as low as Geno, no less)
while Mega Man failed to even match Bowser's percentage against
Ryu...and Solid &gt; Bowser in the sprite round last year, too (though
it should be said that Mega did outdo Solid's performance against Ryu
in 2k3). In the third round, they got each other's Sweet Sixteen
opponents last year...and both of them dished out Something Fishy to
their opponents last year, but I'm more impressed with Solid for this
year's Sweet Sixteen because Solid got his worst sprite to date (which
is probably negated by his face-shot in the background, but it needed
to be said) and still managed to beat Yoshi -- who was hot off of
beating Dante when all signs pointed to Dante winning with a bit of
room to spare -- nearly 3% worse than Mega beat Sora -- who was hot off
of...getting 36% on Gordon Freeman.<br><br>The last point I'll bring
out is super-stition...yeah, I'm going there. Think back to Mario/Crono
-- Mario barely won twice, then Crono redeemed himself by firmly
beating his ass in 2k4 in their third match. Solid made Knuckles his
whipping boy in the second round for three years straight, but the
third match was easliy when Knuckles did his best (and was the only
time he broke 40% against him). Mega and Solid have faced off twice
before...and all signs are pointing at Solid to make the third one a
charm...<br><br>...I do want to mention though that this match is a
toss-up, and don't let anybody tell you differently. Also, you can find
counterpoints to many of the things I said and come up with a good
argument for Mega Man to win. Thing is, I feel like you have to delve
too deep too often to do that, whereas the signs for Solid Snake have
oftentimes been right in our face and we notice it right off the bat.
Because of that, I'm going with that feeling instead of my bracket (and
personal preference, even, though both are two of the best out there).<br><br><i><b>Solid Snake</b> wins with 52.12%</i><br> <br> <br> <br>Crew
Consensus: Whew...after all that, the Crew has reached a decision.
Snake for the win! He's favored 6-1 by the Crew because of his
impressive showings thus far. Will we be Crew Curse'd, or right for
once?!
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3786792" class="name">PortugalTheMann</a> |
Posted 11/8/2006 9:16:52 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346328262">message detail</a>
 | #325</td></tr>
<tr class="even"><td>
6-1 Snake?<br><br>Lopen for the point!<br><br>---<br>Portugal. The Man<br>Cheer Up Emo Kids
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3613117" class="name">The_Lady_Ashe</a> |
Posted 11/8/2006 9:17:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346328340">message detail</a>
 | #326</td></tr>
<tr class="even"><td>
Way to go, Turtle. Even <i>I</i> managed to avoid breaking it. Couldn't you have waited just two minutes? D:<br>~~~<br><i>The one. The only. <b>Lady Ashe.</b></i>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/8/2006 9:17:24 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346328414">message detail</a>
 | #327</td></tr>
<tr class="even"><td>
<i>DpOblivion's Quick Analysis:</i><br><br>Samus underperforms. Zelda
overperforms. What's gonna happen next round? Well, we got this round
to deal with first. The first match between 2 Noble Niners is Solid
Snake vs. Mega Man. MM beat SS with 57% in 2004. Since then, SS has had
MGS3, and hype for MGS4 and SSBB, so SS has clearly grown since then.
But will that be enough? Mega Man is a classic, and has been around the
block quite a few more times than Snake has.<br><br>My vote: Solid Snake<br>My bracket: Mega Man<br>My prediction: Mega Man with 53%<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/8/2006 9:17:59 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346328567">message detail</a>
 | #328</td></tr>
<tr class="even"><td>
6-1 in favor of.....SNAKE? Wow....<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 11/8/2006 9:18:00 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346328571">message detail</a>
 | #329</td></tr>
<tr class="even"><td>
I thought he was done &lt;_&lt;<br><br><b>TuRtLe</b><br>~~~<br>81/88 in the contest. My analysis topic here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/8/2006 9:18:06 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346328598">message detail</a>
 | #330</td></tr>
<tr class="even"><td>
AHAHAHAHAHAHA I WROTE MORE THAN EVERYONE COMBINED<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=484834" class="name">BlAcK TuRtLe</a> |
Posted 11/8/2006 9:18:35 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346328698">message detail</a>
 | #331</td></tr>
<tr class="even"><td>
Besides, noone cares what Harrich has to say &gt;_&gt;<br><br><b>TuRtLe</b><br>~~~<br>81/88 in the contest. My analysis topic here:<br><a class="linkification-ext" href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1" title="Linkification: http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1">http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=30498383&amp;page=1</a>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3251974" class="name">trannyscience</a> |
Posted 11/8/2006 9:19:55 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346328998">message detail</a>
 | #332</td></tr>
<tr class="even"><td>
hey karma hunter get a life nerdface<br><br>hahahahahahaa<br><br>...ha<br>---<br>zizzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/8/2006 9:22:05 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346329528">message detail</a>
 | #333</td></tr>
<tr class="even"><td>
no u<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3251974" class="name">trannyscience</a> |
Posted 11/8/2006 9:22:19 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346329583">message detail</a>
 | #334</td></tr>
<tr class="even"><td>
owned :(<br>---<br>zizzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/8/2006 9:36:53 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346333282">message detail</a>
 | #335</td></tr>
<tr class="even"><td>
Who would've thought it would be everyone else making the stupid, crazy prediction, and with Lopen being the lone smart one?<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/8/2006 10:15:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346342981">message detail</a>
 | #336</td></tr>
<tr class="even"><td>
I'm sorry that not taking the character who's projected to win with <i>52.35%</i> last year is is such a stupid choice.<br><br>Heh, you'd think that Luigi could have beaten Zero or something!!!<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=476641" class="name">DaruniaTheGoron</a> |
Posted 11/8/2006 10:29:16 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346346322">message detail</a>
 | #337</td></tr>
<tr class="even"><td>
Hit or miss Lopen shall hit once again!<br>---<br>CB06 - Score: <b>98/104 </b>Rank: <b>Tied - 213th </b>Yesterday's Pick:<b> Samus</b> <br>Today's Pick: <b>Zelda</b> Tomorrow's Pick: <b>Mega Man</b> Losses: <b>Cortana, Ganon, Zero, MC, Kirby</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=152338" class="name">Lopen</a> |
Posted 11/8/2006 10:33:28 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346347341">message detail</a>
 | #338</td></tr>
<tr class="even"><td>
<i>Now, I know you gots to know&#8230; why haven't I abandoned him for Snake like the rest of the crew almost certainly has?</i><br><br>Look, I'm psychic!  Well, the point is easy to get now!  Ha ha ha ha...<br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=254355" class="name">Lugia2</a> |
Posted 11/9/2006 5:59:10 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346392430">message detail</a>
 | #339</td></tr>
<tr class="even"><td>
Tradition is dead.<br><br>GFAW<br><br>GF falls below 40%<br><br>Luigi gets in the third round<br><br>Crew doesn't get cursed.<br><br>IS NOTHING SACRED!?!?!<br>---<br>VIVA LA REVOLU-er, Wii!!<br>Thank you Nintendo, thank you very much.
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3608784" class="name">THEJackSparrow</a> |
Posted 11/9/2006 9:28:42 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346407572">message detail</a>
 | #340</td></tr>
<tr class="even"><td>
<i>difference this time around is that the writing is clearly on the wall, whereas Cloud hit everyone out of nowhere.</i><br><br>What? Cloud doubling up Sonic wasn't a big enough hint for you?<br>---<br><b>Captain Jack Sparrow's Run to the NCAA Character Contest II Championship:</b><br><i>Week 7</i>: Bahamut (2-4)
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/9/2006 9:37:54 AM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346408591">message detail</a>
 | #341</td></tr>
<tr class="even"><td>
Another Crew point for Kay Aitch in a Snake match!<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=152338" class="name">Lopen</a> |
Posted 11/9/2006 1:36:01 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346441335">message detail</a>
 | #342</td></tr>
<tr class="even"><td>
Well, at least this makes Dante look good.  <br><br>Dante &gt; Mega Man next year, book it <i>!!</i><br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=721959" class="name">Karma Hunter</a> |
Posted 11/9/2006 1:37:42 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346441609">message detail</a>
 | #343</td></tr>
<tr class="even"><td>
...actually, if Mega Man doesn't rebound Dante really could win that match with Devil May Cry 4 on his side. o_________O<br>---<br><b>*kills self*<br>Commit it to memory.</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=683142" class="name">transience</a> |
Posted 11/9/2006 1:37:44 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346441616">message detail</a>
 | #344</td></tr>
<tr class="even"><td>
i think Dp is worthy of an lol..?<br>---<br>xyzzy
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=152338" class="name">Lopen</a> |
Posted 11/9/2006 1:44:14 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346442626">message detail</a>
 | #345</td></tr>
<tr class="even"><td>
Hey, I'm not joking about that booking! Mega Man's in very real danger
from a good few non-noble-niners if he doesn't help himself. My money's
on Post DMC4 Dante, Squall, or Vincent though, because they aren't held
back by the old school support. I'm not seeing Mega Man lose to
Ganondorf or Zelda anytime soon. <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=508292" class="name">DpObliVion</a> |
Posted 11/9/2006 1:53:36 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346444113">message detail</a>
 | #346</td></tr>
<tr class="even"><td>
<i>i think Dp is worthy of an lol..?</i><br><br>Indeed, tranny. Indeed.<br><br>I guess I better get to work on Sonic/Crono to try and redeem myself....<br><br>---<br>Dp, you are one awesome, sexy bastard. I less than 3 you. -Shadow Ryoko<br><b>NEW YORK METS: 2006 NL EASTERN DIVISION CHAMPS</b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=2821123" class="name">MyWorldIsZelda</a> |
Posted 11/9/2006 2:41:34 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346452932">message detail</a>
 | #347</td></tr>
<tr class="even"><td>
<i>My money's on Post DMC4 Dante, Squall, or Vincent though, because
they aren't held back by the old school support. I'm not seeing Mega
Man lose to Ganondorf or Zelda anytime soon.</i><br><br>Ha ha ha! <br><br>Oh, man, you never cease to make me laugh Lopen. =p<br><br>---<br>"Let's face it: the princess Zelda has always been a symbol of sexual desire."
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=152338" class="name">Lopen</a> |
Posted 11/9/2006 2:51:08 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346454886">message detail</a>
 | #348</td></tr>
<tr class="even"><td>
Mega Man would yank their old school support out from under then like a <i>rug</i>.  A <i>foul</i> rug!  <br><br>Mega Man &gt; Zelda/Ganondorf (they're totally equal!), 53%+!  <br>---<br><b>Squall:</b> <i>"Hi, like Cloud from the last game, I am full of angst and am named after weather."</i> - Slow Beef
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=788233" class="name">PokemonPatriarch</a> |
Posted 11/9/2006 2:55:13 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346455721">message detail</a>
 | #349</td></tr>
<tr class="even"><td>
It truly is sad to see my favorite of the NN drop down to last place :(<br>---<br>Proud fanboy of the Ogre Battle saga!!!<br><b>~~~Allah Approves~~~ </b>
</td>
</tr>
<tr><td>
<a href="http://boards.gamefaqs.com/gfaqs/user.php?board=8&amp;topic=31382187&amp;user=3605206" class="name">wavedash101</a> |
Posted 11/9/2006 2:58:40 PM |
<a href="http://boards.gamefaqs.com/gfaqs/detail.php?board=8&amp;topic=31382187&amp;message=346456494">message detail</a>
 | #350</td></tr>
<tr class="even"><td>
Assuming MM does get into SSBB, and game that actually translates into
contest strength...unlike generic MM game #45 or so...he'll remain
above the elites...<br>---<br><b>Our shields cannot withstand wavedashing of this magnitude!</b><br>Board 8's Unofficial Master of the Phoenix Down
</td>
</tr>


</tbody></table>

</div>
<div class="pagejumper">
<ul>
<li class="first">Jump to Page: <a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187">1</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=1">2</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=2">3</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=3">4</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=4">5</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=5">6</a></li>
<li>7</li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=7">8</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=8">9</a></li>
<li><a href="http://boards.gamefaqs.com/gfaqs/genmessage.php?board=8&amp;topic=31382187&amp;page=9">10</a></li>
</ul>
</div>


</div>
<img src="genmessage7_files/c.gif" height="1" width="1">
<div id="sponsored_links">
	<iframe src="genmessage7_files/search.htm" id="sponsored_iframe" marginheight="0" marginwidth="0" longdesc="Sponsored Matches" frameborder="0" height="187" scrolling="no" width="570"></iframe>
</div>	</div>
	<div id="gamefox-quickpost-normal"><div id="gamefox-quickpost-title">QuickPost</div><form id="gamefox-quickpost-form" action="post.php?board=8&amp;topic=31382187&amp;page=6" method="post"><textarea name="message" wrap="virtual" id="gamefox-message" rows="15" cols="100"></textarea><br><input id="gamefox-quickpost-btn" name="quickpost" value="Post Message" type="button"> <input name="post" value="Preview Message" type="submit"> <input name="post" value="Preview and Spellcheck Message" type="submit"> <input value="Reset" type="reset"> </form></div><div id="footer">
		<div id="sitenav">
			<a href="http://www.gamespot.com/downloads/index.html">Free Games</a> |
			<a href="http://www.gamespot.com/news/index.html">News</a> |
			<a href="http://www.gamespot.com/pc/index.html">PC</a> |
			<a href="http://www.gamespot.com/xbox/index.html">Xbox</a> |
			<a href="http://www.gamespot.com/xbox360/index.html">Xbox 360</a> |
			<a href="http://www.gamespot.com/gamecube/index.html">GameCube</a> |
			<a href="http://www.gamespot.com/ps2/index.html">PlayStation 2</a> |
			<a href="http://www.gamespot.com/ps3/index.html">PS3</a> |
			<a href="http://www.gamespot.com/psp/index.html">PSP</a> |
			<a href="http://www.gamespot.com/ds/index.html">Nintendo DS</a> |
			<a href="http://www.gamespot.com/gba/index.html">GBA</a> |
			<a href="http://www.gamespot.com/cheats.html">Cheat Codes</a> |
			<a href="http://www.gamespot.com/pages/forums/index.php">Forums</a>
		</div>
		<div id="broadnav">
			<p style="margin-left: 100px;">
			<a href="http://www.gamerankings.com/">Game Rankings</a> :
			<a href="http://www.gamerankings.com/itemrankings/defaultPC.asp">PC</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultxbox.asp">Xbox</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultgc.asp">GameCube</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultPS2.asp">PlayStation 2</a> |
			<a href="http://www.gamerankings.com/itemrankings/defaultGBA.asp">GBA</a>
			&nbsp; &nbsp; &nbsp; &nbsp;
			<a href="http://www.metacritic.com/">Metacritic.com</a>
			</p>
			<p>
			<a href="http://www.gamespot.com/misc/helpcenter.html">Help</a> |
			<a href="http://www.gamespot.com/misc/worldwide.html">Worldwide</a> |
			<a href="http://www.gamespot.com/misc/aboutus.html">About Us </a> |
			<a href="http://www.cnetnetworks.com/advertise/properties/ge_portfolio.php?tag=gs.ft.no">Advertise on GameFAQs</a> |
			<a href="http://www.gamespot.com/games.html?type=top_rated&amp;page_type=games">Shop for Games</a> |
			<a href="http://e3.gamespot.com/">E3</a>
			</p>
		</div>
		<div id="todayoncnet">
			Today on CNET:
			<a href="http://reviews.cnet.com/Music/2001-6450_7-0.html">MP3 Players</a> |
			<a href="http://reviews.cnet.com/Cell_phones/2001-3504_7-0.html">Cell Phones</a> |
			<a href="http://reviews.cnet.com/Digital_cameras/2001-6501_7-0.html">Digital Cameras</a> |
			<a href="http://reviews.cnet.com/Notebooks/2001-3121_7-0.html">Laptops</a> |
			<a href="http://reviews.cnet.com/Handhelds/2001-3127_7-0.html">PDAs</a> |
			<a href="http://reviews.cnet.com/4521-6531_7-5021436-3.html">Speakers</a> |
			<a href="http://reviews.cnet.com/Web_hosting/2001-6540_7-0.html">Web Hosting</a> |
			<a href="http://clearance.cnet.com/">Overstock Clearance</a> |
			<a href="http://shopper.cnet.com/4520-5-6276184.html">Tech Bargains</a>
		</div>
		<div id="cnetfooter">
			<script language="javascript">
				document.write("<div style=\"float:right;\">Visit other CNET Networks sites: <select name=\"menu\" id=\"form_menu\"><option selected value=\"\">Select Site</option><option value=\"http://www.bnet.com\">BNET</option><option value=\"http://www.chow.com\">CHOW</option><option value=\"http://www.cnet.com\">CNET.com</option><option value=\"http://www.cnetchannel.com\">CNET Channel</option><option value=\"http://www.gamespot.com\">GameSpot</option><option value=\"http://www.cnetnetworks.com/advertise/properties/international.html\">International Media</option><option value=\"http://www.mp3.com\">MP3.com</option><option value=\"http://www.mysimon.com\">mySimon</option><option value=\"http://www.search.com\">Search.com</option><option value=\"http://techrepublic.com.com/\">TechRepublic</option><option value=\"http://www.tv.com\">TV.com</option><option value=\"http://www.webshots.com\">Webshots</option><option value=\"http://www.zdnet.com\">ZDNet</option></select> <input type=\"button\" value=\"Go\" onClick=\"window.location=document.getElementById(\'form_menu\').options[document.getElementById(\'form_menu\').selectedIndex].value;\" /></div>");
			</script><div style="float: right;">Visit other CNET Networks sites: <select name="menu" id="form_menu"><option selected="selected" value="">Select Site</option><option value="http://www.bnet.com">BNET</option><option value="http://www.chow.com">CHOW</option><option value="http://www.cnet.com">CNET.com</option><option value="http://www.cnetchannel.com">CNET Channel</option><option value="http://www.gamespot.com">GameSpot</option><option value="http://www.cnetnetworks.com/advertise/properties/international.html">International Media</option><option value="http://www.mp3.com">MP3.com</option><option value="http://www.mysimon.com">mySimon</option><option value="http://www.search.com">Search.com</option><option value="http://techrepublic.com.com/">TechRepublic</option><option value="http://www.tv.com">TV.com</option><option value="http://www.webshots.com">Webshots</option><option value="http://www.zdnet.com">ZDNet</option></select> <input value="Go" onclick="window.location=document.getElementById('form_menu').options[document.getElementById('form_menu').selectedIndex].value;" type="button"></div>
			<div id="aboutcnet">
				<a href="http://www.cnetnetworks.com/">About CNET Networks</a> | <a href="http://www.cnetnetworks.com/careers/">Jobs</a> | <a href="http://www.cnetnetworks.com/advertise/">Advertise</a> | <a href="http://www.cnetnetworks.com/partnerships/">Partnerships</a>
			</div>
			<noscript>
<div> <a href="http://www.bnet.com/">BNET</a> | <a
href="http://www.chow.com/">CHOW</a> | <a
href="http://www.cnet.com/">CNET.com</a> | <a
href="http://www.cnetchannel.com/main/default.aspx">CNET Channel</a> |
<a href="http://www.gamespot.com/">GameSpot</a> | <a
href="http://www.cnetnetworks.com/advertise/properties/international.html">International
Media</a> | <a href="http://www.mp3.com/">MP3.com</a> | <a
href="http://www.mysimon.com/2001-1_8-0.html">mySimon</a> | <a
href="http://www.search.com/">Search.com</a> | <a
href="http://techrepublic.com.com/">TechRepublic</a> | <a
href="http://www.tv.com/">TV.com</a> | <a
href="http://www.webshots.com/">Webshots</a><br /> <a
href="http://www.zdnet.com/">ZDNet</a> </div> </noscript>
		</div>
	</div>
	<div id="copyright">
		<div>
		<a href="http://www.cnet.com/aboutcnet/editorial/copyright.html?tag=gs.ft.no">Copyright</a> �2006 CNET Networks, Inc. All Rights Reserved.
		<a href="http://www.cnet.com/html/aboutcnet/editorial/privacy.html?tag=gs.ft.no">Privacy Policy</a> |
		<a href="http://www.cnet.com/html/aboutcnet/editorial/terms.html?tag=gs.ft.no">Terms of Use</a>
		</div>
	</div>
	<br style="clear: both; font-size: 0pt; height: 0pt;">
</div>
<script src="genmessage7_files/1086.js"></script>
<script language="JavaScript">
<!--
var SymRealOnLoad;
var SymRealOnUnload;

function SymOnUnload()
{
  window.open = SymWinOpen;
  if(SymRealOnUnload != null)
     SymRealOnUnload();
}

function SymOnLoad()
{
  if(SymRealOnLoad != null)
     SymRealOnLoad();
  window.open = SymRealWinOpen;
  SymRealOnUnload = window.onunload;
  window.onunload = SymOnUnload;
}

SymRealOnLoad = window.onload;
window.onload = SymOnLoad;

//-->
</script>

</body></html>